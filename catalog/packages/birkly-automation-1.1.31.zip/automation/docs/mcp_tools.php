<?php
/**
 * Automation plugin MCP tools — registered when the plugin is active.
 *
 * Docs: docs/mcp-tools.md · read_birkly_docs topic automation
 */

declare(strict_types=1);

require_once __DIR__ . '/../automation.php';
require_once __DIR__ . '/../init.php';
require_once __DIR__ . '/../includes/AutomationMcpAdmin.php';

function automation_mcp_user_can(array $aiUser, string $permission = 'manage_content'): bool
{
    return automation_mcp_admin_user_can($aiUser, $permission);
}

/** @return array{status: string, message?: string}|null */
function automation_mcp_require(array $aiUser): ?array
{
    if (!automation_mcp_user_can($aiUser)) {
        return ['status' => 'error', 'message' => 'Permission denied for Automation (requires manage_content)'];
    }
    return null;
}

function automation_mcp_bootstrap(): void
{
    if (!automation_bootstrap()) {
        throw new RuntimeException('Automation plugin is not active');
    }
}

function automation_mcp_schema_object(array $properties = [], array $required = []): array
{
    $schema = ['type' => 'object', 'properties' => $properties];
    if ($required !== []) {
        $schema['required'] = $required;
    }
    return $schema;
}

/** @return array<string, array> */
function automation_mcp_tool_registry(): array
{
    $automationId = ['type' => 'string', 'description' => 'Automation id'];
    $payload = [
        'type' => 'object',
        'description' => 'Action-specific fields (merged with action name for automation_admin_action)',
        'additionalProperties' => true,
    ];

    return [
        'automation_list_admin_actions' => [
            'description' => 'List all Automation admin API actions available via automation_admin_action (full admin parity).',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = automation_mcp_require($aiUser)) {
                    return $err;
                }
                return [
                    'status' => 'ok',
                    'data' => ['actions' => automation_mcp_admin_action_catalog()],
                ];
            },
        ],
        'automation_admin_action' => [
            'description' => 'Run any Automation admin action (same as api/automation.php). Pass action name and payload fields.',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'action' => ['type' => 'string', 'description' => 'Admin action name (e.g. dry_run, run_live, save_mail_settings)'],
                'payload' => $payload,
            ], ['action']),
            'handler' => static function (array $arguments, array $aiUser): array {
                $action = (string) ($arguments['action'] ?? '');
                $payload = is_array($arguments['payload'] ?? null) ? $arguments['payload'] : $arguments;
                unset($payload['action'], $payload['payload']);
                return automation_mcp_dispatch_admin($action, $payload, $aiUser);
            },
        ],
        'automation_dashboard_summary' => [
            'description' => 'Automation dashboard summary: enabled workflows, queue, recent runs.',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('dashboard_summary', $arguments, $aiUser);
            },
        ],
        'automation_list_workflows' => [
            'description' => 'List automation workflows. Optional filters: enabled, trigger type fields.',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object([
                'filters' => ['type' => 'object', 'additionalProperties' => true],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('list', $arguments, $aiUser);
            },
        ],
        'automation_get_workflow' => [
            'description' => 'Get one automation workflow by id (trigger, conditions, actions, graph).',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object(['automation_id' => $automationId], ['automation_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('get', $arguments, $aiUser);
            },
        ],
        'automation_list_recipes' => [
            'description' => 'List built-in automation recipe packs and individual recipes.',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object([
                'pack' => ['type' => 'string', 'description' => 'Optional pack id filter'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('list_recipes', $arguments, $aiUser);
            },
        ],
        'automation_get_recipe' => [
            'description' => 'Get one automation recipe definition and validation result.',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object(['recipe_id' => ['type' => 'string']], ['recipe_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('get_recipe', $arguments, $aiUser);
            },
        ],
        'automation_get_blocks' => [
            'description' => 'List available trigger, condition, and action blocks for building workflows.',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object([
                'type' => ['type' => 'string', 'description' => 'trigger, condition, or action — omit for all'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('get_blocks', $arguments, $aiUser);
            },
        ],
        'automation_setup_health' => [
            'description' => 'Automation setup health: mail transport, queue, blocking issues before go-live.',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('setup_health', $arguments, $aiUser);
            },
        ],
        'automation_queue_status' => [
            'description' => 'Automation job queue depth and processing status.',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('queue_status', $arguments, $aiUser);
            },
        ],
        'automation_get_logs' => [
            'description' => 'Recent automation execution logs; optional filter by automation_id.',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object([
                'automation_id' => $automationId,
                'limit' => ['type' => 'number'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('get_logs', $arguments, $aiUser);
            },
        ],
        'automation_get_collections' => [
            'description' => 'List site collections for automation workflow pickers (slug, title, sub-collections).',
            'category' => 'read',
            'permissions' => ['manage_content', 'read'],
            'inputSchema' => automation_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('get_collections', $arguments, $aiUser);
            },
        ],
        'automation_create_workflow' => [
            'description' => 'Create an automation workflow. Pass name, trigger, conditions, actions, and/or graph.',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'name' => ['type' => 'string'],
                'enabled' => ['type' => 'boolean'],
                'trigger' => ['type' => 'object'],
                'conditions' => ['type' => 'array'],
                'actions' => ['type' => 'array'],
                'graph' => ['type' => 'object'],
                'recipe_id' => ['type' => 'string'],
            ], ['name']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('create', $arguments, $aiUser);
            },
        ],
        'automation_update_workflow' => [
            'description' => 'Update an automation workflow by id.',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'automation_id' => $automationId,
                'name' => ['type' => 'string'],
                'enabled' => ['type' => 'boolean'],
                'trigger' => ['type' => 'object'],
                'conditions' => ['type' => 'array'],
                'actions' => ['type' => 'array'],
                'graph' => ['type' => 'object'],
            ], ['automation_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('update', $arguments, $aiUser);
            },
        ],
        'automation_delete_workflow' => [
            'description' => 'Delete an automation workflow by id.',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object(['automation_id' => $automationId], ['automation_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('delete', $arguments, $aiUser);
            },
        ],
        'automation_import_recipe' => [
            'description' => 'Import a built-in recipe as a new workflow. Optional name, enabled, to (email override).',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'recipe_id' => ['type' => 'string'],
                'name' => ['type' => 'string'],
                'enabled' => ['type' => 'boolean'],
                'to' => ['type' => 'string', 'description' => 'Override notification email in recipe'],
            ], ['recipe_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('import_recipe', $arguments, $aiUser);
            },
        ],
        'automation_import_recipe_pack' => [
            'description' => 'Import all recipes from a pack (e.g. commerce). Optional enabled, to email override.',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'pack' => ['type' => 'string', 'description' => 'Pack id (default commerce)'],
                'enabled' => ['type' => 'boolean'],
                'to' => ['type' => 'string'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('import_recipe_pack', $arguments, $aiUser);
            },
        ],
        'automation_test_workflow' => [
            'description' => 'Test an automation in dry-run mode (execute_automation with _test_mode; no real side effects).',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'automation_id' => $automationId,
                'context' => ['type' => 'object', 'description' => 'Optional sample context'],
            ], ['automation_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('test', $arguments, $aiUser);
            },
        ],
        'automation_dry_run' => [
            'description' => 'Structured dry-run: validate trigger/conditions/actions without side effects (admin Dry Run panel).',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'automation_id' => $automationId,
                'context' => ['type' => 'object', 'description' => 'Optional sample context'],
            ], ['automation_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('dry_run', $arguments, $aiUser);
            },
        ],
        'automation_run_live' => [
            'description' => 'Manual live run — executes real email, webhook, and Slack actions (admin Confirm & Run Live).',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'automation_id' => $automationId,
                'context' => ['type' => 'object', 'description' => 'Optional run context'],
                'skip_conditions' => ['type' => 'boolean', 'description' => 'Skip condition checks'],
            ], ['automation_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('run_live', $arguments, $aiUser);
            },
        ],
        'automation_save_mail_settings' => [
            'description' => 'Save Automation Setup mail settings (From, method log/smtp/mail, SMTP host, etc.).',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'method' => ['type' => 'string'],
                'from_email' => ['type' => 'string'],
                'from_name' => ['type' => 'string'],
                'smtp_host' => ['type' => 'string'],
                'smtp_port' => ['type' => 'number'],
                'smtp_user' => ['type' => 'string'],
                'smtp_password' => ['type' => 'string'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('save_mail_settings', $arguments, $aiUser);
            },
        ],
        'automation_send_test_email' => [
            'description' => 'Send a real test email using current Automation Setup transport.',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'to' => ['type' => 'string', 'description' => 'Recipient email'],
            ], ['to']),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('send_test_email', $arguments, $aiUser);
            },
        ],
        'automation_process_queue_now' => [
            'description' => 'Process pending automation queue jobs immediately (admin drain).',
            'category' => 'write',
            'permissions' => ['manage_content'],
            'inputSchema' => automation_mcp_schema_object([
                'limit' => ['type' => 'number', 'description' => 'Max jobs (1–100, default 25)'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                return automation_mcp_dispatch_admin('process_queue_now', $arguments, $aiUser);
            },
        ],
    ];
}
