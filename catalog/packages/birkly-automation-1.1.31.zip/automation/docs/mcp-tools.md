# Automation MCP tools

Registered when the Automation plugin is **active**. Tool definitions and handlers live in `docs/mcp_tools.php`; admin parity dispatch lives in `includes/AutomationMcpAdmin.php`.

## When to use

- Manage workflows, recipes, queue health, mail setup, dry-runs, and live runs from MCP.
- Call `list_plugins` before assuming tools exist.
- Call `automation_list_admin_actions` to discover every admin API action, or use named tools below.
- Read full context: `read_birkly_docs` topic `automation` or `birkly://docs/plugin/automation`.

## Generic admin dispatch

| Tool | Purpose |
|------|---------|
| `automation_list_admin_actions` | Catalog of all `api/automation.php` actions |
| `automation_admin_action` | Run any action: `action` + `payload` (or top-level fields) |

## Read tools

| Tool | Purpose |
|------|---------|
| `automation_dashboard_summary` | Dashboard widget: enabled count, queue, recent runs |
| `automation_list_workflows` | All workflows (`filters` optional) |
| `automation_get_workflow` | One workflow by `automation_id` |
| `automation_list_recipes` | Recipe packs + recipes |
| `automation_get_recipe` | One recipe + validation |
| `automation_get_blocks` | Trigger/condition/action block catalog |
| `automation_get_collections` | Site collections for workflow pickers |
| `automation_setup_health` | Mail + queue readiness |
| `automation_queue_status` | Queue depth |
| `automation_get_logs` | Execution logs |

## Write tools

| Tool | Purpose |
|------|---------|
| `automation_create_workflow` | Create workflow |
| `automation_update_workflow` | Update by `automation_id` |
| `automation_delete_workflow` | Delete by `automation_id` |
| `automation_import_recipe` | Import built-in recipe |
| `automation_import_recipe_pack` | Import full recipe pack |
| `automation_test_workflow` | Execute in test mode (no real side effects) |
| `automation_dry_run` | Structured dry-run steps (admin Dry Run panel) |
| `automation_run_live` | **Live** run — real email/webhook/Slack |
| `automation_save_mail_settings` | Save Setup mail transport settings |
| `automation_send_test_email` | Send Setup test email (`to` required) |
| `automation_process_queue_now` | Drain queue (`limit` optional) |

Additional admin actions (cron URLs, template preview, context variables, `process_queue`, `process_scheduled`) are available via `automation_admin_action`.

## Permissions

Requires `manage_content` (or admin role) on the connected MCP user.

## Safety

- `automation_dry_run` and `automation_test_workflow` do not send live email, Slack, Teams, or webhooks.
- `automation_run_live` and `automation_send_test_email` perform **real** side effects — confirm with the user first.
- Use `automation_setup_health` before enabling production workflows.
