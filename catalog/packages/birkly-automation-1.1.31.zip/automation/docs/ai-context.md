# Automation — AI context

Official Birkly plugin for event-driven workflows (triggers → conditions → actions).

## MCP tools (when plugin active)

Inbound MCP exposes `automation_*` tools — see `docs/mcp-tools.md`.

- **Full admin parity:** `automation_list_admin_actions` + `automation_admin_action` mirror every `api/automation.php` action (recipes, blocks, dry-run, live run, mail settings, test email, template preview, collections, dashboard, queue, cron info, etc.).
- **Named shortcuts:** `automation_dry_run`, `automation_run_live`, `automation_import_recipe_pack`, `automation_save_mail_settings`, `automation_send_test_email`, `automation_get_collections`, `automation_dashboard_summary`, plus workflow CRUD and queue tools.
- Use `automation_setup_health` before go-live.
- `automation_dry_run` / `automation_test_workflow` never send real messages; `automation_run_live` and `automation_send_test_email` do.

## Critical product facts

- **Test / dry-run never sends** email, Slack, Teams, or webhooks.
- **Setup** configures email transport (SMTP recommended, Log, or PHP mail) and queue processing.
- Cloud/Docker hosts almost never deliver PHP `mail()` — prefer SMTP; use **Send test email** to verify.
- Slack/Teams need an **Incoming Webhook URL on the action**, not OAuth in Setup.
- Triggers enqueue jobs; current builds also process a small batch inline after enqueue. **Process queue now** drains stuck jobs. Cron still recommended.
- Canvas persists `graph` with If-true / Else edges; runtime walks branches.

## Admin surfaces

- List + Setup + Documentation tabs (`?page=automation`)
- Dedicated editor (`?page=automation-editor`)

## Help topics (in-plugin Documentation tab)

overview, getting-started, setup, email, slack-webhooks, triggers, workflows, examples, troubleshooting
