# Email delivery

> **Migration note:** As of Birkly Phase 65, email delivery is managed in **Settings → Connections**.
> Automation → Setup now links to Connections and shows a read-only view of the legacy transport.
> Send Email actions use the shared Connections mail pipeline when it is available.

Send Email actions use the transport configured under **Settings → Connections** (or the legacy view under **Automation → Setup** if Connections is unavailable).

## Choose a transport

### SMTP (recommended)

Works on Dokploy, Docker, and most VPS hosts.

Typical providers:

- Brevo (Sendinblue)
- Mailgun
- Postmark
- Amazon SES
- Your hosting SMTP (cPanel, etc.)

Common settings:

| Field | Usual value |
|-------|-------------|
| Host | `smtp.…` from provider docs |
| Port | `587` |
| Encryption | STARTTLS |
| Username | mailbox or API user |
| Password | SMTP password or API key |
| From | Verified sender / domain |

After save, always click **Send test email**.

### Log only

Writes accepted messages to **Recent sends** instead of the network.

Use this to prove:

- the trigger fired
- the queue processed
- the email action ran

Then switch to SMTP for real inboxes.

### PHP mail()

Calls PHP `mail()`. Fine on some classic shared hosts with a local MTA. On cloud containers it often returns success while **nothing is delivered**. Prefer SMTP.

## Templates in email fields

Subject and body support `{{variable}}` placeholders.

**Recommended defaults** (used when you add a Send Email node):

```text
Subject: {{automation.name}}
Body:
{{trigger_summary}}

Title: {{entry.title}}
Collection: {{collection}}

Open in Birkly:
{{entry_admin_url}}
```

| Variable | Meaning |
|----------|---------|
| `{{automation.name}}` | Name of the workflow (best email subject) |
| `{{trigger_summary}}` | e.g. `New entry in "blog": My title` |
| `{{entry.title}}` / `{{entry.status}}` | Entry fields |
| `{{collection}}` | Collection slug |
| `{{entry_admin_url}}` | Admin link to open the entry (emails also get an **Open entry** button) |

Other variables depend on the trigger (status change fields, webhook payload, etc.).

## Send to one address from entry content

Use **Send Email** when the recipient comes from the triggering entry:

```text
To: {{entry.email}}
Subject: New update for {{entry.title}}
Body:
Hello {{entry.display_name}},

{{trigger_summary}}
```

Set the trigger collection so the editor shows field chips for that collection.

## Notify many people (broadcast)

Use **Send Email to Many** when something happens and you want to email a list — for example **all site users when a blog post is published**.

The inspector is split into **Recipients · Message · Delivery** tabs.

### All site users (User Management)

| Setting | Purpose |
|---------|---------|
| Recipients | **All site users** |
| User tier | Optional — limit to one membership tier |
| Verified email only | Skip users without verified addresses (recommended) |
| User status | Typically **Active** |

Requires the **User Management** plugin. Each user with a valid email receives one message.

Template tokens for site users:

| Variable | Meaning |
|----------|---------|
| `{{recipient.name}}` / `{{recipient.display_name}}` | User display name |
| `{{recipient.email}}` | User email |
| `{{recipient.tier}}` | Membership tier |
| `{{entry.title}}` / `{{entry.*}}` | The entry that triggered the workflow |

**Starter recipe:** import **Content notifications → New blog post → email all users** from Automation recipes.

### Collection entries

Use **Collection entries** when recipients live in a CMS collection (newsletter list, members collection, etc.).

| Setting | Purpose |
|---------|---------|
| Recipient collection | Collection whose entries receive mail (e.g. `members`) |
| Email field slug | Field holding each recipient address (usually `email`) |
| Entry status | Typically **Published only** |
| Optional filter field | Limit to rows where a checkbox or value matches (e.g. `notify` is checked) |
| Max recipients | Safety cap per run (default 500) |

Template tokens:

| Variable | Meaning |
|----------|---------|
| `{{recipient.display_name}}` / `{{recipient.email}}` | Each matching recipient entry |
| `{{entry.title}}` / `{{entry.*}}` | The entry that triggered the workflow |
| `{{trigger_summary}}` | Human-readable trigger line |

Example body:

```text
Hello {{recipient.display_name}},

We just posted a new event: {{entry.title}}

{{entry_admin_url}}
```

## Lookup a related entry first

Use **Lookup Related Entry** when later steps need data from another collection — for example resolve a host member from an event's `host_id` field before sending email.

1. Add **Lookup Related Entry** before Send Email (or broadcast).
2. Set lookup collection, trigger field (`{{entry.host_id}}`), and match field on the lookup collection (`member_code` or `slug`).
3. Use `{{related.email}}` or set **Context prefix** to `recipient` to reuse recipient tokens.

The executor merges the found entry into the workflow context for all following steps.

## Proving delivery

1. Setup → Send test email → your address
2. Check inbox **and spam**
3. Check Setup → Recent sends (method column shows `smtp`, `mail`, or `log`)
4. Run the workflow live (not only Test)
5. Open automation Logs for action errors

## Failure messages (what they mean)

| Message / symptom | Likely cause | Fix |
|-------------------|--------------|-----|
| Test says succeeded, no email | Dry-run only | Confirm & Run Live + SMTP |
| SMTP connect error | Wrong host/port/firewall | Fix host/port; allow outbound 587/465 |
| SMTP auth failed | Bad user/password | Reset SMTP credentials |
| Recipient rejected | Provider policy / bad To | Verify To; check provider logs |
| From rejected | Unverified domain | Verify domain / use allowed From |
| Logs empty | Queue not processed | Process queue now |
| Action error in logs | Handler threw | Read log detail; fix Setup or action fields |

## SPF / DKIM / DMARC (advanced)

For production inboxes, configure DNS at your domain registrar as your SMTP provider instructs. Without SPF/DKIM, messages may land in spam even when SMTP accepts them.

## Security

- Do not put SMTP passwords in workflow action fields — they belong in Setup only
- Prefer API keys with send-only scope when the provider offers them
- Rotate credentials if a URL or backup leaked
