# Automation recipes

Installable starter workflows (JSON) for common automation patterns. Part of **P54 P3-M3**.

## Starter packs (shipped in release zip)

| Pack | When it appears in admin | Recipes |
|------|--------------------------|---------|
| **Commerce** | Commerce active + commerce triggers registered | Post-purchase receipt, subscription dunning, low stock alert, order shipped |
| **Content notifications** | User Management active + core entry triggers | New blog post → email all site users |

The admin **Starter templates** section is a collapsed panel **below your automation list**. It only lists packs that are available on this site. Club/internal packs are excluded from the starter catalog even if their JSON files exist on disk (ops sites can still import via CLI/API).

Imported workflows are **disabled** by default. Review addresses, collections, and SMTP under **Automation → Setup** before enabling.

## Internal packs (source repo only)

`recipes/club/` and `recipes/membership-club-depth/` hold Birkly Club–specific workflows used on internal sites. They are marked `visibility: hidden`, excluded from the marketplace zip, and not shown in the default admin catalog.

## Commerce pack (`recipes/commerce/`)

| Recipe id | Name | Trigger |
|-----------|------|---------|
| `commerce-post-purchase-receipt` | Post-purchase receipt | `commerce_order_paid` |
| `commerce-subscription-dunning` | Subscription dunning | `commerce_subscription_payment_failed` |
| `commerce-low-stock-alert` | Low stock alert | `commerce_low_stock` *(expected — see notes)* |
| `commerce-order-fulfilled` | Order shipped / fulfilled | `commerce_order_shipped` |

### Trigger notes (verified in Commerce `init.php`)

| Trigger | Status |
|---------|--------|
| `commerce_order_paid` | Registered — fires on paid checkout |
| `commerce_subscription_payment_failed` | Registered — dunning / payment failure |
| `commerce_subscription_past_due` | Registered — related past-due status |
| `commerce_order_shipped` | Registered — shipment with customer notify |
| `commerce_shipment_created` | Registered — every shipment (partial/full) |
| `commerce_low_stock` | Registered in Commerce P3-M4 (`CommerceLowStockService`). Payload: `sku`, `on_hand`, `reserved`, `available`, `threshold`. |

## How merchants install

### Admin UI (recommended)

1. Activate **Automation** and any pack-specific plugins (**Commerce**, **User Management**).
2. Open **Automation** in the sidebar.
3. Under **Starter templates**, browse the pack that matches your connected plugins.
4. Click **Import** on a template (or **Import all** for a whole pack).
5. Edit the created workflow: set real email addresses, review the canvas, configure **Setup → SMTP**.
6. Enable the automation and dry-run / live-test.

Imported workflows are **disabled** by default so placeholders are not sent live.

### API

```http
GET  /api/automation.php?action=list_recipes
GET  /api/automation.php?action=list_recipes&pack=commerce
GET  /api/automation.php?action=get_recipe&recipe_id=commerce-post-purchase-receipt
POST /api/automation.php
     { "action": "import_recipe", "recipe_id": "commerce-post-purchase-receipt", "_csrf": "…" }
```

Optional import body fields:

- `enabled` — override default `false`
- `name` — override recipe name
- `to` — override email action `to` when present

### CLI

From the CMS root (plugin active):

```bash
php plugins/automation/cli/import_recipe.php commerce-post-purchase-receipt
php plugins/automation/cli/import_recipe.php --pack=commerce
php plugins/automation/cli/import_recipe.php --list
```

## Recipe JSON shape

```json
{
  "id": "commerce-example",
  "pack": "commerce",
  "name": "Example",
  "description": "…",
  "trigger": { "type": "commerce_order_paid", "config": {} },
  "conditions": [],
  "actions": [
    { "type": "email", "config": { "to": "{{customer_email}}", "subject": "…", "body": "…" } }
  ],
  "enabled": false,
  "tags": ["commerce"]
}
```

Import builds a canvas `graph` via `automation_canvas_from_workflow()` and stores the record in `settings/automations.json` through `create_automation()`.

## Template variables (commerce)

Common keys from Commerce enqueue payloads:

- Order paid: `order_id`, `customer_email`, `total_cents`, `currency`, `status`, `lines`
- Dunning: `subscription_id`, `order_id`, `customer_email`, `status`, `attempt_count`, `dunning`
- Shipped: `order_id`, `customer_email`, `shipment_id`, `tracking_number`, `carrier`, `package_count`
- Low stock: `sku`, `on_hand`, `reserved`, `available`, `threshold`

Plus shared automation vars such as `{{trigger_summary}}` and `{{automation.name}}`.
