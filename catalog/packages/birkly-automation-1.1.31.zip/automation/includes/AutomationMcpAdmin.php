<?php
/**
 * Automation MCP admin dispatch — mirrors api/automation.php without session/CSRF.
 *
 * Used by docs/mcp_tools.php so connected AI can perform any Automation admin action.
 */

declare(strict_types=1);

require_once __DIR__ . '/../automation.php';
require_once __DIR__ . '/../init.php';
require_once __DIR__ . '/recipes.php';
require_once __DIR__ . '/../template_preview.php';
require_once __DIR__ . '/cron_auth.php';

/**
 * @return array<string, array{description: string, category: string, write: bool, fields?: array<string, string>}>
 */
function automation_mcp_admin_action_catalog(): array
{
    return [
        'dashboard_summary' => [
            'description' => 'Dashboard widget summary: enabled count, queue, recent runs.',
            'category' => 'dashboard',
            'write' => false,
        ],
        'cron_info' => [
            'description' => 'Cron CLI command and signed queue/scheduled URLs with token.',
            'category' => 'setup',
            'write' => false,
        ],
        'list' => [
            'description' => 'List automations; optional filters object.',
            'category' => 'workflows',
            'write' => false,
            'fields' => ['filters' => 'object — optional filter keys'],
        ],
        'get' => [
            'description' => 'Get one automation by automation_id.',
            'category' => 'workflows',
            'write' => false,
            'fields' => ['automation_id' => 'string — required'],
        ],
        'list_recipes' => [
            'description' => 'List built-in recipe packs and recipes.',
            'category' => 'recipes',
            'write' => false,
            'fields' => ['pack' => 'string — optional pack id filter'],
        ],
        'get_recipe' => [
            'description' => 'Get one recipe definition and validation.',
            'category' => 'recipes',
            'write' => false,
            'fields' => ['recipe_id' => 'string — required'],
        ],
        'import_recipe' => [
            'description' => 'Import a built-in recipe as a new workflow.',
            'category' => 'recipes',
            'write' => true,
            'fields' => [
                'recipe_id' => 'string — required',
                'enabled' => 'boolean — optional',
                'name' => 'string — optional',
                'to' => 'string — optional email override',
            ],
        ],
        'import_recipe_pack' => [
            'description' => 'Import all recipes from a pack (default commerce).',
            'category' => 'recipes',
            'write' => true,
            'fields' => [
                'pack' => 'string — pack id (default commerce)',
                'enabled' => 'boolean — optional',
                'to' => 'string — optional email override',
            ],
        ],
        'create' => [
            'description' => 'Create automation (name, trigger, conditions, actions, graph).',
            'category' => 'workflows',
            'write' => true,
        ],
        'update' => [
            'description' => 'Update automation by automation_id.',
            'category' => 'workflows',
            'write' => true,
            'fields' => ['automation_id' => 'string — required'],
        ],
        'delete' => [
            'description' => 'Delete automation by automation_id.',
            'category' => 'workflows',
            'write' => true,
            'fields' => ['automation_id' => 'string — required'],
        ],
        'get_blocks' => [
            'description' => 'List trigger/condition/action blocks; optional type filter.',
            'category' => 'blocks',
            'write' => false,
            'fields' => ['type' => 'string — trigger, condition, or action'],
        ],
        'get_logs' => [
            'description' => 'Execution logs; optional automation_id and limit.',
            'category' => 'logs',
            'write' => false,
            'fields' => [
                'automation_id' => 'string — optional',
                'limit' => 'number — default 100',
            ],
        ],
        'test' => [
            'description' => 'Execute automation in test mode (no logging, dry-run context).',
            'category' => 'execution',
            'write' => true,
            'fields' => [
                'automation_id' => 'string — required',
                'context' => 'object — optional sample context',
            ],
        ],
        'dry_run' => [
            'description' => 'Structured dry-run steps without side effects.',
            'category' => 'execution',
            'write' => true,
            'fields' => [
                'automation_id' => 'string — required',
                'context' => 'object — optional sample context',
            ],
        ],
        'run_live' => [
            'description' => 'Manual live run — executes real email/webhook/Slack actions.',
            'category' => 'execution',
            'write' => true,
            'fields' => [
                'automation_id' => 'string — required',
                'context' => 'object — optional run context',
                'skip_conditions' => 'boolean — skip condition checks',
            ],
        ],
        'process_queue' => [
            'description' => 'Process pending queue jobs (cron-style batch).',
            'category' => 'queue',
            'write' => true,
            'fields' => ['limit' => 'number — default 10'],
        ],
        'process_queue_now' => [
            'description' => 'Admin queue drain with force reclaim and health snapshot.',
            'category' => 'queue',
            'write' => true,
            'fields' => ['limit' => 'number — 1–100, default 25'],
        ],
        'queue_status' => [
            'description' => 'Queue depth and processing status.',
            'category' => 'queue',
            'write' => false,
        ],
        'setup_health' => [
            'description' => 'Setup readiness: mail transport, queue, blocking issues.',
            'category' => 'setup',
            'write' => false,
        ],
        'save_mail_settings' => [
            'description' => 'Save email From / SMTP settings for Send Email actions.',
            'category' => 'setup',
            'write' => true,
        ],
        'send_test_email' => [
            'description' => 'Send a real test email using current Setup transport.',
            'category' => 'setup',
            'write' => true,
            'fields' => ['to' => 'string — recipient email, required'],
        ],
        'preview_template' => [
            'description' => 'Preview template with sample context and validation.',
            'category' => 'templates',
            'write' => false,
            'fields' => [
                'template' => 'string — required',
                'trigger_type' => 'string — optional',
                'sample_context' => 'object — optional',
            ],
        ],
        'get_context_variables' => [
            'description' => 'Available template context variables for a trigger type.',
            'category' => 'templates',
            'write' => false,
            'fields' => ['trigger_type' => 'string — optional'],
        ],
        'get_collections' => [
            'description' => 'Collections list for workflow pickers.',
            'category' => 'content',
            'write' => false,
        ],
        'process_scheduled' => [
            'description' => 'Run scheduled automations and plugin scheduled tasks.',
            'category' => 'queue',
            'write' => true,
        ],
    ];
}

function automation_mcp_admin_user_can(array $aiUser, string $permission = 'manage_content'): bool
{
    $role = (string) ($aiUser['role'] ?? '');
    if (in_array($role, ['admin', 'superadmin'], true)) {
        return true;
    }
    return function_exists('checkPermission') && checkPermission($aiUser, $permission);
}

function automation_mcp_admin_dashboard_can_view(array $aiUser): bool
{
    $role = (string) ($aiUser['role'] ?? '');
    if (in_array($role, ['admin', 'superadmin'], true)) {
        return true;
    }
    $capabilities = $aiUser['capabilities'] ?? $aiUser['plugin_capabilities']['automation'] ?? [];
    return is_array($capabilities) && in_array('manage_content', $capabilities, true);
}

function automation_mcp_admin_user_id(array $aiUser): string
{
    $id = $aiUser['id'] ?? $aiUser['user_id'] ?? $aiUser['email'] ?? 'mcp';
    return (string) $id;
}

function automation_mcp_admin_base_url(): string
{
    $host = $_SERVER['HTTP_HOST'] ?? 'yoursite.com';
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'https';
    return $scheme . '://' . $host;
}

/**
 * Dispatch an Automation admin API action for MCP (no CSRF/session).
 *
 * @return array<string, mixed>
 */
function automation_mcp_dispatch_admin(string $action, array $input, array $aiUser): array
{
    if (!automation_mcp_admin_user_can($aiUser)) {
        return ['status' => 'error', 'message' => 'Permission denied for Automation (requires manage_content)'];
    }

    if (!automation_bootstrap()) {
        return ['status' => 'error', 'message' => 'Automation plugin is not active'];
    }

    $action = trim($action);
    if ($action === '') {
        return ['status' => 'error', 'message' => 'action required'];
    }

    switch ($action) {
        case 'dashboard_summary':
            return automation_mcp_admin_dashboard_summary($aiUser);
        case 'cron_info':
            return automation_mcp_admin_cron_info();
        case 'list':
            return automation_mcp_admin_list($input);
        case 'get':
            return automation_mcp_admin_get($input);
        case 'list_recipes':
            return automation_mcp_admin_list_recipes($input);
        case 'get_recipe':
            return automation_mcp_admin_get_recipe($input);
        case 'import_recipe':
            return automation_mcp_admin_import_recipe($input);
        case 'import_recipe_pack':
            return automation_mcp_admin_import_recipe_pack($input);
        case 'create':
            return automation_mcp_admin_create($input);
        case 'update':
            return automation_mcp_admin_update($input);
        case 'delete':
            return automation_mcp_admin_delete($input);
        case 'get_blocks':
            return automation_mcp_admin_get_blocks($input);
        case 'get_logs':
            return automation_mcp_admin_get_logs($input);
        case 'test':
            return automation_mcp_admin_test($input);
        case 'dry_run':
            return automation_mcp_admin_dry_run($input);
        case 'run_live':
            return automation_mcp_admin_run_live($input, $aiUser);
        case 'process_queue':
            return automation_mcp_admin_process_queue($input);
        case 'process_queue_now':
            return automation_mcp_admin_process_queue_now($input);
        case 'queue_status':
            return ['status' => 'ok', 'data' => ['queue' => get_automation_queue_status()]];
        case 'setup_health':
            return ['status' => 'ok', 'data' => automation_setup_health()];
        case 'save_mail_settings':
            return automation_mcp_admin_save_mail_settings($input);
        case 'send_test_email':
            return automation_mcp_admin_send_test_email($input);
        case 'preview_template':
            return automation_mcp_admin_preview_template($input);
        case 'get_context_variables':
            return automation_mcp_admin_get_context_variables($input);
        case 'get_collections':
            return automation_mcp_admin_get_collections();
        case 'process_scheduled':
            return automation_mcp_admin_process_scheduled();
        default:
            return ['status' => 'error', 'message' => 'Invalid action'];
    }
}

/** @return array<string, mixed> */
function automation_mcp_admin_dashboard_summary(array $aiUser): array
{
    if (!automation_mcp_admin_dashboard_can_view($aiUser)) {
        return ['status' => 'error', 'message' => 'Forbidden'];
    }

    $automations = get_automations();
    $logs = get_automation_logs(null, 5);
    $queue = get_automation_queue_status();
    $recent = array_map(static function (array $log): array {
        return [
            'automation_id' => (string) ($log['automation_id'] ?? ''),
            'status' => (string) ($log['status'] ?? 'unknown'),
            'executed_at' => (string) ($log['executed_at'] ?? ''),
        ];
    }, $logs);

    return [
        'status' => 'ok',
        'data' => [
            'enabled' => count(array_filter($automations, static fn (array $a): bool => !empty($a['enabled']))),
            'total' => count($automations),
            'queue' => $queue,
            'recent' => $recent,
            'automation_url' => function_exists('admin_url')
                ? admin_url('automation')
                : '/admin/index.php?page=automation',
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_cron_info(): array
{
    $token = automation_get_cron_token();
    $base_url = automation_mcp_admin_base_url();

    return [
        'status' => 'ok',
        'data' => [
            'queue_cli' => 'php plugins/automation/cli/process_queue.php 10',
            'queue_url' => $base_url . '/api/automation.php?action=process_queue&token=' . $token,
            'scheduled_url' => $base_url . '/api/automation.php?action=process_scheduled&token=' . $token,
            'token_created' => true,
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_list(array $input): array
{
    $filters = is_array($input['filters'] ?? null) ? $input['filters'] : [];
    return [
        'status' => 'ok',
        'data' => ['automations' => get_automations($filters)],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_get(array $input): array
{
    $automation_id = (string) ($input['automation_id'] ?? '');
    if ($automation_id === '') {
        return ['status' => 'error', 'message' => 'Automation ID required'];
    }
    $automation = get_automation($automation_id);
    if (!$automation) {
        return ['status' => 'error', 'message' => 'Automation not found'];
    }
    return ['status' => 'ok', 'data' => ['automation' => $automation]];
}

/** @return array<string, mixed> */
function automation_mcp_admin_list_recipes(array $input): array
{
    $pack = $input['pack'] ?? null;
    $pack = is_string($pack) && $pack !== '' ? $pack : null;
    $recipes = automation_list_recipes($pack);
    $packs = [];
    foreach (automation_list_recipe_packs() as $packId) {
        $meta = automation_read_recipe_pack($packId);
        if (is_array($meta)) {
            $packs[] = $meta;
        }
    }
    return [
        'status' => 'ok',
        'data' => ['recipes' => $recipes, 'packs' => $packs],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_get_recipe(array $input): array
{
    $recipeId = (string) ($input['recipe_id'] ?? '');
    $recipe = automation_get_recipe($recipeId);
    if (!$recipe) {
        return ['status' => 'error', 'message' => 'Recipe not found'];
    }
    $errors = automation_validate_recipe($recipe);
    return [
        'status' => 'ok',
        'data' => ['recipe' => $recipe, 'valid' => $errors === [], 'errors' => $errors],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_import_recipe(array $input): array
{
    $recipeId = (string) ($input['recipe_id'] ?? '');
    if ($recipeId === '') {
        return ['status' => 'error', 'message' => 'recipe_id required'];
    }
    $options = [];
    if (array_key_exists('enabled', $input)) {
        $options['enabled'] = (bool) $input['enabled'];
    }
    if (!empty($input['name'])) {
        $options['name'] = (string) $input['name'];
    }
    if (!empty($input['to'])) {
        $options['to'] = (string) $input['to'];
    }
    $result = automation_import_recipe($recipeId, $options);
    if (empty($result['ok'])) {
        return [
            'status' => 'error',
            'message' => implode('; ', $result['errors'] ?? ['Import failed']),
            'errors' => $result['errors'] ?? [],
        ];
    }
    return [
        'status' => 'ok',
        'data' => [
            'automation' => $result['automation'],
            'recipe' => $result['recipe'] ?? null,
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_import_recipe_pack(array $input): array
{
    $pack = (string) ($input['pack'] ?? 'commerce');
    $options = [];
    if (array_key_exists('enabled', $input)) {
        $options['enabled'] = (bool) $input['enabled'];
    }
    if (!empty($input['to'])) {
        $options['to'] = (string) $input['to'];
    }
    $result = automation_import_recipe_pack($pack, $options);
    if (empty($result['ok'])) {
        return [
            'status' => 'error',
            'message' => implode('; ', $result['errors'] ?? ['Pack import failed']),
            'errors' => $result['errors'] ?? [],
            'imported' => $result['imported'] ?? [],
        ];
    }
    return [
        'status' => 'ok',
        'data' => [
            'imported' => $result['imported'],
            'count' => count($result['imported']),
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_create(array $input): array
{
    $payload = $input;
    unset($payload['action'], $payload['_csrf']);
    $result = create_automation($payload);
    if (!$result) {
        return ['status' => 'error', 'message' => 'Failed to create automation'];
    }
    return ['status' => 'ok', 'data' => ['automation' => $result]];
}

/** @return array<string, mixed> */
function automation_mcp_admin_update(array $input): array
{
    $automation_id = (string) ($input['automation_id'] ?? '');
    if ($automation_id === '') {
        return ['status' => 'error', 'message' => 'Automation ID required'];
    }
    $payload = $input;
    unset($payload['action'], $payload['_csrf'], $payload['automation_id']);
    $result = update_automation($automation_id, $payload);
    if (!$result) {
        return ['status' => 'error', 'message' => 'Failed to update automation'];
    }
    return ['status' => 'ok', 'data' => ['automation' => $result]];
}

/** @return array<string, mixed> */
function automation_mcp_admin_delete(array $input): array
{
    $automation_id = (string) ($input['automation_id'] ?? '');
    if ($automation_id === '') {
        return ['status' => 'error', 'message' => 'Automation ID required'];
    }
    if (!delete_automation($automation_id)) {
        return ['status' => 'error', 'message' => 'Failed to delete automation'];
    }
    return ['status' => 'ok', 'message' => 'Automation deleted'];
}

/** @return array<string, mixed> */
function automation_mcp_admin_get_blocks(array $input): array
{
    $block_type = $input['type'] ?? null;
    $blocks = is_string($block_type) && $block_type !== ''
        ? get_automation_blocks($block_type)
        : get_all_automation_blocks();
    return ['status' => 'ok', 'data' => ['blocks' => $blocks]];
}

/** @return array<string, mixed> */
function automation_mcp_admin_get_logs(array $input): array
{
    $automation_id = $input['automation_id'] ?? null;
    $limit = $input['limit'] ?? 100;
    $logs = get_automation_logs(
        is_string($automation_id) && $automation_id !== '' ? $automation_id : null,
        $limit
    );
    return ['status' => 'ok', 'data' => ['logs' => $logs]];
}

/** @return array<string, mixed> */
function automation_mcp_admin_test(array $input): array
{
    $automation_id = (string) ($input['automation_id'] ?? '');
    if ($automation_id === '') {
        return ['status' => 'error', 'message' => 'Automation ID required'];
    }
    $automation = get_automation($automation_id);
    if (!$automation) {
        return ['status' => 'error', 'message' => 'Automation not found'];
    }

    $sample_context = is_array($input['context'] ?? null) ? $input['context'] : [];
    $test_automation = $automation;
    $test_automation['_test_mode'] = true;
    $test_context = array_merge($sample_context, ['_test_mode' => true, '_dry_run' => true]);

    $start_time = microtime(true);
    try {
        $result = execute_automation($test_automation, $test_context);
        $runtime = (microtime(true) - $start_time) * 1000;
        return [
            'status' => 'ok',
            'data' => [
                'success' => $result,
                'runtime_ms' => $runtime,
                'conditions_met' => true,
                'actions_executed' => count($automation['actions'] ?? []),
            ],
        ];
    } catch (Exception $e) {
        return [
            'status' => 'error',
            'message' => $e->getMessage(),
            'data' => ['success' => false, 'error' => $e->getMessage()],
        ];
    }
}

/** @return array<string, mixed> */
function automation_mcp_admin_dry_run(array $input): array
{
    $automation_id = (string) ($input['automation_id'] ?? '');
    if ($automation_id === '') {
        return ['status' => 'error', 'message' => 'Automation ID required'];
    }
    $automation = get_automation($automation_id);
    if (!$automation) {
        return ['status' => 'error', 'message' => 'Automation not found'];
    }

    $sample_context = array_merge(
        is_array($input['context'] ?? null) ? $input['context'] : [],
        ['_dry_run' => true, '_test_mode' => true]
    );
    if (function_exists('generate_sample_automation_context')) {
        $sample_context = array_merge(
            generate_sample_automation_context($automation['trigger']['type'] ?? null),
            $sample_context
        );
    }

    $steps = [];
    $all_ok = true;

    $trigger_type = $automation['trigger']['type'] ?? '';
    $steps[] = [
        'type' => 'trigger',
        'label' => 'Trigger',
        'detail' => $trigger_type ?: 'none',
        'status' => $trigger_type ? 'pass' : 'warn',
    ];

    $conditions = $automation['conditions'] ?? [];
    if (empty($conditions)) {
        $steps[] = [
            'type' => 'conditions',
            'label' => 'Conditions',
            'detail' => 'No conditions — always runs',
            'status' => 'info',
        ];
    } else {
        foreach ($conditions as $i => $condition) {
            $ctype = $condition['type'] ?? '';
            $block = get_automation_block('condition', $ctype);
            if (!$block) {
                $steps[] = [
                    'type' => 'condition',
                    'label' => 'Condition ' . ($i + 1),
                    'detail' => "Unknown type: $ctype",
                    'status' => 'warn',
                ];
                $all_ok = false;
                continue;
            }
            try {
                $handler = $block['handler'] ?? null;
                $result = $handler ? call_user_func($handler, $condition['config'] ?? [], $sample_context) : true;
                $steps[] = [
                    'type' => 'condition',
                    'label' => 'Condition ' . ($i + 1) . ': ' . ($block['name'] ?? $ctype),
                    'detail' => $result ? 'Would pass' : 'Would skip (condition not met)',
                    'status' => $result ? 'pass' : 'skip',
                ];
            } catch (Exception $e) {
                $steps[] = [
                    'type' => 'condition',
                    'label' => 'Condition ' . ($i + 1),
                    'detail' => $e->getMessage(),
                    'status' => 'warn',
                ];
                $all_ok = false;
            }
        }
    }

    $actions = $automation['actions'] ?? [];
    if (empty($actions) && !empty($automation['graph']['nodes'])) {
        foreach ($automation['graph']['nodes'] as $node) {
            if (($node['kind'] ?? '') !== 'action') {
                continue;
            }
            $actions[] = [
                'type' => $node['type'] ?? '',
                'config' => $node['config'] ?? [],
            ];
        }
    }

    $health = automation_setup_health();
    if (!empty($health['blocking'])) {
        foreach ($health['blocking'] as $blockMsg) {
            $steps[] = [
                'type' => 'setup',
                'label' => 'Setup required',
                'detail' => $blockMsg,
                'status' => 'warn',
            ];
            $all_ok = false;
        }
    } elseif (!empty($health['warnings'])) {
        foreach (array_slice($health['warnings'], 0, 3) as $warnMsg) {
            $steps[] = [
                'type' => 'setup',
                'label' => 'Setup warning',
                'detail' => $warnMsg,
                'status' => 'warn',
            ];
        }
    }

    if (empty($actions)) {
        $steps[] = [
            'type' => 'actions',
            'label' => 'Actions',
            'detail' => 'No actions configured',
            'status' => 'warn',
        ];
        $all_ok = false;
    } else {
        foreach ($actions as $i => $action_def) {
            $atype = $action_def['type'] ?? '';
            $block = get_automation_block('action', $atype);
            $label = 'Action ' . ($i + 1) . ': ' . ($block['name'] ?? ($atype !== '' ? $atype : 'unknown'));
            $detail = automation_describe_dry_run_action($atype, $action_def['config'] ?? [], $sample_context);
            $steps[] = ['type' => 'action', 'label' => $label, 'detail' => $detail, 'status' => 'info'];
        }
    }

    $steps[] = [
        'type' => 'notice',
        'label' => 'Dry run only',
        'detail' => 'No email, webhook, Slack, or other side effects were performed. Use Confirm & Run Live (or create a real entry) to execute for real.',
        'status' => 'info',
    ];

    return [
        'status' => 'ok',
        'data' => [
            'steps' => $steps,
            'all_ok' => $all_ok,
            'action_count' => count($actions),
            'dry_run' => true,
            'setup' => [
                'ready' => $health['ready'],
                'blocking' => $health['blocking'],
                'warnings' => $health['warnings'],
            ],
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_run_live(array $input, array $aiUser): array
{
    $automation_id = (string) ($input['automation_id'] ?? '');
    if ($automation_id === '') {
        return ['status' => 'error', 'message' => 'Automation ID required'];
    }

    $automation = get_automation($automation_id);
    if (!$automation) {
        return ['status' => 'error', 'message' => 'Automation not found'];
    }

    $run_context = is_array($input['context'] ?? null) ? $input['context'] : [];
    if ($run_context === []) {
        $run_context = generate_sample_automation_context($automation['trigger']['type'] ?? null);
    }
    $run_context['_manual_run'] = true;
    $run_context['_skip_conditions'] = !empty($input['skip_conditions']);

    $health = automation_setup_health();
    $actionTypes = [];
    foreach ($automation['actions'] ?? [] as $actionDef) {
        $actionTypes[] = (string) ($actionDef['type'] ?? '');
    }
    foreach ($automation['graph']['nodes'] ?? [] as $node) {
        if (($node['kind'] ?? '') === 'action') {
            $actionTypes[] = (string) ($node['type'] ?? '');
        }
    }
    $needsMail = in_array('email', $actionTypes, true);
    $mailMethod = (string) ($health['mail']['method'] ?? 'mail');
    if ($needsMail && $mailMethod === 'mail' && empty($health['capabilities']['mail']) && !function_exists('birkly_send_mail')) {
        return [
            'status' => 'error',
            'message' => 'Email cannot be sent: PHP mail() is unavailable. Configure an email connection under Settings → Connections.',
            'data' => ['setup' => $health],
        ];
    }
    if ($needsMail && $mailMethod === 'smtp' && empty($health['mail']['smtp_host']) && !function_exists('birkly_send_mail')) {
        return [
            'status' => 'error',
            'message' => 'SMTP is selected but not configured. Use Settings → Connections for email delivery, or open Automations → Setup for legacy SMTP.',
            'data' => ['setup' => $health],
        ];
    }

    $liveClaim = 'run_live_' . md5($automation_id . '|' . automation_mcp_admin_user_id($aiUser));
    if (!automation_claim_side_effect($liveClaim, 8)) {
        return [
            'status' => 'ok',
            'data' => [
                'success' => true,
                'runtime_ms' => 0,
                'actions_executed' => 0,
                'manual_run' => true,
                'deduped' => true,
                'errors' => [],
                'delivery_note' => 'Live run already started a moment ago — not executed again.',
            ],
        ];
    }

    $start_time = microtime(true);
    try {
        $execDetails = [];
        $success = execute_automation($automation, $run_context, $execDetails);
        $runtime = (microtime(true) - $start_time) * 1000;
        $actionCount = count($automation['actions'] ?? []);
        if ($actionCount === 0 && !empty($automation['graph']['nodes'])) {
            $actionCount = count(array_filter(
                $automation['graph']['nodes'],
                static fn ($n) => ($n['kind'] ?? '') === 'action'
            ));
        }

        $deliveryNote = null;
        if ($needsMail) {
            if ($mailMethod === 'connections' || function_exists('birkly_send_mail')) {
                $deliveryNote = 'Email transport: Settings → Connections (uses the Send using connection on each email action, or the site default).';
            } elseif ($mailMethod === 'smtp') {
                $deliveryNote = 'Email transport: SMTP via '
                    . ($health['mail']['smtp_host'] ?? '?')
                    . ' From ' . ($health['mail']['from_email'] ?? '')
                    . '.';
            } elseif ($mailMethod === 'log') {
                $deliveryNote = 'Email transport: Log only (no inbox delivery). Check Setup → Recent sends.';
            } else {
                $deliveryNote = 'Email transport: PHP mail() From '
                    . ($health['mail']['from_email'] ?? '')
                    . '. Configure Settings → Connections — PHP mail() rarely delivers on cloud hosts.';
            }
        }

        $errors = array_values(array_filter(array_map('strval', $execDetails['errors'] ?? [])));
        if (!$success && $errors === []) {
            $errors[] = 'Automation finished with errors. Open Logs for details.';
        }

        return [
            'status' => 'ok',
            'data' => [
                'success' => $success,
                'runtime_ms' => $runtime,
                'actions_executed' => $actionCount,
                'manual_run' => true,
                'errors' => $errors,
                'results' => $execDetails['results'] ?? [],
                'delivery_note' => $deliveryNote,
                'setup_warnings' => $health['warnings'],
                'mail_method' => $mailMethod,
            ],
        ];
    } catch (Exception $e) {
        return [
            'status' => 'error',
            'message' => $e->getMessage(),
            'data' => ['success' => false, 'error' => $e->getMessage()],
        ];
    }
}

/** @return array<string, mixed> */
function automation_mcp_admin_process_queue(array $input): array
{
    $limit = $input['limit'] ?? 10;
    $processed = process_automation_queue((int) $limit);
    return ['status' => 'ok', 'data' => ['processed' => $processed]];
}

/** @return array<string, mixed> */
function automation_mcp_admin_process_queue_now(array $input): array
{
    $limit = (int) ($input['limit'] ?? 25);
    if ($limit < 1) {
        $limit = 1;
    }
    if ($limit > 100) {
        $limit = 100;
    }
    $processed = process_automation_queue($limit, ['force' => true]);
    $queue = get_automation_queue_status();
    $recent = function_exists('automation_get_recent_queue_jobs')
        ? automation_get_recent_queue_jobs(8)
        : [];

    return [
        'status' => 'ok',
        'data' => [
            'processed' => $processed,
            'queue' => $queue,
            'recent_jobs' => $recent,
            'health' => automation_setup_health(),
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_save_mail_settings(array $input): array
{
    $saved = automation_save_mail_settings($input);
    if ($saved === false) {
        return [
            'status' => 'error',
            'message' => 'Valid From email is required. For SMTP, also provide an SMTP host.',
        ];
    }
    return [
        'status' => 'ok',
        'data' => [
            'mail' => $saved,
            'health' => automation_setup_health(),
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_send_test_email(array $input): array
{
    $to = trim((string) ($input['to'] ?? ''));
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return ['status' => 'error', 'message' => 'Enter a valid test recipient email'];
    }

    $dedupe = automation_acquire_test_email_lock($to, 20);
    if (!$dedupe['acquired']) {
        return [
            'status' => 'ok',
            'message' => 'Test email already sent a moment ago — check your inbox before sending again.',
            'data' => [
                'result' => ['ok' => true, 'method' => 'deduped'],
                'health' => automation_setup_health(),
            ],
        ];
    }

    $subject = 'Birkly Automation test email';
    if (function_exists('automation_recent_send_exists') && automation_recent_send_exists($to, $subject, 20)) {
        return [
            'status' => 'ok',
            'message' => 'Test email already sent a moment ago — check your inbox before sending again.',
            'data' => [
                'result' => ['ok' => true, 'method' => 'deduped'],
                'health' => automation_setup_health(),
            ],
        ];
    }

    $mail = automation_get_mail_settings();
    $body = '<p>This is a Birkly Automation test email.</p>'
        . '<p>Transport: <strong>' . htmlspecialchars((string) $mail['method']) . '</strong></p>'
        . '<p>Plugin version: <strong>' . htmlspecialchars(automation_plugin_version()) . '</strong></p>'
        . '<p>If you received this, Setup email delivery is working.</p>'
        . '<p>Sent at ' . htmlspecialchars(date('c')) . '</p>';

    $result = automation_send_mail($to, $subject, $body, $mail);

    if (empty($result['ok'])) {
        automation_release_test_email_lock($to);
        return [
            'status' => 'error',
            'message' => $result['error'] ?? 'Test email failed',
            'data' => ['result' => $result, 'health' => automation_setup_health()],
        ];
    }

    $message = !empty($result['logged']) && ($result['method'] ?? '') === 'log'
        ? 'Test email logged (Log transport). Open Setup → Recent sends to confirm. Switch to SMTP to deliver to a real inbox.'
        : 'Test email accepted by transport (' . ($result['method'] ?? 'mail') . '). Check the inbox (and spam).';

    return [
        'status' => 'ok',
        'message' => $message,
        'data' => [
            'result' => $result,
            'health' => automation_setup_health(),
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_preview_template(array $input): array
{
    $template = (string) ($input['template'] ?? '');
    if ($template === '') {
        return ['status' => 'error', 'message' => 'Template required'];
    }
    $trigger_type = $input['trigger_type'] ?? null;
    $sample_context = $input['sample_context'] ?? null;
    if ($sample_context === null && $trigger_type) {
        $sample_context = generate_sample_automation_context($trigger_type);
    }
    $preview = preview_automation_template($template, $sample_context);
    $validation = validate_automation_template($template);
    return [
        'status' => 'ok',
        'data' => [
            'rendered' => $preview['rendered'],
            'variables' => $preview['variables'],
            'sample_context' => $preview['sample_context'],
            'validation' => $validation,
        ],
    ];
}

/** @return array<string, mixed> */
function automation_mcp_admin_get_context_variables(array $input): array
{
    $trigger_type = $input['trigger_type'] ?? null;
    $variables = get_automation_context_variables($trigger_type);
    return ['status' => 'ok', 'data' => ['variables' => $variables]];
}

/** @return array<string, mixed> */
function automation_mcp_admin_get_collections(): array
{
    $contentRoot = automation_cms_root();
    $col_dirs = @scandir($contentRoot . '/content/collections') ?: [];
    $collections = [];
    foreach ($col_dirs as $dir) {
        if ($dir === '.' || $dir === '..') {
            continue;
        }
        $meta_file = $contentRoot . '/content/collections/' . $dir . '/collection.json';
        if (!is_file($meta_file)) {
            continue;
        }
        $meta = json_decode((string) file_get_contents($meta_file), true);
        if (!$meta) {
            continue;
        }
        $collections[] = [
            'slug' => $meta['slug'] ?? $dir,
            'title' => $meta['title'] ?? $dir,
            'sub_collections' => array_map(static function ($sc) {
                return [
                    'slug' => $sc['slug'] ?? '',
                    'title' => $sc['title'] ?? $sc['slug'] ?? '',
                ];
            }, $meta['sub_collections'] ?? []),
        ];
    }
    return ['status' => 'ok', 'data' => ['collections' => $collections]];
}

/** @return array<string, mixed> */
function automation_mcp_admin_process_scheduled(): array
{
    $triggered = process_scheduled_automations();
    if (function_exists('process_plugin_scheduled_tasks')) {
        $cmsRoot = automation_cms_root();
        if (is_file($cmsRoot . '/core/plugins/scheduled_tasks.php')) {
            require_once $cmsRoot . '/core/plugins/scheduled_tasks.php';
        }
        $plugin_tasks_executed = process_plugin_scheduled_tasks();
    } else {
        $plugin_tasks_executed = 0;
    }
    return [
        'status' => 'ok',
        'data' => [
            'triggered' => $triggered,
            'plugin_tasks_executed' => $plugin_tasks_executed,
        ],
    ];
}
