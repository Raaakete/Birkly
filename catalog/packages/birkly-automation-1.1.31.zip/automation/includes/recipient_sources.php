<?php
/**
 * Resolve email broadcast recipients from collections or site users.
 */

require_once __DIR__ . '/collection_entries.php';

function automation_user_management_plugin_dir(): ?string
{
    $candidates = [
        automation_cms_path('plugins/user_management'),
        automation_cms_path('data/plugins/user_management'),
    ];
    foreach ($candidates as $dir) {
        if (is_file($dir . '/includes/UserStorage.php')) {
            return $dir;
        }
    }

    return null;
}

function automation_user_management_available(): bool
{
    if (automation_user_management_plugin_dir() === null) {
        return false;
    }
    if (!function_exists('get_all_plugins')) {
        return true;
    }
    global $birkly_plugins;
    if (!isset($birkly_plugins) && function_exists('load_plugins')) {
        load_plugins();
    }

    return !empty($birkly_plugins['user_management']['active']);
}

/**
 * @return list<string>
 */
function automation_user_management_tier_options(): array
{
    $dir = automation_user_management_plugin_dir();
    if ($dir === null) {
        return [];
    }

    if (!class_exists('UserStorage')) {
        require_once $dir . '/includes/UserStorage.php';
    }

    $storage = new UserStorage();
    if (!method_exists($storage, 'listTiers')) {
        return [];
    }

    $tiers = $storage->listTiers();
    if (!is_array($tiers)) {
        return [];
    }

    $ids = [];
    foreach ($tiers as $tier) {
        if (!is_array($tier)) {
            continue;
        }
        $id = trim((string) ($tier['tier_id'] ?? $tier['id'] ?? ''));
        if ($id !== '') {
            $ids[] = $id;
        }
    }

    sort($ids);

    return $ids;
}

/**
 * @param array<string, mixed> $user
 * @return array<string, mixed>
 */
function automation_map_site_user_recipient(array $user): array
{
    $email = trim((string) ($user['email'] ?? ''));
    $name = trim((string) ($user['name'] ?? $user['username'] ?? ''));

    return [
        'id' => (string) ($user['id'] ?? ''),
        'email' => $email,
        'name' => $name,
        'display_name' => $name !== '' ? $name : $email,
        'tier' => (string) ($user['tier'] ?? 'all'),
        'role' => (string) ($user['role'] ?? 'member'),
        'status' => (string) ($user['status'] ?? ''),
        'verified' => !empty($user['verified']),
        'source' => 'site_user',
    ];
}

/**
 * @return list<array<string, mixed>>
 */
function automation_load_site_user_recipients(array $options = []): array
{
    $dir = automation_user_management_plugin_dir();
    if ($dir === null) {
        return [];
    }

    if (!class_exists('UserStorage')) {
        require_once $dir . '/includes/UserStorage.php';
    }

    $storage = new UserStorage();
    $filters = [
        'deleted' => false,
    ];
    $statusFilter = trim((string) ($options['user_status'] ?? ''));
    if ($statusFilter !== '' && $statusFilter !== 'any') {
        $filters['status'] = $statusFilter;
    }

    $users = $storage->listUsers($filters);
    $tierFilter = trim((string) ($options['user_tier_filter'] ?? ''));
    $verifiedOnly = !empty($options['user_verified_only']);
    $recipients = [];

    foreach ($users as $user) {
        if (!is_array($user)) {
            continue;
        }
        if ($verifiedOnly && empty($user['verified'])) {
            continue;
        }
        if ($tierFilter !== '' && $tierFilter !== 'any') {
            $userTier = (string) ($user['tier'] ?? 'all');
            if ($userTier !== $tierFilter) {
                continue;
            }
        }

        $mapped = automation_map_site_user_recipient($user);
        $email = trim((string) ($mapped['email'] ?? ''));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            continue;
        }

        $recipients[] = $mapped;
    }

    return $recipients;
}

/**
 * @param array<string, mixed> $config
 * @param array<string, mixed> $context
 * @return list<array<string, mixed>>
 */
function automation_resolve_broadcast_recipients(array $config, array $context = []): array
{
    $source = trim((string) ($config['recipient_source'] ?? ''));
    if ($source === '') {
        $source = trim((string) ($config['collection'] ?? '')) !== '' ? 'collection' : 'site_users';
    }
    if ($source === 'site_users') {
        return automation_load_site_user_recipients([
            'user_tier_filter' => $config['user_tier_filter'] ?? '',
            'user_verified_only' => !empty($config['user_verified_only']),
            'user_status' => $config['user_status_filter'] ?? 'active',
        ]);
    }

    $collection = trim((string) ($config['collection'] ?? ''));
    if ($collection === '') {
        return [];
    }

    $status = trim((string) ($config['status_filter'] ?? 'published'));
    if ($status === 'any') {
        $status = '';
    }

    $emailField = trim((string) ($config['email_field'] ?? 'email'));
    if ($emailField === '') {
        $emailField = 'email';
    }

    $filterValue = render_automation_template((string) ($config['filter_value'] ?? ''), $context);

    return automation_load_collection_entries($collection, [
        'status' => $status,
        'email_field' => $emailField,
        'filter_field' => trim((string) ($config['filter_field'] ?? '')),
        'filter_operator' => trim((string) ($config['filter_operator'] ?? 'equals')),
        'filter_value' => $filterValue,
    ]);
}

function automation_broadcast_recipient_label(array $config): string
{
    $source = trim((string) ($config['recipient_source'] ?? ''));
    if ($source === '') {
        $source = trim((string) ($config['collection'] ?? '')) !== '' ? 'collection' : 'site_users';
    }
    if ($source === 'site_users') {
        $tier = trim((string) ($config['user_tier_filter'] ?? ''));
        if ($tier !== '' && $tier !== 'any') {
            return 'site users (tier: ' . $tier . ')';
        }

        return 'all site users';
    }

    $collection = trim((string) ($config['collection'] ?? ''));

    return $collection !== '' ? 'collection "' . $collection . '"' : 'recipients';
}
