<?php
/**
 * Load and filter collection entries for automation actions.
 */

require_once __DIR__ . '/../cms_paths.php';

/**
 * @return array<int, array<string, mixed>>
 */
function automation_load_collection_entries(string $collectionSlug, array $options = []): array
{
    $collectionSlug = trim($collectionSlug);
    if ($collectionSlug === '') {
        return [];
    }

    $entriesDir = automation_content_dir() . '/collections/' . $collectionSlug . '/entries';
    if (!is_dir($entriesDir)) {
        return [];
    }

    $statusFilter = trim((string) ($options['status'] ?? ''));
    $filterField = trim((string) ($options['filter_field'] ?? ''));
    $filterOperator = trim((string) ($options['filter_operator'] ?? 'equals'));
    $filterValue = (string) ($options['filter_value'] ?? '');
    $requireEmailField = trim((string) ($options['email_field'] ?? ''));

    $entries = [];
    foreach (glob($entriesDir . '/*.json') ?: [] as $file) {
        if (!is_string($file) || !is_file($file)) {
            continue;
        }
        $raw = file_get_contents($file);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data)) {
            continue;
        }

        if ($statusFilter !== '' && ($data['status'] ?? 'draft') !== $statusFilter) {
            continue;
        }

        if ($filterField !== '') {
            $fieldValue = (string) ($data[$filterField] ?? '');
            if (!automation_entry_field_matches($fieldValue, $filterValue, $filterOperator)) {
                continue;
            }
        }

        if ($requireEmailField !== '') {
            $email = trim((string) ($data[$requireEmailField] ?? ''));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                continue;
            }
        }

        $data['collection'] = $collectionSlug;
        $entries[] = $data;
    }

    return $entries;
}

function automation_entry_field_matches(string $fieldValue, string $expected, string $operator): bool
{
    switch ($operator) {
        case 'not_equals':
            return $fieldValue != $expected;
        case 'contains':
            return $expected === '' || (is_string($fieldValue) && str_contains($fieldValue, $expected));
        case 'is_truthy':
            return automation_checkbox_truthy($fieldValue);
        case 'is_empty':
            return trim($fieldValue) === '';
        case 'equals':
        default:
            return $fieldValue == $expected;
    }
}

function automation_checkbox_truthy($value): bool
{
    if (is_bool($value)) {
        return $value;
    }
    $normalized = strtolower(trim((string) $value));
    return in_array($normalized, ['1', 'true', 'yes', 'on'], true);
}

/**
 * Find the first entry in a collection where target field matches a value.
 *
 * @return array<string, mixed>|null
 */
function automation_lookup_collection_entry(
    string $collectionSlug,
    string $targetField,
    string $matchValue,
    string $operator = 'equals'
): ?array {
    $collectionSlug = trim($collectionSlug);
    $targetField = trim($targetField);
    if ($collectionSlug === '' || $targetField === '') {
        return null;
    }

    $entries = automation_load_collection_entries($collectionSlug, [
        'filter_field' => $targetField,
        'filter_value' => $matchValue,
        'filter_operator' => $operator,
    ]);

    return $entries[0] ?? null;
}
