<?php
/**
 * Shared templated email delivery for automation actions.
 */

require_once __DIR__ . '/../executor.php';
require_once __DIR__ . '/context.php';
require_once __DIR__ . '/side_effects.php';

/**
 * Resolve subject/body templates and send one email.
 *
 * @param array<string, mixed> $context
 * @param array<string, mixed> $config Action config (connection_alias, etc.)
 * @return array<string, mixed>
 */
function automation_send_templated_email(string $to, string $subjectTemplate, string $bodyTemplate, array $context, array $config = []): array
{
    if (!function_exists('automation_default_email_templates')) {
        require_once __DIR__ . '/context.php';
    }
    $defaults = automation_default_email_templates();

    $to = trim($to);
    $subjectTemplate = trim($subjectTemplate);
    if ($subjectTemplate === '') {
        $subjectTemplate = $defaults['subject'];
    }
    $bodyTemplate = trim($bodyTemplate);
    if ($bodyTemplate === '') {
        $bodyTemplate = $defaults['body'];
    }

    $subject = trim(render_automation_template($subjectTemplate, $context));
    $body = render_automation_template($bodyTemplate, $context);

    if ($subject === '' || strcasecmp($subject, 'new entry') === 0) {
        $fallback = trim((string) ($context['automation']['name'] ?? $context['automation_name'] ?? ''));
        if ($fallback !== '') {
            $subject = $fallback;
        } elseif (!empty($context['trigger_summary'])) {
            $subject = (string) $context['trigger_summary'];
        }
    }

    if ($to === '' || $subject === '') {
        throw new Exception('Email recipient and subject are required');
    }

    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid recipient email address: ' . ($to !== '' ? $to : '(empty)'));
    }

    if (!function_exists('automation_send_mail')) {
        require_once __DIR__ . '/setup_health.php';
    }
    if (!function_exists('automation_claim_side_effect')) {
        require_once __DIR__ . '/side_effects.php';
    }

    $claimKey = automation_email_side_effect_key($to, $subject, $context);
    if (!automation_claim_side_effect($claimKey, 60)) {
        return [
            'sent' => true,
            'deduped' => true,
            'to' => $to,
            'method' => 'deduped',
            'subject' => $subject,
        ];
    }

    $html = automation_format_email_html($body, $context);
    automation_ensure_mail_pipeline();

    if (function_exists('birkly_send_mail')) {
        $connectionAlias = trim((string) ($config['connection_alias'] ?? ''));
        $result = birkly_send_mail($to, $subject, $html, [
            'text' => automation_email_html_to_text($html),
            'alias' => $connectionAlias !== '' ? $connectionAlias : null,
            'idempotency_key' => $claimKey,
        ]);
        if (!is_array($result)) {
            $result = ['ok' => false, 'error' => 'Core mailer returned an invalid response'];
        }
        $status = (string) ($result['status'] ?? '');
        if (!isset($result['method'])) {
            $result['method'] = ($status === 'logged') ? 'log' : 'core';
        }
        if ($status === 'logged') {
            $result['logged'] = true;
        }
        if (empty($result['ok']) && in_array($status, ['accepted', 'queued', 'logged'], true)) {
            $result['ok'] = true;
        }
    } else {
        $mailSettings = automation_get_mail_settings();
        $mailSettings['connection_alias'] = trim((string) ($config['connection_alias'] ?? ''));
        $result = automation_send_mail($to, $subject, $html, $mailSettings);
    }

    $status = (string) ($result['status'] ?? '');
    $mailOk = !empty($result['ok']) || in_array($status, ['accepted', 'queued', 'logged'], true);
    if (!$mailOk) {
        $hint = function_exists('birkly_send_mail')
            ? 'Configure an email connection under Settings → Connections.'
            : 'Update CMS core, then configure email under Settings → Connections.';
        throw new Exception($result['error'] ?? ('Failed to send email. ' . $hint));
    }

    return [
        'sent' => true,
        'to' => $to,
        'from' => $result['from'] ?? null,
        'method' => $result['method'] ?? null,
        'logged' => !empty($result['logged']),
        'subject' => $subject,
        'entry_admin_url' => $context['entry_admin_url'] ?? null,
    ];
}

/**
 * Count how many recipients would match a broadcast config (dry-run helper).
 */
function automation_broadcast_recipient_count(array $config, array $context = []): int
{
    if (!function_exists('automation_resolve_broadcast_recipients')) {
        require_once __DIR__ . '/recipient_sources.php';
    }

    return count(automation_resolve_broadcast_recipients($config, $context));
}
