<?php
/**
 * P83-M6 — Subscribe to core birkly_entry_saved for workflow triggers.
 */

declare(strict_types=1);

if (!function_exists('register_hook')) {
    return;
}

register_hook('birkly_entry_saved', static function (array $payload): void {
    if (!function_exists('enqueue_automation')) {
        return;
    }

    $entry = is_array($payload['entry'] ?? null) ? $payload['entry'] : [];
    $collection = (string) ($payload['collection'] ?? '');
    $isNew = !empty($payload['is_new']);

    try {
        if ($isNew) {
            enqueue_automation('entry_created', [
                'entry' => $entry,
                'collection' => $collection,
            ]);
            return;
        }

        $oldEntry = is_array($payload['old_entry'] ?? null) ? $payload['old_entry'] : null;
        enqueue_automation('entry_updated', [
            'entry' => $entry,
            'collection' => $collection,
            'old_entry' => $oldEntry,
        ]);

        if (!empty($payload['status_changed'])) {
            enqueue_automation('status_changed', [
                'entry' => $entry,
                'collection' => $collection,
                'from_status' => (string) ($payload['old_status'] ?? ''),
                'to_status' => (string) ($payload['new_status'] ?? ''),
            ]);
        }
    } catch (Throwable $e) {
        error_log('automation birkly_entry_saved hook skipped: ' . $e->getMessage());
    }
});
