<?php
/**
 * Automation notification shelf registrations (P83-M3).
 */

declare(strict_types=1);

if (!function_exists('register_broadcast_actor')) {
    return;
}

if (!function_exists('automation_plugin_active') || !automation_plugin_active()) {
    return;
}

register_broadcast_actor('automation', ['automation'], ['automation_']);
