<?php
/**
 * Automation recipe pack loader / validator / importer (P54 P3-M3).
 *
 * Recipes live as JSON under recipes/{pack}/*.json (+ pack.json manifest).
 */

require_once __DIR__ . '/node_serializer.php';

/**
 * Absolute path to the recipes root directory.
 */
function automation_recipes_root(): string
{
    return dirname(__DIR__) . '/recipes';
}

/**
 * @return list<string> Pack directory names under recipes/
 */
function automation_list_recipe_packs(): array
{
    $root = automation_recipes_root();
    if (!is_dir($root)) {
        return [];
    }

    $packs = [];
    foreach (scandir($root) ?: [] as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        $dir = $root . '/' . $entry;
        if (is_dir($dir) && is_file($dir . '/pack.json')) {
            $packs[] = $entry;
        }
    }
    sort($packs);
    return $packs;
}

/**
 * @return array<string, mixed>|null
 */
function automation_read_recipe_pack(string $packId): ?array
{
    $packId = automation_sanitize_recipe_slug($packId);
    if ($packId === '') {
        return null;
    }
    $path = automation_recipes_root() . '/' . $packId . '/pack.json';
    if (!is_file($path)) {
        return null;
    }
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

/**
 * Trigger types currently registered in the automation block registry.
 *
 * @return list<string>
 */
function automation_recipe_registered_trigger_types(): array
{
    if (!function_exists('get_automation_blocks')) {
        return [];
    }

    $blocks = get_automation_blocks('trigger');
    return array_keys($blocks);
}

/**
 * Active plugin ids from the CMS (empty when unavailable, e.g. isolated tests).
 *
 * @return list<string>
 */
function automation_recipe_active_plugin_ids(): array
{
    if (!function_exists('get_active_plugins')) {
        return [];
    }

    return array_keys(get_active_plugins());
}

/**
 * Human label for a plugin id referenced in recipe pack requirements.
 */
function automation_recipe_plugin_label(string $pluginId): string
{
    $labels = [
        'commerce' => 'Commerce',
        'user_management' => 'User Management',
        'automation' => 'Automation',
    ];

    if (isset($labels[$pluginId])) {
        return $labels[$pluginId];
    }

    return ucwords(str_replace('_', ' ', $pluginId));
}

/**
 * Evaluate whether a pack's declared requirements are met on this site.
 *
 * @param array<string, mixed> $requires
 * @return array{available: bool, missing_plugins: list<string>, missing_triggers: list<string>}
 */
function automation_recipe_evaluate_requirements(array $requires): array
{
    $activePlugins = automation_recipe_active_plugin_ids();
    $registeredTriggers = automation_recipe_registered_trigger_types();
    $missingPlugins = [];
    $missingTriggers = [];

    foreach ($requires as $key => $level) {
        if ($key === 'triggers' || $key === 'actions' || $key === 'automation') {
            continue;
        }
        if (!is_string($level)) {
            continue;
        }
        if (!in_array($key, $activePlugins, true)) {
            $missingPlugins[] = $key;
        }
    }

    $triggerList = is_array($requires['triggers'] ?? null) ? $requires['triggers'] : [];
    foreach ($triggerList as $trigger) {
        $trigger = trim((string) $trigger);
        if ($trigger === '') {
            continue;
        }
        if (!in_array($trigger, $registeredTriggers, true)) {
            $missingTriggers[] = $trigger;
        }
    }

    return [
        'available' => $missingPlugins === [] && $missingTriggers === [],
        'missing_plugins' => array_values(array_unique($missingPlugins)),
        'missing_triggers' => array_values(array_unique($missingTriggers)),
    ];
}

/**
 * Explain why a recipe is not importable on this site.
 *
 * @param array{available: bool, missing_plugins: list<string>, missing_triggers: list<string>} $eval
 */
function automation_recipe_unavailable_reason(array $eval, bool $triggerAvailable, string $triggerType): string
{
    if ($eval['missing_plugins'] !== []) {
        $names = array_map('automation_recipe_plugin_label', $eval['missing_plugins']);
        return 'Requires ' . implode(' and ', $names) . ' plugin' . (count($names) === 1 ? '' : 's');
    }

    if (!$triggerAvailable && $triggerType !== '') {
        return 'Trigger not available yet: ' . $triggerType;
    }

    if ($eval['missing_triggers'] !== []) {
        return 'Waiting for triggers from connected plugins';
    }

    return 'Unavailable on this site';
}

/**
 * Internal / site-specific packs that must never appear in the merchant starter catalog.
 *
 * @return list<string>
 */
function automation_recipe_starter_pack_denylist(): array
{
    return ['club', 'membership-club-depth'];
}

/**
 * Whether a pack belongs in the admin starter-template catalog.
 *
 * @param array<string, mixed> $packMeta
 */
function automation_recipe_is_starter_catalog_pack(string $packId, array $packMeta, bool $includeHidden = false): bool
{
    if (!automation_recipe_pack_is_catalog_visible($packMeta, $includeHidden)) {
        return false;
    }

    if (in_array($packId, automation_recipe_starter_pack_denylist(), true)) {
        return false;
    }

    return true;
}

/**
 * Whether a pack should appear in the admin starter catalog.
 *
 * @param array<string, mixed> $packMeta
 */
function automation_recipe_pack_is_catalog_visible(array $packMeta, bool $includeHidden = false): bool
{
    $visibility = strtolower(trim((string) ($packMeta['visibility'] ?? 'default')));
    if ($visibility === 'hidden') {
        return $includeHidden;
    }

    return true;
}

/**
 * Build grouped recipe catalog for admin UI (filters hidden packs + annotates availability).
 *
 * @param array<string, mixed> $options include_hidden?, available_only?
 * @return list<array<string, mixed>>
 */
function automation_build_recipe_catalog(array $options = []): array
{
    $includeHidden = !empty($options['include_hidden']);
    $availableOnly = !empty($options['available_only']);
    $starterOnly = !array_key_exists('starter_only', $options) || !empty($options['starter_only']);
    $registeredTriggers = automation_recipe_registered_trigger_types();
    $catalog = [];

    foreach (automation_list_recipe_packs() as $packId) {
        $meta = automation_read_recipe_pack($packId);
        if (!is_array($meta)) {
            continue;
        }

        if ($starterOnly && !automation_recipe_is_starter_catalog_pack($packId, $meta, $includeHidden)) {
            continue;
        }

        if (!$starterOnly && !automation_recipe_pack_is_catalog_visible($meta, $includeHidden)) {
            continue;
        }

        $requires = is_array($meta['requires'] ?? null) ? $meta['requires'] : [];
        $eval = automation_recipe_evaluate_requirements($requires);
        $recipes = [];

        foreach (automation_list_recipes($packId) as $summary) {
            $triggerType = (string) ($summary['trigger_type'] ?? '');
            $triggerAvailable = $triggerType !== '' && in_array($triggerType, $registeredTriggers, true);
            $available = $eval['available'] && $triggerAvailable;

            $summary['available'] = $available;
            if (!$available) {
                $summary['unavailable_reason'] = automation_recipe_unavailable_reason($eval, $triggerAvailable, $triggerType);
            }

            if ($availableOnly && !$available) {
                continue;
            }

            $recipes[] = $summary;
        }

        if ($availableOnly && $recipes === []) {
            continue;
        }

        if ($availableOnly && !$eval['available']) {
            continue;
        }

        $catalog[] = [
            'id' => (string) ($meta['id'] ?? $packId),
            'name' => (string) ($meta['name'] ?? $packId),
            'description' => (string) ($meta['description'] ?? ''),
            'visibility' => (string) ($meta['visibility'] ?? 'default'),
            'available' => $eval['available'],
            'missing_plugins' => $eval['missing_plugins'],
            'missing_triggers' => $eval['missing_triggers'],
            'recipe_count' => count($recipes),
            'recipes' => $recipes,
        ];
    }

    return $catalog;
}

/**
 * List recipes, optionally filtered by pack.
 *
 * @return list<array<string, mixed>>
 */
function automation_list_recipes(?string $packId = null): array
{
    $packs = $packId !== null && $packId !== ''
        ? [automation_sanitize_recipe_slug($packId)]
        : automation_list_recipe_packs();

    $out = [];
    foreach ($packs as $pack) {
        if ($pack === '') {
            continue;
        }
        $dir = automation_recipes_root() . '/' . $pack;
        if (!is_dir($dir)) {
            continue;
        }
        foreach (scandir($dir) ?: [] as $file) {
            if ($file === 'pack.json' || !str_ends_with($file, '.json')) {
                continue;
            }
            $recipe = automation_load_recipe_file($dir . '/' . $file);
            if ($recipe !== null) {
                $out[] = automation_recipe_public_summary($recipe);
            }
        }
    }

    usort($out, static function (array $a, array $b): int {
        return strcmp((string) ($a['id'] ?? ''), (string) ($b['id'] ?? ''));
    });

    return $out;
}

/**
 * @return array<string, mixed>|null Full recipe including workflow fields
 */
function automation_get_recipe(string $recipeId): ?array
{
    $recipeId = trim($recipeId);
    if ($recipeId === '') {
        return null;
    }

    foreach (automation_list_recipe_packs() as $pack) {
        $dir = automation_recipes_root() . '/' . $pack;
        foreach (scandir($dir) ?: [] as $file) {
            if ($file === 'pack.json' || !str_ends_with($file, '.json')) {
                continue;
            }
            $recipe = automation_load_recipe_file($dir . '/' . $file);
            if ($recipe !== null && ($recipe['id'] ?? '') === $recipeId) {
                return $recipe;
            }
        }
    }

    return null;
}

/**
 * Validate a recipe array. Returns list of error strings (empty = valid).
 *
 * @param array<string, mixed> $recipe
 * @return list<string>
 */
function automation_validate_recipe(array $recipe): array
{
    $errors = [];

    $id = trim((string) ($recipe['id'] ?? ''));
    if ($id === '') {
        $errors[] = 'Recipe id is required';
    } elseif (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $id)) {
        $errors[] = 'Recipe id must be lowercase kebab-case';
    }

    if (trim((string) ($recipe['name'] ?? '')) === '') {
        $errors[] = 'Recipe name is required';
    }

    $trigger = $recipe['trigger'] ?? null;
    if (!is_array($trigger) || trim((string) ($trigger['type'] ?? '')) === '') {
        $errors[] = 'Recipe trigger.type is required';
    }

    $actions = $recipe['actions'] ?? null;
    if (!is_array($actions) || $actions === []) {
        $errors[] = 'Recipe must include at least one action';
    } else {
        foreach ($actions as $index => $action) {
            if (!is_array($action) || trim((string) ($action['type'] ?? '')) === '') {
                $errors[] = "Action {$index} is missing type";
                continue;
            }
            $type = (string) $action['type'];
            $config = is_array($action['config'] ?? null) ? $action['config'] : [];
            if ($type === 'email') {
                if (trim((string) ($config['subject'] ?? '')) === '') {
                    $errors[] = "Action {$index} email subject is required";
                }
                if (trim((string) ($config['body'] ?? '')) === '') {
                    $errors[] = "Action {$index} email body is required";
                }
            }
            if ($type === 'log' && trim((string) ($config['message'] ?? '')) === '') {
                $errors[] = "Action {$index} log message is required";
            }
        }
    }

    if (isset($recipe['conditions']) && !is_array($recipe['conditions'])) {
        $errors[] = 'Recipe conditions must be an array';
    }

    return $errors;
}

/**
 * Import a recipe into automations storage.
 *
 * @param array<string, mixed> $options enabled?, name?, to?
 * @return array{ok: bool, automation?: array, errors?: list<string>, recipe?: array}
 */
function automation_import_recipe(string $recipeId, array $options = []): array
{
    $recipe = automation_get_recipe($recipeId);
    if ($recipe === null) {
        return ['ok' => false, 'errors' => ['Recipe not found: ' . $recipeId]];
    }

    $errors = automation_validate_recipe($recipe);
    if ($errors !== []) {
        return ['ok' => false, 'errors' => $errors, 'recipe' => $recipe];
    }

    $actions = [];
    foreach ($recipe['actions'] as $action) {
        if (!is_array($action)) {
            continue;
        }
        $config = is_array($action['config'] ?? null) ? $action['config'] : [];
        if (($action['type'] ?? '') === 'email' && isset($options['to']) && trim((string) $options['to']) !== '') {
            $config['to'] = trim((string) $options['to']);
        }
        $actions[] = [
            'type' => (string) $action['type'],
            'config' => $config,
        ];
    }

    $workflow = [
        'name' => trim((string) ($options['name'] ?? $recipe['name'] ?? 'Imported recipe')),
        'enabled' => array_key_exists('enabled', $options)
            ? (bool) $options['enabled']
            : (bool) ($recipe['enabled'] ?? false),
        'stop_on_failure' => (bool) ($recipe['stop_on_failure'] ?? false),
        'trigger' => [
            'type' => (string) $recipe['trigger']['type'],
            'config' => is_array($recipe['trigger']['config'] ?? null) ? $recipe['trigger']['config'] : [],
        ],
        'conditions' => is_array($recipe['conditions'] ?? null) ? $recipe['conditions'] : [],
        'actions' => $actions,
        'recipe_id' => (string) $recipe['id'],
        'recipe_pack' => (string) ($recipe['pack'] ?? ''),
    ];

    $workflow['graph'] = automation_canvas_from_workflow($workflow);

    if (!function_exists('create_automation')) {
        require_once dirname(__DIR__) . '/automation.php';
    }

    $created = create_automation($workflow);
    if (!is_array($created)) {
        return ['ok' => false, 'errors' => ['Failed to create automation record'], 'recipe' => $recipe];
    }

    return [
        'ok' => true,
        'automation' => $created,
        'recipe' => automation_recipe_public_summary($recipe),
    ];
}

/**
 * Import every recipe in a pack.
 *
 * @return array{ok: bool, imported: list<array>, errors: list<string>}
 */
function automation_import_recipe_pack(string $packId, array $options = []): array
{
    $packId = automation_sanitize_recipe_slug($packId);
    $recipes = automation_list_recipes($packId);
    if ($recipes === []) {
        return ['ok' => false, 'imported' => [], 'errors' => ['No recipes found for pack: ' . $packId]];
    }

    $imported = [];
    $errors = [];
    foreach ($recipes as $summary) {
        $id = (string) ($summary['id'] ?? '');
        $result = automation_import_recipe($id, $options);
        if (!empty($result['ok']) && isset($result['automation'])) {
            $imported[] = $result['automation'];
        } else {
            $errors[] = $id . ': ' . implode('; ', $result['errors'] ?? ['import failed']);
        }
    }

    return [
        'ok' => $errors === [],
        'imported' => $imported,
        'errors' => $errors,
    ];
}

/**
 * @return array<string, mixed>|null
 */
function automation_load_recipe_file(string $path): ?array
{
    if (!is_file($path)) {
        return null;
    }
    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        return null;
    }
    if (empty($data['pack'])) {
        $data['pack'] = basename(dirname($path));
    }
    return $data;
}

/**
 * @param array<string, mixed> $recipe
 * @return array<string, mixed>
 */
function automation_recipe_public_summary(array $recipe): array
{
    $triggerType = is_array($recipe['trigger'] ?? null)
        ? (string) ($recipe['trigger']['type'] ?? '')
        : '';
    $packId = (string) ($recipe['pack'] ?? '');
    $packMeta = $packId !== '' ? automation_read_recipe_pack($packId) : null;
    $requires = is_array($packMeta['requires'] ?? null) ? $packMeta['requires'] : [];
    $eval = automation_recipe_evaluate_requirements($requires);
    $triggerAvailable = $triggerType !== '' && in_array($triggerType, automation_recipe_registered_trigger_types(), true);
    $available = $eval['available'] && $triggerAvailable;

    $summary = [
        'id' => (string) ($recipe['id'] ?? ''),
        'pack' => $packId,
        'name' => (string) ($recipe['name'] ?? ''),
        'description' => (string) ($recipe['description'] ?? ''),
        'trigger_type' => $triggerType,
        'tags' => is_array($recipe['tags'] ?? null) ? array_values($recipe['tags']) : [],
        'notes' => (string) ($recipe['notes'] ?? ''),
        'expected_trigger' => is_array($recipe['expected_trigger'] ?? null) ? $recipe['expected_trigger'] : null,
        'action_count' => is_array($recipe['actions'] ?? null) ? count($recipe['actions']) : 0,
        'available' => $available,
    ];

    if (!$available) {
        $summary['unavailable_reason'] = automation_recipe_unavailable_reason($eval, $triggerAvailable, $triggerType);
    }

    return $summary;
}

function automation_sanitize_recipe_slug(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9\-]/', '', $value) ?? '';
    return $value;
}
