#!/usr/bin/env php
<?php
/**
 * Import automation recipe(s) into settings/automations.json.
 *
 * Usage:
 *   php plugins/automation/cli/import_recipe.php --list
 *   php plugins/automation/cli/import_recipe.php commerce-post-purchase-receipt
 *   php plugins/automation/cli/import_recipe.php --pack=commerce
 *   php plugins/automation/cli/import_recipe.php commerce-post-purchase-receipt --enabled --to=ops@example.com
 */

if (php_sapi_name() !== 'cli') {
    fwrite(STDERR, "This script must be run from the command line.\n");
    exit(1);
}

$root = dirname(__DIR__, 3);
chdir($root);

require_once $root . '/core/automation/bootstrap.php';
if (!automation_bootstrap()) {
    fwrite(STDERR, "Automation plugin is not active.\n");
    exit(1);
}

require_once dirname(__DIR__) . '/includes/recipes.php';

$args = array_slice($argv, 1);
$listOnly = false;
$pack = null;
$recipeId = null;
$options = [];

foreach ($args as $arg) {
    if ($arg === '--list' || $arg === '-l') {
        $listOnly = true;
        continue;
    }
    if (str_starts_with($arg, '--pack=')) {
        $pack = substr($arg, 7);
        continue;
    }
    if ($arg === '--enabled') {
        $options['enabled'] = true;
        continue;
    }
    if (str_starts_with($arg, '--to=')) {
        $options['to'] = substr($arg, 5);
        continue;
    }
    if (str_starts_with($arg, '--name=')) {
        $options['name'] = substr($arg, 7);
        continue;
    }
    if (!str_starts_with($arg, '-')) {
        $recipeId = $arg;
    }
}

if ($listOnly) {
    $recipes = automation_list_recipes($pack);
    echo json_encode(['status' => 'ok', 'recipes' => $recipes], JSON_PRETTY_PRINT) . "\n";
    exit(0);
}

if ($pack !== null && $recipeId === null) {
    $result = automation_import_recipe_pack($pack, $options);
    echo json_encode([
        'status' => $result['ok'] ? 'ok' : 'error',
        'imported' => array_map(static fn (array $a): string => (string) ($a['id'] ?? ''), $result['imported']),
        'count' => count($result['imported']),
        'errors' => $result['errors'],
    ], JSON_PRETTY_PRINT) . "\n";
    exit($result['ok'] ? 0 : 1);
}

if ($recipeId === null || $recipeId === '') {
    fwrite(STDERR, "Usage: php plugins/automation/cli/import_recipe.php <recipe_id|--pack=commerce|--list>\n");
    exit(1);
}

$result = automation_import_recipe($recipeId, $options);
if (empty($result['ok'])) {
    echo json_encode([
        'status' => 'error',
        'errors' => $result['errors'] ?? ['import failed'],
    ], JSON_PRETTY_PRINT) . "\n";
    exit(1);
}

echo json_encode([
    'status' => 'ok',
    'automation' => [
        'id' => $result['automation']['id'] ?? null,
        'name' => $result['automation']['name'] ?? null,
        'enabled' => $result['automation']['enabled'] ?? false,
        'recipe_id' => $result['automation']['recipe_id'] ?? null,
        'trigger' => $result['automation']['trigger'] ?? null,
    ],
], JSON_PRETTY_PRINT) . "\n";
exit(0);
