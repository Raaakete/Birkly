<?php
/**
 * Advanced automation actions: related entry lookup and collection email broadcast.
 */

require_once __DIR__ . '/../registry.php';
require_once __DIR__ . '/../executor.php';
require_once __DIR__ . '/../includes/collection_entries.php';
require_once __DIR__ . '/../includes/email_delivery.php';
require_once __DIR__ . '/../includes/recipient_sources.php';

$automationEmailDefaults = function_exists('automation_default_email_templates')
    ? automation_default_email_templates()
    : [
        'subject' => '{{automation.name}}',
        'body' => "{{trigger_summary}}\n\nTitle: {{entry.title}}\nCollection: {{collection}}\n\nOpen in Birkly:\n{{entry_admin_url}}",
    ];

$broadcastBodyDefault = "Hello {{recipient.display_name}},\n\n{{trigger_summary}}\n\n{{entry.title}}\n\nOpen in Birkly:\n{{entry_admin_url}}";

register_automation_block('action', 'lookup_entry', [
    'name' => 'Lookup Related Entry',
    'description' => 'Find an entry in another collection and expose it as {{related.*}} in later steps',
    'category' => 'Content',
    'schema' => [
        'collection' => [
            'type' => 'collection_picker',
            'label' => 'Lookup collection',
            'required' => true,
            'description' => 'Collection to search (for example members or users).',
        ],
        'match_trigger_field' => [
            'type' => 'string',
            'label' => 'Value from trigger entry',
            'required' => true,
            'templated' => true,
            'placeholder' => '{{entry.author_id}}',
            'description' => 'Field on the triggering entry whose value is used for the lookup.',
        ],
        'match_target_field' => [
            'type' => 'string',
            'label' => 'Match field on lookup collection',
            'required' => true,
            'default' => 'slug',
            'description' => 'Field on entries in the lookup collection that must equal the trigger value (for example id, slug, or email).',
        ],
        'match_operator' => [
            'type' => 'select',
            'label' => 'Match operator',
            'options' => [
                ['value' => 'equals', 'label' => 'Equals'],
                ['value' => 'contains', 'label' => 'Contains'],
            ],
            'default' => 'equals',
        ],
        'store_as' => [
            'type' => 'string',
            'label' => 'Context prefix',
            'default' => 'related',
            'description' => 'Templates use {{related.field}} when set to related. Use recipient to reuse Send Email tokens.',
        ],
    ],
    'handler' => function ($config, $context) {
        $collection = trim((string) ($config['collection'] ?? ''));
        $triggerFieldTemplate = trim((string) ($config['match_trigger_field'] ?? ''));
        $targetField = trim((string) ($config['match_target_field'] ?? ''));
        $operator = trim((string) ($config['match_operator'] ?? 'equals'));
        $storeAs = trim((string) ($config['store_as'] ?? 'related'));
        if ($storeAs === '' || !preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/', $storeAs)) {
            $storeAs = 'related';
        }

        if ($collection === '' || $triggerFieldTemplate === '' || $targetField === '') {
            throw new Exception('Lookup collection, trigger field, and target field are required');
        }

        $matchValue = trim(render_automation_template($triggerFieldTemplate, $context));
        if ($matchValue === '') {
            throw new Exception('Lookup value is empty after resolving templates. Check the trigger entry field used for matching.');
        }

        $found = automation_lookup_collection_entry($collection, $targetField, $matchValue, $operator);
        if ($found === null) {
            throw new Exception(
                'No entry found in "' . $collection . '" where ' . $targetField . ' ' . $operator . ' "' . $matchValue . '"'
            );
        }

        return [
            'found' => true,
            'collection' => $collection,
            'entry_id' => $found['id'] ?? null,
            'entry_slug' => $found['slug'] ?? null,
            '_context_merge' => [
                $storeAs => $found,
            ],
        ];
    },
]);

$userTierOptions = [['value' => 'any', 'label' => 'Any tier']];
foreach (automation_user_management_tier_options() as $tierId) {
    $userTierOptions[] = ['value' => $tierId, 'label' => ucfirst(str_replace(['-', '_'], ' ', $tierId))];
}

register_automation_block('action', 'email_broadcast', [
    'name' => 'Send Email to Many',
    'description' => 'Email many people when something happens — all site users, or every matching entry in a collection',
    'category' => 'Communication',
    'schema' => [
        'recipient_source' => [
            'type' => 'recipient_source',
            'label' => 'Recipients',
            'required' => true,
            'default' => 'site_users',
            'options' => [
                ['value' => 'site_users', 'label' => 'All site users', 'description' => 'Everyone in User Management with a valid email'],
                ['value' => 'collection', 'label' => 'Collection entries', 'description' => 'Each matching entry in a collection (newsletter list, members, etc.)'],
            ],
            'ui_section' => 'recipients',
        ],
        'collection' => [
            'type' => 'collection_picker',
            'label' => 'Recipient collection',
            'required' => true,
            'description' => 'Each entry with a valid email field receives one message.',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'collection'],
            'required_when' => ['recipient_source' => 'collection'],
        ],
        'email_field' => [
            'type' => 'string',
            'label' => 'Email field slug',
            'required' => true,
            'default' => 'email',
            'description' => 'Field on recipient entries that holds the email address.',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'collection'],
        ],
        'status_filter' => [
            'type' => 'select',
            'label' => 'Entry status',
            'options' => [
                ['value' => 'published', 'label' => 'Published only'],
                ['value' => 'draft', 'label' => 'Draft only'],
                ['value' => 'any', 'label' => 'Any status'],
            ],
            'default' => 'published',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'collection'],
        ],
        'filter_field' => [
            'type' => 'string',
            'label' => 'Optional filter field',
            'description' => 'Only include entries whose field matches the filter value (leave empty for all).',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'collection'],
        ],
        'filter_operator' => [
            'type' => 'select',
            'label' => 'Filter operator',
            'options' => [
                ['value' => 'equals', 'label' => 'Equals'],
                ['value' => 'not_equals', 'label' => 'Not equals'],
                ['value' => 'contains', 'label' => 'Contains'],
                ['value' => 'is_truthy', 'label' => 'Is checked / truthy'],
            ],
            'default' => 'equals',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'collection'],
        ],
        'filter_value' => [
            'type' => 'string',
            'label' => 'Filter value',
            'templated' => true,
            'description' => 'Compared against each recipient entry. For checkbox fields use 1 or true.',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'collection'],
        ],
        'user_tier_filter' => [
            'type' => 'select',
            'label' => 'User tier',
            'options' => $userTierOptions,
            'default' => 'any',
            'description' => 'Limit to one membership tier, or any tier.',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'site_users'],
        ],
        'user_verified_only' => [
            'type' => 'checkbox',
            'label' => 'Verified email only',
            'default' => true,
            'description' => 'Skip users who have not verified their email address.',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'site_users'],
        ],
        'user_status_filter' => [
            'type' => 'select',
            'label' => 'User status',
            'options' => [
                ['value' => 'active', 'label' => 'Active'],
                ['value' => 'any', 'label' => 'Any status'],
            ],
            'default' => 'active',
            'ui_section' => 'recipients',
            'show_when' => ['recipient_source' => 'site_users'],
        ],
        'subject' => [
            'type' => 'string',
            'label' => 'Subject',
            'required' => true,
            'default' => 'New on {{collection}}: {{entry.title}}',
            'templated' => true,
            'ui_section' => 'message',
        ],
        'body' => [
            'type' => 'textarea',
            'label' => 'Message',
            'required' => true,
            'default' => $broadcastBodyDefault,
            'rows' => 10,
            'templated' => true,
            'description' => 'Use {{recipient.field}} for each recipient and {{entry.field}} for the triggering entry.',
            'ui_section' => 'message',
            'template_vars_collapsed' => true,
        ],
        'max_recipients' => [
            'type' => 'number',
            'label' => 'Max recipients',
            'default' => 500,
            'description' => 'Safety cap per workflow run.',
            'ui_section' => 'delivery',
        ],
        'connection_alias' => [
            'type' => 'email_connection',
            'label' => 'Send using',
            'required' => false,
            'ui_section' => 'delivery',
        ],
    ],
    'handler' => function ($config, $context) {
        $source = trim((string) ($config['recipient_source'] ?? ''));
        if ($source === '') {
            $source = trim((string) ($config['collection'] ?? '')) !== '' ? 'collection' : 'site_users';
        }
        if ($source === 'site_users' && !automation_user_management_available()) {
            throw new Exception('Site users recipient source requires the User Management plugin to be active.');
        }

        $entries = automation_resolve_broadcast_recipients($config, $context);
        if ($entries === []) {
            throw new Exception(
                'No matching recipients found for ' . automation_broadcast_recipient_label($config)
            );
        }

        $maxRecipients = (int) ($config['max_recipients'] ?? 500);
        if ($maxRecipients < 1) {
            $maxRecipients = 500;
        }
        if ($maxRecipients > 5000) {
            $maxRecipients = 5000;
        }

        if (count($entries) > $maxRecipients) {
            throw new Exception(
                'Recipient list has ' . count($entries) . ' entries but max_recipients is ' . $maxRecipients . '. Raise the cap or tighten filters.'
            );
        }

        $subjectTemplate = (string) ($config['subject'] ?? '');
        $bodyTemplate = (string) ($config['body'] ?? '');

        $sent = 0;
        $deduped = 0;
        $failures = [];
        $recipients = [];

        foreach ($entries as $recipientEntry) {
            $to = trim((string) ($recipientEntry['email'] ?? ''));
            if ($to === '') {
                continue;
            }

            $recipientContext = array_merge($context, [
                'recipient' => $recipientEntry,
            ]);

            try {
                $result = automation_send_templated_email($to, $subjectTemplate, $bodyTemplate, $recipientContext, $config);
                if (!empty($result['deduped'])) {
                    $deduped++;
                } else {
                    $sent++;
                }
                $recipients[] = [
                    'to' => $to,
                    'entry_id' => $recipientEntry['id'] ?? null,
                    'deduped' => !empty($result['deduped']),
                ];
            } catch (Exception $e) {
                $failures[] = $to . ': ' . $e->getMessage();
            }
        }

        if ($sent === 0 && $deduped === 0) {
            $detail = $failures !== [] ? implode('; ', array_slice($failures, 0, 3)) : 'unknown error';
            throw new Exception('Broadcast did not send any emails: ' . $detail);
        }

        return [
            'sent' => $sent,
            'deduped' => $deduped,
            'total_matched' => count($entries),
            'failures' => count($failures),
            'failure_samples' => array_slice($failures, 0, 5),
            'recipients' => array_slice($recipients, 0, 20),
            'recipient_source' => $source,
        ];
    },
]);
