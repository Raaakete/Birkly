# Changelog

## 1.1.31 - 2026-09-09

- **Starter templates UX** — moved below your automation list, collapsed by default when you already have workflows, compact table layout.
- Admin catalog now shows **only generic, available** starter packs (club/internal packs hard-excluded; unavailable packs hidden).

## 1.1.30 - 2026-09-08

- **Hotfix:** Fix PHP 8.3 parse error in `api/automation.php` that broke all Automation admin API calls (empty 500 / “Unexpected end of JSON input”).

## 1.1.29 - 2026-09-08

- **Starter templates** — recipe catalog grouped by pack with clearer copy; club/internal packs hidden from the default admin view.
- Templates only appear when required plugins are active and their triggers are registered (Automation does not assume other plugins until they connect).
- Release zip ships Commerce + Content starter packs only (internal club recipe packs remain in source for Birkly ops sites).

## 1.1.28 - 2026-09-08

- **Send Email to Many** (formerly “Send Email to Collection”) — choose **All site users** (User Management) or **Collection entries** as recipients; tier/status/verified filters for site users.
- Tabbed email inspector (**Recipients · Message · Delivery**) with recipient preview count and collapsible template variable chips.
- Recipe pack **Content notifications** — `New blog post → email all users` starter workflow.
- API: `preview_email_recipients` for live recipient counts in the editor.

## 1.1.27 - 2026-09-08

- **Send Email to Collection** action — broadcast templated email to every matching entry in a recipient collection (status + optional field filter, max cap, per-recipient `{{recipient.field}}` tokens).
- **Lookup Related Entry** action — find an entry in another collection and expose it as `{{related.*}}` (custom prefix) for later steps in the same workflow.
- Shared `automation_send_templated_email()` delivery helper; Send Email action refactored to use it.
- Executor merges `_context_merge` from action results so lookup enriches downstream steps.
- Editor: recipient/trigger field chips for broadcast; collection field API accepts `prefix` query param.
- Docs: `docs/help-email.md` expanded for broadcast and lookup patterns.

## 1.1.26 - 2026-09-08

- **Send Email content variables:** `to` field supports `{{entry.field_slug}}` templates; subject/body templated; editor chips load collection schema fields via `get_collection_fields`.

## 1.1.23 - 2026-09-08

- **P83-M2:** Dashboard mount shelf — `admin/dashboard-widget.js` registers `automationRuns` (active/queued stat grid) via `admin.scripts`.

## 1.1.22 - 2026-09-05

- **P80-M6:** Recipe pack `membership-club-depth` v1.0.2 — welcome email on `club_member_onboarded`; admin email on `club_member_reported`.

## 1.1.21 - 2026-09-05

- **P80-M3:** Recipe `club-depth-send-notification-digests` — daily scheduled workflow calling User `send_club_notification_digests` action.

## 1.1.20 - 2026-09-05

- **P80-M1:** Recipe pack `membership-club-depth` — send activation email on `commerce_subscription_started` when checkout includes club opt-in; optional welcome email on `user_tier_changed`.

## 1.1.19 - 2026-09-05

- **P79:** Club supporter badge sync recipe pack (`recipes/club/`) — donation, subscription, and subscription-cancel workflows call User `sync_supporter_badge`.

## 1.1.18 - 2026-09-02

- **P74-M6:** Remove deprecated `commerce-membership-club-activation` recipe from Commerce recipe pack (club activation is User signup-flow owned).

## 1.1.17 - 2026-08-19

- **MCP admin parity:** `includes/AutomationMcpAdmin.php` dispatches every `api/automation.php` action for connected AI (`automation_list_admin_actions`, `automation_admin_action`, plus named tools for dry-run, live run, recipe pack import, mail settings, test email, collections, dashboard).
- See `docs/mcp-tools.md`.

## 1.1.16 - 2026-08-19

- **MCP tools:** Register `automation_*` inbound MCP tools when active (workflows CRUD, recipes, blocks, setup health, queue, dry-run test, process queue). See `docs/mcp-tools.md`.
- Requires Birkly core with plugin MCP shelf (`register_plugin_mcp_tools`).

## 1.1.15 - 2026-08-17

- Fix Send Email live runs using `noreply@HTTP_HOST` instead of the configured email connection From address (SMTP 553 sender rejected).
- Core mail sends no longer pass legacy Automation From headers; Settings → Connections owns the envelope.

## 1.1.14 - 2026-08-17

- Hotfix: restore `automation_settings_dir()` accidentally removed in 1.1.13 (broke Automation API / list loading).

## 1.1.13 - 2026-08-17

- Fix live email sends ignoring Settings → Connections: load `birkly_send_mail` before Send Email actions run (no more PHP mail() fallback on cloud hosts).
- Treat core mail `accepted`/`logged` results as success; pass per-action `connection_alias` through the legacy mailer fallback.
- Clearer errors pointing to Settings → Connections instead of the legacy Setup SMTP form.

## 1.1.12 - 2026-08-17

- Harden Send Email **Send using** picker: avoids duplicate labels, persists site default selection, and renames the graph footer to **Workflow links** (not email connections).

## 1.1.11 - 2026-08-17

- Fix Send Email **Send using** picker on the workflow editor page (loads `email-connection-picker.js`).

## 1.1.10 - 2026-08-17

- Send Email action: **Send using** connection picker (`connection_alias`) routes through Settings → Connections (falls back to site default).
- Automation admin loads shared `email-connection-picker.js` for the node editor.

## 1.1.9 - 2026-08-07

- P61: Admin activity toggles on Setup (`activity_notify`, `activity_nav_dot`) via plugins settings API.

## 1.1.8 - 2026-08-04

- Adopt P56 admin design language: core `.tabs`/`.tab`, `.card`, `.badge`, `.empty-state`, `.callout`, `.main-actions-bar`.
- Replace `payments-tabs` / `payments-tab` dialect with core filled-pill tabs.
- Shrink `automation.css` to Tier 1 (setup checklist, recipe grid, form blocks, dry-run/logs, workflow canvas); remove hardcoded hex (1520 → ~1041 lines, 175 → 0 hex).

## 1.1.7

- Commerce automation recipe pack and earlier fixes. See git history for details.
