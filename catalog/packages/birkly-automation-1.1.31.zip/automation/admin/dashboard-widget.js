(function () {
    'use strict';
    var UI = window.Birkly && window.Birkly.DashboardMount;
    var widgets = window.BirklyDashboardWidgets = window.BirklyDashboardWidgets || {};
    if (!UI) return;
    widgets.automationRuns = function (element, widget, data) {
        var queue = data && data.queue;
        UI.setContent(element, UI.statGrid([
            UI.statTile(data && data.enabled || 0, 'Active', 'good'),
            UI.statTile(queue && queue.pending || 0, 'Queued', 'warning'),
        ]));
    };
})();
