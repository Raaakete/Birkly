<?php
/**
 * User Management Plugin - Bootstrap
 * 
 * Fully self-contained user management plugin for Birkly
 * Phase 1: Core Infrastructure & Storage
 */

// Note: Plugin state is checked by the loader before including this file
// We don't need to check state here - if this file is included, the plugin is active

require_once __DIR__ . '/cms_paths.php';
require_once __DIR__ . '/init.php';

// Load plugin classes
require_once __DIR__ . '/includes/UserStorage.php';
require_once __DIR__ . '/includes/UserService.php';
require_once __DIR__ . '/includes/UserAuth.php';
require_once __DIR__ . '/includes/UserPermissions.php';
require_once __DIR__ . '/includes/UserTiers.php';
require_once __DIR__ . '/includes/ProfileService.php';
require_once __DIR__ . '/includes/EntryPermissions.php';

// P82 — storefront shelf filters (register on plugin load)
if (function_exists('add_filter')) {
    add_filter('birkly_public_current_user', function (?array $user): ?array {
        if (is_array($user) && !empty($user['id'])) {
            return $user;
        }
        $auth = new UserAuth('site');
        $resolved = $auth->getCurrentUser();
        if (is_array($resolved) && !empty($resolved['id'])) {
            return $resolved;
        }
        return $user;
    }, 10, 'user_management');

    add_filter('birkly_site_client_config', function (array $config): array {
        $chunk = [
            'auth' => [
                'check' => ['route' => 'user_auth', 'action' => 'check'],
                'login' => ['route' => 'user_auth', 'action' => 'login'],
                'logout' => ['route' => 'user_auth', 'action' => 'logout'],
                'csrf' => '/api/csrf.php',
            ],
        ];
        if (function_exists('birkly_merge_site_client_config')) {
            return birkly_merge_site_client_config($config, $chunk);
        }
        return array_replace_recursive($config, $chunk);
    }, 10, 'user_management');

    add_filter('birkly_entries_view_filter', function (array $entries, string $userId, string $collectionSlug): array {
        $entryPermissions = new EntryPermissions();
        return $entryPermissions->filterEntriesByViewPermission($userId, $entries, $collectionSlug);
    }, 10, 'user_management');

    add_filter('birkly_entry_view_allowed', function ($allowed, array $entry, string $userId, string $collectionSlug) {
        $entryPermissions = new EntryPermissions();
        return $entryPermissions->canViewEntry($userId, $entry, $collectionSlug);
    }, 10, 'user_management');
}

// Register User fieldtype when plugin is active
if (function_exists('register_plugin_fieldtype')) {
    // Load BaseField first
    if (!class_exists('Birkly\FieldTypes\BaseField')) {
        require_once __DIR__ . '/../../fieldtypes/BaseField.php';
    }
    
    // Load User fieldtype class
    require_once __DIR__ . '/fieldtypes/User/User.php';
    
    // Register the fieldtype
    register_plugin_fieldtype('user', 'UserManagement\\Fieldtypes\\User', 'user_management');
    
    // Load Password fieldtype class
    require_once __DIR__ . '/fieldtypes/Password/Password.php';
    
    // Register the fieldtype
    register_plugin_fieldtype('password', 'UserManagement\\Fieldtypes\\Password', 'user_management');

    require_once __DIR__ . '/fieldtypes/UserRelationship/UserRelationship.php';
    register_plugin_fieldtype('user_relationship', 'UserManagement\\Fieldtypes\\UserRelationship', 'user_management');

    user_management_register_fieldtype_profiles();
}

// Initialize default tier - always run when plugin loads (idempotent)
// This ensures the "All" tier exists and old tiers are cleaned up
try {
    $tiers = new UserTiers();
    $tiers->initializeDefaultTiers();
    user_management_ensure_club_collection_permissions();
    user_management_ensure_p76_schema();
    user_management_ensure_club_profiles_onboarding_schema();
    user_management_ensure_club_posts_mentions_schema();
    user_management_ensure_club_posts_moderation_schema();
    user_management_ensure_user_plugin_collection_markers();
    user_management_ensure_club_posts_subcollection_schemas();
    user_management_ensure_club_reports_collection();
    user_management_ensure_club_wishes_schema();
    user_management_ensure_club_deals_schema();
    user_management_ensure_club_introduce_yourself_post();
    user_management_backfill_profile_entries();
    user_management_ensure_fieldtype_profiles();
    require_once __DIR__ . '/includes/MemberProfileReconcile.php';
    try {
        user_management_reconcile_member_profiles();
    } catch (Throwable $e) {
        error_log('User Management member profile reconcile error: ' . $e->getMessage());
    }
    try {
        user_management_reconcile_club_tiers();
    } catch (Throwable $e) {
        error_log('User Management club tier reconcile error: ' . $e->getMessage());
    }
    if (function_exists('user_management_upgrade_club_profiles_p78')) {
        require_once __DIR__ . '/includes/ClubProfilesP78Upgrade.php';
        user_management_upgrade_club_profiles_p78();
    }
    
    // Migrate old default tiers if they exist
    $storage = new UserStorage();
    $oldDefaultTiers = ['free', 'basic', 'premium'];
    foreach ($oldDefaultTiers as $oldTierId) {
        $oldTier = $storage->getTier($oldTierId);
        if ($oldTier) {
            // Delete old default tiers
            $storage->deleteTier($oldTierId);
        }
    }
} catch (Exception $e) {
    // Silently fail - initialization will retry on next load
    error_log('User Management Plugin initialization error: ' . $e->getMessage());
}

// Register hook for future activations (redundant but safe)
if (function_exists('register_hook')) {
    register_hook('plugin_activated', function($plugin_id) {
        if ($plugin_id === 'user_management') {
            try {
                // Initialize default tier (just "All")
                $tiers = new UserTiers();
                $tiers->initializeDefaultTiers();
                user_management_ensure_club_collection_permissions();
                user_management_ensure_fieldtype_profiles();
                
                // Migrate old default tiers if they exist
                $storage = new UserStorage();
                $oldDefaultTiers = ['free', 'basic', 'premium'];
                foreach ($oldDefaultTiers as $oldTierId) {
                    $oldTier = $storage->getTier($oldTierId);
                    if ($oldTier) {
                        // Delete old default tiers
                        $storage->deleteTier($oldTierId);
                    }
                }
                
                // Log activation
                error_log('User Management Plugin activated');
            } catch (Exception $e) {
                error_log('User Management Plugin activation error: ' . $e->getMessage());
            }
        }
    });
}

// Register plugin service
if (function_exists('register_plugin_service')) {
    register_plugin_service('user_service', new UserService(), [
        'version' => '1.0.0',
        'description' => 'User management service for creating, updating, and querying users',
        'capability' => null,
        'scope' => 'global',
    ]);

    require_once __DIR__ . '/includes/UserActivationShelf.php';
    register_plugin_service('user_activation_shelf', new UserActivationShelf(), [
        'version' => '1.0.0',
        'description' => 'Account activation — send links, verify tokens, complete signup',
        'capability' => null,
        'scope' => 'global',
    ]);

    require_once __DIR__ . '/includes/SignupFlowShelf.php';
    register_plugin_service('signup_flow_shelf', new SignupFlowShelf(), [
        'version' => '1.0.0',
        'description' => 'Signup flow orchestration — presets, steps, commerce handoff',
        'capability' => null,
        'scope' => 'global',
    ]);
}

if (function_exists('subscribe_to_event')) {
    require_once __DIR__ . '/includes/SignupFlowPayload.php';
    require_once __DIR__ . '/includes/SignupFlowShelf.php';
    require_once __DIR__ . '/includes/UserMembershipLifecycle.php';
    require_once __DIR__ . '/includes/MemberCommerceShelf.php';
    require_once __DIR__ . '/includes/SupporterBadgeSync.php';
    UserMembershipLifecycle::register();
    SignupFlowEngine::registerEntitlementFilter();
    if (function_exists('user_management_register_club_tier_hooks')) {
        require_once __DIR__ . '/includes/MemberProfileReconcile.php';
        user_management_register_club_tier_hooks();
    }

    $signupFlowShelf = new SignupFlowShelf();
    $membershipLifecycle = new UserMembershipLifecycle();
    $memberCommerceShelf = new MemberCommerceShelf();

    $storedVersion = '';
    try {
        $storage = new UserStorage();
        $meta = $storage->readMetadata('plugin_runtime');
        if (is_array($meta)) {
            $storedVersion = (string) ($meta['membership_reconcile_version'] ?? '');
        }
    } catch (Throwable $e) {
        $storedVersion = '';
    }
    $currentVersion = (string) (json_decode((string) file_get_contents(__DIR__ . '/plugin.json'), true)['version'] ?? '');
    if ($storedVersion !== $currentVersion && $currentVersion !== '') {
        try {
            // Version bumps refresh club permissions only — never replay membership reconcile (welcome emails).
            user_management_ensure_club_collection_permissions();
            if ($currentVersion === '1.0.32') {
                require_once __DIR__ . '/includes/ClubSocialService.php';
                (new ClubSocialService())->resetAllReactions();
            }
            if ($currentVersion === '1.0.33') {
                user_management_ensure_roadmap_likes_subcollection();
            }
            if ($currentVersion === '1.0.36') {
                user_management_ensure_club_posts_comments_subcollection();
            }
            if ($currentVersion === '1.0.37') {
                user_management_ensure_user_relationships_collection();
            }
            if ($currentVersion === '1.0.38') {
                user_management_ensure_club_posts_likes_subcollection();
                user_management_ensure_club_wishes_likes_subcollection();
                user_management_upgrade_roadmap_likes_owner_schema();
                user_management_upgrade_club_posts_comments_owner_schema();
                require_once __DIR__ . '/includes/ClubSocialService.php';
                (new ClubSocialService())->resetAllReactions();
                require_once __DIR__ . '/scripts/migrate-p75-ugc.php';
                if (function_exists('user_management_migrate_p75_ugc')) {
                    user_management_migrate_p75_ugc(false);
                }
            }
            if ($currentVersion === '1.0.39') {
                user_management_ensure_club_profiles_owner_schema();
                user_management_ensure_user_relationships_collection();
            }
            if ($currentVersion === '1.0.40') {
                user_management_ensure_user_relationships_collection();
            }
            if ($currentVersion === '1.0.41') {
                require_once __DIR__ . '/scripts/migrate-p75-ugc.php';
                if (function_exists('user_management_migrate_p75_ugc')) {
                    user_management_migrate_p75_ugc(false);
                }
            }
            if ($currentVersion === '1.0.44' || $currentVersion === '1.0.42' || $currentVersion === '1.0.43') {
                if (version_compare($storedVersion, '1.0.42', '<')) {
                    user_management_run_p76_migration();
                }
            }
            if ($currentVersion === '1.0.45') {
                user_management_backfill_profile_entries();
            }
            if ($currentVersion === '1.0.57') {
                require_once __DIR__ . '/includes/ClubProfilesP78Upgrade.php';
                user_management_upgrade_club_profiles_p78();
            }
            if ($currentVersion === '1.0.60') {
                require_once __DIR__ . '/includes/SupporterBadgeSync.php';
                try {
                    (new SupporterBadgeSync())->reconcileAll();
                } catch (Throwable $e) {
                    error_log('User plugin P79 badge grandfather reconcile: ' . $e->getMessage());
                }
            }
            if ($currentVersion === '1.0.64') {
                user_management_ensure_club_profiles_onboarding_schema();
            }
            if ($currentVersion === '1.0.65') {
                user_management_ensure_club_posts_mentions_schema();
            }
            if ($currentVersion === '1.0.66') {
                user_management_ensure_club_posts_moderation_schema();
                user_management_ensure_club_reports_collection();
            }
            if ($currentVersion === '1.0.67') {
                user_management_ensure_club_wishes_schema();
                user_management_ensure_club_deals_schema();
                user_management_migrate_club_wish_statuses();
                user_management_ensure_club_introduce_yourself_post();
            }
            if ($currentVersion === '1.0.72') {
                user_management_ensure_club_posts_subcollection_schemas();
            }
            $storage = $storage ?? new UserStorage();
            $existingRuntime = $storage->readMetadata('plugin_runtime');
            if (!is_array($existingRuntime)) {
                $existingRuntime = [];
            }
            $storage->saveMetadata('plugin_runtime', array_merge($existingRuntime, [
                'membership_reconcile_version' => $currentVersion,
                'membership_reconciled_at' => date('c'),
            ]));
        } catch (Throwable $e) {
            error_log('User plugin version bump: ' . $e->getMessage());
        }
    }

    foreach (['commerce_subscription_started', 'commerce_order_paid'] as $commerceEvent) {
        subscribe_to_event($commerceEvent, function (array $payload) use ($signupFlowShelf, $commerceEvent) {
            if (!user_management_should_handle_signup_flow_commerce($payload)) {
                return;
            }
            try {
                $signupFlowShelf->onCommerceEvent($commerceEvent, $payload);
            } catch (Throwable $e) {
                error_log('Signup flow commerce handler: ' . $e->getMessage());
            }
        });
    }

    foreach ([
        'commerce_membership_started',
        'commerce_subscription_started',
        'commerce_subscription_canceled',
        'commerce_subscription_paused',
        'commerce_subscription_resumed',
        'commerce_subscription_past_due',
        'commerce_subscription_recovered',
        'commerce_subscription_renewed',
        'commerce_order_paid',
    ] as $commerceEvent) {
        subscribe_to_event($commerceEvent, function (array $payload) use ($membershipLifecycle, $memberCommerceShelf, $commerceEvent) {
            try {
                $memberCommerceShelf->handleCommerceEvent($commerceEvent, $payload);
            } catch (Throwable $e) {
                error_log('Member commerce shelf handler: ' . $e->getMessage());
            }
            try {
                $membershipLifecycle->handleCommerceEvent($commerceEvent, $payload);
            } catch (Throwable $e) {
                error_log('Membership lifecycle handler: ' . $e->getMessage());
            }
        });
    }
}

// Demo-website scope: on /demo-website/ pages only treat users as "logged in" if they are
// demo users (e.g. *@demo.social). CMS/admin users must not appear as logged in on the demo.
function user_management_is_demo_website_context() {
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    return (strpos($ref, '/demo-website/') !== false);
}

function user_management_is_demo_user($user) {
    if (!$user || !is_array($user)) {
        return false;
    }
    $email = $user['email'] ?? '';
    return (strpos($email, '@demo.social') !== false);
}

// Register template functions (stubs for Phase 1, will be fully implemented in Phase 2)
if (function_exists('register_template_function')) {
    // user_current - Get current logged-in user (demo-website: only demo users)
    register_template_function('user_current', function() {
        try {
            $auth = new UserAuth();
            $user = $auth->getCurrentUser();
            if (user_management_is_demo_website_context() && !user_management_is_demo_user($user)) {
                return null;
            }
            return $user;
        } catch (Exception $e) {
            error_log('Template function user_current error: ' . $e->getMessage());
            return null;
        }
    }, [
        'description' => 'Get current logged-in user object',
        'arguments' => []
    ]);
    
    // user_logged_in - Check if user is logged in (demo-website: only demo users)
    register_template_function('user_logged_in', function() {
        try {
            $auth = new UserAuth();
            if (!$auth->isLoggedIn()) {
                return false;
            }
            if (user_management_is_demo_website_context()) {
                $user = $auth->getCurrentUser();
                return user_management_is_demo_user($user);
            }
            return true;
        } catch (Exception $e) {
            error_log('Template function user_logged_in error: ' . $e->getMessage());
            return false;
        }
    }, [
        'description' => 'Check if a user is currently logged in',
        'arguments' => []
    ]);
    
    // user_by_id - Get user by ID (demo-website: only returns demo users)
    register_template_function('user_by_id', function($user_id) {
        try {
            $service = new UserService();
            $user = $service->getUser($user_id);
            if (!$user) return null;
            if (user_management_is_demo_website_context() && !user_management_is_demo_user($user)) {
                return null;
            }
            return $user;
        } catch (Exception $e) {
            error_log('Template function user_by_id error: ' . $e->getMessage());
            return null;
        }
    }, [
        'description' => 'Get user by ID',
        'arguments' => [
            ['name' => 'user_id', 'type' => 'string', 'required' => true]
        ]
    ]);
    
    // user_can - Check user permissions (stub for Phase 4)
    register_template_function('user_can', function($action, $context = null) {
        try {
            $auth = new UserAuth();
            $user = $auth->getCurrentUser();
            if (!$user) {
                return false;
            }
            
            $permissions = new UserPermissions();
            return $permissions->userCan($user['id'], $action, $context);
        } catch (Exception $e) {
            error_log('Template function user_can error: ' . $e->getMessage());
            return false;
        }
    }, [
        'description' => 'Check if current user can perform an action',
        'arguments' => [
            ['name' => 'action', 'type' => 'string', 'required' => true],
            ['name' => 'context', 'type' => 'string', 'required' => false]
        ]
    ]);
    
    // user_tier - Get user tier (stub for Phase 6)
    register_template_function('user_tier', function() {
        try {
            $auth = new UserAuth();
            $user = $auth->getCurrentUser();
            if (!$user) {
                return null;
            }
            
            $tiers = new UserTiers();
            return $tiers->getUserTier($user['id']);
        } catch (Exception $e) {
            error_log('Template function user_tier error: ' . $e->getMessage());
            return null;
        }
    }, [
        'description' => 'Get current user tier',
        'arguments' => []
    ]);
    
    // user_in_field - Check if current user is in a user fieldtype field
    register_template_function('user_in_field', function($fieldValue) {
        try {
            $auth = new UserAuth();
            $currentUser = $auth->getCurrentUser();
            
            if (!$currentUser) {
                return false;
            }
            
            $userId = $currentUser['id'] ?? null;
            if (!$userId) {
                return false;
            }
            
            // Handle both single and multiple values
            if (is_array($fieldValue)) {
                return in_array($userId, $fieldValue);
            }
            
            return $fieldValue === $userId;
        } catch (Exception $e) {
            error_log('Template function user_in_field error: ' . $e->getMessage());
            return false;
        }
    }, [
        'description' => 'Check if current user is in a user fieldtype field',
        'arguments' => ['field_value']
    ]);
    
    // user_field - Get user data from user fieldtype value(s)
    register_template_function('user_field', function($userIds) {
        try {
            if (empty($userIds)) {
                return [];
            }
            
            $service = new UserService();
            $ids = is_array($userIds) ? $userIds : [$userIds];
            $users = [];
            
            foreach ($ids as $id) {
                if (empty($id)) continue;
                
                $user = $service->getUser($id);
                if ($user) {
                    // Remove sensitive data
                    unset($user['password_hash']);
                    $users[] = $user;
                }
            }
            
            // Return single user if single ID provided, array if multiple
            return is_array($userIds) ? $users : ($users[0] ?? null);
        } catch (Exception $e) {
            error_log('Template function user_field error: ' . $e->getMessage());
            return is_array($userIds) ? [] : null;
        }
    }, [
        'description' => 'Get user data from user fieldtype value(s)',
        'arguments' => ['user_ids']
    ]);

    // user_profile - Get profile entry from a configured profile collection
    // Usage: { user_profile "user_id" } or { user_profile } for current user.
    // On demo-website we never fall back to current user when user_id is empty (avoids showing CMS admin).
    register_template_function('user_profile', function($user_id = null) {
        try {
            $auth = new UserAuth('site');
            $me = $auth->getCurrentUser();
            $uid = $user_id ? (string)$user_id : (string)($me['id'] ?? '');
            if ($uid === '') return null;
            // Demo-website: only return profile for demo users when in demo context
            if (user_management_is_demo_website_context() && !user_management_is_demo_user($me) && $uid === (string)($me['id'] ?? '')) {
                return null;
            }
            // Resolve target user when uid is set (for demo check and for auto-create)
            $targetUser = null;
            if ($uid !== '') {
                $svc = new UserService();
                $targetUser = $svc->getUser($uid);
            }
            // Demo-website: only allow profile for demo users; block when we know target is not demo
            if (user_management_is_demo_website_context() && $targetUser && strpos($targetUser['email'] ?? '', '@demo.social') === false) {
                return null;
            }

            // Respect admin toggle: if collection profiles are disabled, don't expose profile entries.
            $enabled = function_exists('get_plugin_setting')
                ? (bool)get_plugin_setting('user_management', 'profile_collection_enabled', false)
                : false;
            $collection = function_exists('get_plugin_setting')
                ? (string)get_plugin_setting('user_management', 'profile_collection_slug', '')
                : '';
            // Use social_profiles for demo users when profile collection is not configured
            // (works even when Referer is missing, so profile page always loads for Alice/Bob/Carol)
            $isDemoUser = $targetUser && strpos($targetUser['email'] ?? '', '@demo.social') !== false;
            if ($isDemoUser && (!$enabled || $collection === '')) {
                $enabled = true;
                $collection = 'social_profiles';
            }
            if (!$enabled || $collection === '') return null;

            $profiles = new ProfileService();
            $profile = $profiles->getProfileByUserId($collection, $uid);

            // Auto-create for the requested user when enabled.
            // This keeps the site experience smooth and stays generic (collection is configurable).
            if (!$profile) {
                $auto = function_exists('get_plugin_setting')
                    ? (bool)get_plugin_setting('user_management', 'auto_create_profiles', true)
                    : true;
                if ($auto) {
                    // For self, use session snapshot; otherwise use already-loaded target user.
                    if ($me && ($me['id'] ?? '') === $uid) {
                        $profile = $profiles->ensureProfileForUser($collection, $me);
                    } elseif ($targetUser) {
                        $profile = $profiles->ensureProfileForUser($collection, $targetUser);
                    } else {
                        $svc = new UserService();
                        $target = $svc->getUser($uid);
                        if ($target) {
                            $profile = $profiles->ensureProfileForUser($collection, $target);
                        }
                    }
                }
            }

            return $profile;
        } catch (Exception $e) {
            error_log('Template function user_profile error: ' . $e->getMessage());
            return null;
        }
    }, [
        'description' => 'Get profile entry from a configured profile collection',
        'arguments' => [
            ['name' => 'user_id', 'type' => 'string', 'required' => false]
        ]
    ]);

    // user_is_self - Check if a user_id is the current logged-in user
    // Usage: {if user_is_self "user_..." } ... {endif}
    register_template_function('user_is_self', function($user_id) {
        try {
            $auth = new UserAuth('site');
            $me = $auth->getCurrentUser();
            if (!$me || empty($me['id'])) return false;
            return (string)$me['id'] === (string)$user_id;
        } catch (Exception $e) {
            return false;
        }
    }, [
        'description' => 'Check if a user_id matches the current logged-in user',
        'arguments' => [
            ['name' => 'user_id', 'type' => 'string', 'required' => true]
        ]
    ]);

    // user_is_following — directed follow edge (active)
    register_template_function('user_is_following', function($from_user_id, $to_user_id) {
        try {
            require_once __DIR__ . '/includes/UserGraphService.php';
            $graph = new UserGraphService();
            return $graph->isFollowing((string) $from_user_id, (string) $to_user_id);
        } catch (Exception $e) {
            error_log('Template function user_is_following error: ' . $e->getMessage());
            return false;
        }
    }, [
        'description' => 'Check if one user follows another',
        'arguments' => [
            ['name' => 'from_user_id', 'type' => 'string', 'required' => true],
            ['name' => 'to_user_id', 'type' => 'string', 'required' => true],
        ],
    ]);

    // user_is_friend — mutual friend or active connection
    register_template_function('user_is_friend', function($user_a, $user_b) {
        try {
            require_once __DIR__ . '/includes/UserGraphService.php';
            $graph = new UserGraphService();
            return $graph->isFriend((string) $user_a, (string) $user_b);
        } catch (Exception $e) {
            error_log('Template function user_is_friend error: ' . $e->getMessage());
            return false;
        }
    }, [
        'description' => 'Check if two users are friends',
        'arguments' => [
            ['name' => 'user_a', 'type' => 'string', 'required' => true],
            ['name' => 'user_b', 'type' => 'string', 'required' => true],
        ],
    ]);

    // user_is_blocked — block edge from first user to second
    register_template_function('user_is_blocked', function($from_user_id, $to_user_id) {
        try {
            require_once __DIR__ . '/includes/UserGraphService.php';
            $graph = new UserGraphService();
            return $graph->isBlocked((string) $from_user_id, (string) $to_user_id);
        } catch (Exception $e) {
            error_log('Template function user_is_blocked error: ' . $e->getMessage());
            return false;
        }
    }, [
        'description' => 'Check if one user has blocked another',
        'arguments' => [
            ['name' => 'from_user_id', 'type' => 'string', 'required' => true],
            ['name' => 'to_user_id', 'type' => 'string', 'required' => true],
        ],
    ]);

    // user_graph_follows — user IDs this account follows (active)
    register_template_function('user_graph_follows', function($user_id) {
        try {
            require_once __DIR__ . '/includes/UserGraphService.php';
            $graph = new UserGraphService();
            return $graph->listFollowing((string) $user_id);
        } catch (Exception $e) {
            error_log('Template function user_graph_follows error: ' . $e->getMessage());
            return [];
        }
    }, [
        'description' => 'List user IDs that a user follows',
        'arguments' => [
            ['name' => 'user_id', 'type' => 'string', 'required' => true],
        ],
    ]);

    // user_graph_followers — user IDs following this account (active)
    register_template_function('user_graph_followers', function($user_id) {
        try {
            require_once __DIR__ . '/includes/UserGraphService.php';
            $graph = new UserGraphService();
            return $graph->listFollowers((string) $user_id);
        } catch (Exception $e) {
            error_log('Template function user_graph_followers error: ' . $e->getMessage());
            return [];
        }
    }, [
        'description' => 'List user IDs that follow a user',
        'arguments' => [
            ['name' => 'user_id', 'type' => 'string', 'required' => true],
        ],
    ]);

    // user_graph_connected — mutual connection user IDs
    register_template_function('user_graph_connected', function($user_id) {
        try {
            require_once __DIR__ . '/includes/UserGraphService.php';
            $graph = new UserGraphService();
            return $graph->listConnected((string) $user_id);
        } catch (Exception $e) {
            error_log('Template function user_graph_connected error: ' . $e->getMessage());
            return [];
        }
    }, [
        'description' => 'List user IDs connected to a user (mutual connection)',
        'arguments' => [
            ['name' => 'user_id', 'type' => 'string', 'required' => true],
        ],
    ]);

    // user_is_connected — active mutual connection
    register_template_function('user_is_connected', function($user_a, $user_b) {
        try {
            require_once __DIR__ . '/includes/UserGraphService.php';
            $graph = new UserGraphService();
            return $graph->isConnected((string) $user_a, (string) $user_b);
        } catch (Exception $e) {
            error_log('Template function user_is_connected error: ' . $e->getMessage());
            return false;
        }
    }, [
        'description' => 'Check if two users are connected (mutual)',
        'arguments' => [
            ['name' => 'user_a', 'type' => 'string', 'required' => true],
            ['name' => 'user_b', 'type' => 'string', 'required' => true],
        ],
    ]);

    // user_can_view — delegates to EntryPermissions for visibility rules
    register_template_function('user_can_view', function($entry) {
        try {
            if (!is_array($entry)) {
                return false;
            }
            require_once __DIR__ . '/includes/EntryPermissions.php';
            $auth = new UserAuth('site');
            $me = $auth->getCurrentUser();
            $userId = is_array($me) ? ($me['id'] ?? null) : null;
            $permissions = new EntryPermissions();
            return $permissions->canViewEntry($userId, $entry);
        } catch (Exception $e) {
            error_log('Template function user_can_view error: ' . $e->getMessage());
            return false;
        }
    }, [
        'description' => 'Check if the current user can view an entry',
        'arguments' => [
            ['name' => 'entry', 'type' => 'array', 'required' => true],
        ],
    ]);

    // user_list - List active users (site scope). On demo-website, only demo users (*@demo.social).
    register_template_function('user_list', function() {
        try {
            $svc = new UserService();
            $users = $svc->listUsers(['status' => 'active']);
            $out = [];
            $demoOnly = user_management_is_demo_website_context();
            foreach ($users as $u) {
                if (!is_array($u)) continue;
                if ($demoOnly && strpos($u['email'] ?? '', '@demo.social') === false) {
                    continue;
                }
                $out[] = [
                    'id' => $u['id'] ?? '',
                    'name' => $u['name'] ?? ($u['username'] ?? ($u['email'] ?? '')),
                    'email' => $u['email'] ?? ''
                ];
            }
            return $out;
        } catch (Exception $e) {
            return [];
        }
    }, [
        'description' => 'List active users (id, name, email)',
        'arguments' => []
    ]);

    register_template_function('user_notifications', function ($limit = 40, $unreadOnly = false) {
        try {
            require_once __DIR__ . '/includes/UserNotificationService.php';
            $auth = new UserAuth('site');
            $user = $auth->getCurrentUser();
            if (!$user || empty($user['id'])) {
                return [];
            }
            $service = new UserNotificationService();
            $items = $service->listForUser((string) $user['id'], (int) $limit);
            if ($unreadOnly === true || $unreadOnly === '1' || $unreadOnly === 1 || $unreadOnly === 'true') {
                $items = array_values(array_filter($items, static fn ($row) => is_array($row) && empty($row['read_at'])));
            }

            return $items;
        } catch (Exception $e) {
            error_log('Template function user_notifications error: ' . $e->getMessage());
            return [];
        }
    }, [
        'description' => 'List in-app notifications for the current user',
        'arguments' => [
            ['name' => 'limit', 'type' => 'integer', 'required' => false],
            ['name' => 'unread_only', 'type' => 'boolean', 'required' => false],
        ],
    ]);

    register_template_function('user_notification_unread_count', function () {
        try {
            require_once __DIR__ . '/includes/UserNotificationService.php';
            $auth = new UserAuth('site');
            $user = $auth->getCurrentUser();
            if (!$user || empty($user['id'])) {
                return 0;
            }

            return (new UserNotificationService())->unreadCount((string) $user['id']);
        } catch (Exception $e) {
            error_log('Template function user_notification_unread_count error: ' . $e->getMessage());
            return 0;
        }
    }, [
        'description' => 'Unread in-app notification count for the current user',
        'arguments' => [],
    ]);

    register_template_function('render_mentions', function ($text, $profileUrlPrefix = null) {
        try {
            if (!is_string($text) || trim($text) === '') {
                return '';
            }
            require_once __DIR__ . '/includes/ClubMentionParser.php';
            $prefix = is_string($profileUrlPrefix) && $profileUrlPrefix !== ''
                ? $profileUrlPrefix
                : '/club/member.html?slug=';

            return (new ClubMentionParser())->renderMentionsHtml($text, $prefix);
        } catch (Exception $e) {
            error_log('Template function render_mentions error: ' . $e->getMessage());
            return htmlspecialchars((string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
    }, [
        'description' => 'Render @mentions in text as profile links (SSR-safe HTML)',
        'arguments' => [
            ['name' => 'text', 'type' => 'string', 'required' => true],
            ['name' => 'profile_url_prefix', 'type' => 'string', 'required' => false],
        ],
    ]);
}

// Register API endpoints (stubs for Phase 1, will be fully implemented in Phase 2-3)
if (function_exists('register_api_endpoint')) {
    // Authentication API (Phase 2)
    register_api_endpoint('user_auth', __DIR__ . '/api/user_auth.php');
    
    // Registration API (Phase 3)
    register_api_endpoint('user_registration', __DIR__ . '/api/user_registration.php');

    register_api_endpoint('user_graph', __DIR__ . '/api/user_graph.php');
    register_api_endpoint('user_graph_admin', __DIR__ . '/api/user_graph_admin.php');
    
    // Admin API (Phase 5)
    register_api_endpoint('user_admin', __DIR__ . '/api/user_admin.php');
    
    // Tiers API (Phase 6)
    register_api_endpoint('user_tiers', __DIR__ . '/api/user_tiers.php');
    register_api_endpoint('user_fieldtype_profiles', __DIR__ . '/api/user_fieldtype_profiles.php');
    register_api_endpoint('user_members', __DIR__ . '/api/user_members.php');
    register_api_endpoint('user_member_signup', __DIR__ . '/api/user_member_signup.php');
    
    // Groups API (Phase 7)
    register_api_endpoint('user_groups', __DIR__ . '/api/user_groups.php');
    
    // Settings API
    register_api_endpoint('user_settings', __DIR__ . '/api/user_settings.php');
    
    // Collection Permissions API
    register_api_endpoint('collection_permissions', __DIR__ . '/api/collection_permissions.php');
    
    // User Verification API
    register_api_endpoint('user_verification', __DIR__ . '/api/user_verification.php');
    
    // User 2FA API
    register_api_endpoint('user_2fa', __DIR__ . '/api/user_2fa.php');
    
    // Password Reset API
    register_api_endpoint('password_reset', __DIR__ . '/api/password_reset.php');

    // Account activation API (membership / post-purchase)
    register_api_endpoint('user_activation', __DIR__ . '/api/user_activation.php');

    // Email templates (admin)
    register_api_endpoint('user_emails', __DIR__ . '/api/user_emails.php');

    // Signup field schema (admin + public)
    register_api_endpoint('user_signup_fields', __DIR__ . '/api/user_signup_fields.php');

    // Signup flows (admin + public)
    register_api_endpoint('user_signup', __DIR__ . '/api/user_signup.php');

    // Membership products + lifecycle settings (admin)
    register_api_endpoint('user_membership', __DIR__ . '/api/user_membership.php');

    // Site user account + user notifications (storefront)
    register_api_endpoint('user_account', __DIR__ . '/api/user_account.php');
    register_api_endpoint('user_notifications', __DIR__ . '/api/user_notifications.php');
    register_api_endpoint('club_notifications', __DIR__ . '/api/club_notifications.php');
    register_api_endpoint('club_reports', __DIR__ . '/api/club_reports.php');
    register_api_endpoint('club_deals', __DIR__ . '/api/club_deals.php');
    register_api_endpoint('club_wishes', __DIR__ . '/api/club_wishes.php');
}

if (function_exists('register_public_route')) {
    $userPublicPages = [
        '/activate-account' => 'activate-account.php',
        '/reset-password' => 'reset-password.php',
        '/verify-email' => 'verify-email.php',
    ];
    foreach ($userPublicPages as $prefix => $file) {
        register_public_route($prefix, function (string $uri) use ($file, $prefix): bool {
            if ($uri !== $prefix && !str_starts_with($uri, $prefix . '/')) {
                return false;
            }
            $path = __DIR__ . '/' . $file;
            if (!is_file($path)) {
                return false;
            }
            require $path;
            return true;
        }, ['plugin_id' => 'user_management', 'priority' => 50]);
    }
}

// Register admin pages (Phase 5)
if (function_exists('register_admin_page')) {
    register_admin_page('site_users', __DIR__ . '/admin/site_users.html');
    register_admin_page('user_tiers', __DIR__ . '/admin/tiers.html');
    register_admin_page('user_groups', __DIR__ . '/admin/groups.html');
}

if (function_exists('register_plugin_admin_meta')) {
    register_plugin_admin_meta('user_management', [
        'title' => 'User',
        'root_page' => 'site_users',
        'permission' => 'manage_users',
        'page_slugs' => ['site_users', 'user_tiers', 'user_groups'],
        'sub_pages' => [
            'user_tiers' => ['title' => 'Tiers', 'permission' => 'manage_users'],
            'user_groups' => ['title' => 'Groups', 'permission' => 'manage_users'],
        ],
        'sidebar' => [
            'show' => true,
            'label' => 'User',
            'order' => 35,
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>',
        ],
    ]);
}

// Hook into collection system for permissions (Phase 4)
if (function_exists('register_hook')) {
    require_once __DIR__ . '/includes/UserAuth.php';
    require_once __DIR__ . '/includes/UserPermissions.php';
    require_once __DIR__ . '/includes/EntryPermissions.php';

    if (!function_exists('user_management_is_cms_admin_request')) {
        function user_management_is_cms_admin_request() {
            if (!isset($_SESSION['user']) || !is_array($_SESSION['user'])) {
                return false;
            }
            if (function_exists('checkPermission')) {
                $user = $_SESSION['user'];
                return checkPermission($user, 'write')
                    || checkPermission($user, 'delete')
                    || checkPermission($user, 'manage_content');
            }
            $role = $_SESSION['user']['role'] ?? '';
            return in_array($role, ['admin', 'editor', 'author'], true);
        }
    }

    if (!function_exists('user_management_guard_entry_create')) {
        function user_management_guard_entry_create($collection, $entry) {
            if (user_management_is_cms_admin_request()) {
                return $entry;
            }

            $auth = new UserAuth();
            $user = $auth->getCurrentUser();
            if (!$user) {
                throw new Exception('Authentication required to create entries');
            }

            $permissions = new UserPermissions();
            if (!$permissions->userCan($user['id'], 'create', $collection)) {
                throw new Exception('Permission denied: Cannot create entries in this collection');
            }

            if (!isset($entry['author_id']) && !isset($entry['author_user_id'])) {
                $entry['author_id'] = $user['id'];
            }

            return $entry;
        }
    }

    if (!function_exists('user_management_guard_entry_delete')) {
        function user_management_guard_entry_delete($collection, $entry_id, $entry = null) {
            if (user_management_is_cms_admin_request()) {
                return true;
            }

            $auth = new UserAuth();
            $user = $auth->getCurrentUser();
            if (!$user) {
                throw new Exception('Authentication required to delete entries');
            }

            if ($entry === null && function_exists('get_entry')) {
                $entry = get_entry($collection, $entry_id);
            }
            if (!is_array($entry) && is_string($entry_id)) {
                $entryPath = dirname(dirname(__DIR__)) . "/content/collections/$collection/entries/$entry_id.json";
                if (file_exists($entryPath)) {
                    $entry = json_decode(file_get_contents($entryPath), true);
                }
            }

            $entryPermissions = new EntryPermissions();
            if (!is_array($entry) || !$entryPermissions->canDeleteEntry($user['id'], $entry, $collection)) {
                throw new Exception('Permission denied: Cannot delete this entry');
            }

            return true;
        }
    }

    register_hook('before_entry_create', function($collection, $entry) {
        return user_management_guard_entry_create($collection, $entry);
    });

    if (function_exists('add_filter')) {
        add_filter('before_entry_create', function($entry, $collection) {
            return user_management_guard_entry_create($collection, $entry);
        }, 10);

        add_filter('before_entry_create', function ($entry, $collectionSlug) {
            if (!is_array($entry) || !is_string($collectionSlug) || $collectionSlug === '') {
                return $entry;
            }
            require_once __DIR__ . '/includes/MemberSignupService.php';
            try {
                return (new MemberSignupService())->applyPublicSubmit($entry, $collectionSlug);
            } catch (Throwable $e) {
                throw new Exception($e->getMessage());
            }
        }, 20, 2);
    }
    
    register_hook('before_entry_save', function($collection, $entry) {
        $auth = new UserAuth();
        $user = $auth->getCurrentUser();
        
        if (!$user) {
            throw new Exception('Authentication required to save entries');
        }
        
        $permissions = new UserPermissions();
        
        // Check if this is a new entry or update
        $isNew = !isset($entry['id']);
        $action = $isNew ? 'create' : 'edit';
        
        // Build context for permission check
        $context = [
            'collection' => $collection,
            'entry' => $entry['id'] ?? null,
            'author_id' => $entry['author_id'] ?? null
        ];
        
        $canSave = $permissions->userCan($user['id'], $action, $context);
        
        if (!$canSave) {
            throw new Exception('Permission denied: Cannot ' . ($isNew ? 'create' : 'edit') . ' this entry');
        }
        
        return $entry;
    });
    
    register_hook('before_entry_delete', function($collection, $entry_id) {
        return user_management_guard_entry_delete($collection, $entry_id);
    });

    if (function_exists('add_filter')) {
        require_once __DIR__ . '/includes/UserPublicUgcFilter.php';

        add_filter('birkly_public_entries_filter', function ($entries, $collectionSlug, $context = null) {
            if (!is_array($entries)) {
                return $entries;
            }
            $entryPermissions = new EntryPermissions();
            $userId = $entryPermissions->getCurrentUserId();

            $entries = $entryPermissions->filterEntriesByViewPermission($userId, $entries, (string) $collectionSlug);

            return UserPublicUgcFilter::filterEntries($entries, (string) $collectionSlug, $userId);
        }, 10);

        add_filter('birkly_public_entry_filter', function ($entry, $collectionSlug, $context = null) {
            if (!is_array($entry)) {
                return $entry;
            }
            $entryPermissions = new EntryPermissions();
            $userId = $entryPermissions->getCurrentUserId();
            if (!$entryPermissions->canViewEntry($userId, $entry, (string) $collectionSlug)) {
                return null;
            }

            $filtered = UserPublicUgcFilter::filterEntries([$entry], (string) $collectionSlug, $userId);

            return $filtered[0] ?? null;
        }, 10);

        add_filter('birkly_ai_read_entry', function ($entry, $collectionSlug = '') {
            if (!is_array($entry)) {
                return $entry;
            }

            $schema = null;
            if ($collectionSlug !== '' && function_exists('birkly_entry_read_schema')) {
                $schema = birkly_entry_read_schema((string) $collectionSlug);
            }

            return user_management_scrub_entry_account_fields($entry, is_array($schema) ? $schema : null);
        }, 10, 2);
    }

    if (function_exists('register_hook')) {
        require_once __DIR__ . '/includes/UserMemberIndexer.php';

        register_hook('after_entry_save', function ($entry, $collection, $oldEntry = null) {
            if (!is_array($entry)) {
                return;
            }
            $collectionSlug = is_string($collection) ? $collection : (is_array($collection) ? (string) ($collection['slug'] ?? '') : '');
            if ($collectionSlug === '') {
                return;
            }
            $indexer = new UserMemberIndexer();
            $indexer->indexEntry($entry, $collectionSlug);
        });

        register_hook('after_entry_delete', function ($entry, $collection) {
            $entryId = is_array($entry) ? (string) ($entry['id'] ?? '') : (string) $entry;
            $collectionSlug = is_string($collection) ? $collection : (is_array($collection) ? (string) ($collection['slug'] ?? '') : '');
            if ($entryId === '' || $collectionSlug === '') {
                return;
            }
            $indexer = new UserMemberIndexer();
            $indexer->removeEntry($entryId, $collectionSlug);
        });

        require_once __DIR__ . '/includes/ClubNotificationHooks.php';
        club_notification_register_hooks();
        require_once __DIR__ . '/includes/ClubMentionHooks.php';
        club_mention_register_hooks();
        require_once __DIR__ . '/includes/ClubAutomationHooks.php';
        club_automation_register_hooks();
    }

    if (function_exists('add_filter')) {
        add_filter('before_entry_save', function ($entry, $collection) {
            if ($collection !== 'club-wishes' || !is_array($entry)) {
                return $entry;
            }
            require_once __DIR__ . '/includes/ClubWishService.php';
            $service = new ClubWishService();
            $isNew = empty($entry['id']) && empty($entry['created_at']);

            return $service->sanitizeWishEntry($entry, $isNew);
        }, 12);
    }
    
    // Auto-create user from profile entry when entry is saved
    if (function_exists('add_filter')) {
        add_filter('before_entry_save', function($entry, $collection) {
            // Only process if profile collection is enabled and this is the profile collection
            if (!function_exists('get_plugin_setting')) {
                return $entry;
            }
            
            $profileCollectionEnabled = get_plugin_setting('user_management', 'profile_collection_enabled', false);
            $profileCollectionSlug = get_plugin_setting('user_management', 'profile_collection_slug', '');
            
            if (!$profileCollectionEnabled || $profileCollectionSlug !== $collection) {
                return $entry;
            }
            
            // If entry already has user_id, sync title with user name
            if (!empty($entry['user_id'])) {
                try {
                    require_once __DIR__ . '/includes/UserService.php';
                    $userService = new UserService();
                    $user = $userService->getUser($entry['user_id']);
                    
                    if ($user) {
                        $userName = $user['name'] ?? $user['username'] ?? '';
                        if (!empty($userName)) {
                            $entry['title'] = $userName;
                        }
                    }
                } catch (Exception $e) {
                    error_log("Failed to sync title from user: " . $e->getMessage());
                }
                
                return $entry;
            }
            
            // Check if a user with this email already exists (prevent duplicates)
            $email = trim($entry['email'] ?? '');
            if (empty($email)) {
                error_log("Profile entry missing email (required field), cannot auto-create user");
                return $entry;
            }
            
            try {
                require_once __DIR__ . '/includes/UserService.php';
                require_once __DIR__ . '/includes/ProfileService.php';
                $userService = new UserService();
                $profileService = new ProfileService();
                
                // Check if email already exists
                $existingUser = $userService->getUserByEmail($email);
                if ($existingUser) {
                    // User already exists - link the profile entry to existing user
                    $entry['user_id'] = $existingUser['id'];
                    error_log("Linked profile entry to existing user {$existingUser['id']} ({$email})");
                    return $entry;
                }
                
                // Also check if another profile entry with this email already exists (without user_id)
                // This prevents creating duplicate users when the same entry is saved multiple times
                $entryId = $entry['id'] ?? '';
                // Use Storage class directly (ProfileService uses it internally)
                require_once __DIR__ . '/../../api/storage.php';
                $rootDir = dirname(dirname(__DIR__)); // Go from plugins/user_management/ to root
                $storage = new Storage($rootDir . '/content');
                $allProfiles = $storage->query($profileCollectionSlug, [], []);
                foreach ($allProfiles as $profile) {
                    // Skip the current entry
                    if (isset($profile['id']) && $profile['id'] === $entryId) {
                        continue;
                    }
                    // If another profile has this email and no user_id, don't create a duplicate user
                    if (isset($profile['email']) && $profile['email'] === $email && empty($profile['user_id'])) {
                        error_log("Another profile entry with email {$email} already exists, skipping user creation to prevent duplicate");
                        return $entry;
                    }
                }
                
                // Extract user data from entry
                $name = trim($entry['name'] ?? $entry['title'] ?? '');
                if (empty($name)) {
                    error_log("Profile entry missing name/title, cannot auto-create user");
                    return $entry;
                }
                
                // Get password from entry (required field)
                $password = trim($entry['password'] ?? '');
                if (empty($password)) {
                    error_log("Profile entry missing password (required field), cannot auto-create user");
                    return $entry;
                }
                
                // Determine user status based on entry status and auto-approve setting
                $entryStatus = $entry['status'] ?? 'pending';
                $autoApprove = get_plugin_setting('user_management', 'auto_approve_users', false);
                
                // Map entry status to user status/approved
                // published = approved + active, unpublished = not approved + inactive, pending = not approved + pending
                $userStatus = 'pending';
                $userApproved = false;
                if ($entryStatus === 'published') {
                    $userStatus = 'active';
                    $userApproved = true;
                } elseif ($entryStatus === 'unpublished') {
                    $userStatus = 'inactive';
                    $userApproved = false;
                } else { // pending or other
                    $userStatus = 'pending';
                    $userApproved = false;
                }
                
                // If auto-approve is enabled, override to approved + active
                if ($autoApprove) {
                    $userStatus = 'active';
                    $userApproved = true;
                    // Also set entry status to published if it was pending
                    if ($entryStatus === 'pending') {
                        $entry['status'] = 'published';
                    }
                }
                
                // Create user account
                // Set flag to skip profile creation (since profile entry already exists)
                $userData = [
                    'email' => $email,
                    'password' => $password,
                    'name' => $name,
                    'username' => $name,
                    'status' => $userStatus,
                    'verified' => true,
                    'approved' => $userApproved,
                    'tier' => get_plugin_setting('user_management', 'default_tier', 'all'),
                    '_skip_profile_creation' => true // Prevent circular dependency
                ];
                
                $newUser = $userService->createUser($userData);
                
                // Link profile entry to the created user
                $entry['user_id'] = $newUser['id'];
                
                // Sync title with username/name
                $entry['title'] = $name;
                
                // Remove password from entry (it's only used for user creation, not stored in profile)
                unset($entry['password']);
                
                error_log("Auto-created user {$newUser['id']} ({$email}) from profile entry in collection {$collection} with status: {$userStatus}, approved: " . ($userApproved ? 'yes' : 'no'));
            } catch (Exception $e) {
                error_log("Failed to auto-create user from profile entry: " . $e->getMessage());
                // Don't fail entry save if user creation fails - just log it
                // The entry will be saved without user_id, which can be fixed later
            }
            
            return $entry;
        }, 5); // Priority 5 (higher priority, runs early)
        
        // Sync entry status to user status when entry is saved (after save)
        if (function_exists('register_hook')) {
            register_hook('after_entry_save', function($entry, $collection, $oldEntry = null) {
            // Only process if profile collection is enabled and this is the profile collection
            if (!function_exists('get_plugin_setting')) {
                return;
            }
            
            $profileCollectionEnabled = get_plugin_setting('user_management', 'profile_collection_enabled', false);
            $profileCollectionSlug = get_plugin_setting('user_management', 'profile_collection_slug', '');
            
            if (!$profileCollectionEnabled || $profileCollectionSlug !== $collection) {
                return;
            }
            
            // Only sync if entry has a user_id
            $userId = $entry['user_id'] ?? '';
            if (empty($userId)) {
                return;
            }
            
            try {
                require_once __DIR__ . '/includes/UserService.php';
                $userService = new UserService();
                $user = $userService->getUser($userId);
                
                if (!$user) {
                    return; // User doesn't exist
                }
                
                // Sync title with username/name
                $userName = $user['name'] ?? $user['username'] ?? '';
                if (!empty($userName) && ($entry['title'] ?? '') !== $userName) {
                    // Update entry title to match user name
                    require_once __DIR__ . '/../../api/storage.php';
                    $rootDir = dirname(dirname(__DIR__));
                    $storage = new Storage($rootDir . '/content');
                    $entryId = $entry['id'] ?? '';
                    if (!empty($entryId)) {
                        $entryPath = "collections/{$profileCollectionSlug}/entries/{$entryId}.json";
                        $currentEntry = $storage->read($entryPath);
                        if ($currentEntry) {
                            $currentEntry['title'] = $userName;
                            $storage->write($entryPath, $currentEntry);
                        }
                    }
                }
                
                // Map entry status to user status/approved
                $entryStatus = $entry['status'] ?? 'pending';
                $userStatus = 'pending';
                $userApproved = false;
                
                if ($entryStatus === 'published') {
                    $userStatus = 'active';
                    $userApproved = true;
                } elseif ($entryStatus === 'unpublished') {
                    $userStatus = 'inactive';
                    $userApproved = false;
                } else { // pending or other
                    $userStatus = 'pending';
                    $userApproved = false;
                }
                
                // Only update if status changed
                $statusChanged = ($user['status'] ?? '') !== $userStatus;
                $approvedChanged = ($user['approved'] ?? false) !== $userApproved;
                
                if ($statusChanged || $approvedChanged) {
                    $updateData = [];
                    if ($statusChanged) {
                        $updateData['status'] = $userStatus;
                    }
                    if ($approvedChanged) {
                        $updateData['approved'] = $userApproved;
                    }
                    
                    $userService->updateUser($userId, $updateData);
                    error_log("Synced entry status '{$entryStatus}' to user {$userId}: status={$userStatus}, approved=" . ($userApproved ? 'yes' : 'no'));
                }
                
                // Also sync name if changed
                $entryName = trim($entry['name'] ?? '');
                $userName = trim($user['name'] ?? '');
                if (!empty($entryName) && $entryName !== $userName) {
                    $userService->updateUser($userId, ['name' => $entryName, 'username' => $entryName]);
                    error_log("Synced entry name '{$entryName}' to user {$userId}");
                }
            } catch (Exception $e) {
                error_log("Failed to sync entry status to user: " . $e->getMessage());
            }
            }, 10);
        }
        
        // Sync user status to entry status when user is updated
        if (function_exists('register_hook')) {
            register_hook('after_user_update', function($user) {
            // Only process if profile collection is enabled
            if (!function_exists('get_plugin_setting')) {
                return;
            }
            
            $profileCollectionEnabled = get_plugin_setting('user_management', 'profile_collection_enabled', false);
            $profileCollectionSlug = get_plugin_setting('user_management', 'profile_collection_slug', '');
            
            if (!$profileCollectionEnabled || empty($profileCollectionSlug)) {
                return;
            }
            
            $userId = $user['id'] ?? '';
            if (empty($userId)) {
                return;
            }
            
            try {
                require_once __DIR__ . '/includes/ProfileService.php';
                $profileService = new ProfileService();
                $profile = $profileService->getProfileByUserId($profileCollectionSlug, $userId);
                
                if (!$profile) {
                    return; // Profile entry doesn't exist
                }
                
                // Map user status/approved to entry status
                $userStatus = $user['status'] ?? 'pending';
                $userApproved = $user['approved'] ?? false;
                $entryStatus = 'pending';
                
                if ($userApproved && $userStatus === 'active') {
                    $entryStatus = 'published';
                } elseif ($userStatus === 'inactive') {
                    $entryStatus = 'unpublished';
                } else {
                    $entryStatus = 'pending';
                }
                
                // Only update if status changed
                $currentStatus = $profile['status'] ?? 'pending';
                if ($currentStatus !== $entryStatus) {
                    $profile['status'] = $entryStatus;
                    $profileService->saveProfile($profileCollectionSlug, $profile);
                    error_log("Synced user status '{$userStatus}' (approved: " . ($userApproved ? 'yes' : 'no') . ") to entry {$profile['id']}: status={$entryStatus}");
                }
                
                // Also sync name if changed
                $userName = trim($user['name'] ?? '');
                $profileName = trim($profile['name'] ?? '');
                if (!empty($userName) && $userName !== $profileName) {
                    $profile['name'] = $userName;
                    $profileService->saveProfile($profileCollectionSlug, $profile);
                    error_log("Synced user name '{$userName}' to entry {$profile['id']}");
                }
            } catch (Exception $e) {
                error_log("Failed to sync user status to entry: " . $e->getMessage());
            }
            }, 10);

            register_hook('after_user_delete', function ($user) {
                $userId = (string) ($user['id'] ?? '');
                if ($userId === '') {
                    return;
                }

                try {
                    require_once __DIR__ . '/includes/UserGraphService.php';
                    (new UserGraphService())->purgeUser($userId);
                } catch (Throwable $e) {
                    error_log('P76 graph purge on user delete: ' . $e->getMessage());
                }

                if (!function_exists('get_plugin_setting')) {
                    return;
                }

                $profileCollectionEnabled = get_plugin_setting('user_management', 'profile_collection_enabled', false);
                $profileCollectionSlug = get_plugin_setting('user_management', 'profile_collection_slug', '');
                if (!$profileCollectionEnabled || $profileCollectionSlug === '') {
                    return;
                }

                try {
                    require_once __DIR__ . '/includes/ProfileService.php';
                    (new ProfileService())->deleteProfileForUser($profileCollectionSlug, $userId);
                } catch (Throwable $e) {
                    error_log('P76 profile delete on user delete: ' . $e->getMessage());
                }
            }, 10);
        }
    }
}

if (function_exists('birkly_webmcp_register_tools')) {
    require_once __DIR__ . '/includes/webmcp_tools.php';
    birkly_webmcp_register_tools('user_management', user_management_webmcp_tool_catalog());
}

if (function_exists('birkly_webmcp_register_runtime_pack')) {
    require_once __DIR__ . '/includes/webmcp_runtime.php';
}

require __DIR__ . '/docs/register_docs.php';

/**
 * Seed tier permissions for club collections (idempotent; always enforces club defaults).
 */
/**
 * Ensure roadmap-features has a likes sub-collection for vote entries.
 */
/**
 * Ensure club-posts has a comments sub-collection (best practice vs standalone club-comments).
 */
function user_management_ensure_club_posts_comments_subcollection(): void
{
    $collectionPath = __DIR__ . '/../../../content/collections/club-posts/collection.json';
    if (!is_file($collectionPath)) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $subCollections = $config['sub_collections'] ?? [];
    if (!is_array($subCollections)) {
        $subCollections = [];
    }

    foreach ($subCollections as $sub) {
        if (is_array($sub) && ($sub['slug'] ?? '') === 'comments') {
            return;
        }
    }

    $subCollections[] = [
        'slug' => 'comments',
        'name' => 'Comments',
        'entry_method' => 'public_api',
        'auto_publish' => true,
        'fields' => user_management_p75_comment_subcollection_fields(),
    ];

    $config['sub_collections'] = $subCollections;
    $config['updated_at'] = date('c');
    file_put_contents($collectionPath, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
}

function user_management_ensure_roadmap_likes_subcollection(): void
{
    $collectionPath = __DIR__ . '/../../../content/collections/roadmap-features/collection.json';
    if (!is_file($collectionPath)) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $subCollections = $config['sub_collections'] ?? [];
    if (!is_array($subCollections)) {
        $subCollections = [];
    }

    foreach ($subCollections as $sub) {
        if (is_array($sub) && ($sub['slug'] ?? '') === 'likes') {
            return;
        }
    }

    $subCollections[] = [
        'slug' => 'likes',
        'name' => 'Votes',
        'entry_method' => 'public_api',
        'auto_publish' => true,
        'fields' => user_management_p75_likes_subcollection_fields(),
    ];

    $config['sub_collections'] = $subCollections;
    $config['updated_at'] = date('c');
    file_put_contents($collectionPath, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
}

function user_management_p75_likes_subcollection_fields(): array
{
    return [
        ['name' => 'title', 'type' => 'text', 'label' => 'Title'],
        [
            'name' => 'owner',
            'type' => 'user',
            'label' => 'Owner',
            'ownership' => true,
            'required' => true,
            'public_visible' => false,
        ],
    ];
}

function user_management_p75_comment_subcollection_fields(): array
{
    return [
        ['name' => 'body', 'type' => 'textarea', 'label' => 'Comment', 'required' => true],
        [
            'name' => 'owner',
            'type' => 'user',
            'label' => 'Owner',
            'ownership' => true,
            'required' => true,
            'public_visible' => false,
        ],
    ];
}

function user_management_ensure_likes_subcollection(string $collectionSlug, string $entryMethod = 'public_api'): void
{
    $collectionPath = __DIR__ . '/../../../content/collections/' . $collectionSlug . '/collection.json';
    if (!is_file($collectionPath)) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $subCollections = $config['sub_collections'] ?? [];
    if (!is_array($subCollections)) {
        $subCollections = [];
    }

    $likesFields = user_management_p75_likes_subcollection_fields();
    $updated = false;
    foreach ($subCollections as $index => $sub) {
        if (!is_array($sub) || ($sub['slug'] ?? '') !== 'likes') {
            continue;
        }
        $subCollections[$index]['name'] = 'Likes';
        $subCollections[$index]['entry_method'] = $entryMethod;
        $subCollections[$index]['auto_publish'] = true;
        $subCollections[$index]['fields'] = $likesFields;
        $updated = true;
        break;
    }

    if (!$updated) {
        $subCollections[] = [
            'slug' => 'likes',
            'name' => 'Likes',
            'entry_method' => $entryMethod,
            'auto_publish' => true,
            'fields' => $likesFields,
        ];
        $updated = true;
    }

    if (!$updated) {
        return;
    }

    $config['sub_collections'] = $subCollections;
    $config['updated_at'] = date('c');
    file_put_contents($collectionPath, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
}

function user_management_ensure_club_posts_likes_subcollection(): void
{
    user_management_ensure_likes_subcollection('club-posts', 'public_api');
}

function user_management_ensure_club_wishes_likes_subcollection(): void
{
    user_management_ensure_likes_subcollection('club-wishes', 'public_api');
}

function user_management_upgrade_roadmap_likes_owner_schema(): void
{
    user_management_ensure_likes_subcollection('roadmap-features', 'public_api');
}

function user_management_upgrade_club_posts_comments_owner_schema(): void
{
    user_management_ensure_club_posts_subcollection_schemas();
}

/**
 * Idempotent repair for club-posts sub-collections (ownership + P81 aggregates).
 */
function user_management_ensure_club_posts_subcollection_schemas(): void
{
    $collectionPath = user_management_resolve_collection_json_path('club-posts');
    if ($collectionPath === null) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $subCollections = $config['sub_collections'] ?? [];
    if (!is_array($subCollections)) {
        $subCollections = [];
    }

    $commentFields = user_management_p75_comment_subcollection_fields();
    $likeFields = user_management_p75_likes_subcollection_fields();
    $changed = false;

    foreach ($subCollections as $index => $sub) {
        if (!is_array($sub)) {
            continue;
        }
        $slug = (string) ($sub['slug'] ?? '');
        if ($slug === 'comments') {
            $subCollections[$index]['fields'] = $commentFields;
            $subCollections[$index]['entry_method'] = 'public_api';
            $subCollections[$index]['auto_publish'] = true;
            $subCollections[$index]['aggregate_on_parent'] = ['count_as' => 'comments_count'];

            $nested = $subCollections[$index]['sub_collections'] ?? [];
            if (!is_array($nested)) {
                $nested = [];
            }
            $hasReplies = false;
            foreach ($nested as $nestedIndex => $nestedSub) {
                if (!is_array($nestedSub) || ($nestedSub['slug'] ?? '') !== 'replies') {
                    continue;
                }
                $nested[$nestedIndex]['fields'] = $commentFields;
                $nested[$nestedIndex]['entry_method'] = 'public_api';
                $nested[$nestedIndex]['auto_publish'] = true;
                $hasReplies = true;
                break;
            }
            if (!$hasReplies) {
                $nested[] = [
                    'slug' => 'replies',
                    'name' => 'Replies',
                    'entry_method' => 'public_api',
                    'auto_publish' => true,
                    'fields' => $commentFields,
                ];
            }
            $subCollections[$index]['sub_collections'] = $nested;
            $changed = true;
        } elseif ($slug === 'likes') {
            $subCollections[$index]['fields'] = $likeFields;
            $subCollections[$index]['entry_method'] = 'public_api';
            $subCollections[$index]['auto_publish'] = true;
            $subCollections[$index]['aggregate_on_parent'] = ['count_as' => 'likes_count'];
            $changed = true;
        }
    }

    if (!$changed) {
        return;
    }

    $config['sub_collections'] = $subCollections;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

function user_management_ensure_club_profiles_onboarding_schema(): void
{
    $collectionPath = user_management_resolve_collection_json_path('club-profiles');
    if ($collectionPath === null) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $fields = $config['fields'] ?? [];
    if (!is_array($fields)) {
        $fields = [];
    }

    $wanted = [
        'interests' => [
            'name' => 'interests',
            'type' => 'textarea',
            'label' => 'Interests',
            'required' => false,
            'public_visible' => true,
        ],
        'onboarding_completed' => [
            'name' => 'onboarding_completed',
            'type' => 'checkbox',
            'label' => 'Onboarding completed',
            'required' => false,
            'public_visible' => false,
        ],
        'profile_completeness' => [
            'name' => 'profile_completeness',
            'type' => 'number',
            'label' => 'Profile completeness',
            'required' => false,
            'public_visible' => false,
        ],
    ];

    $names = [];
    foreach ($fields as $field) {
        if (is_array($field) && isset($field['name'])) {
            $names[(string) $field['name']] = true;
        }
    }

    $changed = false;
    foreach ($wanted as $name => $definition) {
        if (!isset($names[$name])) {
            $fields[] = $definition;
            $changed = true;
        }
    }

    if (!$changed) {
        return;
    }

    $config['fields'] = $fields;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

/**
 * Stamp user_plugin markers on UGC collections (idempotent migration; P81-M5).
 */
function user_management_ensure_user_plugin_collection_markers(): void
{
    $markers = [
        'club-posts' => [
            'ugc' => true,
            'mentions_enabled' => true,
            'notifications' => ['birkly_post', 'following_post', 'comment', 'reaction', 'mention'],
            'notification_link' => '/club.html#feed',
        ],
        'club-deals' => [
            'notifications' => ['deal'],
            'notification_link' => '/club.html#deals',
        ],
    ];

    foreach ($markers as $slug => $marker) {
        user_management_merge_user_plugin_marker((string) $slug, $marker);
    }
}

/**
 * @param array<string, mixed> $marker
 */
function user_management_merge_user_plugin_marker(string $collectionSlug, array $marker): void
{
    $collectionPath = user_management_resolve_collection_json_path($collectionSlug);
    if ($collectionPath === null) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $existing = $config['user_plugin'] ?? [];
    if (!is_array($existing)) {
        $existing = [];
    }

    $merged = array_merge($marker, $existing);
    if ($merged === ($config['user_plugin'] ?? null)) {
        return;
    }

    $config['user_plugin'] = $merged;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);

    if (class_exists('UserPluginCollectionConfig')) {
        UserPluginCollectionConfig::resetCache();
    }
}

function user_management_ensure_club_posts_mentions_schema(): void
{
    $collectionPath = user_management_resolve_collection_json_path('club-posts');
    if ($collectionPath === null) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $fields = $config['fields'] ?? [];
    if (!is_array($fields)) {
        $fields = [];
    }

    foreach ($fields as $field) {
        if (is_array($field) && ($field['name'] ?? '') === 'mentioned_user_ids') {
            return;
        }
    }

    $fields[] = [
        'name' => 'mentioned_user_ids',
        'type' => 'textarea',
        'label' => 'Mentioned user IDs',
        'required' => false,
        'public_visible' => false,
    ];
    $config['fields'] = $fields;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

function user_management_ensure_club_posts_moderation_schema(): void
{
    $collectionPath = user_management_resolve_collection_json_path('club-posts');
    if ($collectionPath === null) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $fields = $config['fields'] ?? [];
    if (!is_array($fields)) {
        $fields = [];
    }

    foreach ($fields as $field) {
        if (is_array($field) && ($field['name'] ?? '') === 'moderation_hidden') {
            return;
        }
    }

    $fields[] = [
        'name' => 'moderation_hidden',
        'type' => 'checkbox',
        'label' => 'Hidden by moderation',
        'required' => false,
        'public_visible' => false,
    ];
    $config['fields'] = $fields;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

function user_management_ensure_club_reports_collection(): void
{
    $fields = [
        ['name' => 'title', 'type' => 'text', 'label' => 'Title', 'required' => true],
        [
            'name' => 'target_collection',
            'type' => 'text',
            'label' => 'Target collection',
            'required' => true,
            'public_visible' => false,
        ],
        [
            'name' => 'target_entry_id',
            'type' => 'text',
            'label' => 'Target entry ID',
            'required' => true,
            'public_visible' => false,
        ],
        [
            'name' => 'reporter_user_id',
            'type' => 'text',
            'label' => 'Reporter user ID',
            'required' => true,
            'public_visible' => false,
        ],
        [
            'name' => 'reason',
            'type' => 'textarea',
            'label' => 'Reason',
            'required' => true,
            'public_visible' => false,
        ],
        [
            'name' => 'report_status',
            'type' => 'select',
            'label' => 'Report status',
            'required' => true,
            'options' => ['open', 'reviewed', 'dismissed'],
            'public_visible' => false,
        ],
        [
            'name' => 'owner',
            'type' => 'user',
            'label' => 'Owner',
            'ownership' => true,
            'required' => true,
            'public_visible' => false,
        ],
    ];

    $collectionPath = user_management_resolve_collection_json_path('club-reports');
    if ($collectionPath === null) {
        $baseDir = user_management_cms_path('content/collections/club-reports');
        $entriesDir = $baseDir . '/entries';
        if (!is_dir($entriesDir) && !mkdir($entriesDir, 0755, true) && !is_dir($entriesDir)) {
            error_log('User Management: could not create club-reports entries directory');
            return;
        }
        $config = [
            'slug' => 'club-reports',
            'name' => 'Club reports',
            'entry_method' => 'admin_only',
            'allow_public_read' => false,
            'fields' => $fields,
            'created_at' => date('c'),
            'updated_at' => date('c'),
        ];
        user_management_write_collection_json($baseDir . '/collection.json', $config);

        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $existingNames = [];
    $configFields = $config['fields'] ?? [];
    if (!is_array($configFields)) {
        $configFields = [];
    }
    foreach ($configFields as $field) {
        if (is_array($field) && isset($field['name'])) {
            $existingNames[(string) $field['name']] = true;
        }
    }

    $changed = false;
    foreach ($fields as $field) {
        $name = (string) ($field['name'] ?? '');
        if ($name === '' || isset($existingNames[$name])) {
            continue;
        }
        $configFields[] = $field;
        $changed = true;
    }

    if (!$changed) {
        return;
    }

    $config['fields'] = $configFields;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

function user_management_ensure_club_wishes_schema(): void
{
    $collectionPath = user_management_resolve_collection_json_path('club-wishes');
    if ($collectionPath === null) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $fields = $config['fields'] ?? [];
    if (!is_array($fields)) {
        $fields = [];
    }

    $wanted = [
        'decline_reason' => [
            'name' => 'decline_reason',
            'type' => 'textarea',
            'label' => 'Decline reason',
            'required' => false,
            'public_visible' => true,
        ],
        'roadmap_link' => [
            'name' => 'roadmap_link',
            'type' => 'text',
            'label' => 'Roadmap link slug',
            'required' => false,
            'public_visible' => true,
        ],
    ];

    $names = [];
    $changed = false;
    foreach ($fields as $index => $field) {
        if (!is_array($field) || !isset($field['name'])) {
            continue;
        }
        $name = (string) $field['name'];
        $names[$name] = $index;
        if ($name === 'status') {
            $options = [
                'pending',
                'under_review',
                'planned',
                'shipped',
                'declined',
            ];
            $current = $field['options'] ?? [];
            if (!is_array($current) || $current !== $options) {
                $fields[$index]['options'] = $options;
                $changed = true;
            }
        }
    }

    foreach ($wanted as $name => $definition) {
        if (!isset($names[$name])) {
            $fields[] = $definition;
            $changed = true;
        }
    }

    if (!$changed) {
        return;
    }

    $config['fields'] = $fields;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

function user_management_ensure_club_deals_schema(): void
{
    $collectionPath = user_management_resolve_collection_json_path('club-deals');
    if ($collectionPath === null) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $fields = $config['fields'] ?? [];
    if (!is_array($fields)) {
        $fields = [];
    }

    $wanted = [
        'copy_count' => [
            'name' => 'copy_count',
            'type' => 'number',
            'label' => 'Copy count',
            'required' => false,
            'public_visible' => false,
        ],
        'visit_count' => [
            'name' => 'visit_count',
            'type' => 'number',
            'label' => 'Visit count',
            'required' => false,
            'public_visible' => false,
        ],
    ];

    $names = [];
    foreach ($fields as $field) {
        if (is_array($field) && isset($field['name'])) {
            $names[(string) $field['name']] = true;
        }
    }

    $changed = false;
    foreach ($wanted as $name => $definition) {
        if (!isset($names[$name])) {
            $fields[] = $definition;
            $changed = true;
        }
    }

    if (!$changed) {
        return;
    }

    $config['fields'] = $fields;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

function user_management_migrate_club_wish_statuses(): void
{
    require_once __DIR__ . '/includes/ClubWishService.php';
    $service = new ClubWishService();
    require_once user_management_cms_path('api/storage.php');
    $storage = new Storage(user_management_cms_path('content'));

    foreach ($storage->list('collections') as $dir) {
        $meta = $storage->read("collections/{$dir}/collection.json");
        if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== 'club-wishes') {
            continue;
        }
        foreach ($storage->list("collections/{$dir}/entries") as $file) {
            if (!str_ends_with($file, '.json')) {
                continue;
            }
            $path = "collections/{$dir}/entries/{$file}";
            $entry = $storage->read($path);
            if (!is_array($entry)) {
                continue;
            }
            $normalized = $service->normalizeStatus((string) ($entry['status'] ?? 'pending'));
            if ($normalized === (string) ($entry['status'] ?? '')) {
                continue;
            }
            $entry['status'] = $normalized;
            $entry['updated_at'] = date('c');
            $storage->write($path, $entry);
        }
        break;
    }
}

function user_management_ensure_club_introduce_yourself_post(): void
{
    $slug = 'introduce-yourself';
    require_once user_management_cms_path('api/storage.php');
    $storage = new Storage(user_management_cms_path('content'));

    foreach ($storage->list('collections') as $dir) {
        $meta = $storage->read("collections/{$dir}/collection.json");
        if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== 'club-posts') {
            continue;
        }
        foreach ($storage->list("collections/{$dir}/entries") as $file) {
            if (!str_ends_with($file, '.json')) {
                continue;
            }
            $entry = $storage->read("collections/{$dir}/entries/{$file}");
            if (!is_array($entry)) {
                continue;
            }
            if ((string) ($entry['slug'] ?? '') === $slug) {
                $entryId = (string) ($entry['id'] ?? pathinfo($file, PATHINFO_FILENAME));
                if (!isTruthyClubPinned($entry['pinned'] ?? '')) {
                    $entry['pinned'] = '1';
                    $entry['updated_at'] = date('c');
                    $storage->write("collections/{$dir}/entries/{$entryId}.json", $entry);
                }

                return;
            }
        }

        $entryId = 'clubpost_introduce_yourself';
        $entry = [
            'id' => $entryId,
            'title' => 'Introduce yourself',
            'slug' => $slug,
            'status' => 'published',
            'pinned' => '1',
            'body' => '<p>Welcome to Birkly Club! Tell us who you are, what you are building, and what brought you here. Reply in the comments below.</p>',
            'author_name' => 'Birkly',
            'author_user_id' => '__birkly__',
            'owner' => '__birkly__',
            'created_at' => date('c'),
            'updated_at' => date('c'),
        ];
        $storage->write("collections/{$dir}/entries/{$entryId}.json", $entry);
        return;
    }
}

function isTruthyClubPinned(mixed $value): bool
{
    return $value === true || $value === '1' || $value === 1 || $value === 'true' || $value === 'yes';
}

function user_management_ensure_club_profiles_owner_schema(): void
{
    if (!class_exists('MemberAccountCodec')) {
        require_once __DIR__ . '/includes/MemberAccountCodec.php';
    }

    $collectionPath = user_management_resolve_collection_json_path('club-profiles');
    if ($collectionPath === null) {
        return;
    }

    $raw = file_get_contents($collectionPath);
    if ($raw === false) {
        return;
    }

    $config = json_decode($raw, true);
    if (!is_array($config)) {
        return;
    }

    $fields = $config['fields'] ?? [];
    if (!is_array($fields)) {
        $fields = [];
    }

    $hasOwner = false;
    $hasAccount = false;
    $nextFields = [];
    foreach ($fields as $field) {
        if (!is_array($field)) {
            continue;
        }
        if (($field['name'] ?? '') === 'user_id') {
            continue;
        }
        if (MemberAccountCodec::isAccountFieldType((string) ($field['type'] ?? ''))) {
            $hasAccount = true;
        }
        if (($field['name'] ?? '') === 'owner' && ($field['type'] ?? '') === 'user') {
            $hasOwner = true;
            if ($hasAccount) {
                continue;
            }
            $field['ownership'] = true;
            $field['required'] = true;
            $field['public_visible'] = false;
        }
        $nextFields[] = $field;
    }

    if (!$hasOwner && !$hasAccount) {
        $nextFields[] = [
            'name' => 'owner',
            'type' => 'user',
            'label' => 'Owner',
            'ownership' => true,
            'required' => true,
            'public_visible' => false,
        ];
    }

    $config['fields'] = $nextFields;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

function user_management_ensure_user_relationships_collection(): void
{
    user_management_ensure_graph_store();
}

function user_management_ensure_graph_store(): void
{
    require_once __DIR__ . '/includes/UserGraphStore.php';
    (new UserGraphStore())->ensureStore();
}

function user_management_run_p76_migration(): void
{
    user_management_ensure_p76_schema();
    require_once __DIR__ . '/scripts/migrate-p76-graph-store.php';
    if (function_exists('user_management_migrate_p76_graph_store')) {
        user_management_migrate_p76_graph_store(true);
    }
}

function user_management_ensure_p76_schema(): void
{
    user_management_ensure_graph_store();
    user_management_ensure_club_profiles_relationships_field();
    require_once __DIR__ . '/scripts/migrate-p76-graph-store.php';
    if (function_exists('user_management_hide_user_relationships_collection')) {
        $contentRoot = user_management_cms_path('content');
        user_management_hide_user_relationships_collection($contentRoot);
    }
}

function user_management_ensure_club_profiles_relationships_field(): void
{
    $collectionPath = user_management_resolve_collection_json_path('club-profiles');
    if ($collectionPath === null) {
        return;
    }

    $config = json_decode((string) file_get_contents($collectionPath), true);
    if (!is_array($config)) {
        return;
    }

    $fields = $config['fields'] ?? [];
    if (!is_array($fields)) {
        $fields = [];
    }

    foreach ($fields as $field) {
        if (is_array($field) && ($field['type'] ?? '') === 'user_relationship') {
            return;
        }
    }

    $fields[] = [
        'name' => 'relationships',
        'type' => 'user_relationship',
        'label' => 'Relationships',
        'required' => false,
        'modes' => ['follow', 'connection', 'block'],
        'show_counts' => true,
        'public_visible' => false,
    ];

    $config['fields'] = $fields;
    $config['updated_at'] = date('c');
    user_management_write_collection_json($collectionPath, $config);
}

/**
 * Create missing profile collection entries for active site users (idempotent).
 */
function user_management_backfill_profile_entries(): void
{
    if (!function_exists('get_plugin_setting')) {
        return;
    }

    $enabled = (bool) get_plugin_setting('user_management', 'profile_collection_enabled', false);
    $slug = trim((string) get_plugin_setting('user_management', 'profile_collection_slug', ''));
    if (!$enabled || $slug === '') {
        return;
    }

    if (user_management_resolve_collection_json_path($slug) === null) {
        return;
    }

    $storage = new UserStorage();
    $runtime = $storage->readMetadata('plugin_runtime');
    if (!is_array($runtime)) {
        $runtime = [];
    }

    $backfillKey = 'profile_backfill_' . preg_replace('/[^a-z0-9_-]/i', '_', $slug);
    if (($runtime[$backfillKey] ?? '') === '1') {
        return;
    }

    require_once __DIR__ . '/includes/UserService.php';
    require_once __DIR__ . '/includes/ProfileService.php';

    $users = new UserService();
    $profiles = new ProfileService();
    $listed = $users->listUsers(['status' => 'active'], 10000, 0);
    if (!is_array($listed)) {
        return;
    }

    foreach ($listed as $user) {
        if (!is_array($user)) {
            continue;
        }
        $profiles->ensureProfileForUser($slug, $user);
    }

    $runtime[$backfillKey] = '1';
    $storage->saveMetadata('plugin_runtime', $runtime);
}

function user_management_ensure_club_collection_permissions(): void
{
    require_once __DIR__ . '/includes/CollectionPermissionsService.php';
    $service = new CollectionPermissionsService();
    $permissions = $service->getPermissions();
    $changed = false;

    $defaults = [
        'club-home' => ['read' => true],
        'club-posts' => ['read' => true, 'create' => true, 'edit_own' => true, 'delete_own' => true],
        'club-profiles' => ['read' => true, 'create' => true, 'edit_own' => true],
        'club-wishes' => ['read' => true, 'create' => true, 'edit_own' => true],
        'club-deals' => ['read' => true],
        'roadmap-features' => ['read' => true],
        'roadmap-phases' => ['read' => true],
    ];

    foreach ($defaults as $collectionSlug => $tierPerms) {
        if (!isset($permissions[$collectionSlug]) || !is_array($permissions[$collectionSlug])) {
            $permissions[$collectionSlug] = [];
        }
        $existingClub = $permissions[$collectionSlug]['club'] ?? [];
        if (!is_array($existingClub)) {
            $existingClub = [];
        }
        $mergedClub = $existingClub;
        foreach ($tierPerms as $permKey => $permValue) {
            if (($mergedClub[$permKey] ?? null) !== $permValue) {
                $mergedClub[$permKey] = $permValue;
                $changed = true;
            }
        }
        if ($mergedClub !== $existingClub) {
            $permissions[$collectionSlug]['club'] = $mergedClub;
            $changed = true;
        }
    }

    if ($changed) {
        try {
            $service->savePermissions($permissions);
        } catch (Exception $e) {
            error_log('User Management club permissions seed failed: ' . $e->getMessage());
        }
    }
}

if (function_exists('register_plugin_action') && function_exists('get_plugin_state') && get_plugin_state('automation')) {
    register_plugin_action('send_activation_email', [
        'name' => 'Send account activation email',
        'description' => 'Send a membership activation link when the customer email is entitled (subscription, signup flow opt-in, etc.)',
        'category' => 'User',
        'schema' => [
            'email' => [
                'type' => 'text',
                'label' => 'Customer email',
                'description' => 'Optional override; defaults to payload customer_email',
                'required' => false,
            ],
            'tier_id' => [
                'type' => 'text',
                'label' => 'Tier id',
                'description' => 'Optional tier override (defaults to activation_tier setting)',
                'required' => false,
            ],
        ],
        'handler' => function (array $config, array $context) {
            $email = strtolower(trim((string) ($config['email'] ?? '')));
            if ($email === '') {
                $email = strtolower(trim((string) ($context['customer_email'] ?? $context['email'] ?? '')));
            }
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return ['ok' => false, 'error' => 'No customer email for activation'];
            }

            $activationContext = [
                'source' => 'automation',
                'order_id' => (string) ($context['order_id'] ?? ''),
                'signup_flow_id' => (string) ($context['signup_flow_id'] ?? ($context['metadata']['signup_flow_id'] ?? '')),
                'signup_flow_session_id' => (string) ($context['signup_flow_session_id'] ?? ($context['metadata']['signup_flow_session_id'] ?? '')),
            ];
            if (!empty($config['tier_id'])) {
                $activationContext['tier_id'] = (string) $config['tier_id'];
            }

            $send = (new UserActivationShelf())->sendActivation($email, $activationContext);

            return [
                'ok' => (bool) ($send['success'] ?? false),
                'message' => $send['message'] ?? '',
                'email' => $email,
            ];
        },
    ]);

    register_plugin_action('sync_supporter_badge', [
        'name' => 'Sync supporter badge',
        'description' => 'Reconcile club profile supporter badge fields for the customer email on the trigger payload',
        'category' => 'User',
        'schema' => [
            'email' => [
                'type' => 'text',
                'label' => 'Customer email',
                'description' => 'Optional override; defaults to payload customer_email',
                'required' => false,
            ],
        ],
        'handler' => function (array $config, array $context) {
            require_once __DIR__ . '/includes/SupporterBadgeSync.php';
            $email = trim((string) ($config['email'] ?? ''));
            if ($email === '') {
                $email = trim((string) ($context['customer_email'] ?? $context['email'] ?? ''));
            }
            if ($email === '') {
                return ['ok' => false, 'error' => 'No customer email for supporter badge sync'];
            }

            return (new SupporterBadgeSync())->reconcileForEmail(strtolower($email));
        },
    ]);

    register_plugin_action('send_club_notification_digests', [
        'name' => 'Send club notification digests',
        'description' => 'Email batched unread club notifications to members with digest enabled',
        'category' => 'User',
        'schema' => [
            'frequency' => [
                'type' => 'text',
                'label' => 'Frequency filter',
                'description' => 'Optional: daily or weekly (omit to process all due digests)',
                'required' => false,
            ],
        ],
        'handler' => function (array $config, array $context) {
            require_once __DIR__ . '/includes/ClubNotificationDigestService.php';
            $frequency = trim((string) ($config['frequency'] ?? ''));
            $result = (new ClubNotificationDigestService())->processDueDigests($frequency !== '' ? $frequency : null);

            return [
                'ok' => true,
                'sent' => $result['sent'],
                'skipped' => $result['skipped'],
                'errors' => $result['errors'],
            ];
        },
    ]);
}

if (function_exists('register_automation_block')) {
    user_management_register_automation_triggers();
}

if (function_exists('register_plugin_mcp_tools') && function_exists('get_plugin_state') && get_plugin_state('user_management')) {
    require_once __DIR__ . '/docs/mcp_tools.php';
    register_plugin_mcp_tools('user_management', user_management_mcp_tool_registry());
}

if (function_exists('register_broadcast_actor') && function_exists('get_plugin_state') && get_plugin_state('user_management')) {
    require_once __DIR__ . '/includes/notification_shelf.php';
}

/**
 * Register User-category automation triggers for the node editor palette.
 */
function user_management_register_automation_triggers(): void
{
    $blocks = [
        'user_created' => [
            'name' => 'User Created',
            'description' => 'Fires when a new site user is registered',
        ],
        'user_login' => [
            'name' => 'User Login',
            'description' => 'Fires when a user logs in',
        ],
        'user_tier_changed' => [
            'name' => 'User Tier Changed',
            'description' => 'Fires when a user tier is updated',
        ],
        'club_profile_created' => [
            'name' => 'Club Profile Created',
            'description' => 'Fires when a new club profile entry is created',
        ],
        'club_member_onboarded' => [
            'name' => 'Club Member Onboarded',
            'description' => 'Fires when a member completes club onboarding',
        ],
        'club_post_created' => [
            'name' => 'Club Post Created',
            'description' => 'Fires when a new club-posts entry is published',
        ],
        'club_mention_created' => [
            'name' => 'Club Mention Created',
            'description' => 'Fires when @mentions notify members on posts or comments',
        ],
        'supporter_badge_granted' => [
            'name' => 'Supporter Badge Granted',
            'description' => 'Fires when Commerce sync grants a non-none supporter badge',
        ],
        'club_member_reported' => [
            'name' => 'Club Member Reported',
            'description' => 'Fires when a member submits a moderation report',
        ],
    ];

    foreach ($blocks as $id => $meta) {
        register_automation_block('trigger', $id, [
            'name' => $meta['name'],
            'description' => $meta['description'],
            'category' => 'User',
            'schema' => [],
            'handler' => function () {
                return true;
            },
        ]);
    }
}
