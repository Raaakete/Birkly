/**
 * @mention autocomplete for club composers (posts, comments, replies).
 * Uses User Management API: user_account?action=list_members
 */
(function () {
  'use strict';

  var MEMBERS_URL = '/api/index.php?route=user_account&action=list_members';
  var SESSION_KEY = 'birkly_site_session_id';
  var membersCache = null;
  var membersPromise = null;
  var active = null;

  function cmsBase() {
    var meta = document.querySelector('meta[name="birkly-cms-base"]');
    if (meta) {
      var fromMeta = (meta.getAttribute('content') || '').trim().replace(/\/$/, '');
      if (fromMeta) return fromMeta;
    }
    var script = document.querySelector('script[data-cms-url]');
    if (script) {
      var fromAttr = (script.getAttribute('data-cms-url') || '').trim().replace(/\/$/, '');
      if (fromAttr) return fromAttr;
    }
    if (window.Birkly && Birkly.cmsUrl) {
      return String(Birkly.cmsUrl).replace(/\/$/, '');
    }
    return '';
  }

  function withSessionHeaders(headers) {
    var h = headers && typeof headers === 'object' ? Object.assign({}, headers) : {};
    try {
      var sid = localStorage.getItem(SESSION_KEY);
      if (sid) h['X-Birkly-Site-Session'] = sid;
    } catch (_) { /* ignore */ }
    return h;
  }

  function fetchMembers() {
    if (membersCache) return Promise.resolve(membersCache);
    if (membersPromise) return membersPromise;

    var base = cmsBase();
    if (!base) return Promise.resolve([]);

    membersPromise = fetch(base + MEMBERS_URL, {
      credentials: 'include',
      headers: withSessionHeaders({ Accept: 'application/json' }),
    })
      .then(function (res) {
        if (!res.ok) return [];
        return res.json();
      })
      .then(function (json) {
        membersCache = Array.isArray(json && json.members) ? json.members : [];
        return membersCache;
      })
      .catch(function () {
        return [];
      });

    return membersPromise;
  }

  function mentionToken(member) {
    var title = String(member.title || '').trim();
    var slug = String(member.slug || '').trim();
    if (title.indexOf(' ') !== -1 || title.indexOf('-') !== -1) {
      return '@"' + title.replace(/"/g, '') + '"';
    }
    if (slug) return '@' + slug;
    if (title) return '@' + title.replace(/\s+/g, '');
    return '@member';
  }

  function matchesQuery(member, query) {
    var q = String(query || '').toLowerCase();
    if (!q) return true;
    var title = String(member.title || '').toLowerCase();
    var slug = String(member.slug || '').toLowerCase();
    return title.indexOf(q) !== -1 || slug.indexOf(q) !== -1;
  }

  function getMentionContext(textarea) {
    var value = textarea.value;
    var pos = textarea.selectionStart;
    if (typeof pos !== 'number') return null;
    var before = value.slice(0, pos);
    var match = before.match(/(^|[\s([{])@([^\s@]*)$/);
    if (!match) return null;
    var atIndex = before.lastIndexOf('@');
    return {
      query: match[2] || '',
      start: atIndex,
      end: pos,
    };
  }

  function ensureMenu() {
    var menu = document.getElementById('bk-mention-menu');
    if (menu) return menu;
    menu = document.createElement('div');
    menu.id = 'bk-mention-menu';
    menu.className = 'bk-mention-menu';
    menu.setAttribute('role', 'listbox');
    menu.hidden = true;
    document.body.appendChild(menu);
    return menu;
  }

  function hideMenu() {
    var menu = document.getElementById('bk-mention-menu');
    if (menu) menu.hidden = true;
    active = null;
  }

  function positionMenu(textarea) {
    var menu = ensureMenu();
    var rect = textarea.getBoundingClientRect();
    menu.style.left = Math.max(8, rect.left + window.scrollX) + 'px';
    menu.style.top = rect.bottom + window.scrollY + 6 + 'px';
    menu.style.minWidth = Math.min(320, Math.max(200, rect.width)) + 'px';
  }

  function currentUserId() {
    if (window.Birkly && Birkly.siteUser && Birkly.siteUser.id) {
      return String(Birkly.siteUser.id);
    }
    return '';
  }

  function renderMenu(textarea, items, selectedIndex) {
    var menu = ensureMenu();
    menu.innerHTML = '';
    if (!items.length) {
      var empty = document.createElement('p');
      empty.className = 'bk-mention-menu__empty';
      empty.textContent = 'No members match';
      menu.appendChild(empty);
      menu.hidden = false;
      positionMenu(textarea);
      return;
    }

    items.forEach(function (member, index) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'bk-mention-menu__item' + (index === selectedIndex ? ' is-active' : '');
      btn.setAttribute('role', 'option');
      btn.setAttribute('aria-selected', index === selectedIndex ? 'true' : 'false');
      btn.dataset.index = String(index);

      var avatar = document.createElement('span');
      avatar.className = 'bk-mention-menu__avatar';
      if (member.avatar) {
        var img = document.createElement('img');
        img.src = member.avatar.indexOf('http') === 0 ? member.avatar : cmsBase() + member.avatar;
        img.alt = '';
        avatar.appendChild(img);
      } else {
        avatar.textContent = (member.title || '?').charAt(0).toUpperCase();
      }

      var meta = document.createElement('span');
      meta.className = 'bk-mention-menu__meta';
      var name = document.createElement('span');
      name.className = 'bk-mention-menu__name';
      name.textContent = member.title || 'Member';
      var hint = document.createElement('span');
      hint.className = 'bk-mention-menu__hint';
      hint.textContent = member.slug ? '@' + member.slug : mentionToken(member);
      meta.appendChild(name);
      meta.appendChild(hint);

      btn.appendChild(avatar);
      btn.appendChild(meta);
      btn.addEventListener('mousedown', function (e) {
        e.preventDefault();
        applyMention(textarea, member);
      });
      menu.appendChild(btn);
    });

    menu.hidden = false;
    positionMenu(textarea);
  }

  function applyMention(textarea, member) {
    if (!active || active.textarea !== textarea) return;
    var ctx = active.context;
    if (!ctx) return;

    var token = mentionToken(member) + ' ';
    var value = textarea.value;
    textarea.value = value.slice(0, ctx.start) + token + value.slice(ctx.end);
    var caret = ctx.start + token.length;
    textarea.setSelectionRange(caret, caret);
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    hideMenu();
    textarea.focus();
  }

  function updateMenu(textarea) {
    var ctx = getMentionContext(textarea);
    if (!ctx) {
      hideMenu();
      return;
    }

    fetchMembers().then(function (members) {
      var selfId = currentUserId();
      var filtered = members.filter(function (member) {
        if (selfId && String(member.user_id || '') === selfId) return false;
        return matchesQuery(member, ctx.query);
      }).slice(0, 8);

      active = {
        textarea: textarea,
        context: ctx,
        items: filtered,
        selectedIndex: 0,
      };
      renderMenu(textarea, filtered, 0);
    });
  }

  function menuIsOpen(textarea) {
    var menu = document.getElementById('bk-mention-menu');
    return !!(
      menu &&
      !menu.hidden &&
      active &&
      active.textarea === textarea &&
      active.items &&
      active.items.length > 0
    );
  }

  function onKeyDown(e) {
    var textarea = e.target;
    if (!textarea.matches('[data-birkly-mentions]')) return;
    if (!menuIsOpen(textarea)) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      e.stopPropagation();
      active.selectedIndex = Math.min(active.selectedIndex + 1, active.items.length - 1);
      renderMenu(textarea, active.items, active.selectedIndex);
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      e.stopPropagation();
      active.selectedIndex = Math.max(active.selectedIndex - 1, 0);
      renderMenu(textarea, active.items, active.selectedIndex);
      return;
    }
    if (e.key === 'Enter' || e.key === 'Tab') {
      e.preventDefault();
      e.stopPropagation();
      applyMention(textarea, active.items[active.selectedIndex]);
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      hideMenu();
    }
  }

  function bindTextarea(textarea) {
    if (textarea.dataset.birklyMentionsBound === '1') return;
    textarea.dataset.birklyMentionsBound = '1';
    textarea.setAttribute('autocomplete', 'off');
    textarea.addEventListener('input', function () {
      updateMenu(textarea);
    });
    textarea.addEventListener('click', function () {
      updateMenu(textarea);
    });
    textarea.addEventListener('keyup', function () {
      updateMenu(textarea);
    });
    textarea.addEventListener('blur', function () {
      setTimeout(hideMenu, 150);
    });
  }

  function scan() {
    document.querySelectorAll('textarea[data-birkly-mentions]').forEach(bindTextarea);
  }

  document.addEventListener('keydown', onKeyDown, true);
  document.addEventListener('click', function (e) {
    var menu = document.getElementById('bk-mention-menu');
    if (!menu || menu.hidden) return;
    if (e.target.closest('#bk-mention-menu') || e.target.matches('[data-birkly-mentions]')) return;
    hideMenu();
  });

  function init() {
    scan();
    fetchMembers();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  document.addEventListener('birkly:client-ready', init);
})();
