<?php
/**
 * P76 migration — user-relationships collection → plugin graph store.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/UserGraphStore.php';
require_once __DIR__ . '/../cms_paths.php';

/**
 * @return array{migrated: int, skipped: int, hidden_collection: bool, errors: list<string>}
 */
function user_management_migrate_p76_graph_store(bool $hideCollection = true): array
{
    $result = [
        'migrated' => 0,
        'skipped' => 0,
        'hidden_collection' => false,
        'errors' => [],
    ];

    $store = new UserGraphStore();
    $store->ensureStore();

    $contentRoot = user_management_cms_root() . '/content';
    $legacyDir = $contentRoot . '/collections/user-relationships/entries';
    if (!is_dir($legacyDir)) {
        if ($hideCollection) {
            $result['hidden_collection'] = user_management_hide_user_relationships_collection($contentRoot);
        }

        return $result;
    }

    foreach (glob($legacyDir . '/*.json') ?: [] as $file) {
        $raw = file_get_contents($file);
        if ($raw === false) {
            $result['errors'][] = 'read failed: ' . basename($file);
            continue;
        }
        $entry = json_decode($raw, true);
        if (!is_array($entry)) {
            $result['errors'][] = 'invalid json: ' . basename($file);
            continue;
        }

        $from = trim((string) ($entry['from_user'] ?? ''));
        $to = trim((string) ($entry['to_user'] ?? ''));
        $kind = (string) ($entry['relationship_type'] ?? $entry['kind'] ?? '');
        $status = (string) ($entry['status'] ?? UserGraphStore::STATUS_ACTIVE);
        if ($from === '' || $to === '' || $kind === '') {
            $result['skipped']++;
            continue;
        }

        $kind = $store->normalizeKind($kind);
        $edgeId = $store->edgeId($from, $to, $kind);
        if ($store->readEdge($edgeId) !== null) {
            $result['skipped']++;
            continue;
        }

        $edge = $store->normalizeEdge([
            'id' => $edgeId,
            'from_user' => $from,
            'to_user' => $to,
            'kind' => $kind,
            'status' => $status,
            'initiated_by' => (string) ($entry['initiated_by'] ?? $from),
            'created_at' => (string) ($entry['created_at'] ?? date('c')),
            'updated_at' => (string) ($entry['updated_at'] ?? date('c')),
        ]);

        if ($store->writeEdge($edge)) {
            $result['migrated']++;
        } else {
            $result['errors'][] = 'write failed: ' . $edgeId;
        }
    }

    if ($hideCollection) {
        $result['hidden_collection'] = user_management_hide_user_relationships_collection($contentRoot);
        user_management_archive_user_relationships_entries($legacyDir);
    }

    return $result;
}

function user_management_hide_user_relationships_collection(string $contentRoot): bool
{
    $collectionPath = $contentRoot . '/collections/user-relationships/collection.json';
    if (!is_file($collectionPath)) {
        return false;
    }

    $config = json_decode((string) file_get_contents($collectionPath), true);
    if (!is_array($config)) {
        return false;
    }

    $options = is_array($config['options'] ?? null) ? $config['options'] : [];
    $options['hidden'] = true;
    $options['system'] = true;
    $config['options'] = $options;
    $config['name'] = 'User Relationships (system)';
    $config['description'] = 'Deprecated — graph stored in User plugin (P76).';
    $config['updated_at'] = date('c');

    return file_put_contents(
        $collectionPath,
        json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n"
    ) !== false;
}

function user_management_archive_user_relationships_entries(string $legacyDir): void
{
    if (!is_dir($legacyDir)) {
        return;
    }

    $archiveDir = dirname($legacyDir) . '/entries.archived-p76';
    if (is_dir($archiveDir)) {
        return;
    }

    @rename($legacyDir, $archiveDir);
}
