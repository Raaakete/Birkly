<?php
/**
 * P75 UGC migration — owner fields, likes sub-entries, graph edges.
 *
 * Usage: php scripts/migrate-p75-ugc.php [--dry-run]
 */

declare(strict_types=1);

/**
 * @return array<string, int>
 */
function user_management_migrate_p75_ugc(bool $dryRun = false): array
{
    $root = realpath(__DIR__ . '/../../..');
    if ($root === false || !is_dir($root . '/content')) {
        throw new RuntimeException('Cannot resolve CMS content root from plugin scripts directory.');
    }

    require_once $root . '/api/storage.php';
    require_once $root . '/core/sub_entries.php';
    require_once $root . '/core/entry_ownership.php';
    require_once __DIR__ . '/../includes/UserStorage.php';
    require_once __DIR__ . '/../includes/SubEntryLikeService.php';
    require_once __DIR__ . '/../includes/UserGraphService.php';

    $stats = [
        'entries_owner' => 0,
        'comments_owner' => 0,
        'profiles_owner' => 0,
        'likes_created' => 0,
        'likes_owner' => 0,
        'graph_edges' => 0,
        'metadata_cleared' => 0,
    ];

    p75_migrate_collection_entries('club-posts', $dryRun, $stats);
    p75_migrate_collection_entries('club-profiles', $dryRun, $stats);
    p75_migrate_sub_entries('club-posts', 'comments', $dryRun, $stats);
    p75_migrate_sub_entries('club-posts', 'likes', $dryRun, $stats);
    p75_migrate_sub_entries('club-wishes', 'likes', $dryRun, $stats);
    p75_migrate_sub_entries('roadmap-features', 'likes', $dryRun, $stats);
    p75_migrate_reaction_metadata($dryRun, $stats);
    p75_migrate_follow_metadata($dryRun, $stats);

    return $stats;
}

/**
 * @param array<string, mixed> $entry
 *
 * @return array<string, mixed>
 */
function p75_stamp_owner_from_legacy(array $entry, string $ownerField = 'owner'): array
{
    if (trim((string) ($entry[$ownerField] ?? '')) !== '') {
        return $entry;
    }

    foreach (['author_user_id', 'author_id', 'user_id'] as $legacyKey) {
        $value = trim((string) ($entry[$legacyKey] ?? ''));
        if ($value !== '') {
            $entry[$ownerField] = $value;
            break;
        }
    }

    return $entry;
}

function p75_write_json(string $path, array $entry, bool $dryRun): bool
{
    if ($dryRun) {
        return true;
    }

    return file_put_contents(
        $path,
        json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n"
    ) !== false;
}

/**
 * @param array<string, int> $stats
 */
function p75_migrate_collection_entries(string $collection, bool $dryRun, array &$stats): void
{
    $dir = __DIR__ . '/../../../content/collections/' . $collection . '/entries';
    if (!is_dir($dir)) {
        return;
    }

    foreach (glob($dir . '/*.json') ?: [] as $file) {
        $raw = file_get_contents($file);
        if ($raw === false) {
            continue;
        }
        $entry = json_decode($raw, true);
        if (!is_array($entry)) {
            continue;
        }
        $before = (string) ($entry['owner'] ?? '');
        $entry = p75_stamp_owner_from_legacy($entry);
        $after = (string) ($entry['owner'] ?? '');
        if ($after !== '' && $after !== $before) {
            if ($collection === 'club-profiles') {
                $stats['profiles_owner']++;
            } else {
                $stats['entries_owner']++;
            }
            p75_write_json($file, $entry, $dryRun);
        } elseif ($collection === 'club-profiles' && $after !== '' && isset($entry['user_id'])) {
            unset($entry['user_id']);
            p75_write_json($file, $entry, $dryRun);
        }
    }
}

/**
 * @param array<string, int> $stats
 */
function p75_migrate_sub_entries(string $parentCollection, string $subCollection, bool $dryRun, array &$stats): void
{
    $parentDir = __DIR__ . '/../../../content/collections/' . $parentCollection . '/entries';
    if (!is_dir($parentDir)) {
        return;
    }

    foreach (glob($parentDir . '/*', GLOB_ONLYDIR) ?: [] as $entryDir) {
        $subDir = $entryDir . '/sub_entries/' . $subCollection;
        if (!is_dir($subDir)) {
            continue;
        }
        foreach (glob($subDir . '/*.json') ?: [] as $file) {
            $raw = file_get_contents($file);
            if ($raw === false) {
                continue;
            }
            $entry = json_decode($raw, true);
            if (!is_array($entry)) {
                continue;
            }
            $before = (string) ($entry['owner'] ?? '');
            $entry = p75_stamp_owner_from_legacy($entry);
            $after = (string) ($entry['owner'] ?? '');
            if ($after !== '' && $after !== $before) {
                if ($subCollection === 'likes') {
                    $stats['likes_owner']++;
                } else {
                    $stats['comments_owner']++;
                }
                p75_write_json($file, $entry, $dryRun);
            }
        }
    }
}

/**
 * @param array<string, int> $stats
 */
function p75_migrate_reaction_metadata(bool $dryRun, array &$stats): void
{
    $userStorage = new UserStorage();
    $raw = $userStorage->readMetadata('club_social_reactions');
    if (!is_array($raw) || $raw === []) {
        return;
    }

    $map = [
        'post' => new SubEntryLikeService('club-posts'),
        'wish' => new SubEntryLikeService('club-wishes'),
    ];

    foreach ($raw as $key => $users) {
        if (!is_string($key) || !is_array($users)) {
            continue;
        }
        if (!preg_match('/^(post|wish):([a-z0-9_-]+)$/', $key, $matches)) {
            continue;
        }
        $type = $matches[1];
        $slug = $matches[2];
        $service = $map[$type] ?? null;
        if ($service === null) {
            continue;
        }
        foreach ($users as $userId) {
            $userId = trim((string) $userId);
            if ($userId === '') {
                continue;
            }
            if ($dryRun) {
                $stats['likes_created']++;
                continue;
            }
            if ($service->ensureLike($userId, $slug)) {
                $stats['likes_created']++;
            }
        }
    }

    if (!$dryRun) {
        $userStorage->saveMetadata('club_social_reactions', []);
        $stats['metadata_cleared']++;
    }
}

/**
 * @param array<string, int> $stats
 */
function p75_migrate_follow_metadata(bool $dryRun, array &$stats): void
{
    $userStorage = new UserStorage();
    $raw = $userStorage->readMetadata('club_social_follows');
    if (!is_array($raw) || $raw === []) {
        return;
    }

    $graph = new UserGraphService();
    foreach ($raw as $userId => $following) {
        $userId = trim((string) $userId);
        if ($userId === '' || !is_array($following)) {
            continue;
        }
        foreach ($following as $targetUserId) {
            $targetUserId = trim((string) $targetUserId);
            if ($targetUserId === '') {
                continue;
            }
            if ($dryRun) {
                $stats['graph_edges']++;
                continue;
            }
            try {
                $graph->follow($userId, $targetUserId);
                $stats['graph_edges']++;
            } catch (Throwable $e) {
                // Idempotent — duplicate edges are ignored by graph service.
            }
        }
    }

    if (!$dryRun) {
        $userStorage->saveMetadata('club_social_follows', []);
        $stats['metadata_cleared']++;
    }
}

if (PHP_SAPI === 'cli' && realpath($argv[0] ?? '') === __FILE__) {
    $dryRun = in_array('--dry-run', $argv, true);
    echo ($dryRun ? 'P75 migration (dry run)' : 'P75 migration') . PHP_EOL;
    try {
        $stats = user_management_migrate_p75_ugc($dryRun);
        echo 'Done: ' . json_encode($stats, JSON_UNESCAPED_SLASHES) . PHP_EOL;
    } catch (Throwable $e) {
        fwrite(STDERR, $e->getMessage() . PHP_EOL);
        exit(1);
    }
}
