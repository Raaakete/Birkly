<?php
/**
 * P77 migration — UserStorage users + club profiles → member entries.
 *
 * Usage: php scripts/migrate-p77-members.php [--dry-run] [--collection=club-profiles]
 */

declare(strict_types=1);

$dryRun = in_array('--dry-run', $argv ?? [], true);
$collection = 'club-profiles';
foreach ($argv ?? [] as $arg) {
    if (str_starts_with($arg, '--collection=')) {
        $collection = trim(substr($arg, strlen('--collection=')));
    }
}

$root = realpath(__DIR__ . '/../../..');
if ($root === false || !is_dir($root . '/content')) {
    fwrite(STDERR, "Cannot resolve CMS content root.\n");
    exit(1);
}

require_once __DIR__ . '/../includes/MemberMigrateService.php';

$result = user_management_migrate_p77_members([
    'collection' => $collection,
    'dry_run' => $dryRun,
]);

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";

if (!empty($result['errors'])) {
    exit(1);
}

exit(0);
