// User Management — email templates admin (P74-M1)

let userEmailCeAssetsLoaded = false;

function userAdminToast(message, type) {
    const toastType = type || 'success';
    if (window.Birkly && window.Birkly.Utils && typeof window.Birkly.Utils.showToast === 'function') {
        window.Birkly.Utils.showToast(message, toastType);
        return;
    }
    if (window.BirklyFeedback && typeof window.BirklyFeedback.toast === 'function') {
        window.BirklyFeedback.toast(message, toastType);
        return;
    }
    alert(message);
}

function initEmailsManagement() {
    const container = document.getElementById('emails-container');
    if (!container) {
        return;
    }
    if (container.dataset.emailsInit !== '1') {
        container.dataset.emailsInit = '1';
        container.addEventListener('click', handleEmailsAdminClick);
        container.addEventListener('change', handleEmailsAdminChange);
    }
    loadEmailTemplates();
}

function handleEmailsAdminClick(event) {
    const button = event.target.closest('[data-user-email-action]');
    if (!button) {
        return;
    }
    const action = button.getAttribute('data-user-email-action');
    if (action === 'save-delivery') {
        saveEmailDelivery();
    } else if (action === 'save-template') {
        saveEmailTemplate();
    } else if (action === 'send-test') {
        sendEmailTest(button);
    }
}

function handleEmailsAdminChange(event) {
    if (event.target?.id === 'email-template-select') {
        selectEmailTemplate(event.target.value);
    }
}

function getCsrfToken() {
    return document.querySelector('meta[name="csrf-token"]')?.content
        || document.querySelector('input[name="_csrf"]')?.value
        || '';
}

function fieldtypesApiUrl() {
    return (window.Birkly && typeof Birkly.url === 'function')
        ? Birkly.url('/api/admin_fieldtypes.php')
        : '/api/admin_fieldtypes.php';
}

function getAdminCspNonce() {
    const el = document.querySelector('script[nonce]');
    if (!el) return '';
    return el.nonce || el.getAttribute('nonce') || '';
}

function injectContentEditorJavascript(jsSource) {
    if (!jsSource || window.ContentEditorSync) return !!window.ContentEditorSync;
    const nonce = getAdminCspNonce();
    try {
        const script = document.createElement('script');
        script.id = 'user-email-content-editor-js';
        if (nonce) {
            script.nonce = nonce;
            script.setAttribute('nonce', nonce);
        }
        script.textContent = jsSource;
        document.head.appendChild(script);
    } catch (e) {
        console.error('Content Editor script-tag inject failed', e);
    }
    if (window.ContentEditorSync) return true;
    try {
        (0, eval)(jsSource);
    } catch (e2) {
        console.error('Content Editor eval fallback failed', e2);
        return false;
    }
    return !!window.ContentEditorSync;
}

function ensureContentEditorAssets(data) {
    if (userEmailCeAssetsLoaded && window.ContentEditorSync) {
        return true;
    }
    if (data.css && !document.getElementById('user-email-content-editor-css')) {
        const style = document.createElement('style');
        style.id = 'user-email-content-editor-css';
        style.textContent = data.css;
        document.head.appendChild(style);
    }
    let ok = true;
    if (!window.ContentEditorSync) {
        ok = injectContentEditorJavascript(data.javascript || '');
    }
    userEmailCeAssetsLoaded = true;
    return ok;
}

function syncContentEditorHost(hostId, hiddenTextareaId) {
    const host = document.getElementById(hostId);
    const ta = document.getElementById(hiddenTextareaId);
    if (!host || !ta) return ta ? (ta.value || '') : '';
    const fallback = host.querySelector('textarea[id$="_fallback"]');
    if (fallback) {
        ta.value = fallback.value || '';
        return ta.value || '';
    }
    const wrapper = host.querySelector('.content-editor-wrapper');
    if (wrapper && window.ContentEditorSync && typeof ContentEditorSync.syncWrapperToHidden === 'function') {
        ContentEditorSync.syncWrapperToHidden(wrapper, true);
    }
    const field = host.querySelector('input[type="hidden"][id^="field_"], textarea[id^="field_"]');
    if (field) {
        ta.value = field.value || '';
    }
    return ta.value || '';
}

function mountContentEditor(hostId, fieldName, label, htmlValue) {
    const host = document.getElementById(hostId);
    if (!host) return Promise.resolve();
    const formData = new FormData();
    formData.append('action', 'render');
    formData.append('fieldtype', 'content-editor');
    formData.append('config[name]', fieldName);
    formData.append('config[label]', label || 'Body');
    formData.append('config[value]', htmlValue || '');
    return fetch(fieldtypesApiUrl(), {
        method: 'POST',
        credentials: 'same-origin',
        body: formData,
    }).then((r) => r.json()).then((data) => {
        if (data.error) throw new Error(data.error);
        if (!data.html) throw new Error('Content editor failed to render');
        if (!ensureContentEditorAssets(data)) {
            throw new Error('Content Editor scripts blocked by CSP');
        }
        host.innerHTML = data.html;
        const editor = host.querySelector('.content-editor-area');
        if (editor) {
            window.ContentEditorState = window.ContentEditorState || {};
            window.ContentEditorState.activeEditor = editor;
        }
        setTimeout(() => {
            const wrapper = host.querySelector('.content-editor-wrapper');
            if (!wrapper || wrapper.dataset.initialized === 'true') return;
            const html = host.innerHTML;
            host.innerHTML = '';
            host.innerHTML = html;
            const ed = host.querySelector('.content-editor-area');
            if (ed) {
                window.ContentEditorState = window.ContentEditorState || {};
                window.ContentEditorState.activeEditor = ed;
            }
        }, 0);
    }).catch((err) => {
        console.error(err);
        host.innerHTML = '<p class="field-help">Could not load Content Editor — falling back to plain HTML.</p>'
            + `<textarea class="input textarea" rows="12" id="${escapeHtml(fieldName)}_fallback">`
            + `${escapeHtml(htmlValue || '')}</textarea>`;
    });
}

function mountUserEmailConnectionPicker(el, value, onChange) {
    if (!el || !window.BirklyEmailConnectionPicker) return;
    el.setAttribute('data-picker-value', value || '');
    BirklyEmailConnectionPicker.mount(el, {
        name: 'email_connection_alias',
        value: value || '',
        id: el.getAttribute('data-picker-id') || 'user-email-connection',
        help: el.getAttribute('data-picker-help') || '',
        onChange,
    });
}

function mountEmailTemplateConnectionPicker(value) {
    const wrap = document.getElementById('email-template-connection-wrap');
    if (!wrap) return;
    wrap.innerHTML = '<div id="email-template-connection-picker" data-email-connection-picker data-picker-name="email_connection_alias" data-picker-id="email-template-connection" data-picker-help="Send this template using a specific email connection. Leave on the site default unless you need a different From address."></div>';
    mountUserEmailConnectionPicker(wrap.querySelector('[data-email-connection-picker]'), value || '');
}

function loadEmailTemplates() {
    const container = document.getElementById('emails-container');
    if (!container) {
        return;
    }
    container.innerHTML = '<div class="loading-state"><p>Loading email templates…</p></div>';

    fetch(apiUrl('/api/index.php?route=user_emails&action=list_templates'))
        .then(async (res) => {
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error(`Invalid JSON response: ${text.substring(0, 200)}`);
            }
            if (!res.ok) {
                throw new Error(data.error || `HTTP ${res.status}`);
            }
            return data;
        })
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || 'Failed to load templates');
            }
            window.userEmailTemplates = data.templates || [];
            window.userEmailDelivery = data.delivery || { email_connection_alias: '' };
            renderEmailTemplatesUI();
        })
        .catch((error) => {
            console.error('Error loading email templates:', error);
            container.innerHTML = `<div class="alert alert-danger">Error loading templates: ${escapeHtml(error.message)}</div>`;
        });
}

function renderEmailTemplatesUI() {
    const container = document.getElementById('emails-container');
    const templates = window.userEmailTemplates || [];
    const delivery = window.userEmailDelivery || {};

    const templateOptions = templates.map((tpl) => {
        const id = tpl.id || '';
        const name = tpl.name || id;
        return `<option value="${escapeHtml(id)}">${escapeHtml(name)}</option>`;
    }).join('');

    container.innerHTML = `
        <div class="u-stack-6">
            <section class="card">
                <div class="card-header">
                    <h3 class="card-title">Delivery</h3>
                </div>
                <div class="card-body u-stack-4">
                    <p class="field-help">Transactional emails use a Connections alias from <strong>Settings → Connections</strong>. Templates without their own connection use this default.</p>
                    <div id="user-email-connection-picker"
                         data-email-connection-picker
                         data-picker-name="email_connection_alias"
                         data-picker-id="user-email-connection"
                         data-picker-help="Default for templates that do not pick their own connection."></div>
                    <button type="button" class="btn btn-secondary" data-user-email-action="save-delivery">Save delivery settings</button>
                </div>
            </section>

            <section class="card">
                <div class="card-header u-row-2">
                    <h3 class="card-title">Templates</h3>
                    <div class="u-cluster-3">
                        <select id="email-template-select" class="select input">
                            ${templateOptions}
                        </select>
                        <button type="button" class="btn btn-primary" data-user-email-action="save-template">Save template</button>
                    </div>
                </div>
                <div class="card-body u-stack-4" id="email-template-editor">
                    <p class="field-help">Merge tokens: <code>{{site_name}}</code>, <code>{{site_url}}</code>, <code>{{activation_url}}</code>, <code>{{verification_url}}</code>, <code>{{reset_url}}</code>, <code>{{tier_id}}</code></p>
                </div>
            </section>

            <section class="card">
                <div class="card-header">
                    <h3 class="card-title">Send test</h3>
                </div>
                <div class="card-body u-stack-4">
                    <div class="u-grid-auto-sm" style="align-items: end;">
                        <div class="field form-group">
                            <label for="email-test-address">Recipient</label>
                            <input type="email" id="email-test-address" class="input" placeholder="you@example.com">
                        </div>
                        <div class="field form-group">
                            <button type="button" class="btn btn-outline" data-user-email-action="send-test">Send test email</button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    `;

    mountUserEmailConnectionPicker(
        document.getElementById('user-email-connection-picker'),
        delivery.email_connection_alias || '',
    );

    const first = templates[0]?.id || '';
    if (first) {
        selectEmailTemplate(first);
    }
}

function getSelectedEmailTemplate() {
    const id = document.getElementById('email-template-select')?.value || '';
    return (window.userEmailTemplates || []).find((tpl) => tpl.id === id) || null;
}

function selectEmailTemplate(templateId) {
    const select = document.getElementById('email-template-select');
    if (select && select.value !== templateId) {
        select.value = templateId;
    }

    const tpl = (window.userEmailTemplates || []).find((item) => item.id === templateId);
    const editor = document.getElementById('email-template-editor');
    if (!editor || !tpl) {
        return;
    }

    editor.innerHTML = `
        <div class="field form-group">
            <label>
                <input type="checkbox" id="email-template-enabled" ${tpl.enabled !== false ? 'checked' : ''}>
                Enabled
            </label>
        </div>
        <div class="field form-group">
            <label for="email-template-subject">Subject</label>
            <input type="text" id="email-template-subject" class="input" value="${escapeHtml(tpl.subject || '')}">
        </div>
        <div class="field form-group" id="email-template-connection-wrap"></div>
        <div class="field form-group">
            <label>Body (HTML)</label>
            <div id="user-email-body-editor"></div>
            <textarea id="email-template-body" class="input textarea" rows="12" hidden>${escapeHtml(tpl.body_html || '')}</textarea>
        </div>
    `;

    mountEmailTemplateConnectionPicker(tpl.email_connection_alias || '');
    mountContentEditor('user-email-body-editor', 'user_email_body', 'Email body', tpl.body_html || '');
}

function getDeliveryConnectionAlias() {
    return document.getElementById('user-email-connection')?.value
        || document.getElementById('email-connection-alias')?.value
        || '';
}

function getTemplateConnectionAlias() {
    return document.getElementById('email-template-connection')?.value || '';
}

function saveEmailDelivery() {
    const alias = getDeliveryConnectionAlias();
    fetch(apiUrl('/api/index.php?route=user_emails'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'save_delivery',
            csrf_token: getCsrfToken(),
            email_connection_alias: alias,
        }),
    })
        .then((res) => res.json())
        .then((data) => {
            if (data.success) {
                window.userEmailDelivery = data.delivery || { email_connection_alias: alias };
                userAdminToast('Delivery settings saved', 'success');
            } else {
                alert('Failed: ' + (data.error || 'Unknown error'));
            }
        })
        .catch((error) => {
            console.error(error);
            alert('Error saving delivery settings');
        });
}

function saveEmailTemplate() {
    const tpl = getSelectedEmailTemplate();
    if (!tpl) {
        return;
    }

    let bodyHtml = syncContentEditorHost('user-email-body-editor', 'email-template-body');
    const fallback = document.getElementById('user_email_body_fallback');
    if (fallback) bodyHtml = fallback.value || bodyHtml;

    const payload = {
        action: 'save_template',
        csrf_token: getCsrfToken(),
        template: {
            id: tpl.id,
            name: tpl.name,
            enabled: document.getElementById('email-template-enabled')?.checked !== false,
            subject: document.getElementById('email-template-subject')?.value || '',
            body_html: bodyHtml,
            email_connection_alias: getTemplateConnectionAlias(),
        },
    };

    fetch(apiUrl('/api/index.php?route=user_emails'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
    })
        .then((res) => res.json())
        .then((data) => {
            if (data.success && data.template) {
                const idx = (window.userEmailTemplates || []).findIndex((item) => item.id === data.template.id);
                if (idx >= 0) {
                    window.userEmailTemplates[idx] = data.template;
                }
                userAdminToast('Template saved', 'success');
            } else {
                alert('Failed: ' + (data.error || 'Unknown error'));
            }
        })
        .catch((error) => {
            console.error(error);
            alert('Error saving template');
        });
}

function sendEmailTest(triggerButton) {
    const tpl = getSelectedEmailTemplate();
    const email = document.getElementById('email-test-address')?.value?.trim() || '';
    if (!tpl) {
        alert('Select a template first');
        return;
    }
    if (!email) {
        alert('Enter a recipient email');
        return;
    }

    const button = triggerButton || document.querySelector('[data-user-email-action="send-test"]');
    const originalLabel = button?.textContent || 'Send test email';
    if (button) {
        button.disabled = true;
        button.textContent = 'Sending…';
    }

    fetch(apiUrl('/api/index.php?route=user_emails'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'send_test',
            csrf_token: getCsrfToken(),
            template_id: tpl.id,
            email,
        }),
    })
        .then(async (res) => {
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error(`Invalid response: ${text.substring(0, 200)}`);
            }
            if (!res.ok && !data.error) {
                throw new Error(`HTTP ${res.status}`);
            }
            return data;
        })
        .then((data) => {
            if (data.success) {
                userAdminToast(data.message || 'Test email sent', 'success');
            } else {
                alert('Failed: ' + (data.error || data.message || 'Unknown error'));
            }
        })
        .catch((error) => {
            console.error(error);
            alert('Error sending test email: ' + error.message);
        })
        .finally(() => {
            if (button) {
                button.disabled = false;
                button.textContent = originalLabel;
            }
        });
}

window.initEmailsManagement = initEmailsManagement;
window.selectEmailTemplate = selectEmailTemplate;
window.saveEmailDelivery = saveEmailDelivery;
window.saveEmailTemplate = saveEmailTemplate;
window.sendEmailTest = sendEmailTest;
