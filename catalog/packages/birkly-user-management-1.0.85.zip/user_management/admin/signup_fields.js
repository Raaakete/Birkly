// User Management — signup field schema admin (P74-M2)

function initSignupFieldsManagement() {
    if (document.getElementById('signup-fields-container')?.dataset.signupFieldsInit === '1') {
        return;
    }
    const container = document.getElementById('signup-fields-container');
    if (!container) {
        return;
    }
    container.dataset.signupFieldsInit = '1';
    loadSignupFieldsSchema();
}

function loadSignupFieldsSchema() {
    const container = document.getElementById('signup-fields-container');
    if (!container) {
        return;
    }
    container.innerHTML = '<div class="loading-state"><p>Loading signup fields…</p></div>';

    fetch(apiUrl('/api/index.php?route=user_signup_fields&action=get_schema'))
        .then((res) => res.json())
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || 'Failed to load schema');
            }
            window.signupFieldRows = data.schema?.fields || [];
            renderSignupFieldsUI();
        })
        .catch((error) => {
            container.innerHTML = `<div class="alert alert-danger">Error: ${escapeHtml(error.message)}</div>`;
        });
}

function renderSignupFieldsUI() {
    const container = document.getElementById('signup-fields-container');
    const fields = window.signupFieldRows || [];

    let rows = '';
    fields.forEach((field, index) => {
        const contexts = (field.contexts || []).join(', ');
        rows += `
            <tr>
                <td><code>${escapeHtml(field.slug || '')}</code></td>
                <td>${escapeHtml(field.label || '')}</td>
                <td>${escapeHtml(field.type || 'text')}</td>
                <td>${field.required ? 'Yes' : 'No'}</td>
                <td>${field.unique ? 'Yes' : '—'}</td>
                <td>${escapeHtml(contexts)}</td>
                <td>
                    <button type="button" class="btn btn-sm btn-outline" onclick="editSignupField(${index})">Edit</button>
                    ${['email', 'password'].includes(field.slug) ? '' : `<button type="button" class="btn btn-sm btn-danger" onclick="deleteSignupField(${index})">Delete</button>`}
                </td>
            </tr>
        `;
    });

    container.innerHTML = `
        <div class="u-stack-6">
            <div class="main-actions-bar">
                <div class="main-actions-left plugin-actions-left">
                    <button type="button" class="btn btn-primary" onclick="openSignupFieldModal()">Add field</button>
                    <button type="button" class="btn btn-secondary" onclick="resetSignupFieldsDefaults()">Reset defaults</button>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h3 class="card-title">Signup fields</h3></div>
                <div class="card-body">
                    <p class="field-help">Configure fields for public registration and account activation forms. Email and password are always required for registration.</p>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Slug</th>
                                    <th>Label</th>
                                    <th>Type</th>
                                    <th>Required</th>
                                    <th>Unique</th>
                                    <th>Contexts</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>${rows}</tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function openSignupFieldModal(index = -1) {
    const field = index >= 0 ? (window.signupFieldRows[index] || {}) : {};
    document.getElementById('signup-field-index').value = String(index);
    document.getElementById('signup-field-slug').value = field.slug || '';
    document.getElementById('signup-field-slug').disabled = ['email', 'password'].includes(field.slug);
    document.getElementById('signup-field-label').value = field.label || '';
    document.getElementById('signup-field-type').value = field.type || 'text';
    document.getElementById('signup-field-required').checked = !!field.required;
    document.getElementById('signup-field-unique').checked = !!field.unique;
    document.getElementById('signup-field-placeholder').value = field.placeholder || '';
    document.getElementById('signup-field-help').value = field.help_text || '';
    document.getElementById('signup-field-context-register').checked = (field.contexts || ['register', 'activate']).includes('register');
    document.getElementById('signup-field-context-activate').checked = (field.contexts || ['register', 'activate']).includes('activate');
    document.getElementById('signup-field-modal').style.display = 'block';
}

function closeSignupFieldModal() {
    document.getElementById('signup-field-modal').style.display = 'none';
}

function editSignupField(index) {
    openSignupFieldModal(index);
}

function deleteSignupField(index) {
    if (!confirm('Delete this field?')) {
        return;
    }
    window.signupFieldRows.splice(index, 1);
    saveSignupFieldsSchema();
}

function saveSignupFieldFromModal() {
    const index = parseInt(document.getElementById('signup-field-index').value, 10);
    const slug = document.getElementById('signup-field-slug').value.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const contexts = [];
    if (document.getElementById('signup-field-context-register').checked) contexts.push('register');
    if (document.getElementById('signup-field-context-activate').checked) contexts.push('activate');
    if (contexts.length === 0) {
        alert('Select at least one context (register or activate).');
        return;
    }

    const field = {
        slug,
        label: document.getElementById('signup-field-label').value.trim() || slug,
        type: document.getElementById('signup-field-type').value,
        required: document.getElementById('signup-field-required').checked,
        unique: document.getElementById('signup-field-unique').checked,
        placeholder: document.getElementById('signup-field-placeholder').value,
        help_text: document.getElementById('signup-field-help').value,
        contexts,
    };

    if (!slug) {
        alert('Slug is required');
        return;
    }

    if (index >= 0) {
        window.signupFieldRows[index] = field;
    } else {
        window.signupFieldRows.push(field);
    }

    closeSignupFieldModal();
    saveSignupFieldsSchema();
}

function saveSignupFieldsSchema() {
    fetch(apiUrl('/api/index.php?route=user_signup_fields'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'save_schema',
            csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
            fields: window.signupFieldRows || [],
        }),
    })
        .then((res) => res.json())
        .then((data) => {
            if (data.success) {
                window.signupFieldRows = data.schema?.fields || [];
                renderSignupFieldsUI();
            } else {
                alert('Failed to save: ' + (data.error || 'Unknown error'));
            }
        })
        .catch((error) => {
            console.error(error);
            alert('Error saving signup fields');
        });
}

function resetSignupFieldsDefaults() {
    if (!confirm('Reset signup fields to defaults?')) {
        return;
    }
    fetch(apiUrl('/api/index.php?route=user_signup_fields'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'save_schema',
            csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
            fields: [],
        }),
    })
        .then((res) => res.json())
        .then((data) => {
            if (data.success) {
                window.signupFieldRows = data.schema?.fields || [];
                renderSignupFieldsUI();
            }
        });
}

window.initSignupFieldsManagement = initSignupFieldsManagement;
