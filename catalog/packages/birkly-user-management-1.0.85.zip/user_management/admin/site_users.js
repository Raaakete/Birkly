// User Management Admin JavaScript

function apiUrl(path) {
    return (window.Birkly && typeof Birkly.url === 'function') ? Birkly.url(path) : path;
}

let currentPage = 1;
let currentFilters = {};
let searchTimeout = null;
let selectedUserIds = new Set();
let bulkBarInitialized = false;
let lastUsersTotal = 0;
let selectionScope = 'page'; // 'page' | 'all'
let selectionMatchedCount = 0;
let selectionForceConfirm = '';

function syncProfileEntries() {
    if (typeof window.migrateP77Members === 'function') {
        window.migrateP77Members(false);
        return;
    }
    alert('Profile sync is unavailable. Reload the page or upgrade the User plugin.');
}

window.syncProfileEntries = syncProfileEntries;

function initUserManagement() {
    loadUsers();
    loadStats();
    loadRoleFilterOptions();
    initBulkBar();
    initUserRowActions();
    
    // Set up form event listener
    const form = document.getElementById('user-form');
    if (form) {
        // Form submission handled by saveUser()
    }
}

function initUserManagementTabs(root = document) {
    const page = root.querySelector('.user-management-page.plugin-page');
    if (!page || page.dataset.userManagementTabsInit === '1') {
        return;
    }

    const nav = page.querySelector('.tabs-root .tabs') || page.querySelector('.tabs');
    if (!nav) {
        return;
    }

    page.dataset.userManagementTabsInit = '1';
    initUserManagementUiEvents();

    const tabButtons = Array.from(nav.querySelectorAll('.tab[data-tab]'));
    const tabPanels = Array.from(page.querySelectorAll(':scope > .tab-panel'));

    function initializeTab(targetTab) {
        if (targetTab === 'user-list' && typeof window.initUserManagement === 'function') {
            window.initUserManagement();
        } else if (targetTab === 'groups' && typeof window.initGroupsManagement === 'function') {
            window.initGroupsManagement();
        } else if (targetTab === 'tiers' && typeof window.initTiersManagement === 'function') {
            window.initTiersManagement();
        } else if (targetTab === 'members' && typeof window.initMembersManagement === 'function') {
            window.initMembersManagement();
        } else if (targetTab === 'fieldtypes' && typeof window.initFieldtypesManagement === 'function') {
            window.initFieldtypesManagement();
        } else if (targetTab === 'permissions') {
            if (typeof window.loadCollectionPermissions === 'function') {
                window.loadCollectionPermissions();
            } else {
                const container = document.getElementById('permissions-container');
                if (container) {
                    container.innerHTML = '<div class="alert alert-danger">Collection permissions UI failed to load. Hard-refresh the page or upgrade the User plugin.</div>';
                }
            }
        } else if (targetTab === 'emails' && typeof window.initEmailsManagement === 'function') {
            window.initEmailsManagement();
        } else if (targetTab === 'signup-fields' && typeof window.initSignupFieldsManagement === 'function') {
            window.initSignupFieldsManagement();
        } else if (targetTab === 'signup-flows' && typeof window.initSignupFlowsManagement === 'function') {
            window.initSignupFlowsManagement();
        } else if (targetTab === 'membership-products' && typeof window.initMembershipProductsManagement === 'function') {
            window.initMembershipProductsManagement();
        } else if (targetTab === 'documentation' && window.BirklyPluginDocs) {
            window.BirklyPluginDocs.activate('user_management', 'documentation');
        }
    }

    function activateTab(targetTab, updateHash = true) {
        const button = tabButtons.find(btn => btn.getAttribute('data-tab') === targetTab);
        const pane = tabPanels.find(item => item.id === targetTab);
        if (!button || !pane) {
            return false;
        }

        tabButtons.forEach(btn => {
            const active = btn === button;
            btn.classList.toggle('active', active);
            btn.setAttribute('aria-selected', active ? 'true' : 'false');
        });

        tabPanels.forEach(item => {
            const active = item === pane;
            item.classList.toggle('active', active);
            item.hidden = !active;
        });

        initializeTab(targetTab);

        if (updateHash && window.history && window.location.hash.replace('#', '') !== targetTab) {
            history.replaceState(null, '', '#' + targetTab);
        }

        return true;
    }

    tabButtons.forEach(btn => {
        btn.setAttribute('role', 'tab');
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            activateTab(this.getAttribute('data-tab'));
        });
    });

    tabPanels.forEach(pane => {
        pane.setAttribute('role', 'tabpanel');
        pane.hidden = !pane.classList.contains('active');
    });

    const hash = window.location.hash.replace('#', '');
    if (hash) {
        activateTab(hash, false);
    } else {
        const activeButton = tabButtons.find(btn => btn.classList.contains('active')) || tabButtons[0];
        if (activeButton) {
            activateTab(activeButton.getAttribute('data-tab'), false);
        }
    }
}

function initBulkBar() {
    if (bulkBarInitialized) return;
    bulkBarInitialized = true;

    const actionSelect = document.getElementById('users-bulk-action');
    if (!actionSelect) return;

    // Ensure tier options are available for bulk tier change
    loadUserTierOptions();

    actionSelect.addEventListener('change', () => {
        const op = actionSelect.value;
        const statusSel = document.getElementById('users-bulk-status');
        const tierSel = document.getElementById('users-bulk-tier');
        if (statusSel) statusSel.style.display = (op === 'set_status') ? '' : 'none';
        if (tierSel) tierSel.style.display = (op === 'set_tier') ? '' : 'none';
    });
}

function initUserRowActions() {
    const container = document.getElementById('users-table-container');
    if (!container || container.dataset.userRowActionsInit === '1') {
        return;
    }
    container.dataset.userRowActionsInit = '1';
    container.addEventListener('click', (event) => {
        const button = event.target.closest('[data-user-action]');
        if (!button) {
            return;
        }
        event.preventDefault();
        const action = button.getAttribute('data-user-action');
        const userId = button.getAttribute('data-user-id');
        if (!userId) {
            return;
        }
        if (action === 'edit') {
            editUser(userId);
        } else if (action === 'delete') {
            deleteUser(userId);
        } else if (action === 'restore') {
            restoreUser(userId);
        } else if (action === 'purge') {
            purgeUser(userId);
        }
    });
}

function initUserManagementUiEvents() {
    const page = document.querySelector('.user-management-page.plugin-page');
    if (!page || page.dataset.uiEventsInit === '1') {
        return;
    }
    page.dataset.uiEventsInit = '1';

    const userModal = document.getElementById('user-modal');
    if (userModal) {
        userModal.querySelectorAll('[data-user-modal-close]').forEach((button) => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                closeUserModal();
            });
        });
        const saveButton = userModal.querySelector('[data-user-modal-save]');
        if (saveButton) {
            saveButton.addEventListener('click', (event) => {
                event.preventDefault();
                saveUser();
            });
        }
        userModal.addEventListener('click', (event) => {
            if (event.target === userModal) {
                closeUserModal();
            }
        });
    }

    const permissionsPanel = document.getElementById('permissions');
    if (permissionsPanel) {
        permissionsPanel.querySelector('[data-perm-action="add"]')?.addEventListener('click', (event) => {
            event.preventDefault();
            if (typeof window.addCollectionToPermissions === 'function') {
                window.addCollectionToPermissions();
            }
        });
        permissionsPanel.querySelector('[data-perm-action="save"]')?.addEventListener('click', (event) => {
            event.preventDefault();
            if (typeof window.saveCollectionPermissions === 'function') {
                window.saveCollectionPermissions();
            }
        });
    }

    const permissionsContainer = document.getElementById('permissions-container');
    if (permissionsContainer) {
        permissionsContainer.addEventListener('click', (event) => {
            const removeButton = event.target.closest('[data-perm-remove]');
            if (!removeButton) {
                return;
            }
            event.preventDefault();
            const slug = removeButton.getAttribute('data-perm-remove');
            if (slug && typeof window.removeCollectionPermission === 'function') {
                window.removeCollectionPermission(slug);
            }
        });
        permissionsContainer.addEventListener('change', (event) => {
            const input = event.target.closest('[data-perm-collection][data-perm-tier][data-perm-key]');
            if (!input || typeof window.updateCollectionPermission !== 'function') {
                return;
            }
            const collectionSlug = input.getAttribute('data-perm-collection');
            const tierId = input.getAttribute('data-perm-tier');
            const permission = input.getAttribute('data-perm-key');
            if (!collectionSlug || !tierId || !permission) {
                return;
            }
            let value;
            if (input.type === 'checkbox') {
                value = input.checked;
            } else if (permission === 'max_entries') {
                value = input.value ? parseInt(input.value, 10) : null;
            } else {
                value = input.value;
            }
            window.updateCollectionPermission(collectionSlug, tierId, permission, value);
        });
    }
}

function loadUsers(page = 1, filters = {}) {
    currentPage = page;
    currentFilters = filters;
    // Reset selection when list changes
    selectedUserIds = new Set();
    selectionScope = 'page';
    selectionMatchedCount = 0;
    selectionForceConfirm = '';
    updateBulkSelectionUI();
    
    const params = new URLSearchParams({
        action: 'list',
        limit: 50,
        offset: (page - 1) * 50,
        ...filters
    });
    
    fetch(apiUrl(`/api/index.php?route=user_admin&${params}`))
        .then(async res => {
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                if (res.status === 404) {
                    console.error('loadUsers 404 - Full response:', text);
                    try {
                        const errorData = JSON.parse(text);
                        if (errorData.debug) {
                            console.error('Debug info:', errorData.debug);
                            console.error('Available routes:', errorData.debug.available_routes);
                            console.error('User management active:', errorData.debug.user_management_active);
                        }
                    } catch (e2) {
                        // Not JSON, log raw response
                        console.error('404 response (not JSON):', text.substring(0, 500));
                    }
                    throw new Error('API route not found. Please check if the user management plugin is active.');
                }
                throw new Error(`Invalid JSON response: ${text.substring(0, 200)}`);
            }
            
            if (!res.ok) {
                if (data.debug) {
                    console.error('loadUsers error debug:', data.debug);
                }
                throw new Error(data.error || data.message || `HTTP ${res.status}: ${res.statusText}`);
            }
            return data;
        })
        .then(data => {
            if (data.users) {
                renderUsersTable(data.users, data.total || 0);
                renderPagination(data.total || 0, 50, page);
                // Keep stats in sync
                loadStats();
                lastUsersTotal = data.total || 0;
            } else if (data.error) {
                showError('Failed to load users: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error loading users:', error);
            // Don't break the page - show error but keep tabs visible
            const container = document.getElementById('users-table-container');
            if (container) {
                // Only update if container exists and is empty or has error
                const currentContent = container.innerHTML.trim();
                if (!currentContent || currentContent.includes('alert')) {
                    container.innerHTML = `
                        <div class="alert alert-warning">
                            <strong>Error loading users:</strong> ${escapeHtml(error.message)}
                            <br><small>Please refresh the page to try again.</small>
                        </div>
                    `;
                }
            }
            // Always show error message
            showError('Error loading users: ' + error.message);
        });
}

function renderUsersTable(users, total) {
    const container = document.getElementById('users-table-container');
    if (!container) {
        console.error('Users table container not found');
        showError('Users table container not found. Please refresh the page.');
        return;
    }
    
    if (!users || users.length === 0) {
        container.innerHTML = '<div class="empty-state"><p class="empty-state__description">No users found</p></div>';
        return;
    }
    
    let html = `
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 36px;">
                            <input type="checkbox" id="users-select-all-inline" onchange="toggleSelectAllUsers(this.checked)">
                        </th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Verified</th>
                        <th>2FA</th>
                        <th>Tier</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    users.forEach(user => {
        const isDeleted = (user.deleted ?? false) === true;
        const statusBadge = isDeleted
            ? '<span class="badge badge-danger" title="Soft-deleted">Deleted</span>'
            : getStatusBadge(user.status || 'active');
        const roleBadge = getRoleBadge(user.role || 'member');
        const tierBadge = getTierBadge(user.tier || 'free');
        const createdDate = user.created_at ? new Date(user.created_at).toLocaleDateString() : 'N/A';
        
        // Check verification status from user data
        const emailVerified = user.email_verified || user.verified || false;
        const verifiedBadge = emailVerified 
            ? '<span class="badge badge-success" title="Email verified">✓</span>'
            : '<span class="badge badge-warning" title="Email not verified">⚠</span>';
        
        // 2FA status - will be loaded asynchronously if available
        const twofaBadge = user._2fa_enabled 
            ? '<span class="badge badge-success" title="2FA enabled">✓</span>'
            : '<span class="badge badge-neutral" title="2FA disabled">—</span>';
        
        // Escape user ID for use in data attribute (safe for HTML)
        const safeUserId = escapeHtml(user.id);
        
        const safeId = escapeHtml(user.id);
        const safeIdJs = String(user.id).replace(/\\/g, '\\\\').replace(/'/g, "\\'");

        const actionsHtml = isDeleted
            ? `
                <button type="button" class="btn btn-sm btn-success" data-user-action="restore" data-user-id="${safeId}" title="Restore">
                    Restore
                </button>
                <button type="button" class="btn btn-sm btn-danger" data-user-action="purge" data-user-id="${safeId}" title="Permanently delete">
                    Purge
                </button>
              `
            : `
                <button type="button" class="btn btn-sm btn-outline" data-user-action="edit" data-user-id="${safeId}" title="Edit">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                    </svg>
                </button>
                <button type="button" class="btn btn-sm btn-danger" data-user-action="delete" data-user-id="${safeId}" title="Delete">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3,6 5,6 21,6"></polyline>
                        <path d="M19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"></path>
                    </svg>
                </button>
              `;

        html += `
            <tr>
                <td>
                    <input type="checkbox" class="user-row-select" data-user-id="${safeId}" onchange="toggleSelectUser('${safeIdJs}', this.checked)">
                </td>
                <td>${escapeHtml(user.name || user.username || user.email || 'N/A')}</td>
                <td>${escapeHtml(user.email || 'N/A')}</td>
                <td>${roleBadge}</td>
                <td>${statusBadge}</td>
                <td>${verifiedBadge}</td>
                <td data-user-id="${safeUserId}" class="twofa-status-cell">${twofaBadge}</td>
                <td>${tierBadge}</td>
                <td>${createdDate}</td>
                <td>
                    <div class="cell-actions btn-group">
                        ${actionsHtml}
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
    // Sync selection state with newly rendered rows
    syncRenderedSelectionState();
    
    // Load 2FA status for all users asynchronously (non-blocking)
    users.forEach(user => {
        // Only fetch if user has an ID
        if (!user.id) {
            return;
        }
        
        // Use POST instead of GET to ensure action is passed correctly
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
        fetch(apiUrl('/api/index.php?route=user_admin'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'get_user_status',
                user_id: user.id,
                csrf_token: csrfToken
            })
        })
            .then(async res => {
                const text = await res.text();
                let data;
                try {
                    data = JSON.parse(text);
                } catch (e) {
                    // If it's a 404 or other error, just return null - don't break the page
                    if (res.status === 404 || res.status >= 400) {
                        return null;
                    }
                    // For other errors, also return null to prevent breaking
                    return null;
                }
                
                if (!res.ok) {
                    // Don't throw error - just silently fail (status already shown)
                    return null;
                }
                return data;
            })
            .then(data => {
                // Find the status cell using data attribute - more robust than class selector
                // Use querySelectorAll and filter to avoid selector issues with special characters
                const allCells = document.querySelectorAll('.twofa-status-cell');
                let statusCell = null;
                for (const cell of allCells) {
                    if (cell.getAttribute('data-user-id') === user.id) {
                        statusCell = cell;
                        break;
                    }
                }
                
                if (!data) {
                    // Set default status on error - don't break the page
                    if (statusCell) {
                        statusCell.innerHTML = '<span class="badge badge-neutral" title="2FA status unknown">—</span>';
                    }
                    return;
                }
                
                if (statusCell && data.success) {
                    if (data['2fa_enabled']) {
                        statusCell.innerHTML = '<span class="badge badge-success" title="2FA enabled">✓</span>';
                    } else {
                        statusCell.innerHTML = '<span class="badge badge-neutral" title="2FA disabled">—</span>';
                    }
                }
            })
            .catch(() => {
                // Silently fail - 2FA status is not critical, don't break the page
                const allCells = document.querySelectorAll('.twofa-status-cell');
                let statusCell = null;
                for (const cell of allCells) {
                    if (cell.getAttribute('data-user-id') === user.id) {
                        statusCell = cell;
                        break;
                    }
                }
                if (statusCell) {
                    statusCell.innerHTML = '<span class="badge badge-neutral" title="2FA status unknown">—</span>';
                }
            });
    });
}

function updateBulkSelectionUI() {
    const countEl = document.getElementById('users-selected-count');
    const scopeEl = document.getElementById('users-selection-scope');
    if (countEl) {
        if (selectionScope === 'all') {
            countEl.textContent = `All matching selected (${selectionMatchedCount || lastUsersTotal})`;
        } else {
            countEl.textContent = `${selectedUserIds.size} selected`;
        }
    }
    if (scopeEl) {
        if (selectionScope === 'all') {
            scopeEl.textContent = 'All matching';
            scopeEl.className = 'badge badge-warning';
        } else {
            scopeEl.textContent = 'Page';
            scopeEl.className = 'badge badge-neutral';
        }
    }
    const selectAllTop = document.getElementById('users-select-all');
    const selectAllInline = document.getElementById('users-select-all-inline');
    if (selectAllTop) selectAllTop.checked = false;
    if (selectAllInline) selectAllInline.checked = false;
}

function syncRenderedSelectionState() {
    document.querySelectorAll('.user-row-select').forEach(cb => {
        const id = cb.getAttribute('data-user-id');
        cb.checked = selectedUserIds.has(id);
    });
    const countEl = document.getElementById('users-selected-count');
    if (countEl) countEl.textContent = `${selectedUserIds.size} selected`;
}

function toggleSelectUser(userId, checked) {
    // Any manual row selection implies "page" scope
    selectionScope = 'page';
    if (checked) {
        selectedUserIds.add(userId);
    } else {
        selectedUserIds.delete(userId);
    }
    const countEl = document.getElementById('users-selected-count');
    if (countEl) countEl.textContent = `${selectedUserIds.size} selected`;
}

function toggleSelectAllUsers(checked) {
    selectionScope = 'page';
    const rowCheckboxes = document.querySelectorAll('.user-row-select');
    rowCheckboxes.forEach(cb => {
        const id = cb.getAttribute('data-user-id');
        cb.checked = checked;
        if (checked) selectedUserIds.add(id);
        else selectedUserIds.delete(id);
    });

    const countEl = document.getElementById('users-selected-count');
    if (countEl) countEl.textContent = `${selectedUserIds.size} selected`;

    const selectAllTop = document.getElementById('users-select-all');
    const selectAllInline = document.getElementById('users-select-all-inline');
    if (selectAllTop) selectAllTop.checked = checked;
    if (selectAllInline) selectAllInline.checked = checked;
}

function selectAllMatchingUsers() {
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    fetch(apiUrl('/api/index.php?route=user_admin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'bulk_query_preview',
            filters: currentFilters,
            search: currentFilters.search || '',
            csrf_token: csrfToken
        })
    })
        .then(res => res.json().then(data => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok || !data?.success) throw new Error(data.error || 'Preview failed');
            const matched = data.matched ?? 0;
            const limit = data.limit ?? 1000;
            const forceLimit = data.force_limit ?? 5000;

            if (matched <= 0) {
                showError('No users match the current filters/search');
                return;
            }

            // If above safety cap, require explicit typed confirmation
            selectionForceConfirm = '';
            if (matched > limit) {
                const entered = prompt(`This matches ${matched} users (limit ${limit}). To force up to ${forceLimit}, type BULK_OK to continue:`, '');
                if (entered !== 'BULK_OK') {
                    showError('Cancelled');
                    return;
                }
                selectionForceConfirm = 'BULK_OK';
            } else {
                if (!confirm(`Select ALL ${matched} user(s) matching current filters/search (across pages)?`)) {
                    return;
                }
            }

            selectionScope = 'all';
            selectionMatchedCount = matched;
            selectedUserIds = new Set(); // not used in this mode
            updateBulkSelectionUI();
        })
        .catch(err => {
            console.error('Select all matching preview error:', err);
            showError('Select all matching failed: ' + err.message);
        });
}

function applyBulkUserAction() {
    const op = document.getElementById('users-bulk-action')?.value || '';
    if (!op) {
        showError('Please choose a bulk action');
        return;
    }
    if (selectionScope === 'page' && selectedUserIds.size === 0) {
        showError('No users selected');
        return;
    }

    const opLabel =
        op === 'delete' ? 'delete (soft)' :
        op === 'restore' ? 'restore' :
        op === 'purge' ? 'purge (hard delete)' :
        op === 'set_status' ? 'set status' :
        op === 'set_tier' ? 'set tier' :
        op;

    let value = null;
    if (op === 'set_status') {
        value = document.getElementById('users-bulk-status')?.value || '';
        if (!value) {
            showError('Please choose a status');
            return;
        }
    } else if (op === 'set_tier') {
        value = document.getElementById('users-bulk-tier')?.value || '';
        if (!value) {
            showError('Please choose a tier');
            return;
        }
    }

    const targetCount = selectionScope === 'all' ? lastUsersTotal : selectedUserIds.size;
    if (!confirm(`Apply "${opLabel}" to ${targetCount} user(s)?`)) {
        return;
    }

    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    const payload = selectionScope === 'all'
        ? {
            action: 'bulk_query',
            op,
            value,
            filters: currentFilters,
            search: currentFilters.search || '',
            force: selectionForceConfirm === 'BULK_OK',
            confirm: selectionForceConfirm || '',
            csrf_token: csrfToken
        }
        : {
            action: 'bulk',
            op,
            ids: Array.from(selectedUserIds),
            value,
            csrf_token: csrfToken
        };

    fetch(apiUrl('/api/index.php?route=user_admin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
        .then(res => res.json().then(data => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) throw new Error(data.error || data.message || 'Bulk action failed');
            const s = data.summary || {};
            const label = selectionScope === 'all' ? `Bulk ${op} (all matching)` : `Bulk ${op}`;
            if ((s.failed || 0) > 0) {
                showError(`${label} completed: ${s.succeeded || 0} ok, ${s.failed || 0} failed`);
                console.error('Bulk failures:', s.failures || []);
            } else {
                showSuccess(`${label} completed: ${s.succeeded || 0} updated`);
            }
            selectedUserIds = new Set();
            selectionScope = 'page';
            updateBulkSelectionUI();
            loadUsers(currentPage, currentFilters);
        })
        .catch(err => {
            console.error('Bulk action error:', err);
            showError('Bulk action error: ' + err.message);
        });
}

function renderPagination(total, perPage, currentPage) {
    const container = document.getElementById('users-pagination');
    const totalPages = Math.ceil(total / perPage);
    
    if (totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let html = '<div class="pagination">';
    
    // Previous button
    if (currentPage > 1) {
        html += `<button class="btn btn-sm btn-outline" onclick="loadUsers(${currentPage - 1}, currentFilters)">Previous</button>`;
    }
    
    // Page numbers
    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
            html += `<button class="btn btn-sm ${i === currentPage ? 'btn-primary' : 'btn-outline'}" onclick="loadUsers(${i}, currentFilters)">${i}</button>`;
        } else if (i === currentPage - 3 || i === currentPage + 3) {
            html += '<span class="px-2">...</span>';
        }
    }
    
    // Next button
    if (currentPage < totalPages) {
        html += `<button class="btn btn-sm btn-outline" onclick="loadUsers(${currentPage + 1}, currentFilters)">Next</button>`;
    }
    
    html += '</div>';
    container.innerHTML = html;
}

function loadStats() {
    const container = document.getElementById('users-stats');
    if (!container) return;

    fetch(apiUrl('/api/index.php?route=user_admin&action=stats'))
        .then(res => res.json())
        .then(data => {
            if (!data || (!data.success && !data.stats)) {
                return;
            }
            const stats = data.stats || {};

            const items = [
                { label: 'Total', value: stats.total ?? 0, variant: 'secondary' },
                { label: 'Active', value: stats.active ?? 0, variant: 'success' },
                { label: 'Pending', value: stats.pending ?? 0, variant: 'warning' },
                { label: 'Inactive', value: stats.inactive ?? 0, variant: 'secondary' },
                { label: 'Deleted', value: stats.deleted ?? 0, variant: 'danger' },
            ];

            container.innerHTML = items.map(i => `
                <span class="badge badge-${i.variant}">
                    ${escapeHtml(i.label)}: <strong>${i.value}</strong>
                </span>
            `).join('');
        })
        .catch(() => {
            // Non-critical; ignore
        });
}

function openAddUserModal() {
    resetUserForm();
    document.getElementById('user-modal-title').textContent = 'Add New User';
    document.getElementById('user-password').required = true;
    document.getElementById('password-required').style.display = 'inline';
    document.getElementById('password-help').textContent = 'Password is required for new users';
    
    // Load default tier from settings
    loadDefaultTierForNewUser();

    // NOTE: This file previously had a `switchTab()` implementation that hid `.tab-content`,
    // which is also used by the main User Management page tabs. That caused the whole page
    // to go blank after opening the modal (until refresh). The user modal has no internal tabs,
    // so we don't need to switch anything here.
    document.getElementById('user-modal').style.display = 'block';
}

function closeUserModal() {
    document.getElementById('user-modal').style.display = 'none';
    resetUserForm();
}

function resetUserForm() {
    document.getElementById('user-form').reset();
    document.getElementById('user-id').value = '';
    document.getElementById('user-password').required = false;
    document.getElementById('password-required').style.display = 'none';
    document.getElementById('password-help').textContent = 'Leave blank to keep existing password when editing';
    
    // Load tiers and set default tier
    loadUserTierOptions();
}

function editUser(userId) {
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    fetch(apiUrl('/api/index.php?route=user_admin'), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'get',
            id: userId,
            csrf_token: csrfToken
        })
    })
        .then(async res => {
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                if (res.status === 404) {
                    console.error('editUser 404 - Route not found. Response:', text.substring(0, 200));
                    throw new Error('API route not found. Please check if the user management plugin is active.');
                }
                throw new Error(`Invalid JSON response: ${text.substring(0, 200)}`);
            }
            
            if (!res.ok) {
                if (data.debug) {
                    console.error('Available routes:', data.debug.available_routes);
                }
                throw new Error(data.error || data.message || `HTTP ${res.status}`);
            }
            return data;
        })
        .then(data => {
            if (data.user) {
                const user = data.user;
                
                document.getElementById('user-id').value = user.id;
                document.getElementById('user-name').value = user.name || user.username || '';
                document.getElementById('user-email').value = user.email || '';
                document.getElementById('user-status').value = user.status || 'active';
                
                // Load tiers and set user's tier
                loadUserTierOptions(() => {
                    document.getElementById('user-tier').value = user.tier || 'all';
                });
                document.getElementById('user-approved').checked = user.approved || false;
                document.getElementById('user-password').value = '';
                document.getElementById('user-password').required = false;
                document.getElementById('password-required').style.display = 'none';
                
                // Show reset password button only when editing
                document.getElementById('reset-password-btn').style.display = 'inline-block';
                
                // Load verification and 2FA status
                loadUserVerificationStatus(userId);
                loadUser2FAStatus(userId);
                renderUserActivity(data.activity || []);
                
                document.getElementById('user-modal-title').textContent = 'Edit User';
                document.getElementById('user-modal').style.display = 'block';
            } else {
                alert('Failed to load user data');
            }
        })
        .catch(error => {
            alert('Error loading user data: ' + error.message);
        });
}

function loadUserVerificationStatus(userId) {
    // Get user data which includes email_verified status
    fetch(apiUrl(`/api/index.php?route=user_admin&action=get&id=${userId}`))
        .then(res => res.json())
        .then(data => {
            const statusDiv = document.getElementById('email-verification-status');
            const resendBtn = document.getElementById('resend-verification-btn');
            
            const verified = data.user?.email_verified || data.user?.verified || false;
            
            if (verified) {
                statusDiv.innerHTML = '<span class="badge badge-success">✓ Verified</span>';
                resendBtn.style.display = 'none';
            } else {
                statusDiv.innerHTML = '<span class="badge badge-warning">⚠ Not Verified</span>';
                resendBtn.style.display = 'inline-block';
                resendBtn.onclick = () => resendVerificationEmail(userId);
            }
        })
        .catch(error => {
            document.getElementById('email-verification-status').innerHTML = '<span class="badge badge-neutral">Unknown</span>';
        });
}

function loadUser2FAStatus(userId) {
    // Get user status (verification and 2FA) via admin API
    fetch(apiUrl(`/api/index.php?route=user_admin&action=get_user_status&user_id=${userId}`))
        .then(res => res.json())
        .then(data => {
            const statusDiv = document.getElementById('2fa-status');
            const manageBtn = document.getElementById('manage-2fa-btn');
            
            if (data.success) {
                if (data['2fa_enabled']) {
                    statusDiv.innerHTML = '<span class="badge badge-success">✓ Enabled</span>';
                    manageBtn.textContent = 'Disable 2FA';
                    manageBtn.className = 'btn btn-sm btn-danger';
                    manageBtn.style.display = 'inline-block';
                    manageBtn.onclick = () => manageUser2FA(userId);
                } else {
                    statusDiv.innerHTML = '<span class="badge badge-neutral">Disabled</span>';
                    manageBtn.style.display = 'none';
                }
            } else {
                statusDiv.innerHTML = '<span class="badge badge-neutral">Unknown</span>';
                manageBtn.style.display = 'none';
            }
        })
        .catch(error => {
            const statusDiv = document.getElementById('2fa-status');
            statusDiv.innerHTML = '<span class="badge badge-neutral">Unknown</span>';
            const manageBtn = document.getElementById('manage-2fa-btn');
            manageBtn.style.display = 'none';
        });
}

function resendVerificationEmail(userId) {
    const targetUserId = userId || document.getElementById('user-id').value;
    if (!targetUserId) {
        alert('User ID required');
        return;
    }
    
    const btn = event?.target || document.getElementById('resend-verification-btn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Sending...';
    
    fetch(apiUrl('/api/index.php?route=user_verification&action=resend'), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            user_id: targetUserId,
            _csrf: document.querySelector('meta[name="csrf-token"]')?.content || ''
        })
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert('Verification email sent successfully');
                loadUserVerificationStatus(targetUserId);
            } else {
                alert(data.message || 'Failed to send verification email');
            }
        })
        .catch(error => {
            alert('Error sending verification email: ' + error.message);
        })
        .finally(() => {
            btn.disabled = false;
            btn.textContent = originalText;
        });
}

function resetUserPassword(userId) {
    const targetUserId = userId || document.getElementById('user-id').value;
    if (!targetUserId) {
        alert('User ID required');
        return;
    }
    
    if (!confirm('Send password reset email to this user?')) {
        return;
    }
    
    const btn = event?.target || document.getElementById('reset-password-btn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Sending...';
    
    // Get user email first
    fetch(apiUrl(`/api/index.php?route=user_admin&action=get&id=${targetUserId}`))
        .then(res => res.json())
        .then(data => {
            if (!data.user || !data.user.email) {
                throw new Error('User email not found');
            }
            
            return fetch(apiUrl('/api/index.php?route=password_reset&action=request'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email: data.user.email
                })
            });
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'ok') {
                alert('Password reset email sent successfully');
            } else {
                alert(data.message || 'Failed to send password reset email');
            }
        })
        .catch(error => {
            alert('Error sending password reset email: ' + error.message);
        })
        .finally(() => {
            btn.disabled = false;
            btn.textContent = originalText;
        });
}

function manageUser2FA(userId) {
    const targetUserId = userId || document.getElementById('user-id').value;
    if (!targetUserId) {
        showError('User ID required');
        return;
    }

    if (!confirm('Disable two-factor authentication for this user? They will be able to log in without a second factor.')) {
        return;
    }

    const btn = document.getElementById('manage-2fa-btn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Disabling...';

    fetch(apiUrl('/api/index.php?route=user_admin'), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'disable_2fa',
            id: targetUserId,
            csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || ''
        })
    })
        .then(res => res.json())
        .then(data => {
            if (!data.success) {
                throw new Error(data.error || data.message || 'Failed to disable 2FA');
            }
            showSuccess(data.message || '2FA disabled successfully');
            loadUser2FAStatus(targetUserId);
            loadUserActivity(targetUserId);
        })
        .catch(error => {
            showError('Error disabling 2FA: ' + error.message);
        })
        .finally(() => {
            btn.disabled = false;
            btn.textContent = originalText;
        });
}

function saveUser() {
    const form = document.getElementById('user-form');
    const formData = new FormData(form);
    const userId = document.getElementById('user-id').value;
    const isEditing = userId && userId.trim() !== '';
    
    const userData = {
        name: (formData.get('name') || '').trim(),
        email: (formData.get('email') || '').trim(),
        status: formData.get('status'),
        tier: formData.get('tier') || 'all',
        approved: document.getElementById('user-approved')?.checked || false
    };
    
    // Add password if provided
    const password = formData.get('password');
    if (password) {
        userData.password = password;
    }
    
    // Validate
    if (!userData.name || !userData.email) {
        showError('Name and email are required');
        return;
    }
    
    if (!isEditing && !password) {
        showError('Password is required for new users');
        return;
    }
    
    const action = isEditing ? 'update' : 'create';
    const url = apiUrl('/api/index.php?route=user_admin');
    
    // Get CSRF token
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: action,
            id: userId || undefined,
            ...userData,
            csrf_token: csrfToken
        })
    })
    .then(res => {
        if (!res.ok) {
            return res.json().then(data => {
                throw new Error(data.error || `HTTP ${res.status}: ${res.statusText}`);
            });
        }
        return res.json();
    })
        .then(data => {
            if (data.success || data.user) {
                showSuccess(isEditing ? 'User updated successfully' : 'User created successfully');
                closeUserModal();
                // Reload users with error handling to prevent blank page
                try {
                    loadUsers(currentPage, currentFilters);
                } catch (e) {
                    console.error('Error reloading users after save:', e);
                    showError('User saved but failed to reload list. Please refresh the page.');
                }
            } else {
                showError('Failed to save user: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error saving user:', error);
            // Check if it's a 404 - route not found
            if (error.message.includes('404') || error.message.includes('Not Found')) {
                showError('API route not found. The user management plugin may not be active. Please refresh the page.');
            } else {
                showError('Failed to save user: ' + error.message);
            }
        });
}

function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
        return;
    }
    
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    
    function postDelete(forceCancel) {
        return fetch(apiUrl('/api/index.php?route=user_admin'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'delete',
                id: userId,
                force_cancel_subscriptions: !!forceCancel,
                csrf_token: csrfToken
            })
        });
    }
    
    postDelete(false)
    .then(async res => {
        const text = await res.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            if (res.status === 404) {
                throw new Error('API route not found (404). The user management plugin may not be active.');
            }
            throw new Error(`Invalid JSON response: ${text.substring(0, 200)}`);
        }
        
        if (res.status === 409 && data.code === 'active_subscriptions') {
            const subs = Array.isArray(data.subscriptions) ? data.subscriptions : [];
            const summary = subs.map(s => `${s.id || 'subscription'} (${s.status || 'active'})`).join('\n');
            const proceed = confirm(
                'This user has active subscriptions that must be canceled before deletion:\n\n'
                + (summary || 'Active subscription(s)')
                + '\n\nCancel all subscriptions and delete this user?'
            );
            if (!proceed) {
                showError('Delete canceled. Cancel subscriptions in Commerce first, then try again.');
                return null;
            }
            return postDelete(true).then(async r2 => {
                const t2 = await r2.text();
                let d2;
                try { d2 = JSON.parse(t2); } catch (e) {
                    throw new Error(`Invalid JSON response: ${t2.substring(0, 200)}`);
                }
                if (!r2.ok) {
                    throw new Error(d2.error || d2.message || `HTTP ${r2.status}`);
                }
                return d2;
            });
        }
        
        if (!res.ok) {
            if (res.status === 404) {
                throw new Error('API route not found (404). The user management plugin may not be active.');
            }
            throw new Error(data.error || data.message || `HTTP ${res.status}: ${res.statusText}`);
        }
        return data;
    })
    .then(data => {
        if (!data) return;
        if (data.success) {
            showSuccess('User deleted successfully');
            loadUsers(currentPage, currentFilters);
        } else {
            showError('Failed to delete user: ' + (data.error || data.message || 'Unknown error'));
        }
    })
    .catch(error => {
        console.error('Error deleting user:', error);
        if (error.message.includes('404') || error.message.includes('Not Found')) {
            showError('API route not found. The user management plugin may not be active. Please refresh the page.');
        } else {
            showError('Error deleting user: ' + error.message);
        }
    });
}

function syncMembershipsFromSubscriptions() {
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

    fetch(apiUrl('/api/index.php?route=user_admin&action=membership_gaps'))
        .then(async (res) => {
            const text = await res.text();
            return JSON.parse(text);
        })
        .then((gapData) => {
            const gaps = Array.isArray(gapData.gaps) ? gapData.gaps : [];
            const preview = gaps.slice(0, 5).map((g) => g.email).join(', ');
            const suffix = gaps.length > 5 ? ` (+${gaps.length - 5} more)` : '';
            const message = gaps.length === 0
                ? 'No missing club members found. Run sync anyway to resend activation emails?'
                : `Found ${gaps.length} email(s) with active club subscriptions but no site user${preview ? `: ${preview}${suffix}` : ''}. Send activation emails now?`;

            if (!confirm(message)) {
                return null;
            }

            return fetch(apiUrl('/api/index.php?route=user_admin'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'reconcile_memberships',
                    csrf_token: csrfToken
                })
            });
        })
        .then(async (res) => {
            if (!res) return;
            const text = await res.text();
            const data = JSON.parse(text);
            if (!res.ok || !data.success) {
                throw new Error(data.error || data.message || `HTTP ${res.status}`);
            }
            const sent = data.reconcile?.activations ?? 0;
            const remaining = Array.isArray(data.gaps_after) ? data.gaps_after.length : 0;
            showSuccess(`Subscription sync complete. Activation emails sent: ${sent}. Remaining gaps: ${remaining}.`);
            loadUsers(currentPage, currentFilters);
            loadStats();
        })
        .catch((err) => {
            console.error('syncMembershipsFromSubscriptions failed:', err);
            showError('Subscription sync failed: ' + err.message);
        });
}

function purgeDeletedUsers() {
    if (!confirm('Permanently delete ALL soft-deleted users? This cannot be undone.')) {
        return;
    }

    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

    fetch(apiUrl('/api/index.php?route=user_admin'), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            action: 'purge_deleted',
            csrf_token: csrfToken
        })
    })
        .then(async res => {
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error(`Invalid JSON response: ${text.substring(0, 200)}`);
            }

            if (!res.ok) {
                throw new Error(data.error || data.message || `HTTP ${res.status}: ${res.statusText}`);
            }
            return data;
        })
        .then(data => {
            if (data.success) {
                showSuccess(`Purged ${data.purged || 0} deleted user(s)`);
                loadUsers(currentPage, currentFilters);
            } else {
                showError('Failed to purge deleted users: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(err => {
            console.error('Error purging deleted users:', err);
            showError('Error purging deleted users: ' + err.message);
        });
}

function restoreUser(userId) {
    if (!confirm('Restore this user?')) {
        return;
    }

    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

    fetch(apiUrl('/api/index.php?route=user_admin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'restore',
            id: userId,
            csrf_token: csrfToken
        })
    })
        .then(res => res.json().then(data => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) throw new Error(data.error || data.message || 'Restore failed');
            showSuccess('User restored successfully');
            loadUsers(currentPage, currentFilters);
        })
        .catch(err => {
            console.error('Error restoring user:', err);
            showError('Error restoring user: ' + err.message);
        });
}

function purgeUser(userId) {
    if (!confirm('Permanently delete this user? This cannot be undone.')) {
        return;
    }

    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

    fetch(apiUrl('/api/index.php?route=user_admin'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'purge_user',
            id: userId,
            csrf_token: csrfToken
        })
    })
        .then(res => res.json().then(data => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
            if (!ok) throw new Error(data.error || data.message || 'Purge failed');
            showSuccess('User permanently deleted');
            loadUsers(currentPage, currentFilters);
        })
        .catch(err => {
            console.error('Error purging user:', err);
            showError('Error purging user: ' + err.message);
        });
}

function handleSearch(event) {
    if (event.key === 'Enter') {
        applyFilters();
    } else {
        // Debounce search
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            applyFilters();
        }, 500);
    }
}

function applyFilters() {
    const filters = {};
    
    const search = document.getElementById('search-users').value.trim();
    if (search) {
        // Search will be handled server-side via query parameter
        filters.search = search;
    }
    
    const role = document.getElementById('filter-role').value;
    if (role) {
        filters.role = role;
    }
    
    const status = document.getElementById('filter-status').value;
    if (status) {
        filters.status = status;
    }

    const includeDeleted = document.getElementById('filter-include-deleted')?.checked || false;
    if (includeDeleted) {
        filters.include_deleted = '1';
    }
    
    loadUsers(1, filters);
}

function clearFilters() {
    document.getElementById('search-users').value = '';
    document.getElementById('filter-role').value = '';
    document.getElementById('filter-status').value = '';
    const includeDeletedEl = document.getElementById('filter-include-deleted');
    if (includeDeletedEl) includeDeletedEl.checked = false;
    loadUsers(1, {});
}

function loadUserActivity(userId) {
    const container = document.getElementById('user-activity-list');
    if (!container || !userId) {
        return;
    }

    fetch(apiUrl(`/api/index.php?route=user_admin&action=get&id=${encodeURIComponent(userId)}`))
        .then(res => res.json())
        .then(data => {
            renderUserActivity(data.activity || []);
        })
        .catch(error => {
            container.innerHTML = `<div class="alert alert-warning">Unable to load activity: ${escapeHtml(error.message)}</div>`;
        });
}

function renderUserActivity(activity) {
    const container = document.getElementById('user-activity-list');
    if (!container) {
        return;
    }

    if (!Array.isArray(activity) || activity.length === 0) {
        container.innerHTML = '<div class="empty-state empty-state--compact"><p class="empty-state__description">No recent activity recorded for this user.</p></div>';
        return;
    }

    container.innerHTML = activity.slice(0, 20).map(item => {
        const timestamp = item.timestamp ? new Date(item.timestamp).toLocaleString() : 'Unknown time';
        const action = item.action || 'activity';
        const description = item.description || action;
        const ip = item.ip ? `<span class="field-help">IP ${escapeHtml(item.ip)}</span>` : '';
        return `
            <div class="activity-item card-section">
                <div class="u-cluster-3">
                    <strong>${escapeHtml(description)}</strong>
                    <span class="field-help">${escapeHtml(timestamp)}</span>
                </div>
                <div class="field-help">
                    <code>${escapeHtml(action)}</code> ${ip}
                </div>
            </div>
        `;
    }).join('');
}

function exportUsers() {
    const params = new URLSearchParams({
        action: 'list',
        limit: 10000,
        ...currentFilters
    });
    
    window.open(apiUrl(`/api/index.php?route=user_admin&${params}&format=csv`), '_blank');
}

function getStatusBadge(status) {
    const badges = {
        'active': '<span class="badge badge-success">Active</span>',
        'inactive': '<span class="badge badge-neutral">Inactive</span>',
        'pending': '<span class="badge badge-warning">Pending</span>'
    };
    return badges[status] || '<span class="badge badge-neutral">' + status + '</span>';
}

function getRoleBadge(role) {
    const badges = {
        'vip': '<span class="badge badge-danger">VIP</span>',
        'premium': '<span class="badge badge-warning">Premium</span>',
        'subscriber': '<span class="badge badge-info">Subscriber</span>',
        'member': '<span class="badge badge-neutral">Member</span>'
    };
    return badges[role] || '<span class="badge badge-neutral">' + role + '</span>';
}

function getTierBadge(tier) {
    const badges = {
        'premium': '<span class="badge badge-warning">Premium</span>',
        'basic': '<span class="badge badge-info">Basic</span>',
        'free': '<span class="badge badge-neutral">Free</span>'
    };
    return badges[tier] || '<span class="badge badge-neutral">' + tier + '</span>';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Make functions available globally
window.initUserManagement = initUserManagement;
window.loadUsers = loadUsers;
window.openAddUserModal = openAddUserModal;
window.closeUserModal = closeUserModal;
window.saveUser = saveUser;
window.editUser = editUser;
window.deleteUser = deleteUser;
window.handleSearch = handleSearch;
window.applyFilters = applyFilters;
window.clearFilters = clearFilters;
window.exportUsers = exportUsers;

function showSuccess(message) {
    showMessage(message, 'success');
}

function showError(message) {
    showMessage(message, 'error');
}

function showMessage(message, type = 'info') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `alert alert-${type === 'error' ? 'danger' : type === 'success' ? 'success' : 'info'}`;
    messageDiv.style.position = 'fixed';
    messageDiv.style.top = '20px';
    messageDiv.style.right = '20px';
    messageDiv.style.zIndex = '9999';
    messageDiv.style.minWidth = '300px';
    messageDiv.textContent = message;
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.parentNode.removeChild(messageDiv);
        }
    }, 5000);
}

// Load tier options for user form
function loadUserTierOptions(callback) {
    const select = document.getElementById('user-tier');
    if (!select) {
        if (callback) callback();
        return;
    }
    
    fetch(apiUrl('/api/index.php?route=user_tiers&action=list'))
        .then(res => res.json())
        .then(data => {
            // Clear existing options except "All"
            select.innerHTML = '<option value="all">All</option>';

            // Also populate bulk tier select if present
            const bulkTier = document.getElementById('users-bulk-tier');
            if (bulkTier) {
                bulkTier.innerHTML = '<option value="all">All</option>';
            }
            
            if (data.success && data.tiers) {
                data.tiers.forEach(tier => {
                    if (tier.id !== 'all') {
                        const option = document.createElement('option');
                        option.value = tier.id;
                        option.textContent = tier.name || tier.id;
                        select.appendChild(option);

                        if (bulkTier) {
                            const opt2 = document.createElement('option');
                            opt2.value = tier.id;
                            opt2.textContent = tier.name || tier.id;
                            bulkTier.appendChild(opt2);
                        }
                    }
                });
            }
            
            if (callback) callback();
        })
        .catch(error => {
            console.error('Error loading tiers:', error);
            if (callback) callback();
        });
}

// Load default tier from settings for new user
function loadDefaultTierForNewUser() {
    fetch(apiUrl('/api/index.php?route=user_settings&action=get'))
        .then(res => res.json())
        .then(data => {
            if (data.success && data.settings) {
                const defaultTier = data.settings.default_tier || 'all';
                const select = document.getElementById('user-tier');
                if (select) {
                    // Make sure tiers are loaded first
                    loadUserTierOptions(() => {
                        select.value = defaultTier;
                    });
                }
            }
        })
        .catch(error => {
            console.error('Error loading default tier:', error);
            // Still load tiers even if settings fail
            loadUserTierOptions();
        });
}

// Collection Permissions
let collectionPermissions = {};
let allCollections = [];
let configuredCollections = [];
let availableTiers = [];

async function parseAdminJsonResponse(response) {
    const text = await response.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch (error) {
        throw new Error(`Invalid JSON response: ${text.substring(0, 200)}`);
    }
    if (!response.ok) {
        throw new Error(data.error || `HTTP ${response.status}: ${response.statusText}`);
    }
    return data;
}

function loadCollectionPermissions() {
    const container = document.getElementById('permissions-container');
    if (container) {
        container.innerHTML = '<div class="loading-state"><p>Loading…</p></div>';
    }

    Promise.all([
        fetch(apiUrl('/api/index.php?route=collection_permissions&action=get')).then(parseAdminJsonResponse),
        fetch(apiUrl('/api/index.php?route=user_tiers&action=list')).then(parseAdminJsonResponse),
    ])
        .then(([permsData, tiersData]) => {
            if (permsData.success) {
                allCollections = permsData.collections || [];
                const loadedPerms = permsData.permissions;
                if (Array.isArray(loadedPerms)) {
                    console.warn('API returned permissions as array, converting to object');
                    collectionPermissions = {};
                } else {
                    collectionPermissions = loadedPerms || {};
                }
                configuredCollections = Object.keys(collectionPermissions);
                if ((!tiersData.success || !tiersData.tiers) && Array.isArray(permsData.tiers)) {
                    availableTiers = permsData.tiers;
                }
            } else {
                throw new Error(permsData.error || 'Failed to load collection permissions');
            }
            if (tiersData.success) {
                availableTiers = tiersData.tiers || availableTiers || [];
            }
            renderCollectionPermissions();
        })
        .catch((error) => {
            console.error('Error loading collection permissions:', error);
            if (container) {
                container.innerHTML =
                    '<div class="alert alert-danger">Error loading permissions: ' + escapeHtml(error.message) + '</div>';
            }
        });
}

function renderCollectionPermissions() {
    const container = document.getElementById('permissions-container');
    if (!container) {
        return;
    }

    if (configuredCollections.length === 0) {
        container.innerHTML = `
            <div class="loading-state">
                <p class="field-help mb-3">No collection permissions configured yet.</p>
                <p class="field-help">Click "Add Collection" to configure permissions for a collection.</p>
            </div>
        `;
        return;
    }

    let html = '';

    configuredCollections.forEach((collectionSlug) => {
        const collection = allCollections.find((c) => c.slug === collectionSlug) || { slug: collectionSlug, name: collectionSlug };
        const perms = collectionPermissions[collectionSlug] || {};

        html += `
            <div class="card" data-collection="${escapeHtml(collectionSlug)}">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="h5 m-0">${escapeHtml(collection.name)}</h4>
                        <p class="field-help">${escapeHtml(collection.slug)}</p>
                    </div>
                    <button type="button" class="btn btn-sm btn-danger" data-perm-remove="${escapeHtml(collectionSlug)}">
                        Remove
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table table-sm table-bordered">
                            <thead>
                                <tr>
                                    <th>Tier</th>
                                    <th>Create</th>
                                    <th>Edit Own</th>
                                    <th>Edit All</th>
                                    <th>Delete Own</th>
                                    <th>Delete All</th>
                                    <th>Publish</th>
                                    <th>Max Entries</th>
                                </tr>
                            </thead>
                            <tbody>
        `;

        availableTiers.forEach((tier) => {
            const tierId = tier.id || tier;
            if (!tierId) {
                console.warn('Tier missing ID:', tier);
                return;
            }

            const tierPermsObj = perms[tierId];
            const tierPerms = (tierPermsObj && typeof tierPermsObj === 'object' && Object.keys(tierPermsObj).length > 0)
                ? tierPermsObj
                : {
                    create: false,
                    edit_own: false,
                    edit_all: false,
                    delete_own: false,
                    delete_all: false,
                    publish: false,
                    max_entries: null,
                };

            html += `
                <tr>
                    <td><strong>${escapeHtml(tier.name || tierId)}</strong></td>
                    <td class="text-center">
                        <input type="checkbox"
                               ${tierPerms.create ? 'checked' : ''}
                               data-perm-collection="${escapeHtml(collectionSlug)}"
                               data-perm-tier="${escapeHtml(tierId)}"
                               data-perm-key="create">
                    </td>
                    <td class="text-center">
                        <input type="checkbox"
                               ${tierPerms.edit_own ? 'checked' : ''}
                               data-perm-collection="${escapeHtml(collectionSlug)}"
                               data-perm-tier="${escapeHtml(tierId)}"
                               data-perm-key="edit_own">
                    </td>
                    <td class="text-center">
                        <input type="checkbox"
                               ${tierPerms.edit_all ? 'checked' : ''}
                               data-perm-collection="${escapeHtml(collectionSlug)}"
                               data-perm-tier="${escapeHtml(tierId)}"
                               data-perm-key="edit_all">
                    </td>
                    <td class="text-center">
                        <input type="checkbox"
                               ${tierPerms.delete_own ? 'checked' : ''}
                               data-perm-collection="${escapeHtml(collectionSlug)}"
                               data-perm-tier="${escapeHtml(tierId)}"
                               data-perm-key="delete_own">
                    </td>
                    <td class="text-center">
                        <input type="checkbox"
                               ${tierPerms.delete_all ? 'checked' : ''}
                               data-perm-collection="${escapeHtml(collectionSlug)}"
                               data-perm-tier="${escapeHtml(tierId)}"
                               data-perm-key="delete_all">
                    </td>
                    <td class="text-center">
                        <input type="checkbox"
                               ${tierPerms.publish ? 'checked' : ''}
                               data-perm-collection="${escapeHtml(collectionSlug)}"
                               data-perm-tier="${escapeHtml(tierId)}"
                               data-perm-key="publish">
                    </td>
                    <td class="text-center">
                        <input type="number"
                               class="input -sm input"
                               style="width: 100px; display: inline-block;"
                               value="${tierPerms.max_entries || ''}"
                               placeholder="Unlimited"
                               min="1"
                               data-perm-collection="${escapeHtml(collectionSlug)}"
                               data-perm-tier="${escapeHtml(tierId)}"
                               data-perm-key="max_entries">
                        <small class="field-help d-block">-1 or empty for unlimited</small>
                    </td>
                </tr>
            `;
        });

        html += `
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

function addCollectionToPermissions() {
    const unconfigured = allCollections.filter((c) => !configuredCollections.includes(c.slug));

    if (unconfigured.length === 0) {
        alert('All available collections are already configured.');
        return;
    }

    const options = unconfigured.map((c) => `${c.name} (${c.slug})`).join('\n');
    const selection = prompt(
        'Select a collection to configure:\n\n' + options + '\n\nEnter the collection slug:'
    );

    if (!selection) {
        return;
    }

    const collection = allCollections.find((c) => c.slug === selection.trim());
    if (!collection) {
        alert('Collection not found: ' + selection);
        return;
    }

    if (!configuredCollections.includes(collection.slug)) {
        configuredCollections.push(collection.slug);
    }
    if (!collectionPermissions[collection.slug]) {
        collectionPermissions[collection.slug] = {};
    }

    renderCollectionPermissions();
}

function removeCollectionPermission(collectionSlug) {
    if (!confirm(`Remove permissions configuration for collection "${collectionSlug}"?`)) {
        return;
    }

    configuredCollections = configuredCollections.filter((slug) => slug !== collectionSlug);
    delete collectionPermissions[collectionSlug];
    renderCollectionPermissions();
}

function updateCollectionPermission(collectionSlug, tierId, permission, value) {
    if (!collectionPermissions[collectionSlug]) {
        collectionPermissions[collectionSlug] = {};
    }
    if (!collectionPermissions[collectionSlug][tierId]) {
        collectionPermissions[collectionSlug][tierId] = {};
    }
    collectionPermissions[collectionSlug][tierId][permission] = value;
}

function saveCollectionPermissions() {
    if (Array.isArray(collectionPermissions)) {
        collectionPermissions = {};
    }

    const data = {
        action: 'save',
        csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
        permissions: collectionPermissions,
    };

    fetch(apiUrl('/api/index.php?route=collection_permissions'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    })
        .then(parseAdminJsonResponse)
        .then((data) => {
            if (data.success) {
                if (data.permissions) {
                    collectionPermissions = Array.isArray(data.permissions) ? {} : data.permissions;
                    configuredCollections = Object.keys(collectionPermissions);
                }
                alert('Permissions saved successfully');
                renderCollectionPermissions();
            } else {
                alert('Failed to save permissions: ' + (data.error || 'Unknown error'));
            }
        })
        .catch((error) => {
            console.error('Error saving permissions:', error);
            alert('Error saving permissions: ' + error.message);
        });
}

// Expose functions globally
window.initUserManagementTabs = initUserManagementTabs;
window.initUserManagement = initUserManagement;
window.loadUsers = loadUsers;
window.openAddUserModal = openAddUserModal;
window.closeUserModal = closeUserModal;
window.editUser = editUser;
window.deleteUser = deleteUser;
window.saveUser = saveUser;
window.purgeDeletedUsers = purgeDeletedUsers;
window.syncMembershipsFromSubscriptions = syncMembershipsFromSubscriptions;
window.restoreUser = restoreUser;
window.purgeUser = purgeUser;
window.applyFilters = applyFilters;
window.clearFilters = clearFilters;
window.exportUsers = exportUsers;
window.handleSearch = handleSearch;
window.loadUserTierOptions = loadUserTierOptions;
window.loadDefaultTierForNewUser = loadDefaultTierForNewUser;
window.toggleSelectAllUsers = toggleSelectAllUsers;
window.toggleSelectUser = toggleSelectUser;
window.applyBulkUserAction = applyBulkUserAction;
window.selectAllMatchingUsers = selectAllMatchingUsers;
window.loadCollectionPermissions = loadCollectionPermissions;
window.renderCollectionPermissions = renderCollectionPermissions;
window.addCollectionToPermissions = addCollectionToPermissions;
window.removeCollectionPermission = removeCollectionPermission;
window.saveCollectionPermissions = saveCollectionPermissions;
window.updateCollectionPermission = updateCollectionPermission;

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        initUserManagementTabs();
    });
} else {
    setTimeout(function() {
        initUserManagementTabs();
    }, 0);
}