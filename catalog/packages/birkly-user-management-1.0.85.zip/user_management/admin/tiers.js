/**
 * Tiers Management JavaScript (P77-M3 wizard)
 */

function apiUrl(path) {
    return (window.Birkly && typeof Birkly.url === 'function') ? Birkly.url(path) : path;
}

let currentTiers = [];
let isEditing = false;
let currentTierId = null;
let tierWizardStep = 1;
let tierCommerceActive = false;
const tierWizardMaxStep = () => (tierCommerceActive ? 5 : 4);

function initTiersManagement() {
    loadTiers();
}

function loadTiers() {
    fetch(apiUrl('/api/index.php?route=user_tiers&action=list'))
        .then(async res => {
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error(`Invalid JSON response: ${text.substring(0, 200)}`);
            }

            if (!res.ok) {
                throw new Error(data.error || data.message || `HTTP ${res.status}: ${res.statusText}`);
            }
            return data;
        })
        .then(data => {
            if (data.tiers) {
                currentTiers = data.tiers;
                tierCommerceActive = !!data.commerce_active;
                renderTiers(data.tiers);
            } else if (data.error) {
                showError('Failed to load tiers: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error loading tiers:', error);
            showError('Error loading tiers: ' + error.message);
        });
}

function renderTiers(tiers) {
    const container = document.getElementById('tiers-container');

    if (!tiers || tiers.length === 0) {
        container.innerHTML = '<div class="empty-state"><p class="empty-state__description">No tiers found. Create your first tier to get started.</p></div>';
        return;
    }

    let html = '<div class="u-grid-auto">';

    tiers.forEach(tier => {
        const typeKey = tier.fieldtype_type_key || (tier.id === 'all' ? 'user_account' : `user_account_${tier.id}`);
        html += `
            <div>
                <div class="card">
                    <div class="card-header u-row-2">
                        <h4 class="card-title">${escapeHtml(tier.name || tier.id)}</h4>
                        <div class="cell-actions btn-group">
                            <button class="btn btn-sm btn-outline" onclick="editTier('${tier.id}')" title="Edit">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                            </button>
                            ${tier.id !== 'all' ? `<button class="btn btn-sm btn-danger" onclick="deleteTier('${tier.id}')" title="Delete">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="3 6 5 6 21 6"></polyline>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                </svg>
                            </button>` : ''}
                        </div>
                    </div>
                    <div class="card-body u-stack-3">
                        <p class="field-help m-0"><code>${escapeHtml(typeKey)}</code></p>
                        ${tier.description ? `<p class="field-help">${escapeHtml(tier.description)}</p>` : ''}
                        ${tier.features && tier.features.length > 0 ? `
                            <div>
                                <strong>Features:</strong>
                                <ul class="u-stack-2">
                                    ${tier.features.map(f => `<li>${escapeHtml(f)}</li>`).join('')}
                                </ul>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    });

    html += '</div>';
    container.innerHTML = html;
}

function tierTypeKeyPreview() {
    const slug = (document.getElementById('tier-id-field')?.value || '').trim().toLowerCase();
    if (!slug || slug === 'all') {
        return 'user_account';
    }
    return `user_account_${slug}`;
}

function showTierWizardStep(step) {
    tierWizardStep = step;
    const commerceStep = document.getElementById('tier-wizard-commerce-step');
    if (commerceStep) {
        commerceStep.hidden = !tierCommerceActive;
    }

    const activePanel = tierCommerceActive ? step : (step <= 3 ? step : 5);
    document.querySelectorAll('.tier-wizard-panel').forEach((panel) => {
        const panelStep = Number(panel.getAttribute('data-tier-step'));
        panel.hidden = panelStep !== activePanel;
    });

    document.querySelectorAll('[data-tier-step-label]').forEach((badge) => {
        const labelStep = Number(badge.getAttribute('data-tier-step-label'));
        if (!tierCommerceActive && labelStep === 4) {
            badge.hidden = true;
            return;
        }
        badge.hidden = false;
        const logicalStep = !tierCommerceActive && labelStep === 5 ? 4 : labelStep;
        badge.className = 'badge ' + (logicalStep === step ? 'badge-info' : 'badge-neutral');
    });

    document.getElementById('tier-wizard-back').hidden = step <= 1;
    const isLast = step >= tierWizardMaxStep();
    document.getElementById('tier-wizard-next').hidden = isLast;
    document.getElementById('tier-wizard-save').hidden = !isLast;

    if (isLast) {
        document.getElementById('tier-confirm-type-key').textContent = tierTypeKeyPreview();
    }
}

function tierWizardNext() {
    if (tierWizardStep === 1) {
        const name = document.getElementById('tier-name').value.trim();
        const slug = document.getElementById('tier-id-field').value.trim();
        if (!name) {
            showError('Tier name is required');
            return;
        }
        if (!isEditing && !slug) {
            showError('Tier ID is required');
            return;
        }
    }
    const next = Math.min(tierWizardStep + 1, tierWizardMaxStep());
    showTierWizardStep(next);
}

function tierWizardBack() {
    showTierWizardStep(Math.max(1, tierWizardStep - 1));
}

function loadTierProfileSettings(settings) {
    settings = settings || {};
    const req = settings.requirements?.fields || [];
    ['email', 'password', 'name'].forEach((key) => {
        const field = req.find((f) => f.key === key);
        const el = document.getElementById('tier-req-' + key);
        if (el) {
            el.checked = field ? !!field.required : false;
        }
    });

    const social = settings.social || {};
    document.getElementById('tier-social-following').checked = social.enable_following !== false;
    document.getElementById('tier-social-connections').checked = social.enable_connections !== false;
    document.getElementById('tier-social-blocks').checked = social.enable_blocks !== false;

    const privacy = settings.privacy || {};
    document.getElementById('tier-privacy-visibility').value = privacy.default_visibility || 'members_only';
    document.getElementById('tier-privacy-directory').checked = privacy.directory_listed !== false;

    const commerce = settings.commerce || {};
    document.getElementById('tier-commerce-required').checked = !!commerce.payment_required_at_signup;
    document.getElementById('tier-commerce-enabled').checked = commerce.payment_enabled !== false;
    document.getElementById('tier-commerce-product').value = commerce.membership_product_ref || '';
}

function collectTierProfileSettings() {
    const settings = {
        requirements: {
            fields: ['email', 'password', 'name'].map((key) => ({
                key,
                type: key === 'email' ? 'email' : (key === 'password' ? 'password' : 'text'),
                label: key.charAt(0).toUpperCase() + key.slice(1),
                required: document.getElementById('tier-req-' + key)?.checked || false,
                builtin: true,
            })),
            custom_fields: [],
        },
        social: {
            enable_following: document.getElementById('tier-social-following').checked,
            enable_connections: document.getElementById('tier-social-connections').checked,
            enable_blocks: document.getElementById('tier-social-blocks').checked,
            auto_connect_on_mutual_follow: false,
        },
        privacy: {
            default_visibility: document.getElementById('tier-privacy-visibility').value,
            directory_listed: document.getElementById('tier-privacy-directory').checked,
            allowed_visibility_options: ['public', 'members_only', 'private'],
        },
    };

    if (tierCommerceActive) {
        settings.commerce = {
            payment_required_at_signup: document.getElementById('tier-commerce-required').checked,
            payment_enabled: document.getElementById('tier-commerce-enabled').checked,
            membership_product_ref: document.getElementById('tier-commerce-product').value.trim() || null,
        };
    }

    return settings;
}

function openAddTierModal() {
    isEditing = false;
    currentTierId = null;
    tierWizardStep = 1;
    document.getElementById('tier-modal-title').textContent = 'Create Tier';
    document.getElementById('tier-form').reset();
    document.getElementById('tier-id').value = '';
    document.getElementById('tier-id-field').disabled = false;
    document.getElementById('tier-features-list').innerHTML = '';
    loadTierProfileSettings({});
    showTierWizardStep(1);
    document.getElementById('tier-modal').style.display = 'block';
}

function closeTierModal() {
    document.getElementById('tier-modal').style.display = 'none';
    isEditing = false;
    currentTierId = null;
    tierWizardStep = 1;
}

function editTier(tierId) {
    fetch(apiUrl('/api/index.php?route=user_tiers&action=get&tier_id=' + encodeURIComponent(tierId)))
        .then((res) => res.json())
        .then((data) => {
            if (!data.success || !data.tier) {
                throw new Error(data.error || 'Tier not found');
            }
            const tier = data.tier;
            tierCommerceActive = !!data.commerce_active;

            isEditing = true;
            currentTierId = tierId;
            tierWizardStep = 1;
            document.getElementById('tier-modal-title').textContent = 'Edit Tier';
            document.getElementById('tier-id').value = tier.id;
            document.getElementById('tier-id-field').value = tier.id;
            document.getElementById('tier-id-field').disabled = true;
            document.getElementById('tier-name').value = tier.name || '';
            document.getElementById('tier-description').value = tier.description || '';

            const featuresList = document.getElementById('tier-features-list');
            featuresList.innerHTML = '';
            (tier.features || []).forEach((feature) => addFeatureToUI(feature));

            loadTierProfileSettings(data.profile_settings || {});
            showTierWizardStep(1);
            document.getElementById('tier-modal').style.display = 'block';
        })
        .catch((err) => showError(err.message));
}

function saveTier() {
    const form = document.getElementById('tier-form');
    const formData = new FormData(form);

    const tierData = {
        action: isEditing ? 'update' : 'create',
        csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
        name: formData.get('name'),
        description: formData.get('description'),
        profile_settings: collectTierProfileSettings(),
    };

    if (!isEditing) {
        tierData.id = formData.get('tier_id');
        if (!tierData.id) {
            showError('Tier ID is required');
            return;
        }
    } else {
        tierData.tier_id = currentTierId;
    }

    tierData.features = [];
    document.querySelectorAll('.tier-feature-item').forEach((item) => {
        const featureName = item.dataset.feature;
        if (featureName) {
            tierData.features.push(featureName);
        }
    });

    tierData.permissions = {
        collections: {},
        features: tierData.features,
    };

    if (!tierData.name) {
        showError('Tier name is required');
        return;
    }

    fetch(apiUrl('/api/index.php?route=user_tiers'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tierData),
    })
        .then(async (res) => {
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                throw new Error(`Invalid JSON response: ${text.substring(0, 200)}`);
            }
            if (!res.ok) {
                throw new Error(data.error || `HTTP ${res.status}: ${res.statusText}`);
            }
            return data;
        })
        .then((data) => {
            if (data.success) {
                showSuccess(isEditing ? 'Tier updated successfully' : 'Tier created successfully');
                closeTierModal();
                loadTiers();
            } else {
                showError('Failed to save tier: ' + (data.error || 'Unknown error'));
            }
        })
        .catch((error) => {
            console.error('Error saving tier:', error);
            showError('Error saving tier: ' + error.message);
        });
}

function deleteTier(tierId) {
    if (!confirm('Are you sure you want to delete this tier? This action cannot be undone.')) {
        return;
    }

    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';

    fetch(apiUrl('/api/index.php?route=user_tiers'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'delete',
            csrf_token: csrfToken,
            tier_id: tierId,
        }),
    })
        .then(async (res) => {
            const text = await res.text();
            const data = JSON.parse(text);
            if (!res.ok) {
                throw new Error(data.error || `HTTP ${res.status}`);
            }
            return data;
        })
        .then((data) => {
            if (data.success) {
                showSuccess('Tier deleted successfully');
                loadTiers();
            } else {
                showError('Failed to delete tier: ' + (data.error || 'Unknown error'));
            }
        })
        .catch((error) => showError('Error deleting tier: ' + error.message));
}

function showError(message) {
    alert('Error: ' + message);
}

function showSuccess(message) {
    alert('Success: ' + message);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function addTierFeature() {
    const input = document.getElementById('tier-feature-input');
    const featureName = input.value.trim();
    if (!featureName) {
        showError('Please enter a feature name');
        return;
    }
    if (document.querySelector(`.tier-feature-item[data-feature="${CSS.escape(featureName)}"]`)) {
        showError('Feature already added');
        return;
    }
    addFeatureToUI(featureName);
    input.value = '';
}

function addFeatureToUI(featureName) {
    const container = document.getElementById('tier-features-list');
    const item = document.createElement('div');
    item.className = 'tier-feature-item badge badge-neutral';
    item.dataset.feature = featureName;
    item.innerHTML = `
        ${escapeHtml(featureName)}
        <button type="button" class="btn btn-sm btn-ghost" onclick="removeTierFeature('${escapeHtml(featureName)}')" aria-label="Remove feature">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
    `;
    container.appendChild(item);
}

function removeTierFeature(featureName) {
    const item = document.querySelector(`.tier-feature-item[data-feature="${CSS.escape(featureName)}"]`);
    if (item) {
        item.remove();
    }
}

window.initTiersManagement = initTiersManagement;
window.loadTiers = loadTiers;
window.openAddTierModal = openAddTierModal;
window.closeTierModal = closeTierModal;
window.editTier = editTier;
window.saveTier = saveTier;
window.deleteTier = deleteTier;
window.addTierFeature = addTierFeature;
window.removeTierFeature = removeTierFeature;
window.tierWizardNext = tierWizardNext;
window.tierWizardBack = tierWizardBack;
