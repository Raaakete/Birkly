// Membership products admin (P74-M5)

function userAdminToast(message, type) {
    const toastType = type || 'success';
    if (window.Birkly && window.Birkly.Utils && typeof window.Birkly.Utils.showToast === 'function') {
        window.Birkly.Utils.showToast(message, toastType);
        return;
    }
    if (window.BirklyFeedback && typeof window.BirklyFeedback.toast === 'function') {
        window.BirklyFeedback.toast(message, toastType);
        return;
    }
    alert(message);
}

function mpEscapeHtml(text) {
    if (text == null) return '';
    const div = document.createElement('div');
    div.textContent = String(text);
    return div.innerHTML;
}

function initMembershipProductsManagement() {
    const container = document.getElementById('membership-products-container');
    if (!container) {
        return;
    }
    if (container.dataset.membershipProductsInit !== '1') {
        container.dataset.membershipProductsInit = '1';
        container.addEventListener('click', handleMembershipProductsClick);
    }
    loadMembershipProducts();
}

function handleMembershipProductsClick(event) {
    const button = event.target.closest('[data-mp-action]');
    if (!button) {
        return;
    }
    const action = button.getAttribute('data-mp-action');
    if (action === 'add') {
        addMembershipProductRow();
    } else if (action === 'save') {
        saveMembershipProducts();
    } else if (action === 'import') {
        importCommerceMappings();
    } else if (action === 'remove') {
        const index = Number(button.getAttribute('data-index'));
        if (!Number.isNaN(index)) {
            removeMembershipProductRow(index);
        }
    }
}

function loadMembershipProducts() {
    const container = document.getElementById('membership-products-container');
    container.innerHTML = '<div class="loading-state"><p>Loading membership products…</p></div>';

    fetch(apiUrl('/api/index.php?route=user_membership&action=list'))
        .then((res) => res.json())
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || 'Failed to load membership products');
            }
            window.membershipProducts = data.products || [];
            window.membershipSettings = data.settings || {};
            renderMembershipProductsUI();
        })
        .catch((error) => {
            container.innerHTML = `<div class="alert alert-danger">${mpEscapeHtml(error.message)}</div>`;
        });
}

function renderMembershipProductsUI() {
    const container = document.getElementById('membership-products-container');
    const products = window.membershipProducts || [];
    const settings = window.membershipSettings || {};

    let rows = '';
    if (products.length === 0) {
        rows = `
            <tr class="membership-products-empty">
                <td colspan="8" class="field-help">No membership products yet. Click <strong>Add product</strong> to link a Commerce subscription to a tier.</td>
            </tr>
        `;
    } else {
        products.forEach((product, index) => {
            rows += `
                <tr>
                    <td><input type="text" class="input mp-label" data-index="${index}" value="${mpEscapeHtml(product.label || '')}" placeholder="Club monthly"></td>
                    <td><input type="text" class="input mp-collection" data-index="${index}" value="${mpEscapeHtml(product.collection || '')}" placeholder="donations"></td>
                    <td><input type="text" class="input mp-entry" data-index="${index}" value="${mpEscapeHtml(product.entry_id || '')}" placeholder="support-birkly"></td>
                    <td><input type="text" class="input mp-option" data-index="${index}" value="${mpEscapeHtml(product.purchase_option_id || '')}" placeholder="monthly"></td>
                    <td><input type="text" class="input mp-tier" data-index="${index}" value="${mpEscapeHtml(product.tier_id || '')}" placeholder="club"></td>
                    <td><input type="text" class="input mp-flow" data-index="${index}" value="${mpEscapeHtml(product.signup_flow_id || '')}" placeholder="pay_then_activate"></td>
                    <td><label><input type="checkbox" class="mp-enabled" data-index="${index}" ${product.enabled ? 'checked' : ''}> On</label></td>
                    <td><button type="button" class="btn btn-ghost btn-sm" data-mp-action="remove" data-index="${index}">Remove</button></td>
                </tr>
            `;
        });
    }

    container.innerHTML = `
        <div class="u-stack-6">
            <div class="main-actions-bar">
                <div class="main-actions-left plugin-actions-left">
                    <button type="button" class="btn btn-primary" data-mp-action="save">Save products</button>
                    <button type="button" class="btn btn-secondary" data-mp-action="add">Add product</button>
                    <button type="button" class="btn btn-secondary" data-mp-action="import">Import Commerce mappings</button>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h3 class="card-title">Membership settings</h3></div>
                <div class="card-body u-stack-4">
                    <div class="field form-group">
                        <label for="mp-grace-days">Past-due grace (days)</label>
                        <input type="number" min="0" id="mp-grace-days" class="input" value="${mpEscapeHtml(String(settings.past_due_grace_days ?? 7))}">
                        <p class="field-help">Days to keep tier access after a subscription goes past due (0 = revoke immediately).</p>
                    </div>
                    <div class="field form-group">
                        <label for="mp-revoke-tier">Default tier on revoke</label>
                        <input type="text" id="mp-revoke-tier" class="input" value="${mpEscapeHtml(settings.default_tier_on_revoke || 'all')}">
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h3 class="card-title">Membership products</h3></div>
                <div class="card-body">
                    <p class="field-help">Link Commerce catalog product/option refs to a User tier and signup flow. Tier grant/revoke runs on subscription events.</p>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Label</th>
                                    <th>Collection</th>
                                    <th>Entry</th>
                                    <th>Purchase option</th>
                                    <th>Tier</th>
                                    <th>Signup flow</th>
                                    <th>Enabled</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="membership-products-rows">${rows}</tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function collectMembershipProducts() {
    const products = window.membershipProducts || [];
    return products.map((product, index) => ({
        id: product.id,
        label: document.querySelector(`.mp-label[data-index="${index}"]`)?.value || product.label || '',
        collection: document.querySelector(`.mp-collection[data-index="${index}"]`)?.value || '',
        entry_id: document.querySelector(`.mp-entry[data-index="${index}"]`)?.value || '',
        purchase_option_id: document.querySelector(`.mp-option[data-index="${index}"]`)?.value || '',
        tier_id: document.querySelector(`.mp-tier[data-index="${index}"]`)?.value || '',
        signup_flow_id: document.querySelector(`.mp-flow[data-index="${index}"]`)?.value || '',
        enabled: document.querySelector(`.mp-enabled[data-index="${index}"]`)?.checked ?? true,
    }));
}

function collectMembershipSettings() {
    return {
        past_due_grace_days: Number(document.getElementById('mp-grace-days')?.value || 7),
        default_tier_on_revoke: document.getElementById('mp-revoke-tier')?.value || 'all',
    };
}

function addMembershipProductRow() {
    window.membershipProducts = collectMembershipProducts();
    window.membershipProducts.push({
        id: 'mp_' + Date.now(),
        label: '',
        collection: '',
        entry_id: '',
        purchase_option_id: '',
        tier_id: '',
        signup_flow_id: '',
        enabled: true,
    });
    renderMembershipProductsUI();
}

function removeMembershipProductRow(index) {
    window.membershipProducts = collectMembershipProducts();
    window.membershipProducts.splice(index, 1);
    renderMembershipProductsUI();
}

function saveMembershipProducts() {
    fetch(apiUrl('/api/index.php?route=user_membership'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'save',
            csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
            products: collectMembershipProducts(),
            settings: collectMembershipSettings(),
        }),
    })
        .then((res) => res.json())
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || 'Save failed');
            }
            window.membershipProducts = data.products || [];
            window.membershipSettings = data.settings || {};
            renderMembershipProductsUI();
            if (typeof showToast === 'function') {
                showToast('Membership products saved', 'success');
            } else {
                userAdminToast('Membership products saved', 'success');
            }
        })
        .catch((error) => {
            alert(error.message);
        });
}

function importCommerceMappings() {
    fetch(apiUrl('/api/index.php?route=user_membership'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'import_mappings',
            csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
        }),
    })
        .then((res) => res.json())
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || 'Import failed');
            }
            window.membershipProducts = data.products || [];
            renderMembershipProductsUI();
            const msg = `Imported ${data.imported || 0} mapping(s), skipped ${data.skipped || 0}.`;
            if (typeof showToast === 'function') {
                showToast(msg, 'success');
            } else {
                userAdminToast(msg, 'success');
            }
        })
        .catch((error) => {
            alert(error.message);
        });
}

window.initMembershipProductsManagement = initMembershipProductsManagement;
window.addMembershipProductRow = addMembershipProductRow;
window.removeMembershipProductRow = removeMembershipProductRow;
window.saveMembershipProducts = saveMembershipProducts;
window.importCommerceMappings = importCommerceMappings;
