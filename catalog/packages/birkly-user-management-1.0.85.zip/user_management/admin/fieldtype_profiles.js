/**
 * User fieldtype profiles admin (P77-M1) — mirrors Commerce fieldtypes tab.
 */

function umFieldtypesApiUrl(path) {
    return (window.Birkly && typeof Birkly.url === 'function') ? Birkly.url(path) : path;
}

let umFieldtypeProfilesCache = [];
let umFieldtypeProfileDraft = null;
let umFieldtypesUiInit = false;

function initFieldtypesManagement() {
    if (umFieldtypesUiInit) {
        loadFieldtypeProfiles();
        return;
    }
    umFieldtypesUiInit = true;

    const panel = document.getElementById('fieldtypes');

    panel?.querySelector('[data-um-ft-action="add"]')?.addEventListener('click', (e) => {
        e.preventDefault();
        openFieldtypeProfileEditor(null);
    });

    // Modal lives outside #fieldtypes — bind on document, not the tab panel.
    document.querySelectorAll('[data-um-ft-modal-close]').forEach((btn) => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            closeFieldtypeProfileModal();
        });
    });

    document.querySelector('[data-um-ft-action="save"]')?.addEventListener('click', (e) => {
        e.preventDefault();
        saveFieldtypeProfileDraft();
    });

    const modal = document.getElementById('um-fieldtype-profile-modal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeFieldtypeProfileModal();
            }
        });
    }

    loadFieldtypeProfiles();
}

function loadFieldtypeProfiles() {
    const list = document.getElementById('um-fieldtype-profiles-list');
    if (!list) {
        return;
    }
    list.innerHTML = '<div class="loading-state"><p>Loading fieldtype profiles…</p></div>';

    fetch(umFieldtypesApiUrl('/api/index.php?route=user_fieldtype_profiles&action=list'))
        .then(async (res) => {
            const data = await res.json();
            if (!res.ok || !data.success) {
                throw new Error(data.error || `HTTP ${res.status}`);
            }
            return data;
        })
        .then((data) => {
            umFieldtypeProfilesCache = data.profiles || [];
            const commercePanel = document.getElementById('um-ft-commerce-panel');
            if (commercePanel) {
                commercePanel.dataset.commerceActive = data.commerce_active ? '1' : '0';
            }
            renderFieldtypeProfilesList(umFieldtypeProfilesCache, !!data.commerce_active);
        })
        .catch((err) => {
            list.innerHTML = '<div class="alert alert-danger">Error loading fieldtypes: ' + escapeHtml(err.message) + '</div>';
        });
}

function renderFieldtypeProfilesList(profiles, commerceActive) {
    const list = document.getElementById('um-fieldtype-profiles-list');
    if (!list) {
        return;
    }

    if (!profiles.length) {
        list.innerHTML = '<div class="empty-state"><p class="empty-state__description">No fieldtypes yet.</p></div>';
        return;
    }

    let html = '<div class="u-grid-auto">';
    profiles.forEach((profile) => {
        const settings = profile.settings || {};
        const reqCount = (settings.requirements?.fields || []).filter((f) => f.required).length;
        const social = settings.social || {};
        const socialBits = [];
        if (social.enable_following) socialBits.push('Following');
        if (social.enable_connections) socialBits.push('Connections');
        if (social.enable_blocks) socialBits.push('Blocks');
        const commerce = settings.commerce || {};
        const commerceBits = commerceActive
            ? [(commerce.payment_required_at_signup ? 'Payment at signup' : null), (commerce.payment_enabled ? 'Payment in account' : null)].filter(Boolean)
            : [];

        html += '<div class="card' + (profile.is_default ? ' card--highlight' : '') + '">'
            + '<div class="card-header u-row-2">'
            + '<div><h4 class="card-title m-0">' + escapeHtml(profile.name || profile.id) + '</h4>'
            + '<p class="field-help"><code>' + escapeHtml(profile.type_key || 'user_account') + '</code></p></div>'
            + (profile.is_default ? '<span class="badge badge-neutral">Default</span>' : '')
            + '</div>'
            + '<div class="card-body u-stack-3">'
            + '<p class="field-help m-0">' + reqCount + ' required field(s)'
            + (socialBits.length ? ' · ' + escapeHtml(socialBits.join(', ')) : '')
            + (commerceBits.length ? ' · ' + escapeHtml(commerceBits.join(', ')) : '')
            + '</p>'
            + '<div class="btn-group">'
            + '<button type="button" class="btn btn-sm btn-outline" data-um-ft-edit="' + escapeHtml(profile.id) + '">Edit</button>';
        if (!profile.is_default) {
            html += '<button type="button" class="btn btn-sm btn-danger" data-um-ft-delete="' + escapeHtml(profile.id) + '">Delete</button>';
        }
        html += '</div></div></div>';
    });
    html += '</div>';
    list.innerHTML = html;

    list.querySelectorAll('[data-um-ft-edit]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-um-ft-edit');
            const profile = umFieldtypeProfilesCache.find((p) => p.id === id);
            if (profile) {
                openFieldtypeProfileEditor(profile);
            }
        });
    });

    list.querySelectorAll('[data-um-ft-delete]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-um-ft-delete');
            if (!id || !confirm('Delete this fieldtype profile? Collections using it will need updating.')) {
                return;
            }
            postFieldtypeProfiles({ action: 'delete', id }).then(() => loadFieldtypeProfiles());
        });
    });
}

function openFieldtypeProfileEditor(profile) {
    umFieldtypeProfileDraft = profile
        ? JSON.parse(JSON.stringify(profile))
        : {
            name: '',
            settings: {
                requirements: { fields: [], custom_fields: [] },
                social: { enable_following: true, enable_connections: true, enable_blocks: true },
                privacy: { default_visibility: 'members_only', directory_listed: true },
                commerce: { payment_required_at_signup: false, payment_enabled: true },
            },
        };

    const modal = document.getElementById('um-fieldtype-profile-modal');
    if (!modal) {
        return;
    }

    document.getElementById('um-ft-profile-name').value = umFieldtypeProfileDraft.name || '';
    document.getElementById('um-ft-profile-id').value = umFieldtypeProfileDraft.id || '';

    const req = umFieldtypeProfileDraft.settings?.requirements?.fields || [];
    ['email', 'password', 'name'].forEach((key) => {
        const field = req.find((f) => f.key === key);
        const el = document.getElementById('um-ft-req-' + key);
        if (el) {
            el.checked = field ? !!field.required : false;
        }
    });

    const social = umFieldtypeProfileDraft.settings?.social || {};
    document.getElementById('um-ft-social-following').checked = !!social.enable_following;
    document.getElementById('um-ft-social-connections').checked = !!social.enable_connections;
    document.getElementById('um-ft-social-blocks').checked = !!social.enable_blocks;

    const privacy = umFieldtypeProfileDraft.settings?.privacy || {};
    const vis = document.getElementById('um-ft-privacy-visibility');
    if (vis) {
        vis.value = privacy.default_visibility || 'members_only';
    }
    document.getElementById('um-ft-privacy-directory').checked = privacy.directory_listed !== false;

    const commercePanel = document.getElementById('um-ft-commerce-panel');
    const commerce = umFieldtypeProfileDraft.settings?.commerce || {};
    if (commercePanel) {
        const show = commercePanel.dataset.commerceActive === '1';
        commercePanel.hidden = !show;
        if (show) {
            document.getElementById('um-ft-commerce-required').checked = !!commerce.payment_required_at_signup;
            document.getElementById('um-ft-commerce-enabled').checked = commerce.payment_enabled !== false;
            document.getElementById('um-ft-commerce-product').value = commerce.membership_product_ref || '';
        }
    }

    modal.style.display = 'flex';
    modal.hidden = false;
}

function closeFieldtypeProfileModal() {
    const modal = document.getElementById('um-fieldtype-profile-modal');
    if (!modal) {
        return;
    }
    modal.style.display = 'none';
    modal.hidden = true;
    umFieldtypeProfileDraft = null;
}

function collectFieldtypeProfileDraftFromForm() {
    if (!umFieldtypeProfileDraft) {
        umFieldtypeProfileDraft = { settings: {} };
    }
    umFieldtypeProfileDraft.name = document.getElementById('um-ft-profile-name').value.trim();
    umFieldtypeProfileDraft.id = document.getElementById('um-ft-profile-id').value.trim() || undefined;

    const requirements = umFieldtypeProfileDraft.settings.requirements || { fields: [], custom_fields: [] };
    const fields = [];
    ['email', 'password', 'name'].forEach((key) => {
        const el = document.getElementById('um-ft-req-' + key);
        const existing = (requirements.fields || []).find((f) => f.key === key) || { key, type: key === 'email' ? 'email' : (key === 'password' ? 'password' : 'text'), label: key };
        existing.required = el ? el.checked : false;
        fields.push(existing);
    });
    requirements.fields = fields;
    umFieldtypeProfileDraft.settings.requirements = requirements;

    umFieldtypeProfileDraft.settings.social = {
        enable_following: document.getElementById('um-ft-social-following').checked,
        enable_connections: document.getElementById('um-ft-social-connections').checked,
        enable_blocks: document.getElementById('um-ft-social-blocks').checked,
        auto_connect_on_mutual_follow: umFieldtypeProfileDraft.settings.social?.auto_connect_on_mutual_follow || false,
    };

    umFieldtypeProfileDraft.settings.privacy = {
        default_visibility: document.getElementById('um-ft-privacy-visibility').value,
        directory_listed: document.getElementById('um-ft-privacy-directory').checked,
        allowed_visibility_options: ['public', 'members_only', 'private'],
    };

    const commercePanel = document.getElementById('um-ft-commerce-panel');
    if (commercePanel && commercePanel.dataset.commerceActive === '1') {
        umFieldtypeProfileDraft.settings.commerce = {
            payment_required_at_signup: document.getElementById('um-ft-commerce-required').checked,
            payment_enabled: document.getElementById('um-ft-commerce-enabled').checked,
            membership_product_ref: document.getElementById('um-ft-commerce-product').value.trim() || null,
        };
    }

    return umFieldtypeProfileDraft;
}

function saveFieldtypeProfileDraft() {
    const profile = collectFieldtypeProfileDraftFromForm();
    if (!profile.name) {
        alert('Profile name is required');
        return;
    }
    postFieldtypeProfiles({ action: 'save', profile }).then(() => {
        closeFieldtypeProfileModal();
        loadFieldtypeProfiles();
    }).catch((err) => alert(err.message));
}

function postFieldtypeProfiles(body) {
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
    return fetch(umFieldtypesApiUrl('/api/index.php?route=user_fieldtype_profiles'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...body, csrf_token: csrf }),
    }).then(async (res) => {
        const data = await res.json();
        if (!res.ok || data.success === false) {
            throw new Error(data.error || `HTTP ${res.status}`);
        }
        return data;
    });
}

window.initFieldtypesManagement = initFieldtypesManagement;
window.loadFieldtypeProfiles = loadFieldtypeProfiles;
