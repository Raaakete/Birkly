/**
 * Members index admin tab (P77-M4).
 */

function umMembersApiUrl(path) {
    return (window.Birkly && typeof Birkly.url === 'function') ? Birkly.url(path) : path;
}

function initMembersManagement() {
    loadMembersIndex();
}

function loadMembersIndex() {
    const container = document.getElementById('members-container');
    if (!container) {
        return;
    }
    container.innerHTML = '<div class="loading-state"><p>Loading members…</p></div>';

    fetch(umMembersApiUrl('/api/index.php?route=user_members&action=list'))
        .then((res) => res.json())
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || 'Failed to load members');
            }
            renderMembersTable(data.members || []);
        })
        .catch((err) => {
            container.innerHTML = '<div class="alert alert-danger">' + escapeHtml(err.message) + '</div>';
        });
}

function renderMembersTable(members) {
    const container = document.getElementById('members-container');
    if (!members.length) {
        container.innerHTML = '<div class="empty-state"><p class="empty-state__description">No indexed members yet. Member entries with a <code>user_account</code> field appear here after save.</p></div>';
        return;
    }

    let html = '<div class="table-container"><table class="table"><thead><tr>'
        + '<th>Name</th><th>Member ID</th><th>Tier</th><th>Collection</th><th>Status</th><th></th>'
        + '</tr></thead><tbody>';

    members.forEach((member) => {
        const entryUrl = umMembersApiUrl('/admin/index.php?page=entry-editor&collection='
            + encodeURIComponent(member.collection_slug || '')
            + '&id=' + encodeURIComponent(member.entry_id || ''));
        html += '<tr>'
            + '<td>' + escapeHtml(member.name || '—') + '</td>'
            + '<td><code>' + escapeHtml(member.member_id || '') + '</code></td>'
            + '<td>' + escapeHtml(member.tier_id || '') + '</td>'
            + '<td>' + escapeHtml(member.collection_slug || '') + '</td>'
            + '<td>' + escapeHtml(member.status || '') + '</td>'
            + '<td class="table-actions">'
            + '<a class="btn btn-sm btn-outline" href="' + entryUrl + '">Open entry</a> '
            + '<button type="button" class="btn btn-sm btn-secondary" onclick="changeMemberTier(\''
            + escapeHtml(member.member_id || '') + '\', \'' + escapeHtml(member.tier_id || '') + '\')">Change tier</button>'
            + '</td>'
            + '</tr>';
    });

    html += '</tbody></table></div>';
    container.innerHTML = html;
}

function migrateP77Members(dryRun) {
    const message = dryRun
        ? 'Preview migration from User List → member collection entries?'
        : 'Create profile collection entries for User List accounts that are not yet members?\n\n'
            + 'This adds a user_account field when needed, links each account, and rebuilds the members index.';
    if (!confirm(message)) {
        return;
    }

    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
    fetch(umMembersApiUrl('/api/index.php?route=user_members'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'migrate',
            dry_run: !!dryRun,
            csrf_token: csrf,
        }),
    })
        .then((res) => res.json())
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || (data.result && data.result.errors && data.result.errors[0]) || 'Migration failed');
            }
            const r = data.result || {};
            const parts = [];
            if (r.entries_created > 0) parts.push(r.entries_created + ' created');
            if (r.entries_updated > 0) parts.push(r.entries_updated + ' updated');
            if (r.skipped > 0) parts.push(r.skipped + ' skipped');
            if (r.indexed > 0) parts.push(r.indexed + ' indexed');
            alert((dryRun ? 'Dry run: ' : '') + (parts.length ? parts.join(', ') : 'Migration complete'));
            if (!dryRun) {
                loadMembersIndex();
            }
        })
        .catch((err) => alert(err.message));
}

function reindexMembers() {
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
    fetch(umMembersApiUrl('/api/index.php?route=user_members'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reindex', csrf_token: csrf }),
    })
        .then((res) => res.json())
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || 'Reindex failed');
            }
            alert('Reindexed ' + (data.count || 0) + ' member entries');
            loadMembersIndex();
        })
        .catch((err) => alert(err.message));
}

function changeMemberTier(memberId, currentTier) {
    const tierId = window.prompt('New tier id (current: ' + (currentTier || 'all') + '):', currentTier || 'all');
    if (!tierId) {
        return;
    }
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
    fetch(umMembersApiUrl('/api/index.php?route=user_members'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'plan_upgrade',
            member_id: memberId,
            tier_id: tierId,
            csrf_token: csrf,
        }),
    })
        .then((res) => res.json())
        .then((plan) => {
            if (!plan.success) {
                throw new Error(plan.error || 'Could not plan upgrade');
            }
            let targetCollection = '';
            if (plan.mode === 'choose_collection') {
                const options = (plan.target_collections || []).join(', ');
                targetCollection = window.prompt('Target collection (required). Options: ' + options, plan.target_collections?.[0] || '') || '';
                if (!targetCollection) {
                    throw new Error('Target collection required for this tier');
                }
            } else if (plan.mode === 'cross_collection') {
                targetCollection = plan.target_collection || '';
            }
            const runChange = (fields) => fetch(umMembersApiUrl('/api/index.php?route=user_members'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'change_tier',
                    member_id: memberId,
                    tier_id: tierId,
                    target_collection: targetCollection,
                    fields: fields || {},
                    csrf_token: csrf,
                }),
            }).then((res) => res.json());

            if ((plan.missing_requirements || []).length) {
                const fieldsJson = window.prompt(
                    'Missing requirements: ' + plan.missing_requirements.join(', ')
                    + '. Enter JSON fields (e.g. {"invite_code":"ABC"}):',
                    '{}'
                );
                if (fieldsJson === null) {
                    return null;
                }
                let fields = {};
                try {
                    fields = JSON.parse(fieldsJson || '{}');
                } catch (e) {
                    throw new Error('Invalid JSON for extra fields');
                }
                return runChange(fields);
            }
            return runChange({});
        })
        .then((result) => {
            if (!result) {
                return;
            }
            if (!result.success) {
                throw new Error(result.error || 'Tier change failed');
            }
            alert('Tier updated (' + (result.mode || 'ok') + ')');
            loadMembersIndex();
        })
        .catch((err) => alert(err.message));
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text ?? '';
    return div.innerHTML;
}

window.initMembersManagement = initMembersManagement;
window.loadMembersIndex = loadMembersIndex;
window.migrateP77Members = migrateP77Members;
window.reindexMembers = reindexMembers;
window.changeMemberTier = changeMemberTier;
