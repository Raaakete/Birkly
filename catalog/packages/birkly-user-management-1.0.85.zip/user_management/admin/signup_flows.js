// Signup flows admin (P74-M3)

function initSignupFlowsManagement() {
    if (document.getElementById('signup-flows-container')?.dataset.signupFlowsInit === '1') {
        return;
    }
    const container = document.getElementById('signup-flows-container');
    if (!container) {
        return;
    }
    container.dataset.signupFlowsInit = '1';
    loadSignupFlows();
}

function loadSignupFlows() {
    const container = document.getElementById('signup-flows-container');
    container.innerHTML = '<div class="loading-state"><p>Loading signup flows…</p></div>';

    fetch(apiUrl('/api/index.php?route=user_signup&action=list_flows'))
        .then((res) => res.json())
        .then((data) => {
            if (!data.success) {
                throw new Error(data.error || 'Failed to load flows');
            }
            window.signupFlows = data.flows || [];
            renderSignupFlowsUI();
        })
        .catch((error) => {
            container.innerHTML = `<div class="alert alert-danger">${escapeHtml(error.message)}</div>`;
        });
}

function renderSignupFlowsUI() {
    const container = document.getElementById('signup-flows-container');
    const flows = window.signupFlows || [];

    let rows = '';
    flows.forEach((flow, index) => {
        const commerce = flow.commerce || {};
        rows += `
            <tr>
                <td><strong>${escapeHtml(flow.name || flow.id)}</strong><br><code>${escapeHtml(flow.id || '')}</code></td>
                <td>${escapeHtml(flow.description || '')}</td>
                <td><label class="u-row-2"><input type="checkbox" data-flow-index="${index}" class="flow-enabled" ${flow.enabled ? 'checked' : ''}> Enabled</label></td>
                <td><input type="text" class="input flow-tier" data-flow-index="${index}" value="${escapeHtml(flow.tier_id || '')}" placeholder="club"></td>
                <td><input type="text" class="input flow-redirect" data-flow-index="${index}" value="${escapeHtml(flow.redirect_url || '')}" placeholder="/club.html"></td>
                <td>
                    <input type="text" class="input flow-commerce-collection" data-flow-index="${index}" value="${escapeHtml(commerce.collection || '')}" placeholder="collection">
                    <input type="text" class="input flow-commerce-entry" data-flow-index="${index}" value="${escapeHtml(commerce.entry_id || '')}" placeholder="entry_id" style="margin-top:6px;">
                    <input type="text" class="input flow-commerce-option" data-flow-index="${index}" value="${escapeHtml(commerce.purchase_option_id || '')}" placeholder="purchase_option_id" style="margin-top:6px;">
                </td>
            </tr>
        `;
    });

    container.innerHTML = `
        <div class="u-stack-6">
            <div class="main-actions-bar">
                <div class="main-actions-left plugin-actions-left">
                    <button type="button" class="btn btn-primary" onclick="saveSignupFlows()">Save flows</button>
                </div>
            </div>
            <div class="card">
                <div class="card-header"><h3 class="card-title">Signup flows</h3></div>
                <div class="card-body">
                    <p class="field-help">Preset flows ship with the plugin. Enable a flow and wire Commerce product refs for payment steps. Payment metadata uses <code>signup_flow_id</code> and <code>signup_flow_opt_in</code>.</p>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Flow</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Tier</th>
                                    <th>Redirect</th>
                                    <th>Commerce product</th>
                                </tr>
                            </thead>
                            <tbody>${rows}</tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function collectSignupFlowOverrides() {
    const flows = window.signupFlows || [];
    return flows.map((flow, index) => {
        const enabled = document.querySelector(`.flow-enabled[data-flow-index="${index}"]`)?.checked ?? false;
        return {
            id: flow.id,
            enabled,
            tier_id: document.querySelector(`.flow-tier[data-flow-index="${index}"]`)?.value || flow.tier_id,
            redirect_url: document.querySelector(`.flow-redirect[data-flow-index="${index}"]`)?.value || flow.redirect_url,
            commerce: {
                collection: document.querySelector(`.flow-commerce-collection[data-flow-index="${index}"]`)?.value || '',
                entry_id: document.querySelector(`.flow-commerce-entry[data-flow-index="${index}"]`)?.value || '',
                purchase_option_id: document.querySelector(`.flow-commerce-option[data-flow-index="${index}"]`)?.value || '',
            },
        };
    });
}

function saveSignupFlows() {
    fetch(apiUrl('/api/index.php?route=user_signup'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'save_flows',
            csrf_token: document.querySelector('meta[name="csrf-token"]')?.content || '',
            flows: collectSignupFlowOverrides(),
        }),
    })
        .then((res) => res.json())
        .then((data) => {
            if (data.success) {
                window.signupFlows = data.flows || [];
                renderSignupFlowsUI();
                alert('Signup flows saved');
            } else {
                alert('Failed: ' + (data.error || 'Unknown error'));
            }
        })
        .catch((error) => {
            console.error(error);
            alert('Error saving signup flows');
        });
}

window.initSignupFlowsManagement = initSignupFlowsManagement;
