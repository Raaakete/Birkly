<?php
/**
 * Account activation page — set password after membership entitlement.
 */

require_once __DIR__ . '/includes/AccountActivation.php';
require_once __DIR__ . '/includes/SignupFieldSchema.php';
require_once __DIR__ . '/cms_paths.php';

$token = $_GET['token'] ?? '';
$activation = new AccountActivation();
$verify = $token !== '' ? $activation->verifyToken($token) : ['success' => false];
$clubUrl = user_management_site_url() . '/club.html';
$activationApiUrl = '/api/index.php?route=user_activation&action=complete';
if (function_exists('birkly_url')) {
    $activationApiUrl = birkly_url($activationApiUrl);
}

$schema = new SignupFieldSchema();
$activateFields = $schema->getPublicFields(SignupFieldSchema::CONTEXT_ACTIVATE);

function activation_field_input(array $field): string
{
    $slug = htmlspecialchars((string) ($field['slug'] ?? ''), ENT_QUOTES, 'UTF-8');
    $label = htmlspecialchars((string) ($field['label'] ?? $slug), ENT_QUOTES, 'UTF-8');
    $type = (string) ($field['type'] ?? 'text');
    $required = !empty($field['required']) ? ' required' : '';
    $placeholder = htmlspecialchars((string) ($field['placeholder'] ?? ''), ENT_QUOTES, 'UTF-8');
    $help = trim((string) ($field['help_text'] ?? ''));

    $html = '<label for="' . $slug . '">' . $label;
    if ($required !== '') {
        $html .= ' *';
    }
    $html .= '</label>';

    if ($type === 'textarea') {
        $html .= '<textarea id="' . $slug . '" name="' . $slug . '" class="signup-field" data-slug="' . $slug . '"' . $required;
        if ($placeholder !== '') {
            $html .= ' placeholder="' . $placeholder . '"';
        }
        $html .= '></textarea>';
    } elseif ($type === 'checkbox') {
        $html = '<label class="checkbox-row"><input type="checkbox" id="' . $slug . '" name="' . $slug . '" value="1" class="signup-field" data-slug="' . $slug . '"' . $required . '> ' . $label . '</label>';
    } else {
        $inputType = in_array($type, ['email', 'tel', 'password', 'text'], true) ? $type : 'text';
        $html .= '<input type="' . $inputType . '" id="' . $slug . '" name="' . $slug . '" class="signup-field" data-slug="' . $slug . '"' . $required;
        if ($placeholder !== '') {
            $html .= ' placeholder="' . $placeholder . '"';
        }
        if ($inputType === 'password') {
            $html .= ' minlength="8" autocomplete="new-password"';
        }
        $html .= '>';
    }

    if ($help !== '' && $type !== 'checkbox') {
        $html .= '<p class="hint">' . htmlspecialchars($help, ENT_QUOTES, 'UTF-8') . '</p>';
    }

    return $html;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activate community access</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display:flex; justify-content:center; align-items:center; min-height:100vh; margin:0; background:#f5f5f5; }
        .container { background:#fff; padding:2rem; border-radius:8px; box-shadow:0 2px 10px rgba(0,0,0,.1); max-width:420px; width:100%; }
        h1 { margin-top:0; color:#2c3e50; font-size:1.35rem; }
        label { display:block; margin-bottom:.5rem; font-weight:500; }
        input, textarea { width:100%; padding:.75rem; border:1px solid #ddd; border-radius:4px; font-size:1rem; box-sizing:border-box; margin-bottom:1rem; }
        textarea { min-height: 88px; resize: vertical; }
        .checkbox-row { display:flex; align-items:center; gap:.5rem; margin-bottom:1rem; font-weight:500; }
        .checkbox-row input { width:auto; margin:0; }
        button { width:100%; padding:.75rem; background:#3498db; color:#fff; border:none; border-radius:4px; font-size:1rem; cursor:pointer; }
        button:disabled { background:#95a5a6; }
        .message { padding:.75rem; border-radius:4px; margin-bottom:1rem; }
        .message.success { background:#d4edda; color:#155724; }
        .message.error { background:#f8d7da; color:#721c24; }
        .hint { color:#666; font-size:.9rem; margin-top:-.5rem; margin-bottom:1rem; }
    </style>
</head>
<body>
<div class="container">
    <?php if ($token === ''): ?>
        <h1>Activate access</h1>
        <p class="hint">Open the activation link from your email, or request one from the Club page on our website.</p>
    <?php elseif (!$verify['success']): ?>
        <h1>Activation link invalid</h1>
        <div class="message error"><?php echo htmlspecialchars($verify['message'] ?? 'Invalid link'); ?></div>
        <p class="hint">Request a new link from the Club page if you still have an active membership.</p>
    <?php else: ?>
        <h1>Set your password</h1>
        <p class="hint">Create a password for <strong><?php echo htmlspecialchars($verify['email'] ?? ''); ?></strong></p>
        <div id="message" class="message" style="display:none;"></div>
        <form id="activateForm">
            <?php foreach ($activateFields as $field): ?>
                <?php if (($field['slug'] ?? '') === 'password') { continue; } ?>
                <?php echo activation_field_input($field); ?>
            <?php endforeach; ?>
            <label for="password">Password *</label>
            <input type="password" id="password" name="password" required minlength="8" autocomplete="new-password">
            <label for="password2">Confirm password *</label>
            <input type="password" id="password2" name="password2" required minlength="8" autocomplete="new-password">
            <button type="submit" id="submitBtn">Activate and sign in</button>
        </form>
        <script>
        document.getElementById('activateForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const password = document.getElementById('password').value;
            const password2 = document.getElementById('password2').value;
            const messageDiv = document.getElementById('message');
            const submitBtn = document.getElementById('submitBtn');
            messageDiv.style.display = 'none';
            if (password !== password2) {
                messageDiv.className = 'message error';
                messageDiv.textContent = 'Passwords do not match.';
                messageDiv.style.display = 'block';
                return;
            }
            submitBtn.disabled = true;
            submitBtn.textContent = 'Activating…';

            const fields = {};
            document.querySelectorAll('.signup-field').forEach(function(el) {
                const slug = el.getAttribute('data-slug');
                if (!slug) return;
                if (el.type === 'checkbox') {
                    fields[slug] = el.checked ? '1' : '0';
                } else {
                    fields[slug] = el.value;
                }
            });

            try {
                const response = await fetch(<?php echo json_encode($activationApiUrl); ?>, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        token: <?php echo json_encode($token); ?>,
                        password: password,
                        fields: fields
                    })
                });
                const data = await response.json();
                if (data.success) {
                    messageDiv.className = 'message success';
                    messageDiv.textContent = data.message + ' Redirecting…';
                    messageDiv.style.display = 'block';
                    setTimeout(function() { window.location.href = <?php echo json_encode($clubUrl); ?>; }, 1200);
                } else {
                    messageDiv.className = 'message error';
                    messageDiv.textContent = data.message || data.error || 'Activation failed.';
                    messageDiv.style.display = 'block';
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Activate and sign in';
                }
            } catch (err) {
                messageDiv.className = 'message error';
                messageDiv.textContent = 'Network error. Please try again.';
                messageDiv.style.display = 'block';
                submitBtn.disabled = false;
                submitBtn.textContent = 'Activate and sign in';
            }
        });
        </script>
    <?php endif; ?>
</div>
</body>
</html>
