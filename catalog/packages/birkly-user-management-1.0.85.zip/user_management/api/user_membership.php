<?php
/**
 * Membership products API — product links, settings, Commerce mapping import (admin).
 */

declare(strict_types=1);

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/MembershipProductRegistry.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode(is_string($raw) ? $raw : '', true) ?? [];
    if ($input === [] && !empty($_POST)) {
        $input = $_POST;
    }
}

$action = $input['action'] ?? $_GET['action'] ?? 'list';
$registry = new MembershipProductRegistry();

$adminActions = ['save', 'import_mappings', 'save_settings'];
if (in_array($action, $adminActions, true)) {
    if (function_exists('requireAuth')) {
        requireAuth('manage_users');
    } elseif (function_exists('requireAdminAuth')) {
        requireAdminAuth();
    }
}

if ($method === 'POST' && in_array($action, $adminActions, true) && function_exists('validate_csrf_token')) {
    $token = $input['csrf_token'] ?? $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    if (!validate_csrf_token($token)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
        exit;
    }
}

try {
    switch ($action) {
        case 'list':
            $config = $registry->load();
            echo json_encode([
                'success' => true,
                'products' => $config['products'],
                'settings' => $config['settings'],
            ]);
            break;

        case 'save':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'Method not allowed']);
                break;
            }
            $products = is_array($input['products'] ?? null) ? $input['products'] : [];
            $settings = is_array($input['settings'] ?? null) ? $input['settings'] : [];
            $ok = $registry->save($products, $settings);
            $config = $registry->load();
            echo json_encode([
                'success' => $ok,
                'products' => $config['products'],
                'settings' => $config['settings'],
            ]);
            break;

        case 'save_settings':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'Method not allowed']);
                break;
            }
            $settings = is_array($input['settings'] ?? null) ? $input['settings'] : [];
            $config = $registry->load();
            $ok = $registry->save($config['products'], $settings);
            $config = $registry->load();
            echo json_encode(['success' => $ok, 'settings' => $config['settings']]);
            break;

        case 'import_mappings':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'Method not allowed']);
                break;
            }
            $result = $registry->importFromCommercePurchaseMappings();
            $config = $registry->load();
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result, [
                'products' => $config['products'],
            ]));
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Unknown action']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
