<?php
/**
 * Club wishes admin API — promote to roadmap (P80-M5).
 */

declare(strict_types=1);

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../../../api/session.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/ClubWishService.php';

function club_wishes_respond(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function club_wishes_require_csrf(array $input): void
{
    $token = $input['csrf_token'] ?? $input['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (function_exists('verify_csrf_token') && verify_csrf_token($token)) {
        return;
    }
    if (function_exists('validate_csrf_token') && validate_csrf_token($token)) {
        return;
    }

    club_wishes_respond(['success' => false, 'error' => 'Invalid CSRF token'], 403);
}

function club_wishes_is_admin(): bool
{
    if (function_exists('haru_secure_session_start')) {
        haru_secure_session_start();
    }

    return isset($_SESSION['user']);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST' && !empty($_POST)) {
    $input = $_POST;
} else {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '[]', true);
    $input = is_array($decoded) ? $decoded : [];
}

$action = (string) ($_GET['action'] ?? $input['action'] ?? '');
$service = new ClubWishService();

if ($action === 'promote') {
    if ($method !== 'POST') {
        club_wishes_respond(['success' => false, 'error' => 'Method not allowed'], 405);
    }
    if (!club_wishes_is_admin()) {
        club_wishes_respond(['success' => false, 'error' => 'Admin login required'], 401);
    }
    club_wishes_require_csrf($input);

    $wishId = trim((string) ($input['wish_id'] ?? $input['entry_id'] ?? $input['slug'] ?? ''));
    if ($wishId === '') {
        club_wishes_respond(['success' => false, 'error' => 'wish_id required'], 400);
    }

    $result = $service->promoteToRoadmap($wishId);
    if (empty($result['ok'])) {
        club_wishes_respond([
            'success' => false,
            'error' => (string) ($result['error'] ?? 'Could not promote wish'),
        ], 400);
    }

    club_wishes_respond([
        'success' => true,
        'roadmap_entry_id' => (string) ($result['roadmap_entry_id'] ?? ''),
        'roadmap_slug' => (string) ($result['roadmap_slug'] ?? ''),
        'message' => 'Roadmap draft created. Review and publish in admin.',
    ]);
}

club_wishes_respond(['success' => false, 'error' => 'Invalid action'], 400);
