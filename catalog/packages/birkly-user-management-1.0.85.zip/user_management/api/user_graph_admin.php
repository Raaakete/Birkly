<?php
/**
 * Admin User Graph API — mutate relationships on behalf of a profile owner (P76).
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../../../core/csrf.php';

if (function_exists('haru_secure_session_start')) {
    haru_secure_session_start();
}

if (!isset($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Admin login required']);
    exit;
}

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../includes/UserService.php';
require_once __DIR__ . '/../includes/UserGraphService.php';
require_once __DIR__ . '/../includes/RateLimiter.php';

function user_graph_admin_respond($data, $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}

if ($method === 'POST') {
    $token = $_POST['csrf_token'] ?? $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($input['csrf_token'] ?? ''));
    $csrfOk = (function_exists('verify_csrf_token') && verify_csrf_token($token))
        || (function_exists('validate_csrf_token') && validate_csrf_token($token));
    if (!$csrfOk) {
        user_graph_admin_respond(['success' => false, 'error' => 'Invalid CSRF token'], 403);
    }
}

$subjectUserId = trim((string) ($input['subject_user_id'] ?? $_GET['subject_user_id'] ?? $_POST['subject_user_id'] ?? ''));
if ($subjectUserId === '') {
    user_graph_admin_respond(['success' => false, 'error' => 'subject_user_id required'], 400);
}

$userService = new UserService();
if (!$userService->getUser($subjectUserId)) {
    user_graph_admin_respond(['success' => false, 'error' => 'Subject user not found'], 404);
}

$service = new UserGraphService();

function user_graph_admin_target_id(array $input): string
{
    return trim((string) ($input['target_user_id'] ?? $_POST['target_user_id'] ?? ''));
}

try {
    switch ($action) {
        case 'state':
            user_graph_admin_respond([
                'success' => true,
                'subject_user_id' => $subjectUserId,
                'following' => $service->listFollowing($subjectUserId),
                'followers' => $service->listFollowers($subjectUserId),
                'connected' => $service->listConnected($subjectUserId),
                'pending_in' => $service->listPendingConnectionRequests($subjectUserId),
                'blocked' => $service->listBlocked($subjectUserId),
                'summary' => $service->summaryForUser($subjectUserId),
            ]);

        case 'follow':
            if ($method !== 'POST') {
                user_graph_admin_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_admin_target_id($input);
            if ($targetId === '' || $targetId === $subjectUserId) {
                user_graph_admin_respond(['success' => false, 'error' => 'Invalid target_user_id'], 400);
            }
            $service->follow($subjectUserId, $targetId);
            user_graph_admin_respond(['success' => true]);

        case 'unfollow':
            if ($method !== 'POST') {
                user_graph_admin_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_admin_target_id($input);
            $service->unfollow($subjectUserId, $targetId);
            user_graph_admin_respond(['success' => true]);

        case 'connect':
            if ($method !== 'POST') {
                user_graph_admin_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_admin_target_id($input);
            $service->connect($subjectUserId, $targetId);
            user_graph_admin_respond(['success' => true]);

        case 'accept':
            if ($method !== 'POST') {
                user_graph_admin_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_admin_target_id($input);
            $service->accept($subjectUserId, $targetId);
            user_graph_admin_respond(['success' => true]);

        case 'reject':
            if ($method !== 'POST') {
                user_graph_admin_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_admin_target_id($input);
            $service->reject($subjectUserId, $targetId);
            user_graph_admin_respond(['success' => true]);

        case 'disconnect':
            if ($method !== 'POST') {
                user_graph_admin_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_admin_target_id($input);
            $service->disconnect($subjectUserId, $targetId);
            user_graph_admin_respond(['success' => true]);

        case 'block':
            if ($method !== 'POST') {
                user_graph_admin_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_admin_target_id($input);
            $service->block($subjectUserId, $targetId);
            user_graph_admin_respond(['success' => true]);

        case 'unblock':
            if ($method !== 'POST') {
                user_graph_admin_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_admin_target_id($input);
            $service->unblock($subjectUserId, $targetId);
            user_graph_admin_respond(['success' => true]);

        default:
            user_graph_admin_respond(['success' => false, 'error' => 'Invalid action'], 400);
    }
} catch (InvalidArgumentException $e) {
    user_graph_admin_respond(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('user_graph_admin: ' . $e->getMessage());
    user_graph_admin_respond(['success' => false, 'error' => 'User graph admin request failed'], 500);
}
