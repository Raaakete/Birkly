<?php
/**
 * Deprecated alias — use api/user_notifications.php (P81-M7).
 */

declare(strict_types=1);

require __DIR__ . '/user_notifications.php';
