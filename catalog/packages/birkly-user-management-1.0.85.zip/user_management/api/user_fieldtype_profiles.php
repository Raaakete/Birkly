<?php
/**
 * User fieldtype profiles API (P77-M1).
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../cms_paths.php';
require_once __DIR__ . '/../includes/UserFieldtypeProfileStore.php';
require_once __DIR__ . '/../init.php';

if (function_exists('requireAuth')) {
    requireAuth('manage_users');
} elseif (function_exists('requireAdminAuth')) {
    requireAdminAuth();
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw !== false ? $raw : '', true);
    $input = is_array($decoded) ? $decoded : $_POST;
}

$action = (string) ($input['action'] ?? $_GET['action'] ?? 'list');

if ($method === 'POST') {
    $token = (string) ($input['csrf_token'] ?? $_GET['csrf_token'] ?? '');
    if (function_exists('validate_csrf_token') && !validate_csrf_token($token)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
        exit;
    }
}

header('Content-Type: application/json');

$store = new UserFieldtypeProfileStore();

try {
    switch ($action) {
        case 'list':
            echo json_encode([
                'success' => true,
                'profiles' => $store->listProfiles(),
                'commerce_active' => user_management_commerce_plugin_active(),
            ]);
            break;

        case 'get':
            $id = trim((string) ($input['id'] ?? $_GET['id'] ?? ''));
            $profile = $id !== '' ? $store->getProfile($id) : null;
            if (!$profile) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Profile not found']);
                break;
            }
            echo json_encode([
                'success' => true,
                'profile' => $profile,
                'commerce_active' => user_management_commerce_plugin_active(),
            ]);
            break;

        case 'save':
            $profile = $input['profile'] ?? [];
            if (!is_array($profile) || trim((string) ($profile['name'] ?? '')) === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Profile name required']);
                break;
            }
            $saved = $store->saveProfile($profile);
            user_management_register_fieldtype_profiles();
            echo json_encode(['success' => true, 'profile' => $saved]);
            break;

        case 'clone':
            $sourceId = trim((string) ($input['source_id'] ?? 'default'));
            $name = trim((string) ($input['name'] ?? ''));
            if ($name === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Name required']);
                break;
            }
            $saved = $store->cloneProfile($sourceId, $name);
            user_management_register_fieldtype_profiles();
            echo json_encode(['success' => true, 'profile' => $saved]);
            break;

        case 'delete':
            $id = trim((string) ($input['id'] ?? ''));
            if ($id === '' || $id === 'default') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Cannot delete default profile']);
                break;
            }
            $ok = $store->deleteProfile($id);
            if ($ok) {
                user_management_register_fieldtype_profiles();
            }
            echo json_encode(['success' => $ok]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
