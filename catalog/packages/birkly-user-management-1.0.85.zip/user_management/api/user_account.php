<?php
/**
 * Site user account API (storefront / project pages).
 *
 * Requires a signed-in site user session (UserAuth scope site).
 */

declare(strict_types=1);

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../../../api/session.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/UserAuth.php';
require_once __DIR__ . '/../includes/UserService.php';
require_once __DIR__ . '/../includes/UserStorage.php';
require_once __DIR__ . '/../includes/UserDeleteGuard.php';
require_once __DIR__ . '/../includes/UserDeleteBlockedException.php';
require_once __DIR__ . '/../includes/ClubProfileService.php';
require_once __DIR__ . '/../includes/ClubOnboardingService.php';
require_once __DIR__ . '/../includes/ClubNotificationService.php';
require_once __DIR__ . '/../includes/MemberCommerceShelf.php';
require_once __DIR__ . '/../includes/UserMemberIndexer.php';
require_once __DIR__ . '/../includes/MemberAccountCodec.php';
require_once __DIR__ . '/../includes/UserFieldtypeProfileStore.php';

function user_account_respond(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

/**
 * @param array<string, mixed> $user
 * @return array{collection_slug: string, entry_id: string, account: array<string, mixed>}|null
 */
function user_account_resolve_member_for_user(array $user): ?array
{
    $email = strtolower(trim((string) ($user['email'] ?? '')));
    if ($email === '') {
        return null;
    }

    $hash = hash('sha256', $email);
    $indexer = new UserMemberIndexer();
    foreach ($indexer->listMembers() as $row) {
        if (!is_array($row) || ($row['email_hash'] ?? '') !== $hash) {
            continue;
        }

        $memberId = (string) ($row['member_id'] ?? '');
        $collectionSlug = (string) ($row['collection_slug'] ?? '');
        $entryId = (string) ($row['entry_id'] ?? '');
        if ($memberId === '' || $collectionSlug === '' || $entryId === '') {
            continue;
        }

        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $entry = null;
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== $collectionSlug) {
                continue;
            }
            $entry = $storage->read("collections/{$dir}/entries/{$entryId}.json");
            break;
        }

        if (!is_array($entry)) {
            continue;
        }

        require_once __DIR__ . '/../includes/UserCollectionResolver.php';
        $field = (new UserCollectionResolver())->getAccountFieldOnSchema($collectionSlug);
        $fieldName = (string) ($field['name'] ?? 'account');
        $account = MemberAccountCodec::normalize($entry[$fieldName] ?? []);

        return [
            'collection_slug' => $collectionSlug,
            'entry_id' => $entryId,
            'account' => $account,
        ];
    }

    return null;
}

/**
 * @param array{collection_slug: string, entry_id: string, account: array<string, mixed>} $member
 * @return array<string, mixed>
 */
function user_account_member_profile_settings(array $member): array
{
    require_once __DIR__ . '/../includes/UserCollectionResolver.php';
    $resolver = new UserCollectionResolver();
    $field = $resolver->getAccountFieldOnSchema((string) $member['collection_slug']);
    $typeKey = (string) ($field['type'] ?? 'user_account');

    return (new UserFieldtypeProfileStore())->getSettingsForTypeKey($typeKey);
}

function user_account_require_csrf(array $input): void
{
    $token = $input['csrf_token'] ?? $input['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (function_exists('verify_csrf_token') && verify_csrf_token($token)) {
        return;
    }
    if (function_exists('validate_csrf_token') && validate_csrf_token($token)) {
        return;
    }

    user_account_respond(['success' => false, 'error' => 'Invalid CSRF token'], 403);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST' && !empty($_POST)) {
    $input = $_POST;
} else {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '[]', true);
    $input = is_array($decoded) ? $decoded : [];
}

$action = (string) ($_GET['action'] ?? $input['action'] ?? 'profile');

$publicActions = ['public_profile'];
if ($action === 'public_profile') {
    $slug = trim((string) ($_GET['slug'] ?? $input['slug'] ?? ''));
    if ($slug === '') {
        user_account_respond(['success' => false, 'error' => 'Slug required'], 400);
    }
    $profileService = new ClubProfileService();
    $profile = $profileService->getProfileBySlug($slug);
    if ($profile === null) {
        user_account_respond(['success' => false, 'error' => 'Member not found'], 404);
    }
    user_account_respond([
        'success' => true,
        'member' => $profileService->toPublicProfile($profile),
    ]);
}

$auth = new UserAuth('site');
$currentUser = $auth->getCurrentUser();
if (!$currentUser || empty($currentUser['id'])) {
    user_account_respond(['success' => false, 'error' => 'Sign in required'], 401);
}

$userId = (string) $currentUser['id'];
$storage = new UserStorage();
$service = new UserService($storage);
$guard = new UserDeleteGuard();

switch ($action) {
    case 'profile':
        unset($currentUser['password_hash']);
        $profileService = new ClubProfileService();
        $clubProfile = $profileService->getProfileByUserId($userId);
        $onboarding = new ClubOnboardingService($profileService);

        user_account_respond([
            'success' => true,
            'user' => $currentUser,
            'club_profile' => $clubProfile,
            'profile_map' => $profileService->profileMapByUserId(),
            'notification_preferences' => (new ClubNotificationService())->preferencesFromProfile($clubProfile),
            'onboarding_status' => $onboarding->getStatus($userId),
        ]);

    case 'onboarding_status':
        $onboarding = new ClubOnboardingService();
        user_account_respond([
            'success' => true,
            'onboarding_status' => $onboarding->getStatus($userId),
        ]);

    case 'complete_onboarding':
        if ($method !== 'POST') {
            user_account_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_account_require_csrf($input);
        try {
            $result = (new ClubOnboardingService())->completeOnboarding($userId, $input);
            user_account_respond($result);
        } catch (InvalidArgumentException $e) {
            user_account_respond(['success' => false, 'error' => $e->getMessage()], 400);
        } catch (Throwable $e) {
            user_account_respond(['success' => false, 'error' => $e->getMessage()], 400);
        }

    case 'list_members':
        $profileService = new ClubProfileService();
        user_account_respond([
            'success' => true,
            'members' => $profileService->listClubDirectory(),
            'profile_map' => $profileService->profileMapByUserId(),
        ]);

    case 'upload_avatar':
        if ($method !== 'POST') {
            user_account_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_account_require_csrf($input);
        require_once __DIR__ . '/../../../core/avatar_upload.php';
        $upload = birkly_process_avatar_upload_from_request($currentUser);
        if (empty($upload['ok'])) {
            user_account_respond([
                'success' => false,
                'error' => (string) ($upload['message'] ?? 'Avatar upload failed'),
            ], 400);
        }
        $avatarPath = (string) ($upload['path'] ?? '');
        $mediaId = trim((string) ($upload['media_id'] ?? ''));
        $avatarField = $mediaId !== ''
            ? ['id' => $mediaId, 'url' => $avatarPath]
            : $avatarPath;
        $profileService = new ClubProfileService();
        $existing = $profileService->getProfileByUserId($userId);
        $title = trim((string) ($existing['title'] ?? $currentUser['name'] ?? $currentUser['email'] ?? 'Club member'));
        $profile = $profileService->saveProfileForUser($userId, [
            'title' => $title,
            'bio' => (string) ($existing['bio'] ?? ''),
            'description' => (string) ($existing['description'] ?? $existing['bio'] ?? ''),
            'website' => (string) ($existing['website'] ?? ''),
            'links' => (string) ($existing['links'] ?? ''),
            'avatar' => $avatarField,
        ]);
        user_account_respond([
            'success' => true,
            'avatar' => $profileService->normalizeAvatarUrl($profile['avatar'] ?? $avatarField),
            'club_profile' => $profile,
        ]);

    case 'update_profile':
        if ($method !== 'POST') {
            user_account_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_account_require_csrf($input);
        $profileService = new ClubProfileService();
        $fields = [
            'title' => (string) ($input['title'] ?? $input['name'] ?? ''),
            'bio' => (string) ($input['bio'] ?? ''),
            'description' => (string) ($input['description'] ?? $input['bio'] ?? ''),
            'website' => (string) ($input['website'] ?? ''),
            'links' => (string) ($input['links'] ?? ''),
            'interests' => (string) ($input['interests'] ?? ''),
        ];
        if (array_key_exists('avatar', $input)) {
            $fields['avatar'] = $input['avatar'];
        }
        $profile = $profileService->saveProfileForUser($userId, $fields);
        $displayName = trim((string) ($input['title'] ?? $input['name'] ?? ''));
        if ($displayName !== '') {
            $service->updateUser($userId, ['name' => $displayName]);
        }
        user_account_respond([
            'success' => true,
            'club_profile' => $profile,
        ]);

    case 'change_password':
        if ($method !== 'POST') {
            user_account_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_account_require_csrf($input);
        $currentPassword = (string) ($input['current_password'] ?? '');
        $newPassword = (string) ($input['new_password'] ?? '');
        if ($newPassword === '' || strlen($newPassword) < 8) {
            user_account_respond(['success' => false, 'error' => 'Password must be at least 8 characters'], 400);
        }
        $stored = $storage->getUser($userId);
        if (!$stored || !password_verify($currentPassword, (string) ($stored['password_hash'] ?? ''))) {
            user_account_respond(['success' => false, 'error' => 'Current password is incorrect'], 400);
        }
        $service->updateUser($userId, ['password' => $newPassword]);
        user_account_respond([
            'success' => true,
            'message' => 'Password updated',
        ]);

    case 'delete_preview':
        $email = strtolower(trim((string) ($currentUser['email'] ?? '')));
        $blocking = $guard->getBlockingSubscriptionsForEmail($email);

        user_account_respond([
            'success' => true,
            'can_delete' => $blocking === [],
            'subscriptions' => $blocking,
        ]);

    case 'delete_account':
        if ($method !== 'POST') {
            user_account_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_account_require_csrf($input);

        if (empty($input['confirm'])) {
            user_account_respond(['success' => false, 'error' => 'Confirmation required'], 400);
        }

        $forceCancel = !empty($input['force_cancel_subscriptions']);

        try {
            $service->deleteUser($userId, ['force_cancel_subscriptions' => $forceCancel]);
            $auth->logout();

            user_account_respond([
                'success' => true,
                'message' => 'Account deleted successfully',
            ]);
        } catch (UserDeleteBlockedException $e) {
            user_account_respond([
                'success' => false,
                'error' => $e->getMessage(),
                'code' => 'active_subscriptions',
                'subscriptions' => $e->subscriptions,
            ], 409);
        } catch (Throwable $e) {
            user_account_respond(['success' => false, 'error' => $e->getMessage()], 400);
        }

    case 'payment_summary':
        $member = user_account_resolve_member_for_user($currentUser);
        if ($member === null) {
            user_account_respond(['success' => false, 'error' => 'Member entry not found'], 404);
        }
        $settings = user_account_member_profile_settings($member);
        $shelf = new MemberCommerceShelf();
        if (!$shelf->paymentEnabled($settings)) {
            user_account_respond(['success' => false, 'error' => 'Payment management is not enabled for this profile'], 403);
        }
        $account = $shelf->syncAccountCommerce($member['account'], $settings);
        user_account_respond([
            'success' => true,
            'payment_enabled' => true,
            'commerce' => $account['commerce'] ?? [],
        ]);

    case 'payment_checkout':
        if ($method !== 'POST') {
            user_account_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_account_require_csrf($input);
        $member = user_account_resolve_member_for_user($currentUser);
        if ($member === null) {
            user_account_respond(['success' => false, 'error' => 'Member entry not found'], 404);
        }
        $settings = user_account_member_profile_settings($member);
        $shelf = new MemberCommerceShelf();
        if (!$shelf->paymentEnabled($settings)) {
            user_account_respond(['success' => false, 'error' => 'Payment management is not enabled for this profile'], 403);
        }
        $account = $member['account'];
        $memberId = (string) ($account['member_id'] ?? '');
        $email = strtolower(trim((string) ($currentUser['email'] ?? '')));
        $payload = $shelf->buildSignupCheckoutPayload(
            $memberId,
            $email,
            (string) ($account['name'] ?? $currentUser['name'] ?? ''),
            $settings,
            (string) ($member['collection_slug'] ?? '')
        );
        $checkout = $shelf->beginSignupCheckout($payload);
        $paymentUrl = $shelf->buildPaymentUrl($memberId, $settings, array_merge($account, [
            'collection_slug' => (string) ($member['collection_slug'] ?? ''),
        ]));
        user_account_respond([
            'success' => !empty($checkout['ok']) || $paymentUrl !== null,
            'checkout' => $checkout,
            'payment_url' => $paymentUrl,
        ]);

    default:
        user_account_respond(['success' => false, 'error' => 'Unknown action'], 400);
}
