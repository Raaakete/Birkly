<?php
/**
 * User Graph API — follow, connect, block relationships via UserGraphService.
 */

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../includes/UserAuth.php';
require_once __DIR__ . '/../includes/UserService.php';
require_once __DIR__ . '/../includes/UserGraphService.php';
require_once __DIR__ . '/../includes/RateLimiter.php';
require_once __DIR__ . '/../../../core/csrf.php';

function user_graph_respond($data, $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}

function user_graph_require_csrf(array $input = []): void
{
    $token = $input['csrf_token'] ?? $input['_csrf'] ?? $_POST['csrf_token'] ?? $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (function_exists('verify_csrf_token') && verify_csrf_token($token)) {
        return;
    }
    if (function_exists('validate_csrf_token') && validate_csrf_token($token)) {
        return;
    }

    user_graph_respond(['success' => false, 'error' => 'Invalid CSRF token'], 403);
}

$auth = new UserAuth('site');
$me = $auth->getCurrentUser();
if (!$me || empty($me['id'])) {
    user_graph_respond(['success' => false, 'error' => 'Login required'], 401);
}
$myId = (string) $me['id'];

if ($method === 'POST') {
    user_graph_require_csrf($input);
    $rateLimiter = new UserRateLimiter();
    try {
        $rateLimiter->assertAllowed(
            'user_graph',
            $myId . '|' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
            function_exists('get_plugin_setting') ? get_plugin_setting('user_management', 'relation_rate_limit', 60) : 60,
            function_exists('get_plugin_setting') ? get_plugin_setting('user_management', 'relation_rate_window', 300) : 300
        );
    } catch (Exception $e) {
        user_graph_respond(['success' => false, 'error' => $e->getMessage()], 429);
    }
}

$service = new UserGraphService();
$userService = new UserService();

function user_graph_target_id(array $input): string
{
    return trim((string) ($input['target_user_id'] ?? $_POST['target_user_id'] ?? ''));
}

function user_graph_assert_target(string $targetId, string $myId, UserService $userService): void
{
    if ($targetId === '' || $targetId === $myId) {
        user_graph_respond(['success' => false, 'error' => 'Invalid target_user_id'], 400);
    }
    if (!$userService->getUser($targetId)) {
        user_graph_respond(['success' => false, 'error' => 'Target user not found'], 404);
    }
}

try {
    switch ($action) {
        case 'follow':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->follow($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Followed']);

        case 'unfollow':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->unfollow($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Unfollowed']);

        case 'toggle_follow':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $result = $service->toggleFollow($myId, $targetId);
            user_graph_respond(['success' => true] + $result);

        case 'following':
            if ($method !== 'GET') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            user_graph_respond([
                'success' => true,
                'following' => $service->ensureDefaultFollows($myId),
            ]);

        case 'follow_state':
            if ($method !== 'GET') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targets = [];
            if (!empty($_GET['user_ids'])) {
                $targets = array_filter(array_map('trim', explode(',', (string) $_GET['user_ids'])));
            }
            user_graph_respond([
                'success' => true,
                'state' => $service->followStateForUser($myId, $targets),
            ]);

        case 'connect':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->connect($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Connection request sent']);

        case 'accept':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->accept($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Connection accepted']);

        case 'reject':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->reject($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Connection rejected']);

        case 'disconnect':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->disconnect($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Disconnected']);

        case 'block':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->block($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Blocked']);

        case 'unblock':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->unblock($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Unblocked']);

        case 'mute':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->mute($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Muted']);

        case 'unmute':
            if ($method !== 'POST') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            $targetId = user_graph_target_id($input);
            user_graph_assert_target($targetId, $myId, $userService);
            $service->unmute($myId, $targetId);
            user_graph_respond(['success' => true, 'message' => 'Unmuted']);

        case 'list_blocks':
            if ($method !== 'GET') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            user_graph_respond([
                'success' => true,
                'blocked' => $service->listBlocked($myId),
            ]);

        case 'list_mutes':
            if ($method !== 'GET') {
                user_graph_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }
            user_graph_respond([
                'success' => true,
                'muted' => $service->listMuted($myId),
            ]);

        default:
            user_graph_respond(['success' => false, 'error' => 'Invalid action'], 400);
    }
} catch (InvalidArgumentException $e) {
    user_graph_respond(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('user_graph: ' . $e->getMessage());
    user_graph_respond(['success' => false, 'error' => 'User graph request failed'], 500);
}
