<?php
/**
 * Signup field schema API (admin + public schema read).
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/SignupFieldSchema.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode(is_string($raw) ? $raw : '', true) ?? [];
    if ($input === [] && !empty($_POST)) {
        $input = $_POST;
    }
}

$action = $input['action'] ?? $_GET['action'] ?? 'public_schema';
$schemaService = new SignupFieldSchema();

$adminActions = ['get_schema', 'save_schema'];
if (in_array($action, $adminActions, true)) {
    if (function_exists('requireAuth')) {
        requireAuth('manage_users');
    } elseif (function_exists('requireAdminAuth')) {
        requireAdminAuth();
    }
}

if ($method === 'POST' && in_array($action, ['save_schema'], true) && function_exists('validate_csrf_token')) {
    $token = $input['csrf_token'] ?? $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    if (!validate_csrf_token($token)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
        exit;
    }
}

header('Content-Type: application/json');

try {
    switch ($action) {
        case 'public_schema':
            $context = (string) ($input['context'] ?? $_GET['context'] ?? SignupFieldSchema::CONTEXT_REGISTER);
            if (!in_array($context, [SignupFieldSchema::CONTEXT_REGISTER, SignupFieldSchema::CONTEXT_ACTIVATE], true)) {
                $context = SignupFieldSchema::CONTEXT_REGISTER;
            }
            echo json_encode([
                'success' => true,
                'context' => $context,
                'fields' => $schemaService->getPublicFields($context),
            ]);
            break;

        case 'get_schema':
            echo json_encode([
                'success' => true,
                'schema' => $schemaService->getSchema(),
            ]);
            break;

        case 'save_schema':
            $fields = $input['fields'] ?? [];
            if (!is_array($fields)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'fields must be an array']);
                break;
            }
            $ok = $schemaService->saveSchema($fields);
            echo json_encode([
                'success' => $ok,
                'schema' => $schemaService->getSchema(),
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Unknown action']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
