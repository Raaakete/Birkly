<?php
/**
 * Members index API (P77-M4).
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/UserMemberIndexer.php';
require_once __DIR__ . '/../includes/MemberMigrationService.php';

if (function_exists('requireAuth')) {
    requireAuth('manage_users');
} elseif (function_exists('requireAdminAuth')) {
    requireAdminAuth();
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw !== false ? $raw : '', true);
    $input = is_array($decoded) ? $decoded : $_POST;
}

$action = (string) ($input['action'] ?? $_GET['action'] ?? 'list');

if ($method === 'POST') {
    $token = (string) ($input['csrf_token'] ?? $_GET['csrf_token'] ?? '');
    if (function_exists('validate_csrf_token') && !validate_csrf_token($token)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
        exit;
    }
}

header('Content-Type: application/json');
$indexer = new UserMemberIndexer();
$migration = new MemberMigrationService();

try {
    switch ($action) {
        case 'list':
            echo json_encode([
                'success' => true,
                'members' => $indexer->listMembers(),
            ]);
            break;

        case 'get':
            $memberId = trim((string) ($input['member_id'] ?? $_GET['member_id'] ?? ''));
            if ($memberId === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'member_id required']);
                break;
            }
            $member = $indexer->getMember($memberId);
            if (!$member) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Member not found']);
                break;
            }
            echo json_encode(['success' => true, 'member' => $member]);
            break;

        case 'reindex':
            $count = $indexer->reindexAll();
            echo json_encode(['success' => true, 'count' => $count]);
            break;

        case 'migrate_p77_members':
        case 'migrate':
            require_once __DIR__ . '/../includes/MemberMigrateService.php';
            $collection = trim((string) ($input['collection'] ?? $_GET['collection'] ?? 'club-profiles'));
            $typeKey = trim((string) ($input['type_key'] ?? $_GET['type_key'] ?? 'user_account_club'));
            $dryRun = !empty($input['dry_run']) || !empty($_GET['dry_run']);
            $result = user_management_migrate_p77_members([
                'collection' => $collection,
                'type_key' => $typeKey,
                'dry_run' => $dryRun,
            ]);
            $ok = empty($result['errors']);
            if (!$ok) {
                http_response_code(400);
            }
            echo json_encode([
                'success' => $ok,
                'dry_run' => $dryRun,
                'result' => $result,
            ]);
            break;

        case 'plan_upgrade':
            $memberId = trim((string) ($input['member_id'] ?? $_GET['member_id'] ?? ''));
            $tierId = trim((string) ($input['tier_id'] ?? $_GET['tier_id'] ?? ''));
            $targetCollection = trim((string) ($input['target_collection'] ?? $_GET['target_collection'] ?? ''));
            if ($memberId === '' || $tierId === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'member_id and tier_id required']);
                break;
            }
            $plan = $migration->planUpgrade(
                $memberId,
                $tierId,
                $targetCollection !== '' ? $targetCollection : null
            );
            echo json_encode(array_merge(['success' => !empty($plan['ok'])], $plan));
            if (empty($plan['ok'])) {
                http_response_code(400);
            }
            break;

        case 'change_tier':
            $memberId = trim((string) ($input['member_id'] ?? ''));
            $tierId = trim((string) ($input['tier_id'] ?? ''));
            $targetCollection = trim((string) ($input['target_collection'] ?? ''));
            $extraFields = is_array($input['fields'] ?? null) ? $input['fields'] : [];
            if ($memberId === '' || $tierId === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'member_id and tier_id required']);
                break;
            }
            $result = $migration->changeTier(
                $memberId,
                $tierId,
                $targetCollection !== '' ? $targetCollection : null,
                $extraFields
            );
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result));
            if (empty($result['ok'])) {
                http_response_code(400);
            }
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
            break;
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
