<?php
/**
 * User notifications API (in-app inbox + preferences) — primary route (P81-M7).
 */

declare(strict_types=1);

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../../../api/session.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/UserAuth.php';
require_once __DIR__ . '/../includes/UserNotificationService.php';
require_once __DIR__ . '/../includes/ClubProfileService.php';

function user_notifications_respond(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function user_notifications_require_csrf(array $input): void
{
    $token = $input['csrf_token'] ?? $input['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (function_exists('verify_csrf_token') && verify_csrf_token($token)) {
        return;
    }
    if (function_exists('validate_csrf_token') && validate_csrf_token($token)) {
        return;
    }

    user_notifications_respond(['success' => false, 'error' => 'Invalid CSRF token'], 403);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST' && !empty($_POST)) {
    $input = $_POST;
} else {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '[]', true);
    $input = is_array($decoded) ? $decoded : [];
}

$action = (string) ($_GET['action'] ?? $input['action'] ?? 'list');

$auth = new UserAuth('site');
$currentUser = $auth->getCurrentUser();
if (!$currentUser || empty($currentUser['id'])) {
    user_notifications_respond(['success' => false, 'error' => 'Sign in required'], 401);
}

$userId = (string) $currentUser['id'];
$service = new UserNotificationService();
$profileService = new ClubProfileService();

switch ($action) {
    case 'list':
        $limit = (int) ($_GET['limit'] ?? $input['limit'] ?? 40);
        user_notifications_respond([
            'success' => true,
            'notifications' => $service->listForUser($userId, $limit),
            'unread_count' => $service->unreadCount($userId),
        ]);

    case 'unread_count':
        user_notifications_respond([
            'success' => true,
            'unread_count' => $service->unreadCount($userId),
        ]);

    case 'mark_read':
        if ($method !== 'POST') {
            user_notifications_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_notifications_require_csrf($input);
        $notificationId = trim((string) ($input['notification_id'] ?? $input['id'] ?? ''));
        if ($notificationId === '') {
            user_notifications_respond(['success' => false, 'error' => 'notification_id required'], 400);
        }
        user_notifications_respond([
            'success' => $service->markRead($userId, $notificationId),
            'unread_count' => $service->unreadCount($userId),
        ]);

    case 'mark_all_read':
        if ($method !== 'POST') {
            user_notifications_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_notifications_require_csrf($input);
        $marked = $service->markAllRead($userId);
        user_notifications_respond([
            'success' => true,
            'marked' => $marked,
            'unread_count' => 0,
        ]);

    case 'get_preferences':
        $profile = $profileService->getProfileByUserId($userId);
        user_notifications_respond([
            'success' => true,
            'preferences' => $service->preferencesFromProfile($profile),
            'defaults' => UserNotificationService::defaultPreferences(),
        ]);

    case 'save_preferences':
        if ($method !== 'POST') {
            user_notifications_respond(['success' => false, 'error' => 'Method not allowed'], 405);
        }
        user_notifications_require_csrf($input);
        $prefs = is_array($input['preferences'] ?? null) ? $input['preferences'] : $input;
        $saved = $service->savePreferencesForUser($userId, $prefs);
        user_notifications_respond([
            'success' => true,
            'preferences' => $saved,
        ]);

    default:
        user_notifications_respond(['success' => false, 'error' => 'Unknown action'], 400);
}
