<?php
/**
 * Club deal analytics API (P80-M5).
 */

declare(strict_types=1);

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../../../api/session.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/UserAuth.php';
require_once __DIR__ . '/../includes/ClubDealService.php';

function club_deals_respond(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function club_deals_require_csrf(array $input): void
{
    $token = $input['csrf_token'] ?? $input['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (function_exists('verify_csrf_token') && verify_csrf_token($token)) {
        return;
    }
    if (function_exists('validate_csrf_token') && validate_csrf_token($token)) {
        return;
    }

    club_deals_respond(['success' => false, 'error' => 'Invalid CSRF token'], 403);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST' && !empty($_POST)) {
    $input = $_POST;
} else {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '[]', true);
    $input = is_array($decoded) ? $decoded : [];
}

$action = (string) ($_GET['action'] ?? $input['action'] ?? '');
$service = new ClubDealService();

if ($action === 'track') {
    if ($method !== 'POST') {
        club_deals_respond(['success' => false, 'error' => 'Method not allowed'], 405);
    }
    club_deals_require_csrf($input);

    $auth = new UserAuth('site');
    $currentUser = $auth->getCurrentUser();
    if (!$currentUser || empty($currentUser['id'])) {
        club_deals_respond(['success' => false, 'error' => 'Sign in required'], 401);
    }

    $dealId = trim((string) ($input['deal_id'] ?? $input['entry_id'] ?? $input['slug'] ?? ''));
    $event = trim((string) ($input['event'] ?? ''));
    $result = $service->track($dealId, $event);
    if (empty($result['ok'])) {
        club_deals_respond([
            'success' => false,
            'error' => (string) ($result['error'] ?? 'Could not track event'),
        ], 400);
    }

    club_deals_respond([
        'success' => true,
        'copy_count' => (int) ($result['copy_count'] ?? 0),
        'visit_count' => (int) ($result['visit_count'] ?? 0),
    ]);
}

club_deals_respond(['success' => false, 'error' => 'Invalid action'], 400);
