<?php
/**
 * Collection Permissions API
 * Handles collection-level permission configuration
 */

// Include core files
require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/UserStorage.php';
require_once __DIR__ . '/../includes/CollectionPermissionsService.php';
require_once __DIR__ . '/../cms_paths.php';

// Admin authentication check
if (function_exists('requireAuth')) {
    requireAuth('manage_users');
} elseif (function_exists('requireAdminAuth')) {
    requireAdminAuth();
}

// Get request method and input
$method = $_SERVER['REQUEST_METHOD'];
$input = [];
if ($method === 'POST' && !empty($_POST)) {
    $input = $_POST;
} elseif ($method === 'POST') {
    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true) ?? [];
}

$action = $input['action'] ?? $_GET['action'] ?? 'get';

// CSRF protection for POST requests
if ($method === 'POST') {
    $token = $input['csrf_token'] ?? $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    if (function_exists('validate_csrf_token')) {
        if (!validate_csrf_token($token)) {
            http_response_code(403);
            echo json_encode(['error' => 'Invalid CSRF token']);
            exit;
        }
    }
}

header('Content-Type: application/json');

try {
    $permissionsService = new CollectionPermissionsService();
    
    switch ($action) {
        case 'get':
            // Get all collections
            $collections = [];
            $collectionsPath = user_management_cms_path('content/collections');
            
            if (is_dir($collectionsPath)) {
                $collectionDirs = glob($collectionsPath . '/*', GLOB_ONLYDIR);
                foreach ($collectionDirs as $dir) {
                    $collectionFile = $dir . '/collection.json';
                    if (file_exists($collectionFile)) {
                        $collectionData = json_decode(file_get_contents($collectionFile), true);
                        if ($collectionData) {
                            if (!empty($collectionData['options']['hidden'])) {
                                continue;
                            }
                            $collections[] = [
                                'slug' => basename($dir),
                                'name' => $collectionData['name'] ?? $collectionData['title'] ?? basename($dir),
                                'description' => $collectionData['description'] ?? ''
                            ];
                        }
                    }
                }
            }
            
            $permissions = $permissionsService->getPermissions();
            $tiers = $permissionsService->listTierOptions();
            
            echo json_encode([
                'success' => true,
                'collections' => $collections,
                'permissions' => $permissions,
                'tiers' => $tiers
            ]);
            break;
            
        case 'save':
            // Save permissions configuration
            $permissions = $input['permissions'] ?? [];

            try {
                $cleanedPermissions = $permissionsService->savePermissions($permissions);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
                break;
            }
            
            // Return the saved permissions exactly as they were saved
            echo json_encode([
                'success' => true,
                'message' => 'Permissions saved successfully',
                'permissions' => $cleanedPermissions
            ]);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Server error: ' . $e->getMessage()
    ]);
}
