<?php
/**
 * Public member signup API (P77-M5).
 *
 * Actions: schema, register
 */

declare(strict_types=1);

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../includes/MemberSignupService.php';
require_once __DIR__ . '/../includes/RateLimiter.php';
require_once __DIR__ . '/../includes/UserFieldtypeProfileStore.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw !== false ? $raw : '', true);
    $input = is_array($decoded) ? $decoded : $_POST;
}

$action = (string) ($input['action'] ?? $_GET['action'] ?? 'schema');
$service = new MemberSignupService();

try {
    switch ($action) {
        case 'schema':
        case 'member_signup_schema':
            $collection = trim((string) ($input['collection'] ?? $_GET['collection'] ?? ''));
            $tierId = trim((string) ($input['tier'] ?? $input['tier_id'] ?? $_GET['tier'] ?? $_GET['tier_id'] ?? ''));
            $result = $service->getSignupSchema($collection, $tierId !== '' ? $tierId : null);
            if (empty($result['ok'])) {
                http_response_code(400);
            }
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result));
            break;

        case 'register':
        case 'member_register':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'Method not allowed']);
                break;
            }

            $collection = trim((string) ($input['collection'] ?? $_POST['collection'] ?? ''));
            $tierId = trim((string) ($input['tier'] ?? $input['tier_id'] ?? $_POST['tier'] ?? $_POST['tier_id'] ?? ''));
            $fields = is_array($input['fields'] ?? null) ? $input['fields'] : $input;
            unset($fields['action'], $fields['collection'], $fields['tier'], $fields['tier_id']);

            $rateLimiter = new UserRateLimiter();
            $email = strtolower(trim((string) ($fields['email'] ?? '')));
            try {
                $rateLimiter->assertAllowed(
                    'member_signup',
                    $email . '|' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
                    (int) get_plugin_setting('user_management', 'registration_rate_limit', 5),
                    (int) get_plugin_setting('user_management', 'registration_rate_window', 3600)
                );
            } catch (Exception $e) {
                http_response_code(429);
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
                break;
            }

            $result = $service->register($fields, $collection, $tierId !== '' ? $tierId : null);
            if (empty($result['ok'])) {
                http_response_code(400);
            }
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result));
            break;

        case 'begin_checkout':
        case 'member_checkout':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'Method not allowed']);
                break;
            }
            require_once __DIR__ . '/../includes/MemberCommerceShelf.php';
            $collection = trim((string) ($input['collection'] ?? $_POST['collection'] ?? ''));
            $memberId = trim((string) ($input['member_id'] ?? $_POST['member_id'] ?? ''));
            if ($collection === '' || $memberId === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'collection and member_id required']);
                break;
            }
            $tierId = trim((string) ($input['tier'] ?? $input['tier_id'] ?? ''));
            $schema = $service->getSignupSchema($collection, $tierId !== '' ? $tierId : null);
            if (empty($schema['ok'])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => (string) ($schema['error'] ?? 'Invalid signup target')]);
                break;
            }
            $settings = (new UserFieldtypeProfileStore())->getSettingsForTypeKey((string) ($schema['type_key'] ?? 'user_account'));
            $shelf = new MemberCommerceShelf();
            $email = strtolower(trim((string) ($input['email'] ?? '')));
            $name = trim((string) ($input['name'] ?? ''));
            $payload = $shelf->buildSignupCheckoutPayload($memberId, $email, $name, $settings, $collection);
            $checkout = $shelf->beginSignupCheckout($payload);
            echo json_encode([
                'success' => !empty($checkout['ok']) || isset($checkout['checkout']),
                'checkout' => $checkout,
                'payload' => $payload,
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
