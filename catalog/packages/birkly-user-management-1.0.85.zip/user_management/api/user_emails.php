<?php
/**
 * User Management email templates API (admin).
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/UserEmailService.php';

if (function_exists('requireAuth')) {
    requireAuth('manage_users');
} elseif (function_exists('requireAdminAuth')) {
    requireAdminAuth();
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode(is_string($raw) ? $raw : '', true) ?? [];
    if ($input === [] && !empty($_POST)) {
        $input = $_POST;
    }
}

$action = $input['action'] ?? $_GET['action'] ?? 'list_templates';

if ($method === 'POST' && function_exists('validate_csrf_token')) {
    $token = $input['csrf_token'] ?? $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    if (!validate_csrf_token($token)) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
        exit;
    }
}

header('Content-Type: application/json');

$emailService = new UserEmailService();

try {
    switch ($action) {
        case 'list_templates':
            echo json_encode([
                'success' => true,
                'templates' => $emailService->listTemplates(),
                'delivery' => $emailService->getDeliverySettings(),
            ]);
            break;

        case 'save_template':
            $result = $emailService->saveTemplate(is_array($input['template'] ?? null) ? $input['template'] : $input);
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result));
            break;

        case 'save_delivery':
            $delivery = $emailService->saveDeliverySettings($input);
            echo json_encode(['success' => true, 'delivery' => $delivery]);
            break;

        case 'send_test':
            $templateId = (string) ($input['template_id'] ?? '');
            $to = (string) ($input['email'] ?? '');
            $result = $emailService->sendTest($templateId, $to);
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result));
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Unknown action']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
