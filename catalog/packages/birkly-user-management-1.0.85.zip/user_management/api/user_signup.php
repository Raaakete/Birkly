<?php
/**
 * Signup flow API — start, step, status (public + admin).
 */

declare(strict_types=1);

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../includes/SignupFlowEngine.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST') {
    $raw = file_get_contents('php://input');
    $input = json_decode(is_string($raw) ? $raw : '', true) ?? [];
    if ($input === [] && !empty($_POST)) {
        $input = $_POST;
    }
}

$action = $input['action'] ?? $_GET['action'] ?? 'list_flows';
$engine = new SignupFlowEngine();

$adminActions = ['save_flows'];
if (in_array($action, $adminActions, true)) {
    if (function_exists('requireAuth')) {
        requireAuth('manage_users');
    } elseif (function_exists('requireAdminAuth')) {
        requireAdminAuth();
    }
}

if ($method === 'POST' && in_array($action, $adminActions, true) && function_exists('validate_csrf_token')) {
    $token = $input['csrf_token'] ?? $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
    if (!validate_csrf_token($token)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
        exit;
    }
}

try {
    switch ($action) {
        case 'list_flows':
            echo json_encode([
                'success' => true,
                'flows' => $engine->listFlows(),
            ]);
            break;

        case 'get_flow':
            $flowId = (string) ($input['flow_id'] ?? $_GET['flow_id'] ?? '');
            $flow = $engine->getFlow($flowId);
            if ($flow === null) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Flow not found']);
                break;
            }
            echo json_encode(['success' => true, 'flow' => $flow]);
            break;

        case 'start':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'Method not allowed']);
                break;
            }
            $flowId = (string) ($input['flow_id'] ?? '');
            $result = $engine->start($flowId, $input);
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result));
            break;

        case 'step':
            if ($method !== 'POST') {
                http_response_code(405);
                echo json_encode(['success' => false, 'error' => 'Method not allowed']);
                break;
            }
            $sessionId = (string) ($input['session_id'] ?? '');
            $stepId = isset($input['step_id']) ? (string) $input['step_id'] : null;
            $result = $engine->runStep($sessionId, $stepId, $input);
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result));
            break;

        case 'status':
            $sessionId = (string) ($input['session_id'] ?? $_GET['session_id'] ?? '');
            $result = $engine->getStatus($sessionId);
            echo json_encode(array_merge(['success' => !empty($result['ok'])], $result));
            break;

        case 'save_flows':
            $flows = $input['flows'] ?? [];
            if (!is_array($flows)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'flows must be an array']);
                break;
            }
            $ok = $engine->saveFlowOverrides($flows);
            echo json_encode([
                'success' => $ok,
                'flows' => $engine->listFlows(),
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Unknown action']);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
