<?php
/**
 * Account activation API — send link and complete setup.
 */

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../includes/AccountActivation.php';
require_once __DIR__ . '/../includes/RateLimiter.php';

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? $_POST['action'] ?? ($input['action'] ?? '');

$activation = new AccountActivation();
$rateLimiter = new UserRateLimiter();

function activation_respond(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

try {
    switch ($action) {
        case 'send':
            if ($method !== 'POST') {
                activation_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }

            $email = trim((string) ($input['email'] ?? $_POST['email'] ?? ''));
            if ($email === '') {
                activation_respond(['success' => false, 'message' => 'Email is required'], 400);
            }

            try {
                $rateLimiter->assertAllowed(
                    'account_activation_request',
                    strtolower($email) . '|' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
                    function_exists('get_plugin_setting') ? (int) get_plugin_setting('user_management', 'activation_rate_limit', 5) : 5,
                    function_exists('get_plugin_setting') ? (int) get_plugin_setting('user_management', 'activation_rate_window', 3600) : 3600
                );
            } catch (Exception $e) {
                activation_respond(['success' => false, 'message' => $e->getMessage()], 429);
            }

            $context = is_array($input['context'] ?? null) ? $input['context'] : [];
            $result = $activation->sendActivationEmail($email, $context);
            activation_respond($result, ($result['success'] ?? false) ? 200 : 500);
            break;

        case 'verify':
            $token = trim((string) ($input['token'] ?? $_GET['token'] ?? ''));
            if ($token === '') {
                activation_respond(['success' => false, 'message' => 'Token is required'], 400);
            }
            activation_respond($activation->verifyToken($token));
            break;

        case 'complete':
            if ($method !== 'POST') {
                activation_respond(['success' => false, 'error' => 'Method not allowed'], 405);
            }

            $token = trim((string) ($input['token'] ?? $_POST['token'] ?? ''));
            $password = (string) ($input['password'] ?? $_POST['password'] ?? '');
            $name = trim((string) ($input['name'] ?? $_POST['name'] ?? ''));
            $fields = is_array($input['fields'] ?? null) ? $input['fields'] : [];
            if ($name !== '' && !isset($fields['name'])) {
                $fields['name'] = $name;
            }

            if ($token === '' || $password === '') {
                activation_respond(['success' => false, 'message' => 'Token and password are required'], 400);
            }

            $result = $activation->completeActivation($token, $password, $name !== '' ? $name : null, $fields);
            activation_respond($result, ($result['success'] ?? false) ? 200 : 400);
            break;

        default:
            activation_respond(['success' => false, 'error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    activation_respond(['success' => false, 'error' => $e->getMessage()], 500);
}
