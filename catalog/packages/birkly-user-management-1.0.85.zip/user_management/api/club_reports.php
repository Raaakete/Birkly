<?php
/**
 * Club moderation reports API (P80-M4).
 */

declare(strict_types=1);

header('Content-Type: application/json');

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'User Management plugin is not active']);
    exit;
}

require_once __DIR__ . '/../../../api/session.php';
require_once __DIR__ . '/../../../core/csrf.php';
require_once __DIR__ . '/../../../api/auth.php';
require_once __DIR__ . '/../includes/UserAuth.php';
require_once __DIR__ . '/../includes/ClubReportService.php';
require_once __DIR__ . '/../includes/UserService.php';

function club_reports_respond(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function club_reports_require_csrf(array $input): void
{
    $token = $input['csrf_token'] ?? $input['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (function_exists('verify_csrf_token') && verify_csrf_token($token)) {
        return;
    }
    if (function_exists('validate_csrf_token') && validate_csrf_token($token)) {
        return;
    }

    club_reports_respond(['success' => false, 'error' => 'Invalid CSRF token'], 403);
}

function club_reports_is_admin(): bool
{
    if (function_exists('haru_secure_session_start')) {
        haru_secure_session_start();
    }

    return isset($_SESSION['user']);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$input = [];
if ($method === 'POST' && !empty($_POST)) {
    $input = $_POST;
} else {
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw ?: '[]', true);
    $input = is_array($decoded) ? $decoded : [];
}

$action = (string) ($_GET['action'] ?? $input['action'] ?? 'list');
$service = new ClubReportService();

if ($action === 'list') {
    if (!club_reports_is_admin()) {
        club_reports_respond(['success' => false, 'error' => 'Admin login required'], 401);
    }
    $limit = (int) ($_GET['limit'] ?? $input['limit'] ?? 50);
    club_reports_respond([
        'success' => true,
        'reports' => $service->listOpenReports($limit),
    ]);
}

if ($action === 'hide_post') {
    if ($method !== 'POST') {
        club_reports_respond(['success' => false, 'error' => 'Method not allowed'], 405);
    }
    if (!club_reports_is_admin()) {
        club_reports_respond(['success' => false, 'error' => 'Admin login required'], 401);
    }
    club_reports_require_csrf($input);
    $entryId = trim((string) ($input['target_entry_id'] ?? $input['entry_id'] ?? ''));
    if ($entryId === '') {
        club_reports_respond(['success' => false, 'error' => 'target_entry_id required'], 400);
    }
    if (!$service->hideClubPost($entryId)) {
        club_reports_respond(['success' => false, 'error' => 'Could not hide post'], 500);
    }
    club_reports_respond(['success' => true, 'message' => 'Post hidden']);
}

if ($action === 'submit') {
    if ($method !== 'POST') {
        club_reports_respond(['success' => false, 'error' => 'Method not allowed'], 405);
    }
    club_reports_require_csrf($input);

    $auth = new UserAuth('site');
    $currentUser = $auth->getCurrentUser();
    if (!$currentUser || empty($currentUser['id'])) {
        club_reports_respond(['success' => false, 'error' => 'Sign in required'], 401);
    }

    $result = $service->submitReport(
        (string) $currentUser['id'],
        (string) ($input['target_collection'] ?? 'club-posts'),
        (string) ($input['target_entry_id'] ?? ''),
        (string) ($input['reason'] ?? '')
    );

    if (empty($result['ok'])) {
        club_reports_respond([
            'success' => false,
            'error' => (string) ($result['error'] ?? 'Could not submit report'),
        ], 400);
    }

    club_reports_respond([
        'success' => true,
        'report_id' => (string) ($result['report_id'] ?? ''),
        'message' => 'Report submitted. Thank you — our team will review it.',
    ]);
}

club_reports_respond(['success' => false, 'error' => 'Invalid action'], 400);
