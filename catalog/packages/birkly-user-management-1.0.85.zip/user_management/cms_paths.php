<?php
/**
 * CMS path helpers for marketplace / data-volume plugin installs.
 *
 * Relative paths like __DIR__ . '/../../../settings/site.json' break when the
 * plugin lives under /app/data/plugins/user_management instead of /app/plugins/user_management.
 */

declare(strict_types=1);

function user_management_cms_root(): string
{
    if (!empty($GLOBALS['user_management_test_cms_root']) && is_string($GLOBALS['user_management_test_cms_root'])) {
        return rtrim($GLOBALS['user_management_test_cms_root'], '/');
    }
    if (function_exists('birkly_project_root')) {
        return birkly_project_root();
    }
    if (defined('BIRKLY_CMS_ROOT')) {
        return (string) BIRKLY_CMS_ROOT;
    }
    $env = getenv('BIRKLY_CMS_ROOT');
    if (is_string($env) && $env !== '') {
        return rtrim($env, '/');
    }
    if (is_dir('/app/core') && is_dir('/app/api')) {
        return '/app';
    }

    $dir = __DIR__;
    for ($i = 0; $i < 6; $i++) {
        if (is_dir($dir . '/core') && is_dir($dir . '/api')) {
            return $dir;
        }
        $parent = dirname($dir);
        if ($parent === $dir) {
            break;
        }
        $dir = $parent;
    }

    $candidate = dirname(__DIR__, 2);
    if (is_dir($candidate . '/core') || is_dir($candidate . '/api')) {
        return $candidate;
    }

    return $candidate;
}

function user_management_cms_path(string $relative): string
{
    return rtrim(user_management_cms_root(), '/') . '/' . ltrim(str_replace('\\', '/', $relative), '/');
}

/**
 * Resolve collection.json across Hub install layouts and legacy plugin-relative paths.
 */
function user_management_resolve_collection_json_path(string $collectionSlug): ?string
{
    $collectionSlug = trim(str_replace('\\', '/', $collectionSlug), '/');
    if ($collectionSlug === '') {
        return null;
    }

    $relative = 'content/collections/' . $collectionSlug . '/collection.json';
    $candidates = [
        user_management_cms_path($relative),
        __DIR__ . '/../../../' . $relative,
        dirname(__DIR__, 2) . '/' . $relative,
    ];

    $seen = [];
    foreach ($candidates as $path) {
        $key = realpath(dirname($path)) ?: $path;
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        if (is_file($path) && is_readable($path)) {
            return $path;
        }
    }

    return null;
}

/**
 * @return bool True when the file was written successfully.
 */
function user_management_write_collection_json(string $path, array $config): bool
{
    $encoded = json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
    if (@file_put_contents($path, $encoded) === false) {
        error_log('User Management: failed to write collection config: ' . $path);
        return false;
    }

    return true;
}

/**
 * Writable runtime data directory (separate from Hub install tree).
 */
function user_management_data_dir(): string
{
    if (is_string(getenv('USER_MANAGEMENT_DATA_DIR')) && trim((string) getenv('USER_MANAGEMENT_DATA_DIR')) !== '') {
        return rtrim((string) getenv('USER_MANAGEMENT_DATA_DIR'), '/');
    }

    if (function_exists('birkly_data_root')) {
        $dataRoot = birkly_data_root();
        if (is_string($dataRoot) && $dataRoot !== '') {
            $root = rtrim($dataRoot, '/');
            $preferred = $root . '/plugin-data/user_management';
            $legacyFlat = user_management_cms_root() . '/data/plugins/user_management';
            $chosen = user_management_resolve_writable_data_dir($preferred, $legacyFlat);
            user_management_ensure_writable_dir($chosen);
            user_management_migrate_encryption_key($chosen);
            user_management_reconcile_data_dirs($chosen);
            return $chosen;
        }
    }

    $legacy = user_management_cms_root() . '/data/plugins/user_management';
    user_management_ensure_writable_dir($legacy);
    user_management_migrate_encryption_key($legacy);
    user_management_reconcile_data_dirs($legacy);
    return $legacy;
}

/**
 * Keep encryption key when migrating from legacy plugin-data paths.
 * Replaces a wrong key in the target dir when encrypted users cannot be read.
 */
function user_management_migrate_encryption_key(string $targetDir): void
{
    $targetDir = rtrim($targetDir, '/');
    $targetKey = $targetDir . '/metadata/encryption_key.txt';
    $currentKey = is_file($targetKey) ? trim((string) file_get_contents($targetKey)) : '';
    if ($currentKey !== '' && user_management_encryption_key_valid_for_dir($targetDir, $currentKey)) {
        return;
    }

    foreach (user_management_candidate_data_dirs() as $sourceDir) {
        $sourceDir = rtrim($sourceDir, '/');
        if ($sourceDir === $targetDir) {
            continue;
        }
        $realSource = realpath($sourceDir);
        $realTarget = realpath($targetDir);
        if ($realSource !== false && $realTarget !== false && $realSource === $realTarget) {
            continue;
        }

        $sourceKey = $sourceDir . '/metadata/encryption_key.txt';
        $usersDir = $sourceDir . '/users';
        if (!is_file($sourceKey) || !is_dir($usersDir)) {
            continue;
        }
        if ((glob($usersDir . '/*.json') ?: []) === []) {
            continue;
        }

        $legacyKey = trim((string) file_get_contents($sourceKey));
        if ($legacyKey === '' || !user_management_encryption_key_valid_for_dir($sourceDir, $legacyKey)) {
            continue;
        }

        if (!is_dir(dirname($targetKey))) {
            @mkdir(dirname($targetKey), 0755, true);
        }
        if (@file_put_contents($targetKey, $legacyKey) !== false) {
            @chmod($targetKey, 0600);
            return;
        }
    }
}

/**
 * @return list<string>
 */
function user_management_candidate_data_dirs(): array
{
    $candidates = [];
    $pluginRoot = __DIR__;
    if (function_exists('birkly_data_root')) {
        $dataRoot = birkly_data_root();
        if (is_string($dataRoot) && $dataRoot !== '') {
            $root = rtrim($dataRoot, '/');
            $candidates[] = $root . '/plugin-data/user_management';
            $candidates[] = $root . '/data/plugins/user_management';
            // Old includes/UserStorage path when plugin code lived under data/plugins/
            $candidates[] = $root . '/data/data/plugins/user_management';
        }
    }
    $candidates[] = user_management_cms_root() . '/data/plugins/user_management';
    // Relative fallback from plugin install tree (Hub data/plugins layout)
    $candidates[] = dirname($pluginRoot, 2) . '/data/plugins/user_management';
    $candidates[] = $pluginRoot . '/data/plugins/user_management';

    $seen = [];
    $unique = [];
    foreach ($candidates as $dir) {
        $key = is_dir($dir) ? (realpath($dir) ?: $dir) : $dir;
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $unique[] = $dir;
    }

    return $unique;
}

/**
 * Test whether a key can decrypt encrypted user records in a data dir.
 */
function user_management_encryption_key_valid_for_dir(string $dataDir, string $key): bool
{
    $dataDir = rtrim($dataDir, '/');
    $usersDir = $dataDir . '/users';
    if (!is_dir($usersDir)) {
        return true;
    }

    $encryptedFound = false;
    foreach (glob($usersDir . '/*.json') ?: [] as $file) {
        $raw = json_decode((string) file_get_contents($file), true);
        if (!is_array($raw) || empty($raw['_encrypted']) || !isset($raw['email'])) {
            continue;
        }
        $encryptedFound = true;
        if (user_management_decrypt_field((string) $raw['email'], $key) !== null) {
            return true;
        }
    }

    return !$encryptedFound;
}

/**
 * Decrypt one encrypted field value with a candidate key.
 */
function user_management_decrypt_field(string $encrypted, string $key): ?string
{
    $encrypted = trim($encrypted);
    if ($encrypted === '' || $key === '') {
        return null;
    }

    $data = base64_decode($encrypted, true);
    if ($data === false) {
        return null;
    }

    $ivLength = openssl_cipher_iv_length('aes-256-cbc');
    if ($ivLength === false || strlen($data) < $ivLength) {
        return null;
    }

    $iv = substr($data, 0, $ivLength);
    $payload = substr($data, $ivLength);
    $plain = openssl_decrypt($payload, 'aes-256-cbc', $key, 0, $iv);
    if (!is_string($plain) || $plain === '') {
        return null;
    }

    return $plain;
}

/**
 * Resolve the active encryption key for member account field values.
 */
function user_management_get_encryption_key(): string
{
    $dir = user_management_data_dir();
    $keyFile = $dir . '/metadata/encryption_key.txt';

    if (function_exists('user_management_migrate_encryption_key')) {
        user_management_migrate_encryption_key($dir);
    }

    if (is_file($keyFile)) {
        $existing = trim((string) file_get_contents($keyFile));
        if ($existing !== '') {
            if (
                !function_exists('user_management_encryption_key_valid_for_dir')
                || user_management_encryption_key_valid_for_dir($dir, $existing)
            ) {
                return $existing;
            }
        }
    }

    if (function_exists('user_management_candidate_encryption_keys')) {
        foreach (user_management_candidate_encryption_keys($dir) as $legacyKey) {
            if (
                function_exists('user_management_encryption_key_valid_for_dir')
                && !user_management_encryption_key_valid_for_dir($dir, $legacyKey)
            ) {
                continue;
            }
            if (!is_dir(dirname($keyFile))) {
                mkdir(dirname($keyFile), 0755, true);
            }
            file_put_contents($keyFile, $legacyKey);
            chmod($keyFile, 0600);

            return $legacyKey;
        }
    }

    $key = bin2hex(random_bytes(32));
    if (!is_dir(dirname($keyFile))) {
        mkdir(dirname($keyFile), 0755, true);
    }
    file_put_contents($keyFile, $key);
    chmod($keyFile, 0600);

    return $key;
}

/**
 * Encrypt one sensitive field value (AES-256-CBC, same format as UserStorage).
 */
function user_management_encrypt_field(string $plain, ?string $key = null): string
{
    $plain = trim($plain);
    if ($plain === '') {
        return '';
    }

    $key = $key ?? user_management_get_encryption_key();
    $ivLength = openssl_cipher_iv_length('aes-256-cbc');
    if ($ivLength === false) {
        throw new RuntimeException('Unable to resolve cipher IV length');
    }
    $iv = openssl_random_pseudo_bytes($ivLength);
    $encrypted = openssl_encrypt($plain, 'aes-256-cbc', $key, 0, $iv);
    if ($encrypted === false) {
        throw new RuntimeException('Unable to encrypt field value');
    }

    return base64_encode($iv . $encrypted);
}

/**
 * Collect encryption keys from all candidate data dirs (target first).
 *
 * @return list<string>
 */
function user_management_candidate_encryption_keys(?string $preferredDir = null): array
{
    $keys = [];
    $seen = [];

    $dirs = [];
    if (is_string($preferredDir) && $preferredDir !== '') {
        $dirs[] = rtrim($preferredDir, '/');
    }
    foreach (user_management_candidate_data_dirs() as $dir) {
        $dirs[] = rtrim($dir, '/');
    }

    foreach ($dirs as $dir) {
        $keyFile = $dir . '/metadata/encryption_key.txt';
        if (!is_file($keyFile)) {
            continue;
        }
        $key = trim((string) file_get_contents($keyFile));
        if ($key === '' || isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $keys[] = $key;
    }

    return $keys;
}

function user_management_resolve_writable_data_dir(string ...$candidates): string
{
    foreach ($candidates as $dir) {
        if (user_management_ensure_writable_dir($dir)) {
            return $dir;
        }
    }

    return $candidates[0] ?? user_management_cms_root() . '/data/plugins/user_management';
}

function user_management_ensure_writable_dir(string $dir): bool
{
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0755, true) && !is_dir($dir)) {
            return false;
        }
    }

    $probe = $dir . '/.write_probe_' . bin2hex(random_bytes(4));
    if (@file_put_contents($probe, 'ok') === false) {
        return false;
    }
    @unlink($probe);

    return true;
}

function user_management_reconcile_data_dirs(string $targetDir): void
{
    if (!is_dir($targetDir)) {
        return;
    }

    foreach (user_management_candidate_data_dirs() as $sourceDir) {
        if ($sourceDir === $targetDir || !is_dir($sourceDir)) {
            continue;
        }
        $realSource = realpath($sourceDir);
        $realTarget = realpath($targetDir);
        if ($realSource !== false && $realTarget !== false && $realSource === $realTarget) {
            continue;
        }

        user_management_merge_data_tree($sourceDir, $targetDir);
    }

    user_management_merge_orphan_users($targetDir);
}

/**
 * Copy user JSON from legacy dirs when missing or unreadable in the active dir.
 */
function user_management_merge_orphan_users(string $targetDir): void
{
    $targetDir = rtrim($targetDir, '/');
    $targetUsers = $targetDir . '/users';
    if (!is_dir($targetUsers)) {
        @mkdir($targetUsers, 0755, true);
    }

    $activeKey = '';
    $activeKeyFile = $targetDir . '/metadata/encryption_key.txt';
    if (is_file($activeKeyFile)) {
        $activeKey = trim((string) file_get_contents($activeKeyFile));
    }

    foreach (user_management_candidate_data_dirs() as $sourceDir) {
        $sourceDir = rtrim($sourceDir, '/');
        if ($sourceDir === $targetDir) {
            continue;
        }
        $sourceUsers = $sourceDir . '/users';
        if (!is_dir($sourceUsers)) {
            continue;
        }

        foreach (glob($sourceUsers . '/*.json') ?: [] as $from) {
            $basename = basename($from);
            $to = $targetUsers . '/' . $basename;
            if (!is_file($to)) {
                @copy($from, $to);
                continue;
            }

            if (user_management_user_file_readable($to, $activeKey)) {
                continue;
            }

            if (user_management_user_file_readable($from, $activeKey)) {
                @copy($from, $to);
            }
        }
    }
}

function user_management_user_file_readable(string $file, string $activeKey): bool
{
    $raw = json_decode((string) file_get_contents($file), true);
    if (!is_array($raw)) {
        return false;
    }
    if (empty($raw['_encrypted']) || !isset($raw['email'])) {
        return true;
    }

    if ($activeKey !== '' && user_management_decrypt_field((string) $raw['email'], $activeKey) !== null) {
        return true;
    }

    foreach (user_management_candidate_encryption_keys() as $candidateKey) {
        if (user_management_decrypt_field((string) $raw['email'], $candidateKey) !== null) {
            return true;
        }
    }

    return false;
}

function user_management_merge_data_tree(string $sourceDir, string $targetDir): void
{
    $items = @scandir($sourceDir);
    if (!is_array($items)) {
        return;
    }

    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $from = $sourceDir . '/' . $item;
        $to = $targetDir . '/' . $item;
        if (is_dir($from)) {
            if (!is_dir($to)) {
                @mkdir($to, 0755, true);
            }
            user_management_merge_data_tree($from, $to);
            continue;
        }
        if (!is_file($to) && is_file($from)) {
            @copy($from, $to);
        }
    }
}

/**
 * Public site URL for activation / verification links.
 */
function user_management_site_url(): string
{
    if (!function_exists('birkly_hosting_public_base_url')) {
        $hostingUrls = user_management_cms_path('core/hosting_urls.php');
        if (is_file($hostingUrls)) {
            require_once $hostingUrls;
        }
    }
    if (function_exists('birkly_hosting_public_base_url')) {
        $publicBase = rtrim((string) birkly_hosting_public_base_url(), '/');
        if ($publicBase !== '') {
            return $publicBase;
        }
    }

    $sitePath = user_management_cms_path('settings/site.json');
    if (is_file($sitePath)) {
        $settings = json_decode((string) file_get_contents($sitePath), true);
        if (!empty($settings['url'])) {
            return rtrim((string) $settings['url'], '/');
        }
    }

    $adminPath = user_management_cms_path('settings/admin.json');
    if (is_file($adminPath)) {
        $admin = json_decode((string) file_get_contents($adminPath), true);
        if (!empty($admin['cms_url'])) {
            return rtrim((string) $admin['cms_url'], '/');
        }
    }

    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    return $protocol . '://' . $host;
}

function user_management_load_birkly_mail(): void
{
    $resolvePath = user_management_cms_path('core/connections/resolve.php');
    if (is_file($resolvePath) && !function_exists('birkly_resolve_email_connection_alias')) {
        require_once $resolvePath;
    }
    if (function_exists('birkly_send_mail')) {
        return;
    }
    $mailPath = user_management_cms_path('core/mail/birkly_send_mail.php');
    if (is_file($mailPath)) {
        require_once $mailPath;
    }
}
