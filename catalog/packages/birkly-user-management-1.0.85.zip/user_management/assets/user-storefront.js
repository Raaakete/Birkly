/**
 * Birkly User Management storefront helper (plugin-owned).
 *
 * Auto-loaded via plugin.json storefront.scripts when User Management is active.
 * Sites may still include manually (deprecated one release):
 *   <script src="/plugins/user_management/assets/user-storefront.js"></script>
 *
 * window.BirklyUser
 *   .session()
 *   .login({ email, password, remember? })
 *   .logout()
 *   .profile()
 *   .deletePreview()
 *   .deleteAccount({ confirm, force_cancel_subscriptions? })
 *   .bind(root?)
 *
 * Declarative regions (after bind):
 *   [data-birkly-account-guest]   — shown when signed out
 *   [data-birkly-account-member]  — shown when signed in
 *   form[data-birkly-login]       — login form wiring
 *   form[data-birkly-delete-account] — delete account with subscription guard
 */
(function (global) {
  'use strict';

  var SITE_SESSION_KEY = 'birkly_site_session_id';
  var ACCOUNT_ROUTE = 'user_account';
  var gateWired = false;

  function getBirkly() {
    return global.Birkly || null;
  }

  function cmsBase() {
    var Birkly = getBirkly();
    var base = (Birkly && Birkly.cmsUrl) ? String(Birkly.cmsUrl) : '';
    return base.replace(/\/$/, '');
  }

  function withSiteSessionHeaders(headers) {
    headers = headers || {};
    try {
      var sid = localStorage.getItem(SITE_SESSION_KEY) || '';
      if (sid) {
        headers['X-Birkly-Site-Session'] = sid;
      }
    } catch (e) { /* ignore */ }
    return headers;
  }

  function captureSiteSession(json) {
    if (json && json.site_session_id) {
      try {
        localStorage.setItem(SITE_SESSION_KEY, String(json.site_session_id));
      } catch (e) { /* ignore */ }
    }
  }

  function credentialedFetch(url, opts) {
    opts = opts || {};
    opts.credentials = 'include';
    opts.headers = withSiteSessionHeaders(Object.assign({ Accept: 'application/json' }, opts.headers || {}));
    return fetch(url, opts);
  }

  function routeFetch(opts) {
    var Birkly = getBirkly();
    if (Birkly && typeof Birkly.routeFetch === 'function') {
      return Birkly.routeFetch(opts);
    }
    if (Birkly && typeof Birkly.fetch === 'function') {
      return Birkly.fetch(opts);
    }

    var route = String(opts.route || '').trim();
    var action = String(opts.action || '').trim();
    var method = String(opts.method || 'GET').toUpperCase();
    var url = cmsBase() + '/api/index.php?route=' + encodeURIComponent(route)
      + '&action=' + encodeURIComponent(action);
    var headers = Object.assign({ Accept: 'application/json' }, opts.headers || {});
    var fetchOpts = { method: method, credentials: 'include', headers: withSiteSessionHeaders(headers) };

    if (opts.body !== undefined && method !== 'GET' && method !== 'HEAD') {
      if (opts.body instanceof FormData) {
        fetchOpts.body = opts.body;
      } else if (typeof opts.body === 'string') {
        fetchOpts.body = opts.body;
      } else {
        if (!headers['Content-Type'] && !headers['content-type']) {
          headers['Content-Type'] = 'application/json';
        }
        fetchOpts.body = JSON.stringify(opts.body);
      }
    }

    return credentialedFetch(url, fetchOpts).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (json) {
        captureSiteSession(json);
        if (!res.ok && opts.throwOnError !== false) {
          var err = new Error((json && (json.error || json.message)) || ('HTTP ' + res.status));
          err.status = res.status;
          err.response = json;
          throw err;
        }
        return json;
      });
    });
  }

  function getSiteConfig() {
    var Birkly = getBirkly();
    if (Birkly && Birkly.siteClientConfig && typeof Birkly.siteClientConfig === 'object') {
      return Promise.resolve(Birkly.siteClientConfig);
    }
    if (Birkly && typeof Birkly.fetch === 'function') {
      return Birkly.fetch('site_client_config').then(function (json) {
        var data = (json && json.data && typeof json.data === 'object') ? json.data : {};
        if (Birkly) {
          Birkly.siteClientConfig = data;
        }
        return data;
      }).catch(function () {
        return {};
      });
    }
    return Promise.resolve({});
  }

  function publicUser(user) {
    if (!user || typeof user !== 'object') {
      return null;
    }
    return {
      id: user.id || '',
      name: user.name || user.username || '',
      email: user.email || '',
      signed_in: true
    };
  }

  function parseJson(res) {
    return res.json().then(function (json) {
      captureSiteSession(json);
      if (!res.ok || (json && (json.success === false || json.error))) {
        var err = new Error((json && (json.error || json.message)) || 'User request failed');
        err.status = res.status;
        err.response = json;
        throw err;
      }
      return json;
    });
  }

  function csrfToken() {
    var meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') || '' : '';
  }

  function extractCsrfToken(json) {
    if (!json || typeof json !== 'object') {
      return '';
    }
    if (json.data && typeof json.data === 'object') {
      if (json.data.csrf_token) return json.data.csrf_token;
      if (json.data.token) return json.data.token;
    }
    if (json.csrf_token) return json.csrf_token;
    if (json.token) return json.token;
    return '';
  }

  function fetchCsrf() {
    return getSiteConfig().then(function (config) {
      var path = (config.auth && config.auth.csrf) || '/api/csrf.php';
      var url = cmsBase() + (path.charAt(0) === '/' ? path : '/' + path);
      return credentialedFetch(url, {
        method: 'GET',
        headers: { Accept: 'application/json' }
      }).then(parseJson).then(function (json) {
        var token = extractCsrfToken(json);
        return token || csrfToken();
      }).catch(function () {
        return csrfToken();
      });
    });
  }

  function accountFetch(action, opts) {
    opts = opts || {};
    return routeFetch({
      route: ACCOUNT_ROUTE,
      action: action,
      method: opts.method || 'GET',
      body: opts.body,
      headers: opts.headers,
      throwOnError: opts.throwOnError
    });
  }

  function session() {
    return getSiteConfig().then(function (config) {
      var check = config.auth && config.auth.check;
      var route = (check && check.route) || 'user_auth';
      var action = (check && check.action) || 'check';
      return routeFetch({
        route: route,
        action: action,
        method: 'GET',
        throwOnError: false
      }).then(function (json) {
        var signedIn = !!(json && json.logged_in);
        return {
          signed_in: signedIn,
          user: signedIn ? publicUser(json.user) : null
        };
      });
    });
  }

  function login(args) {
    args = args || {};
    return getSiteConfig().then(function (config) {
      var loginCfg = config.auth && config.auth.login;
      var route = (loginCfg && loginCfg.route) || 'user_auth';
      var action = (loginCfg && loginCfg.action) || 'login';
      var body = new URLSearchParams();
      body.set('email', args.email || '');
      body.set('password', args.password || '');
      if (args.remember) {
        body.set('remember', 'true');
      }
      return routeFetch({
        route: route,
        action: action,
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/json'
        },
        body: body.toString(),
        throwOnError: false
      });
    }).then(function (json) {
      if (json && json.requires_2fa) {
        return {
          ok: false,
          requires_2fa: true,
          message: json.message || '2FA code required'
        };
      }
      if (json && json.error) {
        var fail = new Error(json.error || 'Sign-in failed');
        fail.response = json;
        throw fail;
      }
      return {
        ok: true,
        signed_in: true,
        user: publicUser(json && json.user)
      };
    });
  }

  function logout() {
    return getSiteConfig().then(function (config) {
      var logoutCfg = config.auth && config.auth.logout;
      var route = (logoutCfg && logoutCfg.route) || 'user_auth';
      var action = (logoutCfg && logoutCfg.action) || 'logout';
      return fetchCsrf().then(function (token) {
        var body = new URLSearchParams();
        if (token) body.set('csrf_token', token);
        return routeFetch({
          route: route,
          action: action,
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            Accept: 'application/json'
          },
          body: body.toString(),
          throwOnError: false
        });
      });
    }).then(function () {
      return { ok: true, signed_in: false, user: null };
    });
  }

  function profile() {
    return accountFetch('profile', { method: 'GET' });
  }

  function updateProfile(args) {
    args = args || {};
    return fetchCsrf().then(function (token) {
      return accountFetch('update_profile', {
        method: 'POST',
        body: {
          title: args.title || args.name || '',
          bio: args.bio || '',
          description: args.description || args.bio || '',
          website: args.website || '',
          links: args.links || '',
          csrf_token: token
        }
      });
    });
  }

  function uploadAvatar(file) {
    if (!file) {
      return Promise.reject(new Error('No file selected'));
    }
    return fetchCsrf().then(function (token) {
      var form = new FormData();
      form.append('avatar', file);
      form.append('csrf_token', token);
      var url = cmsBase() + '/api/index.php?route=' + encodeURIComponent(ACCOUNT_ROUTE)
        + '&action=' + encodeURIComponent('upload_avatar');
      return credentialedFetch(url, {
        method: 'POST',
        headers: { Accept: 'application/json' },
        body: form
      }).then(parseJson);
    });
  }

  function changePassword(args) {
    args = args || {};
    return fetchCsrf().then(function (token) {
      return accountFetch('change_password', {
        method: 'POST',
        body: {
          current_password: args.current_password || '',
          new_password: args.new_password || '',
          csrf_token: token
        }
      });
    });
  }

  function deletePreview() {
    return accountFetch('delete_preview', { method: 'GET' });
  }

  function deleteAccount(args) {
    args = args || {};
    return fetchCsrf().then(function (token) {
      return routeFetch({
        route: ACCOUNT_ROUTE,
        action: 'delete_account',
        method: 'POST',
        body: {
          confirm: !!args.confirm,
          force_cancel_subscriptions: !!args.force_cancel_subscriptions,
          csrf_token: args.csrf_token || token || csrfToken()
        },
        throwOnError: false
      });
    }).then(function (json) {
      if (json && json.code === 'active_subscriptions') {
        var err = new Error(json.error || 'Active subscriptions block deletion');
        err.status = 409;
        err.response = json;
        err.code = 'active_subscriptions';
        err.subscriptions = json.subscriptions || [];
        throw err;
      }
      if (json && (json.success === false || json.error)) {
        var fail = new Error((json && (json.error || json.message)) || 'Delete failed');
        fail.response = json;
        throw fail;
      }
      return json;
    });
  }

  function setVisible(el, show) {
    if (!el) return;
    if (show) {
      el.removeAttribute('hidden');
    } else {
      el.setAttribute('hidden', 'hidden');
    }
  }

  function syncAccountRegions(scope, state) {
    var guest = scope.querySelector('[data-birkly-account-guest]');
    var member = scope.querySelector('[data-birkly-account-member]');
    var emailEl = scope.querySelector('[data-birkly-account-email]');
    setVisible(guest, !state.signed_in);
    setVisible(member, !!state.signed_in);
    if (emailEl && state.user) {
      emailEl.textContent = state.user.email || '';
    }
  }

  function bindLoginForm(form) {
    if (!form || form.getAttribute('data-birkly-login-bound') === '1') return;
    form.setAttribute('data-birkly-login-bound', '1');
    var statusEl = form.parentElement
      ? form.parentElement.querySelector('[data-birkly-login-status]')
      : null;

    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var fd = new FormData(form);
      if (statusEl) statusEl.textContent = 'Signing in…';
      login({
        email: fd.get('email') || '',
        password: fd.get('password') || '',
        remember: fd.get('remember') === 'on' || fd.get('remember') === '1'
      }).then(function (result) {
        if (!result.ok) {
          if (statusEl) statusEl.textContent = result.message || 'Sign-in failed';
          return;
        }
        if (statusEl) statusEl.textContent = '';
        return refreshAccountUi(form.closest('main') || document);
      }).catch(function (err) {
        if (statusEl) statusEl.textContent = err.message || 'Sign-in failed';
      });
    });
  }

  function bindDeleteAccountForm(form) {
    if (!form || form.getAttribute('data-birkly-delete-bound') === '1') return;
    form.setAttribute('data-birkly-delete-bound', '1');
    var statusEl = form.parentElement
      ? form.parentElement.querySelector('[data-birkly-delete-status]')
      : null;

    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var fd = new FormData(form);
      if (fd.get('confirm') !== '1' && fd.get('confirm') !== 'on') {
        if (statusEl) statusEl.textContent = 'Please confirm account deletion.';
        return;
      }

      function attempt(forceCancel) {
        if (statusEl) statusEl.textContent = 'Deleting account…';
        return deleteAccount({ confirm: true, force_cancel_subscriptions: !!forceCancel }).then(function () {
          if (statusEl) statusEl.textContent = 'Account deleted.';
          window.location.href = form.getAttribute('data-success-url') || '/';
        }).catch(function (err) {
          if (err.code === 'active_subscriptions') {
            var subs = err.subscriptions || [];
            var summary = subs.map(function (s) {
              return (s.id || 'subscription') + ' (' + (s.status || 'active') + ')';
            }).join('\n');
            var proceed = window.confirm(
              'You have active subscriptions:\n\n' + (summary || 'Active subscription(s)')
              + '\n\nCancel all subscriptions and delete your account?'
            );
            if (!proceed) {
              if (statusEl) statusEl.textContent = 'Deletion canceled. Cancel subscriptions first.';
              return;
            }
            return attempt(true);
          }
          if (statusEl) statusEl.textContent = err.message || 'Delete failed';
        });
      }

      attempt(false);
    });
  }

  function refreshAccountUi(scope) {
    scope = scope || document;
    return session().then(function (state) {
      syncAccountRegions(scope, state);
      if (state.signed_in && global.BirklyCommerce && typeof global.BirklyCommerce.refreshSubscriptions === 'function') {
        global.BirklyCommerce.refreshSubscriptions(scope);
      }
      return state;
    });
  }

  /**
   * Redirect guests away from member-only pages.
   * Markup: <body data-user-require-auth data-user-login-url="/club/login.html">
   * Legacy alias: data-birkly-require-member
   */
  function requireAuthGate(root) {
    root = root || document;
    var gate = root.querySelector('[data-user-require-auth], [data-birkly-require-member]');
    if (!gate) {
      return Promise.resolve({ signed_in: true, user: null });
    }
    return session().then(function (state) {
      if (state && state.signed_in) {
        return state;
      }
      var loginUrl = gate.getAttribute('data-user-login-url')
        || gate.getAttribute('data-birkly-login-url')
        || '/club/login.html';
      var returnTo = window.location.pathname + window.location.search + window.location.hash;
      var sep = loginUrl.indexOf('?') >= 0 ? '&' : '?';
      window.location.replace(loginUrl + sep + 'return=' + encodeURIComponent(returnTo));
      return state;
    });
  }

  function wireRequireAuthGate(root) {
    if (gateWired) return;
    root = root || document;
    if (!root.querySelector('[data-user-require-auth], [data-birkly-require-member]')) {
      return;
    }
    gateWired = true;
    onClientReady(function () {
      requireAuthGate(root).catch(function () {});
    });
  }

  function onClientReady(fn) {
    if (typeof document === 'undefined') return;
    var ran = false;
    function run() {
      if (ran) return;
      ran = true;
      fn();
    }
    document.addEventListener('birkly:plugins-ready', run, { once: true });
    document.addEventListener('birkly:client-ready', run, { once: true });
    var Birkly = getBirkly();
    if (Birkly && Birkly.initialized) {
      run();
    }
  }

  function bind(root) {
    var scope = root || document;
    Array.prototype.slice.call(scope.querySelectorAll('form[data-birkly-login], form[data-login], form.login, form#login')).forEach(function (form) {
      if (!form.getAttribute('data-birkly-login')) {
        form.setAttribute('data-birkly-login', '');
      }
      bindLoginForm(form);
    });
    Array.prototype.slice.call(scope.querySelectorAll('form[data-birkly-delete-account]')).forEach(bindDeleteAccountForm);
    refreshAccountUi(scope);
    wireRequireAuthGate(scope);
    return BirklyUser;
  }

  var BirklyUser = {
    session: session,
    login: login,
    logout: logout,
    profile: profile,
    updateProfile: updateProfile,
    uploadAvatar: uploadAvatar,
    changePassword: changePassword,
    deletePreview: deletePreview,
    deleteAccount: deleteAccount,
    bind: bind,
    refreshAccountUi: refreshAccountUi,
    requireAuthGate: requireAuthGate
  };

  global.BirklyUser = BirklyUser;

  if (typeof document !== 'undefined') {
    onClientReady(function () {
      bind(document);
    });
  }
})(typeof window !== 'undefined' ? window : this);
