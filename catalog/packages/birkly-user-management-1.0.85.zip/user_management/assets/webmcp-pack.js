/**
 * User Management WebMCP runtime pack (P83-M4).
 */
(function () {
    'use strict';

    var api = window.BirklyWebMcp = window.BirklyWebMcp || {};
    api._packs = api._packs || {};

    api._packs.user_management = function (register, toolEnabled) {
        var U = window.BirklyUser || null;

        if (toolEnabled('birkly_user_session')) {
            register({
                name: 'birkly_user_session',
                scope: 'user',
                description: 'Report whether the visitor is signed in, plus basic public session state.',
                execute: function () {
                    if (U && typeof U.session === 'function') return U.session();
                    var el = document.querySelector('[data-birkly-user-session]');
                    var loggedIn = el ? el.getAttribute('data-birkly-user-session') === 'in' : false;
                    return { signed_in: loggedIn };
                }
            });
        }
        if (toolEnabled('birkly_user_login')) {
            register({
                name: 'birkly_user_login',
                scope: 'user',
                description: 'Start visitor sign-in. Off unless the owner opts in; always asks the visitor to confirm.',
                mutating: true,
                consent: 'login',
                inputSchema: {
                    type: 'object',
                    properties: { email: { type: 'string' }, password: { type: 'string' } }
                },
                confirmMessage: function () { return 'Allow the AI assistant to sign you in?'; },
                gate: function () {
                    return !!(U && typeof U.login === 'function') || !!document.querySelector('form[data-birkly-login], [data-birkly-login]');
                },
                execute: function (args) {
                    if (U && typeof U.login === 'function') return U.login(args || {});
                    var form = document.querySelector('form[data-birkly-login]');
                    if (form) {
                        if (args && args.email) { var e = form.querySelector('[name="email"]'); if (e) e.value = args.email; }
                        if (args && args.password) { var p = form.querySelector('[name="password"]'); if (p) p.value = args.password; }
                        if (typeof form.requestSubmit === 'function') form.requestSubmit(); else form.submit();
                        return { ok: true, note: 'Login form submitted.' };
                    }
                    throw new Error('No login surface on this page.');
                }
            });
        }
    };
})();
