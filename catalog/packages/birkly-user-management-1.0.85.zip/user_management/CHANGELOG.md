# Changelog

## 1.0.85 - 2026-09-08

- **Fix:** Declare P82 storefront shelf hooks in `plugin.json` for Hub preflight (`birkly_public_current_user`, `birkly_site_client_config`, `birkly_entries_view_filter`, `birkly_entry_view_allowed`). Restores tag import and update availability for new releases.

## 1.0.84 - 2026-09-08

- Remove baked-in club notification and club notification digest email template defaults (slots remain; configure in User → Emails).

## 1.0.82 - 2026-09-08

- **P83-M4:** WebMCP runtime pack shelf — `assets/webmcp-pack.js` + `includes/webmcp_runtime.php` register user visitor tools via `birkly_webmcp_register_runtime_pack()`.

## 1.0.79 - 2026-09-08

- **Fix:** Donation signup flow (`pay_then_activate`) grants club tier and sends welcome email when the payer already has a site account (was silently skipped).
- **Fix:** `commerce_order_paid` signup-flow handler no longer returns `user_already_exists` without provisioning.

## 1.0.78 - 2026-09-08

- **Storefront:** `BirklyUser.requireAuthGate()` redirects guests from member-only pages (`data-user-require-auth` / legacy `data-birkly-require-member`).
- **Club:** Example `@mention` autocomplete script (`examples/project/js/club-mentions.js`) with improved keyboard handling.

## 1.0.77 - 2026-09-07

- **Fix:** Club tier reconcile now runs on plugin load (require before `function_exists` guard was skipping it entirely).
- **Fix:** Grant `club` tier on `user_logged_in` when the member already has a `club-profiles` entry.
- **Admin/MCP:** `reconcile_club_tiers` admin action and `user_reconcile_club_tiers` MCP tool.

## 1.0.76 - 2026-09-07

- **Fix:** `user_management_reconcile_club_tiers()` grants `club` tier to members with a `club-profiles` entry who are still on `all` (incomplete signup repair).
- **Fix:** `club_free_register` `create_club_profile` step grants the flow tier immediately so posting works even when later steps fail.

## 1.0.75 - 2026-09-07

- **Fix:** Return `site_session_id` on login for cross-origin club sites when browsers block CMS cookies (`X-Birkly-Site-Session` header fallback).

## 1.0.74 - 2026-09-07

- **Fix:** `club_free_register` HTML forms auto-complete signup when email/password are posted as flat fields (birkly.io register page).
- **Fix:** Align fallback site session `SameSite` with cross-origin CMS session helper.

## 1.0.73 - 2026-09-07

- **Fix:** Rename plugin `RateLimiter` to `UserRateLimiter` to avoid fatal collision with core `api/rate_limit.php` when `user_auth` runs via `api/index.php` (CORS loads `domain_auth` first). Club login/signup returned HTTP 500 / "Action failed".

## 1.0.72 - 2026-09-07

- **P81:** Idempotent `user_management_ensure_club_posts_subcollection_schemas()` restores `ownership: true` on comments/replies/likes and `aggregate_on_parent` for feed counts after MCP schema updates stripped them.

## 1.0.71 - 2026-09-07

- **P81-M6:** Fix `EntryPermissions` graph bootstrap so block/mute checks work without CMS `api/storage.php` on disk.

## 1.0.70 - 2026-09-07

- **P81-M5:** `UserNotificationService` replaces `ClubNotificationService` (compat alias); data writes to `user_notifications/`, reads legacy `club_notifications/` too.
- **P81-M5:** Primary API route `user_notifications` with `club_notifications` alias; notification hooks driven by `user_plugin.notifications` markers.
- **P81-M6:** `EntryPermissions::canViewEntry` applies block/mute before visibility; passes collection slug in public filter hooks.
- **P81-M7:** Template functions `{user_notifications}` and `{user_notification_unread_count}` for SSR inbox.
- **P81-M8:** `UserMentionService` (compat alias) + `{render_mentions}` template function; mention hooks use `mentions_enabled` marker.

## 1.0.69 - 2026-09-05

- **P80-M6:** Declare club automation hooks in `plugin.json` manifest for Hub preflight (no runtime change).

## 1.0.68 - 2026-09-05

- **P80-M6:** `ClubAutomationHooks` bridges club lifecycle hooks to Automation `enqueue_automation` (profile, onboarding, posts, mentions, badges, reports, tier changes).
- **P80-M6:** Fires `club_profile_created`, `club_post_created`, and `supporter_badge_granted` hooks; enriches `club_member_onboarded` and `club_member_reported` payloads.
- **P80-M6:** Registers club trigger blocks in the Automation node editor palette.

## 1.0.67 - 2026-09-05

- **P80-M5:** `club-wishes` schema — `decline_reason`, `roadmap_link`, status enum (`pending`, `under_review`, `planned`, `shipped`, `declined`); legacy `accepted`/`rejected` migrated on upgrade.
- **P80-M5:** `ClubWishService` + admin `club_wishes?action=promote` copies a wish into a `roadmap-features` draft and links `roadmap_link`.
- **P80-M5:** `club-deals` analytics fields `copy_count`, `visit_count`; `club_deals?action=track` (session + CSRF) increments counters.
- **P80-M5:** Seeds pinned `club-posts` entry **Introduce yourself** (`author: __birkly__`, slug `introduce-yourself`).

## 1.0.66 - 2026-09-05

- **P80-M4:** `user_graph` actions `mute`, `unmute`, `list_blocks`, `list_mutes`; block/mute graph edges in `UserGraphStore`.
- **P80-M4:** `ClubReportService` + `club_reports` API (`submit`, admin `list`, `hide_post`); `club-reports` collection schema ensure.
- **P80-M4:** `moderation_hidden` field on `club-posts`; public feed filter hides moderated posts and blocked authors.
- **P80-M4:** Club notifications skip actors muted by the recipient.
- **P80-M4:** Fires `club_member_reported` hook when a member submits a report.

## 1.0.65 - 2026-09-05

- **P80-M3:** `ClubMentionParser` resolves `@slug` / `@DisplayName` mentions to user IDs on `club-posts` save and comment create.
- **P80-M3:** `mentioned_user_ids` schema field on `club-posts`; `mention` notification type with `notify_mentions` / `email_mentions` prefs.
- **P80-M3:** `ClubNotificationDigestService` + `club_notification_digest` email template; Automation action `send_club_notification_digests`.
- **P80-M3:** Digest prefs: `digest_enabled`, `digest_frequency`, `digest_last_sent_at`.
- **P80-M3:** Fires `club_mention_created` hook when mentions notify.

## 1.0.64 - 2026-09-05

- **P80-M2:** `club-profiles` onboarding fields (`interests`, `onboarding_completed`, `profile_completeness`) with schema ensure on plugin load.
- **P80-M2:** `ClubProfileService::computeCompleteness()`, `getProfileBySlug()`, `toPublicProfile()`; completeness recalculated on profile save.
- **P80-M2:** `ClubOnboardingService` plus `user_account` actions `onboarding_status`, `complete_onboarding`, and guest-readable `public_profile`.
- **P80-M2:** Fires `club_member_onboarded` hook when onboarding completes.

## 1.0.63 - 2026-09-05

- **P80-M1:** Account activation (`completeActivation`) creates a `club-profiles` entry when the collection exists and the member has no profile yet.
- **P80-M1:** Automation plugin action `send_activation_email` for membership activation recipes (entitlement-aware, rate-limited via `UserActivationShelf`).

## 1.0.62 - 2026-09-05

- **Fix:** `club_free_register` signup now auto-completes profile creation, tier grant, and redirect in one `runStep` call (frontend only sent the first step).
- **Fix:** Optional `verify_email` signup steps are skipped instead of sending verification mail during club free signup.
- **Fix:** Supporter badge reconcile creates a missing `club-profiles` entry for club-tier users before applying badge fields (donations after signup).

## 1.0.61 - 2026-09-05

- **Club notifications:** In-app notification inbox for club members — Birkly posts, new deals, comments/reactions on your posts, and posts from people you follow.
- **Preferences:** Per-member notification settings stored on `club-profiles` (`notification_prefs` JSON) with separate in-app and email toggles.
- **API:** `club_notifications` route (`list`, `unread_count`, `mark_read`, `mark_all_read`, `get_preferences`, `save_preferences`).
- **Email:** `club_notification` template via UserEmailService + Connections mail pipeline when email prefs are enabled.
- **Hooks:** `sub_entry_created` (comments/likes) and `after_entry_save` (new club posts/deals); CMS `public_submit` now fires `after_entry_save` for member-created posts.
- **Fix:** Register `user_account` API route (was missing from `plugin.php`).

## 1.0.60 - 2026-09-05

- **P79:** Configurable supporter badge rules (`supporter_badge_rules.json`) and `SupporterBadgeSync` service reconcile badge fields on `club-profiles` from Commerce orders, subscriptions, and `supporters` entries.
- **P79:** `club_free_register` signup preset with `create_club_profile` step — free club tier without payment.
- **P79:** Subscription cancel/pause downgrades donor badge only; club tier access is preserved (P79-D4).
- **Admin:** `reconcile_supporter_badges` batch action and MCP tool `user_reconcile_supporter_badges`.
- **Automation:** `sync_supporter_badge` plugin action when Automation is active.

## 1.0.59 - 2026-09-05

- **Fix:** ClubProfileService resolves profile owner from `account.legacy_user_id` (P78) so member directory and profile API work after owner field removal.
- **Fix:** P77 migrate writes `user_id` on club-profiles entries for backward compatibility.

## 1.0.58 - 2026-09-04

- **Hotfix:** User fieldtype `getAdminConfig()` no longer fatals on Content pages — call global `user_management_list_site_role_ids()` from namespaced class (fixes "Error Loading Page" on all collections/entries).

## 1.0.57 - 2026-09-04

- **P78:** `club-profiles` drops redundant `owner` field — ownership resolves from `account.legacy_user_id` (core + plugin).
- **P78:** Site user account fieldtype entry editor — vertical sections (Account, Access, Tier, Profile fields).
- **UX:** Rename user-facing "member account" / "Club members" labels to "site user account" / tier user account.
- **Core (Birkly):** `birkly_get_entry_owner_id` and relationship validation accept `user_account*` fields.

## 1.0.56 - 2026-09-04

- **Fix:** Fieldtype profiles modal close/save buttons work (listeners were scoped to wrong panel).
- **Fix:** User fieldtype — owner fields are read-only in entry editor; no picking other users for profiles.
- **Fix:** User fieldtype schema UI — dynamic site-user roles (not hardcoded); owner fields show simplified help only.
- **Fix:** Club user account fieldtype — removed duplicate Field name/Label in collection schema editor.
- **UX:** Hide separate Members tab; **Sync profile entries** on User List runs P77 reconcile.
- **UX:** Auto-reconcile `club-profiles` entries on plugin load and when admins create users.

## 1.0.55 - 2026-09-04

- **Fix:** Members tab — "Migrate from User List" action wires to `user_members` migrate API (P77-M8).
- **Fix:** Default role and User List role filter load dynamically from actual site users (`list_roles`), not hardcoded plugin.json options.
- **Fix:** Profile Collection Settings marked legacy with P77 guidance; Members tab explains `user_account*` indexing.
- **MCP:** `user_list_site_users`, `user_list_members_index`, `user_migrate_p77_members`, `user_reindex_members` tools for admin MCP connections.

## 1.0.54 - 2026-09-04

- **Fix:** Declare `birkly_ai_read_entry` in `plugin.json` hooks manifest so Hub preflight import succeeds (P77 UserAccount MCP redaction filter).

## 1.0.53 - 2026-09-04

- **P77-M8:** `MemberMigrateService` + `scripts/migrate-p77-members.php` — migrate UserStorage users into member collection entries.
- **P77-M8:** `MemberLegacyMap` — `user_id` ↔ `member_id` mapping; `MemberAuthService` dual-read login fallback.
- **P77-M8:** `member_entry_signup_only` setting blocks legacy `user_registration` after cutover.
- **P77-M8:** `user_relationship` anchor resolves `legacy_user_id` / mapped member accounts.
- **P77-M8:** Tests P77-LIVE-01–04.

## 1.0.52 - 2026-09-04

- **P77-M7:** `MemberCommerceShelf` — Commerce shelf integration for member entries (checkout gate, customer link by `member_id`, payment summary).
- **P77-M7:** Signup returns `checkout_required` when `payment_required_at_signup`; pending entry until Commerce payment completes.
- **P77-M7:** `user_account` API — `payment_summary` and `payment_checkout` when `payment_enabled`.
- **P77-M7:** `UserAccount` fieldtype admin shows read-only Commerce payment summary (no card data).
- **P77-M7:** Tests P77-COM-01–06.

## 1.0.51 - 2026-09-04

- **P77-M6:** `MemberMigrationService` — in-place tier updates and cross-collection moves with stable `member_id`.
- **P77-M6:** `user_members` API — `plan_upgrade` and `change_tier` actions; Members admin tier change control.
- **P77-M6:** Requirement validation blocks publish when new tier profile fields or payment are unsatisfied.
- **P77-M6:** Tests P77-MIG-01–05.

## 1.0.50 - 2026-09-04

- **P77-M5:** `UserCollectionResolver` — Approach C schema helpers (`collectionSupportsProfile`, `listCollectionsForTypeKey`, `getAccountFieldOnSchema`).
- **P77-M5:** `MemberSignupService` — collection-scoped signup schema + register; `before_entry_create` hook for `{entry for}` public submits.
- **P77-M5:** `user_member_signup` API (`member_signup_schema`, `member_register`).
- **P77-M5:** `SignupFlowEngine` reads fieldtype profile when `collection` / `tier` passed in flow context.
- **P77-M5:** Tests P77-FLOW-01–06.

## 1.0.49 - 2026-09-04

- **P77-M4:** `UserMemberIndexer` — `members_index.json` keyed by `member_id`; hooks on entry save/delete.
- **P77-M4:** Members admin tab and `user_members` API (`list`, `get`, `reindex`).
- **P77-M4:** Tests P77-IDX-01–03, 05–06.

## 1.0.48 - 2026-09-04

- **P77-M3:** `TierProfileService` — tiers link to fieldtype profiles (`fieldtype_profile_id`, `fieldtype_type_key`).
- **P77-M3:** Tier create/edit wizard — requirements, capabilities, commerce, and profile confirm step.
- **P77-M3:** Auto-provision `user_account_{slug}` profiles on tier create; migrate global Signup Fields into default profile; hide Signup Fields tab.
- **P77-M3:** Tests P77-TIER-01–05.

## 1.0.47 - 2026-09-04

- **P77-M2:** `MemberAccountCodec` — member account value model with encrypted email, hashed password, stable `member_id`, and profile-driven validation.
- **P77-M2:** Full `UserAccount` fieldtype — admin entry editor UI, `processValue` / `processLoadedValue`, list cell rendering, and export/MCP redaction via `birkly_ai_read_entry` filter.
- **P77-M2:** Tests P77-FT-01–08.

## 1.0.46 - 2026-09-04

- **P77-M1:** `UserFieldtypeProfileStore` — member account fieldtype profiles mirroring Commerce (`user_account`, `user_account_*`).
- **P77-M1:** User admin **Fieldtypes** tab — CRUD profiles with requirements, social, privacy, and Commerce payment flags (when Commerce installed).
- **P77-M1:** `user_fieldtype_profiles` API and dynamic `UserAccount` fieldtype registration.

## 1.0.45 - 2026-09-04

- **Fix:** Collection permissions tab — move JS into `site_users.js` so it loads with external scripts (inline script was not always executed); clearer API error handling.
- **Fix:** P76 `relationships` field ensure uses multi-path collection.json resolution for Hub installs.
- **Fix:** `ProfileService` uses `user_management_cms_path()` for content reads/writes.
- **Feature:** One-time backfill creates missing profile collection entries for active site users when profile collection is enabled.

## 1.0.44 - 2026-09-04

- **Fix:** User modal close/save and collection permissions UI — remove inline `onclick` handlers blocked by admin CSP; use delegated listeners.
- **Fix:** P76 schema ensure runs on every plugin load (club-profiles `relationships` field, hide legacy graph collection).
- **Fix:** Collection permissions API uses correct CMS paths and skips hidden/system collections.

## 1.0.43 - 2026-09-04

- **Fix:** Membership products admin JS syntax error (tab failed to load since 1.0.16).
- **Fix:** Collection permissions tab — expose `loadCollectionPermissions` on `window` for tab init.
- **Fix:** User list edit/delete actions use delegated click handlers (no inline `onclick`).
- **Fix:** P76 migration runs when upgrading from versions below 1.0.42 directly to 1.0.43.

## 1.0.42 - 2026-09-04

- **P76:** `user_relationship` virtual fieldtype — admin relationship panel on profile entries (follow, connection, block).
- **P76:** `UserGraphStore` — plugin-private graph at `data/plugins/user_management/graph/` (replaces merchant-visible collection as SoT).
- **P76:** `user_graph_admin` API for admin inline graph mutations; `migrate-p76-graph-store.php` migrates legacy collection edges.
- **P76:** Template functions `user_is_connected`, `user_graph_connected`; `follow_state` includes `connected`.
- **P76:** User delete purges graph edges and profile entry; `ProfileService` resolves profiles by `owner`.

## 1.0.41 - 2026-09-04

- **P75:** Re-run `migrate-p75-ugc.php` on upgrade (idempotent); migrates club-posts/club-wishes likes sub-entries; strips legacy profile `user_id` when `owner` is set.
- **P75:** User fieldtype collection editor — Entry owner toggle, public form visibility, role filter.

## 1.0.40 - 2026-09-04

- **P75:** Template functions `user_is_following`, `user_is_friend`, `user_is_blocked`, `user_graph_follows`, `user_graph_followers`, and `user_can_view`.
- **P75:** `UserGraphService::listFollowers()` for follower lists.
- **P75:** Upgrade hook ensures `user-relationships` collection on sites that skipped 1.0.37.

## 1.0.39 - 2026-09-04

- **P75:** Removes legacy `club_social`, `club_social_public`, and `user_relations` API routes (use `user_graph` and `public_sub_entry` for likes).
- **P75:** `club-profiles` schema upgrade adds `owner` field and drops text `user_id`.

## 1.0.38 - 2026-09-04

- **P75:** Declares `birkly_public_entries_filter` and `birkly_public_entry_filter` in `plugin.json` (Hub publish fix).
- **P75:** Post/wish/roadmap likes stored as `likes` sub-entries with `owner` field — `club_social_reactions` metadata removed.
- **P75:** `club-posts` and `club-wishes` gain public `likes` sub-collections; roadmap `likes` schema uses `owner` instead of text `user_id`.
- **P75:** `scripts/migrate-p75-ugc.php` migrates legacy author fields, reaction metadata, and follow metadata.

## 1.0.37 - 2026-09-04

- **P75:** `UserGraphService` stores follow/connect/block/friend edges in `user-relationships` collection (replaces `club_social_follows` metadata).
- **P75:** New `user_graph` API for follow, connect, block, and relationship state queries.
- **P75:** `EntryPermissions` resolves entry owner via ownership field / `birkly_get_entry_owner_id`; relationship visibility uses graph queries with profile fallback.
- **P75:** Registers `birkly_public_entries_filter` and `birkly_public_entry_filter` hooks for public read enforcement.

## 1.0.36 - 2026-09-04

- **Club:** Post comments are a `comments` sub-collection on `club-posts` (replaces standalone `club-comments` collection).
- **Club:** Ensures `club-posts` has a public `comments` sub-collection schema on upgrade.

## 1.0.35 - 2026-09-04

- **Fix:** Club profile save no longer clears the avatar — `update_profile` omits avatar unless explicitly sent; `saveProfileForUser` preserves existing avatar on text-only saves.

## 1.0.34 - 2026-09-04

- **Fix:** `user-storefront.js` reads CSRF tokens from `/api/csrf.php` response (`data.csrf_token`) so club profile save, avatar upload, and password change work on all sites.

## 1.0.33 - 2026-09-04

- **Club:** Roadmap votes stored as real `likes` sub-entries on each `roadmap-features` entry (visible in admin; same pattern as social post likes).
- **Club:** Profile avatar upload stores a proper media object on `club-profiles.avatar` and returns a resolved public URL.
- **Club:** Ensures `roadmap-features` has a `likes` sub-collection schema on upgrade.

## 1.0.32 - 2026-09-04

- **Club:** Member directory lists all active club-tier users (`list_members`), not only saved `club-profiles` entries.
- **Club:** Profile avatar upload (`upload_avatar`) stored on `club-profiles.avatar` media field.
- **Club:** Public roadmap vote counts API (`club_social_public` → `roadmap_counts`) for syncing with the marketing roadmap page.
- **Club:** Reset all roadmap/post/wish reactions on upgrade to 1.0.32 (club server counts are source of truth).

## 1.0.31 - 2026-09-04

- **Fix:** Welcome emails are deduplicated per email+tier; plugin version bumps no longer run membership reconcile (permissions refresh only).
- **Fix:** Club collection permissions are force-seeded on every load (fixes club-comments create denied).
- **Club:** Profile tab API (`update_profile`, `change_password`) and `ClubProfileService`.
- **Club:** Follow system in `club_social` (default follow Birkly; cannot unfollow).

## 1.0.30 - 2026-09-04

- **Fix:** Plugin version upgrades no longer re-send activation/welcome emails during membership reconcile (tier grants only).
- **Club:** `club_social` API for server-side likes/votes on posts, roadmap features, and wishes.
- **Club:** Tier permissions for club-comments, club-wishes, club-deals, and roadmap collections.

## 1.0.29 - 2026-09-04

- **Fix:** Define missing `fetchCsrf()` in `user-storefront.js` so `BirklyUser.logout()` works (1.0.28 referenced the helper but never declared it).

## 1.0.25 - 2026-09-03

- **Fix:** Subscription sync now resends activation emails (bypasses stale token dedupe) and skips entitlement re-check when provisioning from reconcile.
- **Admin:** “Sync from subscriptions” button on Site users — shows entitlement gaps and sends activation emails for missing accounts.

## 1.0.24 - 2026-09-03

- **Fix:** Membership reconcile now sends activation emails for active club subscriptions when no site user exists, even when checkout included signup-flow metadata (fixes “lost” test users after data migration).
- **Admin:** `reconcile_memberships` action to manually replay subscription → site-user provisioning.

## 1.0.23 - 2026-09-03

- **Fix:** Recover site users after upgrades when the active encryption key was wrong — validates keys against encrypted user files, scans nested legacy data paths (`data/data/plugins/user_management`), merges orphan user JSON, and re-encrypts on read when a legacy key is found.

## 1.0.22 - 2026-09-03

- **Fix:** Site users no longer disappear after plugin upgrades — encryption key is inherited from legacy data dirs before creating a new key.
- **Fix:** Returning club members receive a welcome email when they already have a site account (instead of a silent tier grant with no email).
- **Fix:** Activation dedupe is scoped per order — new purchases send a fresh activation email even if an older pending token exists.

## 1.0.21 - 2026-09-03

- **Fix:** Activation links no longer show "no longer valid" — membership entitlement re-checks subscriptions via direct store read when Commerce shelf capability is unavailable.
- **Fix:** Subscription matching uses line-level `collection_slug` / `entry_slug` from Commerce subscription records.
- **Fix:** Duplicate activation emails — skip deprecated `commerce_membership_started` signup handler; dedupe pending tokens per email.

## 1.0.15 - 2026-09-02

- **Fix:** Membership products admin — Add product / Save / Import buttons work (event delegation; no broken inline handlers).
- **UX:** Empty state hint; new rows pre-fill birkly.io donation defaults.

## 1.0.14 - 2026-09-02

- **P74-M5:** Membership products — link Commerce product/option ref → tier + signup flow in User admin.
- **Lifecycle:** `UserMembershipLifecycle` grants/revokes tiers on subscription events; entitlement via active subscription match.
- **Migration:** Import legacy Commerce `purchase_mappings.json` grant_tier entries.
- **Flows:** `pay_then_activate` preset picks commerce refs from linked membership product config.
- **API:** `user_membership` — list/save products, settings, import mappings.

## 1.0.13 - 2026-09-02

- **P74-M3:** Signup flow engine with `signup_flow_shelf` — preset flows (`free_register`, `pay_then_activate`, `register_then_pay`, `activate_only`).
- **Steps:** collect_fields, verify_email, payment (Commerce handoff with `signup_flow_*` metadata), set_password, grant_tier, redirect.
- **API:** `user_signup` — start, step, status, list/save flows.
- **Admin:** Signup flows tab — enable presets, tier, redirect URL, Commerce product refs.
- **Events:** Listens for `commerce_membership_started` / `commerce_subscription_started` when flow metadata present.

## 1.0.12 - 2026-09-02

- **P74-M2:** Configurable signup field schema — merchants define registration and activation form fields in admin.
- **Signup fields tab** — add/edit fields (slug, type, required, unique, contexts).
- **API:** `user_signup_fields` and `user_registration?action=schema` for public form metadata.
- **Validation:** Registration and activation validate against schema; custom values persist to user + profile collection.

## 1.0.11 - 2026-09-02

- **P74-M1:** `user_activation_shelf` lobby service — Commerce and other plugins call `get_plugin_service('user_activation_shelf')` instead of loading `AccountActivation.php` directly.
- **Email:** Admin-editable transactional templates (`account_activation`, `verification`, `password_reset`, `welcome`) with merge tokens and test send; new **Emails** tab in User admin.
- **Email:** `UserEmailService` stores templates under plugin data; delivery uses Connections alias (default `transactional_email`).
- **Activation:** Entitlement is filter-only (`user_activation_entitled`) — Commerce subscription fallback removed from `AccountActivation`.

## 1.0.10 - 2026-09-02

- **Fix:** `/activate-account` route handler closure now captures the route prefix so public activation pages resolve on birkly.io.

## 1.0.7 - 2026-09-02

- **Fix:** Runtime data path on Docker / Hub installs under `data/plugins/user_management` — use `plugin-data/user_management` (with legacy reconciliation) instead of mis-resolved `data/data/plugins/...`.
- **Club:** Seed default `club` tier alongside `all`; auto-seed collection permissions for `club-home`, `club-posts`, and `club-profiles` when `activation_tier` is `club`.
- **Email:** Route verification, password reset, and account activation mail through `birkly_send_mail` (`transactional_email` connection alias).
- **URLs:** Activation and verification links fall back to admin `cms_url` when `settings/site.json` has no public URL.

## 1.0.3 - 2026-08-26

- **WebMCP:** Register visitor tools (`birkly_user_session`, `birkly_user_login`) via `birkly_webmcp_register_tools()` when User Management is active. Defaults off.
- Add `assets/user-storefront.js` exposing `BirklyUser.session()` / `BirklyUser.login()` for public-page surface detection. See `docs/webmcp-tools.md`.

## 1.0.2 - 2026-08-07

- P61: Admin activity toggles (`activity_notify`, `activity_nav_dot`) on Settings, persisted via `user_management` plugin settings.

## 1.0.1 - 2026-08-04

- Adopt P56 admin design language for User Management admin (Tier 0 compose).
- Migrate tabs to core `.tabs-root` / `.tabs` / `.tab` / `.tab-panel`; forms to `.field` / `.input` / `.select`; tables, badges, modals, and action bars to core classes.
- Replace inline Documentation tab with `plugin-docs-panel`; remove private docs CSS and hex.
- Fix duplicate `id="permissions"` (docs section vs permissions tab).
- Align `groups.html` / `tiers.html` standalone pages with the same chrome.

## 1.0.0 - unreleased

- User management plugin with registration, authentication, permissions, and tier-based access.
