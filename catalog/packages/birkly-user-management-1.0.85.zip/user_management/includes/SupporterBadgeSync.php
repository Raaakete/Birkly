<?php
/**
 * Reconcile supporter badge fields on club-profiles from Commerce facts (P79-M3).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';
require_once __DIR__ . '/SupporterBadgeRules.php';
require_once __DIR__ . '/ClubProfileService.php';
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/MembershipProductRegistry.php';

class SupporterBadgeSync
{
    public const SUPPORTERS_COLLECTION = 'supporters';

    private SupporterBadgeRules $rules;
    private ClubProfileService $profiles;
    private UserService $users;
    private MembershipProductRegistry $registry;

    public function __construct(
        ?SupporterBadgeRules $rules = null,
        ?ClubProfileService $profiles = null,
        ?UserService $users = null,
        ?MembershipProductRegistry $registry = null
    ) {
        $this->rules = $rules ?? new SupporterBadgeRules();
        $this->profiles = $profiles ?? new ClubProfileService();
        $this->users = $users ?? new UserService();
        $this->registry = $registry ?? new MembershipProductRegistry();
    }

    /**
     * @return array<string, mixed>
     */
    public function reconcileForEmail(string $email): array
    {
        $email = strtolower(trim($email));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'error' => 'Invalid email'];
        }

        $userId = $this->resolveUserIdByEmail($email);
        if ($userId === null) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'no_user', 'email' => $email];
        }

        return $this->reconcileProfileForUser($userId, $email);
    }

    /**
     * @return array<string, mixed>
     */
    public function reconcileForUserId(string $userId): array
    {
        $userId = trim($userId);
        if ($userId === '') {
            return ['ok' => false, 'error' => 'User id required'];
        }

        $user = $this->users->getUser($userId);
        if (!is_array($user)) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'no_user', 'user_id' => $userId];
        }

        $email = strtolower(trim((string) ($user['email'] ?? '')));
        if ($email === '') {
            return ['ok' => true, 'skipped' => true, 'reason' => 'no_email', 'user_id' => $userId];
        }

        return $this->reconcileProfileForUser($userId, $email);
    }

    /**
     * @return array{processed: int, updated: int, skipped: int, details: list<array<string, mixed>>}
     */
    public function reconcileAll(): array
    {
        $stats = ['processed' => 0, 'updated' => 0, 'skipped' => 0, 'details' => []];
        $storage = new UserStorage();

        foreach ($storage->listUsers(['status' => 'active', 'deleted' => false], 5000, 0) as $user) {
            if (!is_array($user) || !empty($user['deleted'])) {
                continue;
            }
            if ((string) ($user['tier'] ?? 'all') !== 'club') {
                continue;
            }

            $userId = (string) ($user['id'] ?? '');
            if ($userId === '') {
                continue;
            }

            $result = $this->reconcileForUserId($userId);
            $stats['processed']++;
            if (!empty($result['updated'])) {
                $stats['updated']++;
            } else {
                $stats['skipped']++;
            }
            $stats['details'][] = array_merge(['user_id' => $userId], $result);
        }

        return $stats;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function handleCommerceEvent(string $event, array $payload): array
    {
        $normalized = strtolower(trim($event));
        if (!in_array($normalized, [
            'commerce_subscription_started',
            'commerce_subscription_canceled',
            'commerce_subscription_paused',
            'commerce_subscription_resumed',
            'commerce_subscription_recovered',
            'commerce_subscription_renewed',
            'commerce_order_paid',
        ], true)) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'unsupported_event'];
        }

        $email = strtolower(trim((string) ($payload['customer_email'] ?? $payload['email'] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'no_email'];
        }

        if ($this->resolveUserIdByEmail($email) === null) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'no_user', 'email' => $email];
        }

        return $this->reconcileForEmail($email);
    }

    /**
     * @return array<string, mixed>
     */
    private function reconcileProfileForUser(string $userId, string $email): array
    {
        $existing = $this->profiles->getProfileByUserId($userId);
        if ($existing === null) {
            $existing = $this->ensureClubProfileForUser($userId);
            if ($existing === null) {
                return ['ok' => true, 'skipped' => true, 'reason' => 'no_profile', 'user_id' => $userId, 'email' => $email];
            }
        }

        $facts = $this->collectFactsForEmail($email);
        $badge = $this->rules->resolveDisplayBadge(
            $facts['one_time_best_eur'] > 0 ? $facts['one_time_best_eur'] : null,
            $facts['monthly_active_eur'] > 0 ? $facts['monthly_active_eur'] : null
        );
        $cadence = $facts['monthly_active_eur'] > 0 ? 'month' : ($facts['one_time_best_eur'] > 0 ? 'one_time' : 'none');
        $amount = $facts['monthly_active_eur'] > 0 ? $facts['monthly_active_eur'] : $facts['one_time_best_eur'];

        $next = [
            'supporter_badge' => $badge,
            'supporter_cadence' => $cadence,
            'supporter_amount_eur' => round($amount, 2),
            'supporter_entry_id' => $facts['supporter_entry_id'] ?? '',
            'supporter_synced_at' => date('c'),
        ];

        if ($this->badgeFieldsMatch($existing, $next)) {
            return [
                'ok' => true,
                'skipped' => true,
                'reason' => 'unchanged',
                'user_id' => $userId,
                'email' => $email,
                'supporter_badge' => $badge,
            ];
        }

        $write = $this->profiles->updateBadgeFieldsForUser($userId, $next);
        if (empty($write['ok'])) {
            return array_merge(['ok' => false, 'user_id' => $userId, 'email' => $email], $write);
        }

        if ($badge !== 'none' && function_exists('do_action')) {
            do_action('supporter_badge_granted', [
                'user_id' => $userId,
                'email' => $email,
                'supporter_badge' => $badge,
                'supporter_cadence' => $cadence,
                'supporter_amount_eur' => $next['supporter_amount_eur'],
            ]);
        }

        return [
            'ok' => true,
            'updated' => true,
            'user_id' => $userId,
            'email' => $email,
            'supporter_badge' => $badge,
            'supporter_cadence' => $cadence,
            'supporter_amount_eur' => $next['supporter_amount_eur'],
        ];
    }

    /**
     * @return array{one_time_best_eur: float, monthly_active_eur: float, supporter_entry_id: string}
     */
    private function collectFactsForEmail(string $email): array
    {
        $oneTime = 0.0;
        $monthly = 0.0;
        $supporterEntryId = '';

        foreach ($this->supporterEntriesForEmail($email) as $entry) {
            $amount = $this->amountEurFromSupporterEntry($entry);
            $cadence = $this->normalizeCadence((string) ($entry['cadence'] ?? $entry['supporter_cadence'] ?? 'one_time'));
            if ($cadence === 'month') {
                if ($amount > $monthly) {
                    $monthly = $amount;
                    $supporterEntryId = (string) ($entry['id'] ?? $supporterEntryId);
                }
            } elseif ($amount > $oneTime) {
                $oneTime = $amount;
                $supporterEntryId = (string) ($entry['id'] ?? $supporterEntryId);
            }
        }

        foreach ($this->paidOrdersForEmail($email) as $order) {
            if ($this->orderCadence($order) === 'month') {
                continue;
            }
            $amount = $this->amountEurFromOrder($order);
            if ($amount > $oneTime) {
                $oneTime = $amount;
            }
        }

        foreach ($this->activeSubscriptionsForEmail($email) as $sub) {
            if (!$this->subscriptionCountsAsMonthly($sub)) {
                continue;
            }
            $amount = $this->amountEurFromSubscription($sub);
            if ($amount > $monthly) {
                $monthly = $amount;
            }
        }

        return [
            'one_time_best_eur' => $oneTime,
            'monthly_active_eur' => $monthly,
            'supporter_entry_id' => $supporterEntryId,
        ];
    }

    /**
     * @param array<string, mixed> $existing
     * @param array<string, mixed> $next
     */
    private function badgeFieldsMatch(array $existing, array $next): bool
    {
        foreach (['supporter_badge', 'supporter_cadence', 'supporter_entry_id'] as $key) {
            if ((string) ($existing[$key] ?? '') !== (string) ($next[$key] ?? '')) {
                return false;
            }
        }

        $existingAmount = round((float) ($existing['supporter_amount_eur'] ?? 0), 2);
        $nextAmount = round((float) ($next['supporter_amount_eur'] ?? 0), 2);

        return abs($existingAmount - $nextAmount) < 0.01;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function ensureClubProfileForUser(string $userId): ?array
    {
        $user = $this->users->getUser($userId);
        if (!is_array($user) || (string) ($user['tier'] ?? '') !== 'club') {
            return null;
        }

        $title = trim((string) ($user['name'] ?? $user['email'] ?? 'Club member'));
        if ($title === '') {
            $title = 'Club member';
        }

        try {
            $this->profiles->saveProfileForUser($userId, [
                'title' => $title,
                'supporter_badge' => 'none',
                'supporter_cadence' => 'none',
                'supporter_amount_eur' => 0,
            ]);
        } catch (Throwable $e) {
            error_log('SupporterBadgeSync ensureClubProfileForUser failed: ' . $e->getMessage());

            return null;
        }

        return $this->profiles->getProfileByUserId($userId);
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function supporterEntriesForEmail(string $email): array
    {
        $dir = user_management_cms_path('content/collections/' . self::SUPPORTERS_COLLECTION . '/entries');
        if (!is_dir($dir)) {
            return [];
        }

        $matched = [];
        foreach (glob($dir . '/*.json') ?: [] as $file) {
            $entry = json_decode((string) file_get_contents($file), true);
            if (!is_array($entry)) {
                continue;
            }
            if (!$this->supporterEntryIsPaid($entry)) {
                continue;
            }
            if (!$this->emailMatchesSupporterEntry($entry, $email)) {
                continue;
            }
            $matched[] = $entry;
        }

        return $matched;
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function emailMatchesSupporterEntry(array $entry, string $email): bool
    {
        $email = strtolower(trim($email));
        $entryEmail = strtolower(trim((string) ($entry['email'] ?? '')));
        if ($entryEmail !== '' && $entryEmail === $email) {
            return true;
        }

        $hash = trim((string) ($entry['email_hash'] ?? ''));
        if ($hash !== '') {
            return hash_equals($hash, hash('sha256', $email));
        }

        return false;
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function supporterEntryIsPaid(array $entry): bool
    {
        $status = strtolower(trim((string) ($entry['status'] ?? 'published')));
        if (in_array($status, ['draft', 'pending', 'abandoned'], true)) {
            return false;
        }

        $paymentStatus = strtolower(trim((string) ($entry['payment_status'] ?? '')));
        if ($paymentStatus !== '' && !in_array($paymentStatus, ['paid', 'succeeded', 'complete'], true)) {
            return false;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function amountEurFromSupporterEntry(array $entry): float
    {
        if (isset($entry['amount_eur']) && is_numeric($entry['amount_eur'])) {
            return max(0.0, (float) $entry['amount_eur']);
        }
        if (isset($entry['amount']) && is_numeric($entry['amount'])) {
            return max(0.0, (float) $entry['amount']);
        }
        if (isset($entry['amount_cents']) && is_numeric($entry['amount_cents'])) {
            return max(0.0, (float) $entry['amount_cents'] / 100);
        }

        return 0.0;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function paidOrdersForEmail(string $email): array
    {
        if (!class_exists('CommerceOrderStore')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceOrderStore.php')) {
                require_once $pluginDir . '/includes/CommerceOrderStore.php';
            }
        }
        if (!class_exists('CommerceOrderStore')) {
            return [];
        }

        $email = strtolower(trim($email));
        $orders = [];
        try {
            foreach ((new CommerceOrderStore())->listAll() as $order) {
                if (!is_array($order)) {
                    continue;
                }
                if (strtolower(trim((string) ($order['customer_email'] ?? ''))) !== $email) {
                    continue;
                }
                $status = strtolower(trim((string) ($order['status'] ?? '')));
                if (!in_array($status, ['paid', 'partially_refunded'], true)) {
                    continue;
                }
                $orders[] = $order;
            }
        } catch (Throwable $e) {
            error_log('SupporterBadgeSync order lookup: ' . $e->getMessage());
        }

        return $orders;
    }

    /**
     * @param array<string, mixed> $order
     */
    private function orderCadence(array $order): string
    {
        $billing = strtolower(trim((string) ($order['billing_mode'] ?? '')));
        if ($billing === 'recurring') {
            return 'month';
        }

        $lines = is_array($order['lines'] ?? null) ? $order['lines'] : [];
        foreach ($lines as $line) {
            if (!is_array($line)) {
                continue;
            }
            if (($line['billing'] ?? '') === 'recurring') {
                return 'month';
            }
        }

        return 'one_time';
    }

    /**
     * @param array<string, mixed> $order
     */
    private function amountEurFromOrder(array $order): float
    {
        $cents = (int) ($order['total_cents'] ?? 0);
        if ($cents <= 0) {
            $lines = is_array($order['lines'] ?? null) ? $order['lines'] : [];
            foreach ($lines as $line) {
                if (!is_array($line)) {
                    continue;
                }
                $cents += (int) ($line['line_total_cents'] ?? $line['amount_cents'] ?? 0);
            }
        }

        return max(0.0, $cents / 100);
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function activeSubscriptionsForEmail(string $email): array
    {
        if (function_exists('get_plugin_service')) {
            $shelf = get_plugin_service('payment_shelf', false, 'user_management')
                ?? get_plugin_service('commerce_shelf', false, 'user_management');
            if (is_object($shelf) && method_exists($shelf, 'getActiveSubscriptionsForEmail')) {
                try {
                    $subs = $shelf->getActiveSubscriptionsForEmail($email, $this->registry->pastDueGraceDays());
                    if (is_array($subs)) {
                        return $subs;
                    }
                } catch (Throwable $e) {
                    error_log('SupporterBadgeSync subscription shelf lookup: ' . $e->getMessage());
                }
            }
        }

        if (!class_exists('CommerceSubscriptionStore')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceSubscriptionStore.php')) {
                require_once $pluginDir . '/includes/CommerceSubscriptionStore.php';
            }
        }
        if (!class_exists('CommerceSubscriptionStore')) {
            return [];
        }

        $email = strtolower(trim($email));
        $graceDays = $this->registry->pastDueGraceDays();
        $now = time();
        $active = [];

        try {
            foreach ((new CommerceSubscriptionStore())->listAll() as $sub) {
                if (!is_array($sub) || strtolower(trim((string) ($sub['customer_email'] ?? ''))) !== $email) {
                    continue;
                }

                $status = (string) ($sub['status'] ?? '');
                if ($status === 'active' || $status === 'paused') {
                    $active[] = $sub;
                    continue;
                }

                if ($status === 'past_due' && $graceDays > 0) {
                    $pastDueAt = strtotime((string) ($sub['past_due_at'] ?? $sub['updated_at'] ?? ''));
                    if ($pastDueAt !== false && ($now - $pastDueAt) <= ($graceDays * 86400)) {
                        $active[] = $sub;
                    }
                }
            }
        } catch (Throwable $e) {
            error_log('SupporterBadgeSync subscription store lookup: ' . $e->getMessage());
        }

        return $active;
    }

    /**
     * @param array<string, mixed> $sub
     */
    private function subscriptionCountsAsMonthly(array $sub): bool
    {
        $status = strtolower(trim((string) ($sub['status'] ?? '')));
        if (in_array($status, ['canceled', 'cancelled'], true)) {
            return false;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $sub
     */
    private function amountEurFromSubscription(array $sub): float
    {
        $cents = (int) ($sub['amount_cents'] ?? 0);
        if ($cents <= 0) {
            $lines = is_array($sub['lines'] ?? null) ? $sub['lines'] : [];
            foreach ($lines as $line) {
                if (!is_array($line)) {
                    continue;
                }
                $lineCents = (int) ($line['amount_cents'] ?? $line['line_total_cents'] ?? 0);
                if ($lineCents > $cents) {
                    $cents = $lineCents;
                }
            }
        }

        return max(0.0, $cents / 100);
    }

    private function normalizeCadence(string $cadence): string
    {
        $cadence = strtolower(trim($cadence));
        if (in_array($cadence, ['month', 'monthly', 'recurring', 'subscription'], true)) {
            return 'month';
        }
        if (in_array($cadence, ['one_time', 'one-time', 'onetime', 'once'], true)) {
            return 'one_time';
        }

        return $cadence === 'none' ? 'none' : 'one_time';
    }

    private function resolveUserIdByEmail(string $email): ?string
    {
        try {
            $user = $this->users->getUserByEmail($email);

            return isset($user['id']) ? (string) $user['id'] : null;
        } catch (Throwable $e) {
            return null;
        }
    }
}
