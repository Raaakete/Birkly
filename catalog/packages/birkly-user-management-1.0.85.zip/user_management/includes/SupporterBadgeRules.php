<?php
/**
 * Configurable supporter badge thresholds (P79-M1).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';

class SupporterBadgeRules
{
    private string $rulesFile;

    public function __construct(?string $dataDir = null)
    {
        $dir = $dataDir ?? user_management_data_dir();
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $this->rulesFile = $dir . '/supporter_badge_rules.json';
        if (!is_file($this->rulesFile)) {
            $this->save($this->defaultDocument());
        }
    }

    /**
     * @return array<string, mixed>
     */
    public function load(): array
    {
        $raw = is_file($this->rulesFile) ? file_get_contents($this->rulesFile) : false;
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data) || empty($data['rules'])) {
            return $this->defaultDocument();
        }

        return $this->normalizeDocument($data);
    }

    /**
     * @param array<string, mixed> $document
     */
    public function save(array $document): bool
    {
        $normalized = $this->normalizeDocument($document);
        $written = file_put_contents(
            $this->rulesFile,
            json_encode($normalized, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n"
        );

        return $written !== false;
    }

    public function resolveBadge(string $cadence, float $amountEur): string
    {
        $cadence = $this->normalizeCadence($cadence);
        if ($cadence === 'none' || $amountEur <= 0) {
            return $this->defaultBadge();
        }

        $best = $this->defaultBadge();
        foreach ($this->rulesForCadence($cadence) as $rule) {
            $min = (float) ($rule['min_amount_eur'] ?? 0);
            if ($amountEur >= $min) {
                $best = (string) ($rule['badge'] ?? $best);
            }
        }

        return $best;
    }

    /**
     * Monthly badge wins when an active subscription exists (P79-D9).
     */
    public function resolveDisplayBadge(?float $oneTimeBestEur, ?float $monthlyActiveEur): string
    {
        $oneTime = max(0.0, (float) ($oneTimeBestEur ?? 0));
        $monthly = max(0.0, (float) ($monthlyActiveEur ?? 0));

        if ($monthly > 0) {
            return $this->resolveBadge('month', $monthly);
        }
        if ($oneTime > 0) {
            return $this->resolveBadge('one_time', $oneTime);
        }

        return $this->defaultBadge();
    }

    public function defaultBadge(): string
    {
        $doc = $this->load();

        return (string) ($doc['default_badge'] ?? 'none');
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listRules(): array
    {
        $doc = $this->load();

        return array_values($doc['rules'] ?? []);
    }

    /**
     * @return array<string, mixed>
     */
    private function defaultDocument(): array
    {
        $path = dirname(__DIR__) . '/data/supporter_badge_rules.json';
        if (is_file($path)) {
            $data = json_decode((string) file_get_contents($path), true);
            if (is_array($data)) {
                return $this->normalizeDocument($data);
            }
        }

        return [
            'version' => 1,
            'default_badge' => 'none',
            'rules' => [
                ['cadence' => 'one_time', 'min_amount_eur' => 5, 'badge' => 'supporter'],
                ['cadence' => 'one_time', 'min_amount_eur' => 25, 'badge' => 'patron'],
                ['cadence' => 'one_time', 'min_amount_eur' => 100, 'badge' => 'champion'],
                ['cadence' => 'month', 'min_amount_eur' => 5, 'badge' => 'monthly_supporter'],
                ['cadence' => 'month', 'min_amount_eur' => 25, 'badge' => 'monthly_patron'],
                ['cadence' => 'month', 'min_amount_eur' => 100, 'badge' => 'monthly_champion'],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $document
     *
     * @return array<string, mixed>
     */
    private function normalizeDocument(array $document): array
    {
        $rules = [];
        foreach ($document['rules'] ?? [] as $rule) {
            if (!is_array($rule)) {
                continue;
            }
            $cadence = $this->normalizeCadence((string) ($rule['cadence'] ?? ''));
            $badge = trim((string) ($rule['badge'] ?? ''));
            if ($cadence === 'none' || $badge === '') {
                continue;
            }
            $rules[] = [
                'cadence' => $cadence,
                'min_amount_eur' => (float) ($rule['min_amount_eur'] ?? 0),
                'badge' => $badge,
            ];
        }

        usort($rules, static function (array $a, array $b): int {
            $cadenceCmp = strcmp((string) ($a['cadence'] ?? ''), (string) ($b['cadence'] ?? ''));
            if ($cadenceCmp !== 0) {
                return $cadenceCmp;
            }

            return (float) ($a['min_amount_eur'] ?? 0) <=> (float) ($b['min_amount_eur'] ?? 0);
        });

        return [
            'version' => (int) ($document['version'] ?? 1),
            'default_badge' => trim((string) ($document['default_badge'] ?? 'none')) ?: 'none',
            'rules' => $rules,
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function rulesForCadence(string $cadence): array
    {
        $matched = [];
        foreach ($this->listRules() as $rule) {
            if (($rule['cadence'] ?? '') === $cadence) {
                $matched[] = $rule;
            }
        }

        return $matched;
    }

    private function normalizeCadence(string $cadence): string
    {
        $cadence = strtolower(trim($cadence));
        if (in_array($cadence, ['one_time', 'one-time', 'onetime', 'once'], true)) {
            return 'one_time';
        }
        if (in_array($cadence, ['month', 'monthly', 'recurring', 'subscription'], true)) {
            return 'month';
        }
        if ($cadence === 'none') {
            return 'none';
        }

        return $cadence;
    }
}
