<?php
/**
 * Likes / votes stored as sub-entries with schema owner field (P75).
 */

declare(strict_types=1);

require_once __DIR__ . '/../../../api/storage.php';
require_once __DIR__ . '/../../../core/sub_entries.php';
require_once __DIR__ . '/../../../core/entry_ownership.php';

class SubEntryLikeService
{
    public const SUB_COLLECTION = 'likes';

    private string $parentCollection;

    private Storage $storage;

    public function __construct(string $parentCollection)
    {
        $this->parentCollection = trim($parentCollection);
        $this->storage = new Storage(__DIR__ . '/../../../content');
    }

    public function parentCollection(): string
    {
        return $this->parentCollection;
    }

    /**
     * @return array{liked: bool, count: int}
     */
    public function toggleLike(string $userId, string $parentSlug): array
    {
        $userId = trim($userId);
        $parentSlug = trim($parentSlug);
        if ($userId === '' || $parentSlug === '') {
            throw new InvalidArgumentException('User id and parent slug required');
        }

        $entryId = $this->resolveEntryIdBySlug($parentSlug);
        if ($entryId === '') {
            throw new InvalidArgumentException('Parent entry not found');
        }

        $likeId = $this->likeSubEntryId($userId);
        $existing = getSubEntry($this->parentCollection, $entryId, self::SUB_COLLECTION, $likeId);
        if ($existing) {
            if (!deleteSubEntry($this->parentCollection, $entryId, self::SUB_COLLECTION, $likeId)) {
                throw new RuntimeException('Failed to remove like');
            }

            return [
                'liked' => false,
                'count' => $this->countLikes($entryId),
            ];
        }

        $payload = [
            'id' => $likeId,
            'title' => 'Like',
            'owner' => $userId,
            'status' => 'published',
        ];

        $created = createSubEntry($this->parentCollection, $entryId, self::SUB_COLLECTION, $payload);
        if (!$created) {
            throw new RuntimeException('Failed to save like');
        }

        return [
            'liked' => true,
            'count' => $this->countLikes($entryId),
        ];
    }

    /**
     * @param list<string> $parentSlugs
     *
     * @return array<string, array{count: int, liked: bool}>
     */
    public function countsForUser(string $userId, array $parentSlugs): array
    {
        $userId = trim($userId);
        $out = [];
        foreach ($parentSlugs as $slug) {
            $slug = (string) $slug;
            if ($slug === '') {
                continue;
            }
            $entryId = $this->resolveEntryIdBySlug($slug);
            $count = $entryId !== '' ? $this->countLikes($entryId) : 0;
            $liked = false;
            if ($userId !== '' && $entryId !== '') {
                $liked = getSubEntry(
                    $this->parentCollection,
                    $entryId,
                    self::SUB_COLLECTION,
                    $this->likeSubEntryId($userId)
                ) !== null;
            }
            $out[$slug] = [
                'count' => $count,
                'liked' => $liked,
            ];
        }

        return $out;
    }

    /**
     * @param list<string> $parentSlugs
     *
     * @return array<string, int>
     */
    public function countsPublic(array $parentSlugs): array
    {
        $out = [];
        foreach ($parentSlugs as $slug) {
            $slug = (string) $slug;
            if ($slug === '') {
                continue;
            }
            $entryId = $this->resolveEntryIdBySlug($slug);
            $out[$slug] = $entryId !== '' ? $this->countLikes($entryId) : 0;
        }

        return $out;
    }

    public function countLikesForSlug(string $parentSlug): int
    {
        $entryId = $this->resolveEntryIdBySlug($parentSlug);

        return $entryId !== '' ? $this->countLikes($entryId) : 0;
    }

    /**
     * Create a like sub-entry if missing (idempotent).
     */
    public function ensureLike(string $userId, string $parentSlug): bool
    {
        $userId = trim($userId);
        $parentSlug = trim($parentSlug);
        if ($userId === '' || $parentSlug === '') {
            return false;
        }

        $entryId = $this->resolveEntryIdBySlug($parentSlug);
        if ($entryId === '') {
            return false;
        }

        $likeId = $this->likeSubEntryId($userId);
        if (getSubEntry($this->parentCollection, $entryId, self::SUB_COLLECTION, $likeId)) {
            return true;
        }

        return createSubEntry($this->parentCollection, $entryId, self::SUB_COLLECTION, [
            'id' => $likeId,
            'title' => 'Like',
            'owner' => $userId,
            'status' => 'published',
        ]) !== null;
    }

    public function likeSubEntryId(string $userId): string
    {
        $safe = preg_replace('/[^a-zA-Z0-9_-]/', '', $userId) ?? '';

        return 'like_' . ($safe !== '' ? $safe : 'user');
    }

    private function countLikes(string $entryId): int
    {
        $likes = getSubEntries($this->parentCollection, $entryId, self::SUB_COLLECTION, [
            'status' => 'published',
        ]);

        return is_array($likes) ? count($likes) : 0;
    }

    private function resolveEntryIdBySlug(string $slug): string
    {
        $slug = trim($slug);
        if ($slug === '') {
            return '';
        }

        $results = $this->storage->query($this->parentCollection, ['slug' => $slug], ['limit' => 1]);
        if (is_array($results) && isset($results[0]['id'])) {
            return (string) $results[0]['id'];
        }

        $dir = __DIR__ . '/../../../content/collections/' . $this->parentCollection . '/entries';
        if (!is_dir($dir)) {
            return '';
        }

        foreach (glob($dir . '/*.json') ?: [] as $file) {
            $raw = file_get_contents($file);
            if ($raw === false) {
                continue;
            }
            $entry = json_decode($raw, true);
            if (!is_array($entry)) {
                continue;
            }
            if ((string) ($entry['slug'] ?? '') === $slug) {
                return (string) ($entry['id'] ?? '');
            }
        }

        return '';
    }
}
