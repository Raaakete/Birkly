<?php
/**
 * User Management WebMCP runtime pack registration (P83-M4).
 */

declare(strict_types=1);

if (!function_exists('birkly_webmcp_register_runtime_pack')) {
    return;
}

birkly_webmcp_register_runtime_pack('user_management', [
    'pack' => 'user_management',
    'label' => 'Accounts',
    'note' => 'Appears on pages with sign-in.',
    'global' => 'BirklyUser',
    'surface' => '[data-birkly-login], form[data-birkly-login], [data-birkly-user-session]',
    'script' => '/plugins/user_management/assets/webmcp-pack.js',
    'tools' => [
        'birkly_user_session',
        'birkly_user_login',
    ],
]);
