<?php
/**
 * Member index — entries with user_account fieldtypes (P77-M4).
 */

declare(strict_types=1);

require_once __DIR__ . '/MemberAccountCodec.php';

class UserMemberIndexer
{
    private string $indexFile;
    private string $dataDir;

    public function __construct(?string $dataDir = null)
    {
        $this->dataDir = $dataDir ?? user_management_data_dir();
        if (!is_dir($this->dataDir)) {
            mkdir($this->dataDir, 0755, true);
        }
        $this->indexFile = $this->dataDir . '/members_index.json';
        if (!is_file($this->indexFile)) {
            $this->saveIndex(['members' => []]);
        }
    }

    public function loadIndex(): array
    {
        if (!is_file($this->indexFile)) {
            return ['members' => []];
        }
        $data = json_decode((string) file_get_contents($this->indexFile), true);

        return is_array($data) ? $data : ['members' => []];
    }

    public function saveIndex(array $index): void
    {
        file_put_contents(
            $this->indexFile,
            json_encode($index, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n",
            LOCK_EX
        );
    }

    /**
     * @param array<string, mixed> $entry
     */
    public function indexEntry(array $entry, string $collectionSlug): bool
    {
        $collectionSlug = trim($collectionSlug);
        $entryId = trim((string) ($entry['id'] ?? ''));
        if ($collectionSlug === '' || $entryId === '') {
            return false;
        }

        $account = $this->extractAccountFromEntry($entry, $collectionSlug);
        if ($account === null) {
            $this->removeEntry($entryId, $collectionSlug);

            return false;
        }

        $memberId = trim((string) ($account['member_id'] ?? ''));
        if ($memberId === '') {
            return false;
        }

        $emailPlain = MemberAccountCodec::decryptEmail((string) ($account['email'] ?? '')) ?? '';
        $row = [
            'member_id' => $memberId,
            'collection_slug' => $collectionSlug,
            'entry_id' => $entryId,
            'tier_id' => (string) ($account['tier_id'] ?? 'all'),
            'fieldtype_profile_id' => (string) ($account['fieldtype_profile_id'] ?? 'default'),
            'fieldtype_type_key' => $this->resolveTypeKey($account),
            'email_hash' => $emailPlain !== '' ? hash('sha256', strtolower($emailPlain)) : '',
            'status' => (string) ($account['status'] ?? 'pending'),
            'verified' => !empty($account['verified']),
            'name' => (string) ($account['name'] ?? ($entry['title'] ?? '')),
            'directory_listed' => true,
            'updated_at' => date('c'),
        ];

        $index = $this->loadIndex();
        $index['members'][$memberId] = $row;
        $this->saveIndex($index);

        return true;
    }

    public function removeEntry(string $entryId, string $collectionSlug): void
    {
        $entryId = trim($entryId);
        $collectionSlug = trim($collectionSlug);
        if ($entryId === '' || $collectionSlug === '') {
            return;
        }

        $index = $this->loadIndex();
        foreach ($index['members'] as $memberId => $row) {
            if (!is_array($row)) {
                continue;
            }
            if (($row['entry_id'] ?? '') === $entryId && ($row['collection_slug'] ?? '') === $collectionSlug) {
                unset($index['members'][$memberId]);
                $this->saveIndex($index);
                return;
            }
        }
    }

    public function reindexAll(): int
    {
        $count = 0;
        $index = ['members' => []];
        $this->saveIndex($index);

        foreach ($this->listCollectionSlugs() as $collectionSlug) {
            foreach ($this->listEntryFiles($collectionSlug) as $entryFile) {
                $entry = $this->readEntry($collectionSlug, $entryFile);
                if (!is_array($entry)) {
                    continue;
                }
                if ($this->indexEntry($entry, $collectionSlug)) {
                    $count++;
                }
            }
        }

        return $count;
    }

    /** @return list<array<string, mixed>> */
    public function listMembers(): array
    {
        $index = $this->loadIndex();

        return array_values($index['members'] ?? []);
    }

    public function getMember(string $memberId): ?array
    {
        $index = $this->loadIndex();

        return $index['members'][$memberId] ?? null;
    }

    /**
     * @param array<string, mixed> $entry
     * @return array<string, mixed>|null
     */
    private function extractAccountFromEntry(array $entry, string $collectionSlug): ?array
    {
        $schema = $this->readCollectionSchema($collectionSlug);
        $fields = is_array($schema) ? ($schema['fields'] ?? []) : [];

        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }
            $type = (string) ($field['type'] ?? '');
            $name = (string) ($field['name'] ?? '');
            if ($name === '' || !MemberAccountCodec::isAccountFieldType($type)) {
                continue;
            }
            if (!array_key_exists($name, $entry)) {
                continue;
            }
            $value = MemberAccountCodec::normalize($entry[$name]);
            if (trim((string) ($value['member_id'] ?? '')) !== '') {
                return $value;
            }
        }

        foreach ($entry as $value) {
            if (!is_array($value) && !is_string($value)) {
                continue;
            }
            $normalized = MemberAccountCodec::normalize($value);
            if (trim((string) ($normalized['member_id'] ?? '')) !== '') {
                return $normalized;
            }
        }

        return null;
    }

  /**
     * @return array<string, mixed>|null
     */
    private function readCollectionSchema(string $collectionSlug): ?array
    {
        $path = user_management_resolve_collection_json_path($collectionSlug);
        if ($path === null || !is_file($path)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($path), true);

        return is_array($data) ? $data : null;
    }

    /** @return list<string> */
    private function listCollectionSlugs(): array
    {
        $root = user_management_cms_path('content/collections');
        if (!is_dir($root)) {
            return [];
        }

        $slugs = [];
        foreach (scandir($root) ?: [] as $dir) {
            if ($dir === '.' || $dir === '..') {
                continue;
            }
            $full = $root . '/' . $dir;
            if (!is_dir($full)) {
                continue;
            }
            $meta = $full . '/collection.json';
            if (!is_file($meta)) {
                continue;
            }
            $data = json_decode((string) file_get_contents($meta), true);
            $slug = is_array($data) ? (string) ($data['slug'] ?? $dir) : $dir;
            $slugs[] = $slug !== '' ? $slug : $dir;
        }

        return $slugs;
    }

    /** @return list<string> */
    private function listEntryFiles(string $collectionSlug): array
    {
        $dir = user_management_cms_path('content/collections/' . $collectionSlug . '/entries');
        if (!is_dir($dir)) {
            $dir = user_management_cms_path('content/collections/' . rawurlencode($collectionSlug) . '/entries');
        }
        if (!is_dir($dir)) {
            return [];
        }

        return array_values(array_filter(scandir($dir) ?: [], static fn ($f) => str_ends_with($f, '.json')));
    }

    /** @return array<string, mixed>|null */
    private function readEntry(string $collectionSlug, string $fileName): ?array
    {
        $path = user_management_cms_path('content/collections/' . $collectionSlug . '/entries/' . $fileName);
        if (!is_file($path)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($path), true);

        return is_array($data) ? $data : null;
    }

    /** @param array<string, mixed> $account */
    private function resolveTypeKey(array $account): string
    {
        $profileId = (string) ($account['fieldtype_profile_id'] ?? 'default');
        if ($profileId === 'default') {
            return 'user_account';
        }

        return 'user_account_' . $profileId;
    }
}
