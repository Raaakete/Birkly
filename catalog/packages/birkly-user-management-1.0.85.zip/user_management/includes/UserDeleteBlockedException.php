<?php
/**
 * Thrown when a site user cannot be deleted due to active subscriptions.
 */

declare(strict_types=1);

class UserDeleteBlockedException extends RuntimeException
{
    /** @var list<array<string, mixed>> */
    public array $subscriptions;

    /**
     * @param list<array<string, mixed>> $subscriptions
     */
    public function __construct(string $message, array $subscriptions = [])
    {
        parent::__construct($message);
        $this->subscriptions = $subscriptions;
    }
}
