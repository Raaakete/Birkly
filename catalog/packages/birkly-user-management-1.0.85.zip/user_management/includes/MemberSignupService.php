<?php
/**
 * Collection-scoped member signup (P77-M5).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';
require_once __DIR__ . '/UserCollectionResolver.php';
require_once __DIR__ . '/UserFieldtypeProfileStore.php';
require_once __DIR__ . '/TierProfileService.php';
require_once __DIR__ . '/MemberAccountCodec.php';
require_once __DIR__ . '/UserMemberIndexer.php';
require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/MemberCommerceShelf.php';

class MemberSignupService
{
    private UserCollectionResolver $resolver;
    private UserFieldtypeProfileStore $profiles;
    private TierProfileService $tierProfiles;
    private UserStorage $storage;
    private MemberCommerceShelf $commerce;

    public function __construct(
        ?UserCollectionResolver $resolver = null,
        ?UserFieldtypeProfileStore $profiles = null,
        ?TierProfileService $tierProfiles = null,
        ?UserStorage $storage = null,
        ?MemberCommerceShelf $commerce = null
    ) {
        $this->resolver = $resolver ?? new UserCollectionResolver();
        $this->profiles = $profiles ?? new UserFieldtypeProfileStore();
        $this->tierProfiles = $tierProfiles ?? new TierProfileService($this->profiles, $storage);
        $this->storage = $storage ?? new UserStorage();
        $this->commerce = $commerce ?? new MemberCommerceShelf();
    }

    /**
     * @return array{ok: bool, error?: string, collection?: string, tier_id?: string, type_key?: string, fields?: list<array<string, mixed>>}
     */
    public function getSignupSchema(string $collectionSlug, ?string $tierId = null): array
    {
        $collectionSlug = trim($collectionSlug);
        if ($collectionSlug === '') {
            return ['ok' => false, 'error' => 'Collection is required'];
        }

        $accountField = $this->resolver->getAccountFieldOnSchema($collectionSlug);
        if ($accountField === null) {
            return ['ok' => false, 'error' => 'Collection does not support member signup (no account field)'];
        }

        $typeKey = (string) ($accountField['type'] ?? 'user_account');
        $resolvedTier = $this->resolveTierId($tierId, $typeKey);
        $settings = $this->resolveProfileSettings($resolvedTier, $typeKey);

        return [
            'ok' => true,
            'collection' => $collectionSlug,
            'tier_id' => $resolvedTier,
            'type_key' => $typeKey,
            'account_field' => (string) ($accountField['name'] ?? 'account'),
            'fields' => $this->buildPublicFields($settings),
            'commerce' => $this->buildCommerceSchema($settings),
        ];
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    public function buildCommerceSchema(array $settings): array
    {
        if (!$this->commerce->isAvailable()) {
            return ['available' => false];
        }

        return [
            'available' => true,
            'payment_required_at_signup' => $this->commerce->paymentRequiredAtSignup($settings),
            'payment_enabled' => $this->commerce->paymentEnabled($settings),
            'membership_product_ref' => ($settings['commerce'] ?? [])['membership_product_ref'] ?? null,
        ];
    }

    /**
     * @param array<string, mixed> $input
     * @return array{ok: bool, error?: string, errors?: list<string>, entry?: array<string, mixed>, member_id?: string}
     */
    public function register(array $input, string $collectionSlug, ?string $tierId = null): array
    {
        $schema = $this->getSignupSchema($collectionSlug, $tierId);
        if (empty($schema['ok'])) {
            return ['ok' => false, 'error' => (string) ($schema['error'] ?? 'Invalid signup target')];
        }

        $accountFieldName = (string) ($schema['account_field'] ?? 'account');
        $typeKey = (string) ($schema['type_key'] ?? 'user_account');
        $resolvedTier = (string) ($schema['tier_id'] ?? 'all');
        $settings = $this->resolveProfileSettings($resolvedTier, $typeKey);

        $accountInput = $this->mapInputToAccountValue($input, $settings, $typeKey, $resolvedTier);
        $errors = MemberAccountCodec::validate($accountInput, $settings, true);
        if ($errors !== []) {
            return ['ok' => false, 'error' => implode(' ', $errors), 'errors' => $errors];
        }

        $emailPlain = strtolower(trim((string) ($accountInput['email'] ?? '')));
        if ($emailPlain !== '' && $this->emailExists($emailPlain)) {
            return ['ok' => false, 'error' => 'An account with this email already exists'];
        }

        $accountValue = MemberAccountCodec::processForStorage($accountInput, [], $settings, $typeKey);
        $accountValue['tier_id'] = $resolvedTier;
        $paymentRequired = $this->commerce->paymentRequiredAtSignup($settings);
        $accountValue['status'] = $paymentRequired ? 'pending' : $this->resolveMemberStatus();
        $accountValue['verified'] = !(bool) get_plugin_setting('user_management', 'require_email_verification', false);

        if ($this->commerce->paymentEnabled($settings) && !$paymentRequired) {
            $accountValue = $this->commerce->syncAccountCommerce($accountValue, $settings);
        }

        $entry = $this->buildEntryPayload($input, $accountFieldName, $accountValue, $collectionSlug);
        if ($paymentRequired) {
            $entry['status'] = 'pending';
        }
        $saved = $this->persistEntry($collectionSlug, $entry);
        if (!$saved) {
            return ['ok' => false, 'error' => 'Could not create member entry'];
        }

        $indexer = new UserMemberIndexer();
        $indexer->indexEntry($saved, $collectionSlug);

        if (function_exists('do_action')) {
            do_action('user_member_registered', $saved, $collectionSlug, $accountValue);
        }

        $memberId = (string) ($accountValue['member_id'] ?? '');
        if ($this->commerce->checkoutRequiredForSignup($settings, $accountValue)) {
            $checkout = $this->commerce->buildSignupCheckoutPayload(
                $memberId,
                $emailPlain,
                (string) ($accountValue['name'] ?? ''),
                $settings,
                $collectionSlug
            );

            return [
                'ok' => true,
                'checkout_required' => true,
                'entry' => $saved,
                'member_id' => $memberId,
                'checkout' => $checkout,
                'message' => 'Complete payment to activate membership',
            ];
        }

        return [
            'ok' => true,
            'entry' => $saved,
            'member_id' => $memberId,
        ];
    }

    /**
     * Transform flat public_submit fields into a member entry (before_entry_create).
     *
     * @param array<string, mixed> $entry
     * @return array<string, mixed>
     */
    public function applyPublicSubmit(array $entry, string $collectionSlug): array
    {
        $accountField = $this->resolver->getAccountFieldOnSchema($collectionSlug);
        if ($accountField === null) {
            return $entry;
        }

        $accountFieldName = (string) ($accountField['name'] ?? 'account');
        $existing = $entry[$accountFieldName] ?? null;
        if (is_array($existing) && trim((string) ($existing['member_id'] ?? '')) !== '') {
            return $entry;
        }

        $typeKey = (string) ($accountField['type'] ?? 'user_account');
        $tierId = $this->extractTierParam($entry);
        $settings = $this->resolveProfileSettings($this->resolveTierId($tierId, $typeKey), $typeKey);

        $accountInput = $this->mapInputToAccountValue($entry, $settings, $typeKey, $this->resolveTierId($tierId, $typeKey));
        $errors = MemberAccountCodec::validate($accountInput, $settings, true);
        if ($errors !== []) {
            throw new Exception(implode(' ', $errors));
        }

        $emailPlain = strtolower(trim((string) ($accountInput['email'] ?? '')));
        if ($emailPlain !== '' && $this->emailExists($emailPlain)) {
            throw new Exception('An account with this email already exists');
        }

        $accountValue = MemberAccountCodec::processForStorage($accountInput, [], $settings, $typeKey);
        $accountValue['tier_id'] = $this->resolveTierId($tierId, $typeKey);
        $paymentRequired = $this->commerce->paymentRequiredAtSignup($settings);
        $accountValue['status'] = $paymentRequired ? 'pending' : $this->resolveMemberStatus();
        $accountValue['verified'] = !(bool) get_plugin_setting('user_management', 'require_email_verification', false);

        if ($this->commerce->paymentEnabled($settings) && !$paymentRequired) {
            $accountValue = $this->commerce->syncAccountCommerce($accountValue, $settings);
        }

        $entry[$accountFieldName] = $accountValue;
        $entry = $this->stripBuiltinFields($entry, $settings, $accountFieldName, $collectionSlug);
        $entry['title'] = trim((string) ($entry['title'] ?? $accountValue['name'] ?? $emailPlain));

        if (empty($entry['status'])) {
            $entry['status'] = $paymentRequired ? 'pending' : $this->resolveEntryStatus();
        }

        return $entry;
    }

    /**
     * @param array<string, mixed> $settings
     * @return list<array<string, mixed>>
     */
    public function buildPublicFields(array $settings): array
    {
        $fields = [];
        foreach ((array) ($settings['requirements']['fields'] ?? []) as $field) {
            if (!is_array($field)) {
                continue;
            }
            $key = (string) ($field['key'] ?? '');
            if ($key === '') {
                continue;
            }
            $fields[] = [
                'slug' => $key,
                'type' => (string) ($field['type'] ?? 'text'),
                'label' => (string) ($field['label'] ?? ucfirst($key)),
                'required' => !empty($field['required']),
                'placeholder' => '',
                'help_text' => '',
            ];
        }

        foreach ((array) ($settings['requirements']['custom_fields'] ?? []) as $field) {
            if (!is_array($field)) {
                continue;
            }
            $key = (string) ($field['key'] ?? '');
            if ($key === '') {
                continue;
            }
            $fields[] = [
                'slug' => $key,
                'type' => (string) ($field['type'] ?? 'text'),
                'label' => (string) ($field['label'] ?? $key),
                'required' => !empty($field['required']),
                'placeholder' => '',
                'help_text' => (string) ($field['help'] ?? ''),
            ];
        }

        return $fields;
    }

  /**
     * @param array<string, mixed> $input
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    public function mapInputToAccountValue(array $input, array $settings, string $typeKey, string $tierId): array
    {
        $profile = $this->profiles->getProfileByTypeKey($typeKey);
        $custom = [];
        foreach ((array) ($settings['requirements']['custom_fields'] ?? []) as $field) {
            if (!is_array($field)) {
                continue;
            }
            $key = (string) ($field['key'] ?? '');
            if ($key === '' || !array_key_exists($key, $input)) {
                continue;
            }
            $custom[$key] = $input[$key];
        }

        return [
            'email' => (string) ($input['email'] ?? ''),
            'password' => (string) ($input['password'] ?? ''),
            'name' => trim((string) ($input['name'] ?? $input['title'] ?? '')),
            'tier_id' => $tierId,
            'fieldtype_profile_id' => (string) ($profile['id'] ?? 'default'),
            'custom' => $custom,
        ];
    }

    private function resolveTierId(?string $tierId, string $typeKey): string
    {
        $tierId = trim((string) $tierId);
        if ($tierId === '') {
            if (str_starts_with($typeKey, 'user_account_')) {
                return substr($typeKey, strlen('user_account_'));
            }

            return 'all';
        }

        $tier = $this->storage->getTier($tierId);

        return is_array($tier) ? (string) ($tier['id'] ?? $tierId) : $tierId;
    }

    /** @return array<string, mixed> */
    private function resolveProfileSettings(string $tierId, string $typeKey): array
    {
        $tier = $this->storage->getTier($tierId);
        if (is_array($tier)) {
            $fromTier = $this->tierProfiles->getProfileSettingsForTier($tier);
            if (is_array($fromTier)) {
                return UserFieldtypeProfileStore::normalizeSettings(
                    $fromTier,
                    user_management_commerce_plugin_active()
                );
            }
        }

        return $this->profiles->getSettingsForTypeKey($typeKey);
    }

    /**
     * @param array<string, mixed> $input
     * @param array<string, mixed> $accountValue
     * @return array<string, mixed>
     */
    private function buildEntryPayload(array $input, string $accountFieldName, array $accountValue, string $collectionSlug): array
    {
        $entry = [
            'id' => uniqid('member_'),
            'title' => trim((string) ($input['title'] ?? $accountValue['name'] ?? '')),
            'status' => $this->resolveEntryStatus(),
            'created_at' => date('c'),
            'updated_at' => date('c'),
            $accountFieldName => $accountValue,
        ];

        $schemaFieldNames = $this->schemaFieldNames($collectionSlug);
        foreach ($input as $key => $value) {
            if (!is_string($key) || in_array($key, ['tier', 'tier_id', 'collection', 'email', 'password', 'name'], true)) {
                continue;
            }
            if ($key === $accountFieldName) {
                continue;
            }
            if ($schemaFieldNames !== [] && !in_array($key, $schemaFieldNames, true)) {
                continue;
            }
            if (!array_key_exists($key, $entry)) {
                $entry[$key] = $value;
            }
        }

        if (trim((string) ($entry['title'] ?? '')) === '') {
            $email = MemberAccountCodec::decryptEmail((string) ($accountValue['email'] ?? '')) ?? '';
            $entry['title'] = $email !== '' ? $email : 'Member';
        }

        return $entry;
    }

    /** @return array<string, mixed>|null */
    private function persistEntry(string $collectionSlug, array $entry): ?array
    {
        $entryId = (string) ($entry['id'] ?? '');
        if ($entryId === '') {
            return null;
        }

        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $dir = $this->resolveCollectionDir($storage, $collectionSlug);
        if ($dir === null) {
            return null;
        }

        $path = "collections/{$dir}/entries/{$entryId}.json";
        if (!$storage->write($path, $entry)) {
            return null;
        }

        return $entry;
    }

    private function resolveCollectionDir(Storage $storage, string $collectionSlug): ?string
    {
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (is_array($meta) && (string) ($meta['slug'] ?? '') === $collectionSlug) {
                return (string) $dir;
            }
        }

        if (is_dir(user_management_cms_path('content/collections/' . $collectionSlug))) {
            return $collectionSlug;
        }

        return null;
    }

    /** @return list<string> */
    private function schemaFieldNames(string $collectionSlug): array
    {
        $resolver = new UserCollectionResolver();
        $field = $resolver->getAccountFieldOnSchema($collectionSlug);
        if ($field === null) {
            return [];
        }

        $names = [];
        if (function_exists('birkly_entry_read_schema')) {
            $schema = birkly_entry_read_schema($collectionSlug);
            foreach ((array) ($schema['fields'] ?? []) as $f) {
                if (is_array($f) && !empty($f['name'])) {
                    $names[] = (string) $f['name'];
                }
            }
        }

        $schemaPath = user_management_cms_path('content/collections/' . $collectionSlug . '/schema.json');
        if ($names === [] && is_file($schemaPath)) {
            $schema = json_decode((string) file_get_contents($schemaPath), true);
            foreach ((array) ($schema['fields'] ?? []) as $f) {
                if (is_array($f) && !empty($f['name'])) {
                    $names[] = (string) $f['name'];
                }
            }
        }

        return $names;
    }

    private function emailExists(string $email): bool
    {
        $hash = hash('sha256', strtolower($email));
        $indexer = new UserMemberIndexer();
        foreach ($indexer->listMembers() as $row) {
            if (is_array($row) && ($row['email_hash'] ?? '') === $hash) {
                return true;
            }
        }

        return false;
    }

    private function resolveMemberStatus(): string
    {
        $autoApprove = get_plugin_setting('user_management', 'auto_approve_users', null);
        if ($autoApprove === null) {
            $autoApprove = get_plugin_setting('user_management', 'auto_approve', true);
        }

        return $autoApprove ? 'active' : 'pending';
    }

    private function resolveEntryStatus(): string
    {
        $autoApprove = get_plugin_setting('user_management', 'auto_approve_users', null);
        if ($autoApprove === null) {
            $autoApprove = get_plugin_setting('user_management', 'auto_approve', true);
        }

        return $autoApprove ? 'published' : 'pending';
    }

    /**
     * @param array<string, mixed> $entry
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    private function stripBuiltinFields(array $entry, array $settings, string $accountFieldName, string $collectionSlug): array
    {
        $builtin = ['email', 'password', 'name'];
        foreach ((array) ($settings['requirements']['custom_fields'] ?? []) as $field) {
            if (!is_array($field)) {
                continue;
            }
            $key = (string) ($field['key'] ?? '');
            if ($key !== '') {
                $builtin[] = $key;
            }
        }

        $schemaNames = $this->schemaFieldNames($collectionSlug);
        foreach ($builtin as $key) {
            if ($schemaNames !== [] && in_array($key, $schemaNames, true)) {
                continue;
            }
            unset($entry[$key]);
        }

        unset($entry['tier'], $entry['tier_id'], $entry['collection']);

        return $entry;
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function extractTierParam(array $entry): ?string
    {
        $tier = trim((string) ($entry['tier_id'] ?? $entry['tier'] ?? ''));
        if ($tier !== '') {
            return $tier;
        }

        if (isset($_GET['tier'])) {
            return trim((string) $_GET['tier']);
        }
        if (isset($_GET['tier_id'])) {
            return trim((string) $_GET['tier_id']);
        }

        return null;
    }
}
