<?php
/**
 * Signup flow engine (P74-M3).
 *
 * Orchestrates preset signup flows: field collection, payment handoff, activation, tier grant.
 */

declare(strict_types=1);

require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/SignupFieldSchema.php';
require_once __DIR__ . '/MemberSignupService.php';
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/UserActivationShelf.php';
require_once __DIR__ . '/UserTiers.php';
require_once __DIR__ . '/EmailVerification.php';
require_once __DIR__ . '/ClubProfileService.php';

class SignupFlowEngine
{
    private UserStorage $storage;
    private SignupFieldSchema $fieldSchema;
    private MemberSignupService $memberSignup;

    public static function registerEntitlementFilter(): void
    {
        if (!function_exists('add_filter')) {
            return;
        }

        add_filter('user_activation_entitled', static function (bool $entitled, string $email, array $context = []): bool {
            if ($entitled) {
                return true;
            }

            return user_management_signup_flow_activation_entitled($email, $context);
        }, 20, 3);
    }

    public function __construct(
        ?UserStorage $storage = null,
        ?SignupFieldSchema $fieldSchema = null,
        ?MemberSignupService $memberSignup = null
    ) {
        $this->storage = $storage ?? new UserStorage();
        $this->fieldSchema = $fieldSchema ?? new SignupFieldSchema($this->storage);
        $this->memberSignup = $memberSignup ?? new MemberSignupService();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listFlows(bool $enabledOnly = false): array
    {
        $flows = $this->mergedFlows();
        if ($enabledOnly) {
            $flows = array_values(array_filter($flows, static fn ($f) => !empty($f['enabled'])));
        }

        return $flows;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getFlow(string $flowId): ?array
    {
        foreach ($this->mergedFlows() as $flow) {
            if (($flow['id'] ?? '') === $flowId) {
                return $flow;
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function start(string $flowId, array $payload = []): array
    {
        $flow = $this->getFlow($flowId);
        if ($flow === null || empty($flow['enabled'])) {
            return ['ok' => false, 'error' => 'Signup flow not found or disabled'];
        }

        $steps = $flow['steps'] ?? [];
        if (!is_array($steps) || $steps === []) {
            return ['ok' => false, 'error' => 'Flow has no steps'];
        }

        $sessionId = bin2hex(random_bytes(16));
        $metadata = is_array($payload['metadata'] ?? null) ? $payload['metadata'] : [];
        $collectionSlug = trim((string) ($payload['collection'] ?? $payload['collection_slug'] ?? $metadata['collection'] ?? $metadata['collection_slug'] ?? ''));
        $tierId = trim((string) ($payload['tier'] ?? $payload['tier_id'] ?? $metadata['tier'] ?? $metadata['tier_id'] ?? ''));
        if ($collectionSlug !== '') {
            $metadata['collection_slug'] = $collectionSlug;
        }
        if ($tierId !== '') {
            $metadata['tier_id'] = $tierId;
        }

        $session = [
            'session_id' => $sessionId,
            'flow_id' => $flowId,
            'current_step_index' => 0,
            'email' => strtolower(trim((string) ($payload['email'] ?? ''))),
            'field_values' => $this->extractSignupFieldsFromPayload($payload),
            'user_id' => null,
            'member_id' => null,
            'completed_steps' => [],
            'metadata' => $metadata,
            'created_at' => date('c'),
            'updated_at' => date('c'),
        ];
        if ($session['email'] === '' && !empty($session['field_values']['email'])) {
            $session['email'] = strtolower(trim((string) $session['field_values']['email']));
        }

        if (!$this->storage->saveSignupFlowSession($sessionId, $session)) {
            return ['ok' => false, 'error' => 'Could not start signup flow'];
        }

        if ($this->shouldAutoRunSignupStartStep($payload, $session)) {
            $firstStepId = (string) (($steps[0]['id'] ?? '') ?: 'fields');
            return $this->runStep($sessionId, $firstStepId, [
                'fields' => $session['field_values'],
                'email' => $session['email'],
            ]);
        }

        return $this->buildStepResponse($session, $flow);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function extractSignupFieldsFromPayload(array $payload): array
    {
        $fields = is_array($payload['fields'] ?? null) ? $payload['fields'] : [];
        foreach (['email', 'password', 'name', 'username', 'phone'] as $key) {
            if (array_key_exists($key, $payload) && $payload[$key] !== '' && $payload[$key] !== null) {
                $fields[$key] = $payload[$key];
            }
        }

        return $fields;
    }

    /**
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $session
     */
    private function shouldAutoRunSignupStartStep(array $payload, array $session): bool
    {
        // HTML forms post flat keys; programmatic/API callers use fields[] only.
        $fromHtmlForm = array_key_exists('email', $payload) || array_key_exists('password', $payload);
        if (!$fromHtmlForm) {
            return false;
        }

        $email = trim((string) ($session['email'] ?? ''));
        $password = trim((string) (($session['field_values']['password'] ?? '')));

        return $email !== '' && $password !== '';
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function runStep(string $sessionId, ?string $stepId, array $payload = []): array
    {
        $session = $this->storage->getSignupFlowSession($sessionId);
        if ($session === null) {
            return ['ok' => false, 'error' => 'Signup session not found'];
        }

        $flow = $this->getFlow((string) ($session['flow_id'] ?? ''));
        if ($flow === null) {
            return ['ok' => false, 'error' => 'Flow configuration missing'];
        }

        $steps = $flow['steps'] ?? [];
        $index = (int) ($session['current_step_index'] ?? 0);
        $current = $steps[$index] ?? null;
        if (!is_array($current)) {
            return ['ok' => false, 'error' => 'Flow already completed'];
        }

        if ($stepId !== null && $stepId !== '' && ($current['id'] ?? '') !== $stepId) {
            return ['ok' => false, 'error' => 'Unexpected step'];
        }

        $result = $this->executeStep($current, $session, $flow, $payload);
        if (!($result['ok'] ?? false)) {
            return $result;
        }

        $session = $result['session'] ?? $session;
        if (!empty($result['advance'])) {
            $session['current_step_index'] = $index + 1;
            $session['completed_steps'][] = (string) ($current['id'] ?? $current['type'] ?? 'step');
            $session = $this->autoAdvanceAutomaticSteps($session, $flow, $payload);
        }

        $session['updated_at'] = date('c');
        $this->storage->saveSignupFlowSession($sessionId, $session);

        if (!empty($result['advance'])) {
            return $this->buildStepResponse($session, $flow);
        }

        return array_merge(['ok' => true, 'session_id' => $sessionId], $result);
    }

    /**
     * @return array<string, mixed>
     */
    public function getStatus(string $sessionId): array
    {
        $session = $this->storage->getSignupFlowSession($sessionId);
        if ($session === null) {
            return ['ok' => false, 'error' => 'Signup session not found'];
        }

        $flow = $this->getFlow((string) ($session['flow_id'] ?? ''));
        if ($flow === null) {
            return ['ok' => false, 'error' => 'Flow configuration missing'];
        }

        return $this->buildStepResponse($session, $flow);
    }

    /**
     * Handle generic Commerce events (subscription started, order paid).
     *
     * @param array<string, mixed> $payload
     */
    public function onCommerceEvent(string $event, array $payload): array
    {
        $normalized = strtolower(trim($event));
        if (!in_array($normalized, ['commerce_subscription_started', 'commerce_membership_started', 'commerce_order_paid'], true)) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'unsupported_event'];
        }

        if (!function_exists('user_management_signup_flow_signals')) {
            require_once __DIR__ . '/SignupFlowPayload.php';
        }
        $signals = user_management_signup_flow_signals($payload);
        if (!user_management_should_handle_signup_flow_commerce($payload)) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'signup_flow_not_opted_in'];
        }

        $sessionId = $signals['session_id'];
        $flowId = $signals['flow_id'];

        $email = strtolower(trim((string) ($payload['customer_email'] ?? $payload['email'] ?? $metadata['customer_email'] ?? '')));
        if ($email === '' && $sessionId !== '') {
            $session = $this->storage->getSignupFlowSession($sessionId);
            $email = strtolower(trim((string) ($session['email'] ?? '')));
        }

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'error' => 'No customer email on commerce event'];
        }

        if ($sessionId !== '') {
            $session = $this->storage->getSignupFlowSession($sessionId);
            if (is_array($session)) {
                $session['email'] = $email;
                $session['metadata']['commerce_event'] = $normalized;
                $session['updated_at'] = date('c');
                $this->storage->saveSignupFlowSession($sessionId, $session);
            }
        }

        $flow = $flowId !== '' ? $this->getFlow($flowId) : null;
        $tierId = (string) ($flow['tier_id'] ?? 'club');
        $context = [
            'source' => 'signup_flow',
            'signup_flow_id' => $flowId,
            'signup_flow_session_id' => $sessionId,
            'tier_id' => $tierId,
            'commerce_event' => $normalized,
            'order_id' => (string) ($payload['order_id'] ?? ''),
        ];

        if ($existingUserId = $this->resolveExistingUserId($email)) {
            return $this->handleExistingUserCommerceSignup($existingUserId, $email, $tierId, $payload, $context);
        }

        $shelf = new UserActivationShelf();
        $send = $shelf->sendActivation($email, $context);

        return [
            'ok' => (bool) ($send['success'] ?? false),
            'activation' => $send,
            'email' => $email,
            'flow_id' => $flowId,
        ];
    }

    /**
     * @param array<string, mixed> $overrides
     */
    public function saveFlowOverrides(array $overrides): bool
    {
        $flows = [];
        foreach ($overrides as $row) {
            if (!is_array($row) || empty($row['id'])) {
                continue;
            }
            $flows[] = [
                'id' => (string) $row['id'],
                'enabled' => !empty($row['enabled']),
                'tier_id' => trim((string) ($row['tier_id'] ?? '')),
                'redirect_url' => trim((string) ($row['redirect_url'] ?? '')),
                'commerce' => is_array($row['commerce'] ?? null) ? $row['commerce'] : [],
            ];
        }

        return $this->storage->saveMetadata('signup_flows', ['flows' => $flows, 'updated_at' => date('c')]);
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function mergedFlows(): array
    {
        $presets = $this->loadPresets();
        $stored = $this->storage->readMetadata('signup_flows');
        $overrides = is_array($stored['flows'] ?? null) ? $stored['flows'] : [];
        $byId = [];
        foreach ($overrides as $row) {
            if (!empty($row['id'])) {
                $byId[(string) $row['id']] = $row;
            }
        }

        $merged = [];
        foreach ($presets as $preset) {
            $id = (string) ($preset['id'] ?? '');
            if ($id === '') {
                continue;
            }
            $merged[] = $this->applyMembershipProductWiring(
            array_replace_recursive($preset, $byId[$id] ?? [])
        );
        }

        return $merged;
    }

    /**
     * Wire signup flow commerce refs from membership product config (P74-M5).
     *
     * @param array<string, mixed> $flow
     * @return array<string, mixed>
     */
    private function applyMembershipProductWiring(array $flow): array
    {
        if (!class_exists('MembershipProductRegistry')) {
            require_once __DIR__ . '/MembershipProductRegistry.php';
        }
        $flowId = (string) ($flow['id'] ?? '');
        if ($flowId === '') {
            return $flow;
        }

        $product = (new MembershipProductRegistry())->getBySignupFlowId($flowId);
        if ($product === null) {
            return $flow;
        }

        $commerce = is_array($flow['commerce'] ?? null) ? $flow['commerce'] : [];
        foreach (['collection', 'entry_id', 'purchase_option_id'] as $key) {
            $current = trim((string) ($commerce[$key] ?? ''));
            $fromProduct = trim((string) ($product[$key] ?? ''));
            if ($current === '' && $fromProduct !== '') {
                $commerce[$key] = $fromProduct;
            }
        }
        $flow['commerce'] = $commerce;

        $tierFromProduct = trim((string) ($product['tier_id'] ?? ''));
        if ($tierFromProduct !== '') {
            $flow['tier_id'] = $tierFromProduct;
        }

        return $flow;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function loadPresets(): array
    {
        $path = dirname(__DIR__) . '/config/signup_flow_presets.json';
        if (!is_file($path)) {
            return [];
        }
        $data = json_decode((string) file_get_contents($path), true);

        return is_array($data) ? $data : [];
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     * @return array<string, mixed>
     */
    private function buildStepResponse(array $session, array $flow): array
    {
        $steps = $flow['steps'] ?? [];
        $index = (int) ($session['current_step_index'] ?? 0);
        if (!isset($steps[$index])) {
            return [
                'ok' => true,
                'completed' => true,
                'session_id' => $session['session_id'] ?? '',
                'flow_id' => $flow['id'] ?? '',
                'redirect_url' => $this->resolveRedirectUrl($flow),
            ];
        }

        $step = $steps[$index];

        return [
            'ok' => true,
            'completed' => false,
            'session_id' => $session['session_id'] ?? '',
            'flow_id' => $flow['id'] ?? '',
            'step' => [
                'id' => $step['id'] ?? '',
                'type' => $step['type'] ?? '',
                'index' => $index,
                'total' => count($steps),
            ],
            'fields' => ($step['type'] ?? '') === 'collect_fields'
                ? $this->resolveCollectFields($session, $flow)
                : [],
            'email' => $session['email'] ?? '',
        ];
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     * @param array<string, mixed> $payload
     *
     * @return array<string, mixed>
     */
    private function autoAdvanceAutomaticSteps(array $session, array $flow, array $payload = []): array
    {
        $steps = $flow['steps'] ?? [];
        $maxHops = is_array($steps) ? count($steps) + 2 : 2;

        while ($maxHops-- > 0) {
            $index = (int) ($session['current_step_index'] ?? 0);
            $current = $steps[$index] ?? null;
            if (!is_array($current) || !$this->isAutomaticStep($current)) {
                break;
            }

            $result = $this->executeStep($current, $session, $flow, $payload);
            if (!($result['ok'] ?? false) || empty($result['advance'])) {
                break;
            }

            $session = $result['session'] ?? $session;
            $session['current_step_index'] = $index + 1;
            $session['completed_steps'][] = (string) ($current['id'] ?? $current['type'] ?? 'step');
        }

        return $session;
    }

    /**
     * @param array<string, mixed> $step
     */
    private function isAutomaticStep(array $step): bool
    {
        $type = (string) ($step['type'] ?? '');

        return match ($type) {
            'verify_email' => !empty($step['optional']),
            'create_club_profile', 'grant_tier', 'redirect' => true,
            default => false,
        };
    }

    private function executeStep(array $step, array $session, array $flow, array $payload): array
    {
        $type = (string) ($step['type'] ?? '');

        return match ($type) {
            'collect_fields' => $this->stepCollectFields($session, $flow, $payload),
            'verify_email' => $this->stepVerifyEmail($session, $flow, $step),
            'payment' => $this->stepPayment($session, $flow, $payload),
            'set_password' => $this->stepSetPassword($session, $flow, $step, $payload),
            'grant_tier' => $this->stepGrantTier($session, $flow),
            'create_club_profile' => $this->stepCreateClubProfile($session, $flow),
            'redirect' => $this->stepRedirect($flow),
            default => ['ok' => false, 'error' => 'Unknown step type: ' . $type],
        };
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     * @param array<string, mixed> $payload
     */
    private function stepCollectFields(array $session, array $flow, array $payload): array
    {
        $collectionSlug = $this->sessionCollectionSlug($session);
        if ($collectionSlug !== '') {
            return $this->stepCollectMemberFields($session, $flow, $payload, $collectionSlug);
        }

        $input = is_array($payload['fields'] ?? null) ? $payload['fields'] : $payload;
        $validated = $this->fieldSchema->validate($input, SignupFieldSchema::CONTEXT_REGISTER);
        if (!$validated['ok']) {
            return ['ok' => false, 'error' => implode(' ', $validated['errors']), 'errors' => $validated['errors']];
        }

        $userData = $validated['user_data'];
        $email = strtolower(trim((string) ($userData['email'] ?? '')));

        try {
            $service = new UserService();
            $user = $service->createUser(array_merge($userData, [
                'tier' => $flow['tier_id'] ?? 'all',
                'verified' => false,
                'approved' => true,
            ]));
            $session['user_id'] = $user['id'] ?? null;
            $session['email'] = $email;
            $session['field_values'] = array_merge($session['field_values'] ?? [], $userData, $validated['custom_fields']);
            if ($validated['custom_fields'] !== []) {
                $this->fieldSchema->persistForUser((string) $user['id'], $userData, $validated['custom_fields']);
            }
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }

        return ['ok' => true, 'advance' => true, 'session' => $session];
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     * @param array<string, mixed> $payload
     */
    private function stepCollectMemberFields(array $session, array $flow, array $payload, string $collectionSlug): array
    {
        $input = is_array($payload['fields'] ?? null) ? $payload['fields'] : $payload;
        $tierId = $this->sessionTierId($session, $flow);
        $result = $this->memberSignup->register($input, $collectionSlug, $tierId !== '' ? $tierId : null);
        if (empty($result['ok'])) {
            return [
                'ok' => false,
                'error' => (string) ($result['error'] ?? 'Signup failed'),
                'errors' => $result['errors'] ?? [],
            ];
        }

        $email = strtolower(trim((string) ($input['email'] ?? '')));
        $session['email'] = $email;
        $session['member_id'] = (string) ($result['member_id'] ?? '');
        $session['field_values'] = array_merge($session['field_values'] ?? [], $input);

        return ['ok' => true, 'advance' => true, 'session' => $session, 'entry' => $result['entry'] ?? null];
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     * @return list<array<string, mixed>>
     */
    private function resolveCollectFields(array $session, array $flow): array
    {
        $collectionSlug = $this->sessionCollectionSlug($session);
        if ($collectionSlug === '') {
            return $this->fieldSchema->getPublicFields(SignupFieldSchema::CONTEXT_REGISTER);
        }

        $schema = $this->memberSignup->getSignupSchema($collectionSlug, $this->sessionTierId($session, $flow) ?: null);
        if (empty($schema['ok'])) {
            return [];
        }

        return is_array($schema['fields'] ?? null) ? $schema['fields'] : [];
    }

    /**
     * @param array<string, mixed> $session
     */
    private function sessionCollectionSlug(array $session): string
    {
        $metadata = is_array($session['metadata'] ?? null) ? $session['metadata'] : [];

        return trim((string) ($metadata['collection_slug'] ?? $metadata['collection'] ?? ''));
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     */
    private function sessionTierId(array $session, array $flow): string
    {
        $metadata = is_array($session['metadata'] ?? null) ? $session['metadata'] : [];

        return trim((string) ($metadata['tier_id'] ?? $metadata['tier'] ?? $flow['tier_id'] ?? ''));
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     * @param array<string, mixed> $step
     */
    private function stepVerifyEmail(array $session, array $flow, array $step): array
    {
        if (!empty($step['optional'])) {
            return ['ok' => true, 'advance' => true, 'session' => $session];
        }

        $userId = (string) ($session['user_id'] ?? '');
        $email = (string) ($session['email'] ?? '');
        if ($userId === '' || $email === '') {
            return ['ok' => false, 'error' => 'User required for email verification'];
        }

        $verification = new EmailVerification();
        $token = $verification->generateToken($userId);
        $sent = $verification->sendVerificationEmail($userId, $email, $token);
        if (!$sent) {
            return ['ok' => false, 'error' => 'Could not send verification email'];
        }

        return ['ok' => true, 'advance' => true, 'session' => $session, 'message' => 'Verification email sent'];
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     * @param array<string, mixed> $payload
     */
    private function stepPayment(array $session, array $flow, array $payload): array
    {
        $email = strtolower(trim((string) ($payload['email'] ?? $session['email'] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'error' => 'customer.email required for payment step'];
        }

        $session['email'] = $email;
        $commerce = is_array($flow['commerce'] ?? null) ? $flow['commerce'] : [];
        $collection = trim((string) ($commerce['collection'] ?? ''));
        $entryId = trim((string) ($commerce['entry_id'] ?? ''));
        $optionId = trim((string) ($commerce['purchase_option_id'] ?? ''));

        $metadata = [
            'signup_flow_id' => (string) ($flow['id'] ?? ''),
            'signup_flow_session_id' => (string) ($session['session_id'] ?? ''),
            'signup_flow_opt_in' => '1',
            'tier_id' => (string) ($flow['tier_id'] ?? 'club'),
        ];

        $checkout = [
            'action' => 'begin_linked_checkout',
            'product' => [
                'collection' => $collection,
                'entry_id' => $entryId,
                'purchase_option_id' => $optionId,
            ],
            'customer' => ['email' => $email],
            'metadata' => $metadata,
        ];

        $hosted = $this->tryBeginLinkedCheckout($checkout);
        if ($hosted !== null) {
            return [
                'ok' => true,
                'advance' => false,
                'session' => $session,
                'checkout' => $hosted,
            ];
        }

        return [
            'ok' => true,
            'advance' => false,
            'session' => $session,
            'checkout' => $checkout,
            'message' => 'Complete checkout via Commerce begin_linked_checkout',
        ];
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     * @param array<string, mixed> $step
     * @param array<string, mixed> $payload
     */
    private function stepSetPassword(array $session, array $flow, array $step, array $payload): array
    {
        if (($step['mode'] ?? '') === 'request_link') {
            $email = strtolower(trim((string) ($payload['email'] ?? $session['email'] ?? '')));
            if ($email === '') {
                return ['ok' => false, 'error' => 'Email is required'];
            }

            $context = [
                'source' => 'signup_flow',
                'signup_flow_id' => (string) ($flow['id'] ?? ''),
                'signup_flow_session_id' => (string) ($session['session_id'] ?? ''),
                'tier_id' => (string) ($flow['tier_id'] ?? 'club'),
            ];

            $shelf = new UserActivationShelf();
            $send = $shelf->sendActivation($email, $context);
            $session['email'] = $email;

            return [
                'ok' => (bool) ($send['success'] ?? false),
                'advance' => true,
                'session' => $session,
                'message' => $send['message'] ?? 'Activation email sent if entitled',
            ];
        }

        return [
            'ok' => true,
            'advance' => false,
            'activate_url' => $this->activationUrl(),
            'message' => 'Complete activation at activate-account with token from email',
        ];
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     */
    private function stepCreateClubProfile(array $session, array $flow): array
    {
        $userId = (string) ($session['user_id'] ?? '');
        if ($userId === '') {
            return ['ok' => false, 'error' => 'User required for club profile'];
        }

        $fields = is_array($session['field_values'] ?? null) ? $session['field_values'] : [];
        $title = trim((string) ($fields['name'] ?? $fields['title'] ?? ''));
        if ($title === '') {
            try {
                $user = (new UserService())->getUser($userId);
                $title = trim((string) ($user['name'] ?? $user['email'] ?? 'Club member'));
            } catch (Throwable $e) {
                $title = 'Club member';
            }
        }

        try {
            $profiles = new ClubProfileService();
            $profiles->saveProfileForUser($userId, [
                'title' => $title,
                'bio' => trim((string) ($fields['bio'] ?? '')),
                'supporter_badge' => 'none',
                'supporter_cadence' => 'none',
                'supporter_amount_eur' => 0,
            ]);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }

        $tierId = trim((string) ($flow['tier_id'] ?? ''));
        if ($tierId !== '' && $tierId !== 'all') {
            try {
                (new UserTiers())->setUserTier($userId, $tierId);
            } catch (Throwable $e) {
                return ['ok' => false, 'error' => 'Could not grant tier: ' . $e->getMessage()];
            }
        }

        return ['ok' => true, 'advance' => true, 'session' => $session];
    }

    /**
     * @param array<string, mixed> $session
     * @param array<string, mixed> $flow
     */
    private function stepGrantTier(array $session, array $flow): array
    {
        $userId = (string) ($session['user_id'] ?? '');
        $tierId = (string) ($flow['tier_id'] ?? 'all');
        if ($userId === '') {
            return ['ok' => true, 'advance' => true, 'session' => $session, 'skipped' => true];
        }

        $tiers = new UserTiers();
        try {
            $tiers->setUserTier($userId, $tierId);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'Could not grant tier: ' . $e->getMessage()];
        }

        return ['ok' => true, 'advance' => true, 'session' => $session];
    }

    /**
     * @param array<string, mixed> $flow
     */
    private function stepRedirect(array $flow): array
    {
        return [
            'ok' => true,
            'advance' => true,
            'redirect_url' => $this->resolveRedirectUrl($flow),
        ];
    }

    /**
     * @param array<string, mixed> $flow
     */
    private function resolveRedirectUrl(array $flow): string
    {
        $url = trim((string) ($flow['redirect_url'] ?? '/'));
        if ($url === '') {
            return '/';
        }
        if (!function_exists('user_management_site_url')) {
            require_once dirname(__DIR__) . '/cms_paths.php';
        }
        if (str_starts_with($url, 'http://') || str_starts_with($url, 'https://')) {
            return $url;
        }

        return rtrim(user_management_site_url(), '/') . '/' . ltrim($url, '/');
    }

    private function activationUrl(): string
    {
        if (!function_exists('user_management_site_url')) {
            require_once dirname(__DIR__) . '/cms_paths.php';
        }

        return user_management_site_url() . '/activate-account';
    }

    /**
     * @param array<string, mixed> $checkout
     * @return array<string, mixed>|null
     */
    private function tryBeginLinkedCheckout(array $checkout): ?array
    {
        if (!function_exists('get_plugin_state') || !get_plugin_state('commerce')) {
            return null;
        }

        if (function_exists('birkly_plugin_require')) {
            birkly_plugin_require('commerce', 'includes/CommerceLinkedCheckoutService.php');
            birkly_plugin_require('commerce', 'includes/CommerceCartSession.php');
            birkly_plugin_require('commerce', 'includes/CommerceCatalog.php');
            birkly_plugin_require('commerce', 'includes/CommerceCheckoutService.php');
        }

        if (!class_exists('CommerceLinkedCheckoutService')) {
            return null;
        }

        try {
            $cart = new CommerceCartSession();
            $catalog = new CommerceCatalog();
            $checkoutService = new CommerceCheckoutService();
            $linked = new CommerceLinkedCheckoutService($cart, $catalog, $checkoutService);
            $product = $checkout['product'] ?? [];
            if (trim((string) ($product['collection'] ?? '')) === '' || trim((string) ($product['entry_id'] ?? '')) === '') {
                return null;
            }

            $result = $linked->begin([
                'product' => $product,
                'customer' => $checkout['customer'] ?? [],
                'metadata' => $checkout['metadata'] ?? [],
            ]);

            return is_array($result) ? $result : null;
        } catch (Throwable $e) {
            error_log('SignupFlowEngine linked checkout: ' . $e->getMessage());

            return null;
        }
    }

    /**
     * Returning site users who opted into club via donation/checkout.
     *
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function handleExistingUserCommerceSignup(
        string $userId,
        string $email,
        string $tierId,
        array $payload,
        array $context
    ): array {
        $tierId = trim($tierId) !== '' ? trim($tierId) : 'club';

        try {
            $tiers = new UserTiers();
            $currentTier = (string) ($tiers->getUserTier($userId) ?? '');
            if ($currentTier !== $tierId) {
                $tiers->setUserTier($userId, $tierId);
            }
        } catch (Throwable $e) {
            error_log('SignupFlowEngine existing user tier grant: ' . $e->getMessage());

            return ['ok' => false, 'error' => 'Could not grant club tier'];
        }

        $welcomeSent = false;
        try {
            $verification = new EmailVerification();
            $welcomeSent = $verification->sendMembershipWelcomeEmail($email, $tierId, array_merge($payload, $context));
        } catch (Throwable $e) {
            error_log('SignupFlowEngine existing user welcome email: ' . $e->getMessage());
        }

        return [
            'ok' => true,
            'action' => 'existing_user_tier_granted',
            'user_id' => $userId,
            'tier_id' => $tierId,
            'email' => $email,
            'welcome_sent' => $welcomeSent,
        ];
    }

    private function resolveExistingUserId(string $email): ?string
    {
        $email = strtolower(trim($email));
        if ($email === '') {
            return null;
        }

        if (function_exists('get_plugin_service')) {
            $service = get_plugin_service('user_service', false, 'user_management');
            if (is_object($service) && method_exists($service, 'getUserByEmail')) {
                try {
                    $user = $service->getUserByEmail($email);

                    return isset($user['id']) ? (string) $user['id'] : null;
                } catch (Throwable $e) {
                    return null;
                }
            }
        }

        try {
            $service = new UserService();
            $user = $service->getUserByEmail($email);

            return isset($user['id']) ? (string) $user['id'] : null;
        } catch (Throwable $e) {
            return null;
        }
    }
}
