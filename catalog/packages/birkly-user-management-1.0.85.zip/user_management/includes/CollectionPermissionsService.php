<?php
/**
 * CollectionPermissionsService - admin collection/tier permission matrix support.
 */

require_once __DIR__ . '/UserStorage.php';

class CollectionPermissionsService {
    private $storage;

    public function __construct() {
        $this->storage = new UserStorage();
    }

    /**
     * Return tier summaries for the admin matrix.
     */
    public function listTierOptions() {
        $tiers = [];
        foreach ($this->storage->listTiers() as $tierData) {
            if (!is_array($tierData)) {
                continue;
            }

            $tierId = $tierData['id'] ?? ($tierData['tier_id'] ?? null);
            if (!$tierId) {
                continue;
            }

            $tiers[] = [
                'id' => $tierId,
                'name' => $tierData['name'] ?? $tierId
            ];
        }

        return $tiers;
    }

    /**
     * Get stored matrix as an associative array.
     */
    public function getPermissions() {
        $permissions = $this->storage->readMetadata('collection_permissions');
        if (!is_array($permissions) || $this->isListArray($permissions)) {
            return [];
        }

        return $permissions;
    }

    /**
     * Save sanitized collection permission matrix.
     */
    public function savePermissions($permissions) {
        $cleanedPermissions = $this->normalizePermissions($permissions);
        if (!$this->storage->saveMetadata('collection_permissions', $cleanedPermissions)) {
            throw new Exception('Failed to save permissions');
        }

        return $cleanedPermissions;
    }

    /**
     * Normalize JSON-decoded payloads while preserving empty collection objects.
     */
    public function normalizePermissions($permissions) {
        if (is_object($permissions)) {
            $permissions = (array) $permissions;
        }

        if (!is_array($permissions) || $this->isListArray($permissions)) {
            return [];
        }

        $cleanedPermissions = [];
        foreach ($permissions as $collectionSlug => $tierPerms) {
            if (!is_string($collectionSlug) || $collectionSlug === '') {
                continue;
            }

            if (is_object($tierPerms)) {
                $tierPerms = (array) $tierPerms;
            }

            $cleanedPermissions[$collectionSlug] = is_array($tierPerms)
                ? $this->normalizeTierPermissions($tierPerms)
                : [];
        }

        return $cleanedPermissions;
    }

    private function normalizeTierPermissions($tierPerms) {
        if ($this->isListArray($tierPerms)) {
            return [];
        }

        $normalized = [];
        foreach ($tierPerms as $tierId => $permissions) {
            if (!is_string($tierId) || $tierId === '') {
                continue;
            }

            if (is_object($permissions)) {
                $permissions = (array) $permissions;
            }

            $normalized[$tierId] = is_array($permissions) ? $permissions : [];
        }

        return $normalized;
    }

    private function isListArray($value) {
        if (!is_array($value)) {
            return false;
        }

        if (empty($value)) {
            return false;
        }

        return array_keys($value) === range(0, count($value) - 1);
    }
}
