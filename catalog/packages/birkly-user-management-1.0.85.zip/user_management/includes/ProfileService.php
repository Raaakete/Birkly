<?php
/**
 * ProfileService - optional "profile collection" helper for sites.
 *
 * This stays generic: the site/admin chooses which collection slug is the profile collection.
 * The plugin can then auto-create and manage profile entries.
 */
require_once __DIR__ . '/../cms_paths.php';
require_once user_management_cms_path('api/storage.php'); // Storage compatibility layer

class ProfileService {
    private $storage;

    public function __construct() {
        $this->storage = new Storage(user_management_cms_path('content'));
    }

    public function collectionExists(string $collectionSlug): bool {
        return is_dir(user_management_cms_path('content/collections/' . $collectionSlug));
    }

    public function getProfileByUserId(string $collectionSlug, string $userId): ?array {
        return $this->getProfileByOwnerId($collectionSlug, $userId);
    }

    public function getProfileByOwnerId(string $collectionSlug, string $userId): ?array {
        if ($collectionSlug === '' || $userId === '') return null;
        if (!$this->collectionExists($collectionSlug)) return null;

        $results = $this->storage->query($collectionSlug, ['owner' => $userId], ['limit' => 1]);
        if (is_array($results) && count($results) > 0) {
            return $results[0];
        }

        // Legacy fallback during migration
        $legacy = $this->storage->query($collectionSlug, ['user_id' => $userId], ['limit' => 1]);
        if (is_array($legacy) && count($legacy) > 0) {
            return $legacy[0];
        }

        return null;
    }

    public function ensureProfileForUser(string $collectionSlug, array $user): ?array {
        $userId = (string)($user['id'] ?? '');
        if ($collectionSlug === '' || $userId === '') return null;
        if (!$this->collectionExists($collectionSlug)) return null;

        $existing = $this->getProfileByOwnerId($collectionSlug, $userId);
        if ($existing) return $existing;

        $name = (string)($user['name'] ?? $user['username'] ?? '');
        $email = (string)($user['email'] ?? '');

        $entryId = 'profile_' . substr(sha1($userId), 0, 12);
        $slug = $this->slugify($name !== '' ? $name : $userId);

        // Determine entry status based on user status/approved and auto-approve setting
        $userStatus = $user['status'] ?? 'pending';
        $userApproved = $user['approved'] ?? false;
        $autoApprove = function_exists('get_plugin_setting')
            ? get_plugin_setting('user_management', 'auto_approve_users', false)
            : false;
        
        // Map user status to entry status
        $entryStatus = 'pending';
        if ($userApproved && $userStatus === 'active') {
            $entryStatus = 'published';
        } elseif ($userStatus === 'inactive') {
            $entryStatus = 'unpublished';
        } else {
            $entryStatus = 'pending';
        }
        
        // If auto-approve is enabled, always publish
        if ($autoApprove) {
            $entryStatus = 'published';
        }

        $entry = [
            'id' => $entryId,
            'slug' => $slug,
            'owner' => $userId,
            'title' => $name !== '' ? $name : $email,
            'name' => $name !== '' ? $name : $email,
            'bio' => '',
            'avatar' => null,
            'status' => $entryStatus,
            'created_at' => date('c'),
            'updated_at' => date('c')
        ];

        $ok = $this->storage->write("collections/{$collectionSlug}/entries/{$entryId}.json", $entry);
        return $ok ? $entry : null;
    }

    public function deleteProfileForUser(string $collectionSlug, string $userId): bool {
        $profile = $this->getProfileByOwnerId($collectionSlug, $userId);
        if ($profile === null) {
            return false;
        }
        $id = (string)($profile['id'] ?? '');
        if ($id === '') {
            return false;
        }

        return (bool) $this->storage->delete("collections/{$collectionSlug}/entries/{$id}.json");
    }

    public function saveProfile(string $collectionSlug, array $profile): bool {
        $id = (string)($profile['id'] ?? '');
        if ($collectionSlug === '' || $id === '') return false;
        if (!$this->collectionExists($collectionSlug)) return false;

        $profile['updated_at'] = date('c');
        return (bool)$this->storage->write("collections/{$collectionSlug}/entries/{$id}.json", $profile);
    }

    private function slugify(string $s): string {
        $s = trim(mb_strtolower($s));
        $s = preg_replace('/[^a-z0-9]+/u', '-', $s);
        $s = trim($s, '-');
        if ($s === '') $s = 'profile';
        return substr($s, 0, 80);
    }
}
