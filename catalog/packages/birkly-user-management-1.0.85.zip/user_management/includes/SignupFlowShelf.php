<?php
/**
 * Lobby shelf for signup flows (P74-M3).
 */

declare(strict_types=1);

require_once __DIR__ . '/SignupFlowEngine.php';

class SignupFlowShelf
{
    private SignupFlowEngine $engine;

    public function __construct(?SignupFlowEngine $engine = null)
    {
        $this->engine = $engine ?? new SignupFlowEngine();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listFlows(bool $enabledOnly = false): array
    {
        return $this->engine->listFlows($enabledOnly);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getFlow(string $flowId): ?array
    {
        return $this->engine->getFlow($flowId);
    }

    /**
     * @param array<string, mixed> $payload
     */
    public function runStep(string $flowId, string $stepId, array $payload = []): array
    {
        $sessionId = trim((string) ($payload['session_id'] ?? ''));
        if ($sessionId === '') {
            $start = $this->engine->start($flowId, $payload);
            if (!($start['ok'] ?? false)) {
                return $start;
            }
            $sessionId = (string) ($start['session_id'] ?? '');
        }

        return $this->engine->runStep($sessionId, $stepId, $payload);
    }

    /**
     * @param array<string, mixed> $payload
     */
    public function onCommerceEvent(string $event, array $payload): array
    {
        return $this->engine->onCommerceEvent($event, $payload);
    }
}
