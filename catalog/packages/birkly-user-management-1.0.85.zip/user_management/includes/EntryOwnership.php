<?php
/**
 * Entry ownership helper — wraps core resolver when available, legacy fallback otherwise.
 */

declare(strict_types=1);

class EntryOwnership
{
    /**
     * Resolve the owning user id for an entry.
     *
     * @param array<string, mixed> $entry
     */
    public static function getEntryOwnerId(array $entry, ?string $collectionSlug = null): ?string
    {
        if (function_exists('birkly_get_entry_owner_id')) {
            $ownerId = birkly_get_entry_owner_id($entry, $collectionSlug);
            if (is_string($ownerId) && trim($ownerId) !== '') {
                return trim($ownerId);
            }
            if (is_int($ownerId) || is_float($ownerId)) {
                return (string) $ownerId;
            }
        }

        foreach (['owner', 'author_id', 'author_user_id', 'user_id'] as $key) {
            if (!array_key_exists($key, $entry)) {
                continue;
            }
            $value = $entry[$key];
            if (is_string($value) && trim($value) !== '') {
                return trim($value);
            }
            if (is_int($value) || is_float($value)) {
                return (string) $value;
            }
        }

        foreach ($entry as $value) {
            if (!is_array($value)) {
                continue;
            }
            $legacyId = trim((string) ($value['legacy_user_id'] ?? ''));
            if ($legacyId !== '') {
                return $legacyId;
            }
        }

        return null;
    }
}
