<?php
/**
 * Migrate legacy UserStorage users + club profiles → member entries (P77-M8).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';
require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/MemberAccountCodec.php';
require_once __DIR__ . '/MemberLegacyMap.php';
require_once __DIR__ . '/UserMemberIndexer.php';
require_once __DIR__ . '/UserCollectionResolver.php';
require_once __DIR__ . '/UserFieldtypeProfileStore.php';

class MemberMigrateService
{
    private UserStorage $storage;
    private MemberLegacyMap $legacyMap;
    private UserMemberIndexer $indexer;
    private UserCollectionResolver $resolver;

    public function __construct(
        ?UserStorage $storage = null,
        ?MemberLegacyMap $legacyMap = null,
        ?UserMemberIndexer $indexer = null,
        ?UserCollectionResolver $resolver = null
    ) {
        $this->storage = $storage ?? new UserStorage();
        $this->legacyMap = $legacyMap ?? new MemberLegacyMap($this->storage);
        $this->indexer = $indexer ?? new UserMemberIndexer();
        $this->resolver = $resolver ?? new UserCollectionResolver();
    }

    /**
     * @param array<string, mixed> $options
     * @return array<string, int|list<string>>
     */
    public function migrate(array $options = []): array
    {
        $collection = trim((string) ($options['collection'] ?? 'club-profiles'));
        $dryRun = !empty($options['dry_run']);
        $typeKey = trim((string) ($options['type_key'] ?? 'user_account_club'));
        if ($typeKey === '') {
            $typeKey = 'user_account_club';
        }

        $result = [
            'users_scanned' => 0,
            'entries_created' => 0,
            'entries_updated' => 0,
            'skipped' => 0,
            'indexed' => 0,
            'errors' => [],
        ];

        if ($collection === '') {
            $result['errors'][] = 'Collection slug is required';

            return $result;
        }

        if (!$dryRun) {
            $this->ensureAccountFieldOnSchema($collection, $typeKey);
        }

        require_once user_management_cms_path('api/storage.php');
        $cmsStorage = new Storage(user_management_cms_path('content'));
        $collectionDir = $this->resolveCollectionDir($cmsStorage, $collection);
        if ($collectionDir === null) {
            $result['errors'][] = 'Collection not found: ' . $collection;

            return $result;
        }

        $accountField = $this->resolver->getAccountFieldOnSchema($collection);
        $accountFieldName = (string) ($accountField['name'] ?? 'account');
        $profilesByUser = $this->loadProfilesByUserId($cmsStorage, $collectionDir);

        foreach ($this->storage->listUsers(['deleted' => false]) as $user) {
            if (!is_array($user)) {
                continue;
            }
            $result['users_scanned']++;

            $userId = trim((string) ($user['id'] ?? ''));
            $email = strtolower(trim((string) ($user['email'] ?? '')));
            if ($userId === '' || $email === '') {
                $result['skipped']++;
                continue;
            }

            $entry = $profilesByUser[$userId] ?? null;
            $isNew = !is_array($entry);
            if ($isNew) {
                $entry = $this->buildProfileEntry($user, $collection);
                $profilesByUser[$userId] = $entry;
            }

            $existingAccount = MemberAccountCodec::normalize($entry[$accountFieldName] ?? []);
            $memberId = trim((string) ($existingAccount['member_id'] ?? ''));
            if ($memberId === '') {
                $memberId = MemberAccountCodec::generateMemberId();
            }

            $account = $this->buildAccountFromUser($user, $existingAccount, $memberId, $typeKey);
            $entry[$accountFieldName] = $account;
            $entry['user_id'] = $userId;
            unset($entry['owner']);
            $entry['status'] = $entry['status'] ?? 'published';
            $entry['updated_at'] = date('c');

            $path = "collections/{$collectionDir}/entries/" . ($entry['id'] ?? '') . '.json';
            if ($path === "collections/{$collectionDir}/entries/.json") {
                $result['errors'][] = 'Missing entry id for user ' . $userId;
                continue;
            }

            if ($dryRun) {
                if ($isNew) {
                    $result['entries_created']++;
                } else {
                    $result['entries_updated']++;
                }
                continue;
            }

            if (!$cmsStorage->write($path, $entry)) {
                $result['errors'][] = 'Write failed for user ' . $userId;
                continue;
            }

            $this->legacyMap->link($userId, $memberId, $collection, (string) ($entry['id'] ?? ''));
            if ($this->indexer->indexEntry($entry, $collection)) {
                $result['indexed']++;
            }

            if ($isNew) {
                $result['entries_created']++;
            } else {
                $result['entries_updated']++;
            }
        }

        if (!$dryRun) {
            $runtime = $this->storage->readMetadata('plugin_runtime');
            if (!is_array($runtime)) {
                $runtime = [];
            }
            $runtime['p77_members_migrated_at'] = date('c');
            $runtime['p77_members_collection'] = $collection;
            $this->storage->saveMetadata('plugin_runtime', $runtime);

            $map = $this->legacyMap->load();
            $map['migrated_at'] = date('c');
            $this->legacyMap->save($map);

            if (function_exists('set_plugin_setting')) {
                set_plugin_setting('user_management', 'member_entry_auth', true);
            }
        }

        return $result;
    }

    public function ensureAccountFieldOnSchema(string $collectionSlug, string $typeKey = 'user_account_club'): bool
    {
        $schemaPath = user_management_cms_path('content/collections/' . $collectionSlug . '/schema.json');
        $collectionPath = user_management_cms_path('content/collections/' . $collectionSlug . '/collection.json');

        $config = null;
        if (is_file($schemaPath)) {
            $config = json_decode((string) file_get_contents($schemaPath), true);
        } elseif (is_file($collectionPath)) {
            $config = json_decode((string) file_get_contents($collectionPath), true);
        }

        if (!is_array($config)) {
            return false;
        }

        $fields = is_array($config['fields'] ?? null) ? $config['fields'] : [];
        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }
            $type = (string) ($field['type'] ?? '');
            if (MemberAccountCodec::isAccountFieldType($type)) {
                return true;
            }
        }

        $fields[] = [
            'name' => 'account',
            'type' => $typeKey,
            'label' => 'Site user account',
            'required' => true,
            'public_visible' => false,
        ];
        $config['fields'] = $fields;
        $config['updated_at'] = date('c');

        $target = is_file($schemaPath) ? $schemaPath : $collectionPath;

        return file_put_contents(
            $target,
            json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n"
        ) !== false;
    }

    /**
     * @param array<string, mixed> $user
     * @param array<string, mixed> $existing
     * @return array<string, mixed>
     */
    private function buildAccountFromUser(array $user, array $existing, string $memberId, string $typeKey): array
    {
        $userId = (string) ($user['id'] ?? '');
        $email = strtolower(trim((string) ($user['email'] ?? '')));
        $name = trim((string) ($user['name'] ?? $user['username'] ?? ''));

        $profile = (new UserFieldtypeProfileStore())->getProfileByTypeKey($typeKey);
        $settings = UserFieldtypeProfileStore::normalizeSettings(
            is_array($profile['settings'] ?? null) ? $profile['settings'] : [],
            user_management_commerce_plugin_active()
        );

        $accountInput = [
            'member_id' => $memberId,
            'legacy_user_id' => $userId,
            'email' => $email,
            'password' => (string) ($user['password_hash'] ?? $existing['password'] ?? ''),
            'name' => $name,
            'tier_id' => (string) ($user['tier'] ?? $existing['tier_id'] ?? 'all'),
            'status' => (string) ($user['status'] ?? $existing['status'] ?? 'active'),
            'verified' => !empty($user['verified']) || !empty($existing['verified']),
            'fieldtype_profile_id' => (string) ($profile['id'] ?? 'default'),
            'custom' => is_array($existing['custom'] ?? null) ? $existing['custom'] : [],
        ];

        $stored = MemberAccountCodec::processForStorage($accountInput, $existing, $settings, $typeKey);
        $stored['legacy_user_id'] = $userId;

        if (MemberAccountCodec::isPasswordHash((string) ($user['password_hash'] ?? ''))) {
            $stored['password'] = (string) $user['password_hash'];
        }

        return $stored;
    }

    /**
     * @param array<string, mixed> $user
     * @return array<string, mixed>
     */
    private function buildProfileEntry(array $user, string $collection): array
    {
        $userId = (string) ($user['id'] ?? '');
        $title = trim((string) ($user['name'] ?? $user['username'] ?? $user['email'] ?? 'Member'));
        $now = date('c');

        return [
            'id' => 'club_profile_' . substr(sha1($userId), 0, 12),
            'slug' => $this->slugify($title) . '-' . substr(sha1($userId), 0, 6),
            'title' => $title,
            'bio' => '',
            'description' => '',
            'status' => 'published',
            'created_at' => $now,
            'updated_at' => $now,
        ];
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function loadProfilesByUserId(Storage $storage, string $collectionDir): array
    {
        $byUser = [];
        $entriesDir = user_management_cms_path('content/collections/' . $collectionDir . '/entries');
        if (!is_dir($entriesDir)) {
            return $byUser;
        }

        foreach (glob($entriesDir . '/*.json') ?: [] as $file) {
            $entry = json_decode((string) file_get_contents($file), true);
            if (!is_array($entry)) {
                continue;
            }
            $userId = trim((string) ($entry['user_id'] ?? $entry['owner'] ?? ''));
            if ($userId === '' && isset($entry['account']) && is_array($entry['account'])) {
                $userId = trim((string) ($entry['account']['legacy_user_id'] ?? ''));
            }
            if ($userId === '') {
                continue;
            }
            $byUser[$userId] = $entry;
        }

        return $byUser;
    }

    private function resolveCollectionDir(Storage $storage, string $collectionSlug): ?string
    {
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (is_array($meta) && (string) ($meta['slug'] ?? '') === $collectionSlug) {
                return (string) $dir;
            }
        }

        if (is_dir(user_management_cms_path('content/collections/' . $collectionSlug))) {
            return $collectionSlug;
        }

        return null;
    }

    private function slugify(string $value): string
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
        $value = trim($value, '-');

        return $value !== '' ? $value : 'member';
    }
}

/**
 * @param array<string, mixed> $options
 * @return array<string, int|list<string>>
 */
function user_management_migrate_p77_members(array $options = []): array
{
    return (new MemberMigrateService())->migrate($options);
}
