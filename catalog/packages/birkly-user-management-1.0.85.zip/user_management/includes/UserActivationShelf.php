<?php
/**
 * Lobby shelf for account activation (P74-M1).
 *
 * Consumer plugins (e.g. Commerce) call get_plugin_service('user_activation_shelf')
 * instead of loading AccountActivation.php directly.
 */

declare(strict_types=1);

require_once __DIR__ . '/AccountActivation.php';

class UserActivationShelf
{
    private AccountActivation $activation;

    public function __construct(?AccountActivation $activation = null)
    {
        $this->activation = $activation ?? new AccountActivation();
    }

    public function isEntitled(string $email, array $context = []): bool
    {
        return $this->activation->isEntitled($email, $context);
    }

    /**
     * @return array{success: bool, message?: string}
     */
    public function sendActivation(string $email, array $context = []): array
    {
        return $this->activation->sendActivationEmail($email, $context);
    }

    /**
     * @return array{success: bool, message?: string, email?: string, tier_id?: string}
     */
    public function verifyToken(string $token): array
    {
        return $this->activation->verifyToken($token);
    }

    /**
     * @param array<string, mixed> $fields
     * @return array{success: bool, message?: string, user_id?: string, tier_id?: string}
     */
    public function completeActivation(string $token, string $password, ?string $name = null, array $fields = []): array
    {
        return $this->activation->completeActivation($token, $password, $name, $fields);
    }
}
