<?php
/**
 * User notifications — in-app inbox + optional email delivery (P81-M5/M7).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';
require_once __DIR__ . '/ClubProfileService.php';
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/UserGraphService.php';
require_once __DIR__ . '/EntryOwnership.php';
require_once __DIR__ . '/UserEmailService.php';
require_once __DIR__ . '/UserPluginCollectionConfig.php';

class UserNotificationService
{
    public const TYPE_BIRKLY_POST = 'birkly_post';
    public const TYPE_DEAL = 'deal';
    public const TYPE_COMMENT = 'comment';
    public const TYPE_REACTION = 'reaction';
    public const TYPE_FOLLOWING_POST = 'following_post';
    public const TYPE_MENTION = 'mention';

    private const MAX_NOTIFICATIONS = 150;

    private ClubProfileService $profiles;

    public function __construct(?ClubProfileService $profiles = null)
    {
        $this->profiles = $profiles ?? new ClubProfileService();
    }

    /**
     * @return array<string, bool>
     */
    public static function defaultPreferences(): array
    {
        return [
            'notify_birkly_posts' => true,
            'notify_deals' => true,
            'notify_comments' => true,
            'notify_reactions' => true,
            'notify_following_posts' => true,
            'notify_mentions' => true,
            'email_enabled' => false,
            'email_birkly_posts' => false,
            'email_deals' => false,
            'email_comments' => false,
            'email_reactions' => false,
            'email_following_posts' => false,
            'email_mentions' => false,
            'digest_enabled' => false,
            'digest_frequency' => 'weekly',
            'digest_last_sent_at' => '',
        ];
    }

    /**
     * @param array<string, mixed>|null $profile
     *
     * @return array<string, bool|string>
     */
    public function preferencesFromProfile(?array $profile): array
    {
        $defaults = self::defaultPreferences();
        if (!is_array($profile)) {
            return $defaults;
        }

        $raw = $profile['notification_prefs'] ?? null;
        if (is_string($raw) && trim($raw) !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                foreach ($defaults as $key => $value) {
                    if (!array_key_exists($key, $decoded)) {
                        continue;
                    }
                    $defaults[$key] = self::normalizePreferenceValue($key, $decoded[$key], $value);
                }

                return $defaults;
            }
        }

        foreach ($defaults as $key => $defaultValue) {
            if (array_key_exists($key, $profile)) {
                $defaults[$key] = self::normalizePreferenceValue($key, $profile[$key], $defaultValue);
            }
        }

        return $defaults;
    }

    /**
     * @param array<string, bool|string> $prefs
     *
     * @return array<string, bool|string>
     */
    public function savePreferencesForUser(string $userId, array $prefs): array
    {
        $merged = $this->preferencesFromProfile($this->profiles->getProfileByUserId($userId));
        foreach (self::defaultPreferences() as $key => $default) {
            if (array_key_exists($key, $prefs)) {
                $merged[$key] = self::normalizePreferenceValue($key, $prefs[$key], $default);
            }
        }

        $existing = $this->profiles->getProfileByUserId($userId);
        $title = trim((string) ($existing['title'] ?? 'Club member'));
        $this->profiles->saveProfileForUser($userId, array_merge(
            is_array($existing) ? [
                'title' => $title,
                'bio' => (string) ($existing['bio'] ?? ''),
                'description' => (string) ($existing['description'] ?? ''),
                'website' => (string) ($existing['website'] ?? ''),
                'links' => (string) ($existing['links'] ?? ''),
            ] : ['title' => $title],
            ['notification_prefs' => json_encode($merged, JSON_UNESCAPED_UNICODE)]
        ));

        return $merged;
    }

    public function wantsInApp(string $userId, string $type): bool
    {
        $prefs = $this->preferencesFromProfile($this->profiles->getProfileByUserId($userId));

        return match ($type) {
            self::TYPE_BIRKLY_POST => $prefs['notify_birkly_posts'],
            self::TYPE_DEAL => $prefs['notify_deals'],
            self::TYPE_COMMENT => $prefs['notify_comments'],
            self::TYPE_REACTION => $prefs['notify_reactions'],
            self::TYPE_FOLLOWING_POST => $prefs['notify_following_posts'],
            self::TYPE_MENTION => $prefs['notify_mentions'],
            default => false,
        };
    }

    public function wantsEmail(string $userId, string $type): bool
    {
        $prefs = $this->preferencesFromProfile($this->profiles->getProfileByUserId($userId));
        if (!$prefs['email_enabled']) {
            return false;
        }

        return match ($type) {
            self::TYPE_BIRKLY_POST => $prefs['email_birkly_posts'],
            self::TYPE_DEAL => $prefs['email_deals'],
            self::TYPE_COMMENT => $prefs['email_comments'],
            self::TYPE_REACTION => $prefs['email_reactions'],
            self::TYPE_FOLLOWING_POST => $prefs['email_following_posts'],
            self::TYPE_MENTION => $prefs['email_mentions'],
            default => false,
        };
    }

    /**
     * @param array<string, mixed> $payload
     */
    public function notify(string $recipientUserId, string $type, array $payload): ?array
    {
        $recipientUserId = trim($recipientUserId);
        if ($recipientUserId === '') {
            return null;
        }

        $actorUserId = trim((string) ($payload['actor_user_id'] ?? ''));
        if ($actorUserId !== '' && $actorUserId === $recipientUserId) {
            return null;
        }

        if ($actorUserId !== '') {
            $graph = new UserGraphService();
            if ($graph->isMuted($recipientUserId, $actorUserId)) {
                return null;
            }
        }

        $sendInApp = $this->wantsInApp($recipientUserId, $type);
        $sendEmail = $this->wantsEmail($recipientUserId, $type);
        if (!$sendInApp && !$sendEmail) {
            return null;
        }

        $notification = null;
        if ($sendInApp) {
            $notification = $this->appendNotification($recipientUserId, [
                'id' => 'user_notif_' . bin2hex(random_bytes(8)),
                'type' => $type,
                'actor_user_id' => $actorUserId,
                'title' => trim((string) ($payload['title'] ?? 'Update')),
                'body' => trim((string) ($payload['body'] ?? '')),
                'link' => trim((string) ($payload['link'] ?? '/')),
                'target_collection' => trim((string) ($payload['target_collection'] ?? '')),
                'target_entry_id' => trim((string) ($payload['target_entry_id'] ?? '')),
                'target_sub_id' => trim((string) ($payload['target_sub_id'] ?? '')),
                'created_at' => date('c'),
                'read_at' => null,
            ]);
        }

        if ($sendEmail) {
            $this->sendEmailNotification($recipientUserId, $type, $payload);
        }

        return $notification;
    }

    /**
     * @param list<string> $recipientUserIds
     * @param array<string, mixed> $payload
     */
    public function notifyMany(array $recipientUserIds, string $type, array $payload): int
    {
        $count = 0;
        foreach (array_unique(array_filter(array_map('strval', $recipientUserIds))) as $userId) {
            if ($this->notify($userId, $type, $payload) !== null) {
                $count++;
            }
        }

        return $count;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listForUser(string $userId, int $limit = 40): array
    {
        $store = $this->loadStore($userId);
        $items = $store['notifications'] ?? [];
        if (!is_array($items)) {
            return [];
        }

        usort($items, static function ($a, $b) {
            return strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? ''));
        });

        return array_slice($items, 0, max(1, min(100, $limit)));
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listUnreadSince(string $userId, ?string $sinceIso, int $limit = 20): array
    {
        $sinceTs = $sinceIso ? strtotime($sinceIso) : false;
        $items = [];
        foreach ($this->listForUser($userId, 100) as $row) {
            if (!empty($row['read_at'])) {
                continue;
            }
            if ($sinceTs !== false) {
                $createdTs = strtotime((string) ($row['created_at'] ?? ''));
                if ($createdTs !== false && $createdTs <= $sinceTs) {
                    continue;
                }
            }
            $items[] = $row;
            if (count($items) >= max(1, min(100, $limit))) {
                break;
            }
        }

        return $items;
    }

    public function unreadCount(string $userId): int
    {
        $count = 0;
        foreach ($this->listForUser($userId, 100) as $row) {
            if (empty($row['read_at'])) {
                $count++;
            }
        }

        return $count;
    }

    public function markRead(string $userId, string $notificationId): bool
    {
        $store = $this->loadStore($userId);
        $changed = false;
        foreach ($store['notifications'] as &$row) {
            if (($row['id'] ?? '') === $notificationId && empty($row['read_at'])) {
                $row['read_at'] = date('c');
                $changed = true;
            }
        }
        unset($row);

        return $changed ? $this->saveStore($userId, $store) : false;
    }

    public function markAllRead(string $userId): int
    {
        $store = $this->loadStore($userId);
        $marked = 0;
        $now = date('c');
        foreach ($store['notifications'] as &$row) {
            if (empty($row['read_at'])) {
                $row['read_at'] = $now;
                $marked++;
            }
        }
        unset($row);
        $this->saveStore($userId, $store);

        return $marked;
    }

    /**
     * @return list<string>
     */
    public function listClubMemberUserIds(): array
    {
        $ids = [];
        $service = new UserService(new UserStorage());
        foreach ($service->listUsers(['status' => 'active'], 1000, 0) as $user) {
            if (!is_array($user) || !empty($user['deleted'])) {
                continue;
            }
            if ((string) ($user['tier'] ?? '') !== 'club') {
                continue;
            }
            $id = trim((string) ($user['id'] ?? ''));
            if ($id !== '') {
                $ids[] = $id;
            }
        }

        return $ids;
    }

    public function actorDisplayName(string $actorUserId, string $fallback = 'Someone'): string
    {
        $actorUserId = trim($actorUserId);
        if ($actorUserId === ClubProfileService::SYSTEM_USER_ID) {
            return 'Birkly';
        }
        $profile = $this->profiles->getProfileByUserId($actorUserId);
        if (is_array($profile)) {
            $title = trim((string) ($profile['title'] ?? ''));
            if ($title !== '') {
                return $title;
            }
        }
        if ($actorUserId !== '') {
            $user = (new UserService(new UserStorage()))->getUser($actorUserId);
            if (is_array($user)) {
                $name = trim((string) ($user['name'] ?? $user['email'] ?? ''));
                if ($name !== '') {
                    return $name;
                }
            }
        }

        return $fallback;
    }

    /**
     * @param array<string, mixed> $entry
     */
    public function handlePostCreated(array $entry, string $collectionSlug): void
    {
        if (($entry['status'] ?? 'published') !== 'published') {
            return;
        }
        if (!UserPluginCollectionConfig::isUgcCollection($collectionSlug)) {
            return;
        }
        if (
            !UserPluginCollectionConfig::notificationsEnabled($collectionSlug, self::TYPE_FOLLOWING_POST)
            && !UserPluginCollectionConfig::notificationsEnabled($collectionSlug, self::TYPE_BIRKLY_POST)
        ) {
            return;
        }

        $authorId = EntryOwnership::getEntryOwnerId($entry, $collectionSlug) ?? '';
        $postTitle = trim((string) ($entry['title'] ?? 'New post'));
        $postId = trim((string) ($entry['id'] ?? ''));
        $link = trim((string) (UserPluginCollectionConfig::forCollection($collectionSlug)['notification_link'] ?? '/'));
        $actorName = $this->actorDisplayName($authorId);

        $payload = [
            'actor_user_id' => $authorId,
            'title' => $actorName . ' posted',
            'body' => $postTitle,
            'link' => $link,
            'target_collection' => $collectionSlug,
            'target_entry_id' => $postId,
        ];

        if ($authorId === ClubProfileService::SYSTEM_USER_ID) {
            if (!UserPluginCollectionConfig::notificationsEnabled($collectionSlug, self::TYPE_BIRKLY_POST)) {
                return;
            }
            $recipients = array_filter(
                $this->listClubMemberUserIds(),
                fn (string $id) => $id !== $authorId
            );
            $this->notifyMany($recipients, self::TYPE_BIRKLY_POST, array_merge($payload, [
                'title' => 'New post from Birkly',
                'body' => $postTitle,
            ]));

            return;
        }

        if ($authorId === '') {
            return;
        }

        if (!UserPluginCollectionConfig::notificationsEnabled($collectionSlug, self::TYPE_FOLLOWING_POST)) {
            return;
        }

        $graph = new UserGraphService();
        $followers = $graph->listFollowers($authorId);
        $this->notifyMany($followers, self::TYPE_FOLLOWING_POST, $payload);
    }

    /** @deprecated Use handlePostCreated() */
    public function handleClubPostCreated(array $entry, string $collectionSlug): void
    {
        $this->handlePostCreated($entry, $collectionSlug);
    }

    /**
     * @param array<string, mixed> $entry
     */
    public function handleDealCreated(array $entry, string $collectionSlug): void
    {
        if (!UserPluginCollectionConfig::notificationsEnabled($collectionSlug, self::TYPE_DEAL)) {
            return;
        }
        if (($entry['status'] ?? 'published') !== 'published') {
            return;
        }

        $dealTitle = trim((string) ($entry['title'] ?? $entry['discount'] ?? 'New deal'));
        $link = trim((string) (UserPluginCollectionConfig::forCollection($collectionSlug)['notification_link'] ?? '/'));
        $this->notifyMany($this->listClubMemberUserIds(), self::TYPE_DEAL, [
            'actor_user_id' => ClubProfileService::SYSTEM_USER_ID,
            'title' => 'New member deal',
            'body' => $dealTitle,
            'link' => $link,
            'target_collection' => $collectionSlug,
            'target_entry_id' => trim((string) ($entry['id'] ?? '')),
        ]);
    }

    /**
     * @param array<string, mixed> $subEntry
     */
    public function handleSubEntryCreated(
        string $subEntryId,
        array $subEntry,
        string $parentCollection,
        string $parentEntryId,
        string $subCollection
    ): void {
        if ($subCollection === 'comments') {
            if (!UserPluginCollectionConfig::notificationsEnabled($parentCollection, self::TYPE_COMMENT)) {
                return;
            }
        } elseif ($subCollection === 'likes') {
            if (!UserPluginCollectionConfig::notificationsEnabled($parentCollection, self::TYPE_REACTION)) {
                return;
            }
        } else {
            return;
        }

        $parent = $this->loadEntry($parentCollection, $parentEntryId);
        if ($parent === null) {
            return;
        }

        $ownerId = EntryOwnership::getEntryOwnerId($parent, $parentCollection) ?? '';
        if ($ownerId === '') {
            return;
        }

        $actorId = EntryOwnership::getEntryOwnerId($subEntry, $parentCollection) ?? '';
        $actorName = $this->actorDisplayName($actorId);
        $postTitle = trim((string) ($parent['title'] ?? 'your post'));
        $link = trim((string) (UserPluginCollectionConfig::forCollection($parentCollection)['notification_link'] ?? '/'));

        if ($subCollection === 'comments') {
            $snippet = trim((string) ($subEntry['body'] ?? ''));
            if (strlen($snippet) > 120) {
                $snippet = substr($snippet, 0, 117) . '…';
            }
            $this->notify($ownerId, self::TYPE_COMMENT, [
                'actor_user_id' => $actorId,
                'title' => $actorName . ' commented on your post',
                'body' => $snippet !== '' ? $snippet : $postTitle,
                'link' => $link,
                'target_collection' => $parentCollection,
                'target_entry_id' => $parentEntryId,
                'target_sub_id' => $subEntryId,
            ]);

            return;
        }

        $this->notify($ownerId, self::TYPE_REACTION, [
            'actor_user_id' => $actorId,
            'title' => $actorName . ' reacted to your post',
            'body' => $postTitle,
            'link' => $link,
            'target_collection' => $parentCollection,
            'target_entry_id' => $parentEntryId,
            'target_sub_id' => $subEntryId,
        ]);
    }

    /**
     * @param array<string, mixed> $notification
     *
     * @return array<string, mixed>
     */
    private function appendNotification(string $userId, array $notification): array
    {
        $store = $this->loadStore($userId);
        $items = is_array($store['notifications'] ?? null) ? $store['notifications'] : [];
        array_unshift($items, $notification);
        if (count($items) > self::MAX_NOTIFICATIONS) {
            $items = array_slice($items, 0, self::MAX_NOTIFICATIONS);
        }
        $store['notifications'] = $items;
        $this->saveStore($userId, $store);

        return $notification;
    }

    /**
     * @return array{notifications: list<array<string, mixed>>}
     */
    private function loadStore(string $userId): array
    {
        foreach ($this->storePaths($userId) as $path) {
            if (!is_file($path)) {
                continue;
            }
            $raw = file_get_contents($path);
            $data = is_string($raw) ? json_decode($raw, true) : null;
            if (is_array($data) && is_array($data['notifications'] ?? null)) {
                return $data;
            }
        }

        return ['notifications' => []];
    }

    /**
     * @param array{notifications: list<array<string, mixed>>} $store
     */
    private function saveStore(string $userId, array $store): bool
    {
        $path = $this->writeStorePath($userId);
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        return file_put_contents(
            $path,
            json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        ) !== false;
    }

    /**
     * Read legacy club_notifications/ then user_notifications/ (new writes go to user_notifications/).
     *
     * @return list<string>
     */
    private function storePaths(string $userId): array
    {
        $safe = preg_replace('/[^a-zA-Z0-9_-]/', '', $userId) ?: 'unknown';
        $base = rtrim(user_management_data_dir(), '/');

        return [
            $base . '/user_notifications/' . $safe . '.json',
            $base . '/club_notifications/' . $safe . '.json',
        ];
    }

    private function writeStorePath(string $userId): string
    {
        $safe = preg_replace('/[^a-zA-Z0-9_-]/', '', $userId) ?: 'unknown';

        return rtrim(user_management_data_dir(), '/') . '/user_notifications/' . $safe . '.json';
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function sendEmailNotification(string $userId, string $type, array $payload): void
    {
        $user = (new UserService(new UserStorage()))->getUser($userId);
        if (!is_array($user)) {
            return;
        }
        $email = trim((string) ($user['email'] ?? ''));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return;
        }

        $emailService = new UserEmailService();
        $siteUrl = '';
        if (function_exists('birkly_site_public_url')) {
            $siteUrl = rtrim((string) birkly_site_public_url(), '/');
        }
        $link = trim((string) ($payload['link'] ?? '/'));
        if ($siteUrl !== '' && str_starts_with($link, '/')) {
            $link = $siteUrl . $link;
        }

        $emailService->send('club_notification', $email, [
            'member_name' => trim((string) ($user['name'] ?? 'Member')),
            'notification_title' => (string) ($payload['title'] ?? 'Update'),
            'notification_body' => (string) ($payload['body'] ?? ''),
            'notification_link' => $link,
            'notification_type' => $type,
        ]);
    }

    /**
     * @return array<string, mixed>|null
     */
    private function loadEntry(string $collectionSlug, string $entryId): ?array
    {
        $entryId = trim($entryId);
        if ($entryId === '') {
            return null;
        }

        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== $collectionSlug) {
                continue;
            }
            $entry = $storage->read("collections/{$dir}/entries/{$entryId}.json");
            if (is_array($entry)) {
                return $entry;
            }
        }

        return null;
    }

    private static function toBool(mixed $value, bool $default): bool
    {
        if ($value === null) {
            return $default;
        }
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return (int) $value !== 0;
        }
        $normalized = strtolower(trim((string) $value));

        return in_array($normalized, ['1', 'true', 'yes', 'on'], true);
    }

    /**
     * @return bool|string
     */
    private static function normalizePreferenceValue(string $key, mixed $value, mixed $default): bool|string
    {
        if ($key === 'digest_frequency') {
            $freq = (string) $value;

            return in_array($freq, ['daily', 'weekly'], true) ? $freq : 'weekly';
        }
        if ($key === 'digest_last_sent_at') {
            return trim((string) $value);
        }

        return self::toBool($value, is_bool($default) ? $default : false);
    }
}

if (!class_exists('ClubNotificationService', false)) {
    class_alias(UserNotificationService::class, 'ClubNotificationService');
}
