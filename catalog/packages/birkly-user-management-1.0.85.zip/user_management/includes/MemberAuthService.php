<?php
/**
 * Dual-read authentication — legacy UserStorage or member entry (P77-M8).
 */

declare(strict_types=1);

require_once __DIR__ . '/MemberLegacyMap.php';
require_once __DIR__ . '/MemberAccountCodec.php';
require_once __DIR__ . '/UserMemberIndexer.php';
require_once __DIR__ . '/UserCollectionResolver.php';
require_once __DIR__ . '/UserService.php';

class MemberAuthService
{
    private UserMemberIndexer $indexer;
    private MemberLegacyMap $legacyMap;
    private UserCollectionResolver $resolver;

    public function __construct(
        ?UserMemberIndexer $indexer = null,
        ?MemberLegacyMap $legacyMap = null,
        ?UserCollectionResolver $resolver = null
    ) {
        $this->indexer = $indexer ?? new UserMemberIndexer();
        $this->legacyMap = $legacyMap ?? new MemberLegacyMap();
        $this->resolver = $resolver ?? new UserCollectionResolver();
    }

    public function isEnabled(): bool
    {
        return user_management_member_entry_auth_enabled();
    }

    /**
     * Authenticate by email/password against a member entry account field.
     *
     * @return array<string, mixed>|null Session-shaped user payload
     */
    public function authenticate(string $email, string $password): ?array
    {
        if (!$this->isEnabled()) {
            return null;
        }

        $email = strtolower(trim($email));
        if ($email === '' || $password === '') {
            return null;
        }

        $context = $this->findMemberContextByEmail($email);
        if ($context === null) {
            return null;
        }

        $account = $context['account'];
        if (!$this->verifyPassword($account, $password)) {
            return null;
        }

        if (($account['status'] ?? 'pending') !== 'active') {
            return null;
        }

        $requiresVerification = false;
        if (function_exists('get_plugin_setting')) {
            $requiresVerification = (bool) get_plugin_setting('user_management', 'require_email_verification', false);
        }
        if ($requiresVerification && empty($account['verified'])) {
            return null;
        }

        $memberId = (string) ($account['member_id'] ?? '');
        $legacyUserId = trim((string) ($account['legacy_user_id'] ?? ''));
        if ($legacyUserId === '') {
            $legacyUserId = (string) ($this->legacyMap->resolveUserIdForMember($memberId) ?? '');
        }

        $sessionId = $legacyUserId !== '' ? $legacyUserId : $memberId;

        return [
            'id' => $sessionId,
            'member_id' => $memberId,
            'legacy_user_id' => $legacyUserId !== '' ? $legacyUserId : null,
            'email' => $email,
            'name' => (string) ($account['name'] ?? ''),
            'tier' => (string) ($account['tier_id'] ?? 'all'),
            'auth_source' => 'member_entry',
            'collection_slug' => (string) ($context['collection_slug'] ?? ''),
            'entry_id' => (string) ($context['entry_id'] ?? ''),
        ];
    }

    /**
     * @param array<string, mixed> $account
     */
    public function verifyPassword(array $account, string $password): bool
    {
        $stored = (string) ($account['password'] ?? '');
        if ($stored === '' || $password === '') {
            return false;
        }

        if (MemberAccountCodec::isPasswordHash($stored)) {
            return password_verify($password, $stored);
        }

        $service = new UserService();

        return $service->verifyPassword($password, $stored);
    }

    /**
     * @return array{collection_slug: string, entry_id: string, account: array<string, mixed>}|null
     */
    public function findMemberContextByEmail(string $email): ?array
    {
        $email = strtolower(trim($email));
        if ($email === '') {
            return null;
        }

        $hash = hash('sha256', $email);
        foreach ($this->indexer->listMembers() as $row) {
            if (!is_array($row) || ($row['email_hash'] ?? '') !== $hash) {
                continue;
            }

            $collectionSlug = (string) ($row['collection_slug'] ?? '');
            $entryId = (string) ($row['entry_id'] ?? '');
            if ($collectionSlug === '' || $entryId === '') {
                continue;
            }

            $entry = $this->loadEntry($collectionSlug, $entryId);
            if ($entry === null) {
                continue;
            }

            $accountField = $this->resolver->getAccountFieldOnSchema($collectionSlug);
            if ($accountField === null) {
                continue;
            }

            $fieldName = (string) ($accountField['name'] ?? 'account');
            $account = MemberAccountCodec::normalize($entry[$fieldName] ?? []);

            return [
                'collection_slug' => $collectionSlug,
                'entry_id' => $entryId,
                'account' => $account,
                'entry' => $entry,
            ];
        }

        return null;
    }

    /** @return array<string, mixed>|null */
    private function loadEntry(string $collectionSlug, string $entryId): ?array
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== $collectionSlug) {
                continue;
            }
            $entry = $storage->read("collections/{$dir}/entries/{$entryId}.json");

            return is_array($entry) ? $entry : null;
        }

        $path = user_management_cms_path('content/collections/' . $collectionSlug . '/entries/' . $entryId . '.json');
        if (is_file($path)) {
            $entry = json_decode((string) file_get_contents($path), true);

            return is_array($entry) ? $entry : null;
        }

        return null;
    }
}
