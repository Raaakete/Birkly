<?php
/**
 * Roadmap feature votes stored as sub-entries on roadmap-features/likes.
 */

declare(strict_types=1);

require_once __DIR__ . '/SubEntryLikeService.php';

class RoadmapVoteService
{
    public const PARENT_COLLECTION = 'roadmap-features';

    private SubEntryLikeService $likes;

    public function __construct()
    {
        $this->likes = new SubEntryLikeService(self::PARENT_COLLECTION);
    }

    /**
     * @return array{liked: bool, count: int}
     */
    public function toggleLike(string $userId, string $featureSlug): array
    {
        return $this->likes->toggleLike($userId, $featureSlug);
    }

    /**
     * @param list<string> $featureSlugs
     *
     * @return array<string, array{count: int, liked: bool}>
     */
    public function countsForUser(string $userId, array $featureSlugs): array
    {
        return $this->likes->countsForUser($userId, $featureSlugs);
    }

    /**
     * @param list<string> $featureSlugs
     *
     * @return array<string, int>
     */
    public function countsPublic(array $featureSlugs): array
    {
        return $this->likes->countsPublic($featureSlugs);
    }

    public function countLikesForSlug(string $featureSlug): int
    {
        return $this->likes->countLikesForSlug($featureSlug);
    }
}
