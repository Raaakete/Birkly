<?php
/**
 * Club social reactions (likes / votes) and member follows.
 */

declare(strict_types=1);

require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/ClubProfileService.php';
require_once __DIR__ . '/SubEntryLikeService.php';

class ClubSocialService
{
    public const DEFAULT_FOLLOW_USER_ID = ClubProfileService::SYSTEM_USER_ID;

    /** @var array<string, string> */
    private const LIKE_PARENT_COLLECTIONS = [
        'post' => 'club-posts',
        'wish' => 'club-wishes',
        'roadmap' => 'roadmap-features',
    ];

    private UserStorage $storage;

    private $graph = null;

    private bool $graphUnavailable = false;

    /** @var array<string, SubEntryLikeService> */
    private array $likeServices = [];

    public function __construct()
    {
        $this->storage = new UserStorage();
    }

    private function graph()
    {
        if ($this->graphUnavailable) {
            throw new RuntimeException('User graph storage unavailable');
        }
        if ($this->graph === null) {
            $storagePath = __DIR__ . '/../../../api/storage.php';
            if (!is_file($storagePath)) {
                $this->graphUnavailable = true;
                throw new RuntimeException('User graph storage unavailable');
            }
            require_once __DIR__ . '/UserGraphService.php';
            $this->graph = new UserGraphService();
        }

        return $this->graph;
    }

    private function likeServiceForType(string $targetType): SubEntryLikeService
    {
        $type = preg_replace('/[^a-z0-9_-]/', '', strtolower(trim($targetType))) ?: 'post';
        $parentCollection = self::LIKE_PARENT_COLLECTIONS[$type] ?? '';
        if ($parentCollection === '') {
            throw new InvalidArgumentException('Unsupported target type');
        }
        if (!isset($this->likeServices[$parentCollection])) {
            $this->likeServices[$parentCollection] = new SubEntryLikeService($parentCollection);
        }

        return $this->likeServices[$parentCollection];
    }

    /**
     * @return array{liked: bool, count: int}
     */
    public function toggleLike(string $userId, string $targetType, string $targetSlug): array
    {
        $userId = trim($userId);
        if ($userId === '') {
            throw new InvalidArgumentException('User id required');
        }

        $targetSlug = trim($targetSlug);
        if ($targetSlug === '') {
            throw new InvalidArgumentException('Target slug required');
        }

        return $this->likeServiceForType($targetType)->toggleLike($userId, $targetSlug);
    }

    /**
     * @param list<string> $targetSlugs
     *
     * @return array<string, array{count: int, liked: bool}>
     */
    public function countsForUser(string $userId, string $targetType, array $targetSlugs): array
    {
        return $this->likeServiceForType($targetType)->countsForUser(trim($userId), $targetSlugs);
    }

    /**
     * @param list<string> $targetSlugs
     *
     * @return array<string, int>
     */
    public function countsPublic(string $targetType, array $targetSlugs): array
    {
        return $this->likeServiceForType($targetType)->countsPublic($targetSlugs);
    }

    /**
     * @deprecated Reactions are stored as sub-entries; metadata is cleared on upgrade.
     */
    public function resetAllReactions(): void
    {
        $this->storage->saveMetadata('club_social_reactions', []);
    }

    /**
     * Ensure the Birkly system account is followed by default.
     *
     * @return list<string>
     */
    public function ensureDefaultFollows(string $userId): array
    {
        return $this->graph()->ensureDefaultFollows($userId);
    }

    /**
     * @return list<string>
     */
    public function listFollowing(string $userId): array
    {
        return $this->graph()->listFollowing($userId);
    }

    /**
     * @return array{following: bool, followers: int}
     */
    public function toggleFollow(string $userId, string $targetUserId): array
    {
        return $this->graph()->toggleFollow($userId, $targetUserId);
    }

    /**
     * @param list<string> $targetUserIds
     *
     * @return array<string, array{following: bool, followers: int}>
     */
    public function followStateForUser(string $userId, array $targetUserIds): array
    {
        return $this->graph()->followStateForUser($userId, $targetUserIds);
    }
}
