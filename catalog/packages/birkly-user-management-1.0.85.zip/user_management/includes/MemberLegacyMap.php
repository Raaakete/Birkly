<?php
/**
 * Legacy user_id ↔ member_id mapping (P77-M8).
 */

declare(strict_types=1);

require_once __DIR__ . '/UserStorage.php';

class MemberLegacyMap
{
    private UserStorage $storage;
    private const META_KEY = 'member_legacy_map';

    public function __construct(?UserStorage $storage = null)
    {
        $this->storage = $storage ?? new UserStorage();
    }

    /**
     * @return array{users: array<string, array<string, mixed>>, members: array<string, array<string, mixed>>, migrated_at?: string}
     */
    public function load(): array
    {
        $stored = $this->storage->readMetadata(self::META_KEY);
        if (!is_array($stored)) {
            return ['users' => [], 'members' => []];
        }

        return [
            'users' => is_array($stored['users'] ?? null) ? $stored['users'] : [],
            'members' => is_array($stored['members'] ?? null) ? $stored['members'] : [],
            'migrated_at' => (string) ($stored['migrated_at'] ?? ''),
        ];
    }

    public function save(array $data): bool
    {
        return $this->storage->saveMetadata(self::META_KEY, [
            'users' => is_array($data['users'] ?? null) ? $data['users'] : [],
            'members' => is_array($data['members'] ?? null) ? $data['members'] : [],
            'migrated_at' => (string) ($data['migrated_at'] ?? date('c')),
            'updated_at' => date('c'),
        ]);
    }

    public function link(string $userId, string $memberId, string $collectionSlug, string $entryId): void
    {
        $userId = trim($userId);
        $memberId = trim($memberId);
        if ($userId === '' || $memberId === '') {
            return;
        }

        $data = $this->load();
        $row = [
            'member_id' => $memberId,
            'collection_slug' => $collectionSlug,
            'entry_id' => $entryId,
            'updated_at' => date('c'),
        ];
        $data['users'][$userId] = $row;
        $data['members'][$memberId] = [
            'user_id' => $userId,
            'collection_slug' => $collectionSlug,
            'entry_id' => $entryId,
            'updated_at' => date('c'),
        ];
        $this->save($data);
    }

  /** @return array<string, mixed>|null */
    public function getByUserId(string $userId): ?array
    {
        $userId = trim($userId);
        if ($userId === '') {
            return null;
        }
        $data = $this->load();

        return is_array($data['users'][$userId] ?? null) ? $data['users'][$userId] : null;
    }

    /** @return array<string, mixed>|null */
    public function getByMemberId(string $memberId): ?array
    {
        $memberId = trim($memberId);
        if ($memberId === '') {
            return null;
        }
        $data = $this->load();

        return is_array($data['members'][$memberId] ?? null) ? $data['members'][$memberId] : null;
    }

    public function resolveUserIdForMember(string $memberId): ?string
    {
        $row = $this->getByMemberId($memberId);

        return $row !== null ? trim((string) ($row['user_id'] ?? '')) : null;
    }

    public function resolveMemberIdForUser(string $userId): ?string
    {
        $row = $this->getByUserId($userId);

        return $row !== null ? trim((string) ($row['member_id'] ?? '')) : null;
    }

    public function isMigrated(): bool
    {
        $data = $this->load();

        return ($data['migrated_at'] ?? '') !== '' && $data['users'] !== [];
    }
}

/**
 * Whether dual-read member entry auth is enabled.
 */
function user_management_member_entry_auth_enabled(): bool
{
    if (function_exists('get_plugin_setting')) {
        $explicit = get_plugin_setting('user_management', 'member_entry_auth', null);
        if ($explicit !== null) {
            return (bool) $explicit;
        }
    }

    return (new MemberLegacyMap())->isMigrated();
}

/**
 * Whether new signups must use member entry flow only.
 */
function user_management_member_entry_signup_only(): bool
{
    if (!function_exists('get_plugin_setting')) {
        return false;
    }

    return (bool) get_plugin_setting('user_management', 'member_entry_signup_only', false);
}
