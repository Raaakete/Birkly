<?php
/**
 * Normalize signup_flow_* fields from Commerce event payloads.
 */

declare(strict_types=1);

/**
 * @return array{flow_id: string, session_id: string, opt_in: string}
 */
function user_management_signup_flow_signals(array $payload): array
{
    $metadata = is_array($payload['metadata'] ?? null) ? $payload['metadata'] : [];

    $optIn = trim((string) (
        $metadata['signup_flow_opt_in']
        ?? $payload['signup_flow_opt_in']
        ?? $metadata['club_opt_in']
        ?? $payload['club_opt_in']
        ?? ''
    ));
    $flowId = trim((string) ($metadata['signup_flow_id'] ?? $payload['signup_flow_id'] ?? ''));
    if ($flowId === '' && user_management_signup_flow_opted_in($optIn)) {
        $flowId = 'pay_then_activate';
    }

    return [
        'flow_id' => $flowId,
        'session_id' => trim((string) ($metadata['signup_flow_session_id'] ?? $payload['signup_flow_session_id'] ?? '')),
        'opt_in' => $optIn,
    ];
}

function user_management_signup_flow_opted_in(string $optIn): bool
{
    $optIn = strtolower(trim($optIn));

    return in_array($optIn, ['1', 'true', 'yes', 'on'], true);
}

function user_management_should_handle_signup_flow_commerce(array $payload): bool
{
    $signals = user_management_signup_flow_signals($payload);
    if ($signals['flow_id'] === '' && $signals['session_id'] === '') {
        return false;
    }
    if ($signals['session_id'] !== '') {
        return true;
    }

    return user_management_signup_flow_opted_in($signals['opt_in']);
}

function user_management_payload_has_signup_flow(array $payload): bool
{
    $signals = user_management_signup_flow_signals($payload);

    return $signals['flow_id'] !== '' || $signals['session_id'] !== '';
}

/**
 * Whether a paid Commerce order still entitles account activation for the given email.
 */
function user_management_commerce_order_entitles_activation(string $email, string $orderId): bool
{
    $email = strtolower(trim($email));
    $orderId = trim($orderId);
    if ($email === '' || $orderId === '') {
        return false;
    }

    if (!class_exists('CommerceOrderStore')) {
        $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
        if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceOrderStore.php')) {
            require_once $pluginDir . '/includes/CommerceOrderStore.php';
        }
    }
    if (!class_exists('CommerceOrderStore')) {
        return false;
    }

    try {
        $order = (new CommerceOrderStore())->get($orderId);
    } catch (Throwable $e) {
        return false;
    }
    if (!is_array($order)) {
        return false;
    }

    if (strtolower(trim((string) ($order['customer_email'] ?? ''))) !== $email) {
        return false;
    }

    $status = strtolower(trim((string) ($order['status'] ?? '')));

    return in_array($status, ['paid', 'partially_refunded'], true);
}

/**
 * Whether activation context from a signup flow commerce handoff is still valid at verify time.
 *
 * @param array<string, mixed> $context
 */
function user_management_signup_flow_activation_entitled(string $email, array $context): bool
{
    if ((string) ($context['source'] ?? '') !== 'signup_flow') {
        return false;
    }

    $email = strtolower(trim($email));
    if ($email === '') {
        return false;
    }

    $orderId = trim((string) ($context['order_id'] ?? ''));
    if ($orderId !== '' && user_management_commerce_order_entitles_activation($email, $orderId)) {
        return true;
    }

    $sessionId = trim((string) ($context['signup_flow_session_id'] ?? ''));
    if ($sessionId !== '') {
        if (!class_exists('UserStorage')) {
            require_once __DIR__ . '/UserStorage.php';
        }
        $session = (new UserStorage())->getSignupFlowSession($sessionId);
        if (is_array($session) && strtolower(trim((string) ($session['email'] ?? ''))) === $email) {
            return true;
        }
    }

    $flowId = trim((string) ($context['signup_flow_id'] ?? ''));
    if ($flowId === '') {
        return false;
    }

    return user_management_email_has_signup_flow_paid_order($email, $flowId);
}

/**
 * @return list<array<string, mixed>>
 */
function user_management_paid_orders_for_email(string $email): array
{
    $email = strtolower(trim($email));
    if ($email === '') {
        return [];
    }

    if (!class_exists('CommerceOrderStore')) {
        $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
        if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceOrderStore.php')) {
            require_once $pluginDir . '/includes/CommerceOrderStore.php';
        }
    }
    if (!class_exists('CommerceOrderStore')) {
        return [];
    }

    $orders = [];
    try {
        foreach ((new CommerceOrderStore())->listAll() as $order) {
            if (!is_array($order)) {
                continue;
            }
            if (strtolower(trim((string) ($order['customer_email'] ?? ''))) !== $email) {
                continue;
            }
            $status = strtolower(trim((string) ($order['status'] ?? '')));
            if (!in_array($status, ['paid', 'partially_refunded'], true)) {
                continue;
            }
            $orders[] = $order;
        }
    } catch (Throwable $e) {
        return [];
    }

    return $orders;
}

function user_management_email_has_signup_flow_paid_order(string $email, string $flowId): bool
{
    $flowId = trim($flowId);
    if ($flowId === '') {
        return false;
    }

    foreach (user_management_paid_orders_for_email($email) as $order) {
        $metadata = is_array($order['metadata'] ?? null) ? $order['metadata'] : [];
        $signals = user_management_signup_flow_signals(array_merge($order, ['metadata' => $metadata]));
        if ($signals['flow_id'] !== $flowId) {
            continue;
        }
        if ($signals['session_id'] !== '' || user_management_signup_flow_opted_in($signals['opt_in'])) {
            return true;
        }
    }

    return false;
}
