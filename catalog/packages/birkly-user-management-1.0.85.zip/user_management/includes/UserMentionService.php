<?php
/**
 * Persist and notify @mentions on UGC posts and comments (P81-M8).
 */

declare(strict_types=1);

require_once __DIR__ . '/ClubMentionParser.php';
require_once __DIR__ . '/UserNotificationService.php';
require_once __DIR__ . '/UserPluginCollectionConfig.php';
require_once __DIR__ . '/EntryOwnership.php';

class UserMentionService
{
    private ClubMentionParser $parser;
    private UserNotificationService $notifications;

    public function __construct(
        ?ClubMentionParser $parser = null,
        ?UserNotificationService $notifications = null
    ) {
        $this->parser = $parser ?? new ClubMentionParser();
        $this->notifications = $notifications ?? new UserNotificationService();
    }

    /**
     * @param array<string, mixed> $entry
     * @param array<string, mixed>|null $oldEntry
     */
    public function processPost(array $entry, string $collectionSlug, ?array $oldEntry = null): void
    {
        if (($entry['status'] ?? 'published') !== 'published') {
            return;
        }
        if (!UserPluginCollectionConfig::mentionsEnabled($collectionSlug)) {
            return;
        }

        $entryId = trim((string) ($entry['id'] ?? ''));
        if ($entryId === '') {
            return;
        }

        $authorId = EntryOwnership::getEntryOwnerId($entry, $collectionSlug) ?? '';
        $body = (string) ($entry['body'] ?? '');
        $mentioned = $this->parser->parseMentionedUserIds($body, $authorId !== '' ? $authorId : null);
        $previous = $this->parser->decodeMentionedUserIds(
            is_array($oldEntry) ? ($oldEntry['mentioned_user_ids'] ?? '[]') : ($entry['mentioned_user_ids'] ?? '[]')
        );
        $stored = $this->parser->decodeMentionedUserIds($entry['mentioned_user_ids'] ?? '[]');

        if ($mentioned !== $stored) {
            $this->persistEntryField($collectionSlug, $entryId, 'mentioned_user_ids', $this->parser->encodeMentionedUserIds($mentioned));
        }

        $newMentions = array_values(array_diff($mentioned, $previous));
        if ($newMentions === []) {
            return;
        }

        $link = trim((string) (UserPluginCollectionConfig::forCollection($collectionSlug)['notification_link'] ?? '/'));
        $this->notifyMentionedUsers($authorId, $newMentions, [
            'title' => trim((string) ($entry['title'] ?? 'Post')),
            'body' => $body,
            'target_collection' => $collectionSlug,
            'target_entry_id' => $entryId,
            'link' => $link,
        ]);

        if (function_exists('do_action')) {
            do_action('club_mention_created', [
                'entry_id' => $entryId,
                'mentioned_user_ids' => $newMentions,
                'collection' => $collectionSlug,
            ]);
        }
    }

    /** @deprecated Use processPost() */
    public function processClubPost(array $entry, ?array $oldEntry = null): void
    {
        $collectionSlug = trim((string) ($entry['target_collection'] ?? ''));
        if ($collectionSlug === '') {
            $collectionSlug = 'club-posts';
        }
        $this->processPost($entry, $collectionSlug, $oldEntry);
    }

    /**
     * @param array<string, mixed> $subEntry
     */
    public function processComment(
        string $subEntryId,
        array $subEntry,
        string $parentCollection,
        string $parentEntryId
    ): void {
        if (!UserPluginCollectionConfig::mentionsEnabled($parentCollection)) {
            return;
        }

        $authorId = EntryOwnership::getEntryOwnerId($subEntry, $parentCollection) ?? '';
        $body = (string) ($subEntry['body'] ?? '');
        $mentioned = $this->parser->parseMentionedUserIds($body, $authorId !== '' ? $authorId : null);
        if ($mentioned === []) {
            return;
        }

        if ($subEntryId !== '') {
            $this->persistSubEntryField(
                $parentCollection,
                $parentEntryId,
                'comments',
                $subEntryId,
                'mentioned_user_ids',
                $this->parser->encodeMentionedUserIds($mentioned)
            );
        }

        $link = trim((string) (UserPluginCollectionConfig::forCollection($parentCollection)['notification_link'] ?? '/'));
        $this->notifyMentionedUsers($authorId, $mentioned, [
            'title' => 'Mentioned in a comment',
            'body' => $body,
            'target_collection' => $parentCollection,
            'target_entry_id' => $parentEntryId,
            'target_sub_id' => $subEntryId,
            'link' => $link,
        ]);

        if (function_exists('do_action')) {
            do_action('club_mention_created', [
                'entry_id' => $parentEntryId,
                'sub_entry_id' => $subEntryId,
                'mentioned_user_ids' => $mentioned,
                'collection' => $parentCollection,
                'sub_collection' => 'comments',
            ]);
        }
    }

    /** @deprecated Use processComment() */
    public function processClubComment(
        string $subEntryId,
        array $subEntry,
        string $parentEntryId
    ): void {
        $this->processComment($subEntryId, $subEntry, 'club-posts', $parentEntryId);
    }

    /**
     * @param list<string> $mentionedUserIds
     * @param array<string, mixed> $context
     */
    private function notifyMentionedUsers(string $authorId, array $mentionedUserIds, array $context): void
    {
        $actorName = $this->notifications->actorDisplayName($authorId);
        $snippet = trim(strip_tags((string) ($context['body'] ?? '')));
        if (strlen($snippet) > 120) {
            $snippet = substr($snippet, 0, 117) . '…';
        }

        $payload = [
            'actor_user_id' => $authorId,
            'title' => $actorName . ' mentioned you',
            'body' => $snippet !== '' ? $snippet : (string) ($context['title'] ?? 'Update'),
            'link' => (string) ($context['link'] ?? '/'),
            'target_collection' => (string) ($context['target_collection'] ?? ''),
            'target_entry_id' => (string) ($context['target_entry_id'] ?? ''),
            'target_sub_id' => (string) ($context['target_sub_id'] ?? ''),
        ];

        $this->notifications->notifyMany($mentionedUserIds, UserNotificationService::TYPE_MENTION, $payload);
    }

    private function persistEntryField(string $collectionSlug, string $entryId, string $field, string $value): void
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== $collectionSlug) {
                continue;
            }
            $path = "collections/{$dir}/entries/{$entryId}.json";
            $entry = $storage->read($path);
            if (!is_array($entry)) {
                return;
            }
            $entry[$field] = $value;
            $entry['updated_at'] = date('c');
            $storage->write($path, $entry);

            return;
        }
    }

    private function persistSubEntryField(
        string $parentCollection,
        string $parentEntryId,
        string $subCollection,
        string $subEntryId,
        string $field,
        string $value
    ): void {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== $parentCollection) {
                continue;
            }
            $path = "collections/{$dir}/entries/{$parentEntryId}/sub_entries/{$subCollection}/{$subEntryId}.json";
            $entry = $storage->read($path);
            if (!is_array($entry)) {
                return;
            }
            $entry[$field] = $value;
            $entry['updated_at'] = date('c');
            $storage->write($path, $entry);

            return;
        }
    }
}

if (!class_exists('ClubMentionService', false)) {
    class_alias(UserMentionService::class, 'ClubMentionService');
}
