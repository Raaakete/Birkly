<?php
/**
 * Member tier upgrades and cross-collection moves (P77-M6).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';
require_once __DIR__ . '/UserCollectionResolver.php';
require_once __DIR__ . '/UserFieldtypeProfileStore.php';
require_once __DIR__ . '/TierProfileService.php';
require_once __DIR__ . '/MemberAccountCodec.php';
require_once __DIR__ . '/UserMemberIndexer.php';
require_once __DIR__ . '/UserStorage.php';

class MemberMigrationService
{
    private UserCollectionResolver $resolver;
    private UserFieldtypeProfileStore $profiles;
    private TierProfileService $tierProfiles;
    private UserStorage $storage;
    private UserMemberIndexer $indexer;

    public function __construct(
        ?UserCollectionResolver $resolver = null,
        ?UserFieldtypeProfileStore $profiles = null,
        ?TierProfileService $tierProfiles = null,
        ?UserStorage $storage = null,
        ?UserMemberIndexer $indexer = null
    ) {
        $this->resolver = $resolver ?? new UserCollectionResolver();
        $this->profiles = $profiles ?? new UserFieldtypeProfileStore();
        $this->storage = $storage ?? new UserStorage();
        $this->tierProfiles = $tierProfiles ?? new TierProfileService($this->profiles, $this->storage);
        $this->indexer = $indexer ?? new UserMemberIndexer();
    }

    /**
     * @return array{ok: bool, mode?: string, member_id?: string, collection?: string, target_collection?: string, tier_id?: string, type_key?: string, missing_requirements?: list<string>, target_collections?: list<string>, error?: string}
     */
    public function planUpgrade(string $memberId, string $newTierId, ?string $targetCollection = null): array
    {
        $context = $this->loadMemberContext($memberId);
        if ($context === null) {
            return ['ok' => false, 'error' => 'Member not found'];
        }

        $newTierId = $this->normalizeTierId($newTierId);
        $newTypeKey = $this->tierProfiles->typeKeyForTierSlug($newTierId);
        $sourceCollection = (string) $context['collection_slug'];
        $accountField = $context['account_field'];
        $currentTypeKey = (string) ($accountField['type'] ?? 'user_account');

        $mode = 'in_place';
        $resolvedTarget = $sourceCollection;

        if (!$this->canUpgradeInPlace($sourceCollection, $currentTypeKey, $newTypeKey)) {
            $targetCollection = trim((string) $targetCollection);
            if ($targetCollection !== '' && $this->resolver->collectionSupportsProfile($targetCollection, $newTypeKey)) {
                $mode = 'cross_collection';
                $resolvedTarget = $targetCollection;
            } else {
                $candidates = $this->resolver->listCollectionsForTypeKey($newTypeKey);
                $candidates = array_values(array_filter($candidates, static fn ($s) => $s !== $sourceCollection));
                if ($candidates === []) {
                    return [
                        'ok' => false,
                        'error' => 'No collection supports tier type ' . $newTypeKey,
                        'type_key' => $newTypeKey,
                        'target_collections' => [],
                    ];
                }
                if (count($candidates) === 1) {
                    $mode = 'cross_collection';
                    $resolvedTarget = $candidates[0];
                } else {
                    return [
                        'ok' => true,
                        'mode' => 'choose_collection',
                        'member_id' => $memberId,
                        'collection' => $sourceCollection,
                        'tier_id' => $newTierId,
                        'type_key' => $newTypeKey,
                        'target_collections' => $candidates,
                    ];
                }
            }
        }

        $settings = $this->profileSettingsForTier($newTierId, $newTypeKey);
        $previousTierId = (string) ($context['account']['tier_id'] ?? 'all');
        $previousTypeKey = (string) ($context['account_field']['type'] ?? 'user_account');
        $previousSettings = $this->profileSettingsForTier($previousTierId, $previousTypeKey);
        $missing = $this->missingRequirements($context['account'], $settings, $previousSettings);

        return [
            'ok' => true,
            'mode' => $mode,
            'member_id' => $memberId,
            'collection' => $sourceCollection,
            'target_collection' => $resolvedTarget,
            'tier_id' => $newTierId,
            'type_key' => $newTypeKey,
            'missing_requirements' => $missing,
            'blocked' => $missing !== [] || $this->paymentBlocksPublish($settings, $context['account']),
        ];
    }

    /**
     * @param array<string, mixed> $extraFields Values for newly required profile fields
     * @return array{ok: bool, error?: string, mode?: string, entry?: array<string, mixed>, member_id?: string, collection?: string, missing_requirements?: list<string>}
     */
    public function changeTier(
        string $memberId,
        string $newTierId,
        ?string $targetCollection = null,
        array $extraFields = []
    ): array {
        $plan = $this->planUpgrade($memberId, $newTierId, $targetCollection);
        if (empty($plan['ok'])) {
            return ['ok' => false, 'error' => (string) ($plan['error'] ?? 'Upgrade not possible')];
        }

        if (($plan['mode'] ?? '') === 'choose_collection') {
            return [
                'ok' => false,
                'error' => 'Target collection required',
                'target_collections' => $plan['target_collections'] ?? [],
            ];
        }

        $context = $this->loadMemberContext($memberId);
        if ($context === null) {
            return ['ok' => false, 'error' => 'Member not found'];
        }

        $newTierId = (string) $plan['tier_id'];
        $newTypeKey = (string) $plan['type_key'];
        $settings = $this->profileSettingsForTier($newTierId, $newTypeKey);
        $previousTierId = (string) ($context['account']['tier_id'] ?? 'all');
        $previousTypeKey = (string) ($context['account_field']['type'] ?? 'user_account');
        $previousSettings = $this->profileSettingsForTier($previousTierId, $previousTypeKey);
        $account = $this->mergeExtraFields($context['account'], $extraFields, $settings);
        $missing = $this->missingRequirements($account, $settings, $previousSettings);
        if ($missing !== []) {
            return ['ok' => false, 'error' => 'Missing requirements', 'missing_requirements' => $missing];
        }
        if ($this->paymentBlocksPublish($settings, $account)) {
            return ['ok' => false, 'error' => 'Payment required before publish', 'missing_requirements' => ['payment']];
        }

        $profile = $this->profiles->getProfileByTypeKey($newTypeKey);
        $account['tier_id'] = $newTierId;
        $account['fieldtype_profile_id'] = (string) ($profile['id'] ?? 'default');
        $processed = MemberAccountCodec::processForStorage(
            $account,
            $context['account'],
            $settings,
            $newTypeKey
        );

        $accountFieldName = (string) ($context['account_field']['name'] ?? 'account');
        $entry = $context['entry'];
        $entry[$accountFieldName] = $processed;
        $entry['updated_at'] = date('c');

        $mode = (string) ($plan['mode'] ?? 'in_place');
        if ($mode === 'cross_collection') {
            $target = (string) ($plan['target_collection'] ?? '');
            $moved = $this->moveEntry(
                (string) $context['collection_slug'],
                (string) $context['entry_id'],
                $target,
                $entry,
                $newTypeKey
            );
            if ($moved === null) {
                return ['ok' => false, 'error' => 'Could not move member entry'];
            }

            return [
                'ok' => true,
                'mode' => 'cross_collection',
                'member_id' => $memberId,
                'collection' => $target,
                'entry' => $moved,
            ];
        }

        $saved = $this->writeEntry((string) $context['collection_slug'], $entry);
        if ($saved === null) {
            return ['ok' => false, 'error' => 'Could not save member entry'];
        }

        $this->indexer->indexEntry($saved, (string) $context['collection_slug']);

        return [
            'ok' => true,
            'mode' => 'in_place',
            'member_id' => $memberId,
            'collection' => (string) $context['collection_slug'],
            'entry' => $saved,
        ];
    }

    public function canUpgradeInPlace(string $collectionSlug, string $currentTypeKey, string $newTypeKey): bool
    {
        if ($currentTypeKey === $newTypeKey) {
            return true;
        }
        if ($currentTypeKey === 'user_account') {
            return true;
        }
        if (str_starts_with($currentTypeKey, 'user_account_') && str_starts_with($newTypeKey, 'user_account_')) {
            return false;
        }

        return $this->resolver->collectionSupportsProfile($collectionSlug, $newTypeKey);
    }

    /**
     * @param array<string, mixed> $account
     * @param array<string, mixed> $settings
     * @param array<string, mixed>|null $previousSettings
     * @return list<string>
     */
    public function missingRequirements(array $account, array $settings, ?array $previousSettings = null): array
    {
        $normalized = MemberAccountCodec::normalize($account);

        if ($previousSettings === null) {
            return MemberAccountCodec::validate($normalized, $settings, false);
        }

        $errors = [];
        $oldRequiredCustom = [];
        foreach ((array) ($previousSettings['requirements']['custom_fields'] ?? []) as $field) {
            if (!is_array($field) || empty($field['required'])) {
                continue;
            }
            $key = (string) ($field['key'] ?? '');
            if ($key !== '') {
                $oldRequiredCustom[$key] = true;
            }
        }

        foreach ((array) ($settings['requirements']['custom_fields'] ?? []) as $field) {
            if (!is_array($field) || empty($field['required'])) {
                continue;
            }
            $key = (string) ($field['key'] ?? '');
            if ($key === '' || isset($oldRequiredCustom[$key])) {
                continue;
            }
            $val = trim((string) ($normalized['custom'][$key] ?? ''));
            if ($val === '') {
                $errors[] = (string) ($field['label'] ?? $key) . ' is required';
            }
        }

        return $errors;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function loadMemberEntry(string $collectionSlug, string $entryId): ?array
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $dir = $this->resolveCollectionDir($storage, $collectionSlug);
        if ($dir === null) {
            return null;
        }
        $data = $storage->read("collections/{$dir}/entries/{$entryId}.json");

        return is_array($data) ? $data : null;
    }

    /**
     * @param array<string, mixed> $settings
     * @param array<string, mixed> $account
     */
    public function paymentBlocksPublish(array $settings, array $account): bool
    {
        if (!user_management_commerce_plugin_active()) {
            return false;
        }
        $commerce = $settings['commerce'] ?? [];
        if (empty($commerce['payment_required_at_signup'])) {
            return false;
        }
        $normalized = MemberAccountCodec::normalize($account);
        $linked = trim((string) (($normalized['commerce']['customer_id'] ?? '') ?: ''));

        return $linked === '';
    }

    /**
     * @return array{collection_slug: string, entry_id: string, entry: array<string, mixed>, account: array<string, mixed>, account_field: array<string, mixed>}|null
     */
    private function loadMemberContext(string $memberId): ?array
    {
        $row = $this->indexer->getMember($memberId);
        if (!is_array($row)) {
            return null;
        }

        $collectionSlug = (string) ($row['collection_slug'] ?? '');
        $entryId = (string) ($row['entry_id'] ?? '');
        if ($collectionSlug === '' || $entryId === '') {
            return null;
        }

        $accountField = $this->resolver->getAccountFieldOnSchema($collectionSlug);
        if ($accountField === null) {
            return null;
        }

        $entry = $this->loadMemberEntry($collectionSlug, $entryId);
        if ($entry === null) {
            return null;
        }

        $fieldName = (string) ($accountField['name'] ?? 'account');
        $account = MemberAccountCodec::normalize($entry[$fieldName] ?? []);
        if (trim((string) ($account['member_id'] ?? '')) === '') {
            $account['member_id'] = $memberId;
        }

        return [
            'collection_slug' => $collectionSlug,
            'entry_id' => $entryId,
            'entry' => $entry,
            'account' => $account,
            'account_field' => $accountField,
        ];
    }

    private function normalizeTierId(string $tierId): string
    {
        $tierId = trim($tierId);
        if ($tierId === '') {
            return 'all';
        }
        $tier = $this->storage->getTier($tierId);

        return is_array($tier) ? (string) ($tier['id'] ?? $tierId) : $tierId;
    }

    /** @return array<string, mixed> */
    private function profileSettingsForTier(string $tierId, string $typeKey): array
    {
        $tier = $this->storage->getTier($tierId);
        if (is_array($tier)) {
            $fromTier = $this->tierProfiles->getProfileSettingsForTier($tier);
            if (is_array($fromTier)) {
                return UserFieldtypeProfileStore::normalizeSettings(
                    $fromTier,
                    user_management_commerce_plugin_active()
                );
            }
        }

        return $this->profiles->getSettingsForTypeKey($typeKey);
    }

    /**
     * @param array<string, mixed> $account
     * @param array<string, mixed> $extraFields
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    private function mergeExtraFields(array $account, array $extraFields, array $settings): array
    {
        $custom = is_array($account['custom'] ?? null) ? $account['custom'] : [];
        foreach ($extraFields as $key => $value) {
            if (!is_string($key)) {
                continue;
            }
            if (in_array($key, ['email', 'password', 'name', 'tier_id'], true)) {
                $account[$key] = $value;
                continue;
            }
            $custom[$key] = $value;
        }
        $account['custom'] = $custom;

        return $account;
    }

    /**
     * @param array<string, mixed> $entry
     * @return array<string, mixed>|null
     */
    private function moveEntry(
        string $sourceCollection,
        string $entryId,
        string $targetCollection,
        array $entry,
        string $newTypeKey
    ): ?array {
        $targetField = $this->resolver->getAccountFieldOnSchema($targetCollection);
        if ($targetField === null) {
            return null;
        }

        $targetFieldName = (string) ($targetField['name'] ?? 'account');
        $sourceField = $this->resolver->getAccountFieldOnSchema($sourceCollection);
        $sourceFieldName = (string) ($sourceField['name'] ?? 'account');

        if ($targetFieldName !== $sourceFieldName && isset($entry[$sourceFieldName])) {
            $entry[$targetFieldName] = $entry[$sourceFieldName];
            unset($entry[$sourceFieldName]);
        }

        $memberId = MemberAccountCodec::normalize($entry[$targetFieldName] ?? [])['member_id'] ?? '';
        $entry['updated_at'] = date('c');

        $written = $this->writeEntry($targetCollection, $entry);
        if ($written === null) {
            return null;
        }

        $this->deleteEntry($sourceCollection, $entryId);
        $this->indexer->removeEntry($entryId, $sourceCollection);
        $this->indexer->indexEntry($written, $targetCollection);

        if (function_exists('do_action')) {
            do_action('user_member_migrated', $memberId, $sourceCollection, $targetCollection, $written);
        }

        return $written;
    }

    /**
     * @param array<string, mixed> $entry
     * @return array<string, mixed>|null
     */
    private function writeEntry(string $collectionSlug, array $entry): ?array
    {
        $entryId = (string) ($entry['id'] ?? '');
        if ($entryId === '') {
            return null;
        }

        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $dir = $this->resolveCollectionDir($storage, $collectionSlug);
        if ($dir === null) {
            return null;
        }

        if (!$storage->write("collections/{$dir}/entries/{$entryId}.json", $entry)) {
            return null;
        }

        return $entry;
    }

    private function deleteEntry(string $collectionSlug, string $entryId): bool
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $dir = $this->resolveCollectionDir($storage, $collectionSlug);
        if ($dir === null) {
            return false;
        }

        return (bool) $storage->delete("collections/{$dir}/entries/{$entryId}.json");
    }

    private function resolveCollectionDir(Storage $storage, string $collectionSlug): ?string
    {
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (is_array($meta) && (string) ($meta['slug'] ?? '') === $collectionSlug) {
                return (string) $dir;
            }
        }

        if (is_dir(user_management_cms_path('content/collections/' . $collectionSlug))) {
            return $collectionSlug;
        }

        return null;
    }
}
