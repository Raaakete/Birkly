<?php
/**
 * Collection schema inference for member signups (P77-M5, Approach C).
 */

declare(strict_types=1);

require_once __DIR__ . '/MemberAccountCodec.php';

class UserCollectionResolver
{
    public function collectionSupportsProfile(string $collectionSlug, string $typeKey): bool
    {
        $field = $this->getAccountFieldOnSchema($collectionSlug);
        if ($field === null) {
            return false;
        }

        $fieldType = (string) ($field['type'] ?? '');

        return $fieldType === $typeKey;
    }

    /** @return list<string> */
    public function listCollectionsForTypeKey(string $typeKey): array
    {
        $matches = [];
        foreach ($this->listCollectionSlugs() as $slug) {
            if ($this->collectionSupportsProfile($slug, $typeKey)) {
                $matches[] = $slug;
            }
        }

        return $matches;
    }

    /**
     * @return array<string, mixed>|null Field config with name, type, label
     */
    public function getAccountFieldOnSchema(string $collectionSlug): ?array
    {
        $collectionSlug = trim($collectionSlug);
        if ($collectionSlug === '') {
            return null;
        }

        $fields = $this->readSchemaFields($collectionSlug);
        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }
            $type = (string) ($field['type'] ?? '');
            if (!MemberAccountCodec::isAccountFieldType($type)) {
                continue;
            }
            $name = trim((string) ($field['name'] ?? ''));
            if ($name === '') {
                continue;
            }

            return $field;
        }

        return null;
    }

    public function collectionExists(string $collectionSlug): bool
    {
        return user_management_resolve_collection_json_path($collectionSlug) !== null;
    }

    /** @return list<array<string, mixed>> */
    private function readSchemaFields(string $collectionSlug): array
    {
        $schemaPath = user_management_cms_path('content/collections/' . $collectionSlug . '/schema.json');
        if (is_file($schemaPath)) {
            $schema = json_decode((string) file_get_contents($schemaPath), true);
            if (is_array($schema) && isset($schema['fields']) && is_array($schema['fields'])) {
                return $schema['fields'];
            }
        }

        if (function_exists('birkly_entry_read_schema')) {
            $schema = birkly_entry_read_schema($collectionSlug);
            if (is_array($schema) && isset($schema['fields']) && is_array($schema['fields'])) {
                return $schema['fields'];
            }
        }

        $collectionPath = user_management_resolve_collection_json_path($collectionSlug);
        if ($collectionPath !== null) {
            $meta = json_decode((string) file_get_contents($collectionPath), true);
            if (is_array($meta) && isset($meta['fields']) && is_array($meta['fields'])) {
                return $meta['fields'];
            }
        }

        return [];
    }

    /** @return list<string> */
    private function listCollectionSlugs(): array
    {
        $root = user_management_cms_path('content/collections');
        if (!is_dir($root)) {
            return [];
        }

        $slugs = [];
        foreach (scandir($root) ?: [] as $dir) {
            if ($dir === '.' || $dir === '..') {
                continue;
            }
            $full = $root . '/' . $dir;
            if (!is_dir($full)) {
                continue;
            }
            $metaFile = $full . '/collection.json';
            if (!is_file($metaFile)) {
                continue;
            }
            $data = json_decode((string) file_get_contents($metaFile), true);
            $slug = is_array($data) ? (string) ($data['slug'] ?? $dir) : $dir;
            $slugs[] = $slug !== '' ? $slug : $dir;
        }

        return $slugs;
    }
}
