<?php
/**
 * UserGraphStore — plugin-private social graph edge storage (P76).
 */

declare(strict_types=1);

require_once dirname(__DIR__) . '/cms_paths.php';

class UserGraphStore
{
    public const KIND_FOLLOW = 'follow';
    public const KIND_CONNECTION = 'connection';
    public const KIND_BLOCK = 'block';
    public const KIND_MUTE = 'mute';
    /** @deprecated migrated to KIND_CONNECTION */
    public const KIND_FRIEND = 'friend';

    public const STATUS_ACTIVE = 'active';
    public const STATUS_PENDING = 'pending';
    public const STATUS_REJECTED = 'rejected';

    private string $baseDir;

    public function __construct(?string $baseDir = null)
    {
        if ($baseDir !== null && $baseDir !== '') {
            $this->baseDir = rtrim($baseDir, '/') . '/graph';
        } else {
            $this->baseDir = user_management_data_dir() . '/graph';
        }
    }

    public function getBaseDir(): string
    {
        return $this->baseDir;
    }

    public function ensureStore(): bool
    {
        foreach ([
            $this->baseDir,
            $this->baseDir . '/edges',
            $this->baseDir . '/index/outgoing',
            $this->baseDir . '/index/incoming',
        ] as $dir) {
            if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function readEdge(string $edgeId): ?array
    {
        $edgeId = trim($edgeId);
        if ($edgeId === '') {
            return null;
        }
        $path = $this->edgePath($edgeId);
        if (!is_file($path)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($path), true);

        return is_array($data) ? $this->normalizeEdge($data) : null;
    }

    /**
     * @param array<string, mixed> $edge
     */
    public function writeEdge(array $edge): bool
    {
        $edge = $this->normalizeEdge($edge);
        $edgeId = (string) ($edge['id'] ?? '');
        if ($edgeId === '') {
            return false;
        }

        $from = (string) ($edge['from_user'] ?? '');
        $to = (string) ($edge['to_user'] ?? '');
        if ($from === '' || $to === '') {
            return false;
        }

        $existing = $this->readEdge($edgeId);
        if ($existing !== null) {
            $this->removeFromIndex($existing);
        }

        $edge['updated_at'] = date('c');
        if (empty($edge['created_at'])) {
            $edge['created_at'] = $edge['updated_at'];
        }

        $ok = file_put_contents(
            $this->edgePath($edgeId),
            json_encode($edge, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n"
        ) !== false;

        if ($ok) {
            $this->addToIndex($edge);
        }

        return $ok;
    }

    public function deleteEdgeById(string $edgeId): bool
    {
        $existing = $this->readEdge($edgeId);
        if ($existing === null) {
            return false;
        }
        $this->removeFromIndex($existing);
        $path = $this->edgePath($edgeId);
        if (is_file($path)) {
            return unlink($path);
        }

        return true;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findEdge(string $fromUserId, string $toUserId, string $kind, ?string $status = self::STATUS_ACTIVE): ?array
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $kind = $this->normalizeKind($kind);

        foreach ($this->listOutgoingEdgeIds($fromUserId) as $edgeId) {
            $edge = $this->readEdge($edgeId);
            if ($edge === null) {
                continue;
            }
            if ((string) ($edge['to_user'] ?? '') !== $toUserId) {
                continue;
            }
            if ((string) ($edge['kind'] ?? '') !== $kind) {
                continue;
            }
            if ($status !== null && (string) ($edge['status'] ?? '') !== $status) {
                continue;
            }

            return $edge;
        }

        return null;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listOutgoing(string $userId, ?string $kind = null, ?string $status = self::STATUS_ACTIVE): array
    {
        $userId = trim($userId);
        if ($userId === '') {
            return [];
        }

        $edges = [];
        foreach ($this->listOutgoingEdgeIds($userId) as $edgeId) {
            $edge = $this->readEdge($edgeId);
            if ($edge === null) {
                continue;
            }
            if ($kind !== null && (string) ($edge['kind'] ?? '') !== $this->normalizeKind($kind)) {
                continue;
            }
            if ($status !== null && (string) ($edge['status'] ?? '') !== $status) {
                continue;
            }
            $edges[] = $edge;
        }

        return $edges;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listIncoming(string $userId, ?string $kind = null, ?string $status = self::STATUS_ACTIVE): array
    {
        $userId = trim($userId);
        if ($userId === '') {
            return [];
        }

        $edges = [];
        foreach ($this->listIncomingEdgeIds($userId) as $edgeId) {
            $edge = $this->readEdge($edgeId);
            if ($edge === null) {
                continue;
            }
            if ($kind !== null && (string) ($edge['kind'] ?? '') !== $this->normalizeKind($kind)) {
                continue;
            }
            if ($status !== null && (string) ($edge['status'] ?? '') !== $status) {
                continue;
            }
            $edges[] = $edge;
        }

        return $edges;
    }

    /**
     * @return list<string>
     */
    public function listUserIdsOutgoing(string $userId, string $kind, ?string $status = self::STATUS_ACTIVE): array
    {
        $ids = [];
        foreach ($this->listOutgoing($userId, $kind, $status) as $edge) {
            $target = (string) ($edge['to_user'] ?? '');
            if ($target !== '') {
                $ids[] = $target;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @return list<string>
     */
    public function listUserIdsIncoming(string $userId, string $kind, ?string $status = self::STATUS_ACTIVE): array
    {
        $ids = [];
        foreach ($this->listIncoming($userId, $kind, $status) as $edge) {
            $source = (string) ($edge['from_user'] ?? '');
            if ($source !== '') {
                $ids[] = $source;
            }
        }

        return array_values(array_unique($ids));
    }

    public function countIncoming(string $userId, string $kind, ?string $status = self::STATUS_ACTIVE): int
    {
        return count($this->listIncoming($userId, $kind, $status));
    }

    /**
     * @param list<string> $targetUserIds
     *
     * @return array<string, int>
     */
    public function countIncomingForTargets(array $targetUserIds, string $kind, ?string $status = self::STATUS_ACTIVE): array
    {
        $targets = [];
        foreach ($targetUserIds as $targetUserId) {
            $targetUserId = trim((string) $targetUserId);
            if ($targetUserId !== '') {
                $targets[$targetUserId] = 0;
            }
        }
        if ($targets === []) {
            return [];
        }

        foreach ($targets as $targetId => $_) {
            $targets[$targetId] = $this->countIncoming($targetId, $kind, $status);
        }

        return $targets;
    }

    public function purgeUser(string $userId): int
    {
        $userId = trim($userId);
        if ($userId === '') {
            return 0;
        }

        $removed = 0;
        $edgeIds = array_unique(array_merge(
            $this->listOutgoingEdgeIds($userId),
            $this->listIncomingEdgeIds($userId)
        ));

        foreach ($edgeIds as $edgeId) {
            if ($this->deleteEdgeById($edgeId)) {
                $removed++;
            }
        }

        $outgoingIndex = $this->indexPath('outgoing', $userId);
        $incomingIndex = $this->indexPath('incoming', $userId);
        if (is_file($outgoingIndex)) {
            unlink($outgoingIndex);
        }
        if (is_file($incomingIndex)) {
            unlink($incomingIndex);
        }

        return $removed;
    }

    /**
     * @return array{following: int, followers: int, connected: int, pending_in: int, blocked: int}
     */
    public function summaryForUser(string $userId): array
    {
        $userId = trim($userId);

        return [
            'following' => count($this->listOutgoing($userId, self::KIND_FOLLOW, self::STATUS_ACTIVE)),
            'followers' => count($this->listIncoming($userId, self::KIND_FOLLOW, self::STATUS_ACTIVE)),
            'connected' => count($this->listConnectedUserIds($userId)),
            'pending_in' => count($this->listIncoming($userId, self::KIND_CONNECTION, self::STATUS_PENDING)),
            'blocked' => count($this->listOutgoing($userId, self::KIND_BLOCK, self::STATUS_ACTIVE)),
        ];
    }

    /**
     * @return list<string>
     */
    public function listConnectedUserIds(string $userId): array
    {
        $userId = trim($userId);
        if ($userId === '') {
            return [];
        }

        $connected = [];
        foreach ($this->listOutgoing($userId, self::KIND_CONNECTION, self::STATUS_ACTIVE) as $edge) {
            $other = (string) ($edge['to_user'] ?? '');
            if ($other === '') {
                continue;
            }
            $reverse = $this->findEdge($other, $userId, self::KIND_CONNECTION, self::STATUS_ACTIVE);
            if ($reverse !== null) {
                $connected[] = $other;
            }
        }

        return array_values(array_unique($connected));
    }

    public function edgeId(string $fromUserId, string $toUserId, string $kind): string
    {
        $hash = substr(sha1($this->normalizeKind($kind) . '|' . $fromUserId . '|' . $toUserId), 0, 16);

        return 'edge_' . $hash;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listAllEdges(): array
    {
        $dir = $this->baseDir . '/edges';
        if (!is_dir($dir)) {
            return [];
        }

        $edges = [];
        foreach (glob($dir . '/*.json') ?: [] as $file) {
            $data = json_decode((string) file_get_contents($file), true);
            if (is_array($data)) {
                $edges[] = $this->normalizeEdge($data);
            }
        }

        return $edges;
    }

    /**
     * @param array<string, mixed> $edge
     *
     * @return array<string, mixed>
     */
    public function normalizeEdge(array $edge): array
    {
        $kind = (string) ($edge['kind'] ?? $edge['relationship_type'] ?? '');
        $edge['kind'] = $this->normalizeKind($kind);
        unset($edge['relationship_type']);

        return $edge;
    }

    public function normalizeKind(string $kind): string
    {
        $kind = strtolower(trim($kind));
        if ($kind === self::KIND_FRIEND) {
            return self::KIND_CONNECTION;
        }

        return $kind;
    }

    private function edgePath(string $edgeId): string
    {
        return $this->baseDir . '/edges/' . $edgeId . '.json';
    }

    private function indexPath(string $direction, string $userId): string
    {
        $safe = preg_replace('/[^a-zA-Z0-9._-]/', '_', $userId) ?? $userId;

        return $this->baseDir . '/index/' . $direction . '/' . $safe . '.json';
    }

    /**
     * @return list<string>
     */
    private function listOutgoingEdgeIds(string $userId): array
    {
        return $this->readIndex($this->indexPath('outgoing', $userId));
    }

    /**
     * @return list<string>
     */
    private function listIncomingEdgeIds(string $userId): array
    {
        return $this->readIndex($this->indexPath('incoming', $userId));
    }

    /**
     * @return list<string>
     */
    private function readIndex(string $path): array
    {
        if (!is_file($path)) {
            return [];
        }
        $data = json_decode((string) file_get_contents($path), true);
        if (!is_array($data)) {
            return [];
        }

        return array_values(array_filter(array_map('strval', $data)));
    }

    /**
     * @param array<string, mixed> $edge
     */
    private function addToIndex(array $edge): void
    {
        $edgeId = (string) ($edge['id'] ?? '');
        $from = (string) ($edge['from_user'] ?? '');
        $to = (string) ($edge['to_user'] ?? '');
        if ($edgeId === '' || $from === '' || $to === '') {
            return;
        }

        $outPath = $this->indexPath('outgoing', $from);
        $inPath = $this->indexPath('incoming', $to);

        $out = $this->readIndex($outPath);
        if (!in_array($edgeId, $out, true)) {
            $out[] = $edgeId;
        }
        file_put_contents($outPath, json_encode(array_values($out), JSON_PRETTY_PRINT) . "\n");

        $in = $this->readIndex($inPath);
        if (!in_array($edgeId, $in, true)) {
            $in[] = $edgeId;
        }
        file_put_contents($inPath, json_encode(array_values($in), JSON_PRETTY_PRINT) . "\n");
    }

    /**
     * @param array<string, mixed> $edge
     */
    private function removeFromIndex(array $edge): void
    {
        $edgeId = (string) ($edge['id'] ?? '');
        $from = (string) ($edge['from_user'] ?? '');
        $to = (string) ($edge['to_user'] ?? '');
        if ($edgeId === '') {
            return;
        }

        if ($from !== '') {
            $outPath = $this->indexPath('outgoing', $from);
            $out = array_values(array_filter($this->readIndex($outPath), static fn ($id) => $id !== $edgeId));
            file_put_contents($outPath, json_encode($out, JSON_PRETTY_PRINT) . "\n");
        }
        if ($to !== '') {
            $inPath = $this->indexPath('incoming', $to);
            $in = array_values(array_filter($this->readIndex($inPath), static fn ($id) => $id !== $edgeId));
            file_put_contents($inPath, json_encode($in, JSON_PRETTY_PRINT) . "\n");
        }
    }
}
