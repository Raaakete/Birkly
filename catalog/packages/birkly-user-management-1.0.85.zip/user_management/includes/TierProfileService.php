<?php
/**
 * Links user tiers to fieldtype profiles (P77-M3).
 */

declare(strict_types=1);

require_once __DIR__ . '/UserFieldtypeProfileStore.php';
require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/SignupFieldSchema.php';

class TierProfileService
{
    private UserFieldtypeProfileStore $profiles;
    private UserStorage $storage;

    public function __construct(?UserFieldtypeProfileStore $profiles = null, ?UserStorage $storage = null)
    {
        $this->profiles = $profiles ?? new UserFieldtypeProfileStore();
        $this->storage = $storage ?? new UserStorage();
    }

    public function profileIdForTierSlug(string $tierSlug): string
    {
        return $tierSlug === 'all' ? 'default' : $tierSlug;
    }

    public function typeKeyForTierSlug(string $tierSlug): string
    {
        return $tierSlug === 'all' ? 'user_account' : 'user_account_' . $tierSlug;
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    public function upsertProfileForTier(string $tierSlug, string $tierName, array $settings): array
    {
        $profileId = $this->profileIdForTierSlug($tierSlug);
        $existing = $this->profiles->getProfile($profileId);

        $payload = [
            'id' => $profileId,
            'name' => $tierSlug === 'all'
                ? (string) ($existing['name'] ?? 'Site user account (Default)')
                : trim($tierName) . ' user account',
            'settings' => $settings,
        ];

        if ($tierSlug === 'all') {
            $payload['is_default'] = true;
            $payload['slug'] = 'default';
        } else {
            $payload['slug'] = $tierSlug;
        }

        if (is_array($existing) && !empty($existing['name']) && $tierSlug !== 'all') {
            $payload['name'] = (string) $existing['name'];
        }

        $saved = $this->profiles->saveProfile($payload);
        if (function_exists('user_management_register_fieldtype_profiles')) {
            user_management_register_fieldtype_profiles();
        }

        return $saved;
    }

    /**
     * @param array<string, mixed> $tier
     * @param array<string, mixed>|null $settings
     * @return array<string, mixed>
     */
    public function attachProfileToTier(array $tier, ?array $settings = null): array
    {
        $tierSlug = (string) ($tier['id'] ?? $tier['tier_id'] ?? '');
        if ($tierSlug === '') {
            return $tier;
        }

        $profileId = $this->profileIdForTierSlug($tierSlug);
        $typeKey = $this->typeKeyForTierSlug($tierSlug);

        if ($settings !== null) {
            $this->upsertProfileForTier($tierSlug, (string) ($tier['name'] ?? $tierSlug), $settings);
        } elseif ($this->profiles->getProfile($profileId) === null && $tierSlug !== 'all') {
            $defaultSettings = $this->profiles->getSettingsForTypeKey('user_account');
            $this->upsertProfileForTier($tierSlug, (string) ($tier['name'] ?? $tierSlug), $defaultSettings);
        }

        $tier['fieldtype_profile_id'] = $profileId;
        $tier['fieldtype_type_key'] = $typeKey;

        return $tier;
    }

    public function ensureAllTiersLinked(): void
    {
        foreach ($this->storage->listTiers() as $tier) {
            if (!is_array($tier)) {
                continue;
            }
            $tierId = (string) ($tier['id'] ?? '');
            if ($tierId === '') {
                continue;
            }
            if (!empty($tier['fieldtype_profile_id']) && !empty($tier['fieldtype_type_key'])) {
                continue;
            }
            $linked = $this->attachProfileToTier($tier);
            $this->storage->saveTier($tierId, $linked);
        }
    }

    /**
     * One-time migration: global Signup Fields → default fieldtype profile.
     */
    public function migrateSignupFieldsToDefaultProfile(): bool
    {
        $flag = $this->storage->readMetadata('signup_fields_migrated');
        if (is_array($flag) && !empty($flag['done'])) {
            return false;
        }

        $schema = new SignupFieldSchema($this->storage);
        $signupFields = $schema->getSchema()['fields'] ?? [];
        $default = $this->profiles->getProfile('default');
        if (!$default) {
            return false;
        }

        $settings = UserFieldtypeProfileStore::normalizeSettings(
            $default['settings'] ?? [],
            user_management_commerce_plugin_active()
        );

        $builtinKeys = ['email', 'password', 'name'];
        $requirements = [];
        foreach ($settings['requirements']['fields'] as $field) {
            if (!is_array($field)) {
                continue;
            }
            $requirements[(string) ($field['key'] ?? '')] = $field;
        }

        $custom = [];
        foreach ($settings['requirements']['custom_fields'] as $field) {
            if (!is_array($field)) {
                continue;
            }
            $custom[(string) ($field['key'] ?? '')] = $field;
        }

        foreach ($signupFields as $field) {
            if (!is_array($field)) {
                continue;
            }
            $slug = trim((string) ($field['slug'] ?? ''));
            if ($slug === '') {
                continue;
            }

            if (in_array($slug, $builtinKeys, true)) {
                if (!isset($requirements[$slug])) {
                    $requirements[$slug] = [
                        'key' => $slug,
                        'type' => $slug === 'email' ? 'email' : ($slug === 'password' ? 'password' : 'text'),
                        'label' => ucfirst($slug),
                        'required' => !empty($field['required']),
                        'builtin' => true,
                    ];
                } else {
                    $requirements[$slug]['required'] = !empty($field['required']);
                }
                continue;
            }

            if (isset($custom[$slug])) {
                $custom[$slug]['required'] = !empty($field['required']);
                continue;
            }

            $type = (string) ($field['type'] ?? 'text');
            if (!in_array($type, ['text', 'email', 'textarea', 'checkbox', 'number', 'tel'], true)) {
                $type = $slug === 'phone' ? 'tel' : 'text';
            }

            $custom[$slug] = [
                'key' => $slug,
                'label' => trim((string) ($field['label'] ?? $slug)),
                'type' => $type === 'tel' ? 'text' : $type,
                'required' => !empty($field['required']),
                'help' => trim((string) ($field['help_text'] ?? '')),
            ];
        }

        $settings['requirements']['fields'] = array_values($requirements);
        $settings['requirements']['custom_fields'] = array_values($custom);

        $this->profiles->saveProfile([
            'id' => 'default',
            'name' => (string) ($default['name'] ?? 'Site user account (Default)'),
            'is_default' => true,
            'settings' => $settings,
        ]);

        if (function_exists('user_management_register_fieldtype_profiles')) {
            user_management_register_fieldtype_profiles();
        }

        $this->storage->saveMetadata('signup_fields_migrated', [
            'done' => true,
            'migrated_at' => date('c'),
        ]);

        return true;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getProfileSettingsForTier(array $tier): ?array
    {
        $profileId = (string) ($tier['fieldtype_profile_id'] ?? $this->profileIdForTierSlug((string) ($tier['id'] ?? '')));
        $profile = $this->profiles->getProfile($profileId);

        return is_array($profile) ? ($profile['settings'] ?? null) : null;
    }
}
