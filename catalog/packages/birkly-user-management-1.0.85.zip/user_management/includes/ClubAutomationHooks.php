<?php
/**
 * Bridge club lifecycle hooks to Automation enqueue (P80-M6).
 */

declare(strict_types=1);

function club_automation_register_hooks(): void
{
    if (!function_exists('register_hook')) {
        return;
    }

    $clubHooks = [
        'club_profile_created',
        'club_member_onboarded',
        'club_post_created',
        'club_mention_created',
        'supporter_badge_granted',
        'club_member_reported',
    ];

    foreach ($clubHooks as $hook) {
        register_hook($hook, function (...$args) use ($hook): void {
            club_automation_dispatch($hook, club_automation_normalize_payload($args));
        });
    }

    register_hook('user_tier_changed', function ($userId, $oldTier = null, $tierId = null): void {
        club_automation_dispatch('user_tier_changed', club_automation_user_tier_payload(
            (string) $userId,
            (string) ($oldTier ?? ''),
            (string) ($tierId ?? '')
        ));
    });

    if (function_exists('add_filter')) {
        add_filter('automation_context', function (array $context): array {
            return club_automation_merge_site_context($context);
        });
    }
}

/**
 * @param list<mixed> $args
 * @return array<string, mixed>
 */
function club_automation_normalize_payload(array $args): array
{
    if ($args === []) {
        return [];
    }
    if (count($args) === 1 && is_array($args[0])) {
        return $args[0];
    }

    return ['payload' => $args];
}

/**
 * @return array<string, mixed>
 */
function club_automation_user_tier_payload(string $userId, string $oldTier, string $tierId): array
{
    $payload = [
        'user_id' => $userId,
        'old_tier' => $oldTier,
        'tier_id' => $tierId,
    ];

    return club_automation_merge_user_context($payload, $userId);
}

/**
 * @param array<string, mixed> $payload
 */
function club_automation_dispatch(string $trigger, array $payload): void
{
    if (!function_exists('enqueue_automation')) {
        return;
    }

    $userId = trim((string) ($payload['user_id'] ?? $payload['owner_id'] ?? $payload['reporter_id'] ?? ''));
    $context = club_automation_merge_user_context($payload, $userId);
    $context = club_automation_merge_site_context($context);
    $context['trigger_type'] = $trigger;

    enqueue_automation($trigger, $context);
}

/**
 * @param array<string, mixed> $context
 * @return array<string, mixed>
 */
function club_automation_merge_user_context(array $context, string $userId): array
{
    if ($userId === '') {
        return $context;
    }

    try {
        require_once __DIR__ . '/UserService.php';
        $userService = new UserService();
        $user = $userService->getUser($userId);
        if (!is_array($user)) {
            return $context;
        }
        if (empty($context['email']) && !empty($user['email'])) {
            $context['email'] = (string) $user['email'];
        }
        if (empty($context['name']) && !empty($user['name'])) {
            $context['name'] = (string) $user['name'];
        }
        if (empty($context['user_id'])) {
            $context['user_id'] = $userId;
        }
    } catch (Throwable $e) {
        error_log('Club automation user context: ' . $e->getMessage());
    }

    return $context;
}

/**
 * @param array<string, mixed> $context
 * @return array<string, mixed>
 */
function club_automation_merge_site_context(array $context): array
{
    if (empty($context['site_url']) && function_exists('user_management_site_url')) {
        $context['site_url'] = rtrim(user_management_site_url(), '/');
    }
    if (empty($context['site_name'])) {
        $context['site_name'] = club_automation_site_name();
    }

    return $context;
}

function club_automation_site_name(): string
{
    if (function_exists('get_setting')) {
        $name = trim((string) get_setting('site_name', ''));
        if ($name !== '') {
            return $name;
        }
    }

    return 'Birkly';
}
