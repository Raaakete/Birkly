<?php
/**
 * Public-read UGC filtering for collections marked user_plugin.ugc (P81-M5/M6).
 */

declare(strict_types=1);

require_once __DIR__ . '/EntryOwnership.php';
require_once __DIR__ . '/UserGraphService.php';
require_once __DIR__ . '/UserPluginCollectionConfig.php';

class UserPublicUgcFilter
{
    /**
     * @param list<array<string, mixed>> $entries
     * @return list<array<string, mixed>>
     */
    public static function filterEntries(array $entries, string $collectionSlug, ?string $userId): array
    {
        if (!UserPluginCollectionConfig::isUgcCollection($collectionSlug)) {
            return $entries;
        }

        $graph = null;
        if ($userId !== null && $userId !== '') {
            $graph = new UserGraphService();
        }

        return array_values(array_filter($entries, static function ($entry) use ($userId, $graph, $collectionSlug) {
            if (!is_array($entry)) {
                return false;
            }

            $hidden = $entry['moderation_hidden'] ?? '';
            if ($hidden === true || $hidden === '1' || $hidden === 1 || $hidden === 'true') {
                return false;
            }

            if ($graph === null || $userId === null || $userId === '') {
                return true;
            }

            $authorId = EntryOwnership::getEntryOwnerId($entry, $collectionSlug) ?? '';
            if ($authorId === '' || $authorId === $userId) {
                return true;
            }

            return !$graph->isEitherBlocked($userId, $authorId);
        }));
    }
}
