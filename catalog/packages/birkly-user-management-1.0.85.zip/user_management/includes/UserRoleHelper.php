<?php
/**
 * Site user role helpers (distinct from CMS admin roles).
 */

declare(strict_types=1);

require_once __DIR__ . '/UserStorage.php';

/**
 * Distinct role ids used by site users in UserStorage.
 *
 * @return list<string>
 */
function user_management_list_site_role_ids(): array
{
    $roles = ['member'];
    $storage = new UserStorage();
    foreach ($storage->listUsers(['deleted' => false]) as $user) {
        if (!is_array($user)) {
            continue;
        }
        $role = trim((string) ($user['role'] ?? ''));
        if ($role !== '') {
            $roles[] = $role;
        }
    }

    $roles = array_values(array_unique($roles));
    sort($roles);

    return $roles;
}
