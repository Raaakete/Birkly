<?php
/**
 * Saved user account fieldtype profiles — configured in User admin (P77).
 *
 * Type keys use `user_account` / `user_account_{slug}` so the existing `user`
 * reference fieldtype (UGC owner picker) remains unchanged.
 */

declare(strict_types=1);

require_once __DIR__ . '/UserSchema.php';

class UserFieldtypeProfileStore
{
    private string $profilesFile;

    public function __construct(?string $dataDir = null)
    {
        $dir = $dataDir ?? user_management_data_dir();
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $this->profilesFile = $dir . '/fieldtype_profiles.json';
        if (!is_file($this->profilesFile)) {
            $this->saveProfiles($this->defaultProfilesDocument());
        }
    }

    public function loadProfiles(): array
    {
        $raw = is_file($this->profilesFile) ? file_get_contents($this->profilesFile) : false;
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data) || empty($data['profiles'])) {
            return $this->defaultProfilesDocument();
        }

        return $data;
    }

    public function saveProfiles(array $data): void
    {
        file_put_contents($this->profilesFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
    }

    /** @return list<array<string, mixed>> */
    public function listProfiles(): array
    {
        $data = $this->loadProfiles();

        return array_values($data['profiles'] ?? []);
    }

    public function getProfile(string $id): ?array
    {
        $data = $this->loadProfiles();

        return $data['profiles'][$id] ?? null;
    }

    public function getProfileByTypeKey(string $typeKey): ?array
    {
        foreach ($this->listProfiles() as $profile) {
            if (($profile['type_key'] ?? '') === $typeKey) {
                return $profile;
            }
        }

        if ($typeKey === 'user_account') {
            return $this->getProfile('default');
        }

        if (str_starts_with($typeKey, 'user_account_')) {
            $slug = substr($typeKey, strlen('user_account_'));

            return $this->getProfile($slug);
        }

        return null;
    }

    public function getSettingsForTypeKey(string $typeKey): array
    {
        $profile = $this->getProfileByTypeKey($typeKey);
        if (!$profile) {
            return self::defaultSettings(user_management_commerce_plugin_active());
        }

        return self::normalizeSettings($profile['settings'] ?? [], user_management_commerce_plugin_active());
    }

    public function saveProfile(array $profile): array
    {
        $data = $this->loadProfiles();
        $id = trim((string) ($profile['id'] ?? ''));
        if ($id === '') {
            $id = $this->generateId((string) ($profile['name'] ?? 'profile'));
        }
        if ($id === 'default' && empty($profile['is_default'])) {
            $profile['is_default'] = true;
        }
        if (!empty($profile['is_default'])) {
            $id = 'default';
        }

        $slug = $this->normalizeSlug((string) ($profile['slug'] ?? $id));
        if ($id === 'default') {
            $slug = 'default';
        }

        $typeKey = $id === 'default' ? 'user_account' : 'user_account_' . $slug;

        $saved = [
            'id' => $id,
            'slug' => $slug,
            'name' => trim((string) ($profile['name'] ?? 'Site user account')),
            'type_key' => $typeKey,
            'is_default' => ($id === 'default'),
            'settings' => self::normalizeSettings($profile['settings'] ?? [], user_management_commerce_plugin_active()),
            'updated_at' => date('c'),
        ];

        if (empty($data['profiles'][$id]['created_at'])) {
            $saved['created_at'] = date('c');
        } else {
            $saved['created_at'] = $data['profiles'][$id]['created_at'];
        }

        $data['profiles'][$id] = $saved;
        $this->saveProfiles($data);

        return $saved;
    }

    public function deleteProfile(string $id): bool
    {
        if ($id === 'default') {
            return false;
        }
        $data = $this->loadProfiles();
        if (!isset($data['profiles'][$id])) {
            return false;
        }
        unset($data['profiles'][$id]);
        $this->saveProfiles($data);

        return true;
    }

    public function cloneProfile(string $sourceId, string $name): array
    {
        $source = $this->getProfile($sourceId) ?? $this->getProfile('default');
        if (!$source) {
            $source = $this->defaultProfilesDocument()['profiles']['default'];
        }

        return $this->saveProfile([
            'name' => $name,
            'settings' => $source['settings'] ?? [],
        ]);
    }

    public static function defaultSettings(bool $commerceActive = false): array
    {
        $settings = [
            'requirements' => [
                'fields' => UserSchema::defaultRequirementFields(),
                'custom_fields' => [],
            ],
            'social' => [
                'enable_following' => true,
                'enable_connections' => true,
                'enable_blocks' => true,
                'auto_connect_on_mutual_follow' => false,
            ],
            'privacy' => [
                'default_visibility' => UserSchema::VISIBILITY_MEMBERS,
                'directory_listed' => true,
                'allowed_visibility_options' => UserSchema::visibilityOptions(),
            ],
            'commerce' => [
                'payment_required_at_signup' => false,
                'payment_enabled' => true,
                'membership_product_ref' => null,
            ],
        ];

        if (!$commerceActive) {
            unset($settings['commerce']);
        }

        return $settings;
    }

    public static function normalizeSettings(array $settings, bool $commerceActive = false): array
    {
        $defaults = self::defaultSettings($commerceActive);
        $merged = array_replace_recursive($defaults, $settings);

        $merged['requirements']['fields'] = self::normalizeRequirementFields($merged['requirements']['fields'] ?? []);
        $merged['requirements']['custom_fields'] = self::normalizeCustomFields($merged['requirements']['custom_fields'] ?? []);

        $visibility = (string) ($merged['privacy']['default_visibility'] ?? UserSchema::VISIBILITY_MEMBERS);
        if (!in_array($visibility, UserSchema::visibilityOptions(), true)) {
            $visibility = UserSchema::VISIBILITY_MEMBERS;
        }
        $merged['privacy']['default_visibility'] = $visibility;

        $allowed = array_values(array_filter(
            (array) ($merged['privacy']['allowed_visibility_options'] ?? UserSchema::visibilityOptions()),
            static fn ($v) => in_array($v, UserSchema::visibilityOptions(), true)
        ));
        if ($allowed === []) {
            $allowed = UserSchema::visibilityOptions();
        }
        $merged['privacy']['allowed_visibility_options'] = $allowed;
        $merged['privacy']['directory_listed'] = !empty($merged['privacy']['directory_listed']);

        $merged['social']['enable_following'] = !empty($merged['social']['enable_following']);
        $merged['social']['enable_connections'] = !empty($merged['social']['enable_connections']);
        $merged['social']['enable_blocks'] = !empty($merged['social']['enable_blocks']);
        $merged['social']['auto_connect_on_mutual_follow'] = !empty($merged['social']['auto_connect_on_mutual_follow']);

        if ($commerceActive) {
            $merged['commerce']['payment_required_at_signup'] = !empty($merged['commerce']['payment_required_at_signup']);
            $merged['commerce']['payment_enabled'] = array_key_exists('payment_enabled', $merged['commerce'] ?? [])
                ? !empty($merged['commerce']['payment_enabled'])
                : true;
            $ref = trim((string) ($merged['commerce']['membership_product_ref'] ?? ''));
            $merged['commerce']['membership_product_ref'] = $ref !== '' ? $ref : null;
        } else {
            unset($merged['commerce']);
        }

        return $merged;
    }

    /** @param mixed $fields */
    private static function normalizeRequirementFields($fields): array
    {
        $builtinKeys = [];
        foreach (UserSchema::defaultRequirementFields() as $field) {
            $builtinKeys[$field['key']] = $field;
        }

        $normalized = [];
        foreach ((array) $fields as $field) {
            if (!is_array($field)) {
                continue;
            }
            $key = trim((string) ($field['key'] ?? ''));
            if ($key === '' || !preg_match('/^[a-z0-9_]+$/', $key)) {
                continue;
            }
            if (isset($builtinKeys[$key])) {
                $base = $builtinKeys[$key];
                $base['required'] = array_key_exists('required', $field) ? !empty($field['required']) : $base['required'];
                $normalized[] = $base;
                unset($builtinKeys[$key]);
                continue;
            }
        }

        foreach ($builtinKeys as $remaining) {
            $normalized[] = $remaining;
        }

        usort($normalized, static function (array $a, array $b): int {
            $order = ['email' => 0, 'password' => 1, 'name' => 2];

            return ($order[$a['key']] ?? 99) <=> ($order[$b['key']] ?? 99);
        });

        return $normalized;
    }

    /** @param mixed $fields */
    private static function normalizeCustomFields($fields): array
    {
        $custom = [];
        foreach ((array) $fields as $cf) {
            if (!is_array($cf)) {
                continue;
            }
            $key = trim((string) ($cf['key'] ?? ''));
            if ($key === '' || !preg_match('/^[a-z0-9_]+$/', $key)) {
                continue;
            }
            $type = (string) ($cf['type'] ?? 'text');
            if (!in_array($type, ['text', 'email', 'textarea', 'checkbox', 'number'], true)) {
                $type = 'text';
            }
            $custom[] = [
                'key' => $key,
                'label' => trim((string) ($cf['label'] ?? $key)),
                'type' => $type,
                'required' => !empty($cf['required']),
                'help' => trim((string) ($cf['help'] ?? '')),
            ];
        }

        return $custom;
    }

    private function defaultProfilesDocument(): array
    {
        return [
            'profiles' => [
                'default' => [
                    'id' => 'default',
                    'slug' => 'default',
                    'name' => 'Site user account (Default)',
                    'type_key' => 'user_account',
                    'is_default' => true,
                    'settings' => self::defaultSettings(user_management_commerce_plugin_active()),
                    'created_at' => date('c'),
                    'updated_at' => date('c'),
                ],
            ],
        ];
    }

    private function generateId(string $name): string
    {
        $base = $this->normalizeSlug($name);
        $data = $this->loadProfiles();
        $id = $base;
        $i = 2;
        while (isset($data['profiles'][$id])) {
            $id = $base . '_' . $i;
            $i++;
        }

        return $id;
    }

    private function normalizeSlug(string $slug): string
    {
        $slug = strtolower(trim($slug));
        $slug = preg_replace('/[^a-z0-9_]+/', '_', $slug) ?? '';
        $slug = trim($slug, '_');
        if ($slug === '' || $slug === 'default') {
            $slug = 'profile_' . bin2hex(random_bytes(3));
        }

        return $slug;
    }
}

/**
 * Whether Commerce plugin is active (shelf available).
 */
function user_management_commerce_plugin_active(): bool
{
    if (array_key_exists('user_management_test_commerce_active', $GLOBALS)) {
        return (bool) $GLOBALS['user_management_test_commerce_active'];
    }

    if (function_exists('is_plugin_active')) {
        return is_plugin_active('commerce') || is_plugin_active('birkly_commerce');
    }

    return is_dir(user_management_cms_path('plugins/commerce'))
        || is_dir(user_management_cms_path('data/plugins/commerce'));
}
