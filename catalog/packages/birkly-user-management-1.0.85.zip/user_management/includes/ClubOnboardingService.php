<?php
/**
 * Club member onboarding (P80-M2).
 */

declare(strict_types=1);

require_once __DIR__ . '/ClubProfileService.php';

/**
 * Resolve member email for automation payloads (P80-M6).
 */
function club_automation_member_email(string $userId): string
{
    if ($userId === '') {
        return '';
    }
    try {
        require_once __DIR__ . '/UserService.php';
        $user = (new UserService())->getUser($userId);
        if (is_array($user) && !empty($user['email'])) {
            return (string) $user['email'];
        }
    } catch (Throwable $e) {
        return '';
    }

    return '';
}

class ClubOnboardingService
{
    private ClubProfileService $profiles;

    public function __construct(?ClubProfileService $profiles = null)
    {
        $this->profiles = $profiles ?? new ClubProfileService();
    }

    /**
     * @return array<string, mixed>
     */
    public function getStatus(string $userId): array
    {
        $profile = $this->profiles->getProfileByUserId($userId);
        if ($profile === null) {
            return [
                'onboarding_completed' => false,
                'profile_completeness' => 0,
                'needs_onboarding' => true,
                'steps' => [
                    'avatar' => false,
                    'bio' => false,
                    'links' => false,
                    'interests' => false,
                ],
                'slug' => '',
            ];
        }

        $completeness = (int) ($profile['profile_completeness'] ?? $this->profiles->computeCompleteness($profile));

        return [
            'onboarding_completed' => $this->isOnboardingCompleted($profile),
            'profile_completeness' => $completeness,
            'needs_onboarding' => !$this->isOnboardingCompleted($profile),
            'steps' => $this->profiles->completenessSteps($profile),
            'slug' => trim((string) ($profile['slug'] ?? '')),
        ];
    }

    /**
     * @param array<string, mixed> $fields
     *
     * @return array<string, mixed>
     */
    public function completeOnboarding(string $userId, array $fields): array
    {
        $existing = $this->profiles->getProfileByUserId($userId);
        $title = trim((string) ($fields['title'] ?? $fields['name'] ?? ''));
        if ($title === '' && is_array($existing)) {
            $title = trim((string) ($existing['title'] ?? ''));
        }
        if ($title === '') {
            throw new InvalidArgumentException('Display name is required');
        }

        $saveFields = [
            'title' => $title,
            'onboarding_completed' => true,
        ];
        foreach (['bio', 'description', 'website', 'links', 'interests', 'avatar'] as $key) {
            if (array_key_exists($key, $fields)) {
                $saveFields[$key] = $fields[$key];
            }
        }

        $profile = $this->profiles->saveProfileForUser($userId, $saveFields);
        $completeness = (int) ($profile['profile_completeness'] ?? $this->profiles->computeCompleteness($profile));

        if (function_exists('do_action')) {
            do_action('club_member_onboarded', [
                'user_id' => $userId,
                'completeness' => $completeness,
                'slug' => (string) ($profile['slug'] ?? ''),
                'profile_slug' => (string) ($profile['slug'] ?? ''),
                'email' => club_automation_member_email($userId),
            ]);
        }

        return [
            'success' => true,
            'club_profile' => $profile,
            'onboarding_status' => $this->getStatus($userId),
        ];
    }

    /**
     * @param array<string, mixed> $profile
     */
    private function isOnboardingCompleted(array $profile): bool
    {
        $value = $profile['onboarding_completed'] ?? false;

        return $value === true
            || $value === 1
            || in_array(strtolower(trim((string) $value)), ['1', 'true', 'yes'], true);
    }
}
