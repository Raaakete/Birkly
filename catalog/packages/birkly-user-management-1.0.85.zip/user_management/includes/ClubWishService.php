<?php
/**
 * Club wish lifecycle — status validation and roadmap promotion (P80-M5).
 */

declare(strict_types=1);

class ClubWishService
{
    public const COLLECTION = 'club-wishes';

    public const STATUS_PENDING = 'pending';
    public const STATUS_UNDER_REVIEW = 'under_review';
    public const STATUS_PLANNED = 'planned';
    public const STATUS_SHIPPED = 'shipped';
    public const STATUS_DECLINED = 'declined';

    /** @var list<string> */
    public const VALID_STATUSES = [
        self::STATUS_PENDING,
        self::STATUS_UNDER_REVIEW,
        self::STATUS_PLANNED,
        self::STATUS_SHIPPED,
        self::STATUS_DECLINED,
    ];

    public function normalizeStatus(string $status): string
    {
        $status = strtolower(trim($status));
        $legacy = [
            'accepted' => self::STATUS_PLANNED,
            'approved' => self::STATUS_PLANNED,
            'rejected' => self::STATUS_DECLINED,
            'denied' => self::STATUS_DECLINED,
        ];
        if (isset($legacy[$status])) {
            return $legacy[$status];
        }
        if (in_array($status, self::VALID_STATUSES, true)) {
            return $status;
        }

        return self::STATUS_PENDING;
    }

    public function isValidStatus(string $status): bool
    {
        return in_array($this->normalizeStatus($status), self::VALID_STATUSES, true);
    }

    /**
     * @param array<string, mixed> $entry
     * @return array<string, mixed>
     */
    public function sanitizeWishEntry(array $entry, bool $isNew): array
    {
        $status = $this->normalizeStatus((string) ($entry['status'] ?? self::STATUS_PENDING));
        if ($isNew) {
            $status = self::STATUS_PENDING;
        }
        $entry['status'] = $status;

        if ($status === self::STATUS_DECLINED) {
            $reason = trim((string) ($entry['decline_reason'] ?? ''));
            if ($reason !== '') {
                $entry['decline_reason'] = mb_substr($reason, 0, 2000);
            }
        } else {
            unset($entry['decline_reason']);
        }

        if (in_array($status, [self::STATUS_PLANNED, self::STATUS_SHIPPED], true)) {
            $link = trim((string) ($entry['roadmap_link'] ?? ''));
            if ($link !== '') {
                $entry['roadmap_link'] = mb_substr($link, 0, 200);
            }
        } else {
            unset($entry['roadmap_link']);
        }

        return $entry;
    }

    /**
     * @return array{ok: bool, roadmap_entry_id?: string, roadmap_slug?: string, error?: string}
     */
    public function promoteToRoadmap(string $wishId): array
    {
        $wish = $this->readWishEntry($wishId);
        if ($wish === null) {
            return ['ok' => false, 'error' => 'Wish not found'];
        }

        $title = trim((string) ($wish['title'] ?? ''));
        if ($title === '') {
            return ['ok' => false, 'error' => 'Wish has no title'];
        }

        $body = trim(strip_tags((string) ($wish['body'] ?? '')));
        $slug = $this->slugify($title);
        $entryId = 'roadmap_' . bin2hex(random_bytes(6));
        $roadmapEntry = [
            'id' => $entryId,
            'title' => $title,
            'slug' => $slug,
            'status' => 'draft',
            'heading' => $title,
            'description' => $body !== '' ? $body : $title,
            'tag' => 'From community wish',
            'created_at' => date('c'),
            'updated_at' => date('c'),
        ];

        if (!$this->writeRoadmapEntry($entryId, $roadmapEntry)) {
            return ['ok' => false, 'error' => 'Could not create roadmap draft'];
        }

        $wishIdKey = (string) ($wish['id'] ?? $wishId);
        $wish['status'] = self::STATUS_PLANNED;
        $wish['roadmap_link'] = $slug;
        $wish['updated_at'] = date('c');
        $this->writeWishEntry($wishIdKey, $wish);

        return [
            'ok' => true,
            'roadmap_entry_id' => $entryId,
            'roadmap_slug' => $slug,
        ];
    }

    private function slugify(string $title): string
    {
        $slug = strtolower(trim($title));
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug) ?? '';
        $slug = trim($slug, '-');
        if ($slug === '') {
            $slug = 'wish-' . substr(bin2hex(random_bytes(4)), 0, 8);
        }

        return $slug;
    }

    /**
     * @return ?array<string, mixed>
     */
    private function readWishEntry(string $wishId): ?array
    {
        return $this->readCollectionEntry(self::COLLECTION, $wishId);
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function writeWishEntry(string $wishId, array $entry): bool
    {
        return $this->writeCollectionEntry(self::COLLECTION, $wishId, $entry);
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function writeRoadmapEntry(string $entryId, array $entry): bool
    {
        return $this->writeCollectionEntry('roadmap-features', $entryId, $entry);
    }

    /**
     * @return ?array<string, mixed>
     */
    private function readCollectionEntry(string $collectionSlug, string $entryId): ?array
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));

        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== $collectionSlug) {
                continue;
            }
            $path = "collections/{$dir}/entries/{$entryId}.json";
            $entry = $storage->read($path);
            if (is_array($entry)) {
                return $entry;
            }
            foreach ($storage->list("collections/{$dir}/entries") as $file) {
                if (!str_ends_with($file, '.json')) {
                    continue;
                }
                $candidate = $storage->read("collections/{$dir}/entries/{$file}");
                if (!is_array($candidate)) {
                    continue;
                }
                if ((string) ($candidate['id'] ?? '') === $entryId || (string) ($candidate['slug'] ?? '') === $entryId) {
                    return $candidate;
                }
            }
            break;
        }

        return null;
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function writeCollectionEntry(string $collectionSlug, string $entryId, array $entry): bool
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $writeId = (string) ($entry['id'] ?? $entryId);

        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== $collectionSlug) {
                continue;
            }
            $path = "collections/{$dir}/entries/{$writeId}.json";

            return $storage->write($path, $entry);
        }

        return false;
    }
}
