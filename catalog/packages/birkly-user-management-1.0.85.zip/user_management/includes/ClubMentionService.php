<?php
/**
 * Backward-compat shim — use UserMentionService (P81-M8).
 */

declare(strict_types=1);

require_once __DIR__ . '/UserMentionService.php';
