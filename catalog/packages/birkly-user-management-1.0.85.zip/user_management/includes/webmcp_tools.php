<?php
/**
 * User Management WebMCP catalog — visitor session / sign-in tools.
 *
 * Separate from inbound Birkly MCP. Register with `birkly_webmcp_register_tools()`.
 * Runtime handlers live in `assets/webmcp-pack.js` (registered via
 * `includes/webmcp_runtime.php`) and prefer `window.BirklyUser`.
 */

declare(strict_types=1);

/**
 * @return list<array{id:string,kind:string,mutating:bool,consent:string,default:bool,label:string,description:string}>
 */
function user_management_webmcp_tool_catalog(): array
{
    return [
        [
            'id' => 'birkly_user_session',
            'kind' => 'read',
            'mutating' => false,
            'consent' => 'none',
            'default' => false,
            'label' => 'Check sign-in',
            'description' => 'Lets an AI helper see whether the visitor is signed in.',
        ],
        [
            'id' => 'birkly_user_login',
            'kind' => 'write',
            'mutating' => true,
            'consent' => 'login',
            'default' => false,
            'label' => 'Sign in',
            'description' => 'Lets an AI helper start sign-in — off unless you opt in, and always confirmed.',
        ],
    ];
}
