<?php
/**
 * Batch club notification digests (P80-M3).
 */

declare(strict_types=1);

require_once __DIR__ . '/ClubNotificationService.php';
require_once __DIR__ . '/ClubProfileService.php';
require_once __DIR__ . '/UserEmailService.php';
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/UserStorage.php';

class ClubNotificationDigestService
{
    private const MAX_ITEMS = 20;

    private ClubNotificationService $notifications;
    private ClubProfileService $profiles;

    public function __construct(
        ?ClubNotificationService $notifications = null,
        ?ClubProfileService $profiles = null
    ) {
        $this->notifications = $notifications ?? new ClubNotificationService();
        $this->profiles = $profiles ?? new ClubProfileService();
    }

    /**
     * @return array{sent: int, skipped: int, errors: list<string>}
     */
    public function processDueDigests(?string $frequencyFilter = null): array
    {
        $sent = 0;
        $skipped = 0;
        $errors = [];

        foreach ($this->notifications->listClubMemberUserIds() as $userId) {
            try {
                $result = $this->processUserIfDue($userId, $frequencyFilter);
                if ($result === 'sent') {
                    $sent++;
                } else {
                    $skipped++;
                }
            } catch (Throwable $e) {
                $errors[] = $userId . ': ' . $e->getMessage();
            }
        }

        return ['sent' => $sent, 'skipped' => $skipped, 'errors' => $errors];
    }

    /**
     * @return array{sent: bool, item_count: int}
     */
    public function sendDigestForUser(string $userId, bool $force = false): array
    {
        $prefs = $this->digestPreferences($userId);
        if (!$force && empty($prefs['digest_enabled'])) {
            return ['sent' => false, 'item_count' => 0];
        }

        $since = (string) ($prefs['digest_last_sent_at'] ?? '');
        if (!$force && !$this->isDue($since, (string) ($prefs['digest_frequency'] ?? 'weekly'))) {
            return ['sent' => false, 'item_count' => 0];
        }

        $items = $this->notifications->listUnreadSince($userId, $since, self::MAX_ITEMS);
        if ($items === []) {
            return ['sent' => false, 'item_count' => 0];
        }

        $this->sendDigestEmail($userId, $items, count($items));
        $this->updateDigestLastSent($userId);

        return ['sent' => true, 'item_count' => count($items)];
    }

    private function processUserIfDue(string $userId, ?string $frequencyFilter): string
    {
        $prefs = $this->digestPreferences($userId);
        if (empty($prefs['digest_enabled'])) {
            return 'skipped';
        }

        $frequency = (string) ($prefs['digest_frequency'] ?? 'weekly');
        if ($frequencyFilter !== null && $frequencyFilter !== '' && $frequency !== $frequencyFilter) {
            return 'skipped';
        }

        $result = $this->sendDigestForUser($userId, false);

        return !empty($result['sent']) ? 'sent' : 'skipped';
    }

    /**
     * @return array<string, mixed>
     */
    private function digestPreferences(string $userId): array
    {
        $prefs = $this->notifications->preferencesFromProfile($this->profiles->getProfileByUserId($userId));

        return [
            'digest_enabled' => !empty($prefs['digest_enabled']),
            'digest_frequency' => in_array((string) ($prefs['digest_frequency'] ?? 'weekly'), ['daily', 'weekly'], true)
                ? (string) $prefs['digest_frequency']
                : 'weekly',
            'digest_last_sent_at' => (string) ($prefs['digest_last_sent_at'] ?? ''),
        ];
    }

    private function isDue(string $lastSentAt, string $frequency): bool
    {
        if ($lastSentAt === '') {
            return true;
        }
        $last = strtotime($lastSentAt);
        if ($last === false) {
            return true;
        }

        $interval = $frequency === 'daily' ? 86400 : 604800;

        return (time() - $last) >= $interval;
    }

    /**
     * @param list<array<string, mixed>> $items
     */
    private function sendDigestEmail(string $userId, array $items, int $itemCount): void
    {
        $user = (new UserService(new UserStorage()))->getUser($userId);
        if (!is_array($user)) {
            return;
        }
        $email = trim((string) ($user['email'] ?? ''));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return;
        }

        $lines = [];
        foreach ($items as $item) {
            $lines[] = '• ' . trim((string) ($item['title'] ?? 'Club update'));
        }
        $summary = implode("\n", $lines);

        $siteUrl = '';
        if (function_exists('birkly_site_public_url')) {
            $siteUrl = rtrim((string) birkly_site_public_url(), '/');
        }
        $clubLink = ($siteUrl !== '' ? $siteUrl : '') . '/club.html#feed';

        (new UserEmailService())->send('club_notification_digest', $email, [
            'member_name' => trim((string) ($user['name'] ?? 'Club member')),
            'digest_item_count' => (string) $itemCount,
            'digest_summary' => $summary,
            'club_link' => $clubLink,
        ]);
    }

    private function updateDigestLastSent(string $userId): void
    {
        $profile = $this->profiles->getProfileByUserId($userId);
        $prefs = $this->notifications->preferencesFromProfile($profile);
        $prefs['digest_last_sent_at'] = date('c');
        $title = trim((string) ($profile['title'] ?? 'Club member'));
        $fields = is_array($profile) ? [
            'title' => $title,
            'bio' => (string) ($profile['bio'] ?? ''),
            'description' => (string) ($profile['description'] ?? ''),
            'website' => (string) ($profile['website'] ?? ''),
            'links' => (string) ($profile['links'] ?? ''),
            'interests' => (string) ($profile['interests'] ?? ''),
        ] : ['title' => $title];
        $fields['notification_prefs'] = json_encode($prefs, JSON_UNESCAPED_UNICODE);
        $this->profiles->saveProfileForUser($userId, $fields);
    }
}
