<?php
/**
 * Read user_plugin markers from collection.json (P81-M5).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';

class UserPluginCollectionConfig
{
    /** @var array<string, array<string, mixed>|null> */
    private static array $cache = [];

    /**
     * @return array<string, mixed>
     */
    public static function forCollection(string $collectionSlug): array
    {
        $collectionSlug = trim($collectionSlug);
        if ($collectionSlug === '') {
            return [];
        }

        if (array_key_exists($collectionSlug, self::$cache)) {
            return self::$cache[$collectionSlug] ?? [];
        }

        $config = [];
        if (function_exists('birkly_entry_read_collection_meta')) {
            $meta = birkly_entry_read_collection_meta($collectionSlug);
            if (is_array($meta) && isset($meta['user_plugin']) && is_array($meta['user_plugin'])) {
                $config = $meta['user_plugin'];
            }
        } else {
            $path = user_management_resolve_collection_json_path($collectionSlug);
            if ($path !== null) {
                $meta = json_decode((string) file_get_contents($path), true);
                if (is_array($meta) && isset($meta['user_plugin']) && is_array($meta['user_plugin'])) {
                    $config = $meta['user_plugin'];
                }
            }
        }

        self::$cache[$collectionSlug] = $config;

        return $config;
    }

    public static function isUgcCollection(string $collectionSlug): bool
    {
        $config = self::forCollection($collectionSlug);

        return !empty($config['ugc']);
    }

    public static function mentionsEnabled(string $collectionSlug): bool
    {
        $config = self::forCollection($collectionSlug);

        return !empty($config['mentions_enabled']);
    }

    public static function notificationsEnabled(string $collectionSlug, string $type): bool
    {
        $config = self::forCollection($collectionSlug);
        $notifications = $config['notifications'] ?? [];
        if (!is_array($notifications)) {
            return false;
        }

        return in_array($type, $notifications, true);
    }

    public static function resetCache(): void
    {
        self::$cache = [];
    }
}
