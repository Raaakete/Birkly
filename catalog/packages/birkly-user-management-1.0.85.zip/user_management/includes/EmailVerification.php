<?php
/**
 * EmailVerification - Email verification system
 * 
 * Handles:
 * - Verification token generation
 * - Email sending
 * - Token validation
 * - Admin approval workflow
 */

require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/UserEmailService.php';

class EmailVerification {
    private $storage;
    private $service;
    private UserEmailService $emailService;
    
    public function __construct() {
        $this->storage = new UserStorage();
        $this->service = new UserService();
        $this->emailService = new UserEmailService();
    }
    
    /**
     * Generate verification token
     * 
     * @param string $user_id User ID
     * @return string Token
     */
    public function generateToken($user_id) {
        // Generate secure random token
        $token = bin2hex(random_bytes(32));
        
        // Store token with expiration (24 hours)
        $tokenData = [
            'user_id' => $user_id,
            'token' => $token,
            'created_at' => date('c'),
            'expires_at' => date('c', strtotime('+24 hours')),
            'used' => false
        ];
        
        $this->storage->saveVerificationToken($user_id, $tokenData);
        
        return $token;
    }
    
    /**
     * Send verification email
     * 
     * @param string $user_id User ID
     * @param string $email User email
     * @param string $token Verification token
     * @return bool Success
     */
    public function sendVerificationEmail($user_id, $email, $token) {
        // Get site URL from settings or use default
        $siteUrl = $this->getSiteUrl();
        $verificationUrl = $siteUrl . '/verify-email?token=' . urlencode($token) . '&user=' . urlencode($user_id);
        
        return $this->emailService->send('verification', $email, [
            'verification_url' => $verificationUrl,
            'token' => $token,
            'user_id' => $user_id,
        ]);
    }
    
    /**
     * Verify token and activate user
     * 
     * @param string $token Verification token
     * @param string $user_id User ID
     * @return array Result with status and message
     */
    public function verifyToken($token, $user_id) {
        // Get token data
        $tokenData = $this->storage->getVerificationToken($user_id);
        
        if (!$tokenData) {
            return [
                'success' => false,
                'message' => 'Invalid verification token'
            ];
        }
        
        // Check if token matches
        if ($tokenData['token'] !== $token) {
            return [
                'success' => false,
                'message' => 'Invalid verification token'
            ];
        }
        
        // Check if token is expired
        $expiresAt = strtotime($tokenData['expires_at']);
        if (time() > $expiresAt) {
            return [
                'success' => false,
                'message' => 'Verification token has expired. Please request a new one.'
            ];
        }
        
        // Check if token already used
        if ($tokenData['used']) {
            return [
                'success' => false,
                'message' => 'This verification link has already been used'
            ];
        }
        
        // Mark token as used
        $tokenData['used'] = true;
        $tokenData['verified_at'] = date('c');
        $this->storage->saveVerificationToken($user_id, $tokenData);
        
        // Update user as verified
        $user = $this->service->getUser($user_id);
        if ($user) {
            $verifiedAt = date('c');
            $this->service->updateUser($user_id, [
                'verified' => true,
                'verified_at' => $verifiedAt
            ]);
            $user['verified'] = true;
            $user['verified_at'] = $verifiedAt;

            if (function_exists('do_action')) {
                do_action('user_email_verified', $user);
            }
        }
        
        return [
            'success' => true,
            'message' => 'Email verified successfully'
        ];
    }
    
    /**
     * Resend verification email
     * 
     * @param string $user_id User ID
     * @return array Result with status and message
     */
    public function resendVerificationEmail($user_id) {
        $user = $this->service->getUser($user_id);
        if (!$user) {
            return [
                'success' => false,
                'message' => 'User not found'
            ];
        }
        
        // Check if already verified
        if (!empty($user['verified'])) {
            return [
                'success' => false,
                'message' => 'Email is already verified'
            ];
        }
        
        // Generate new token
        $token = $this->generateToken($user_id);
        
        // Send email
        $email = $user['email'] ?? '';
        if (empty($email)) {
            return [
                'success' => false,
                'message' => 'User email not found'
            ];
        }
        
        $sent = $this->sendVerificationEmail($user_id, $email, $token);
        
        if ($sent) {
            return [
                'success' => true,
                'message' => 'Verification email sent'
            ];
        } else {
            return [
                'success' => false,
                'message' => 'Failed to send verification email'
            ];
        }
    }
    
    /**
     * Get site URL
     * 
     * @return string Site URL
     */
    private function getSiteUrl() {
        if (!function_exists('user_management_site_url')) {
            require_once dirname(__DIR__) . '/cms_paths.php';
        }

        return user_management_site_url();
    }
    
    /**
     * Get email subject
     * 
     * @param string $type Email type
     * @return string Subject
     */
    private function getEmailSubject($type) {
        $subjects = [
            'verification' => 'Verify your email address',
            'password_reset' => 'Reset your password',
            'account_activation' => 'Activate your community access',
            'welcome' => 'Welcome!'
        ];
        
        return $subjects[$type] ?? 'Email from ' . $this->getSiteName();
    }
    
    /**
     * Send password reset email
     * 
     * @param string $user_id User ID
     * @param string $email User email
     * @param string $token Reset token
     * @param string $resetUrl Reset URL
     * @return bool Success
     */
    public function sendPasswordResetEmail($user_id, $email, $token, $resetUrl) {
        return $this->emailService->send('password_reset', $email, [
            'reset_url' => $resetUrl,
            'token' => $token,
            'user_id' => $user_id,
        ]);
    }

    /**
     * Send membership / community account activation email.
     */
    public function sendAccountActivationEmail($email, $activationUrl, $tierId = 'club') {
        return $this->emailService->send('account_activation', $email, [
            'activation_url' => $activationUrl,
            'tier_id' => $tierId,
        ]);
    }

    /**
     * Send club / membership welcome when the site account already exists.
     *
     * @param array<string, mixed> $payload
     */
    public function sendMembershipWelcomeEmail(string $email, string $tierId = 'club', array $payload = []): bool
    {
        if (!function_exists('user_management_site_url')) {
            require_once dirname(__DIR__) . '/cms_paths.php';
        }

        $clubUrl = user_management_site_url() . '/club.html';

        return $this->emailService->send('welcome', $email, [
            'tier_id' => $tierId,
            'club_url' => $clubUrl,
            'order_id' => (string) ($payload['order_id'] ?? ''),
        ]);
    }

    public function getEmailService(): UserEmailService
    {
        return $this->emailService;
    }
    
    /**
     * Get email template
     * 
     * @param string $type Email type
     * @param array $data Template data
     * @return string Email body
     */
    private function getEmailTemplate($type, $data = []) {
        // Check for custom template
        $templatePath = __DIR__ . '/../templates/emails/' . $type . '.html';
        if (file_exists($templatePath)) {
            $template = file_get_contents($templatePath);
            // Replace placeholders
            foreach ($data as $key => $value) {
                $template = str_replace('{' . $key . '}', htmlspecialchars($value), $template);
            }
            return $template;
        }
        
        // Default templates
        switch ($type) {
            case 'verification':
                return $this->getDefaultVerificationTemplate($data);
            case 'password_reset':
                return $this->getDefaultPasswordResetTemplate($data);
            case 'account_activation':
                return $this->getDefaultAccountActivationTemplate($data);
            case 'welcome':
                return $this->getDefaultWelcomeTemplate($data);
            default:
                return 'Email from ' . $this->getSiteName();
        }
    }
    
    /**
     * Get default verification email template
     */
    private function getDefaultVerificationTemplate($data) {
        $url = $data['verification_url'] ?? '#';
        $siteName = $this->getSiteName();
        
        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Verify your email</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #2c3e50;">Verify your email address</h1>
        <p>Thank you for signing up for {$siteName}!</p>
        <p>Please click the button below to verify your email address:</p>
        <p style="text-align: center; margin: 30px 0;">
            <a href="{$url}" style="display: inline-block; padding: 12px 24px; background-color: #3498db; color: white; text-decoration: none; border-radius: 5px;">Verify Email</a>
        </p>
        <p>Or copy and paste this link into your browser:</p>
        <p style="word-break: break-all; color: #7f8c8d;">{$url}</p>
        <p style="color: #7f8c8d; font-size: 12px; margin-top: 30px;">
            This link will expire in 24 hours. If you didn't create an account, you can safely ignore this email.
        </p>
    </div>
</body>
</html>
HTML;
    }
    
    /**
     * Get default password reset email template
     */
    private function getDefaultPasswordResetTemplate($data) {
        $url = $data['reset_url'] ?? '#';
        $siteName = $this->getSiteName();
        
        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Reset your password</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #2c3e50;">Reset your password</h1>
        <p>You requested to reset your password for {$siteName}.</p>
        <p>Click the button below to reset your password:</p>
        <p style="text-align: center; margin: 30px 0;">
            <a href="{$url}" style="display: inline-block; padding: 12px 24px; background-color: #e74c3c; color: white; text-decoration: none; border-radius: 5px;">Reset Password</a>
        </p>
        <p>Or copy and paste this link into your browser:</p>
        <p style="word-break: break-all; color: #7f8c8d;">{$url}</p>
        <p style="color: #7f8c8d; font-size: 12px; margin-top: 30px;">
            This link will expire in 1 hour. If you didn't request a password reset, you can safely ignore this email.
        </p>
    </div>
</body>
</html>
HTML;
    }

    private function getDefaultAccountActivationTemplate($data) {
        $url = $data['activation_url'] ?? '#';
        $siteName = $this->getSiteName();

        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Activate your access</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #2c3e50;">Activate your community access</h1>
        <p>Thank you for supporting {$siteName}.</p>
        <p>Click below to set your password and join the member community:</p>
        <p style="text-align: center; margin: 30px 0;">
            <a href="{$url}" style="display: inline-block; padding: 12px 24px; background-color: #3498db; color: white; text-decoration: none; border-radius: 5px;">Activate access</a>
        </p>
        <p>Or copy and paste this link into your browser:</p>
        <p style="word-break: break-all; color: #7f8c8d;">{$url}</p>
        <p style="color: #7f8c8d; font-size: 12px; margin-top: 30px;">
            This link expires in 72 hours. If you did not request community access, you can ignore this email.
        </p>
    </div>
</body>
</html>
HTML;
    }
    
    /**
     * Get default welcome email template
     */
    private function getDefaultWelcomeTemplate($data) {
        $siteName = $this->getSiteName();
        $clubUrl = htmlspecialchars((string) ($data['club_url'] ?? ''), ENT_QUOTES, 'UTF-8');
        $clubLink = $clubUrl !== ''
            ? '<p style="text-align: center; margin: 30px 0;"><a href="' . $clubUrl . '" style="display: inline-block; padding: 12px 24px; background-color: #3498db; color: white; text-decoration: none; border-radius: 5px;">Visit the Club</a></p>'
            : '';
        
        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #2c3e50;">Welcome to {$siteName} Club!</h1>
        <p>Thank you for your support. Your membership is active and your community access is ready.</p>
        {$clubLink}
        <p>If you have any questions, feel free to reach out to us.</p>
        <p style="color: #7f8c8d; font-size: 12px; margin-top: 30px;">
            Best regards,<br>
            The {$siteName} Team
        </p>
    </div>
</body>
</html>
HTML;
    }
    
    /**
     * Get site name
     * 
     * @return string Site name
     */
    private function getSiteName() {
        if (!function_exists('user_management_cms_path')) {
            require_once dirname(__DIR__) . '/cms_paths.php';
        }

        $settingsPath = user_management_cms_path('settings/site.json');
        if (file_exists($settingsPath)) {
            $settings = json_decode((string) file_get_contents($settingsPath), true);
            if (!empty($settings['name'])) {
                return $settings['name'];
            }
        }
        return 'Birkly';
    }
    
    /**
     * Send email
     * 
     * @param string $to Recipient email
     * @param string $subject Email subject
     * @param string $body Email body (HTML)
     * @return bool Success
     */
    private function sendEmail($to, $subject, $body) {
        if (!function_exists('user_management_load_birkly_mail')) {
            require_once dirname(__DIR__) . '/cms_paths.php';
        }
        user_management_load_birkly_mail();

        if (function_exists('birkly_send_mail')) {
            $result = birkly_send_mail([
                'to' => $to,
                'subject' => $subject,
                'html' => $body,
                'text' => trim(preg_replace('/\s+/', ' ', strip_tags($body)) ?? ''),
            ]);

            $status = is_array($result) ? (string) ($result['status'] ?? '') : '';
            if (in_array($status, ['accepted', 'queued', 'logged'], true)) {
                return true;
            }

            if ($status === 'failed') {
                error_log('User Management email failed: ' . (string) ($result['error'] ?? 'unknown'));
            }
        }

        // Legacy fallback when CMS mail pipeline is unavailable (tests / old installs).
        $emailSettings = $this->getEmailSettings();
        $method = $emailSettings['method'] ?? 'mail';

        switch ($method) {
            case 'log':
                return $this->sendViaLog($to, $subject, $body);
            case 'smtp':
                return $this->sendViaSMTP($to, $subject, $body, $emailSettings);
            case 'sendmail':
                return $this->sendViaSendmail($to, $subject, $body, $emailSettings);
            case 'mail':
            default:
                return $this->sendViaMail($to, $subject, $body, $emailSettings);
        }
    }

    /**
     * Get email settings
     * 
     * @return array Email settings
     */
    private function getEmailSettings() {
        // Get from plugin settings
        $pluginSettings = $this->storage->getMetadata('email_settings', []);
        
        // Default settings
        return array_merge([
            'method' => 'mail',
            'from_email' => 'noreply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost'),
            'from_name' => $this->getSiteName(),
            'smtp_host' => '',
            'smtp_port' => 587,
            'smtp_username' => '',
            'smtp_password' => '',
            'smtp_encryption' => 'tls'
        ], $pluginSettings);
    }
    
    /**
     * Store outbound email in plugin metadata for local/dev/test transports.
     */
    private function sendViaLog($to, $subject, $body) {
        $messages = $this->storage->getMetadata('sent_emails', []);
        if (!is_array($messages)) {
            $messages = [];
        }

        $messages[] = [
            'to' => $to,
            'subject' => $subject,
            'body' => $body,
            'sent_at' => date('c')
        ];

        $this->storage->saveMetadata('sent_emails', $messages);
        return true;
    }

    /**
     * Send email via PHP mail()
     */
    private function sendViaMail($to, $subject, $body, $settings) {
        $headers = [
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $settings['from_name'] . ' <' . $settings['from_email'] . '>',
            'Reply-To: ' . $settings['from_email']
        ];
        
        return mail($to, $subject, $body, implode("\r\n", $headers));
    }
    
    /**
     * Send email via Sendmail
     */
    private function sendViaSendmail($to, $subject, $body, $settings) {
        // Similar to mail() but uses sendmail
        return $this->sendViaMail($to, $subject, $body, $settings);
    }
    
    /**
     * Send email via SMTP
     */
    private function sendViaSMTP($to, $subject, $body, $settings) {
        // Check if PHPMailer or similar is available
        // For now, fall back to mail()
        // TODO: Implement proper SMTP sending
        error_log('SMTP email sending not yet implemented, falling back to mail()');
        return $this->sendViaMail($to, $subject, $body, $settings);
    }
}
