<?php
/**
 * AccountActivation — opt-in membership account setup after external entitlement (e.g. subscription).
 *
 * General pattern: entitlement plugins register `user_activation_entitled` filter;
 * this class sends a one-time link so the visitor sets a password and receives the configured tier.
 */

require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/UserAuth.php';
require_once __DIR__ . '/UserTiers.php';
require_once __DIR__ . '/EmailVerification.php';

class AccountActivation
{
    private UserStorage $storage;
    private UserService $service;
    private EmailVerification $emailVerification;

    public function __construct()
    {
        $this->storage = new UserStorage();
        $this->service = new UserService();
        $this->emailVerification = new EmailVerification();
    }

    /**
     * Whether an email may activate a site account (subscription, invite pack, etc.).
     */
    public function isEntitled(string $email, array $context = []): bool
    {
        $email = strtolower(trim($email));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        if (function_exists('apply_filters')) {
            $entitled = apply_filters('user_activation_entitled', false, $email, $context);
            if ($entitled) {
                return true;
            }
        }

        return false;
    }

    /**
     * Request activation email. Always returns a generic success message when email format is valid.
     */
    public function sendActivationEmail(string $email, array $context = []): array
    {
        $email = strtolower(trim($email));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return [
                'success' => false,
                'message' => 'A valid email address is required.',
            ];
        }

        $generic = 'If your email qualifies for community access, we sent an activation link.';

        $forceResend = !empty($context['force_resend']) || !empty($context['reconcile_provision']);
        $reconcileProvision = !empty($context['reconcile_provision']);

        if (!$reconcileProvision && !$this->isEntitled($email, $context)) {
            return ['success' => true, 'message' => $generic];
        }

        $existingToken = $this->findReusableActivationToken($email, $context);
        $hadExistingToken = $existingToken !== null;
        if ($existingToken !== null && !$forceResend) {
            return ['success' => true, 'message' => $generic];
        }

        $tierId = $this->resolveActivationTier($context);
        if ($existingToken !== null && $forceResend) {
            $token = $existingToken;
            $tokenData = $this->storage->getActivationToken($token);
            if (!is_array($tokenData)) {
                $existingToken = null;
            } else {
                $tierId = (string) ($tokenData['tier_id'] ?? $tierId);
            }
        }

        if ($existingToken === null) {
            $token = bin2hex(random_bytes(32));
            $tokenData = [
                'token' => $token,
                'email' => $email,
                'tier_id' => $tierId,
                'context' => $context,
                'created_at' => date('c'),
                'expires_at' => date('c', strtotime('+72 hours')),
                'used' => false,
            ];

            if (!$this->storage->saveActivationToken($token, $tokenData)) {
                return [
                    'success' => false,
                    'message' => 'Could not create activation request. Please try again later.',
                ];
            }
        } else {
            $token = $existingToken;
        }

        $siteUrl = $this->getSiteUrl();
        $activationUrl = $siteUrl . '/activate-account?token=' . urlencode($token);
        $sent = $this->emailVerification->sendAccountActivationEmail($email, $activationUrl, $tierId);

        if (!$sent) {
            return [
                'success' => false,
                'message' => 'Could not send activation email. Please try again later.',
            ];
        }

        return ['success' => true, 'message' => $generic, 'resent' => $forceResend && $hadExistingToken];
    }

    public function verifyToken(string $token): array
    {
        $tokenData = $this->storage->getActivationToken($token);
        if (!$tokenData) {
            return ['success' => false, 'message' => 'Invalid or expired activation link.'];
        }

        if (!empty($tokenData['used'])) {
            return ['success' => false, 'message' => 'This activation link has already been used.'];
        }

        $expiresAt = strtotime((string) ($tokenData['expires_at'] ?? ''));
        if ($expiresAt !== false && time() > $expiresAt) {
            return ['success' => false, 'message' => 'Activation link has expired. Request a new one.'];
        }

        if (!$this->isEntitled((string) ($tokenData['email'] ?? ''), (array) ($tokenData['context'] ?? []))) {
            return ['success' => false, 'message' => 'This activation link is no longer valid.'];
        }

        return [
            'success' => true,
            'message' => 'Token is valid',
            'email' => $tokenData['email'] ?? '',
            'tier_id' => $tokenData['tier_id'] ?? $this->resolveActivationTier([]),
        ];
    }

    /**
     * Complete activation: create or update user, set password, grant tier, start session.
     *
     * @param array<string, mixed> $fieldValues Signup schema values (name, username, phone, custom)
     */
    public function completeActivation(string $token, string $password, ?string $name = null, array $fieldValues = []): array
    {
        $verify = $this->verifyToken($token);
        if (!$verify['success']) {
            return $verify;
        }

        if (strlen($password) < 8) {
            return ['success' => false, 'message' => 'Password must be at least 8 characters long.'];
        }

        $email = (string) ($verify['email'] ?? '');
        $tierId = (string) ($verify['tier_id'] ?? $this->resolveActivationTier([]));

        if ($name !== null && $name !== '' && !isset($fieldValues['name'])) {
            $fieldValues['name'] = $name;
        }

        require_once __DIR__ . '/SignupFieldSchema.php';
        $schema = new SignupFieldSchema();
        $validated = $schema->validate($fieldValues, SignupFieldSchema::CONTEXT_ACTIVATE, $email);
        if (!$validated['ok']) {
            return [
                'success' => false,
                'message' => implode(' ', $validated['errors']),
            ];
        }

        $mapped = $validated['user_data'];
        $displayName = (string) ($mapped['name'] ?? $name ?? $email);
        $existing = $this->storage->getUserByEmail($email);

        if ($existing) {
            $userId = (string) $existing['id'];
            $updated = $this->service->updateUser($userId, array_merge([
                'password' => $password,
                'verified' => true,
                'approved' => true,
                'status' => 'active',
            ], array_filter([
                'name' => $mapped['name'] ?? null,
                'username' => $mapped['username'] ?? null,
                'phone' => $mapped['phone'] ?? null,
            ], static fn ($v) => $v !== null && $v !== '')));
            if (!$updated) {
                return ['success' => false, 'message' => 'Failed to update account.'];
            }
        } else {
            $user = $this->service->createUser([
                'email' => $email,
                'password' => $password,
                'name' => $displayName,
                'username' => $mapped['username'] ?? null,
                'phone' => $mapped['phone'] ?? null,
                'verified' => true,
                'approved' => true,
                'status' => 'active',
                'tier' => $tierId,
            ]);
            $userId = (string) $user['id'];
        }

        if ($validated['custom_fields'] !== []
            || !empty($mapped['name'])
            || !empty($mapped['username'])
            || !empty($mapped['phone'])) {
            $schema->persistForUser($userId, $mapped, $validated['custom_fields']);
        }

        $tiers = new UserTiers();
        try {
            $tiers->setUserTier($userId, $tierId);
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Account created but membership tier could not be applied.'];
        }

        $tokenData = $this->storage->getActivationToken($token);
        if (is_array($tokenData)) {
            $tokenData['used'] = true;
            $tokenData['used_at'] = date('c');
            $tokenData['user_id'] = $userId;
            $this->storage->saveActivationToken($token, $tokenData);
        }

        $auth = new UserAuth('site');
        try {
            $auth->login($email, $password, false);
        } catch (Exception $e) {
            // Account exists; user can sign in manually.
        }

        $this->storage->saveActivity($userId, [
            'action' => 'account_activated',
            'description' => 'Membership account activated via email link',
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        ]);

        $this->ensureClubProfileAfterActivation($userId, $displayName);

        return [
            'success' => true,
            'message' => 'Your account is ready. Welcome!',
            'user_id' => $userId,
            'tier_id' => $tierId,
        ];
    }

    private function ensureClubProfileAfterActivation(string $userId, string $displayName): void
    {
        if ($userId === '') {
            return;
        }

        try {
            require_once __DIR__ . '/ClubProfileService.php';
            $profiles = new ClubProfileService();
            if (!$profiles->collectionExists() || $profiles->getProfileByUserId($userId) !== null) {
                return;
            }

            $title = trim($displayName);
            if ($title === '') {
                $title = 'Club member';
            }

            $profiles->saveProfileForUser($userId, ['title' => $title]);
        } catch (Throwable $e) {
            error_log('AccountActivation club profile: ' . $e->getMessage());
        }
    }

    private function resolveActivationTier(array $context): string
    {
        if (!empty($context['tier_id']) && is_string($context['tier_id'])) {
            return $context['tier_id'];
        }

        if (function_exists('get_plugin_setting')) {
            $configured = trim((string) get_plugin_setting('user_management', 'activation_tier', 'club'));
            if ($configured !== '') {
                return $configured;
            }
        }

        return 'club';
    }

    private function getSiteUrl(): string
    {
        if (!function_exists('user_management_site_url')) {
            require_once dirname(__DIR__) . '/cms_paths.php';
        }

        return user_management_site_url();
    }

    /**
     * @param array<string, mixed> $context
     */
    private function findReusableActivationToken(string $email, array $context): ?string
    {
        $tokensDir = $this->storage->getDataDir() . '/activation_tokens';
        if (!is_dir($tokensDir)) {
            return null;
        }

        $email = strtolower(trim($email));
        foreach (glob($tokensDir . '/*.json') ?: [] as $file) {
            $data = json_decode((string) file_get_contents($file), true);
            if (!is_array($data) || !empty($data['used'])) {
                continue;
            }
            if (strtolower(trim((string) ($data['email'] ?? ''))) !== $email) {
                continue;
            }

            $expiresAt = strtotime((string) ($data['expires_at'] ?? ''));
            if ($expiresAt !== false && time() > $expiresAt) {
                continue;
            }

            $storedContext = is_array($data['context'] ?? null) ? $data['context'] : [];
            if ($this->activationContextMatches($storedContext, $context)) {
                return (string) ($data['token'] ?? '');
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $stored
     * @param array<string, mixed> $requested
     */
    private function activationContextMatches(array $stored, array $requested): bool
    {
        $storedOrder = trim((string) ($stored['order_id'] ?? ''));
        $requestedOrder = trim((string) ($requested['order_id'] ?? ''));
        if ($storedOrder !== '' && $requestedOrder !== '' && $storedOrder !== $requestedOrder) {
            return false;
        }
        if ($storedOrder !== $requestedOrder) {
            return false;
        }

        if ($stored === [] && $requested === []) {
            return true;
        }

        foreach (['signup_flow_id', 'signup_flow_session_id', 'membership_product_id'] as $key) {
            $storedVal = trim((string) ($stored[$key] ?? ''));
            $requestedVal = trim((string) ($requested[$key] ?? ''));
            if ($storedVal !== '' && $requestedVal !== '' && $storedVal !== $requestedVal) {
                return false;
            }
        }

        return true;
    }
}
