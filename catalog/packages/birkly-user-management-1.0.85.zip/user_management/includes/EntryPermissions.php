<?php
/**
 * EntryPermissions - Backend permission enforcement for entries
 *
 * CRITICAL: This enforces security on the backend.
 * Frontend checks are for UX only - backend must enforce permissions.
 */

require_once __DIR__ . '/UserAuth.php';
require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/UserPermissions.php';
require_once __DIR__ . '/EntryOwnership.php';
require_once __DIR__ . '/UserPluginCollectionConfig.php';

class EntryPermissions {
    private $auth;
    private $storage;
    private $permissions;
    private $graph = null;
    private bool $graphUnavailable = false;

    public function __construct() {
        $this->auth = new UserAuth();
        $this->storage = new UserStorage();
        $this->permissions = new UserPermissions();
    }

    /**
     * Resolve entry owner id from schema owner field or legacy author keys.
     *
     * @param array<string, mixed> $entry
     */
    public function getEntryOwnerId($entry, $collectionSlug = null): ?string
    {
        if (!is_array($entry)) {
            return null;
        }

        return EntryOwnership::getEntryOwnerId($entry, is_string($collectionSlug) ? $collectionSlug : null);
    }

    private function graph()
    {
        if ($this->graphUnavailable) {
            return null;
        }
        if ($this->graph === null) {
            require_once __DIR__ . '/UserGraphService.php';
            try {
                $this->graph = new UserGraphService();
            } catch (Throwable $e) {
                $this->graphUnavailable = true;
                return null;
            }
        }

        return $this->graph;
    }

    /**
     * Check if user can view an entry
     *
     * @param string|null $user_id Current user ID (null if not logged in)
     * @param array<string, mixed> $entry Entry data
     * @param string|null $collectionSlug Collection slug when available (P81-M6)
     * @return bool
     */
    public function canViewEntry($user_id, $entry, $collectionSlug = null) {
        if (!is_array($entry)) {
            return false;
        }

        // Block/mute for any owned entry before visibility checks (P81-M6).
        if ($user_id) {
            $ownerId = $this->getEntryOwnerId($entry, is_string($collectionSlug) ? $collectionSlug : null);
            if ($ownerId !== null && $ownerId !== '' && (string) $ownerId !== (string) $user_id) {
                if ($this->isBlockedBetween((string) $user_id, (string) $ownerId)) {
                    return false;
                }
                if ($this->isMutedBetween((string) $user_id, (string) $ownerId)) {
                    return false;
                }
            }
        }

        if (is_string($collectionSlug) && $collectionSlug !== '' && UserPluginCollectionConfig::isUgcCollection($collectionSlug)) {
            $hidden = $entry['moderation_hidden'] ?? '';
            if ($hidden === true || $hidden === '1' || $hidden === 1 || $hidden === 'true') {
                return false;
            }
        }

        // Public entries: everyone can view
        $visibility = $entry['visibility'] ?? 'public';
        if ($visibility === 'public') {
            return true;
        }

        // Private entries: only owner can view
        if ($visibility === 'private') {
            if (!$user_id) {
                return false;
            }
            $ownerId = $this->getEntryOwnerId($entry);
            return $ownerId !== null && (string) $ownerId === (string) $user_id;
        }

        // Relationship-based: check graph or profile relationship field
        if ($visibility === 'relationship') {
            if (!$user_id) {
                return false;
            }

            $relationshipField = $entry['visibility_relationship_field'] ?? 'friends';
            $relationshipMode = $entry['visibility_relationship_mode'] ?? 'one_way'; // one_way | mutual

            $ownerId = $this->getEntryOwnerId($entry);
            if (!$ownerId) {
                return false;
            }

            if ($this->isBlockedBetween($user_id, $ownerId)) {
                return false;
            }

            if ($this->viewerHasRelationshipAccess($user_id, $ownerId, $relationshipField, $relationshipMode)) {
                return true;
            }

            return $this->viewerHasProfileRelationshipAccess($user_id, $ownerId, $relationshipField, $relationshipMode);
        }

        // Default: deny access
        return false;
    }

    /**
     * Check if user can edit an entry
     *
     * @param string|null $user_id Current user ID
     * @param array<string, mixed> $entry Entry data
     * @return bool
     */
    public function canEditEntry($user_id, $entry, $collection = null) {
        if (!$user_id) {
            return false;
        }

        $ownerId = $this->getEntryOwnerId($entry, is_string($collection) ? $collection : null);
        $context = [
            'collection' => $collection,
            'entry' => $entry['id'] ?? null,
            'author_id' => $ownerId,
        ];

        if ($this->permissions->userCan($user_id, 'edit', $context)) {
            return true;
        }

        if ($ownerId && (string) $ownerId === (string) $user_id) {
            return $this->permissions->userCan($user_id, 'edit_own', $context);
        }

        return false;
    }

    /**
     * Check if user can delete an entry
     *
     * @param string|null $user_id Current user ID
     * @param array<string, mixed> $entry Entry data
     * @return bool
     */
    public function canDeleteEntry($user_id, $entry, $collection = null) {
        if (!$user_id) {
            return false;
        }

        $ownerId = $this->getEntryOwnerId($entry, is_string($collection) ? $collection : null);
        $context = [
            'collection' => $collection,
            'entry' => $entry['id'] ?? null,
            'author_id' => $ownerId,
        ];

        if ($this->permissions->userCan($user_id, 'delete', $context)) {
            return true;
        }

        if ($ownerId && (string) $ownerId === (string) $user_id) {
            return $this->permissions->userCan($user_id, 'delete_own', $context);
        }

        return false;
    }

    /**
     * Check if user can create sub-entries (comments) on an entry
     *
     * @param string|null $user_id Current user ID
     * @param array<string, mixed> $entry Entry data
     * @return bool
     */
    public function canCommentOnEntry($user_id, $entry) {
        if (!$user_id) {
            return false;
        }

        $allowComments = $entry['allow_comments'] ?? true;
        if (!$allowComments) {
            return false;
        }

        return $this->canViewEntry($user_id, $entry);
    }

    /**
     * Filter entries by view permission
     *
     * @param string|null $user_id Current user ID (null if not logged in)
     * @param array<int, array<string, mixed>> $entries Array of entries
     * @param string|null $collectionSlug Collection slug when available (P81-M6)
     * @return array<int, array<string, mixed>> Filtered entries (only those user can view)
     */
    public function filterEntriesByViewPermission($user_id, $entries, $collectionSlug = null) {
        $filtered = [];
        foreach ($entries as $entry) {
            if ($this->canViewEntry($user_id, $entry, $collectionSlug)) {
                $filtered[] = $entry;
            }
        }
        return $filtered;
    }

    private function isMutedBetween(string $userA, string $userB): bool
    {
        try {
            $graph = $this->graph();
            if ($graph === null) {
                return false;
            }
            return $graph->isMuted($userA, $userB);
        } catch (Throwable $e) {
            return false;
        }
    }

    private function isBlockedBetween(string $userA, string $userB): bool
    {
        try {
            $graph = $this->graph();
            if ($graph === null) {
                return false;
            }
            return $graph->isBlocked($userA, $userB) || $graph->isBlocked($userB, $userA);
        } catch (Throwable $e) {
            return false;
        }
    }

    private function viewerHasRelationshipAccess(
        string $viewerId,
        string $ownerId,
        string $relationshipField,
        string $relationshipMode
    ): bool {
        try {
            $graph = $this->graph();
            if ($graph === null) {
                return false;
            }
            $field = strtolower(trim($relationshipField));

            if (in_array($field, ['friends', 'friend', 'connections', 'connection'], true)) {
                $oneWay = $graph->isFriend($viewerId, $ownerId);
            } elseif (in_array($field, ['following', 'followers'], true)) {
                if ($field === 'following') {
                    $oneWay = $graph->isFollowing($viewerId, $ownerId);
                } else {
                    $oneWay = $graph->isFollowing($ownerId, $viewerId);
                }
            } else {
                $oneWay = $graph->isFriend($viewerId, $ownerId)
                    || $graph->isFollowing($viewerId, $ownerId)
                    || $graph->isFollowing($ownerId, $viewerId);
            }

            if ($relationshipMode !== 'mutual') {
                return $oneWay;
            }

            if (in_array($field, ['following'], true)) {
                return $graph->isFollowing($viewerId, $ownerId)
                    && $graph->isFollowing($ownerId, $viewerId);
            }

            return $oneWay && $graph->isFriend($ownerId, $viewerId);
        } catch (Throwable $e) {
            return false;
        }
    }

    private function viewerHasProfileRelationshipAccess(
        string $viewerId,
        string $ownerId,
        string $relationshipField,
        string $relationshipMode
    ): bool {
        $profileEntry = $this->getProfileEntry($ownerId);
        if (!$profileEntry) {
            return false;
        }

        $relationships = $profileEntry[$relationshipField] ?? [];
        if (!is_array($relationships)) {
            $relationships = empty($relationships) ? [] : [$relationships];
        }

        $oneWay = in_array($viewerId, $relationships, true);
        if ($relationshipMode !== 'mutual') {
            return $oneWay;
        }

        $viewerProfile = $this->getProfileEntry($viewerId);
        if (!$viewerProfile) {
            return false;
        }
        $viewerRelationships = $viewerProfile[$relationshipField] ?? [];
        if (!is_array($viewerRelationships)) {
            $viewerRelationships = empty($viewerRelationships) ? [] : [$viewerRelationships];
        }

        return $oneWay && in_array($ownerId, $viewerRelationships, true);
    }

    /**
     * Get profile entry for a user
     *
     * @param string $user_id User ID
     * @return array<string, mixed>|null Profile entry or null
     */
    private function getProfileEntry($user_id) {
        $slug = 'profiles';
        if (function_exists('get_plugin_setting')) {
            $enabled = (bool)get_plugin_setting('user_management', 'profile_collection_enabled', false);
            if (!$enabled) return null;
            $s = (string)get_plugin_setting('user_management', 'profile_collection_slug', 'profiles');
            if ($s !== '') $slug = $s;
        }

        $contentRoot = getenv('USER_MANAGEMENT_CONTENT_DIR');
        if (!is_string($contentRoot) || trim($contentRoot) === '') {
            $contentRoot = __DIR__ . '/../../../content';
        }

        $base = rtrim($contentRoot, '/') . '/collections';
        if (!is_dir($base . '/' . $slug) && is_dir($base . '/social_profiles')) {
            $slug = 'social_profiles';
        }

        if (!is_dir($base . '/' . $slug)) return null;

        if (class_exists('Storage')) {
            try {
                $storage = new \Storage(rtrim($contentRoot, '/'));
                $results = $storage->query($slug, ['user_id' => $user_id], ['limit' => 1]);
                if (is_array($results) && count($results) > 0) {
                    return $results[0];
                }
            } catch (\Throwable $e) {
                // fall through
            }
        }

        $entriesDir = $base . '/' . $slug . '/entries';
        if (!is_dir($entriesDir)) return null;
        foreach (glob($entriesDir . '/*.json') as $file) {
            $entry = json_decode(@file_get_contents($file), true);
            if (is_array($entry) && isset($entry['user_id']) && $entry['user_id'] === $user_id) {
                return $entry;
            }
        }
        return null;
    }

    /**
     * Get current user ID
     *
     * @return string|null User ID or null if not logged in
     */
    public function getCurrentUserId() {
        try {
            $user = $this->auth->getCurrentUser();
            return $user['id'] ?? null;
        } catch (Exception $e) {
            return null;
        }
    }
}
