<?php
/**
 * UserGraphService — social graph domain layer over UserGraphStore (P76).
 */

declare(strict_types=1);

require_once __DIR__ . '/UserGraphStore.php';

class UserGraphService
{
    public const USER_RELATIONSHIPS_COLLECTION = 'user-relationships';

    public const TYPE_FOLLOW = UserGraphStore::KIND_FOLLOW;
    public const TYPE_FRIEND = UserGraphStore::KIND_FRIEND;
    public const TYPE_BLOCK = UserGraphStore::KIND_BLOCK;
    public const TYPE_MUTE = UserGraphStore::KIND_MUTE;
    public const TYPE_CONNECTION = UserGraphStore::KIND_CONNECTION;

    public const STATUS_ACTIVE = UserGraphStore::STATUS_ACTIVE;
    public const STATUS_PENDING = UserGraphStore::STATUS_PENDING;
    public const STATUS_REJECTED = UserGraphStore::STATUS_REJECTED;

    public const DEFAULT_FOLLOW_USER_ID = '__birkly__';

    private UserGraphStore $store;

    public function __construct(?UserGraphStore $store = null)
    {
        $this->store = $store ?? new UserGraphStore();
        $this->store->ensureStore();
    }

    public function getStore(): UserGraphStore
    {
        return $this->store;
    }

    public function ensureStore(): bool
    {
        return $this->store->ensureStore();
    }

    /** @deprecated P76 — graph is plugin-private; use ensureStore() */
    public function ensureCollection(): bool
    {
        return $this->ensureStore();
    }

    public function follow(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $this->assertDistinctUsers($fromUserId, $toUserId);
        $this->assertNotBlocked($fromUserId, $toUserId);

        if ($this->isFollowing($fromUserId, $toUserId)) {
            return true;
        }

        return $this->upsertEdge([
            'from_user' => $fromUserId,
            'to_user' => $toUserId,
            'kind' => self::TYPE_FOLLOW,
            'status' => self::STATUS_ACTIVE,
            'initiated_by' => $fromUserId,
        ]);
    }

    public function unfollow(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $this->assertDistinctUsers($fromUserId, $toUserId);

        if ($toUserId === self::DEFAULT_FOLLOW_USER_ID) {
            throw new InvalidArgumentException('Cannot unfollow Birkly');
        }

        return $this->deleteEdge($fromUserId, $toUserId, self::TYPE_FOLLOW);
    }

    /**
     * @return array{following: bool, followers: int}
     */
    public function toggleFollow(string $fromUserId, string $toUserId): array
    {
        if ($this->isFollowing($fromUserId, $toUserId)) {
            $this->unfollow($fromUserId, $toUserId);

            return [
                'following' => false,
                'followers' => $this->countFollowers($toUserId),
            ];
        }

        $this->follow($fromUserId, $toUserId);

        return [
            'following' => true,
            'followers' => $this->countFollowers($toUserId),
        ];
    }

    public function connect(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $this->assertDistinctUsers($fromUserId, $toUserId);
        $this->assertNotBlocked($fromUserId, $toUserId);
        $this->assertNotBlocked($toUserId, $fromUserId);

        $existing = $this->findEdge($fromUserId, $toUserId, self::TYPE_CONNECTION);
        if ($existing !== null) {
            $status = (string) ($existing['status'] ?? '');
            if ($status === self::STATUS_ACTIVE || $status === self::STATUS_PENDING) {
                return true;
            }
        }

        return $this->upsertEdge([
            'from_user' => $fromUserId,
            'to_user' => $toUserId,
            'kind' => self::TYPE_CONNECTION,
            'status' => self::STATUS_PENDING,
            'initiated_by' => $fromUserId,
        ]);
    }

    public function accept(string $acceptorUserId, string $requesterUserId): bool
    {
        $acceptorUserId = trim($acceptorUserId);
        $requesterUserId = trim($requesterUserId);
        $this->assertDistinctUsers($acceptorUserId, $requesterUserId);

        $pending = $this->findEdge($requesterUserId, $acceptorUserId, self::TYPE_CONNECTION, self::STATUS_PENDING);
        if ($pending === null) {
            throw new InvalidArgumentException('No pending connection request');
        }

        $pending['status'] = self::STATUS_ACTIVE;
        if (!$this->store->writeEdge($pending)) {
            return false;
        }

        $reverse = $this->findEdge($acceptorUserId, $requesterUserId, self::TYPE_CONNECTION);
        if ($reverse === null) {
            return $this->upsertEdge([
                'from_user' => $acceptorUserId,
                'to_user' => $requesterUserId,
                'kind' => self::TYPE_CONNECTION,
                'status' => self::STATUS_ACTIVE,
                'initiated_by' => $requesterUserId,
            ]);
        }

        if (($reverse['status'] ?? '') !== self::STATUS_ACTIVE) {
            $reverse['status'] = self::STATUS_ACTIVE;

            return $this->store->writeEdge($reverse);
        }

        return true;
    }

    public function reject(string $rejectorUserId, string $requesterUserId): bool
    {
        $rejectorUserId = trim($rejectorUserId);
        $requesterUserId = trim($requesterUserId);
        $this->assertDistinctUsers($rejectorUserId, $requesterUserId);

        $pending = $this->findEdge($requesterUserId, $rejectorUserId, self::TYPE_CONNECTION, self::STATUS_PENDING);
        if ($pending === null) {
            throw new InvalidArgumentException('No pending connection request');
        }

        return $this->store->deleteEdgeById((string) $pending['id']);
    }

    public function disconnect(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $this->assertDistinctUsers($fromUserId, $toUserId);

        $removedA = $this->deleteEdge($fromUserId, $toUserId, self::TYPE_CONNECTION);
        $removedB = $this->deleteEdge($toUserId, $fromUserId, self::TYPE_CONNECTION);
        $removedFriendA = $this->deleteEdge($fromUserId, $toUserId, self::TYPE_FRIEND);
        $removedFriendB = $this->deleteEdge($toUserId, $fromUserId, self::TYPE_FRIEND);

        return $removedA || $removedB || $removedFriendA || $removedFriendB;
    }

    public function block(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $this->assertDistinctUsers($fromUserId, $toUserId);

        $this->deleteEdge($fromUserId, $toUserId, self::TYPE_FOLLOW);
        $this->deleteEdge($toUserId, $fromUserId, self::TYPE_FOLLOW);
        $this->disconnect($fromUserId, $toUserId);

        return $this->upsertEdge([
            'from_user' => $fromUserId,
            'to_user' => $toUserId,
            'kind' => self::TYPE_BLOCK,
            'status' => self::STATUS_ACTIVE,
            'initiated_by' => $fromUserId,
        ]);
    }

    public function unblock(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $this->assertDistinctUsers($fromUserId, $toUserId);

        return $this->deleteEdge($fromUserId, $toUserId, self::TYPE_BLOCK);
    }

    public function mute(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $this->assertDistinctUsers($fromUserId, $toUserId);

        return $this->upsertEdge([
            'from_user' => $fromUserId,
            'to_user' => $toUserId,
            'kind' => self::TYPE_MUTE,
            'status' => self::STATUS_ACTIVE,
            'initiated_by' => $fromUserId,
        ]);
    }

    public function unmute(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        $this->assertDistinctUsers($fromUserId, $toUserId);

        return $this->deleteEdge($fromUserId, $toUserId, self::TYPE_MUTE);
    }

    public function isMuted(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        if ($fromUserId === '' || $toUserId === '') {
            return false;
        }

        return $this->findEdge($fromUserId, $toUserId, self::TYPE_MUTE, self::STATUS_ACTIVE) !== null;
    }

    public function isFollowing(string $fromUserId, string $toUserId): bool
    {
        return $this->findEdge(trim($fromUserId), trim($toUserId), self::TYPE_FOLLOW, self::STATUS_ACTIVE) !== null;
    }

    public function isConnected(string $userA, string $userB): bool
    {
        $userA = trim($userA);
        $userB = trim($userB);
        if ($userA === '' || $userB === '' || $userA === $userB) {
            return false;
        }

        return $this->findEdge($userA, $userB, self::TYPE_CONNECTION, self::STATUS_ACTIVE) !== null
            && $this->findEdge($userB, $userA, self::TYPE_CONNECTION, self::STATUS_ACTIVE) !== null;
    }

    public function isFriend(string $userA, string $userB): bool
    {
        if ($this->isConnected($userA, $userB)) {
            return true;
        }

        $userA = trim($userA);
        $userB = trim($userB);
        if ($userA === '' || $userB === '') {
            return false;
        }

        if ($this->findEdge($userA, $userB, self::TYPE_FRIEND, self::STATUS_ACTIVE) !== null) {
            return true;
        }

        return $this->findEdge($userB, $userA, self::TYPE_FRIEND, self::STATUS_ACTIVE) !== null;
    }

    public function isBlocked(string $fromUserId, string $toUserId): bool
    {
        $fromUserId = trim($fromUserId);
        $toUserId = trim($toUserId);
        if ($fromUserId === '' || $toUserId === '') {
            return false;
        }

        return $this->findEdge($fromUserId, $toUserId, self::TYPE_BLOCK, self::STATUS_ACTIVE) !== null;
    }

    /**
     * @return list<string>
     */
    public function listFollowing(string $userId): array
    {
        return $this->store->listUserIdsOutgoing(trim($userId), self::TYPE_FOLLOW, self::STATUS_ACTIVE);
    }

    /**
     * @return list<string>
     */
    public function listFollowers(string $userId): array
    {
        return $this->store->listUserIdsIncoming(trim($userId), self::TYPE_FOLLOW, self::STATUS_ACTIVE);
    }

    /**
     * @return list<string>
     */
    public function listConnected(string $userId): array
    {
        return $this->store->listConnectedUserIds(trim($userId));
    }

    /**
     * @return list<string>
     */
    public function listPendingConnectionRequests(string $userId): array
    {
        return $this->store->listUserIdsIncoming(trim($userId), self::TYPE_CONNECTION, self::STATUS_PENDING);
    }

    /**
     * @return list<string>
     */
    public function listBlocked(string $userId): array
    {
        return $this->store->listUserIdsOutgoing(trim($userId), self::TYPE_BLOCK, self::STATUS_ACTIVE);
    }

    /**
     * @return list<string>
     */
    public function listMuted(string $userId): array
    {
        return $this->store->listUserIdsOutgoing(trim($userId), self::TYPE_MUTE, self::STATUS_ACTIVE);
    }

    /**
     * True when either user has blocked the other.
     */
    public function isEitherBlocked(string $userA, string $userB): bool
    {
        return $this->isBlocked($userA, $userB) || $this->isBlocked($userB, $userA);
    }

    /**
     * @return array{following: int, followers: int, connected: int, pending_in: int, blocked: int}
     */
    public function summaryForUser(string $userId): array
    {
        return $this->store->summaryForUser($userId);
    }

    public function purgeUser(string $userId): int
    {
        return $this->store->purgeUser($userId);
    }

    /**
     * @return list<string>
     */
    public function ensureDefaultFollows(string $userId): array
    {
        $userId = trim($userId);
        if ($userId === '') {
            return [];
        }

        if (!$this->isFollowing($userId, self::DEFAULT_FOLLOW_USER_ID)) {
            $this->follow($userId, self::DEFAULT_FOLLOW_USER_ID);
        }

        return $this->listFollowing($userId);
    }

    /**
     * @param list<string> $targetUserIds
     *
     * @return array<string, array{following: bool, followers: int, connected: bool}>
     */
    public function followStateForUser(string $userId, array $targetUserIds): array
    {
        $userId = trim($userId);
        $followingList = $this->ensureDefaultFollows($userId);
        $followingSet = array_fill_keys($followingList, true);
        $followerCounts = $this->followerCountsForTargets($targetUserIds);

        $out = [];
        foreach ($targetUserIds as $targetUserId) {
            $targetUserId = (string) $targetUserId;
            if ($targetUserId === '') {
                continue;
            }
            $out[$targetUserId] = [
                'following' => isset($followingSet[$targetUserId]),
                'followers' => $followerCounts[$targetUserId] ?? 0,
                'connected' => $this->isConnected($userId, $targetUserId),
            ];
        }

        return $out;
    }

    public function countFollowers(string $targetUserId): int
    {
        $counts = $this->followerCountsForTargets([$targetUserId]);

        return $counts[$targetUserId] ?? 0;
    }

    /**
     * @param list<string> $targetUserIds
     *
     * @return array<string, int>
     */
    private function followerCountsForTargets(array $targetUserIds): array
    {
        return $this->store->countIncomingForTargets($targetUserIds, self::TYPE_FOLLOW, self::STATUS_ACTIVE);
    }

    /**
     * @return array<string, mixed>|null
     */
    private function findEdge(
        string $fromUserId,
        string $toUserId,
        string $relationshipType,
        ?string $status = self::STATUS_ACTIVE
    ): ?array {
        if ($fromUserId === '' || $toUserId === '') {
            return null;
        }

        return $this->store->findEdge($fromUserId, $toUserId, $relationshipType, $status);
    }

    /**
     * @param array<string, mixed> $edgeData
     */
    private function upsertEdge(array $edgeData): bool
    {
        $fromUserId = (string) ($edgeData['from_user'] ?? '');
        $toUserId = (string) ($edgeData['to_user'] ?? '');
        $kind = (string) ($edgeData['kind'] ?? $edgeData['relationship_type'] ?? '');

        $existing = $this->store->findEdge($fromUserId, $toUserId, $kind, null);
        if ($existing !== null) {
            $edge = array_merge($existing, $edgeData);
            $edge['kind'] = $this->store->normalizeKind($kind);

            return $this->store->writeEdge($edge);
        }

        $id = $this->store->edgeId($fromUserId, $toUserId, $kind);
        $edge = array_merge([
            'id' => $id,
            'created_at' => date('c'),
        ], $edgeData);
        $edge['kind'] = $this->store->normalizeKind($kind);

        return $this->store->writeEdge($edge);
    }

    private function deleteEdge(string $fromUserId, string $toUserId, string $relationshipType): bool
    {
        $existing = $this->store->findEdge($fromUserId, $toUserId, $relationshipType, null);
        if ($existing === null) {
            return false;
        }

        return $this->store->deleteEdgeById((string) ($existing['id'] ?? ''));
    }

    private function assertDistinctUsers(string $fromUserId, string $toUserId): void
    {
        if ($fromUserId === '' || $toUserId === '') {
            throw new InvalidArgumentException('User id required');
        }
        if ($fromUserId === $toUserId) {
            throw new InvalidArgumentException('Cannot relate user to themselves');
        }
    }

    private function assertNotBlocked(string $fromUserId, string $toUserId): void
    {
        if ($this->isBlocked($fromUserId, $toUserId) || $this->isBlocked($toUserId, $fromUserId)) {
            throw new InvalidArgumentException('User is blocked');
        }
    }
}
