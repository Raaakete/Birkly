<?php
/**
 * Membership product links — Commerce product/option ref → tier + signup flow (P74-M5).
 */

declare(strict_types=1);

require_once __DIR__ . '/UserStorage.php';

class MembershipProductRegistry
{
    private UserStorage $storage;

    public function __construct(?UserStorage $storage = null)
    {
        $this->storage = $storage ?? new UserStorage();
    }

    /**
     * @return array{products: list<array<string, mixed>>, settings: array<string, mixed>}
     */
    public function load(): array
    {
        $stored = $this->storage->readMetadata('membership_products');
        if (!is_array($stored)) {
            return $this->defaultConfig();
        }

        $products = is_array($stored['products'] ?? null) ? $stored['products'] : [];
        $settings = is_array($stored['settings'] ?? null) ? $stored['settings'] : [];

        return [
            'products' => array_values($products),
            'settings' => array_merge($this->defaultSettings(), $settings),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listProducts(bool $enabledOnly = false): array
    {
        $products = $this->load()['products'];
        if ($enabledOnly) {
            $products = array_values(array_filter($products, static fn ($p) => !empty($p['enabled'])));
        }

        return $products;
    }

    /**
     * @param list<array<string, mixed>> $products
     * @param array<string, mixed> $settings
     */
    public function save(array $products, array $settings = []): bool
    {
        $normalized = [];
        foreach ($products as $row) {
            if (!is_array($row)) {
                continue;
            }
            $id = trim((string) ($row['id'] ?? ''));
            if ($id === '') {
                $id = $this->generateId($row);
            }
            $normalized[] = [
                'id' => $id,
                'label' => trim((string) ($row['label'] ?? $id)),
                'collection' => trim((string) ($row['collection'] ?? '')),
                'entry_id' => trim((string) ($row['entry_id'] ?? '')),
                'purchase_option_id' => trim((string) ($row['purchase_option_id'] ?? '')),
                'tier_id' => trim((string) ($row['tier_id'] ?? 'club')) ?: 'club',
                'signup_flow_id' => trim((string) ($row['signup_flow_id'] ?? 'pay_then_activate')),
                'enabled' => !empty($row['enabled']),
                'updated_at' => date('c'),
            ];
        }

        $current = $this->load();
        $mergedSettings = array_merge($current['settings'], $settings);

        return $this->storage->saveMetadata('membership_products', [
            'products' => $normalized,
            'settings' => $mergedSettings,
            'updated_at' => date('c'),
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    public function settings(): array
    {
        return $this->load()['settings'];
    }

    public function pastDueGraceDays(): int
    {
        return max(0, (int) ($this->settings()['past_due_grace_days'] ?? 7));
    }

    public function defaultTierOnRevoke(): string
    {
        $tier = trim((string) ($this->settings()['default_tier_on_revoke'] ?? 'all'));

        return $tier !== '' ? $tier : 'all';
    }

    /**
     * @param array<string, mixed> $payload Commerce event or subscription row
     */
    public function resolveFromPayload(array $payload): ?array
    {
        $optionId = trim((string) ($payload['purchase_option_id'] ?? ''));
        $collection = trim((string) ($payload['collection_slug'] ?? $payload['collection'] ?? ''));
        $entryId = trim((string) ($payload['entry_id'] ?? ''));
        $entrySlug = trim((string) ($payload['entry_slug'] ?? ''));

        $meta = is_array($payload['metadata'] ?? null) ? $payload['metadata'] : [];
        if ($collection === '') {
            $collection = trim((string) ($meta['collection'] ?? $meta['entry_collection'] ?? ''));
        }
        if ($entryId === '') {
            $entryId = trim((string) ($meta['entry_id'] ?? $meta['supporter_entry_id'] ?? ''));
        }
        if ($entrySlug === '') {
            $entrySlug = trim((string) ($meta['entry_slug'] ?? ''));
        }

        $products = $this->listProducts(true);
        if ($products === []) {
            $this->importFromCommercePurchaseMappings();
            $products = $this->listProducts(true);
        }

        $best = null;
        $bestScore = -1;
        foreach ($products as $product) {
            $score = $this->matchScore($product, $collection, $entryId, $entrySlug, $optionId);
            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $product;
            }
        }

        return $bestScore > 0 ? $best : null;
    }

    /**
     * @param array<string, mixed> $subscription
     */
    public function resolveFromSubscription(array $subscription): ?array
    {
        return $this->resolveFromPayload($this->normalizeSubscriptionPayload($subscription));
    }

    /**
     * Merge subscription line fields (collection, entry slug) for membership matching.
     *
     * @param array<string, mixed> $subscription
     * @return array<string, mixed>
     */
    public function normalizeSubscriptionPayload(array $subscription): array
    {
        $line = null;
        $lines = is_array($subscription['lines'] ?? null) ? $subscription['lines'] : [];
        if ($lines !== []) {
            $line = is_array($lines[0]) ? $lines[0] : null;
        }

        $payload = $subscription;
        if (!is_array($line)) {
            return $payload;
        }

        foreach (['collection_slug', 'entry_id', 'entry_slug', 'purchase_option_id'] as $key) {
            $current = trim((string) ($payload[$key] ?? ''));
            if ($current === '' && !empty($line[$key])) {
                $payload[$key] = $line[$key];
            }
        }
        if (trim((string) ($payload['collection_slug'] ?? '')) === '' && !empty($line['collection'])) {
            $payload['collection_slug'] = $line['collection'];
        }

        return $payload;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getBySignupFlowId(string $flowId): ?array
    {
        $flowId = trim($flowId);
        if ($flowId === '') {
            return null;
        }
        foreach ($this->listProducts(true) as $product) {
            if ((string) ($product['signup_flow_id'] ?? '') === $flowId) {
                return $product;
            }
        }

        return null;
    }

    /**
     * Import Commerce purchase_mappings.json grant_tier entries.
     *
     * @return array{ok: bool, imported: int, skipped: int, error?: string}
     */
    public function importFromCommercePurchaseMappings(?string $path = null): array
    {
        $path = $path ?? $this->commercePurchaseMappingsPath();
        if ($path === null || !is_file($path)) {
            return ['ok' => false, 'imported' => 0, 'skipped' => 0, 'error' => 'purchase_mappings.json not found'];
        }

        $data = json_decode((string) file_get_contents($path), true);
        if (!is_array($data)) {
            return ['ok' => false, 'imported' => 0, 'skipped' => 0, 'error' => 'Invalid mappings file'];
        }

        $mappings = is_array($data['mappings'] ?? null) ? $data['mappings'] : [];
        $existing = $this->listProducts();
        $imported = 0;
        $skipped = 0;

        foreach ($mappings as $key => $config) {
            if (!is_array($config) || empty($config['grant_tier'])) {
                $skipped++;
                continue;
            }

            $parsed = $this->parseMappingKey((string) $key, $config);
            if ($parsed === null) {
                $skipped++;
                continue;
            }

            if ($this->productExists($existing, $parsed)) {
                $skipped++;
                continue;
            }

            $existing[] = [
                'id' => $parsed['id'],
                'label' => $parsed['label'],
                'collection' => $parsed['collection'],
                'entry_id' => $parsed['entry_id'],
                'purchase_option_id' => $parsed['purchase_option_id'],
                'tier_id' => (string) $config['grant_tier'],
                'signup_flow_id' => 'pay_then_activate',
                'enabled' => true,
            ];
            $imported++;
        }

        if ($imported > 0) {
            $this->save($existing);
        }

        return ['ok' => true, 'imported' => $imported, 'skipped' => $skipped];
    }

    /**
     * @return array{products: list<array<string, mixed>>, settings: array<string, mixed>}
     */
    private function defaultConfig(): array
    {
        return [
            'products' => [],
            'settings' => $this->defaultSettings(),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function defaultSettings(): array
    {
        return [
            'past_due_grace_days' => 7,
            'default_tier_on_revoke' => 'all',
        ];
    }

    /**
     * @param array<string, mixed> $product
     */
    private function matchScore(array $product, string $collection, string $entryId, string $entrySlug, string $optionId): int
    {
        $pOption = trim((string) ($product['purchase_option_id'] ?? ''));
        $pColl = trim((string) ($product['collection'] ?? ''));
        $pEntry = trim((string) ($product['entry_id'] ?? ''));

        if ($pOption === '') {
            return 0;
        }
        if ($optionId !== '' && $pOption !== $optionId) {
            return 0;
        }

        $score = 1;
        if ($pColl !== '' && $collection !== '') {
            if ($pColl !== $collection) {
                return 0;
            }
            $score += 2;
        }
        if ($pEntry !== '' && ($entryId !== '' || $entrySlug !== '')) {
            $entryMatches = $pEntry === $entryId
                || $pEntry === $entrySlug
                || ($entryId !== '' && $entrySlug !== '' && $pEntry === $entrySlug);
            if (!$entryMatches) {
                return 0;
            }
            $score += 2;
        }

        return $score;
    }

    /**
     * @param array<string, mixed> $row
     */
    private function generateId(array $row): string
    {
        $parts = array_filter([
            trim((string) ($row['collection'] ?? '')),
            trim((string) ($row['entry_id'] ?? '')),
            trim((string) ($row['purchase_option_id'] ?? '')),
        ]);
        if ($parts !== []) {
            return preg_replace('/[^a-z0-9-]+/', '-', strtolower(implode('-', $parts))) ?: bin2hex(random_bytes(4));
        }

        return 'mp_' . bin2hex(random_bytes(4));
    }

    private function commercePurchaseMappingsPath(): ?string
    {
        if (function_exists('commerce_data_dir')) {
            $path = commerce_data_dir() . '/purchase_mappings.json';
            if (is_file($path)) {
                return $path;
            }
        }

        if (function_exists('birkly_plugin_install_path')) {
            $commercePath = birkly_plugin_install_path('commerce');
            if ($commercePath !== null) {
                $candidates = [
                    dirname($commercePath, 3) . '/plugin-data/commerce/purchase_mappings.json',
                    dirname($commercePath, 2) . '/data/plugins/commerce/purchase_mappings.json',
                ];
                foreach ($candidates as $candidate) {
                    if (is_file($candidate)) {
                        return $candidate;
                    }
                }
            }
        }

        return null;
    }

    /**
     * @param list<array<string, mixed>> $existing
     * @param array<string, mixed> $parsed
     */
    private function productExists(array $existing, array $parsed): bool
    {
        foreach ($existing as $row) {
            if ((string) ($row['collection'] ?? '') === (string) ($parsed['collection'] ?? '')
                && (string) ($row['entry_id'] ?? '') === (string) ($parsed['entry_id'] ?? '')
                && (string) ($row['purchase_option_id'] ?? '') === (string) ($parsed['purchase_option_id'] ?? '')) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $config
     * @return array<string, mixed>|null
     */
    private function parseMappingKey(string $key, array $config): ?array
    {
        $collection = trim((string) ($config['collection_slug'] ?? ''));
        $entryId = trim((string) ($config['entry_slug'] ?? ''));
        $optionId = trim((string) ($config['purchase_option_id'] ?? ''));
        $label = trim((string) ($config['label'] ?? $key));

        if (str_starts_with($key, 'purchase_option:')) {
            $parts = explode(':', $key, 4);
            if (count($parts) === 4) {
                $collection = $collection !== '' ? $collection : $parts[1];
                $entryId = $entryId !== '' ? $entryId : $parts[2];
                $optionId = $optionId !== '' ? $optionId : $parts[3];
            }
        } elseif (str_starts_with($key, 'entry:')) {
            $parts = explode(':', $key, 3);
            if (count($parts) === 3) {
                $collection = $collection !== '' ? $collection : $parts[1];
                $entryId = $entryId !== '' ? $entryId : $parts[2];
            }
        } elseif (str_starts_with($key, 'collection:')) {
            $collection = $collection !== '' ? $collection : substr($key, strlen('collection:'));
        }

        if ($optionId === '' && $entryId === '' && $collection === '') {
            return null;
        }

        $id = $this->generateId([
            'collection' => $collection,
            'entry_id' => $entryId,
            'purchase_option_id' => $optionId,
        ]);

        return [
            'id' => $id,
            'label' => $label,
            'collection' => $collection,
            'entry_id' => $entryId,
            'purchase_option_id' => $optionId,
        ];
    }
}
