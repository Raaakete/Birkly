<?php
/**
 * Club deal analytics — copy/visit counters (P80-M5).
 */

declare(strict_types=1);

class ClubDealService
{
    public const COLLECTION = 'club-deals';

    public const EVENT_COPY = 'copy';
    public const EVENT_VISIT = 'visit';

    /**
     * @return array{ok: bool, copy_count?: int, visit_count?: int, error?: string}
     */
    public function track(string $dealId, string $event): array
    {
        $dealId = trim($dealId);
        $event = strtolower(trim($event));
        if ($dealId === '') {
            return ['ok' => false, 'error' => 'deal_id required'];
        }
        if (!in_array($event, [self::EVENT_COPY, self::EVENT_VISIT], true)) {
            return ['ok' => false, 'error' => 'event must be copy or visit'];
        }

        $entry = $this->readDealEntry($dealId);
        if ($entry === null) {
            return ['ok' => false, 'error' => 'Deal not found'];
        }

        $field = $event === self::EVENT_COPY ? 'copy_count' : 'visit_count';
        $current = (int) ($entry[$field] ?? 0);
        $entry[$field] = $current + 1;
        $entry['updated_at'] = date('c');

        if (!$this->writeDealEntry($dealId, $entry)) {
            return ['ok' => false, 'error' => 'Could not update deal'];
        }

        return [
            'ok' => true,
            'copy_count' => (int) ($entry['copy_count'] ?? 0),
            'visit_count' => (int) ($entry['visit_count'] ?? 0),
        ];
    }

    /**
     * @return ?array<string, mixed>
     */
    private function readDealEntry(string $dealId): ?array
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));

        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== self::COLLECTION) {
                continue;
            }
            $path = "collections/{$dir}/entries/{$dealId}.json";
            $entry = $storage->read($path);
            if (is_array($entry)) {
                return $entry;
            }
            foreach ($storage->list("collections/{$dir}/entries") as $file) {
                if (!str_ends_with($file, '.json')) {
                    continue;
                }
                $candidate = $storage->read("collections/{$dir}/entries/{$file}");
                if (!is_array($candidate)) {
                    continue;
                }
                if ((string) ($candidate['id'] ?? '') === $dealId || (string) ($candidate['slug'] ?? '') === $dealId) {
                    return $candidate;
                }
            }
            break;
        }

        return null;
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function writeDealEntry(string $dealId, array $entry): bool
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $entryId = (string) ($entry['id'] ?? $dealId);

        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== self::COLLECTION) {
                continue;
            }
            $path = "collections/{$dir}/entries/{$entryId}.json";

            return $storage->write($path, $entry);
        }

        return false;
    }
}
