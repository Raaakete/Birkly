<?php
/**
 * Configurable signup field schema (P74-M2).
 *
 * Merchants define which fields appear on registration and activation forms.
 * Stored under plugin metadata as signup_fields.
 */

declare(strict_types=1);

require_once __DIR__ . '/UserStorage.php';

class SignupFieldSchema
{
    public const CONTEXT_REGISTER = 'register';
    public const CONTEXT_ACTIVATE = 'activate';

    /** @var list<string> */
    public const FIELD_TYPES = ['email', 'password', 'text', 'tel', 'textarea', 'checkbox'];

    /** @var list<string> */
    private const USER_CORE_SLUGS = ['email', 'password', 'name', 'username', 'phone'];

    private UserStorage $storage;

    public function __construct(?UserStorage $storage = null)
    {
        $this->storage = $storage ?? new UserStorage();
    }

    /**
     * @return array{fields: list<array<string, mixed>>}
     */
    public function getSchema(): array
    {
        $stored = $this->storage->readMetadata('signup_fields');
        if (!is_array($stored) || !is_array($stored['fields'] ?? null)) {
            return ['fields' => $this->defaultFields()];
        }

        return ['fields' => $this->normalizeFields($stored['fields'])];
    }

    /**
     * @param list<array<string, mixed>> $fields
     */
    public function saveSchema(array $fields): bool
    {
        $payload = [
            'fields' => $this->normalizeFields($fields),
            'updated_at' => date('c'),
        ];

        return $this->storage->saveMetadata('signup_fields', $payload);
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function getFieldsForContext(string $context): array
    {
        $out = [];
        foreach ($this->getSchema()['fields'] as $field) {
            if ($this->fieldAppliesToContext($field, $context)) {
                $out[] = $field;
            }
        }

        return $out;
    }

    /**
     * Public-safe field list for front-end forms (no internal flags).
     *
     * @return list<array<string, mixed>>
     */
    public function getPublicFields(string $context): array
    {
        $fields = [];
        foreach ($this->getFieldsForContext($context) as $field) {
            if (($field['slug'] ?? '') === 'password' && $context === self::CONTEXT_ACTIVATE) {
                continue;
            }
            if (($field['slug'] ?? '') === 'email' && $context === self::CONTEXT_ACTIVATE) {
                continue;
            }

            $fields[] = [
                'slug' => (string) ($field['slug'] ?? ''),
                'type' => (string) ($field['type'] ?? 'text'),
                'label' => (string) ($field['label'] ?? ''),
                'required' => !empty($field['required']),
                'placeholder' => (string) ($field['placeholder'] ?? ''),
                'help_text' => (string) ($field['help_text'] ?? ''),
            ];
        }

        return $fields;
    }

    /**
     * @param array<string, mixed> $input
     * @return array{ok: bool, errors: list<string>, user_data: array<string, mixed>, custom_fields: array<string, mixed>}
     */
    public function validate(array $input, string $context, ?string $fixedEmail = null): array
    {
        $errors = [];
        $userData = [];
        $customFields = [];

        foreach ($this->getFieldsForContext($context) as $field) {
            $slug = (string) ($field['slug'] ?? '');
            if ($slug === '') {
                continue;
            }

            if ($slug === 'email' && $context === self::CONTEXT_ACTIVATE) {
                continue;
            }
            if ($slug === 'password' && $context === self::CONTEXT_ACTIVATE) {
                continue;
            }

            $required = !empty($field['required']);
            $raw = $input[$slug] ?? null;
            if (is_string($raw)) {
                $raw = trim($raw);
            }

            if ($slug === 'email' && $fixedEmail !== null) {
                $raw = $fixedEmail;
            }

            if ($required && ($raw === null || $raw === '')) {
                $errors[] = ($field['label'] ?? $slug) . ' is required';
                continue;
            }

            if ($raw === null || $raw === '') {
                continue;
            }

            $type = (string) ($field['type'] ?? 'text');
            if ($type === 'email' && !filter_var((string) $raw, FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'Invalid email format';
                continue;
            }
            if ($type === 'tel' && !preg_match('/^[0-9+\-().\s]{6,}$/', (string) $raw)) {
                $errors[] = ($field['label'] ?? $slug) . ' is not a valid phone number';
                continue;
            }
            if ($type === 'checkbox') {
                $raw = in_array($raw, ['1', 1, true, 'true', 'yes', 'on'], true) ? '1' : '0';
            }

            if ($slug === 'username' && !empty($field['unique'])) {
                $existing = $this->storage->getUserByUsername((string) $raw);
                if ($existing !== null) {
                    $errors[] = 'Username is already taken';
                    continue;
                }
            }

            if (in_array($slug, self::USER_CORE_SLUGS, true)) {
                $userData[$slug] = $raw;
            } else {
                $customFields[$slug] = $raw;
            }
        }

        if ($context === self::CONTEXT_REGISTER) {
            if (empty($userData['email']) && $fixedEmail === null) {
                $email = trim((string) ($input['email'] ?? ''));
                if ($email === '') {
                    $errors[] = 'Email is required';
                } else {
                    $userData['email'] = strtolower($email);
                }
            }
            $password = (string) ($input['password'] ?? $userData['password'] ?? '');
            if ($password === '') {
                $errors[] = 'Password is required';
            } elseif (strlen($password) < 8) {
                $errors[] = 'Password must be at least 8 characters';
            } else {
                $userData['password'] = $password;
            }
        }

        return [
            'ok' => $errors === [],
            'errors' => $errors,
            'user_data' => $userData,
            'custom_fields' => $customFields,
        ];
    }

    /**
     * Merge validated signup values onto a user record and optional profile entry.
     *
     * @param array<string, mixed> $userData
     * @param array<string, mixed> $customFields
     */
    public function persistForUser(string $userId, array $userData, array $customFields = []): void
    {
        $update = [];
        foreach (['name', 'username', 'phone'] as $key) {
            if (array_key_exists($key, $userData) && $userData[$key] !== '') {
                $update[$key] = $userData[$key];
            }
        }

        if ($customFields !== []) {
            $existing = $this->storage->getUser($userId) ?? [];
            $merged = is_array($existing['custom_fields'] ?? null) ? $existing['custom_fields'] : [];
            $update['custom_fields'] = array_merge($merged, $customFields);
        }

        if ($update === []) {
            return;
        }

        require_once __DIR__ . '/UserService.php';
        $service = new UserService();
        $service->updateUser($userId, $update);

        $this->syncProfileEntry($userId, array_merge($userData, $customFields));
    }

    /**
     * @param array<string, mixed> $values
     */
    private function syncProfileEntry(string $userId, array $values): void
    {
        if (!function_exists('get_plugin_setting')) {
            return;
        }

        $enabled = (bool) get_plugin_setting('user_management', 'profile_collection_enabled', false);
        $collection = trim((string) get_plugin_setting('user_management', 'profile_collection_slug', ''));
        if (!$enabled || $collection === '') {
            return;
        }

        try {
            require_once __DIR__ . '/ProfileService.php';
            $profiles = new ProfileService();
            $user = (new UserService())->getUser($userId);
            if (!is_array($user)) {
                return;
            }

            $profile = $profiles->getProfileByUserId($collection, $userId)
                ?? $profiles->ensureProfileForUser($collection, $user);
            if (!is_array($profile)) {
                return;
            }

            foreach ($values as $slug => $value) {
                if ($slug === 'password' || $slug === 'email') {
                    continue;
                }
                $profile[$slug] = $value;
            }

            $profiles->saveProfile($collection, $profile);
        } catch (Throwable $e) {
            error_log('SignupFieldSchema profile sync failed: ' . $e->getMessage());
        }
    }

    /**
     * @param array<string, mixed> $field
     */
    private function fieldAppliesToContext(array $field, string $context): bool
    {
        $contexts = $field['contexts'] ?? ['register', 'activate'];
        if (!is_array($contexts)) {
            return true;
        }

        return in_array($context, $contexts, true);
    }

    /**
     * @param list<array<string, mixed>> $fields
     * @return list<array<string, mixed>>
     */
    private function normalizeFields(array $fields): array
    {
        $out = [];
        $seen = [];
        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }
            $slug = strtolower(trim((string) ($field['slug'] ?? '')));
            $slug = preg_replace('/[^a-z0-9_]/', '_', $slug) ?? '';
            if ($slug === '' || isset($seen[$slug])) {
                continue;
            }
            $seen[$slug] = true;

            $type = (string) ($field['type'] ?? 'text');
            if (!in_array($type, self::FIELD_TYPES, true)) {
                $type = 'text';
            }

            $contexts = $field['contexts'] ?? ['register', 'activate'];
            if (!is_array($contexts)) {
                $contexts = ['register', 'activate'];
            }
            $contexts = array_values(array_intersect($contexts, [self::CONTEXT_REGISTER, self::CONTEXT_ACTIVATE]));
            if ($contexts === []) {
                $contexts = ['register', 'activate'];
            }

            $out[] = [
                'slug' => $slug,
                'type' => $type,
                'label' => trim((string) ($field['label'] ?? ucfirst(str_replace('_', ' ', $slug)))),
                'required' => !empty($field['required']),
                'unique' => !empty($field['unique']),
                'placeholder' => trim((string) ($field['placeholder'] ?? '')),
                'help_text' => trim((string) ($field['help_text'] ?? '')),
                'contexts' => $contexts,
            ];
        }

        if ($out === []) {
            return $this->defaultFields();
        }

        return $this->ensureSystemFields($out);
    }

    /**
     * @param list<array<string, mixed>> $fields
     * @return list<array<string, mixed>>
     */
    private function ensureSystemFields(array $fields): array
    {
        $bySlug = [];
        foreach ($fields as $field) {
            $bySlug[(string) $field['slug']] = $field;
        }

        foreach ($this->defaultFields() as $default) {
            $slug = (string) $default['slug'];
            if (!isset($bySlug[$slug]) && in_array($slug, ['email', 'password'], true)) {
                array_unshift($fields, $default);
            }
        }

        return $fields;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function defaultFields(): array
    {
        return [
            [
                'slug' => 'email',
                'type' => 'email',
                'label' => 'Email',
                'required' => true,
                'unique' => false,
                'placeholder' => '',
                'help_text' => '',
                'contexts' => [self::CONTEXT_REGISTER],
            ],
            [
                'slug' => 'password',
                'type' => 'password',
                'label' => 'Password',
                'required' => true,
                'unique' => false,
                'placeholder' => '',
                'help_text' => 'At least 8 characters',
                'contexts' => [self::CONTEXT_REGISTER, self::CONTEXT_ACTIVATE],
            ],
            [
                'slug' => 'name',
                'type' => 'text',
                'label' => 'Display name',
                'required' => false,
                'unique' => false,
                'placeholder' => '',
                'help_text' => '',
                'contexts' => [self::CONTEXT_REGISTER, self::CONTEXT_ACTIVATE],
            ],
            [
                'slug' => 'username',
                'type' => 'text',
                'label' => 'Username',
                'required' => false,
                'unique' => true,
                'placeholder' => '',
                'help_text' => '',
                'contexts' => [self::CONTEXT_REGISTER],
            ],
            [
                'slug' => 'phone',
                'type' => 'tel',
                'label' => 'Phone',
                'required' => false,
                'unique' => false,
                'placeholder' => '',
                'help_text' => '',
                'contexts' => [self::CONTEXT_REGISTER, self::CONTEXT_ACTIVATE],
            ],
        ];
    }
}
