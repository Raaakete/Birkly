<?php
/**
 * UserRateLimiter - file-backed abuse throttling for public user endpoints.
 *
 * Named UserRateLimiter to avoid collision with core api/rate_limit.php RateLimiter
 * (loaded by domain_auth before plugin API routes run).
 */

require_once __DIR__ . '/UserStorage.php';

class UserRateLimiter {
    private $storage;

    public function __construct() {
        $this->storage = new UserStorage();
    }

    public function assertAllowed($bucket, $identifier, $limit, $windowSeconds) {
        $result = $this->hit($bucket, $identifier, $limit, $windowSeconds);
        if (!$result['allowed']) {
            throw new Exception('Too many requests. Please try again in ' . ceil($result['retry_after'] / 60) . ' minutes.');
        }

        return $result;
    }

    public function hit($bucket, $identifier, $limit, $windowSeconds) {
        $limit = max(1, (int) $limit);
        $windowSeconds = max(1, (int) $windowSeconds);
        $now = time();
        $key = $this->metadataKey($bucket, $identifier);

        $state = $this->storage->getMetadata($key, []);
        $hits = isset($state['hits']) && is_array($state['hits']) ? $state['hits'] : [];
        $hits = array_values(array_filter($hits, function ($timestamp) use ($now, $windowSeconds) {
            return is_int($timestamp) && ($now - $timestamp) < $windowSeconds;
        }));

        if (count($hits) >= $limit) {
            $oldest = min($hits);
            return [
                'allowed' => false,
                'retry_after' => max(1, $windowSeconds - ($now - $oldest)),
                'remaining' => 0
            ];
        }

        $hits[] = $now;
        $this->storage->saveMetadata($key, [
            'bucket' => $bucket,
            'identifier_hash' => hash('sha256', (string) $identifier),
            'hits' => $hits,
            'updated_at' => date('c')
        ]);

        return [
            'allowed' => true,
            'retry_after' => 0,
            'remaining' => max(0, $limit - count($hits))
        ];
    }

    private function metadataKey($bucket, $identifier) {
        $bucket = preg_replace('/[^a-zA-Z0-9_-]/', '_', (string) $bucket);
        return 'rate_limit_' . $bucket . '_' . hash('sha256', (string) $identifier);
    }
}
