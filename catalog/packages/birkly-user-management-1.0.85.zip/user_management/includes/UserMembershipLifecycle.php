<?php
/**
 * Membership tier lifecycle — grant/revoke on Commerce subscription events (P74-M5).
 */

declare(strict_types=1);

require_once __DIR__ . '/SignupFlowPayload.php';
require_once __DIR__ . '/MembershipProductRegistry.php';
require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/UserTiers.php';
require_once __DIR__ . '/UserActivationShelf.php';
require_once __DIR__ . '/SupporterBadgeSync.php';

class UserMembershipLifecycle
{
    private MembershipProductRegistry $registry;
    private UserStorage $storage;
    private SupporterBadgeSync $badgeSync;

    public function __construct(
        ?MembershipProductRegistry $registry = null,
        ?UserStorage $storage = null,
        ?SupporterBadgeSync $badgeSync = null
    ) {
        $this->registry = $registry ?? new MembershipProductRegistry();
        $this->storage = $storage ?? new UserStorage();
        $this->badgeSync = $badgeSync ?? new SupporterBadgeSync();
    }

    public static function register(): void
    {
        $instance = new self();
        if (function_exists('add_filter')) {
            add_filter('user_activation_entitled', [$instance, 'filterEntitled'], 10, 3);
        }
        if (function_exists('register_hook')) {
            register_hook('user_logged_in', function ($user) use ($instance) {
                $instance->syncTierForUser(is_array($user) ? $user : []);
            });
        }
    }

    /**
     * @param array<string, mixed> $context
     */
    public function filterEntitled(bool $entitled, string $email, array $context = []): bool
    {
        if ($entitled) {
            return true;
        }

        $email = strtolower(trim($email));
        if ($email === '') {
            return false;
        }

        $orderId = trim((string) ($context['order_id'] ?? ''));
        if ($orderId !== '' && user_management_commerce_order_entitles_activation($email, $orderId)) {
            $source = (string) ($context['source'] ?? '');
            if ($source === 'membership_product' || $source === 'signup_flow') {
                return true;
            }
        }

        if (user_management_signup_flow_activation_entitled($email, $context)) {
            return true;
        }

        return $this->emailHasQualifyingSubscription($email);
    }

    /**
     * @param array<string, mixed> $payload
     * @param bool $fromReconcile When true, provision missing accounts even if signup_flow metadata is present.
     * @param bool $skipNotifications When true (reconcile only), grant tiers but do not send activation/welcome emails.
     */
    public function handleCommerceEvent(string $event, array $payload, bool $fromReconcile = false, bool $skipNotifications = false): array
    {
        $normalized = strtolower(trim($event));
        $email = strtolower(trim((string) ($payload['customer_email'] ?? $payload['email'] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'error' => 'No customer email on commerce event'];
        }

        if (in_array($normalized, ['commerce_order_paid', 'commerce_subscription_canceled', 'commerce_subscription_paused'], true)) {
            $action = match ($normalized) {
                'commerce_subscription_canceled' => 'badge_synced_on_cancel',
                'commerce_subscription_paused' => 'badge_synced_on_pause',
                default => 'badge_synced',
            };

            return $this->syncBadgeForPayloadEmail($email, $payload, $normalized, $action);
        }

        $badgePrefetch = null;
        if (
            in_array($normalized, ['commerce_subscription_started', 'commerce_membership_started'], true)
            && $this->resolveUserIdByEmail($email) !== null
        ) {
            $badgePrefetch = $this->syncBadgeForPayloadEmail($email, $payload, $normalized);
        }

        $signals = user_management_signup_flow_signals($payload);
        $hasSignupFlow = user_management_payload_has_signup_flow($payload);

        $product = $this->registry->resolveFromPayload($payload);
        if ($product === null) {
            if ($badgePrefetch !== null) {
                return $badgePrefetch;
            }
            if ($hasSignupFlow) {
                return ['ok' => true, 'skipped' => true, 'reason' => 'signup_flow_handles_activation'];
            }

            return ['ok' => true, 'skipped' => true, 'reason' => 'no_membership_product_match'];
        }

        $tierId = (string) ($product['tier_id'] ?? 'club');
        $hasSignupFlow = user_management_payload_has_signup_flow($payload);

        switch ($normalized) {
            case 'commerce_subscription_started':
            case 'commerce_membership_started':
                $badgeResult = $badgePrefetch ?? $this->syncBadgeForPayloadEmail($email, $payload, 'commerce_subscription_started');
                $userId = $this->resolveUserIdByEmail($email);
                if ($userId !== null) {
                    $this->grantTierForUserId($userId, $tierId);
                    if (!$skipNotifications) {
                        $this->notifyExistingMember($email, $tierId, $payload);
                    }

                    return array_merge(
                        ['ok' => true, 'action' => 'tier_granted', 'user_id' => $userId, 'tier_id' => $tierId],
                        $badgeResult
                    );
                }
                if ($hasSignupFlow && !$fromReconcile) {
                    return ['ok' => true, 'skipped' => true, 'reason' => 'signup_flow_handles_activation'];
                }

                if ($skipNotifications) {
                    return ['ok' => true, 'skipped' => true, 'reason' => 'notification_already_sent'];
                }

                return $this->sendActivationForProduct($email, $product, $payload, $fromReconcile);

            case 'commerce_subscription_recovered':
            case 'commerce_subscription_renewed':
                $userId = $this->resolveUserIdByEmail($email);
                if ($userId !== null) {
                    $this->grantTierForUserId($userId, $tierId);
                    return ['ok' => true, 'action' => 'tier_granted', 'user_id' => $userId];
                }

                return ['ok' => true, 'skipped' => true, 'reason' => 'no_user'];

            case 'commerce_subscription_resumed':
                $userId = $this->resolveUserIdByEmail($email);
                if ($userId !== null) {
                    $this->grantTierForUserId($userId, $tierId);

                    return ['ok' => true, 'action' => 'tier_granted', 'user_id' => $userId];
                }

                return ['ok' => true, 'skipped' => true, 'reason' => 'no_user'];

            case 'commerce_subscription_past_due':
                if ($this->registry->pastDueGraceDays() <= 0) {
                    $this->revokeMembershipTierForEmail($email);

                    return ['ok' => true, 'action' => 'tier_revoked'];
                }

                return ['ok' => true, 'skipped' => true, 'reason' => 'grace_period_active'];

            default:
                return ['ok' => true, 'skipped' => true, 'reason' => 'unsupported_event'];
        }
    }

    /**
     * Reconcile active Commerce subscriptions against membership products (e.g. after mapping fixes).
     *
     * @param bool $sendNotifications When false (plugin version bump), grant tiers only — no activation/welcome emails.
     *
     * @return array{processed: int, granted: int, activations: int, skipped: int}
     */
    public function reconcileActiveSubscriptions(bool $sendNotifications = true): array
    {
        if (!class_exists('CommerceSubscriptionStore')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceSubscriptionStore.php')) {
                require_once $pluginDir . '/includes/CommerceSubscriptionStore.php';
            }
        }
        if (!class_exists('CommerceSubscriptionStore')) {
            return ['processed' => 0, 'granted' => 0, 'activations' => 0, 'skipped' => 0];
        }

        $stats = ['processed' => 0, 'granted' => 0, 'activations' => 0, 'skipped' => 0];
        $seen = [];
        $notifiedEmails = [];
        try {
            foreach ((new CommerceSubscriptionStore())->listAll() as $sub) {
                if (!is_array($sub) || (string) ($sub['status'] ?? '') !== 'active') {
                    continue;
                }
                $email = strtolower(trim((string) ($sub['customer_email'] ?? '')));
                if ($email === '') {
                    continue;
                }
                foreach ($sub['lines'] ?? [$sub] as $line) {
                    if (!is_array($line)) {
                        continue;
                    }
                    $dedupe = $email . '|' . ($line['line_id'] ?? $sub['id'] ?? '');
                    if (isset($seen[$dedupe])) {
                        continue;
                    }
                    $seen[$dedupe] = true;
                    $payload = $this->registry->normalizeSubscriptionPayload(array_merge($sub, $line, [
                        'customer_email' => $email,
                        'collection_slug' => $line['collection_slug'] ?? $sub['collection_slug'] ?? '',
                        'entry_id' => $line['entry_id'] ?? $sub['entry_id'] ?? '',
                        'entry_slug' => $line['entry_slug'] ?? $sub['entry_slug'] ?? '',
                        'purchase_option_id' => $line['purchase_option_id'] ?? $sub['purchase_option_id'] ?? '',
                    ]));
                    $skipNotifications = !$sendNotifications || isset($notifiedEmails[$email]);
                    $result = $this->handleCommerceEvent('commerce_subscription_started', $payload, true, $skipNotifications);
                    $stats['processed']++;
                    $action = (string) ($result['action'] ?? '');
                    if ($action === 'tier_granted') {
                        $stats['granted']++;
                        if (!$skipNotifications) {
                            $notifiedEmails[$email] = true;
                        }
                    } elseif (
                        ($result['activation']['success'] ?? false) === true
                        || in_array($action, ['activation_sent', 'activation_resent'], true)
                    ) {
                        if (!isset($notifiedEmails[$email])) {
                            $notifiedEmails[$email] = true;
                            $stats['activations']++;
                        }
                    } elseif (($result['reason'] ?? '') === 'notification_already_sent') {
                        $stats['skipped']++;
                    } else {
                        $stats['skipped']++;
                    }
                }
            }
        } catch (Throwable $e) {
            error_log('UserMembershipLifecycle reconcile: ' . $e->getMessage());
        }

        return $stats;
    }

    /**
     * @param array<string, mixed> $user
     */
    public function syncTierForUser(array $user): void
    {
        $email = strtolower(trim((string) ($user['email'] ?? '')));
        $userId = (string) ($user['id'] ?? '');
        if ($email === '' || $userId === '') {
            return;
        }

        if ($this->emailHasQualifyingSubscription($email)) {
            $product = $this->resolveBestProductForEmail($email);
            if ($product !== null) {
                $this->grantTierForUserId($userId, (string) ($product['tier_id'] ?? 'club'));
            }
        }
    }

    private function emailHasQualifyingSubscription(string $email): bool
    {
        $subs = $this->activeSubscriptionsForEmail($email);
        foreach ($subs as $sub) {
            if ($this->registry->resolveFromSubscription($sub) !== null) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function resolveBestProductForEmail(string $email): ?array
    {
        $best = null;
        $bestScore = -1;
        foreach ($this->activeSubscriptionsForEmail($email) as $sub) {
            $product = $this->registry->resolveFromSubscription($sub);
            if ($product === null) {
                continue;
            }
            $score = 1;
            if ($bestScore < $score) {
                $bestScore = $score;
                $best = $product;
            }
        }

        return $best;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function activeSubscriptionsForEmail(string $email): array
    {
        if (function_exists('get_plugin_service')) {
            $shelf = get_plugin_service('payment_shelf', false, 'user_management')
                ?? get_plugin_service('commerce_shelf', false, 'user_management');
            if (is_object($shelf) && method_exists($shelf, 'getActiveSubscriptionsForEmail')) {
                try {
                    $subs = $shelf->getActiveSubscriptionsForEmail($email, $this->registry->pastDueGraceDays());
                    if (is_array($subs) && $subs !== []) {
                        return $subs;
                    }
                } catch (Throwable $e) {
                    error_log('UserMembershipLifecycle subscription lookup: ' . $e->getMessage());
                }
            }
        }

        return $this->activeSubscriptionsFromStore($email);
    }

    /**
     * Direct subscription store read — avoids commerce_shelf capability gate on public routes.
     *
     * @return list<array<string, mixed>>
     */
    private function activeSubscriptionsFromStore(string $email): array
    {
        if (!class_exists('CommerceSubscriptionStore')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceSubscriptionStore.php')) {
                require_once $pluginDir . '/includes/CommerceSubscriptionStore.php';
            }
        }
        if (!class_exists('CommerceSubscriptionStore')) {
            return [];
        }

        $email = strtolower(trim($email));
        $graceDays = $this->registry->pastDueGraceDays();
        $now = time();
        $active = [];

        try {
            foreach ((new CommerceSubscriptionStore())->listAll() as $sub) {
                if (!is_array($sub) || strtolower(trim((string) ($sub['customer_email'] ?? ''))) !== $email) {
                    continue;
                }

                $status = (string) ($sub['status'] ?? '');
                if ($status === 'active') {
                    $active[] = $sub;
                    continue;
                }

                if ($status === 'past_due' && $graceDays > 0) {
                    $pastDueAt = strtotime((string) ($sub['past_due_at'] ?? $sub['updated_at'] ?? ''));
                    if ($pastDueAt !== false && ($now - $pastDueAt) <= ($graceDays * 86400)) {
                        $active[] = $sub;
                    }
                }
            }
        } catch (Throwable $e) {
            error_log('UserMembershipLifecycle subscription store lookup: ' . $e->getMessage());
        }

        return $active;
    }

    /**
     * @param array<string, mixed> $product
     * @param array<string, mixed> $payload
     */
    private function sendActivationForProduct(string $email, array $product, array $payload, bool $fromReconcile = false): array
    {
        $shelf = new UserActivationShelf();
        $context = [
            'source' => 'membership_product',
            'membership_product_id' => (string) ($product['id'] ?? ''),
            'signup_flow_id' => (string) ($product['signup_flow_id'] ?? 'pay_then_activate'),
            'tier_id' => (string) ($product['tier_id'] ?? 'club'),
            'order_id' => (string) ($payload['order_id'] ?? ''),
            'purchase_option_id' => (string) ($payload['purchase_option_id'] ?? ''),
        ];
        if ($fromReconcile) {
            $context['reconcile_provision'] = true;
            $context['force_resend'] = true;
        }
        $send = $shelf->sendActivation($email, $context);

        $sent = (bool) ($send['success'] ?? false);
        $action = 'activation_failed';
        if ($sent) {
            $action = !empty($send['resent']) ? 'activation_resent' : 'activation_sent';
        }

        return [
            'ok' => $sent,
            'action' => $action,
            'activation' => $send,
            'email' => $email,
            'product_id' => $product['id'] ?? '',
        ];
    }

    /**
     * Emails with qualifying active subscriptions but no site user account.
     *
     * @return list<array{email: string, subscription_id: string, order_id: string}>
     */
    public function listEntitlementGaps(): array
    {
        if (!class_exists('CommerceSubscriptionStore')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceSubscriptionStore.php')) {
                require_once $pluginDir . '/includes/CommerceSubscriptionStore.php';
            }
        }
        if (!class_exists('CommerceSubscriptionStore')) {
            return [];
        }

        $gaps = [];
        $seen = [];
        try {
            foreach ((new CommerceSubscriptionStore())->listAll() as $sub) {
                if (!is_array($sub) || (string) ($sub['status'] ?? '') !== 'active') {
                    continue;
                }
                $email = strtolower(trim((string) ($sub['customer_email'] ?? '')));
                if ($email === '' || isset($seen[$email])) {
                    continue;
                }
                $payload = $this->registry->normalizeSubscriptionPayload($sub);
                if ($this->registry->resolveFromPayload($payload) === null) {
                    continue;
                }
                if ($this->resolveUserIdByEmail($email) !== null) {
                    continue;
                }
                $seen[$email] = true;
                $gaps[] = [
                    'email' => $email,
                    'subscription_id' => (string) ($sub['id'] ?? ''),
                    'order_id' => (string) ($sub['order_id'] ?? ''),
                ];
            }
        } catch (Throwable $e) {
            error_log('UserMembershipLifecycle entitlement gaps: ' . $e->getMessage());
        }

        return $gaps;
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function notifyExistingMember(string $email, string $tierId, array $payload): void
    {
        $email = strtolower(trim($email));
        if ($email === '' || !$this->markWelcomeEmailSent($email, $tierId)) {
            return;
        }

        try {
            require_once __DIR__ . '/EmailVerification.php';
            $verification = new EmailVerification();
            $verification->sendMembershipWelcomeEmail($email, $tierId, $payload);
        } catch (Throwable $e) {
            $this->clearWelcomeEmailSent($email, $tierId);
            error_log('UserMembershipLifecycle welcome email: ' . $e->getMessage());
        }
    }

    /**
     * Persist welcome sends so plugin upgrades / reconciles never re-email members.
     */
    private function markWelcomeEmailSent(string $email, string $tierId): bool
    {
        $ledger = $this->loadWelcomeEmailLedger();
        $key = $this->welcomeLedgerKey($email, $tierId);
        if (isset($ledger[$key])) {
            return false;
        }

        $ledger[$key] = date('c');
        $this->storage->saveMetadata('membership_welcome_sent', $ledger);

        return true;
    }

    private function clearWelcomeEmailSent(string $email, string $tierId): void
    {
        $ledger = $this->loadWelcomeEmailLedger();
        $key = $this->welcomeLedgerKey($email, $tierId);
        if (!isset($ledger[$key])) {
            return;
        }

        unset($ledger[$key]);
        $this->storage->saveMetadata('membership_welcome_sent', $ledger);
    }

    /**
     * @return array<string, string>
     */
    private function loadWelcomeEmailLedger(): array
    {
        $raw = $this->storage->readMetadata('membership_welcome_sent');
        if (!is_array($raw)) {
            return [];
        }

        return $raw;
    }

    private function welcomeLedgerKey(string $email, string $tierId): string
    {
        return strtolower(trim($email)) . '|' . trim($tierId);
    }

    private function grantTierForUserId(string $userId, string $tierId): void
    {
        if ($tierId === '') {
            return;
        }
        try {
            $tiers = new UserTiers();
            $tiers->setUserTier($userId, $tierId);
        } catch (Throwable $e) {
            error_log('UserMembershipLifecycle grant failed: ' . $e->getMessage());
        }
    }

    private function revokeMembershipTierForEmail(string $email): void
    {
        $userId = $this->resolveUserIdByEmail($email);
        if ($userId === null) {
            return;
        }
        $this->grantTierForUserId($userId, $this->registry->defaultTierOnRevoke());
    }

    /**
     * @param array<string, mixed> $payload
     *
     * @return array<string, mixed>
     */
    private function syncBadgeForPayloadEmail(
        string $email,
        array $payload,
        string $event,
        string $action = 'badge_synced'
    ): array {
        try {
            $sync = $this->badgeSync->handleCommerceEvent(
                $event,
                array_merge($payload, ['customer_email' => $email])
            );
        } catch (Throwable $e) {
            error_log('UserMembershipLifecycle badge sync: ' . $e->getMessage());

            return ['ok' => true, 'action' => $action, 'badge_sync' => ['ok' => false, 'error' => $e->getMessage()]];
        }

        return ['ok' => true, 'action' => $action, 'badge_sync' => $sync];
    }

    private function resolveUserIdByEmail(string $email): ?string
    {
        if (function_exists('get_plugin_service')) {
            $service = get_plugin_service('user_service', false, 'user_management');
            if (is_object($service) && method_exists($service, 'getUserByEmail')) {
                try {
                    $user = $service->getUserByEmail($email);

                    return isset($user['id']) ? (string) $user['id'] : null;
                } catch (Throwable $e) {
                    return null;
                }
            }
        }

        try {
            $service = new UserService();
            $user = $service->getUserByEmail($email);

            return isset($user['id']) ? (string) $user['id'] : null;
        } catch (Throwable $e) {
            return null;
        }
    }
}
