<?php
/**
 * Member account field value codec (P77-M2).
 *
 * Normalizes, encrypts, hashes, validates, and redacts user_account field values.
 */

declare(strict_types=1);

require_once __DIR__ . '/UserFieldtypeProfileStore.php';

class MemberAccountCodec
{
    public const PASSWORD_UNCHANGED = '__PASSWORD_UNCHANGED__';

    /** @return array<string, mixed> */
    public static function defaultValue(): array
    {
        return [
            'member_id' => '',
            'tier_id' => 'all',
            'fieldtype_profile_id' => 'default',
            'email' => '',
            'password' => '',
            'name' => '',
            'status' => 'pending',
            'verified' => false,
            'custom' => [],
        ];
    }

    public static function generateMemberId(): string
    {
        return 'm_' . bin2hex(random_bytes(8));
    }

    /**
     * @param mixed $value
     * @return array<string, mixed>
     */
    public static function normalize($value): array
    {
        if (is_string($value)) {
            $trimmed = trim($value);
            if ($trimmed === '') {
                return self::defaultValue();
            }
            $decoded = json_decode($trimmed, true);
            $value = is_array($decoded) ? $decoded : [];
        }

        if (!is_array($value)) {
            return self::defaultValue();
        }

        $base = self::defaultValue();
        foreach (['member_id', 'tier_id', 'fieldtype_profile_id', 'email', 'password', 'name', 'status'] as $key) {
            if (array_key_exists($key, $value)) {
                $base[$key] = is_scalar($value[$key]) ? (string) $value[$key] : '';
            }
        }

        if (array_key_exists('verified', $value)) {
            $base['verified'] = self::toBool($value['verified']);
        }

        if (isset($value['custom']) && is_array($value['custom'])) {
            $base['custom'] = $value['custom'];
        }

        if (isset($value['commerce']) && is_array($value['commerce'])) {
            $base['commerce'] = $value['commerce'];
        }

        if (array_key_exists('legacy_user_id', $value)) {
            $base['legacy_user_id'] = is_scalar($value['legacy_user_id']) ? (string) $value['legacy_user_id'] : '';
        }

        return $base;
    }

    /**
     * Prepare a value for persistence (encrypt email, hash password, assign member_id).
     *
     * @param mixed $incoming
     * @param mixed $existing
     * @param array<string, mixed> $profileSettings
     * @return array<string, mixed>
     */
    public static function processForStorage($incoming, $existing, array $profileSettings, string $typeKey = 'user_account'): array
    {
        $next = self::normalize($incoming);
        $prev = self::normalize($existing);
        $profile = self::resolveProfileMeta($typeKey);

        if ($next['member_id'] === '' && $prev['member_id'] !== '') {
            $next['member_id'] = $prev['member_id'];
        }
        if ($next['member_id'] === '') {
            $next['member_id'] = self::generateMemberId();
        }

        if ($next['fieldtype_profile_id'] === '') {
            $next['fieldtype_profile_id'] = (string) ($profile['id'] ?? 'default');
        }

        if ($next['tier_id'] === '' && $prev['tier_id'] !== '') {
            $next['tier_id'] = $prev['tier_id'];
        }
        if ($next['tier_id'] === '') {
            $next['tier_id'] = 'all';
        }

        $plainEmail = self::resolvePlainEmail($next['email'], $prev['email']);
        if ($plainEmail !== '') {
            $next['email'] = user_management_encrypt_field($plainEmail);
        } elseif ($prev['email'] !== '') {
            $next['email'] = $prev['email'];
        } else {
            $next['email'] = '';
        }

        $next['password'] = self::resolveStoredPassword($next['password'], $prev['password']);

        if ($next['name'] === '' && $prev['name'] !== '') {
            $next['name'] = $prev['name'];
        }

        if ($next['status'] === '' && $prev['status'] !== '') {
            $next['status'] = $prev['status'];
        }

        if (!isset($incoming['verified']) && $prev !== self::defaultValue()) {
            $next['verified'] = $prev['verified'];
        }

        $next['custom'] = self::mergeCustomFields(
            (array) ($next['custom'] ?? []),
            (array) ($prev['custom'] ?? []),
            $profileSettings
        );

        if (isset($prev['commerce']) && !isset($next['commerce'])) {
            $next['commerce'] = $prev['commerce'];
        }

        if (($next['legacy_user_id'] ?? '') === '' && ($prev['legacy_user_id'] ?? '') !== '') {
            $next['legacy_user_id'] = $prev['legacy_user_id'];
        }

        return $next;
    }

    /**
     * Prepare stored value for admin display (decrypt email, mask password).
     *
     * @param mixed $value
     * @return array<string, mixed>
     */
    public static function processForAdmin($value): array
    {
        $data = self::normalize($value);

        if ($data['email'] !== '') {
            $plain = self::decryptEmail($data['email']);
            $data['email'] = $plain ?? '';
        }

        if ($data['password'] !== '') {
            $data['password'] = self::PASSWORD_UNCHANGED;
            $data['password_set'] = true;
        } else {
            $data['password_set'] = false;
        }

        return $data;
    }

    /**
     * Strip sensitive material for export / MCP reads.
     *
     * @param mixed $value
     * @return array<string, mixed>
     */
    public static function redactForExport($value): array
    {
        $data = self::normalize($value);

        if ($data['email'] !== '') {
            $data['email'] = '[redacted]';
        }
        if ($data['password'] !== '') {
            $data['password'] = '[redacted]';
        }

        return $data;
    }

    /**
     * @param array<string, mixed> $value
     * @param array<string, mixed> $profileSettings
     * @return list<string>
     */
    public static function validate(array $value, array $profileSettings, bool $isNew = false): array
    {
        $errors = [];
        $requirements = $profileSettings['requirements'] ?? [];
        $fields = array_merge(
            (array) ($requirements['fields'] ?? []),
            (array) ($requirements['custom_fields'] ?? [])
        );

        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }
            $key = (string) ($field['key'] ?? '');
            if ($key === '') {
                continue;
            }

            $required = !empty($field['required']);
            if (!$required) {
                continue;
            }

            if ($key === 'password' && !$isNew) {
                continue;
            }

            $candidate = match ($key) {
                'email' => self::resolvePlainEmail($value['email'] ?? '', $value['email'] ?? ''),
                'password' => self::plainPasswordCandidate($value['password'] ?? ''),
                'name' => trim((string) ($value['name'] ?? '')),
                default => trim((string) (($value['custom'][$key] ?? '') ?: '')),
            };

            if ($candidate === '') {
                $label = (string) ($field['label'] ?? $key);
                $errors[] = $label . ' is required';
            }
        }

        $emailPlain = self::resolvePlainEmail($value['email'] ?? '', $value['email'] ?? '');
        if ($emailPlain !== '' && !filter_var($emailPlain, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Email is invalid';
        }

        $passwordCandidate = self::plainPasswordCandidate($value['password'] ?? '');
        if ($passwordCandidate !== '' && strlen($passwordCandidate) < 8) {
            $errors[] = 'Password must be at least 8 characters';
        }

        return $errors;
    }

    public static function isAccountFieldType(string $type): bool
    {
        return $type === 'user_account' || str_starts_with($type, 'user_account_');
    }

    public static function hashPassword(string $password): string
    {
        if (class_exists('UserService')) {
            return (new UserService())->hashPassword($password);
        }

        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 3,
        ]);
    }

    public static function isPasswordHash(string $value): bool
    {
        return (bool) preg_match('/^\$2[ay]\$|\$argon2id\$/', $value);
    }

    public static function decryptEmail(string $stored): ?string
    {
        $stored = trim($stored);
        if ($stored === '') {
            return '';
        }

        if (str_contains($stored, '@')) {
            return $stored;
        }

        $key = user_management_get_encryption_key();
        $plain = user_management_decrypt_field($stored, $key);
        if ($plain !== null) {
            return $plain;
        }

        if (function_exists('user_management_candidate_encryption_keys')) {
            foreach (user_management_candidate_encryption_keys() as $candidateKey) {
                $plain = user_management_decrypt_field($stored, $candidateKey);
                if ($plain !== null) {
                    return $plain;
                }
            }
        }

        return null;
    }

    /** @return array<string, mixed> */
    private static function resolveProfileMeta(string $typeKey): array
    {
        $store = new UserFieldtypeProfileStore();
        $profile = $store->getProfileByTypeKey($typeKey);

        return is_array($profile) ? $profile : [];
    }

    private static function resolvePlainEmail(string $incoming, string $fallbackStored): string
    {
        $incoming = trim($incoming);
        if ($incoming === '' || $incoming === self::PASSWORD_UNCHANGED) {
            return '';
        }
        if (str_contains($incoming, '@')) {
            return $incoming;
        }

        $decrypted = self::decryptEmail($incoming);
        if ($decrypted !== null && $decrypted !== '') {
            return $decrypted;
        }

        if ($fallbackStored !== '') {
            $fromFallback = self::decryptEmail($fallbackStored);
            if ($fromFallback !== null) {
                return $fromFallback;
            }
        }

        return '';
    }

    private static function resolveStoredPassword(string $incoming, string $previous): string
    {
        $incoming = trim($incoming);
        if ($incoming === '' || $incoming === self::PASSWORD_UNCHANGED) {
            return $previous;
        }
        if (self::isPasswordHash($incoming)) {
            return $incoming;
        }

        return self::hashPassword($incoming);
    }

    private static function plainPasswordCandidate(string $value): string
    {
        $value = trim($value);
        if ($value === '' || $value === self::PASSWORD_UNCHANGED || self::isPasswordHash($value)) {
            return '';
        }

        return $value;
    }

    /**
     * @param array<string, mixed> $incoming
     * @param array<string, mixed> $previous
     * @param array<string, mixed> $profileSettings
     * @return array<string, mixed>
     */
    private static function mergeCustomFields(array $incoming, array $previous, array $profileSettings): array
    {
        $merged = $previous;
        foreach ($incoming as $key => $val) {
            if (!is_string($key) || !preg_match('/^[a-z0-9_]+$/', $key)) {
                continue;
            }
            $merged[$key] = $val;
        }

        $allowed = [];
        foreach ((array) ($profileSettings['requirements']['custom_fields'] ?? []) as $field) {
            if (!is_array($field)) {
                continue;
            }
            $key = (string) ($field['key'] ?? '');
            if ($key !== '') {
                $allowed[$key] = true;
            }
        }

        if ($allowed === []) {
            return $merged;
        }

        return array_intersect_key($merged, $allowed);
    }

    private static function toBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_numeric($value)) {
            return (int) $value === 1;
        }

        $normalized = strtolower(trim((string) $value));

        return in_array($normalized, ['1', 'true', 'yes', 'on'], true);
    }
}
