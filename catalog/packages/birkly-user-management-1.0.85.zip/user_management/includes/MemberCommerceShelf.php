<?php
/**
 * Commerce shelf integration for member entries (P77-M7).
 *
 * User plugin does not embed payment logic — Commerce owns customers and billing.
 */

declare(strict_types=1);

require_once __DIR__ . '/MembershipProductRegistry.php';
require_once __DIR__ . '/MemberAccountCodec.php';
require_once __DIR__ . '/UserMemberIndexer.php';

class MemberCommerceShelf
{
    /** @var object|null */
    private ?object $customerStore = null;

    public function isAvailable(): bool
    {
        return user_management_commerce_plugin_active();
    }

    /**
     * @param array<string, mixed> $settings
     */
    public function paymentRequiredAtSignup(array $settings): bool
    {
        if (!$this->isAvailable()) {
            return false;
        }

        return !empty(($settings['commerce'] ?? [])['payment_required_at_signup']);
    }

    /**
     * @param array<string, mixed> $settings
     */
    public function paymentEnabled(array $settings): bool
    {
        if (!$this->isAvailable()) {
            return false;
        }

        $commerce = $settings['commerce'] ?? [];

        return array_key_exists('payment_enabled', $commerce)
            ? !empty($commerce['payment_enabled'])
            : true;
    }

    /**
     * @param array<string, mixed> $settings
     * @param array<string, mixed> $account
     */
    public function checkoutRequiredForSignup(array $settings, array $account): bool
    {
        if (!$this->paymentRequiredAtSignup($settings)) {
            return false;
        }

        $normalized = MemberAccountCodec::normalize($account);
        $customerId = trim((string) (($normalized['commerce']['customer_id'] ?? '') ?: ''));

        return $customerId === '';
    }

    /**
     * Resolve membership_product_ref to catalog coordinates.
     *
     * @return array{collection: string, entry_id: string, purchase_option_id: string}|null
     */
    public function resolveProductRef(?string $ref): ?array
    {
        $ref = trim((string) $ref);
        if ($ref === '') {
            return null;
        }

        foreach ((new MembershipProductRegistry())->listProducts(true) as $product) {
            if ((string) ($product['id'] ?? '') === $ref) {
                return $this->normalizeProductCoords($product);
            }
        }

        if (str_contains($ref, ':')) {
            $parts = explode(':', $ref);
            if (count($parts) >= 2) {
                return [
                    'collection' => trim((string) $parts[0]),
                    'entry_id' => trim((string) $parts[1]),
                    'purchase_option_id' => trim((string) ($parts[2] ?? '')),
                ];
            }
        }

        if (str_contains($ref, '/')) {
            $parts = explode('/', $ref);
            if (count($parts) >= 2) {
                return [
                    'collection' => trim((string) $parts[0]),
                    'entry_id' => trim((string) $parts[1]),
                    'purchase_option_id' => trim((string) ($parts[2] ?? '')),
                ];
            }
        }

        return null;
    }

    /**
     * @param array<string, mixed> $settings
     * @return array{collection: string, entry_id: string, purchase_option_id: string}|null
     */
    public function resolveProductForSettings(array $settings): ?array
    {
        $commerce = $settings['commerce'] ?? [];
        $ref = trim((string) ($commerce['membership_product_ref'] ?? ''));

        return $ref !== '' ? $this->resolveProductRef($ref) : null;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function linkCustomer(string $memberId, string $email, ?string $name = null): ?array
    {
        if (!$this->isAvailable()) {
            return null;
        }

        $memberId = trim($memberId);
        $email = strtolower(trim($email));
        if ($memberId === '' || $email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return null;
        }

        $store = $this->customerStore();
        if ($store === null) {
            return null;
        }

        try {
            $customer = $store->upsert([
                'email' => $email,
                'name' => trim((string) $name),
                'source' => 'user_management',
                'external_ids' => ['member_id' => $memberId],
            ]);

            return is_array($customer) ? $customer : null;
        } catch (Throwable $e) {
            error_log('MemberCommerceShelf linkCustomer: ' . $e->getMessage());

            return null;
        }
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findCustomerByMemberId(string $memberId): ?array
    {
        $memberId = trim($memberId);
        if ($memberId === '' || !$this->isAvailable()) {
            return null;
        }

        $store = $this->customerStore();
        if ($store === null) {
            return null;
        }

        foreach ($store->listAll() as $customer) {
            if (!is_array($customer)) {
                continue;
            }
            $external = is_array($customer['external_ids'] ?? null) ? $customer['external_ids'] : [];
            if ((string) ($external['member_id'] ?? '') === $memberId) {
                return $customer;
            }
        }

        return null;
    }

    /**
     * @return array{has_payment_method: bool, subscription_status: string|null}
     */
    public function buildPaymentSummary(?string $customerId, ?string $email = null): array
    {
        $summary = [
            'has_payment_method' => false,
            'subscription_status' => null,
        ];

        if (!$this->isAvailable()) {
            return $summary;
        }

        $email = strtolower(trim((string) $email));
        if ($customerId !== null && trim($customerId) !== '') {
            $store = $this->customerStore();
            if ($store !== null) {
                $customer = $store->getById(trim($customerId));
                if (is_array($customer)) {
                    $external = is_array($customer['external_ids'] ?? null) ? $customer['external_ids'] : [];
                    if (!empty($external['stripe_customer_id']) || !empty($external['default_payment_method'])) {
                        $summary['has_payment_method'] = true;
                    }
                    if ($email === '' && !empty($customer['email'])) {
                        $email = strtolower(trim((string) $customer['email']));
                    }
                }
            }
        }

        if ($email !== '') {
            $subs = $this->activeSubscriptionsForEmail($email);
            if ($subs !== []) {
                $summary['has_payment_method'] = true;
                $summary['subscription_status'] = (string) ($subs[0]['status'] ?? 'active');
            }
        }

        return $summary;
    }

    /**
     * @param array<string, mixed> $account
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    public function syncAccountCommerce(array $account, array $settings): array
    {
        $normalized = MemberAccountCodec::normalize($account);
        if (!$this->isAvailable() || (!$this->paymentEnabled($settings) && !$this->paymentRequiredAtSignup($settings))) {
            return $normalized;
        }

        $memberId = trim((string) ($normalized['member_id'] ?? ''));
        $email = MemberAccountCodec::decryptEmail((string) ($normalized['email'] ?? '')) ?? '';
        $commerce = is_array($normalized['commerce'] ?? null) ? $normalized['commerce'] : [];

        $customerId = trim((string) ($commerce['customer_id'] ?? ''));
        if ($customerId === '' && $memberId !== '' && $email !== '') {
            $linked = $this->linkCustomer($memberId, $email, (string) ($normalized['name'] ?? ''));
            if (is_array($linked) && !empty($linked['id'])) {
                $customerId = (string) $linked['id'];
            }
        }

        if ($customerId !== '') {
            $commerce['customer_id'] = $customerId;
        }

        $commerce['payment_summary'] = $this->buildPaymentSummary(
            $customerId !== '' ? $customerId : null,
            $email !== '' ? $email : null
        );
        $normalized['commerce'] = $commerce;

        return $normalized;
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    public function buildSignupCheckoutPayload(
        string $memberId,
        string $email,
        string $name,
        array $settings,
        string $collectionSlug
    ): array {
        $product = $this->resolveProductForSettings($settings);
        if ($product === null) {
            return ['ok' => false, 'error' => 'No membership product configured for this profile'];
        }

        $metadata = [
            'member_id' => $memberId,
            'member_collection' => $collectionSlug,
            'member_signup' => '1',
        ];

        $checkout = [
            'action' => 'begin_linked_checkout',
            'product' => [
                'collection' => $product['collection'],
                'entry_id' => $product['entry_id'],
                'purchase_option_id' => $product['purchase_option_id'],
            ],
            'customer' => [
                'email' => strtolower(trim($email)),
                'name' => trim($name),
            ],
            'metadata' => $metadata,
            'hosted_checkout' => true,
        ];

        if (function_exists('apply_filters')) {
            $checkout = apply_filters('user_commerce_checkout_required', $checkout, $memberId, $settings, $collectionSlug);
        }

        return $checkout;
    }

    /**
     * @param array<string, mixed> $checkout
     * @return array<string, mixed>
     */
    public function beginSignupCheckout(array $checkout): array
    {
        if (!$this->isAvailable()) {
            return ['ok' => false, 'error' => 'Commerce is not available'];
        }

        if (!function_exists('get_plugin_state') || !get_plugin_state('commerce')) {
            return ['ok' => false, 'error' => 'Commerce plugin is not active'];
        }

        if (function_exists('birkly_plugin_require')) {
            birkly_plugin_require('commerce', 'includes/CommerceLinkedCheckoutService.php');
            birkly_plugin_require('commerce', 'includes/CommerceCartSession.php');
            birkly_plugin_require('commerce', 'includes/CommerceCatalog.php');
            birkly_plugin_require('commerce', 'includes/CommerceCheckoutService.php');
        }

        if (!class_exists('CommerceLinkedCheckoutService')) {
            return ['ok' => false, 'error' => 'Commerce checkout service unavailable'];
        }

        try {
            $cart = new CommerceCartSession();
            $catalog = new CommerceCatalog();
            $checkoutService = new CommerceCheckoutService();
            $linked = new CommerceLinkedCheckoutService($cart, $catalog, $checkoutService);

            return $linked->begin($checkout);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * @param array<string, mixed> $settings
     * @param array<string, mixed> $account
     */
    public function buildPaymentUrl(string $memberId, array $settings, array $account): ?string
    {
        if (!$this->paymentEnabled($settings)) {
            return null;
        }

        $email = MemberAccountCodec::decryptEmail((string) ($account['email'] ?? '')) ?? '';
        $payload = $this->buildSignupCheckoutPayload(
            $memberId,
            $email,
            (string) ($account['name'] ?? ''),
            $settings,
            (string) ($account['collection_slug'] ?? '')
        );

        $url = null;
        if (function_exists('apply_filters')) {
            $url = apply_filters('user_commerce_payment_url', $url, $memberId, $settings, $account, $payload);
        }

        if (is_string($url) && trim($url) !== '') {
            return trim($url);
        }

        $hosted = $this->beginSignupCheckout($payload);
        if (!empty($hosted['checkout_url'])) {
            return (string) $hosted['checkout_url'];
        }
        if (!empty($hosted['url'])) {
            return (string) $hosted['url'];
        }

        return null;
    }

    /**
     * Attach Commerce customer to a pending member entry and publish when payment gate clears.
     */
    public function completeSignupAfterPayment(string $memberId, ?string $customerId = null): bool
    {
        $memberId = trim($memberId);
        if ($memberId === '') {
            return false;
        }

        $indexer = new UserMemberIndexer();
        $row = $indexer->getMember($memberId);
        if (!is_array($row)) {
            return false;
        }

        $collectionSlug = (string) ($row['collection_slug'] ?? '');
        $entryId = (string) ($row['entry_id'] ?? '');
        if ($collectionSlug === '' || $entryId === '') {
            return false;
        }

        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $dir = $this->resolveCollectionDir($storage, $collectionSlug);
        if ($dir === null) {
            return false;
        }

        $path = "collections/{$dir}/entries/{$entryId}.json";
        $entry = $storage->read($path);
        if (!is_array($entry)) {
            return false;
        }

        $accountField = $this->accountFieldName($collectionSlug);
        $account = MemberAccountCodec::normalize($entry[$accountField] ?? []);
        if ($customerId !== null && trim($customerId) !== '') {
            $commerce = is_array($account['commerce'] ?? null) ? $account['commerce'] : [];
            $commerce['customer_id'] = trim($customerId);
            $account['commerce'] = $commerce;
        }

        $settings = $this->profileSettingsForAccount($account, $collectionSlug);
        $account = $this->syncAccountCommerce($account, $settings);
        $entry[$accountField] = $account;

        if (($entry['status'] ?? '') === 'pending' && !$this->checkoutRequiredForSignup($settings, $account)) {
            $entry['status'] = 'published';
            $account['status'] = 'active';
            $entry[$accountField] = $account;
        }

        $entry['updated_at'] = date('c');
        if (!$storage->write($path, $entry)) {
            return false;
        }

        $indexer->indexEntry($entry, $collectionSlug);

        return true;
    }

    /**
     * @param array<string, mixed> $payload
     */
    public function handleCommerceEvent(string $event, array $payload): void
    {
        if (!$this->isAvailable()) {
            return;
        }

        $meta = is_array($payload['metadata'] ?? null) ? $payload['metadata'] : [];
        $memberId = trim((string) ($meta['member_id'] ?? $payload['member_id'] ?? ''));
        $email = strtolower(trim((string) ($payload['customer_email'] ?? $payload['email'] ?? '')));

        if ($memberId === '' && $email !== '') {
            foreach ((new UserMemberIndexer())->listMembers() as $row) {
                if (!is_array($row)) {
                    continue;
                }
                if (($row['email_hash'] ?? '') === hash('sha256', $email)) {
                    $memberId = (string) ($row['member_id'] ?? '');
                    break;
                }
            }
        }

        if ($memberId === '') {
            return;
        }

        if ($email !== '') {
            $this->linkCustomer($memberId, $email, (string) ($payload['customer_name'] ?? ''));
        }

        $customerId = trim((string) ($payload['customer_id'] ?? ''));
        if (in_array($event, [
            'commerce_order_paid',
            'commerce_subscription_started',
            'commerce_membership_started',
        ], true)) {
            $this->completeSignupAfterPayment($memberId, $customerId !== '' ? $customerId : null);
        }
    }

    /**
     * @param array<string, mixed> $product
     * @return array{collection: string, entry_id: string, purchase_option_id: string}|null
     */
    private function normalizeProductCoords(array $product): ?array
    {
        $collection = trim((string) ($product['collection'] ?? ''));
        $entryId = trim((string) ($product['entry_id'] ?? ''));
        if ($collection === '' || $entryId === '') {
            return null;
        }

        return [
            'collection' => $collection,
            'entry_id' => $entryId,
            'purchase_option_id' => trim((string) ($product['purchase_option_id'] ?? '')),
        ];
    }

    /** @return list<array<string, mixed>> */
    private function activeSubscriptionsForEmail(string $email): array
    {
        if (function_exists('get_plugin_service')) {
            $shelf = get_plugin_service('commerce_shelf', false, 'user_management')
                ?? get_plugin_service('payment_shelf', false, 'user_management');
            if (is_object($shelf) && method_exists($shelf, 'getActiveSubscriptionsForEmail')) {
                try {
                    $subs = $shelf->getActiveSubscriptionsForEmail($email);
                    if (is_array($subs)) {
                        return $subs;
                    }
                } catch (Throwable $e) {
                    error_log('MemberCommerceShelf subscriptions: ' . $e->getMessage());
                }
            }
        }

        if (!class_exists('CommerceSubscriptionStore')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceSubscriptionStore.php')) {
                require_once $pluginDir . '/includes/CommerceSubscriptionStore.php';
            }
        }
        if (!class_exists('CommerceSubscriptionStore')) {
            return [];
        }

        $email = strtolower(trim($email));
        $active = [];
        foreach ((new CommerceSubscriptionStore())->listAll() as $sub) {
            if (!is_array($sub) || strtolower(trim((string) ($sub['customer_email'] ?? ''))) !== $email) {
                continue;
            }
            $status = (string) ($sub['status'] ?? '');
            if (in_array($status, ['active', 'paused', 'past_due'], true)) {
                $active[] = $sub;
            }
        }

        return $active;
    }

  /** @return object|null */
    private function customerStore(): ?object
    {
        if ($this->customerStore !== null) {
            return $this->customerStore;
        }

        if (!$this->isAvailable()) {
            return null;
        }

        if (!class_exists('CommerceCustomerStore')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir === '') {
                $pluginDir = dirname(__DIR__, 2) . '/birkly-plugin-commerce';
            }
            $path = $pluginDir . '/includes/CommerceCustomerStore.php';
            if (!is_file($path)) {
                return null;
            }
            require_once $path;
            if (!function_exists('commerce_data_dir') && is_file($pluginDir . '/init.php')) {
                require_once $pluginDir . '/init.php';
            }
        }

        if (!class_exists('CommerceCustomerStore')) {
            return null;
        }

        $dataDir = null;
        if (!empty($GLOBALS['user_management_test_commerce_customers_dir'])) {
            $dataDir = (string) $GLOBALS['user_management_test_commerce_customers_dir'];
        }

        $this->customerStore = $dataDir !== null
            ? new CommerceCustomerStore($dataDir)
            : new CommerceCustomerStore();

        return $this->customerStore;
    }

    public function setCustomerStore(?object $store): void
    {
        $this->customerStore = $store;
    }

    private function accountFieldName(string $collectionSlug): string
    {
        require_once __DIR__ . '/UserCollectionResolver.php';
        $field = (new UserCollectionResolver())->getAccountFieldOnSchema($collectionSlug);

        return (string) ($field['name'] ?? 'account');
    }

    /** @return array<string, mixed> */
    private function profileSettingsForAccount(array $account, string $collectionSlug): array
    {
        require_once __DIR__ . '/UserFieldtypeProfileStore.php';
        require_once __DIR__ . '/UserCollectionResolver.php';

        $resolver = new UserCollectionResolver();
        $field = $resolver->getAccountFieldOnSchema($collectionSlug);
        $typeKey = (string) ($field['type'] ?? 'user_account');

        return (new UserFieldtypeProfileStore())->getSettingsForTypeKey($typeKey);
    }

    private function resolveCollectionDir(Storage $storage, string $collectionSlug): ?string
    {
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (is_array($meta) && (string) ($meta['slug'] ?? '') === $collectionSlug) {
                return (string) $dir;
            }
        }

        if (is_dir(user_management_cms_path('content/collections/' . $collectionSlug))) {
            return $collectionSlug;
        }

        return null;
    }
}
