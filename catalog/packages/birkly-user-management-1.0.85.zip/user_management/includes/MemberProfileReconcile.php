<?php
/**
 * Keep club profile collection entries in sync with User List (P77).
 */

declare(strict_types=1);

require_once __DIR__ . '/MemberMigrateService.php';
require_once __DIR__ . '/UserCollectionResolver.php';

/**
 * Ensure every active User List account has a club-profiles entry with account field.
 * Idempotent — safe on plugin load, user create, and manual sync.
 *
 * @return array<string, int|list<string>>|null null when reconcile not applicable
 */
function user_management_reconcile_member_profiles(?string $collection = null): ?array
{
    $collection = trim((string) ($collection ?? 'club-profiles'));
    if ($collection === '') {
        return null;
    }

    $resolver = new UserCollectionResolver();
    if ($resolver->getAccountFieldOnSchema($collection) === null) {
        return null;
    }

    return user_management_migrate_p77_members([
        'collection' => $collection,
        'dry_run' => false,
    ]);
}

/**
 * Grant club tier when the site user has a published club-profiles entry.
 */
function user_management_ensure_club_tier_for_user(string $userId): bool
{
    $userId = trim($userId);
    if ($userId === '' || $userId === ClubProfileService::SYSTEM_USER_ID) {
        return false;
    }

    require_once __DIR__ . '/ClubProfileService.php';
    require_once __DIR__ . '/UserService.php';
    require_once __DIR__ . '/UserTiers.php';

    $service = new UserService();
    try {
        $user = $service->getUser($userId);
    } catch (Throwable $e) {
        return false;
    }
    if (!is_array($user) || !empty($user['deleted'])) {
        return false;
    }
    if ((string) ($user['tier'] ?? 'all') === 'club') {
        return false;
    }

    $profiles = new ClubProfileService();
    if ($profiles->getProfileByUserId($userId) === null) {
        return false;
    }

    try {
        (new UserTiers())->setUserTier($userId, 'club');

        return true;
    } catch (Throwable $e) {
        error_log('User Management club tier ensure failed for ' . $userId . ': ' . $e->getMessage());

        return false;
    }
}

/**
 * Grant club tier to site users who have a club-profiles entry but are still on all/basic.
 * Repairs incomplete club_free_register signups (profile created, tier grant skipped).
 *
 * @return array{updated: int, user_ids: list<string>}|null
 */
function user_management_reconcile_club_tiers(?string $collection = null): ?array
{
    $collection = trim((string) ($collection ?? 'club-profiles'));
    if ($collection === '') {
        return null;
    }

    require_once __DIR__ . '/ClubProfileService.php';

    $profiles = new ClubProfileService();
    if (!$profiles->collectionExists()) {
        return null;
    }

    $updated = 0;
    $userIds = [];

    foreach ($profiles->listPublishedProfiles() as $profile) {
        if (!is_array($profile)) {
            continue;
        }
        $userId = trim((string) ($profile['user_id'] ?? $profile['owner'] ?? ''));
        if ($userId === '' && isset($profile['account']) && is_array($profile['account'])) {
            $userId = trim((string) ($profile['account']['legacy_user_id'] ?? ''));
        }
        if ($userId === '' || $userId === ClubProfileService::SYSTEM_USER_ID) {
            continue;
        }
        if (user_management_ensure_club_tier_for_user($userId)) {
            $updated++;
            $userIds[] = $userId;
        }
    }

    return ['updated' => $updated, 'user_ids' => $userIds];
}

/**
 * Repair club tier on login for members who already have a profile.
 */
function user_management_register_club_tier_hooks(): void
{
    if (!function_exists('register_hook')) {
        return;
    }

    register_hook('user_logged_in', function ($user): void {
        if (!is_array($user)) {
            return;
        }
        $userId = trim((string) ($user['id'] ?? ''));
        if ($userId === '') {
            return;
        }
        user_management_ensure_club_tier_for_user($userId);
    });
}
