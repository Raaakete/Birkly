<?php
/**
 * Blocks site user deletion when active Commerce subscriptions exist.
 */

declare(strict_types=1);

class UserDeleteGuard
{
    /**
     * @return list<array<string, mixed>>
     */
    public function getBlockingSubscriptionsForEmail(string $email): array
    {
        $email = strtolower(trim($email));
        if ($email === '') {
            return [];
        }

        return $this->summarizeSubscriptions($this->subscriptionsFromStore($email));
    }

    /**
     * @param array<string, mixed> $user
     * @param array<string, mixed> $options
     */
    public function assertCanDelete(array $user, array $options = []): void
    {
        $email = strtolower(trim((string) ($user['email'] ?? '')));
        if ($email === '') {
            return;
        }

        $blocking = $this->getBlockingSubscriptionsForEmail($email);
        if ($blocking === []) {
            return;
        }

        if (!empty($options['force_cancel_subscriptions'])) {
            $this->cancelSubscriptions($blocking);

            return;
        }

        throw new UserDeleteBlockedException(
            'Cannot delete user with active subscriptions. Cancel subscriptions first or confirm cancellation.',
            $blocking
        );
    }

    /**
     * @param list<array<string, mixed>> $subscriptions
     * @return list<array<string, mixed>>
     */
    private function summarizeSubscriptions(array $subscriptions): array
    {
        $out = [];
        foreach ($subscriptions as $sub) {
            if (!is_array($sub)) {
                continue;
            }
            $status = (string) ($sub['status'] ?? '');
            if (!in_array($status, ['active', 'paused', 'past_due', 'trialing'], true)) {
                continue;
            }
            $line = is_array($sub['lines'][0] ?? null) ? $sub['lines'][0] : [];
            $out[] = [
                'id' => (string) ($sub['id'] ?? ''),
                'status' => $status,
                'interval' => (string) ($sub['interval'] ?? ''),
                'amount_cents' => (int) ($sub['amount_cents'] ?? 0),
                'currency' => (string) ($sub['currency'] ?? 'eur'),
                'purchase_option_id' => (string) ($line['purchase_option_id'] ?? $sub['purchase_option_id'] ?? ''),
                'collection_slug' => (string) ($line['collection_slug'] ?? $sub['collection_slug'] ?? ''),
                'entry_id' => (string) ($line['entry_id'] ?? $sub['entry_id'] ?? ''),
            ];
        }

        return $out;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function subscriptionsFromStore(string $email): array
    {
        if (!class_exists('CommerceSubscriptionStore')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceSubscriptionStore.php')) {
                require_once $pluginDir . '/includes/CommerceSubscriptionStore.php';
            }
        }
        if (!class_exists('CommerceSubscriptionStore')) {
            return [];
        }

        $email = strtolower(trim($email));
        $active = [];
        try {
            foreach ((new CommerceSubscriptionStore())->listAll() as $sub) {
                if (!is_array($sub) || strtolower(trim((string) ($sub['customer_email'] ?? ''))) !== $email) {
                    continue;
                }
                $status = (string) ($sub['status'] ?? '');
                if (in_array($status, ['active', 'paused', 'past_due', 'trialing'], true)) {
                    $active[] = $sub;
                }
            }
        } catch (Throwable $e) {
            error_log('UserDeleteGuard subscription store lookup: ' . $e->getMessage());
        }

        return $active;
    }

    /**
     * @param list<array<string, mixed>> $subscriptions
     */
    private function cancelSubscriptions(array $subscriptions): void
    {
        if (!class_exists('CommerceSubscriptionService')) {
            $pluginDir = function_exists('commerce_plugin_dir') ? commerce_plugin_dir() : '';
            if ($pluginDir !== '' && is_file($pluginDir . '/includes/CommerceSubscriptionService.php')) {
                require_once $pluginDir . '/includes/CommerceSubscriptionService.php';
            }
        }
        if (!class_exists('CommerceSubscriptionService')) {
            throw new RuntimeException('Commerce is not available to cancel subscriptions');
        }

        $service = new CommerceSubscriptionService();
        foreach ($subscriptions as $sub) {
            $id = (string) ($sub['id'] ?? '');
            if ($id === '') {
                continue;
            }
            $service->cancel($id);
        }
    }
}
