<?php
/**
 * Parse @mentions in club posts and comments (P80-M3).
 */

declare(strict_types=1);

require_once __DIR__ . '/ClubProfileService.php';

class ClubMentionParser
{
    private ClubProfileService $profiles;

    /** @var array{by_slug: array<string, string>, by_title: array<string, string>}|null */
    private ?array $lookup = null;

    public function __construct(?ClubProfileService $profiles = null)
    {
        $this->profiles = $profiles ?? new ClubProfileService();
    }

    /**
     * @return list<string>
     */
    public function parseMentionedUserIds(string $text, ?string $excludeUserId = null): array
    {
        $tokens = $this->extractMentionTokens($this->stripHtml($text));
        if ($tokens === []) {
            return [];
        }

        $lookup = $this->buildLookupMap();
        $ids = [];
        foreach ($tokens as $token) {
            $userId = $this->resolveToken($token, $lookup);
            if ($userId === '' || ($excludeUserId !== null && $userId === $excludeUserId)) {
                continue;
            }
            $ids[$userId] = $userId;
        }

        return array_values($ids);
    }

    /**
     * @param list<string> $userIds
     */
    public function encodeMentionedUserIds(array $userIds): string
    {
        $normalized = array_values(array_unique(array_filter(array_map('strval', $userIds))));

        return json_encode($normalized, JSON_UNESCAPED_UNICODE) ?: '[]';
    }

    /**
     * @return list<string>
     */
    public function decodeMentionedUserIds(mixed $value): array
    {
        if (is_array($value)) {
            return array_values(array_unique(array_filter(array_map('strval', $value))));
        }
        if (!is_string($value) || trim($value) === '') {
            return [];
        }
        $decoded = json_decode($value, true);

        return is_array($decoded)
            ? array_values(array_unique(array_filter(array_map('strval', $decoded))))
            : [];
    }

    /**
     * @return list<string>
     */
    private function extractMentionTokens(string $text): array
    {
        if ($text === '') {
            return [];
        }

        $tokens = [];
        if (preg_match_all('/@"([^"]+)"/u', $text, $quoted) > 0) {
            foreach ($quoted[1] as $name) {
                $name = trim((string) $name);
                if ($name !== '') {
                    $tokens[] = $name;
                }
            }
        }

        if (preg_match_all('/@([A-Za-z0-9][A-Za-z0-9_-]*)/u', $text, $simple) > 0) {
            foreach ($simple[1] as $token) {
                $token = trim((string) $token);
                if ($token !== '') {
                    $tokens[] = $token;
                }
            }
        }

        $lookup = $this->buildLookupMap();
        if (preg_match_all('/@([^\s@]+(?:\s+[^\s@]+)*)/u', $text, $spaced) > 0) {
            foreach ($spaced[1] as $candidate) {
                $candidate = trim((string) $candidate);
                if ($candidate === '') {
                    continue;
                }
                $resolved = $this->resolveToken($candidate, $lookup);
                if ($resolved !== '' && !in_array($candidate, $tokens, true)) {
                    $tokens[] = $candidate;
                }
            }
        }

        return array_values(array_unique($tokens));
    }

    /**
     * @param array{by_slug: array<string, string>, by_title: array<string, string>} $lookup
     */
    private function resolveToken(string $token, array $lookup): string
    {
        $slugKey = strtolower(trim($token));
        if ($slugKey !== '' && isset($lookup['by_slug'][$slugKey])) {
            return $lookup['by_slug'][$slugKey];
        }

        $titleKey = strtolower(trim($token));
        if ($titleKey !== '' && isset($lookup['by_title'][$titleKey])) {
            return $lookup['by_title'][$titleKey];
        }

        return '';
    }

    /**
     * @return array{by_slug: array<string, string>, by_title: array<string, string>}
     */
    private function buildLookupMap(): array
    {
        if ($this->lookup !== null) {
            return $this->lookup;
        }

        $bySlug = [];
        $byTitle = [];
        foreach ($this->profiles->listClubDirectory() as $member) {
            $userId = trim((string) ($member['user_id'] ?? ''));
            if ($userId === '' || $userId === ClubProfileService::SYSTEM_USER_ID) {
                continue;
            }
            $slug = strtolower(trim((string) ($member['slug'] ?? '')));
            if ($slug !== '' && !isset($bySlug[$slug])) {
                $bySlug[$slug] = $userId;
            }
            $title = strtolower(trim((string) ($member['title'] ?? '')));
            if ($title !== '' && !isset($byTitle[$title])) {
                $byTitle[$title] = $userId;
            }
        }

        $this->lookup = ['by_slug' => $bySlug, 'by_title' => $byTitle];

        return $this->lookup;
    }

    private function stripHtml(string $text): string
    {
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = strip_tags($text);
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;

        return trim($text);
    }

    /**
     * SSR-safe mention linkification for template function render_mentions (P81-M8).
     */
    public function renderMentionsHtml(string $text, string $profileUrlPrefix = '/club/member.html?slug='): string
    {
        if ($text === '') {
            return '';
        }

        $lookup = $this->buildLookupMap();
        $slugByUserId = $this->buildSlugByUserIdMap();
        $escaped = htmlspecialchars($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        $linkify = function (string $token) use ($lookup, $slugByUserId, $profileUrlPrefix): string {
            $userId = $this->resolveToken($token, $lookup);
            if ($userId === '') {
                return '@' . htmlspecialchars($token, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }
            $slug = $slugByUserId[$userId] ?? $token;
            $href = htmlspecialchars($profileUrlPrefix . rawurlencode($slug), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $label = '@' . htmlspecialchars($token, ENT_QUOTES | ENT_HTML5, 'UTF-8');

            return '<a href="' . $href . '" class="mention" rel="nofollow">' . $label . '</a>';
        };

        $escaped = preg_replace_callback('/@"([^"]+)"/u', static function (array $m) use ($linkify): string {
            return $linkify((string) $m[1]);
        }, $escaped) ?? $escaped;

        return preg_replace_callback('/@([A-Za-z0-9][A-Za-z0-9_-]*)/u', static function (array $m) use ($linkify): string {
            return $linkify((string) $m[1]);
        }, $escaped) ?? $escaped;
    }

    /**
     * @return array<string, string>
     */
    private function buildSlugByUserIdMap(): array
    {
        $map = [];
        foreach ($this->profiles->listClubDirectory() as $member) {
            $userId = trim((string) ($member['user_id'] ?? ''));
            $slug = trim((string) ($member['slug'] ?? ''));
            if ($userId !== '' && $slug !== '' && !isset($map[$userId])) {
                $map[$userId] = $slug;
            }
        }

        return $map;
    }
}
