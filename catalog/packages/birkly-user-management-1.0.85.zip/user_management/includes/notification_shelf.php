<?php
/**
 * User Management notification shelf registrations (P83-M3).
 */

declare(strict_types=1);

if (!function_exists('register_broadcast_actor')) {
    return;
}

if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
    return;
}

register_broadcast_actor('user_management', ['user_management'], ['user_']);
