<?php
/**
 * Registers user notification event handlers (marker-driven; P81-M5).
 */

declare(strict_types=1);

require_once __DIR__ . '/UserNotificationService.php';
require_once __DIR__ . '/UserPluginCollectionConfig.php';
require_once __DIR__ . '/EntryOwnership.php';

function club_notification_register_hooks(): void
{
    if (!function_exists('register_hook')) {
        return;
    }

    register_hook('sub_entry_created', function (
        $subEntryId,
        $data,
        $parentCollection,
        $parentEntryId,
        $subCollection
    ): void {
        if (!is_array($data)) {
            return;
        }
        $parentCollection = (string) $parentCollection;
        if ($parentCollection === '') {
            return;
        }
        try {
            (new UserNotificationService())->handleSubEntryCreated(
                (string) $subEntryId,
                $data,
                $parentCollection,
                (string) $parentEntryId,
                (string) $subCollection
            );
        } catch (Throwable $e) {
            error_log('User notification sub_entry_created failed: ' . $e->getMessage());
        }
    });

    register_hook('after_entry_save', function ($entry, $collection, $oldEntry = null): void {
        if (!is_array($entry)) {
            return;
        }
        $collectionSlug = is_string($collection) ? $collection : (is_array($collection) ? (string) ($collection['slug'] ?? '') : '');
        if ($collectionSlug === '') {
            return;
        }

        $isNew = !is_array($oldEntry) || empty($oldEntry['id']);
        if (!$isNew) {
            return;
        }

        try {
            $service = new UserNotificationService();
            if (
                UserPluginCollectionConfig::notificationsEnabled($collectionSlug, UserNotificationService::TYPE_FOLLOWING_POST)
                || UserPluginCollectionConfig::notificationsEnabled($collectionSlug, UserNotificationService::TYPE_BIRKLY_POST)
            ) {
                $service->handlePostCreated($entry, $collectionSlug);
                if (function_exists('do_action') && UserPluginCollectionConfig::isUgcCollection($collectionSlug)) {
                    $authorId = EntryOwnership::getEntryOwnerId($entry, $collectionSlug) ?? '';
                    do_action('club_post_created', [
                        'entry_id' => (string) ($entry['id'] ?? ''),
                        'title' => trim((string) ($entry['title'] ?? '')),
                        'slug' => trim((string) ($entry['slug'] ?? '')),
                        'user_id' => $authorId,
                        'collection' => $collectionSlug,
                    ]);
                }
            }
            if (UserPluginCollectionConfig::notificationsEnabled($collectionSlug, UserNotificationService::TYPE_DEAL)) {
                $service->handleDealCreated($entry, $collectionSlug);
            }
        } catch (Throwable $e) {
            error_log('User notification after_entry_save failed: ' . $e->getMessage());
        }
    }, 20);
}
