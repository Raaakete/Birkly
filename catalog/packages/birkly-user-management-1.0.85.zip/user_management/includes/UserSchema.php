<?php
/**
 * User fieldtype profile settings schema (P77).
 */

declare(strict_types=1);

class UserSchema
{
    public const VISIBILITY_PUBLIC = 'public';
    public const VISIBILITY_MEMBERS = 'members_only';
    public const VISIBILITY_PRIVATE = 'private';

    /** @return list<string> */
    public static function visibilityOptions(): array
    {
        return [
            self::VISIBILITY_PUBLIC,
            self::VISIBILITY_MEMBERS,
            self::VISIBILITY_PRIVATE,
        ];
    }

    /** @return list<array<string, mixed>> */
    public static function defaultRequirementFields(): array
    {
        return [
            ['key' => 'email', 'type' => 'email', 'label' => 'Email', 'required' => true, 'encrypted' => true, 'builtin' => true],
            ['key' => 'password', 'type' => 'password', 'label' => 'Password', 'required' => true, 'builtin' => true],
            ['key' => 'name', 'type' => 'text', 'label' => 'Name', 'required' => true, 'builtin' => true],
        ];
    }
}
