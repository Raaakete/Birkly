<?php
/**
 * Club member profile entries (club-profiles collection).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';
$storageBootstrap = user_management_cms_path('api/storage.php');
if (is_file($storageBootstrap)) {
    require_once $storageBootstrap;
}
require_once __DIR__ . '/UserService.php';
require_once __DIR__ . '/UserStorage.php';

class ClubProfileService
{
    public const COLLECTION = 'club-profiles';
    public const SYSTEM_USER_ID = '__birkly__';

    private Storage $storage;

    public function __construct()
    {
        $this->storage = new Storage(user_management_cms_path('content'));
    }

    public function collectionExists(): bool
    {
        return is_dir(user_management_cms_path('content/collections/' . self::COLLECTION));
    }

    /**
     * @return array{avatar: bool, bio: bool, links: bool, interests: bool}
     */
    public function completenessSteps(array $profile): array
    {
        $avatar = $this->normalizeAvatarUrl($profile['avatar'] ?? null) !== '';
        $bio = trim((string) ($profile['bio'] ?? $profile['description'] ?? '')) !== '';
        $links = trim((string) ($profile['links'] ?? '')) !== ''
            || trim((string) ($profile['website'] ?? '')) !== '';
        $interests = trim((string) ($profile['interests'] ?? '')) !== '';

        return [
            'avatar' => $avatar,
            'bio' => $bio,
            'links' => $links,
            'interests' => $interests,
        ];
    }

    public function computeCompleteness(array $profile): int
    {
        $steps = $this->completenessSteps($profile);
        $done = count(array_filter($steps));

        return (int) round(($done / 4) * 100);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getProfileBySlug(string $slug): ?array
    {
        $slug = trim(strtolower($slug));
        if ($slug === '' || !$this->collectionExists()) {
            return null;
        }

        $results = $this->storage->query(self::COLLECTION, ['slug' => $slug], ['limit' => 1]);
        if (!is_array($results) || count($results) === 0 || !is_array($results[0])) {
            return null;
        }

        $entry = $results[0];
        if (($entry['status'] ?? 'published') !== 'published') {
            return null;
        }

        $userId = self::resolveEntryUserId($entry);
        if ($userId !== '') {
            $entry['user_id'] = $userId;
        }

        return $entry;
    }

    /**
     * Guest-readable member profile shape.
     *
     * @param array<string, mixed> $profile
     *
     * @return array<string, mixed>
     */
    public function toPublicProfile(array $profile): array
    {
        $userId = (string) ($profile['user_id'] ?? '');
        $memberSince = (string) ($profile['created_at'] ?? '');
        if ($userId !== '' && $userId !== self::SYSTEM_USER_ID) {
            $user = (new UserService(new UserStorage()))->getUser($userId);
            if (is_array($user) && !empty($user['created_at'])) {
                $memberSince = (string) $user['created_at'];
            }
        }

        return [
            'user_id' => $userId,
            'slug' => trim((string) ($profile['slug'] ?? '')),
            'title' => trim((string) ($profile['title'] ?? '')),
            'bio' => trim((string) ($profile['bio'] ?? $profile['description'] ?? '')),
            'description' => trim((string) ($profile['description'] ?? $profile['bio'] ?? '')),
            'website' => trim((string) ($profile['website'] ?? '')),
            'links' => trim((string) ($profile['links'] ?? '')),
            'interests' => trim((string) ($profile['interests'] ?? '')),
            'avatar' => $this->normalizeAvatarUrl($profile['avatar'] ?? null),
            'supporter_badge' => trim((string) ($profile['supporter_badge'] ?? 'none')) ?: 'none',
            'supporter_cadence' => trim((string) ($profile['supporter_cadence'] ?? 'none')) ?: 'none',
            'supporter_amount_eur' => round((float) ($profile['supporter_amount_eur'] ?? 0), 2),
            'member_since' => $memberSince,
            'profile_completeness' => (int) ($profile['profile_completeness'] ?? $this->computeCompleteness($profile)),
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getProfileByUserId(string $userId): ?array
    {
        if ($userId === '' || !$this->collectionExists()) {
            return null;
        }

        $byUser = $this->loadAllProfilesByUserId();
        if (isset($byUser[$userId])) {
            return $byUser[$userId];
        }

        $results = $this->storage->query(self::COLLECTION, ['user_id' => $userId], ['limit' => 1]);
        if (is_array($results) && count($results) > 0 && is_array($results[0])) {
            return $results[0];
        }

        return null;
    }

    /**
     * @param array<string, mixed> $fields
     *
     * @return array<string, mixed>
     */
    public function saveProfileForUser(string $userId, array $fields): array
    {
        if ($userId === '') {
            throw new InvalidArgumentException('User id required');
        }
        if (!$this->collectionExists()) {
            throw new RuntimeException('Club profiles collection is not configured');
        }

        $existing = $this->getProfileByUserId($userId);
        $now = date('c');
        $title = trim((string) ($fields['title'] ?? $fields['name'] ?? ''));
        if ($title === '') {
            throw new InvalidArgumentException('Display name is required');
        }

        if ($existing) {
            $entry = $existing;
            $entry['title'] = $title;
            if (array_key_exists('bio', $fields)) {
                $entry['bio'] = trim((string) $fields['bio']);
            }
            if (array_key_exists('description', $fields)) {
                $entry['description'] = trim((string) $fields['description']);
            }
            if (array_key_exists('website', $fields)) {
                $entry['website'] = trim((string) $fields['website']);
            }
            if (array_key_exists('links', $fields)) {
                $entry['links'] = trim((string) $fields['links']);
            }
            if (array_key_exists('interests', $fields)) {
                $entry['interests'] = trim((string) $fields['interests']);
            }
            if (array_key_exists('onboarding_completed', $fields)) {
                $entry['onboarding_completed'] = $this->normalizeCheckboxField($fields['onboarding_completed']);
            }
            if (array_key_exists('avatar', $fields) && $fields['avatar'] !== null && $fields['avatar'] !== '') {
                $entry['avatar'] = $this->normalizeAvatarField($fields['avatar']);
            }
            foreach (['supporter_badge', 'supporter_cadence', 'supporter_amount_eur', 'supporter_entry_id', 'supporter_synced_at'] as $badgeKey) {
                if (array_key_exists($badgeKey, $fields)) {
                    $entry[$badgeKey] = $this->normalizeBadgeFieldValue($badgeKey, $fields[$badgeKey]);
                }
            }
            if (array_key_exists('notification_prefs', $fields)) {
                $entry['notification_prefs'] = $this->normalizeNotificationPrefs($fields['notification_prefs']);
            }
            $entry['user_id'] = $userId;
            $entry['updated_at'] = $now;
            $entry['status'] = $entry['status'] ?? 'published';
            $entry['profile_completeness'] = $this->computeCompleteness($entry);
            $this->writeEntry($entry);

            return $entry;
        }

        $slug = $this->uniqueSlug($this->slugify($title));
        $entryId = 'club_profile_' . substr(sha1($userId), 0, 12);
        $entry = [
            'id' => $entryId,
            'slug' => $slug,
            'title' => $title,
            'user_id' => $userId,
            'bio' => trim((string) ($fields['bio'] ?? '')),
            'description' => trim((string) ($fields['description'] ?? $fields['bio'] ?? '')),
            'website' => trim((string) ($fields['website'] ?? '')),
            'links' => trim((string) ($fields['links'] ?? '')),
            'interests' => trim((string) ($fields['interests'] ?? '')),
            'onboarding_completed' => $this->normalizeCheckboxField($fields['onboarding_completed'] ?? false),
            'avatar' => $this->normalizeAvatarField($fields['avatar'] ?? null),
            'supporter_badge' => $this->normalizeBadgeFieldValue('supporter_badge', $fields['supporter_badge'] ?? 'none'),
            'supporter_cadence' => $this->normalizeBadgeFieldValue('supporter_cadence', $fields['supporter_cadence'] ?? 'none'),
            'supporter_amount_eur' => $this->normalizeBadgeFieldValue('supporter_amount_eur', $fields['supporter_amount_eur'] ?? 0),
            'supporter_entry_id' => $this->normalizeBadgeFieldValue('supporter_entry_id', $fields['supporter_entry_id'] ?? ''),
            'supporter_synced_at' => $this->normalizeBadgeFieldValue('supporter_synced_at', $fields['supporter_synced_at'] ?? ''),
            'notification_prefs' => $this->normalizeNotificationPrefs($fields['notification_prefs'] ?? null),
            'status' => 'published',
            'created_at' => $now,
            'updated_at' => $now,
        ];
        $entry['profile_completeness'] = $this->computeCompleteness($entry);
        $this->writeEntry($entry);

        if (function_exists('do_action')) {
            do_action('club_profile_created', [
                'user_id' => $userId,
                'profile_slug' => $slug,
                'entry_id' => $entryId,
            ]);
        }

        return $entry;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listPublishedProfiles(): array
    {
        return array_values($this->loadAllProfilesByUserId());
    }

    /**
     * Sync-only badge field updates (preserves title, bio, avatar).
     *
     * @param array<string, mixed> $badgeFields
     *
     * @return array<string, mixed>
     */
    public function updateBadgeFieldsForUser(string $userId, array $badgeFields): array
    {
        if ($userId === '') {
            throw new InvalidArgumentException('User id required');
        }
        if (!$this->collectionExists()) {
            return ['ok' => false, 'error' => 'Club profiles collection is not configured'];
        }

        $existing = $this->getProfileByUserId($userId);
        if ($existing === null) {
            return ['ok' => true, 'skipped' => true, 'reason' => 'no_profile'];
        }

        $entry = $existing;
        foreach (['supporter_badge', 'supporter_cadence', 'supporter_amount_eur', 'supporter_entry_id', 'supporter_synced_at'] as $key) {
            if (array_key_exists($key, $badgeFields)) {
                $entry[$key] = $this->normalizeBadgeFieldValue($key, $badgeFields[$key]);
            }
        }
        $entry['updated_at'] = date('c');
        $this->writeEntry($entry);

        return ['ok' => true, 'updated' => true, 'profile' => $entry];
    }

    /**
     * Club member directory: all active club-tier site users merged with profile entries.
     *
     * @return list<array<string, mixed>>
     */
    public function listClubDirectory(): array
    {
        $profilesByUser = $this->loadAllProfilesByUserId();
        $members = [];

        $system = $profilesByUser[self::SYSTEM_USER_ID] ?? $this->getProfileByUserId(self::SYSTEM_USER_ID);
        if (is_array($system)) {
            $members[] = $this->normalizeDirectoryMember($system, self::SYSTEM_USER_ID);
        } else {
            $members[] = [
                'user_id' => self::SYSTEM_USER_ID,
                'title' => 'Birkly',
                'bio' => 'The Birkly team',
                'description' => 'The Birkly team',
                'website' => 'https://birkly.io',
                'links' => '',
                'avatar' => '',
            ];
        }

        $service = new UserService(new UserStorage());
        foreach ($service->listUsers(['status' => 'active'], 500, 0) as $user) {
            if (!is_array($user) || !empty($user['deleted'])) {
                continue;
            }
            $userId = (string) ($user['id'] ?? '');
            if ($userId === '' || $userId === self::SYSTEM_USER_ID) {
                continue;
            }
            $tier = (string) ($user['tier'] ?? 'all');
            if ($tier !== 'club') {
                continue;
            }
            $profile = $profilesByUser[$userId] ?? [];
            $members[] = $this->normalizeDirectoryMember($profile, $userId, $user);
        }

        usort($members, static function (array $a, array $b): int {
            if (($a['user_id'] ?? '') === self::SYSTEM_USER_ID) {
                return -1;
            }
            if (($b['user_id'] ?? '') === self::SYSTEM_USER_ID) {
                return 1;
            }

            return strcasecmp((string) ($a['title'] ?? ''), (string) ($b['title'] ?? ''));
        });

        return $members;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    public function profileMapByUserId(): array
    {
        $map = [];
        foreach ($this->listClubDirectory() as $member) {
            $userId = (string) ($member['user_id'] ?? '');
            if ($userId !== '') {
                $map[$userId] = $member;
            }
        }

        return $map;
    }

    public function normalizeAvatarUrl(mixed $avatar): string
    {
        if (is_string($avatar) && trim($avatar) !== '') {
            return trim($avatar);
        }
        if (is_array($avatar)) {
            foreach (['url', 'src', 'path', 'public_url'] as $key) {
                if (!empty($avatar[$key]) && is_string($avatar[$key])) {
                    return trim($avatar[$key]);
                }
            }
            if (!empty($avatar['id']) && is_string($avatar['id'])) {
                $id = (string) $avatar['id'];
                if (str_starts_with($id, 'avatar-')) {
                    return '/media/avatars/' . $id . '.jpg';
                }

                return '/media/' . ltrim($id, '/');
            }
        }

        return '';
    }

    public function normalizeAvatarField(mixed $avatar): mixed
    {
        if ($avatar === null || $avatar === '') {
            return null;
        }
        if (is_string($avatar)) {
            $url = trim($avatar);
            return $url === '' ? null : $url;
        }
        if (!is_array($avatar)) {
            return null;
        }

        $url = $this->normalizeAvatarUrl($avatar);
        $id = trim((string) ($avatar['id'] ?? ''));
        if ($id !== '' && $url !== '') {
            return ['id' => $id, 'url' => $url];
        }
        if ($url !== '') {
            return $url;
        }

        return null;
    }

    /**
     * @param array<string, mixed> $profile
     * @param array<string, mixed>|null $user
     *
     * @return array<string, mixed>
     */
    private function normalizeDirectoryMember(array $profile, string $userId, ?array $user = null): array
    {
        $title = trim((string) ($profile['title'] ?? ''));
        if ($title === '' && is_array($user)) {
            $title = trim((string) ($user['name'] ?? $user['email'] ?? 'Club member'));
        }
        if ($title === '') {
            $title = 'Club member';
        }

        return [
            'user_id' => $userId,
            'slug' => trim((string) ($profile['slug'] ?? '')),
            'title' => $title,
            'bio' => trim((string) ($profile['bio'] ?? $profile['description'] ?? '')),
            'description' => trim((string) ($profile['description'] ?? $profile['bio'] ?? '')),
            'website' => trim((string) ($profile['website'] ?? '')),
            'links' => trim((string) ($profile['links'] ?? '')),
            'avatar' => $this->normalizeAvatarUrl($profile['avatar'] ?? null),
            'supporter_badge' => trim((string) ($profile['supporter_badge'] ?? 'none')) ?: 'none',
            'supporter_cadence' => trim((string) ($profile['supporter_cadence'] ?? 'none')) ?: 'none',
            'supporter_amount_eur' => round((float) ($profile['supporter_amount_eur'] ?? 0), 2),
            'interests' => trim((string) ($profile['interests'] ?? '')),
            'profile_completeness' => (int) ($profile['profile_completeness'] ?? $this->computeCompleteness($profile)),
        ];
    }

    private function normalizeCheckboxField(mixed $value): string
    {
        if ($value === true || $value === 1) {
            return '1';
        }
        if (is_string($value)) {
            $normalized = strtolower(trim($value));

            return in_array($normalized, ['1', 'true', 'yes', 'on'], true) ? '1' : '0';
        }

        return '0';
    }

    private function normalizeNotificationPrefs(mixed $value): string
    {
        if (is_array($value)) {
            return json_encode($value, JSON_UNESCAPED_UNICODE) ?: '{}';
        }
        if (is_string($value) && trim($value) !== '') {
            $decoded = json_decode($value, true);

            return is_array($decoded)
                ? (json_encode($decoded, JSON_UNESCAPED_UNICODE) ?: '{}')
                : trim($value);
        }

        return json_encode([
            'notify_birkly_posts' => true,
            'notify_deals' => true,
            'notify_comments' => true,
            'notify_reactions' => true,
            'notify_following_posts' => true,
            'email_enabled' => false,
            'email_birkly_posts' => false,
            'email_deals' => false,
            'email_comments' => false,
            'email_reactions' => false,
            'email_following_posts' => false,
        ], JSON_UNESCAPED_UNICODE) ?: '{}';
    }

    private function normalizeBadgeFieldValue(string $key, mixed $value): mixed
    {
        if ($key === 'supporter_amount_eur') {
            return round(max(0.0, (float) $value), 2);
        }
        if ($key === 'supporter_badge' || $key === 'supporter_cadence') {
            $normalized = strtolower(trim((string) $value));

            return $normalized !== '' ? $normalized : 'none';
        }

        return trim((string) $value);
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function loadAllProfilesByUserId(): array
    {
        if (!$this->collectionExists()) {
            return [];
        }

        $dir = user_management_cms_path('content/collections/' . self::COLLECTION . '/entries');
        if (!is_dir($dir)) {
            return [];
        }

        $byUser = [];
        foreach (glob($dir . '/*.json') ?: [] as $file) {
            $raw = file_get_contents($file);
            if ($raw === false) {
                continue;
            }
            $entry = json_decode($raw, true);
            if (!is_array($entry)) {
                continue;
            }
            if (($entry['status'] ?? 'published') !== 'published') {
                continue;
            }

            $userId = self::resolveEntryUserId($entry);
            if ($userId === '') {
                continue;
            }
            $entry['user_id'] = $userId;
            $byUser[$userId] = $entry;
        }

        return $byUser;
    }

    /**
     * Resolve site user id from P78 account field or legacy keys.
     *
     * @param array<string, mixed> $entry
     */
    private static function resolveEntryUserId(array $entry): string
    {
        $userId = trim((string) ($entry['user_id'] ?? $entry['author_user_id'] ?? $entry['author_id'] ?? $entry['owner'] ?? ''));
        if ($userId !== '') {
            return $userId;
        }
        if (isset($entry['account']) && is_array($entry['account'])) {
            return trim((string) ($entry['account']['legacy_user_id'] ?? ''));
        }

        return '';
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function writeEntry(array $entry): void
    {
        $id = (string) ($entry['id'] ?? '');
        if ($id === '') {
            throw new RuntimeException('Profile entry id missing');
        }

        $ok = $this->storage->write(
            'collections/' . self::COLLECTION . '/entries/' . $id . '.json',
            $entry
        );
        if (!$ok) {
            throw new RuntimeException('Failed to save club profile');
        }
    }

    private function slugify(string $value): string
    {
        $value = trim(mb_strtolower($value));
        $value = preg_replace('/[^a-z0-9]+/u', '-', $value) ?? '';
        $value = trim($value, '-');

        return $value !== '' ? $value : 'member';
    }

    private function uniqueSlug(string $base): string
    {
        $slug = $base;
        $suffix = 1;
        while ($this->slugExists($slug)) {
            $slug = $base . '-' . $suffix;
            $suffix++;
        }

        return $slug;
    }

    private function slugExists(string $slug): bool
    {
        $results = $this->storage->query(self::COLLECTION, ['slug' => $slug], ['limit' => 1]);

        return is_array($results) && count($results) > 0;
    }
}
