<?php
/**
 * Club content reports — member submit + admin queue (P80-M4).
 */

declare(strict_types=1);

require_once __DIR__ . '/EntryOwnership.php';
require_once __DIR__ . '/ClubProfileService.php';

class ClubReportService
{
    public const COLLECTION = 'club-reports';
    public const STATUS_OPEN = 'open';
    public const STATUS_REVIEWED = 'reviewed';
    public const STATUS_DISMISSED = 'dismissed';

    /**
     * @return array{ok: bool, report_id?: string, error?: string}
     */
    public function submitReport(
        string $reporterUserId,
        string $targetCollection,
        string $targetEntryId,
        string $reason
    ): array {
        $reporterUserId = trim($reporterUserId);
        $targetCollection = trim($targetCollection);
        $targetEntryId = trim($targetEntryId);
        $reason = trim($reason);

        if ($reporterUserId === '' || $targetCollection === '' || $targetEntryId === '' || $reason === '') {
            return ['ok' => false, 'error' => 'Missing required report fields'];
        }

        if (strlen($reason) > 2000) {
            return ['ok' => false, 'error' => 'Reason is too long'];
        }

        $reportId = 'report_' . bin2hex(random_bytes(8));
        $title = 'Report: ' . $targetCollection . ' / ' . substr($targetEntryId, 0, 12);
        $entry = [
            'id' => $reportId,
            'title' => $title,
            'status' => 'published',
            'target_collection' => $targetCollection,
            'target_entry_id' => $targetEntryId,
            'reporter_user_id' => $reporterUserId,
            'reason' => $reason,
            'report_status' => self::STATUS_OPEN,
            'created_at' => date('c'),
            'updated_at' => date('c'),
        ];

        if (!$this->writeReportEntry($entry, $reporterUserId)) {
            return ['ok' => false, 'error' => 'Could not save report'];
        }

        if (function_exists('do_action')) {
            do_action('club_member_reported', [
                'report_id' => $reportId,
                'target_collection' => $targetCollection,
                'target_entry_id' => $targetEntryId,
                'reporter_id' => $reporterUserId,
                'reason' => $reason,
            ]);
        }

        return ['ok' => true, 'report_id' => $reportId];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listOpenReports(int $limit = 50): array
    {
        $entries = $this->listAllReports();
        $open = array_values(array_filter($entries, static function (array $entry): bool {
            $status = strtolower((string) ($entry['report_status'] ?? self::STATUS_OPEN));

            return $status === self::STATUS_OPEN;
        }));

        usort($open, static function (array $a, array $b): int {
            return strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? ''));
        });

        return array_slice($open, 0, max(1, min(100, $limit)));
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function listAllReports(): array
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $out = [];

        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== self::COLLECTION) {
                continue;
            }
            foreach ($storage->list("collections/{$dir}/entries") as $file) {
                if (!str_ends_with($file, '.json')) {
                    continue;
                }
                $entry = $storage->read("collections/{$dir}/entries/{$file}");
                if (is_array($entry)) {
                    $out[] = $entry;
                }
            }
            break;
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function writeReportEntry(array $entry, string $ownerUserId): bool
    {
        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        $entryId = (string) ($entry['id'] ?? '');
        if ($entryId === '') {
            return false;
        }

        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== self::COLLECTION) {
                continue;
            }
            $path = "collections/{$dir}/entries/{$entryId}.json";
            $entry['owner'] = $ownerUserId;
            $entry['author_user_id'] = $ownerUserId;
            return $storage->write($path, $entry);
        }

        return false;
    }

    public function hideClubPost(string $entryId): bool
    {
        $entryId = trim($entryId);
        if ($entryId === '') {
            return false;
        }

        require_once user_management_cms_path('api/storage.php');
        $storage = new Storage(user_management_cms_path('content'));
        foreach ($storage->list('collections') as $dir) {
            $meta = $storage->read("collections/{$dir}/collection.json");
            if (!is_array($meta) || (string) ($meta['slug'] ?? '') !== 'club-posts') {
                continue;
            }
            $path = "collections/{$dir}/entries/{$entryId}.json";
            $entry = $storage->read($path);
            if (!is_array($entry)) {
                return false;
            }
            $entry['moderation_hidden'] = '1';
            $entry['status'] = 'draft';
            $entry['updated_at'] = date('c');

            return $storage->write($path, $entry);
        }

        return false;
    }
}
