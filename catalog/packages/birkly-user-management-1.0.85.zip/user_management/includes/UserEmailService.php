<?php
/**
 * User Management transactional email templates (P74-M1).
 *
 * Admin-editable templates stored under plugin data. Delivery uses birkly_send_mail
 * with an optional Connections alias; empty uses the site default email connection.
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';

class UserEmailService
{
    public const TEMPLATE_IDS = [
        'account_activation',
        'verification',
        'password_reset',
        'welcome',
        'club_notification',
        'club_notification_digest',
    ];

    private string $dataDir;

    public function __construct(?string $dataDir = null)
    {
        if (!function_exists('user_management_data_dir')) {
            require_once __DIR__ . '/../cms_paths.php';
        }
        $this->dataDir = rtrim($dataDir ?? user_management_data_dir(), '/');
        if (!is_dir($this->dataDir)) {
            mkdir($this->dataDir, 0755, true);
        }
    }

    public function templatesPath(): string
    {
        return $this->dataDir . '/email_templates.json';
    }

    public function deliverySettingsPath(): string
    {
        return $this->dataDir . '/email_delivery.json';
    }

    /**
     * @return array{email_connection_alias: string}
     */
    public function getDeliverySettings(): array
    {
        $path = $this->deliverySettingsPath();
        if (!is_file($path)) {
            return ['email_connection_alias' => ''];
        }
        $raw = file_get_contents($path);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data)) {
            return ['email_connection_alias' => ''];
        }

        return [
            'email_connection_alias' => trim((string) ($data['email_connection_alias'] ?? '')),
        ];
    }

    /**
     * @param array<string, mixed> $settings
     * @return array{email_connection_alias: string, updated_at?: string}
     */
    public function saveDeliverySettings(array $settings): array
    {
        $payload = [
            'email_connection_alias' => trim((string) ($settings['email_connection_alias'] ?? '')),
            'updated_at' => date('c'),
        ];
        file_put_contents($this->deliverySettingsPath(), json_encode($payload, JSON_PRETTY_PRINT));

        return $payload;
    }

    public function resolveEmailConnectionAlias(?array $tpl = null): ?string
    {
        $configured = '';
        if (is_array($tpl)) {
            $configured = trim((string) ($tpl['email_connection_alias'] ?? ''));
        }
        if ($configured === '') {
            $configured = $this->getDeliverySettings()['email_connection_alias'] ?? '';
        }

        $this->ensureBirklyMailLoaded();
        if (function_exists('birkly_resolve_email_connection_alias')) {
            return birkly_resolve_email_connection_alias($configured);
        }

        return $configured !== '' ? $configured : null;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listTemplates(): array
    {
        $stored = $this->loadStoredTemplates();
        $byId = [];
        foreach ($stored as $row) {
            if (!empty($row['id'])) {
                $byId[(string) $row['id']] = $row;
            }
        }

        $defaultsById = [];
        foreach ($this->defaultTemplates() as $default) {
            $defaultsById[(string) ($default['id'] ?? '')] = $default;
        }

        $out = [];
        foreach (self::TEMPLATE_IDS as $id) {
            $default = $defaultsById[$id] ?? [
                'id' => $id,
                'name' => $this->templateDisplayName($id),
                'enabled' => false,
                'subject' => '',
                'body_html' => '',
                'email_connection_alias' => '',
            ];
            $out[] = array_merge($default, $byId[$id] ?? []);
        }

        return $out;
    }

    private function templateDisplayName(string $id): string
    {
        return match ($id) {
            'account_activation' => 'Account activation',
            'verification' => 'Email verification',
            'password_reset' => 'Password reset',
            'welcome' => 'Welcome',
            'club_notification' => 'User notification',
            'club_notification_digest' => 'User notification digest',
            default => ucwords(str_replace('_', ' ', $id)),
        };
    }

    /**
     * @param array<string, mixed> $template
     */
    public function saveTemplate(array $template): array
    {
        $id = trim((string) ($template['id'] ?? ''));
        if ($id === '' || !in_array($id, self::TEMPLATE_IDS, true)) {
            return ['ok' => false, 'error' => 'Unknown template id'];
        }

        $stored = $this->loadStoredTemplates();
        $found = false;
        foreach ($stored as $idx => $row) {
            if (($row['id'] ?? '') === $id) {
                $stored[$idx] = array_merge($row, $template, ['id' => $id, 'updated_at' => date('c')]);
                $found = true;
                break;
            }
        }
        if (!$found) {
            $stored[] = array_merge($template, ['id' => $id, 'updated_at' => date('c')]);
        }

        file_put_contents($this->templatesPath(), json_encode(['templates' => $stored], JSON_PRETTY_PRINT));

        return ['ok' => true, 'template' => $this->getTemplate($id)];
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getTemplate(string $id): ?array
    {
        foreach ($this->listTemplates() as $tpl) {
            if (($tpl['id'] ?? '') === $id) {
                return $tpl;
            }
        }

        return null;
    }

    /**
     * @param array<string, string> $tokens
     */
    public function render(string $templateId, array $tokens = []): array
    {
        $tpl = $this->getTemplate($templateId);
        if ($tpl === null) {
            return ['subject' => '', 'body_html' => ''];
        }

        $merged = array_merge($this->defaultTokens(), $tokens);
        $subject = $this->mergeTokens((string) ($tpl['subject'] ?? ''), $merged);
        $body = $this->mergeTokens((string) ($tpl['body_html'] ?? ''), $merged);

        return ['subject' => $subject, 'body_html' => $body];
    }

    /**
     * @param array<string, string> $tokens
     */
    public function send(string $templateId, string $to, array $tokens = []): bool
    {
        $tpl = $this->getTemplate($templateId);
        if ($tpl === null || empty($tpl['enabled'])) {
            return false;
        }

        $rendered = $this->render($templateId, $tokens);
        $subject = $rendered['subject'];
        $body = $rendered['body_html'];
        if ($subject === '' || $body === '') {
            return false;
        }

        return $this->deliver($to, $subject, $body, $tpl)['ok'] ?? false;
    }

    /**
     * @param array<string, string> $tokens
     */
    public function sendTest(string $templateId, string $to, array $tokens = []): array
    {
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'error' => 'Invalid email address'];
        }

        $tpl = $this->getTemplate($templateId);
        if ($tpl === null) {
            return ['ok' => false, 'error' => 'Template not found'];
        }

        $rendered = $this->render($templateId, array_merge($this->testTokens(), $tokens));
        $delivery = $this->deliver($to, $rendered['subject'], $rendered['body_html'], $tpl);

        return !empty($delivery['ok'])
            ? ['ok' => true, 'message' => 'Test email sent']
            : ['ok' => false, 'error' => (string) ($delivery['error'] ?? 'Could not send test email')];
    }

    /**
     * @param array<string, mixed> $tpl
     * @return array{ok: bool, error?: string}
     */
    private function deliver(string $to, string $subject, string $body, array $tpl): array
    {
        $this->ensureBirklyMailLoaded();

        if (!function_exists('birkly_send_mail')) {
            return ['ok' => false, 'error' => 'Mail system unavailable'];
        }

        $alias = $this->resolveEmailConnectionAlias($tpl);

        $result = birkly_send_mail([
            'to' => $to,
            'subject' => $subject,
            'html' => $body,
            'text' => trim(preg_replace('/\s+/', ' ', strip_tags($body)) ?? ''),
        ], $alias);

        $status = is_array($result) ? (string) ($result['status'] ?? '') : '';
        if (in_array($status, ['accepted', 'queued', 'logged'], true)) {
            return ['ok' => true];
        }

        $error = is_array($result) ? trim((string) ($result['error'] ?? $result['message'] ?? '')) : '';
        if ($error === '') {
            $error = $status !== '' ? 'Mail delivery failed (' . $status . ')' : 'Mail delivery failed';
        }
        error_log('UserEmailService: ' . $error);

        return ['ok' => false, 'error' => $error];
    }

    private function ensureBirklyMailLoaded(): void
    {
        if (!function_exists('user_management_load_birkly_mail')) {
            require_once __DIR__ . '/../cms_paths.php';
        }
        user_management_load_birkly_mail();
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function loadStoredTemplates(): array
    {
        $path = $this->templatesPath();
        if (!is_file($path)) {
            return [];
        }
        $raw = file_get_contents($path);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data) || !is_array($data['templates'] ?? null)) {
            return [];
        }

        return $data['templates'];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function defaultTemplates(): array
    {
        $site = $this->siteName();

        return [
            [
                'id' => 'account_activation',
                'name' => 'Account activation',
                'enabled' => true,
                'subject' => 'Activate your access on {{site_name}}',
                'body_html' => $this->defaultAccountActivationHtml(),
                'email_connection_alias' => '',
            ],
            [
                'id' => 'verification',
                'name' => 'Email verification',
                'enabled' => true,
                'subject' => 'Verify your email for {{site_name}}',
                'body_html' => $this->defaultVerificationHtml(),
                'email_connection_alias' => '',
            ],
            [
                'id' => 'password_reset',
                'name' => 'Password reset',
                'enabled' => true,
                'subject' => 'Reset your password for {{site_name}}',
                'body_html' => $this->defaultPasswordResetHtml(),
                'email_connection_alias' => '',
            ],
            [
                'id' => 'welcome',
                'name' => 'Welcome',
                'enabled' => true,
                'subject' => 'Welcome to {{site_name}}',
                'body_html' => $this->defaultWelcomeHtml(),
                'email_connection_alias' => '',
            ],
        ];
    }

    /**
     * @return array<string, string>
     */
    private function defaultTokens(): array
    {
        return [
            'site_name' => $this->siteName(),
            'site_url' => $this->siteUrl(),
        ];
    }

    /**
     * @return array<string, string>
     */
    private function testTokens(): array
    {
        return array_merge($this->defaultTokens(), [
            'activation_url' => $this->siteUrl() . '/activate-account?token=test-token',
            'verification_url' => $this->siteUrl() . '/verify-email?token=test-token&user=test-user',
            'reset_url' => $this->siteUrl() . '/reset-password?token=test-token&user=test-user',
            'tier_id' => 'club',
        ]);
    }

    /**
     * @param array<string, string> $tokens
     */
    private function mergeTokens(string $text, array $tokens): string
    {
        foreach ($tokens as $key => $value) {
            $text = str_replace('{{' . $key . '}}', (string) $value, $text);
        }

        return $text;
    }

    private function siteName(): string
    {
        if (!function_exists('user_management_cms_path')) {
            require_once __DIR__ . '/../cms_paths.php';
        }
        $settingsPath = user_management_cms_path('settings/site.json');
        if (is_file($settingsPath)) {
            $settings = json_decode((string) file_get_contents($settingsPath), true);
            if (!empty($settings['name'])) {
                return (string) $settings['name'];
            }
        }

        return 'Birkly';
    }

    private function siteUrl(): string
    {
        if (!function_exists('user_management_site_url')) {
            require_once __DIR__ . '/../cms_paths.php';
        }

        return user_management_site_url();
    }

    private function defaultAccountActivationHtml(): string
    {
        return <<<'HTML'
<p>Thank you for supporting {{site_name}}.</p>
<p>Click below to set your password and activate your access:</p>
<p style="text-align:center;margin:24px 0;">
  <a href="{{activation_url}}" style="display:inline-block;padding:12px 24px;background:#3498db;color:#fff;text-decoration:none;border-radius:5px;">Activate access</a>
</p>
<p>Or copy this link: {{activation_url}}</p>
<p style="color:#666;font-size:12px;">This link expires in 72 hours.</p>
HTML;
    }

    private function defaultVerificationHtml(): string
    {
        return <<<'HTML'
<p>Thank you for signing up for {{site_name}}.</p>
<p>Please verify your email:</p>
<p style="text-align:center;margin:24px 0;">
  <a href="{{verification_url}}" style="display:inline-block;padding:12px 24px;background:#3498db;color:#fff;text-decoration:none;border-radius:5px;">Verify email</a>
</p>
<p>Or copy this link: {{verification_url}}</p>
HTML;
    }

    private function defaultPasswordResetHtml(): string
    {
        return <<<'HTML'
<p>You requested a password reset for {{site_name}}.</p>
<p style="text-align:center;margin:24px 0;">
  <a href="{{reset_url}}" style="display:inline-block;padding:12px 24px;background:#e74c3c;color:#fff;text-decoration:none;border-radius:5px;">Reset password</a>
</p>
<p>Or copy this link: {{reset_url}}</p>
HTML;
    }

    private function defaultWelcomeHtml(): string
    {
        return <<<'HTML'
<p>Welcome to {{site_name}}! Your account is ready.</p>
HTML;
    }
}
