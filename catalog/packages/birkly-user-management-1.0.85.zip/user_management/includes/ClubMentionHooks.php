<?php
/**
 * Registers mention handlers when user_plugin.mentions_enabled (P81-M8).
 */

declare(strict_types=1);

require_once __DIR__ . '/ClubMentionParser.php';
require_once __DIR__ . '/UserMentionService.php';
require_once __DIR__ . '/UserPluginCollectionConfig.php';
require_once __DIR__ . '/EntryOwnership.php';

function club_mention_register_hooks(): void
{
    if (function_exists('add_filter')) {
        add_filter('before_entry_save', function ($entry, $collection) {
            if (!is_array($entry)) {
                return $entry;
            }
            $collectionSlug = is_string($collection) ? $collection : '';
            if ($collectionSlug === '' || !UserPluginCollectionConfig::mentionsEnabled($collectionSlug)) {
                return $entry;
            }

            $authorId = EntryOwnership::getEntryOwnerId($entry, $collectionSlug) ?? '';
            if ($authorId === '' && function_exists('get_current_user_id')) {
                $authorId = (string) get_current_user_id();
            }

            $parser = new ClubMentionParser();
            $mentioned = $parser->parseMentionedUserIds((string) ($entry['body'] ?? ''), $authorId !== '' ? $authorId : null);
            $entry['mentioned_user_ids'] = $parser->encodeMentionedUserIds($mentioned);

            return $entry;
        }, 25, 2);
    }

    if (!function_exists('register_hook')) {
        return;
    }

    register_hook('after_entry_save', function ($entry, $collection, $oldEntry = null): void {
        if (!is_array($entry)) {
            return;
        }
        $collectionSlug = is_string($collection) ? $collection : (is_array($collection) ? (string) ($collection['slug'] ?? '') : '');
        if ($collectionSlug === '' || !UserPluginCollectionConfig::mentionsEnabled($collectionSlug)) {
            return;
        }

        try {
            (new UserMentionService())->processPost($entry, $collectionSlug, is_array($oldEntry) ? $oldEntry : null);
        } catch (Throwable $e) {
            error_log('User mention after_entry_save failed: ' . $e->getMessage());
        }
    }, 15);

    register_hook('sub_entry_created', function (
        $subEntryId,
        $data,
        $parentCollection,
        $parentEntryId,
        $subCollection
    ): void {
        if (!is_array($data) || (string) $subCollection !== 'comments') {
            return;
        }
        $parentCollection = (string) $parentCollection;
        if ($parentCollection === '' || !UserPluginCollectionConfig::mentionsEnabled($parentCollection)) {
            return;
        }

        try {
            (new UserMentionService())->processComment(
                (string) $subEntryId,
                $data,
                $parentCollection,
                (string) $parentEntryId
            );
        } catch (Throwable $e) {
            error_log('User mention sub_entry_created failed: ' . $e->getMessage());
        }
    }, 5);
}
