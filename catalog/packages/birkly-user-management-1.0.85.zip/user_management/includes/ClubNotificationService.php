<?php
/**
 * Backward-compat shim — use UserNotificationService (P81-M5).
 */

declare(strict_types=1);

require_once __DIR__ . '/UserNotificationService.php';
