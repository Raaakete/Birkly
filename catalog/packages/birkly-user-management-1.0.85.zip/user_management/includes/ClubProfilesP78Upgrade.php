<?php
/**
 * P78 — club-profiles uses account field only (no redundant owner field).
 */

declare(strict_types=1);

require_once __DIR__ . '/../cms_paths.php';
require_once __DIR__ . '/UserStorage.php';
require_once __DIR__ . '/MemberAccountCodec.php';
require_once __DIR__ . '/UserCollectionResolver.php';
require_once __DIR__ . '/MemberMigrateService.php';

/**
 * Remove owner field from club-profiles; ownership resolves via account.legacy_user_id.
 */
function user_management_upgrade_club_profiles_p78(): void
{
    $collection = 'club-profiles';
    $storage = new UserStorage();
    $runtime = $storage->readMetadata('plugin_runtime');
    if (!is_array($runtime)) {
        $runtime = [];
    }
    if (($runtime['p78_club_profiles_upgraded'] ?? '') === '1') {
        return;
    }

    require_once user_management_cms_path('api/storage.php');
    $cmsStorage = new Storage(user_management_cms_path('content'));
    $collectionDir = user_management_resolve_collection_dir_for_upgrade($cmsStorage, $collection);
    if ($collectionDir === null) {
        $runtime['p78_club_profiles_upgraded'] = '1';
        $storage->saveMetadata('plugin_runtime', $runtime);

        return;
    }

    $resolver = new UserCollectionResolver();
    $accountField = $resolver->getAccountFieldOnSchema($collection);
    if ($accountField === null) {
        (new MemberMigrateService())->ensureAccountFieldOnSchema($collection, 'user_account_club');
        $accountField = $resolver->getAccountFieldOnSchema($collection);
    }

    $accountFieldName = (string) ($accountField['name'] ?? 'account');
    $entriesDir = user_management_cms_path('content/collections/' . $collectionDir . '/entries');
    if (is_dir($entriesDir)) {
        foreach (glob($entriesDir . '/*.json') ?: [] as $file) {
            $entry = json_decode((string) file_get_contents($file), true);
            if (!is_array($entry)) {
                continue;
            }

            $ownerId = trim((string) ($entry['owner'] ?? $entry['user_id'] ?? ''));
            $account = MemberAccountCodec::normalize($entry[$accountFieldName] ?? []);
            if ($ownerId !== '' && trim((string) ($account['legacy_user_id'] ?? '')) === '') {
                $account['legacy_user_id'] = $ownerId;
                $entry[$accountFieldName] = $account;
            }

            unset($entry['owner']);
            file_put_contents($file, json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
        }
    }

    user_management_remove_owner_field_from_collection_schema($collection, $collectionDir);

    if (function_exists('user_management_reconcile_member_profiles')) {
        require_once __DIR__ . '/MemberProfileReconcile.php';
        user_management_reconcile_member_profiles($collection);
    }

    $runtime['p78_club_profiles_upgraded'] = '1';
    $runtime['p78_club_profiles_upgraded_at'] = date('c');
    $storage->saveMetadata('plugin_runtime', $runtime);
}

function user_management_resolve_collection_dir_for_upgrade(Storage $storage, string $collectionSlug): ?string
{
    foreach ($storage->list('collections') as $dir) {
        $meta = $storage->read("collections/{$dir}/collection.json");
        if (is_array($meta) && (string) ($meta['slug'] ?? '') === $collectionSlug) {
            return (string) $dir;
        }
    }

    if (is_dir(user_management_cms_path('content/collections/' . $collectionSlug))) {
        return $collectionSlug;
    }

    return null;
}

function user_management_remove_owner_field_from_collection_schema(string $collectionSlug, string $collectionDir): void
{
    $schemaPath = user_management_cms_path('content/collections/' . $collectionDir . '/schema.json');
    $collectionPath = user_management_cms_path('content/collections/' . $collectionDir . '/collection.json');
    $target = is_file($schemaPath) ? $schemaPath : $collectionPath;
    if (!is_file($target)) {
        return;
    }

    $config = json_decode((string) file_get_contents($target), true);
    if (!is_array($config)) {
        return;
    }

    $fields = is_array($config['fields'] ?? null) ? $config['fields'] : [];
    $nextFields = [];
    foreach ($fields as $field) {
        if (!is_array($field)) {
            continue;
        }
        if (($field['name'] ?? '') === 'user_id') {
            continue;
        }
        if (($field['name'] ?? '') === 'owner' && ($field['type'] ?? '') === 'user') {
            continue;
        }
        if (MemberAccountCodec::isAccountFieldType((string) ($field['type'] ?? ''))) {
            $field['label'] = 'Site user account';
            $field['public_visible'] = false;
        }
        $nextFields[] = $field;
    }

    $config['fields'] = $nextFields;
    $config['updated_at'] = date('c');
    file_put_contents($target, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");

    if ($target === $schemaPath && is_file($collectionPath)) {
        $collectionConfig = json_decode((string) file_get_contents($collectionPath), true);
        if (is_array($collectionConfig)) {
            $collectionConfig['fields'] = $nextFields;
            $collectionConfig['updated_at'] = date('c');
            file_put_contents($collectionPath, json_encode($collectionConfig, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
        }
    }
}
