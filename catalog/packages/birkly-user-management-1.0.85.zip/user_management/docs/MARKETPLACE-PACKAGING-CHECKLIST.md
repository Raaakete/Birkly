# User Management marketplace packaging checklist

Source of truth: this repository.

## Build

```bash
php scripts/build-plugin-zip.php
```

Expected output:

- `build/birkly-user-management-<version>.zip`
- `build/birkly-user-management-<version>.zip.sha256`
- JSON metadata with `status`, `artifact`, `sha256`, `marketplace_slug`, `version`, and `files`.

## Artifact contents

The zip must unpack to one top-level `user_management/` directory.

Included:

- `plugin.json`
- `plugin.php`
- `README.md`
- `admin/`
- `api/`
- `docs/` help and AI context docs
- `fieldtypes/`
- `includes/`
- public reset/verification pages: `reset-password.php`, `verify-email.php`

Excluded:

- `.git/`
- `build/`
- `tests/`
- runtime data: `settings/`, `cache/`, `logs/`, `users/`
- archived implementation-history docs in `docs/archive/`
- internal release-readiness planning files

## Pre-publish checks

- [ ] `php tests/run.php` passes from this repo.
- [ ] `php scripts/build-plugin-zip.php` succeeds.
- [ ] SHA256 file matches the zip.
- [ ] Zip contains no runtime data, secrets, symlinks, or archived implementation history.
- [ ] Fresh CMS install can upload/install the zip through Marketplace.
- [ ] Activation registers admin pages, public API routes, docs shelf, template functions, and User/Password fieldtypes.
- [ ] Public reset and verify URLs resolve from the installed plugin.
- [ ] Deactivation removes admin/API/fieldtypes/template functions from the active runtime without deleting user data.
- [ ] Reactivation restores existing users, sessions, groups, tiers, 2FA metadata, verification tokens, and permissions.
- [ ] README and Help docs match the built artifact behavior.
- [ ] Marketplace listing uses the same `plugin.json` version and `marketplace_slug`.
