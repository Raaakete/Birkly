<?php
/**
 * User Management plugin MCP tools.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/UserStorage.php';
require_once __DIR__ . '/../includes/UserMemberIndexer.php';
require_once __DIR__ . '/../includes/MemberMigrateService.php';

function user_mcp_user_can(array $aiUser, string $capability): bool
{
    $role = (string) ($aiUser['role'] ?? '');
    if (in_array($role, ['admin', 'superadmin'], true)) {
        return true;
    }

    if (function_exists('checkPermission') && checkPermission($aiUser, $capability)) {
        return true;
    }

    $caps = $aiUser['plugin_capabilities']['user_management'] ?? $aiUser['capabilities'] ?? [];
    if (!is_array($caps)) {
        return false;
    }

    return in_array('manage_users', $caps, true) || in_array($capability, $caps, true);
}

/** @return array{status: string, message?: string}|null */
function user_mcp_require(array $aiUser, string $capability): ?array
{
    if (!user_mcp_user_can($aiUser, $capability)) {
        return ['status' => 'error', 'message' => 'Permission denied (requires ' . $capability . ')'];
    }

    return null;
}

/** @return array<string, array> */
function user_management_mcp_tool_registry(): array
{
    return [
        'user_list_site_users' => [
            'description' => 'List site users from User Management (User List tab) — id, email, name, tier, role.',
            'category' => 'read',
            'permissions' => ['manage_users', 'read'],
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'include_deleted' => ['type' => 'boolean', 'description' => 'Include soft-deleted users'],
                ],
            ],
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = user_mcp_require($aiUser, 'manage_users')) {
                    return $err;
                }
                $storage = new UserStorage();
                $users = $storage->listUsers([
                    'deleted' => !empty($arguments['include_deleted']),
                ]);
                $rows = [];
                foreach ($users as $user) {
                    if (!is_array($user)) {
                        continue;
                    }
                    $rows[] = [
                        'id' => (string) ($user['id'] ?? ''),
                        'email' => (string) ($user['email'] ?? ''),
                        'name' => (string) ($user['name'] ?? $user['username'] ?? ''),
                        'tier' => (string) ($user['tier'] ?? 'all'),
                        'role' => (string) ($user['role'] ?? 'member'),
                        'status' => (string) ($user['status'] ?? ''),
                        'verified' => !empty($user['verified']),
                    ];
                }

                return ['status' => 'ok', 'data' => ['users' => $rows, 'count' => count($rows)]];
            },
        ],
        'user_list_members_index' => [
            'description' => 'List indexed P77 members (collection entries with user_account* fields).',
            'category' => 'read',
            'permissions' => ['manage_users', 'read'],
            'inputSchema' => ['type' => 'object', 'properties' => []],
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = user_mcp_require($aiUser, 'manage_users')) {
                    return $err;
                }
                $indexer = new UserMemberIndexer();

                return [
                    'status' => 'ok',
                    'data' => ['members' => $indexer->listMembers()],
                ];
            },
        ],
        'user_migrate_p77_members' => [
            'description' => 'Migrate User List accounts into member collection entries (adds account field, creates missing club profiles, indexes members). Idempotent.',
            'category' => 'write',
            'permissions' => ['manage_users', 'write'],
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'collection' => [
                        'type' => 'string',
                        'description' => 'Member collection slug (default club-profiles)',
                    ],
                    'type_key' => [
                        'type' => 'string',
                        'description' => 'Account fieldtype key (default user_account_club)',
                    ],
                    'dry_run' => [
                        'type' => 'boolean',
                        'description' => 'Preview counts without writing',
                    ],
                ],
            ],
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = user_mcp_require($aiUser, 'manage_users')) {
                    return $err;
                }
                $collection = trim((string) ($arguments['collection'] ?? 'club-profiles'));
                $typeKey = trim((string) ($arguments['type_key'] ?? 'user_account_club'));
                $dryRun = !empty($arguments['dry_run']);
                $result = user_management_migrate_p77_members([
                    'collection' => $collection,
                    'type_key' => $typeKey,
                    'dry_run' => $dryRun,
                ]);

                return [
                    'status' => empty($result['errors']) ? 'ok' : 'error',
                    'data' => $result,
                ];
            },
        ],
        'user_reindex_members' => [
            'description' => 'Rebuild members_index.json from all collections with user_account* fields.',
            'category' => 'write',
            'permissions' => ['manage_users', 'write'],
            'inputSchema' => ['type' => 'object', 'properties' => []],
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = user_mcp_require($aiUser, 'manage_users')) {
                    return $err;
                }
                $count = (new UserMemberIndexer())->reindexAll();

                return ['status' => 'ok', 'data' => ['count' => $count]];
            },
        ],
        'user_reconcile_supporter_badges' => [
            'description' => 'Reconcile supporter badge fields on club-profiles from Commerce donations and subscriptions.',
            'category' => 'write',
            'permissions' => ['manage_users', 'write'],
            'inputSchema' => [
                'type' => 'object',
                'properties' => [
                    'email' => [
                        'type' => 'string',
                        'description' => 'Optional single email; omit to reconcile all club members',
                    ],
                ],
            ],
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = user_mcp_require($aiUser, 'manage_users')) {
                    return $err;
                }
                require_once __DIR__ . '/../includes/SupporterBadgeSync.php';
                $email = strtolower(trim((string) ($arguments['email'] ?? '')));
                if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $result = (new SupporterBadgeSync())->reconcileForEmail($email);
                } else {
                    $result = (new SupporterBadgeSync())->reconcileAll();
                }

                return ['status' => 'ok', 'data' => $result];
            },
        ],
        'user_reconcile_club_tiers' => [
            'description' => 'Grant club tier to site users who have a club-profiles entry but are still on all/basic.',
            'category' => 'write',
            'permissions' => ['manage_users', 'write'],
            'inputSchema' => ['type' => 'object', 'properties' => []],
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = user_mcp_require($aiUser, 'manage_users')) {
                    return $err;
                }
                require_once __DIR__ . '/../includes/MemberProfileReconcile.php';
                $result = user_management_reconcile_club_tiers();

                return ['status' => 'ok', 'data' => $result ?? ['updated' => 0, 'user_ids' => []]];
            },
        ],
    ];
}
