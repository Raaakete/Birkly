# User Management website tools (WebMCP)

Visitor-facing tools an AI helper can call on pages with a **public sign-in surface**. These are **off by default** and stay off until you opt in. Enable them in **Discovery → WebMCP** after turning the Website tools master switch on.

This is **not** inbound Birkly MCP (admin assistants). WebMCP only reports public session state and can start the same login a visitor already uses.

## Tools

| Tool | Kind | Confirmation | Default |
|------|------|--------------|---------|
| `birkly_user_session` | Read | None | Off |
| `birkly_user_login` | Write | Visitor confirms before signing in | Off |

Tools appear in the admin catalog only while User Management is **installed and active**.

## Storefront surface

Include the helper so the runtime can feature-detect `window.BirklyUser`:

```html
<script src="/plugins/user_management/assets/user-storefront.js"></script>
```

`BirklyUser.session()` reports `{ signed_in, user }` with public fields only (no password hashes or tokens). `BirklyUser.login({ email, password })` posts to the public `user_auth` login action.

Markup-only fallback: a form with `data-birkly-login` or an element with `data-birkly-user-session`.

## Owner steps

1. Install and activate User Management.
2. Open **Discovery → WebMCP** and turn Website tools on.
3. Enable **Check sign-in**. Enable **Sign in** only if you want visitor AIs to start login.
4. Add the storefront script or a `data-birkly-login` form on public account pages.

Sign-in always uses the login consent gate. Website tools never expose admin users or draft profiles.
