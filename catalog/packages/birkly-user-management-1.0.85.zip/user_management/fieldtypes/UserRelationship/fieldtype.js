(function () {
  function apiBase() {
    if (typeof window.BIRKLY_API_BASE === 'string' && window.BIRKLY_API_BASE) {
      return window.BIRKLY_API_BASE.replace(/\/$/, '');
    }
    return '/api';
  }

  function csrfToken() {
    var meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.content) return meta.content;
    var input = document.querySelector('input[name="csrf_token"], input[name="_csrf"]');
    return input ? input.value : '';
  }

  function initFieldtype(root) {
    if (!root || root.dataset.userRelationshipInit === '1') return;
    root.dataset.userRelationshipInit = '1';

    var subjectUserId = root.getAttribute('data-subject-user-id') || '';
    if (!subjectUserId) return;

    var state = {
      following: [],
      followers: [],
      connected: [],
      pending_in: [],
      blocked: [],
      users: [],
    };

    function adminUrl(action, query) {
      var url = apiBase() + '/user_graph_admin?action=' + encodeURIComponent(action)
        + '&subject_user_id=' + encodeURIComponent(subjectUserId);
      if (query) {
        Object.keys(query).forEach(function (k) {
          url += '&' + encodeURIComponent(k) + '=' + encodeURIComponent(query[k]);
        });
      }
      return url;
    }

    function postAction(action, body) {
      return fetch(adminUrl(action), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken(),
        },
        credentials: 'same-origin',
        body: JSON.stringify(Object.assign({ subject_user_id: subjectUserId }, body || {})),
      }).then(function (r) { return r.json(); });
    }

    function loadState() {
      return fetch(adminUrl('state'), { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          if (!data || !data.success) throw new Error((data && data.error) || 'Failed to load graph');
          state.following = data.following || [];
          state.followers = data.followers || [];
          state.connected = data.connected || [];
          state.pending_in = data.pending_in || [];
          state.blocked = data.blocked || [];
          renderPanels();
        });
    }

    function loadUsers() {
      return fetch(apiBase() + '/user_admin?action=list&limit=500', { credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (data) {
          var users = (data && data.users) || (data && data.data && data.data.users) || [];
          state.users = Array.isArray(users) ? users : [];
          populateUserSelect();
        })
        .catch(function () { state.users = []; });
    }

    function userLabel(id) {
      var u = state.users.find(function (x) { return String(x.id) === String(id); });
      if (!u) return id;
      return u.name || u.username || u.email || id;
    }

    function renderList(panelName, ids, actions) {
      var panel = root.querySelector('.user-relationship-panel[data-panel="' + panelName + '"]');
      if (!panel) return;
      if (!ids.length) {
        panel.innerHTML = '<p class="help-text">None</p>';
        return;
      }
      panel.innerHTML = ids.map(function (id) {
        var btns = (actions || []).map(function (a) {
          return '<button type="button" class="btn btn-secondary btn-sm user-relationship-action" data-action="' + a.action + '" data-target="' + id + '">' + a.label + '</button>';
        }).join(' ');
        return '<div class="user-relationship-row"><span>' + userLabel(id) + '</span><span>' + btns + '</span></div>';
      }).join('');
    }

    function renderPanels() {
      renderList('following', state.following, [{ action: 'unfollow', label: 'Unfollow' }]);
      renderList('followers', state.followers, []);
      renderList('connected', state.connected, [{ action: 'disconnect', label: 'Disconnect' }]);
      renderList('requests', state.pending_in, [
        { action: 'accept', label: 'Accept' },
        { action: 'reject', label: 'Reject' },
      ]);
      renderList('blocked', state.blocked, [{ action: 'unblock', label: 'Unblock' }]);
    }

    function populateUserSelect() {
      var select = root.querySelector('.user-relationship-user-select');
      if (!select) return;
      var current = select.value;
      select.innerHTML = '<option value="">Select user…</option>';
      state.users.forEach(function (u) {
        if (!u || !u.id || String(u.id) === subjectUserId) return;
        var opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = (u.name || u.username || u.email || u.id);
        select.appendChild(opt);
      });
      if (current) select.value = current;
    }

    root.querySelectorAll('.user-relationship-tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        var name = tab.getAttribute('data-tab');
        root.querySelectorAll('.user-relationship-tab').forEach(function (t) { t.classList.toggle('active', t === tab); });
        root.querySelectorAll('.user-relationship-panel').forEach(function (p) {
          p.classList.toggle('active', p.getAttribute('data-panel') === name);
        });
      });
    });

    root.addEventListener('click', function (e) {
      var btn = e.target.closest('.user-relationship-action');
      if (!btn) return;
      var action = btn.getAttribute('data-action');
      var target = btn.getAttribute('data-target');
      if (!action || !target) return;
      postAction(action, { target_user_id: target }).then(function (data) {
        if (!data || !data.success) throw new Error((data && data.error) || 'Action failed');
        return loadState();
      }).catch(function (err) { alert(err.message || 'Graph action failed'); });
    });

    var addBtn = root.querySelector('.user-relationship-add-btn');
    if (addBtn) {
      addBtn.addEventListener('click', function () {
        var select = root.querySelector('.user-relationship-user-select');
        var actionSelect = root.querySelector('.user-relationship-action-select');
        var target = select ? select.value : '';
        var action = actionSelect ? actionSelect.value : 'follow';
        if (!target) return;
        postAction(action, { target_user_id: target }).then(function (data) {
          if (!data || !data.success) throw new Error((data && data.error) || 'Action failed');
          if (select) select.value = '';
          return loadState();
        }).catch(function (err) { alert(err.message || 'Graph action failed'); });
      });
    }

    var search = root.querySelector('.user-relationship-search');
    if (search) {
      search.addEventListener('input', function () {
        var q = search.value.toLowerCase();
        var select = root.querySelector('.user-relationship-user-select');
        if (!select) return;
        Array.prototype.forEach.call(select.options, function (opt, idx) {
          if (idx === 0) return;
          var text = (opt.textContent || '').toLowerCase();
          opt.hidden = q !== '' && text.indexOf(q) === -1;
        });
      });
    }

    loadUsers().then(loadState).catch(function (err) {
      console.error('user_relationship fieldtype:', err);
    });
  }

  function initAll() {
    document.querySelectorAll('.user-relationship-fieldtype').forEach(initFieldtype);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  if (typeof MutationObserver !== 'undefined') {
    var obs = new MutationObserver(function () { initAll(); });
    obs.observe(document.body, { childList: true, subtree: true });
  }
})();
