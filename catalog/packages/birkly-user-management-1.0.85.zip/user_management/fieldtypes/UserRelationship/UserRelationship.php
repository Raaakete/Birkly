<?php
/**
 * User Relationship fieldtype — virtual graph panel on profile entries (P76).
 */

declare(strict_types=1);

namespace UserManagement\Fieldtypes;

if (!class_exists('Birkly\FieldTypes\BaseField')) {
    $pluginRoot = dirname(__DIR__, 2);
    $candidates = [
        $pluginRoot . '/../../fieldtypes/BaseField.php',
        dirname($pluginRoot) . '/birkly/fieldtypes/BaseField.php',
    ];
    foreach ($candidates as $candidate) {
        if (is_file($candidate)) {
            require_once $candidate;
            break;
        }
    }
}

use Birkly\FieldTypes\BaseField;

class UserRelationship extends BaseField
{
    /** @var list<string> */
    protected array $modes = ['follow', 'connection', 'block'];

    protected bool $showCounts = true;

    protected string $anchorUserId = '';

    protected string $entryId = '';

    public function __construct(array $config)
    {
        parent::__construct($config);
        $modes = $config['modes'] ?? ['follow', 'connection', 'block'];
        $this->modes = is_array($modes) ? array_values($modes) : $this->modes;
        $this->showCounts = !empty($config['show_counts'] ?? true);
        $this->entryId = (string) ($config['entry_id'] ?? '');
        $this->anchorUserId = $this->resolveAnchorUserId($config);
    }

    public function getType(): string
    {
        return 'user_relationship';
    }

    public function getCategory(): string
    {
        return 'User Management';
    }

    public function persistsInEntry(): bool
    {
        return false;
    }

    /**
     * @param array<string, mixed> $entry
     * @param array<string, mixed> $fieldConfig
     */
    public function resolveValueForEntry(array $entry, array $fieldConfig, array $context = [])
    {
        $anchor = $this->resolveAnchorUserId(array_merge($fieldConfig, ['entry' => $entry]));
        if ($anchor === '') {
            return [
                'anchor_user_id' => '',
                'summary' => [],
            ];
        }

        if (!class_exists('UserGraphService')) {
            require_once __DIR__ . '/../../includes/UserGraphService.php';
        }

        $graph = new \UserGraphService();

        return [
            'anchor_user_id' => $anchor,
            'following' => $graph->listFollowing($anchor),
            'followers' => $graph->listFollowers($anchor),
            'connected' => $graph->listConnected($anchor),
            'pending_in' => $graph->listPendingConnectionRequests($anchor),
            'blocked' => $graph->listBlocked($anchor),
            'summary' => $graph->summaryForUser($anchor),
        ];
    }

    public function render(): string
    {
        $value = is_array($this->value) ? $this->value : [];
        $anchor = (string) ($value['anchor_user_id'] ?? $this->anchorUserId);
        $summary = is_array($value['summary'] ?? null) ? $value['summary'] : [];
        $fieldName = htmlspecialchars($this->name);
        $modesJson = htmlspecialchars(json_encode($this->modes), ENT_QUOTES, 'UTF-8');

        if ($anchor === '') {
            return '<div class="user-relationship-fieldtype user-relationship-fieldtype--empty">'
                . '<p class="help-text">Save the profile with an <strong>owner</strong> account first, then reload to manage relationships.</p>'
                . '</div>';
        }

        $countsHtml = '';
        if ($this->showCounts) {
            $countsHtml = '<div class="user-relationship-counts">'
                . '<span>' . (int) ($summary['following'] ?? 0) . ' following</span>'
                . '<span>' . (int) ($summary['followers'] ?? 0) . ' followers</span>'
                . '<span>' . (int) ($summary['connected'] ?? 0) . ' connected</span>'
                . '<span>' . (int) ($summary['blocked'] ?? 0) . ' blocked</span>'
                . '</div>';
        }

        return '<div class="user-relationship-fieldtype" data-field-name="' . $fieldName . '"'
            . ' data-subject-user-id="' . htmlspecialchars($anchor) . '"'
            . ' data-modes="' . $modesJson . '"'
            . ' data-entry-id="' . htmlspecialchars($this->entryId) . '">'
            . $countsHtml
            . '<div class="user-relationship-tabs" role="tablist">'
            . '<button type="button" class="btn btn-secondary user-relationship-tab active" data-tab="following">Following</button>'
            . '<button type="button" class="btn btn-secondary user-relationship-tab" data-tab="followers">Followers</button>'
            . '<button type="button" class="btn btn-secondary user-relationship-tab" data-tab="connected">Connected</button>'
            . '<button type="button" class="btn btn-secondary user-relationship-tab" data-tab="requests">Requests</button>'
            . '<button type="button" class="btn btn-secondary user-relationship-tab" data-tab="blocked">Blocked</button>'
            . '</div>'
            . '<div class="user-relationship-panels">'
            . '<div class="user-relationship-panel active" data-panel="following"></div>'
            . '<div class="user-relationship-panel" data-panel="followers"></div>'
            . '<div class="user-relationship-panel" data-panel="connected"></div>'
            . '<div class="user-relationship-panel" data-panel="requests"></div>'
            . '<div class="user-relationship-panel" data-panel="blocked"></div>'
            . '</div>'
            . '<div class="user-relationship-add">'
            . '<input type="text" class="form-control user-relationship-search" placeholder="Search users by name or email…" autocomplete="off">'
            . '<select class="form-control user-relationship-user-select" aria-label="Select user"><option value="">Select user…</option></select>'
            . '<select class="form-control user-relationship-action-select" aria-label="Action">'
            . '<option value="follow">Follow</option>'
            . '<option value="connect">Connect</option>'
            . '<option value="block">Block</option>'
            . '</select>'
            . '<button type="button" class="btn btn-primary user-relationship-add-btn">Add</button>'
            . '</div>'
            . '<p class="help-text">Changes save immediately to the user graph (not stored on this entry).</p>'
            . '</div>';
    }

    public function validate($value): array
    {
        return [];
    }

    public function getJavaScript(): string
    {
        $jsFile = __DIR__ . '/fieldtype.js';
        if (is_file($jsFile)) {
            return (string) file_get_contents($jsFile);
        }

        return '';
    }

    public function getCSS(): string
    {
        return <<<'CSS'
        .user-relationship-fieldtype { margin: 0.5rem 0 1rem; }
        .user-relationship-counts { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 0.75rem; font-size: 0.9rem; color: var(--text-muted, #666); }
        .user-relationship-tabs { display: flex; flex-wrap: wrap; gap: 0.35rem; margin-bottom: 0.75rem; }
        .user-relationship-tab.active { font-weight: 600; }
        .user-relationship-panel { display: none; min-height: 80px; max-height: 220px; overflow: auto; border: 1px solid var(--border-color, rgba(0,0,0,0.1)); border-radius: 4px; padding: 0.5rem; }
        .user-relationship-panel.active { display: block; }
        .user-relationship-row { display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; padding: 0.35rem 0; border-bottom: 1px solid var(--border-color, rgba(0,0,0,0.06)); }
        .user-relationship-row:last-child { border-bottom: 0; }
        .user-relationship-add { display: grid; grid-template-columns: 1fr 1fr auto auto; gap: 0.5rem; margin-top: 0.75rem; align-items: center; }
        @media (max-width: 720px) { .user-relationship-add { grid-template-columns: 1fr; } }
        .user-relationship-fieldtype--empty { padding: 0.75rem; border: 1px dashed var(--border-color, #ccc); border-radius: 4px; }
        CSS;
    }

    public function getAdminConfig(): array
    {
        return [
            'modes' => [
                'type' => 'multiselect',
                'label' => 'Relationship kinds',
                'options' => ['follow', 'connection', 'block'],
                'default' => ['follow', 'connection', 'block'],
            ],
            'show_counts' => [
                'type' => 'boolean',
                'label' => 'Show counts',
                'default' => true,
            ],
        ];
    }

    public function getConfigUI($fieldIndex, $existingData = []): string
    {
        $modes = is_array($existingData['modes'] ?? null) ? $existingData['modes'] : ['follow', 'connection', 'block'];
        $showCountsChecked = !empty($existingData['show_counts']) ? 'checked' : '';
        $modeOptions = ['follow' => 'Follow (one-way)', 'connection' => 'Connection (mutual)', 'block' => 'Block'];
        $modesHtml = '';
        foreach ($modeOptions as $mode => $label) {
            $checked = in_array($mode, $modes, true) ? 'checked' : '';
            $modesHtml .= '<label class="checkbox-label"><input type="checkbox" name="fields[' . (int) $fieldIndex . '][modes][]" value="' . htmlspecialchars($mode) . '" ' . $checked . '> ' . htmlspecialchars($label) . '</label>';
        }

        return <<<HTML
            <div class="field-config-section">
                <label>Relationship kinds</label>
                <div class="field-config-row">{$modesHtml}</div>
            </div>
            <div class="field-config-section">
                <label class="checkbox-label">
                    <input type="checkbox" name="fields[{$fieldIndex}][show_counts]" value="1" {$showCountsChecked}>
                    Show summary counts in the entry editor
                </label>
            </div>
            <p class="help-text">Virtual field — graph is stored in the User plugin, not on the profile entry. Requires an owner field on this collection.</p>
        HTML;
    }

    public function getSchema(): array
    {
        return ['type' => 'object'];
    }

    public function getDefaultValue()
    {
        return null;
    }

    public function processValue($value)
    {
        return null;
    }

    public function processLoadedValue($value)
    {
        return is_array($value) ? $value : null;
    }

    public function renderListCell($value, array $context = []): string
    {
        if (!is_array($value)) {
            return '<span class="ft-list-empty">–</span>';
        }
        $summary = is_array($value['summary'] ?? null) ? $value['summary'] : $value;
        $parts = [];
        if (isset($summary['following'])) {
            $parts[] = (int) $summary['following'] . ' following';
        }
        if (isset($summary['connected'])) {
            $parts[] = (int) $summary['connected'] . ' connected';
        }

        return $parts === []
            ? '<span class="ft-list-empty">–</span>'
            : '<span class="ft-list-text">' . htmlspecialchars(implode(' · ', $parts), ENT_QUOTES, 'UTF-8') . '</span>';
    }

    /**
     * @param array<string, mixed> $config
     */
    private function resolveAnchorUserId(array $config): string
    {
        foreach (['entry_owner', 'anchor_user_id', 'owner', 'user_id'] as $key) {
            $val = $config[$key] ?? null;
            if (is_array($val)) {
                $val = $val[0] ?? '';
            }
            $val = trim((string) $val);
            if ($val !== '') {
                return $val;
            }
        }

        $entry = $config['entry'] ?? null;
        if (is_array($entry)) {
            foreach (['owner', 'user_id'] as $key) {
                $val = $entry[$key] ?? '';
                if (is_array($val)) {
                    $val = $val[0] ?? '';
                }
                $val = trim((string) $val);
                if ($val !== '') {
                    return $val;
                }
            }

            $anchor = $this->resolveAnchorFromAccountField($entry);
            if ($anchor !== '') {
                return $anchor;
            }
        }

        if (is_array($this->value) && !empty($this->value['anchor_user_id'])) {
            return (string) $this->value['anchor_user_id'];
        }

        return '';
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function resolveAnchorFromAccountField(array $entry): string
    {
        if (!class_exists('UserCollectionResolver')) {
            require_once __DIR__ . '/../../includes/UserCollectionResolver.php';
        }
        if (!class_exists('MemberAccountCodec')) {
            require_once __DIR__ . '/../../includes/MemberAccountCodec.php';
        }
        if (!class_exists('MemberLegacyMap')) {
            require_once __DIR__ . '/../../includes/MemberLegacyMap.php';
        }

        $collectionSlug = trim((string) ($entry['collection_slug'] ?? ''));
        if ($collectionSlug === '' && isset($_GET['collection'])) {
            $collectionSlug = trim((string) $_GET['collection']);
        }

        $resolver = new \UserCollectionResolver();
        $accountField = $collectionSlug !== '' ? $resolver->getAccountFieldOnSchema($collectionSlug) : null;
        if ($accountField === null) {
            foreach ($entry as $key => $value) {
                if (!is_array($value)) {
                    continue;
                }
                if (!empty($value['member_id']) || !empty($value['legacy_user_id'])) {
                    $legacy = trim((string) ($value['legacy_user_id'] ?? ''));
                    if ($legacy !== '') {
                        return $legacy;
                    }
                    $memberId = trim((string) ($value['member_id'] ?? ''));
                    if ($memberId !== '') {
                        $mapped = (new \MemberLegacyMap())->resolveUserIdForMember($memberId);

                        return $mapped ?? $memberId;
                    }
                }
            }

            return '';
        }

        $fieldName = (string) ($accountField['name'] ?? 'account');
        $account = \MemberAccountCodec::normalize($entry[$fieldName] ?? []);
        $legacy = trim((string) ($account['legacy_user_id'] ?? ''));
        if ($legacy !== '') {
            return $legacy;
        }

        $memberId = trim((string) ($account['member_id'] ?? ''));
        if ($memberId === '') {
            return '';
        }

        $mapped = (new \MemberLegacyMap())->resolveUserIdForMember($memberId);

        return $mapped ?? $memberId;
    }
}
