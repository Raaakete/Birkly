<?php
/**
 * Site user account fieldtype (P77/P78) — login identity on a profile collection entry.
 */

declare(strict_types=1);

namespace UserManagement\Fieldtypes;

if (!class_exists('Birkly\FieldTypes\BaseField')) {
    require_once __DIR__ . '/../../cms_paths.php';
    $base = user_management_cms_path('fieldtypes/BaseField.php');
    if (is_file($base)) {
        require_once $base;
    }
}

use Birkly\FieldTypes\BaseField;

class UserAccount extends BaseField
{
    protected string $profileTypeKey = 'user_account';

    /** @var array<string, mixed> */
    protected array $profileSettings = [];

    /** @var array<string, mixed> */
    protected array $fieldConfig = [];

    public function __construct(array $config)
    {
        parent::__construct($config);
        $this->fieldConfig = $config;
        $this->profileTypeKey = (string) ($config['type'] ?? $config['field_type'] ?? 'user_account');
        $this->profileSettings = $this->resolveProfileSettings();
    }

    public function getType(): string
    {
        return $this->profileTypeKey;
    }

    public function getCategory(): string
    {
        return 'User Management';
    }

    public function render(): string
    {
        if (!class_exists('MemberAccountCodec')) {
            require_once __DIR__ . '/../../includes/MemberAccountCodec.php';
        }

        $fieldName = htmlspecialchars($this->name);
        $value = \MemberAccountCodec::processForAdmin($this->value ?? []);
        $profile = $this->resolveProfile();
        $profileName = htmlspecialchars((string) ($profile['name'] ?? 'Site user account'));
        $userId = htmlspecialchars((string) ($value['member_id'] ?? ''));
        $tierId = htmlspecialchars((string) ($value['tier_id'] ?? 'all'));
        $email = htmlspecialchars((string) ($value['email'] ?? ''));
        $name = htmlspecialchars((string) ($value['name'] ?? ''));
        $status = (string) ($value['status'] ?? 'pending');
        $verified = !empty($value['verified']);
        $passwordSet = !empty($value['password_set']);
        $customFields = (array) ($this->profileSettings['requirements']['custom_fields'] ?? []);

        $html = '<div class="user-account-fieldtype" data-field-name="' . $fieldName . '" data-profile-type="' . htmlspecialchars($this->profileTypeKey) . '">';
        $html .= '<div class="user-account-fieldtype-intro">';
        $html .= '<p class="user-account-fieldtype-title">' . $profileName . '</p>';
        $html .= '<p class="field-help">This profile entry is linked to one site user account (login, tier, signup fields).</p>';
        $html .= '</div>';

        $html .= '<section class="user-account-section">';
        $html .= '<h4 class="user-account-section-title">Account</h4>';
        $html .= '<div class="user-account-stack">';
        $html .= '<label class="user-account-field">User ID';
        $html .= '<input type="text" class="form-control" name="' . $fieldName . '[member_id]" value="' . $userId . '" readonly>';
        $html .= '<span class="field-help">Stable id for this user across collections</span>';
        $html .= '</label>';
        $html .= '<label class="user-account-field">Display name';
        $html .= '<input type="text" class="form-control" name="' . $fieldName . '[name]" value="' . $name . '">';
        $html .= '</label>';
        $html .= '<label class="user-account-field">Email';
        $html .= '<input type="email" class="form-control user-account-email" name="' . $fieldName . '[email]" value="' . $email . '" autocomplete="off">';
        $html .= '</label>';
        $html .= '</div></section>';

        $html .= '<section class="user-account-section">';
        $html .= '<h4 class="user-account-section-title">Access</h4>';
        $html .= '<div class="user-account-stack">';
        $html .= '<label class="user-account-field">Status';
        $html .= '<select class="form-control" name="' . $fieldName . '[status]">';
        foreach (['pending' => 'Pending', 'active' => 'Active', 'suspended' => 'Suspended'] as $key => $label) {
            $selected = $status === $key ? ' selected' : '';
            $html .= '<option value="' . $key . '"' . $selected . '>' . $label . '</option>';
        }
        $html .= '</select></label>';
        $html .= '<label class="user-account-field user-account-checkbox">';
        $html .= '<input type="checkbox" name="' . $fieldName . '[verified]" value="1"' . ($verified ? ' checked' : '') . '> Email verified';
        $html .= '</label>';
        $html .= '</div>';
        $html .= '<div class="user-account-password-block">';
        if ($passwordSet) {
            $html .= '<p class="field-help">Password is set. Leave blank to keep the current password.</p>';
            $html .= '<input type="hidden" name="' . $fieldName . '[password]" value="' . htmlspecialchars(\MemberAccountCodec::PASSWORD_UNCHANGED) . '">';
            $html .= '<label class="user-account-field">New password';
            $html .= '<input type="password" class="form-control user-account-password-new" name="' . $fieldName . '[password_new]" autocomplete="new-password" placeholder="Enter new password">';
            $html .= '</label>';
        } else {
            $html .= '<label class="user-account-field">Password';
            $html .= '<input type="password" class="form-control user-account-password-new" name="' . $fieldName . '[password]" autocomplete="new-password" placeholder="Set password">';
            $html .= '</label>';
        }
        $html .= '</div></section>';

        $html .= '<section class="user-account-section">';
        $html .= '<h4 class="user-account-section-title">Tier</h4>';
        $html .= '<label class="user-account-field">Tier id';
        $html .= '<input type="text" class="form-control" name="' . $fieldName . '[tier_id]" value="' . $tierId . '" placeholder="all">';
        $html .= '<span class="field-help">Matches a tier from User → Tiers</span>';
        $html .= '</label></section>';

        if ($customFields !== []) {
            $html .= '<section class="user-account-section">';
            $html .= '<h4 class="user-account-section-title">Profile fields</h4>';
            $html .= '<div class="user-account-stack">';
            foreach ($customFields as $field) {
                if (!is_array($field)) {
                    continue;
                }
                $key = (string) ($field['key'] ?? '');
                if ($key === '') {
                    continue;
                }
                $label = htmlspecialchars((string) ($field['label'] ?? $key));
                $required = !empty($field['required']) ? ' required' : '';
                $customValue = htmlspecialchars((string) (($value['custom'][$key] ?? '') ?: ''));
                $html .= '<label class="user-account-field">' . $label;
                $html .= '<input type="text" class="form-control" name="' . $fieldName . '[custom][' . htmlspecialchars($key) . ']" value="' . $customValue . '"' . $required . '>';
                $html .= '</label>';
            }
            $html .= '</div></section>';
        }

        $commerce = is_array($value['commerce'] ?? null) ? $value['commerce'] : [];
        $paymentSummary = is_array($commerce['payment_summary'] ?? null) ? $commerce['payment_summary'] : [];
        if ($paymentSummary !== [] || !empty($commerce['customer_id'])) {
            $html .= '<section class="user-account-section user-account-commerce-summary">';
            $html .= '<h4 class="user-account-section-title">Payment (Commerce)</h4>';
            if (!empty($commerce['customer_id'])) {
                $html .= '<p class="field-help">Customer: <code>' . htmlspecialchars((string) $commerce['customer_id']) . '</code></p>';
            }
            if (array_key_exists('has_payment_method', $paymentSummary)) {
                $hasMethod = !empty($paymentSummary['has_payment_method']);
                $html .= '<p class="field-help">Payment method: ' . ($hasMethod ? 'On file' : 'None') . '</p>';
            }
            if (!empty($paymentSummary['subscription_status'])) {
                $html .= '<p class="field-help">Subscription: ' . htmlspecialchars((string) $paymentSummary['subscription_status']) . '</p>';
            }
            $html .= '<p class="field-help">Card and billing details are stored in Commerce only.</p>';
            $html .= '</section>';
        }

        $html .= '<input type="hidden" name="' . $fieldName . '[fieldtype_profile_id]" value="' . htmlspecialchars((string) ($value['fieldtype_profile_id'] ?? ($profile['id'] ?? 'default'))) . '">';
        $html .= '</div>';

        return $html;
    }

    public function validate($value): array
    {
        if (!class_exists('MemberAccountCodec')) {
            require_once __DIR__ . '/../../includes/MemberAccountCodec.php';
        }

        $normalized = \MemberAccountCodec::normalize($value);
        $isNew = trim((string) ($normalized['member_id'] ?? '')) === '';

        return \MemberAccountCodec::validate($normalized, $this->profileSettings, $isNew);
    }

    public function getJavaScript(): string
    {
        $jsFile = __DIR__ . '/fieldtype.js';
        if (file_exists($jsFile)) {
            return file_get_contents($jsFile);
        }

        return '';
    }

    public function getCSS(): string
    {
        return '
        .user-account-fieldtype {
            border: 1px solid var(--border-color, #e2e8f0);
            border-radius: 10px;
            padding: 1.25rem;
            background: var(--surface-muted, #f8fafc);
        }
        .user-account-fieldtype-intro {
            margin-bottom: 1.25rem;
        }
        .user-account-fieldtype-title {
            font-weight: 600;
            font-size: 1rem;
            margin: 0 0 0.35rem;
        }
        .user-account-section {
            padding: 1rem 0;
            border-top: 1px solid var(--border-color, #e2e8f0);
        }
        .user-account-section:first-of-type {
            border-top: 0;
            padding-top: 0;
        }
        .user-account-section-title {
            margin: 0 0 0.75rem;
            font-size: 0.8125rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: var(--text-muted, #64748b);
        }
        .user-account-stack {
            display: flex;
            flex-direction: column;
            gap: 0.85rem;
        }
        .user-account-field {
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
            font-size: 0.875rem;
        }
        .user-account-checkbox {
            flex-direction: row;
            align-items: center;
            gap: 0.5rem;
        }
        .user-account-password-block {
            margin-top: 0.85rem;
        }
        .user-account-commerce-summary {
            padding-top: 1rem;
            border-top: 1px solid var(--border-color, #e2e8f0);
        }
        ';
    }

    public function getAdminConfig(): array
    {
        return [];
    }

    public function getSchema(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'member_id' => ['type' => 'string'],
                'tier_id' => ['type' => 'string'],
                'email' => ['type' => 'string'],
                'password' => ['type' => 'string'],
                'name' => ['type' => 'string'],
                'status' => ['type' => 'string'],
                'verified' => ['type' => 'boolean'],
                'custom' => ['type' => 'object'],
            ],
        ];
    }

    public function getDefaultValue()
    {
        if (!class_exists('MemberAccountCodec')) {
            require_once __DIR__ . '/../../includes/MemberAccountCodec.php';
        }

        return \MemberAccountCodec::defaultValue();
    }

    public function processValue($value)
    {
        if (!class_exists('MemberAccountCodec')) {
            require_once __DIR__ . '/../../includes/MemberAccountCodec.php';
        }

        if (is_array($value) && isset($value['password_new'])) {
            $newPassword = trim((string) $value['password_new']);
            if ($newPassword !== '') {
                $value['password'] = $newPassword;
            }
            unset($value['password_new']);
        }

        return \MemberAccountCodec::processForStorage(
            $value,
            $this->value,
            $this->profileSettings,
            $this->profileTypeKey
        );
    }

    public function processLoadedValue($value)
    {
        if (!class_exists('MemberAccountCodec')) {
            require_once __DIR__ . '/../../includes/MemberAccountCodec.php';
        }

        return \MemberAccountCodec::processForAdmin($value);
    }

    public function renderListCell($value, array $context = []): string
    {
        if (!class_exists('MemberAccountCodec')) {
            require_once __DIR__ . '/../../includes/MemberAccountCodec.php';
        }

        $data = \MemberAccountCodec::normalize($value);
        $memberId = trim((string) ($data['member_id'] ?? ''));
        $name = trim((string) ($data['name'] ?? ''));
        if ($memberId === '' && $name === '') {
            return '<span class="ft-list-empty">–</span>';
        }

        $label = $name !== '' ? $name : $memberId;
        $suffix = ($name !== '' && $memberId !== '') ? ' <span class="ft-list-muted">(' . htmlspecialchars($memberId) . ')</span>' : '';

        return '<span class="ft-list-text">' . htmlspecialchars($label) . $suffix . '</span>';
    }

    public function getListColumnWidth(): string
    {
        return '200px';
    }

    public function getConfigUI($fieldIndex, $existingData = []): string
    {
        return '<div class="field-config user-account-field-config">'
            . '<p class="field-help">Links this collection entry to a <strong>site user account</strong> (login, tier, signup fields). '
            . 'Use the Display Name and API Name fields above — do not add a second name here. '
            . 'Signup rules come from the linked fieldtype profile in User → Fieldtypes.</p>'
            . '</div>';
    }

    /** @return array<string, mixed> */
    private function resolveProfile(): array
    {
        if (!class_exists('UserFieldtypeProfileStore')) {
            require_once __DIR__ . '/../../includes/UserFieldtypeProfileStore.php';
        }
        $store = new \UserFieldtypeProfileStore();
        $profile = $store->getProfileByTypeKey($this->profileTypeKey);

        return is_array($profile) ? $profile : [];
    }

    /** @return array<string, mixed> */
    private function resolveProfileSettings(): array
    {
        if (isset($this->fieldConfig['profile_settings']) && is_array($this->fieldConfig['profile_settings'])) {
            return $this->fieldConfig['profile_settings'];
        }

        if (function_exists('user_management_fieldtype_profile_settings')) {
            return user_management_fieldtype_profile_settings($this->profileTypeKey);
        }

        if (!class_exists('UserFieldtypeProfileStore')) {
            require_once __DIR__ . '/../../includes/UserFieldtypeProfileStore.php';
        }

        return (new \UserFieldtypeProfileStore())->getSettingsForTypeKey($this->profileTypeKey);
    }
}
