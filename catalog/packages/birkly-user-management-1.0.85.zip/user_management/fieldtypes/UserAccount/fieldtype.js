/**
 * User account fieldtype admin helpers (P77-M2).
 */
(function () {
    'use strict';

    if (window.__haru_user_account_fieldtype_bound) {
        return;
    }
    window.__haru_user_account_fieldtype_bound = true;

    function initContainer(container) {
        if (!container || !(container instanceof HTMLElement)) {
            return;
        }
        if (container.dataset.userAccountFieldtypeInit === '1') {
            return;
        }
        container.dataset.userAccountFieldtypeInit = '1';

        const passwordNew = container.querySelector('.user-account-password-new');
        const hiddenPassword = container.querySelector('input[type="hidden"][name$="[password]"]');

        if (passwordNew && hiddenPassword) {
            passwordNew.addEventListener('input', function () {
                if (passwordNew.value.trim() !== '') {
                    hiddenPassword.value = passwordNew.value;
                }
            });
        }
    }

    function scan(root) {
        const scope = root && root.querySelectorAll ? root : document;
        scope.querySelectorAll('.user-account-fieldtype').forEach(initContainer);
    }

    document.addEventListener('DOMContentLoaded', function () {
        scan(document);
    });

    if (typeof MutationObserver !== 'undefined') {
        const observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (!(node instanceof HTMLElement)) {
                        return;
                    }
                    if (node.matches && node.matches('.user-account-fieldtype')) {
                        initContainer(node);
                    } else {
                        scan(node);
                    }
                });
            });
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
    }
})();
