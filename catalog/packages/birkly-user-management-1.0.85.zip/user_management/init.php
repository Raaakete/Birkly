<?php
/**
 * P77 fieldtype profile registration and helpers.
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/UserFieldtypeProfileStore.php';

function user_management_register_fieldtype_profiles(): void
{
    if (!function_exists('register_plugin_fieldtype')) {
        return;
    }

    if (!class_exists('Birkly\FieldTypes\BaseField')) {
        $base = user_management_cms_path('fieldtypes/BaseField.php');
        if (is_file($base)) {
            require_once $base;
        }
    }

    require_once __DIR__ . '/fieldtypes/UserAccount/UserAccount.php';

    $pluginId = 'user_management';
    $store = new UserFieldtypeProfileStore();

    global $haru_plugin_fieldtypes;
    if (isset($haru_plugin_fieldtypes) && function_exists('unregister_plugin_fieldtype')) {
        foreach (array_keys($haru_plugin_fieldtypes) as $type) {
            if (!str_starts_with((string) $type, 'user_account')) {
                continue;
            }
            if (($haru_plugin_fieldtypes[$type]['plugin_id'] ?? '') === $pluginId) {
                unregister_plugin_fieldtype($type, $pluginId);
            }
        }
    }

    foreach ($store->listProfiles() as $profile) {
        $typeKey = (string) ($profile['type_key'] ?? 'user_account');
        register_plugin_fieldtype(
            $typeKey,
            'UserManagement\\Fieldtypes\\UserAccount',
            $pluginId,
            [
                'label' => (string) ($profile['name'] ?? 'Site user account'),
                'description' => 'Site user account fieldtype profile',
                'profile_id' => $profile['id'] ?? null,
            ]
        );
    }
}

function user_management_fieldtype_profile_settings(string $typeKey): array
{
    $store = new UserFieldtypeProfileStore();

    return $store->getSettingsForTypeKey($typeKey);
}

function user_management_ensure_fieldtype_profiles(): void
{
    new UserFieldtypeProfileStore();
    user_management_register_fieldtype_profiles();
    user_management_ensure_tier_profiles();
}

function user_management_ensure_tier_profiles(): void
{
    if (!class_exists('TierProfileService')) {
        require_once __DIR__ . '/includes/TierProfileService.php';
    }

    $service = new TierProfileService();
    $service->migrateSignupFieldsToDefaultProfile();
    $service->ensureAllTiersLinked();
}

/**
 * Redact sensitive member account field values before export / MCP reads.
 *
 * @param array<string, mixed> $entry
 * @param array<string, mixed>|null $schema
 * @return array<string, mixed>
 */
function user_management_scrub_entry_account_fields(array $entry, ?array $schema = null): array
{
    if (!class_exists('MemberAccountCodec')) {
        require_once __DIR__ . '/includes/MemberAccountCodec.php';
    }

    $fields = is_array($schema) ? ($schema['fields'] ?? []) : [];
    if ($fields === [] && isset($entry['collection']) && function_exists('birkly_entry_read_schema')) {
        $schemaData = birkly_entry_read_schema((string) $entry['collection']);
        $fields = is_array($schemaData) ? ($schemaData['fields'] ?? []) : [];
    }

    foreach ($fields as $field) {
        if (!is_array($field)) {
            continue;
        }
        $name = (string) ($field['name'] ?? '');
        $type = (string) ($field['type'] ?? '');
        if ($name === '' || !MemberAccountCodec::isAccountFieldType($type)) {
            continue;
        }
        if (!array_key_exists($name, $entry)) {
            continue;
        }
        $entry[$name] = MemberAccountCodec::redactForExport($entry[$name]);
    }

    return $entry;
}
