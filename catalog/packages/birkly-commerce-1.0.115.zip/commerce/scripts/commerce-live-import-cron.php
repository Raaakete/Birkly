#!/usr/bin/env php
<?php
/**
 * Run scheduled Commerce live imports.
 *
 * Usage:
 *   php scripts/commerce-live-import-cron.php --token=<cron_token>
 */

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This script must be run from CLI.\n");
    exit(1);
}

$opts = getopt('', ['token:', 'birkly-root::']);
$token = trim((string) ($opts['token'] ?? getenv('COMMERCE_IMPORT_CRON_TOKEN') ?: ''));
$pluginRoot = dirname(__DIR__);
$birklyRoot = trim((string) ($opts['birkly-root'] ?? getenv('BIRKLY_ROOT') ?: ''));

if ($birklyRoot === '') {
    $candidate = dirname($pluginRoot, 2);
    if (is_file($candidate . '/core/plugins.php')) {
        $birklyRoot = $candidate;
    }
}

if ($birklyRoot !== '' && is_file(rtrim($birklyRoot, '/') . '/core/plugins.php')) {
    require_once rtrim($birklyRoot, '/') . '/core/plugins.php';
    if (function_exists('load_plugins')) {
        load_plugins();
    }
}

require_once $pluginRoot . '/init.php';
commerce_bootstrap_cart_services();
require_once $pluginRoot . '/includes/CommerceImportCredentialStore.php';
require_once $pluginRoot . '/includes/CommerceLiveImportService.php';

$credentials = new CommerceImportCredentialStore();
if (!$credentials->cronTokenMatches($token)) {
    fwrite(STDERR, "Invalid or missing Commerce import cron token.\n");
    exit(2);
}

$service = new CommerceLiveImportService($credentials);
$results = $service->syncScheduled();
$failed = array_values(array_filter($results, fn ($row) => empty($row['ok'])));

echo json_encode([
    'status' => empty($failed) ? 'ok' : 'error',
    'synced_count' => count($results),
    'failed_count' => count($failed),
    'results' => $results,
], JSON_PRETTY_PRINT) . PHP_EOL;

exit(empty($failed) ? 0 : 3);
