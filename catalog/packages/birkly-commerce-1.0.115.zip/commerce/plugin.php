<?php
/**
 * Commerce Plugin — payment providers, catalog, cart, checkout, orders.
 */

if (defined('BIRKLY_COMMERCE_BOOTSTRAP')) {
    return;
}
define('BIRKLY_COMMERCE_BOOTSTRAP', true);

require_once __DIR__ . '/init.php';

$shelf = commerce_bootstrap();

if ($shelf && function_exists('register_plugin_service')) {
    register_plugin_service('commerce_shelf', $shelf, [
        'version' => '1.0.0',
        'description' => 'Payment processing shelf for consumer plugins',
        'capability' => 'access_commerce_shelf',
        'scope' => 'global',
    ]);
    register_plugin_service('payment_shelf', $shelf, [
        'version' => '1.0.0',
        'description' => 'Legacy alias for commerce_shelf',
        'capability' => 'access_payment_shelf',
        'scope' => 'global',
    ]);
}

if (function_exists('register_api_endpoint')) {
    register_api_endpoint('commerce', __DIR__ . '/api/commerce.php');
    register_api_endpoint('payments', __DIR__ . '/api/payments.php');
    register_api_endpoint('commerce_webhook', __DIR__ . '/api/webhook.php');
    register_api_endpoint('payments_webhook', __DIR__ . '/api/webhook.php');
    register_api_endpoint('commerce_inventory_webhook', __DIR__ . '/api/commerce_webhooks.php');
}

if (function_exists('register_admin_page')) {
    register_admin_page('commerce', __DIR__ . '/admin/commerce.html');
    register_admin_page('payments', __DIR__ . '/admin/commerce.html');
}

if (function_exists('register_plugin_admin_meta')) {
    register_plugin_admin_meta('commerce', [
        'title' => 'Commerce',
        'root_page' => 'commerce',
        'permission' => 'manage_commerce',
        'page_slugs' => ['commerce', 'payments'],
        'sidebar' => [
            'show' => true,
            'label' => 'Commerce',
            'order' => 20,
            'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>',
        ],
    ]);
}

if (function_exists('register_plugin_fieldtype') && commerce_plugin_active()) {
    commerce_register_fieldtype_profiles();
}

if (function_exists('register_plugin_scheduled_task') && commerce_plugin_active()) {
    register_plugin_scheduled_task(
        'commerce',
        'process_scheduled_emails',
        'hourly',
        static function () {
            if (!class_exists('CommerceEmailService')) {
                require_once __DIR__ . '/includes/CommerceEmailService.php';
            }
            (new CommerceEmailService())->processDueScheduledEmails();
        },
        ['description' => 'Send delayed Commerce transactional emails (review requests, follow-ups)']
    );
}

if (function_exists('register_hook')) {
    register_hook('plugin_activated', function ($plugin_id) {
        if ($plugin_id === 'commerce') {
            commerce_migrate_legacy_data();
            commerce_bootstrap();
            // Ensure catalog index exists after activate/redeploy (donations, etc.)
            if (!class_exists('CatalogIndexer')) {
                require_once __DIR__ . '/includes/CatalogIndexer.php';
            }
            try {
                (new CatalogIndexer())->reindexAll(commerce_cms_content_root());
            } catch (Throwable $e) {
                // non-fatal
            }
        }
    });

    register_hook('automation_blocks_register', function () {
        if (commerce_plugin_active()) {
            commerce_init_automation_triggers();
        }
    });

    register_hook('after_entry_save', function ($entry, $collection, $oldEntry = null) {
        if (!commerce_plugin_active()) {
            return;
        }
        commerce_bootstrap_cart_services();
        $indexer = new CatalogIndexer();
        $indexer->indexEntry($entry, is_string($collection) ? $collection : ($collection['slug'] ?? ''));
    });

    register_hook('after_entry_delete', function ($entry, $collection) {
        if (!commerce_plugin_active()) {
            return;
        }
        commerce_bootstrap_cart_services();
        $indexer = new CatalogIndexer();
        $entryId = is_array($entry) ? ($entry['id'] ?? '') : (string) $entry;
        $collectionSlug = is_string($collection) ? $collection : ($collection['slug'] ?? '');
        $indexer->removeEntry($entryId, $collectionSlug);
    });
}

if (function_exists('automation_bootstrap') && automation_bootstrap()) {
    commerce_init_automation_triggers();
} elseif (function_exists('register_automation_block')) {
    commerce_init_automation_triggers();
}

commerce_register_payment_handlers();

if (function_exists('register_template_function') && commerce_plugin_active()) {
    register_template_function('commerce_cart_count', function () {
        commerce_bootstrap_cart_services();
        $cart = new CommerceCartSession();
        return (string) $cart->count();
    }, [
        'description' => 'Returns the number of items in the commerce cart session',
        'arguments' => [],
    ]);

    register_template_function('commerce_cart_url', function () {
        return commerce_cart_url();
    }, [
        'description' => 'Returns the URL to view the commerce cart (JSON API)',
        'arguments' => [],
    ]);

    register_template_function('commerce_buy_url', function ($entryId = '', $collectionSlug = '', $qty = 1, $purchaseOptionId = '') {
        return commerce_buy_url(
            (string) $entryId,
            (string) $collectionSlug,
            (int) $qty,
            (string) $purchaseOptionId
        );
    }, [
        'description' => 'Returns add-to-cart URL for a catalog entry and optional purchase option',
        'arguments' => [
            'entry_id' => ['type' => 'string', 'description' => 'Entry or variant sub-entry ID'],
            'collection' => ['type' => 'string', 'description' => 'Collection slug'],
            'quantity' => ['type' => 'integer', 'description' => 'Quantity (default 1)'],
            'purchase_option_id' => ['type' => 'string', 'description' => 'Purchase option ID from commerce field'],
        ],
    ]);

    register_template_function('commerce_add_to_cart', function ($entryId = '', $collectionSlug = '', $qty = 1, $purchaseOptionId = '') {
        return commerce_buy_url(
            (string) $entryId,
            (string) $collectionSlug,
            (int) $qty,
            (string) $purchaseOptionId
        );
    }, [
        'description' => 'Alias for commerce_buy_url',
        'arguments' => [
            'entry_id' => ['type' => 'string'],
            'collection' => ['type' => 'string'],
            'quantity' => ['type' => 'integer'],
            'purchase_option_id' => ['type' => 'string'],
        ],
    ]);

    register_template_function('commerce_subscription_status', function ($subscriptionId = '') {
        $subscriptionId = trim((string) $subscriptionId);
        if ($subscriptionId === '') {
            return '';
        }
        commerce_bootstrap_cart_services();
        $store = new CommerceSubscriptionStore();
        $sub = $store->get($subscriptionId);
        return $sub ? (string) ($sub['status'] ?? '') : '';
    }, [
        'description' => 'Returns the lifecycle status (active, past_due, canceled) for a subscription id, or empty string if not found',
        'arguments' => [
            'subscription_id' => ['type' => 'string', 'description' => 'Commerce subscription id (csub_…)'],
        ],
    ]);

    register_template_function('commerce_price_from', function ($commerceValue = null) {
        if (!class_exists('CommerceSchema')) {
            require_once __DIR__ . '/includes/CommerceSchema.php';
        }
        if (is_string($commerceValue)) {
            $decoded = json_decode($commerceValue, true);
            if (is_array($decoded)) {
                $commerceValue = $decoded;
            }
        }
        if (!is_array($commerceValue)) {
            return '0';
        }
        $cents = CommerceSchema::priceFrom($commerceValue);
        return (string) number_format($cents / 100, 2, '.', '');
    }, [
        'description' => 'Lowest price from a commerce field value (for "from €X" display)',
        'arguments' => [
            'commerce' => ['type' => 'array', 'description' => 'Commerce field value'],
        ],
    ]);

    register_template_function('commerce_quantity_available', function ($entryId = '', $collectionSlug = '') {
        $entryId = trim((string) $entryId);
        $collectionSlug = trim((string) $collectionSlug);
        if ($entryId === '' || $collectionSlug === '') {
            return '';
        }
        commerce_bootstrap_cart_services();
        $catalog = new CommerceCatalog();
        $item = $catalog->getItem($collectionSlug, $entryId);
        if (!$item || !array_key_exists('quantity_available', $item)) {
            return '';
        }
        $qty = $item['quantity_available'];
        return $qty === null ? '' : (string) (int) $qty;
    }, [
        'description' => 'Live catalog Available quantity for an entry (empty string when unlimited / unknown)',
        'arguments' => [
            'entry_id' => ['type' => 'string', 'description' => 'Entry or variant sub-entry ID'],
            'collection' => ['type' => 'string', 'description' => 'Collection slug'],
        ],
    ]);

    register_template_function('commerce_gift_card_balance', function ($code = '') {
        $code = trim((string) $code);
        if ($code === '') {
            return '0';
        }
        commerce_bootstrap_cart_services();
        $store = new GiftCardStore();
        $card = $store->getByCode($code);
        if (!$card || ($card['status'] ?? '') !== 'active') {
            return '0';
        }
        return (string) number_format(((int) ($card['balance_cents'] ?? 0)) / 100, 2, '.', '');
    }, [
        'description' => 'Returns remaining gift card balance in major currency units',
        'arguments' => ['code' => ['type' => 'string', 'description' => 'Gift card code']],
    ]);
}

if (function_exists('register_plugin_docs') && commerce_plugin_active()) {
    register_plugin_docs('commerce', [
        'title' => 'Commerce',
        'summary' => 'Content-first commerce: providers, cart, checkout, fulfillment (ship/deliver/register/none), purchase_options, variants via sub-entries, PostPurchaseRouter. Inbound MCP: commerce_* when active (docs/mcp-tools.md). WebMCP visitor tools: birkly_commerce_* (docs/webmcp-tools.md).',
        'badge' => 'Extension',
        'docs' => [
            'ai' => __DIR__ . '/docs/ai-context.md',
            'help' => __DIR__ . '/docs/help-overview.md',
            'help_topics' => [
                [
                    'id' => 'commerce-getting-started',
                    'title' => 'Getting started',
                    'file' => __DIR__ . '/docs/help-getting-started.md',
                    'keywords' => ['setup', 'quick start', 'stripe', 'first sale', 'beginner'],
                    'group' => 'Start here',
                ],
                [
                    'id' => 'commerce-settings-reference',
                    'title' => 'Settings reference',
                    'file' => __DIR__ . '/docs/help-settings-reference.md',
                    'keywords' => ['settings', 'connections', 'general', 'fieldtypes', 'mappings', 'invoices', 'emails'],
                    'group' => 'Start here',
                ],
                [
                    'id' => 'commerce-fieldtype',
                    'title' => 'Commerce fieldtype',
                    'file' => __DIR__ . '/docs/help-fieldtype.md',
                    'keywords' => ['fieldtype', 'fulfillment', 'purchase_options', 'variants', 'schema', 'tax_included'],
                    'group' => 'Sell & fulfill',
                ],
                [
                    'id' => 'commerce-catalog-inventory',
                    'title' => 'Catalog & inventory',
                    'file' => __DIR__ . '/docs/help-catalog-inventory.md',
                    'keywords' => ['catalog', 'inventory', 'sku', 'stock', 'warehouse'],
                    'group' => 'Sell & fulfill',
                ],
                [
                    'id' => 'commerce-orders-customers',
                    'title' => 'Orders & customers',
                    'file' => __DIR__ . '/docs/help-orders-customers.md',
                    'keywords' => ['orders', 'customers', 'refund', 'cancel', 'draft', 'quote'],
                    'group' => 'Sell & fulfill',
                ],
                [
                    'id' => 'commerce-tax',
                    'title' => 'Tax',
                    'file' => __DIR__ . '/docs/help-tax.md',
                    'keywords' => ['tax', 'vat', 'stripe tax', 'tax_included', 'reverse charge'],
                    'group' => 'Sell & fulfill',
                ],
                [
                    'id' => 'commerce-shipping',
                    'title' => 'Shipping',
                    'file' => __DIR__ . '/docs/help-shipping.md',
                    'keywords' => ['shipping', 'zones', 'easypost', 'weight', 'free shipping'],
                    'group' => 'Sell & fulfill',
                ],
                [
                    'id' => 'commerce-fulfillment',
                    'title' => 'Fulfillment',
                    'file' => __DIR__ . '/docs/help-fulfillment.md',
                    'keywords' => ['fulfillment', 'ship', 'deliver', 'packing slip', 'tracking'],
                    'group' => 'Sell & fulfill',
                ],
                [
                    'id' => 'commerce-subscriptions',
                    'title' => 'Subscriptions',
                    'file' => __DIR__ . '/docs/help-subscriptions.md',
                    'keywords' => ['subscriptions', 'recurring', 'dunning', 'billing'],
                    'group' => 'Grow',
                ],
                [
                    'id' => 'commerce-promotions',
                    'title' => 'Discounts & gift cards',
                    'file' => __DIR__ . '/docs/help-promotions.md',
                    'keywords' => ['discounts', 'coupons', 'gift cards', 'promotions', 'affiliates'],
                    'group' => 'Grow',
                ],
                [
                    'id' => 'commerce-hybrid-cart',
                    'title' => 'Hybrid cart',
                    'file' => __DIR__ . '/docs/help-hybrid-cart.md',
                    'keywords' => ['hybrid', 'split checkout', 'mixed cart'],
                    'group' => 'Grow',
                ],
                [
                    'id' => 'commerce-storefront',
                    'title' => 'Storefront & cart',
                    'file' => __DIR__ . '/docs/help-storefront.md',
                    'keywords' => ['storefront', 'cart', 'checkout', 'commerce-storefront', 'buy button'],
                    'group' => 'Build',
                ],
                [
                    'id' => 'commerce-templates',
                    'title' => 'Template functions',
                    'file' => __DIR__ . '/docs/help-templating.md',
                    'keywords' => ['template', 'commerce_buy_url', 'cart', 'price_from'],
                    'group' => 'Build',
                ],
                [
                    'id' => 'commerce-project-integration',
                    'title' => 'Project site integration',
                    'file' => __DIR__ . '/docs/help-project-integration.md',
                    'keywords' => ['project', 'website', 'integration', 'html', 'js'],
                    'group' => 'Build',
                ],
                [
                    'id' => 'commerce-developer',
                    'title' => 'Developer API',
                    'file' => __DIR__ . '/docs/help-developer.md',
                    'keywords' => ['api', 'webhooks', 'automation', 'mcp', 'webmcp', 'developer'],
                    'group' => 'Build',
                ],
                [
                    'id' => 'commerce-webmcp',
                    'title' => 'Website tools (WebMCP)',
                    'file' => __DIR__ . '/docs/webmcp-tools.md',
                    'keywords' => ['webmcp', 'website tools', 'cart', 'checkout', 'ai helper'],
                    'group' => 'Build',
                ],
                [
                    'id' => 'commerce-webhooks-automation',
                    'title' => 'Webhooks & Automation',
                    'file' => __DIR__ . '/docs/help-webhooks-automation.md',
                    'keywords' => ['webhooks', 'automation', 'recipes', 'triggers', 'dunning', 'low stock', 'easypost'],
                    'group' => 'Build',
                ],
                [
                    'id' => 'commerce-shopify-cutover',
                    'title' => 'Shopify cutover',
                    'file' => __DIR__ . '/docs/help-shopify-cutover.md',
                    'keywords' => ['shopify', 'migration', 'import', 'cutover'],
                    'group' => 'Migrate & fix',
                ],
                [
                    'id' => 'commerce-troubleshooting',
                    'title' => 'Troubleshooting',
                    'file' => __DIR__ . '/docs/help-troubleshooting.md',
                    'keywords' => ['troubleshooting', 'errors', 'remove', 'tax', 'faq'],
                    'group' => 'Migrate & fix',
                ],
            ],
            'public_path' => '06-extensibility/plugins/commerce.html',
        ],
        'mcp_topic_slug' => 'commerce',
        'keywords' => ['commerce', 'cart', 'checkout', 'payments', 'stripe', 'fieldtype', 'fulfillment', 'variants', 'tax', 'shipping'],
    ]);
}

if (function_exists('register_plugin_mcp_tools') && commerce_plugin_active()) {
    require_once __DIR__ . '/docs/mcp_tools.php';
    register_plugin_mcp_tools('commerce', commerce_mcp_tool_registry());
}

// WebMCP is the public-site visitor catalog (Discovery → WebMCP). Do not
// confuse with inbound Birkly MCP above (`register_plugin_mcp_tools`).
if (function_exists('birkly_webmcp_register_tools') && commerce_plugin_active()) {
    require_once __DIR__ . '/includes/webmcp_tools.php';
    birkly_webmcp_register_tools('commerce', commerce_webmcp_tool_catalog());
}

if (function_exists('birkly_webmcp_register_runtime_pack') && commerce_plugin_active()) {
    require_once __DIR__ . '/includes/webmcp_runtime.php';
}

global $birkly_plugins;
if (isset($birkly_plugins['commerce'])) {
    $birkly_plugins['commerce']['dashboard_widgets_callback'] = 'commerce_dashboard_widgets';
}

if (function_exists('register_broadcast_actor') && commerce_plugin_active()) {
    require_once __DIR__ . '/includes/notification_shelf.php';
}
