# Changelog

## 1.0.115 - 2026-09-08

- **P83-M4:** WebMCP runtime pack shelf — `assets/webmcp-pack.js` + `includes/webmcp_runtime.php` register commerce visitor tools via `birkly_webmcp_register_runtime_pack()` (core no longer hardcodes `registerCommercePack`).

## 1.0.113 - 2026-09-08

- **P83-M2:** Admin dashboard mount via `admin.scripts` shelf — `dashboard-widget.js` registers `commerceStats` widget using `Birkly.DashboardMount`.

## 1.0.112 - 2026-09-08

- **P82-M6:** Register `storefront.scripts` in `plugin.json` so `commerce-storefront.js` auto-loads when Commerce is active.
- **Storefront:** `commerce-storefront.js` uses `Birkly.routeFetch` / `Birkly.fetch` with credentialed CMS-origin requests and `X-Birkly-Site-Session` for cross-origin sites (replaces hardcoded `/api/index.php?route=commerce`).

## 1.0.111 - 2026-09-08

- **Fix:** `commerce_order_paid` event payload now includes checkout `metadata` (e.g. `signup_flow_opt_in`) so User plugin can send club activation emails after one-time donations.

## 1.0.106 - 2026-09-02

- **P74-M4:** Commerce decoupling — removed club/membership orchestration from Commerce.
- **Deleted:** `CommerceClubActivation`, `CommerceMembershipTierSync`, `CommerceMembershipEntitlement`.
- **Events:** `commerce_subscription_started` is the canonical trigger; `commerce_membership_started` remains as a deprecated alias for one release.
- **Checkout:** Linked checkout forwards `signup_flow_*` metadata instead of `club_opt_in`.
- **Shelf:** `PaymentShelf::getActiveSubscriptionsForEmail()` returns billing facts only (no tier grants).
- **Mappings:** Purchase mapping tier grants disabled — User plugin owns tier lifecycle (P74-M5).

## 1.0.101 - 2026-09-01

- **Live refunds:** Refunds resolve the Stripe connection from `payment_connection_id` on the order, or infer live/test from payment id (`cs_live_…`, `pi_test_…`) so live charges are not refunded with sandbox keys.
- **Refund errors:** Stripe/API errors are normalized to readable strings (fixes admin toast showing `[object Object]`).
- **Admin UX:** Refund modal uses `commerceToast` for failures and reloads order detail on success.

## 1.0.100 - 2026-09-01

- **Email tokens:** `commerce_store_display_name()` respects the Commerce data directory passed from `CommerceEmailService` (fixes `{{site_name}}` when invoice profile lives outside the default data dir).
- **Tests:** Reliable plugin-setting stub via `commerce_test_settings`; email tests isolate CMS mail/connection resolution with `commerce_test_skip_birkly_mail` and `commerce_test_passthrough_email_alias`.

## 1.0.99 - 2026-09-01

- **PayPal refunds:** Resolve capture ids from checkout order references and call the PayPal capture refund API (sandbox-ready; live remains certification-gated).
- **Stripe subscriptions:** Hosted subscription checkout sessions (`cs_` + `sub_`) resolve refundable PaymentIntents via latest invoice.
- **Donation detection:** Replace site-specific `orderIsDonation()` heuristics with `CommerceSchema::orderIsOpenContribution()` (entry sync metadata, `fulfillment: none`, variable pricing).
- **Linked checkout:** Storefront passes custom linked-entry form fields (including uploaded logo URLs) into `linked_entry.fields`.
- **Tests:** Reliable mail stub via `commerce_test_birkly_mail_result` fixes donation receipt test without sendmail.

## 1.0.98 - 2026-09-01

- **Hotfix:** Stripe refunds and captures now resolve hosted Checkout Session ids (`cs_…`) to the underlying PaymentIntent (`pi_…`) before calling Stripe. Fixes admin refund failures such as `No such payment_intent: 'cs_live_…'`.
- **Payment normalization:** Paid orders store `stripe_checkout_session_id` while `payment_id` is normalized to `pi_…` when available. Order lookup accepts either id; entry sync writes the session id to the configured CMS field.
- **Webhooks:** `checkout.session.completed` events now emit `payment_intent` as `payment_id` (session id kept in `checkout_session_id`).

## 1.0.97 - 2026-09-01

- **Rename:** `CommerceDonorSync` → `CommerceEntrySync` (deprecated subclass kept for one release). Orders store `entry_sync_meta`; `donor_meta` remains as a read/write alias for backward compatibility.
- **Linked checkout file uploads:** New public `upload_linked_checkout_asset` action and storefront pre-upload in `data-commerce-linked-checkout` forms. Images are stored under `/media/linked_checkout/` and passed into `linked_entry.fields` (e.g. `logo`) before `begin_linked_checkout`.

## 1.0.96 - 2026-09-01

- **Hotfix:** Custom donation amount on linked-checkout forms no longer reuses a stale preset amount when **Custom** is selected (`readAmountCentsFromForm` reads the live custom input first). Clear purchase-option state when the custom field is empty.

## 1.0.95 - 2026-09-01

- **Storefront Platform v2 (P70 M6):** Entry sync settings UI in Commerce → Settings (General) for all `commerce_entry_sync_*` keys. New admin `delete_orders` API and bulk **Delete selected** action for abandoned/canceled/failed orders.

## 1.0.94 - 2026-09-01

- **Storefront Platform v2 (P70 M4–M5):** `data-commerce-linked-checkout` form binder calls `begin_linked_checkout`. `handleHostedCheckoutReturn()` abandons canceled hosted checkouts and confirms success returns. `data-commerce-confirm-return` mount helper. Cadence and amount-select wiring for donation-style forms.

## 1.0.93 - 2026-09-01

- **Storefront Platform v2 (P70 M1–M3):** `catalog_item` returns enriched `purchase_options` (`allows_custom_amount`, min/max, suggested amounts). New `data-commerce-purchase-options` binder in `commerce-storefront.js`. New public `begin_linked_checkout` API creates optional linked CMS entries and starts hosted checkout with `commerce_entry_sync_*` metadata. Catalog lazy-index moved to `CommerceCatalog::resolveItem()`. RFC: `docs/RFC-STOREFRONT-PLATFORM-V2.md`.

## 1.0.92 - 2026-08-31

- **Connections UI:** Fix row **⋯** menu clipped by the connections table — menus use fixed viewport positioning with above/below flip; connections list no longer uses `overflow: hidden`.

## 1.0.91 - 2026-08-31

- **Hotfix:** Hosted Stripe Checkout no longer sends `automatic_payment_methods` (PaymentIntent-only parameter). Dashboard payment methods work by **omitting** `payment_method_types` on Checkout Sessions.

## 1.0.90 - 2026-08-31

- **Hotfix:** Remove invalid `excluded_payment_method_types: link` on hosted checkout (Stripe rejects `link` as an exclusion type).
- **Connections UI:** Replace broken core dropdown dependency with a self-contained row **⋯** menu in `payments.js`.

## 1.0.89 - 2026-08-31

- **Hotfix:** Fix donation/hosted checkout failing with Stripe HTTP 400 — `automatic_payment_methods` must not be combined with `wallet_options.link`; Link is excluded via `excluded_payment_method_types` instead.
- **Admin:** Cache-bust `payments.js` / `payments.css` so connection table UX updates load after plugin upgrade.
- Stripe API errors now surface the provider message instead of a bare `HTTP 400`.

## 1.0.88 - 2026-08-31

- **Connections UX:** Checkout connection shows a **Checkout** badge on its row; row **⋯** menu adds quick **Set as checkout**, **Activate/Deactivate**, and **Delete** actions.
- **Stripe hosted checkout:** Uses Stripe Dashboard payment methods (`automatic_payment_methods`) instead of card-only, so iDEAL, SEPA, Bancontact, etc. appear when enabled in Stripe. Link wallet overlay remains disabled.

## 1.0.87 - 2026-08-31

- **Payment connections:** Choose which connection is used for checkout when multiple Stripe (or other provider) connections exist.
- Connections list shows a **Default** badge and **Use for checkout** action; edit modal adds **Enabled** and **Use for checkout** toggles.
- Checkout resolution order: explicit default → live mode over test → most recently updated.
- Fixes production sites accidentally charging through sandbox when multiple connections were enabled.

## 1.0.86 - 2026-08-26

- **WebMCP:** Register visitor storefront tools (`birkly_commerce_get_cart`, `birkly_commerce_add_to_cart`, `birkly_commerce_checkout`) via `birkly_webmcp_register_tools()` so they appear in Discovery → WebMCP when Commerce is active.
- Tools default **off**. Distinct from inbound admin MCP (`register_plugin_mcp_tools` / `docs/mcp_tools.php`). See `docs/webmcp-tools.md`.

## 1.0.85 - 2026-08-20

- **Critical:** Fix Commerce admin API returning HTTP 500 on every request when MCP tools are registered (`Cannot redeclare commerce_inventory_ledger()`). Dashboard, orders, customers, and settings tabs failed to load while MCP could still read data.
- Extract shared `commerce_inventory_ledger()` helper used by HTTP API and MCP admin dispatch.

## 1.0.84 - 2026-08-20

- **Critical:** Fix merchant data loss when runtime JSON lived in a different directory than the active path (split `plugin-data` / colocated / legacy layouts). Reconciles orders, customers, connections, email templates, and invoices from all known storage paths on every bootstrap.
- Deep-merge into existing empty Docker skeleton directories so Hub/volume installs no longer skip migration.

## 1.0.83 - 2026-08-19

- **MCP admin parity:** `commerce_list_admin_actions` and `commerce_admin_action` dispatch all Commerce admin API actions (emails, invoices, fulfillment, inventory, tax, shipping, discounts, import, mappings, draft orders, analytics). Implementation in `includes/CommerceMcpAdmin.php`.
- Catalog read tools accept `manage_commerce`, `view_commerce_orders`, or `view_commerce_stats`.

## 1.0.82 - 2026-08-19

- **MCP tools:** Register `commerce_*` inbound MCP tools when active (orders, customers, catalog, subscriptions, reindex, shipment, notes). See `docs/mcp-tools.md`.
- Requires Birkly core with plugin MCP shelf (`register_plugin_mcp_tools`).

## 1.0.81 - 2026-08-18

- Fix commerce entry fieldtype not saving prices: sync hidden cent fields on `beforeSaveEntry` (entry editor saves via fetch, not form submit).
- Variable pricing min/max/suggested amounts use the same sync path.
- Custom tax class codes repopulate in the entry editor on load.
- Entry UI: group fulfillment, tax, purchase options, and product details in a single commerce shell.

## 1.0.80

- Entry sync is metadata-driven: checkout metadata references a CMS entry and collection slug; Commerce writes order/session/payment fields from plugin settings and publishes only when the consent metadata flag is truthy.
- New Commerce settings (`commerce_entry_sync_*`) configure metadata keys and CMS field names (no hardcoded collection or schema).

## 1.0.79

- `abandon_checkout` marks linked supporter rows `abandoned` and unpublishes them (no public_submit update hack).

## 1.0.78

- Donor sync: paid supporters are always published in the supporters collection; `show_public` / `featured` only control public list visibility (fixes pending paid donors like Tony).

## 1.0.77

- **Order paid** is now the receipt trigger for all paid orders, including donations (matches test send on the Order paid template).
- **Donation thank you** is opt-in only (disabled by default for new installs); use automation or manual resend when you want a separate donor message.
- Recent sends log moved back to the bottom of Settings → Emails.

## 1.0.76

- Move **Recent sends** delivery log to the top of Commerce → Settings → Emails with clearer empty-state guidance.
- Order detail: **Confirm payment & send receipt** (pending orders), **Resend receipt email**, and **View email log** actions.
- Donation orders: fall back to **Order paid** receipt when **Donation thank you** is disabled; clearer skip messages in the email log.

## 1.0.75 - 2026-08-18

- Fix order_paid emails not sending after live purchases: resolve orders from Stripe `pi_` / `cs_` ids, copy checkout metadata onto PaymentIntents, auto-confirm hosted Checkout returns via `session_id`, and log when no enabled template matches a trigger.
- Backfill `customer_email` from Stripe when missing on the order before sending receipt mail.
- Test email API warns when the template is disabled (live sends require **Enabled**).

## 1.0.74 - 2026-08-17

- General settings: **Store name** for customer-facing brand in transactional emails (`{{site_name}}` token).
- `{{site_name}}` now prefers the store name setting, then invoice company name, then “Commerce” (no longer conflates invoice legal name only).

## 1.0.73 - 2026-08-17

- Commerce test email: successful SMTP/ESP handoff now reports as delivered (not “queued for delivery”).
- Aligns with CMS mail transport fix returning `accepted` after SMTP DATA succeeds.

## 1.0.72 - 2026-08-17

- Fix Commerce test emails always logging locally: load the central `birkly_send_mail` pipeline before send (Commerce API no longer depends on another endpoint loading it first).
- Clearer test-email alerts when the active connection is Log only or the mail pipeline is missing.

## 1.0.71 - 2026-08-17

- Fix email connection picker on Settings → Emails: dropdown now loads for Commerce admins (not only Settings admins).
- Default Commerce email connection saves automatically when changed; per-template **Send using** picker renders reliably.

## 1.0.70 - 2026-08-17

- Transactional email templates: each template has its own **Send using** connection picker (override the Commerce default when you need different From addresses).
- Email attachments: optional invoice (HTML), packing slip (HTML), and shipping label (PDF when fulfillment stored a label URL).
- Core mail pipeline attachment support (SMTP, Resend, Postmark, Mailgun, SES raw) powers Commerce attachments.

## 1.0.69 - 2026-08-10

- Hosted Checkout: set Stripe `payment_intent_data[receipt_email]` so card receipts go out even when CMS SMTP is not configured.
- Donor sync stores supporter logos as URL strings so templates can render them.
- Commerce email log: treat Automation log transport / local log-only as not delivered (clearer Ops signal to configure SMTP).
- Migrated CommerceEmailService to the central Birkly mail pipeline: routes through `birkly_send_mail` / `birkly_notify`; removed `automation_send_mail` and PHP `mail()` fallbacks. Statuses are honest (`delivered`, `logged`, `queued`, `failed`) instead of fake `ok: true`. Local log-only remains as a last resort when the pipeline is absent.
- Commerce Emails admin copy and empty states now explain that enabling a template only prepares the message; inbox delivery requires a healthy Email connection under Settings → Connections, and Stripe may still send its own card receipts.

## 1.0.68 - 2026-08-10

- Persist checkout draft `customer_name` + donor `metadata` onto orders and Stripe session metadata.
- After paid donation orders: sync a CMS `supporters` entry (featured → published; otherwise pending) via `CommerceDonorSync`.
- Donation thank-you email trigger (`donation_thanks`) with warmer copy than the shop receipt.

## 1.0.67 - 2026-08-10

- Hosted Checkout: set `wallet_options[link][display]=never` (Stripe API `2025-04-30.basil`) so Link OTP is not the first screen when a donor email matches a Link account. Card entry stays the default path.

## 1.0.66 - 2026-08-10

- Fix Stripe “Failed to write connection file”: probe `plugin-data/commerce` writability and fall back to colocated `plugins/commerce` when the volume cannot create/write the dedicated runtime tree.
- Clearer CredentialStore errors include the target path when encryption key or connection JSON cannot be written.

## 1.0.65 - 2026-08-10

- Hosted Checkout cancel URL: put `commerce_cancel` query before `#hash` so abandon runs after Stripe cancel.

## 1.0.64 - 2026-08-10

- Fix catalog index CMS paths when plugin lives under `BIRKLY_DATA/plugins/commerce` (`commerce_cms_content_root` / `commerce_cms_path`).
- Auto-reindex empty catalog on bootstrap and plugin activate.
- Hosted Checkout: map `cs_` session status, handle `checkout.session.*` webhooks, `abandon_checkout` API, cancel URL `commerce_cancel` param.

## 1.0.63 - 2026-08-10

- Persist runtime data outside Hub install tree (`plugin-data/commerce`) so Stripe connections / orders survive updates.
- Hosted Checkout Session defaults to `payment_method_types: card` (skips Stripe Link OTP as the primary path).

## 1.0.62 - 2026-08-10

- Hub packaging release: same hosted Checkout Session + lazy catalog index as 1.0.61, shipped so Marketplace can attach a clean artifact checksum (repairs Hub “Checksum verification failed” on update).

## 1.0.61 - 2026-08-10

- Hosted Stripe Checkout when `hosted_checkout` is set (returns `redirect_url`) for donation / Payment Link–style redirects.
- Checkout API accepts `success_url` / `customer_email` aliases.
- Includes 1.0.60 lazy catalog index on cart add + reindex on activate.

## 1.0.59 - 2026-08-08

- Settings hub vertical nav matches Media / Agent Guide (`.side-nav-group` + `.side-nav-label`).
- Settings panels: sectioned layout, clearer spacing and form rhythm.
- **Docs** is a primary Commerce tab (no longer buried under Settings).
- Comprehensive in-admin documentation hub: merchant + developer guides, grouped topics, tables, code samples, and SVG figures (settings reference, webhooks/automation, storefront, tax, shipping, and more).

## 1.0.56 - 2026-08-08

- Cart remove: session rows stored without `purchase_option_id` now match a remove that targets the resolved default (e.g. `once`).
- Cart add: persist the resolved `purchase_option_id` onto the session row when the client omitted it.

## 1.0.55 - 2026-08-08

- Cart remove: treat empty purchase_option_id as match-any (fixes storefront remove when option omitted).

## 1.0.54 - 2026-08-08

- Tax-included pricing (default): commerce field `tax_included` · extract VAT from shelf prices · `tax_add_cents` for charge totals · catalog_item `tax` estimate · storefront “Tax (included)” label.
- Tax-excluded remains available for US/B2B-style add-on tax; B2B reverse charge strips embedded VAT when prices include tax.

## 1.0.53 - 2026-08-07

- Activity-bus emit: load `plugin_activity.php` only when the helper is not already defined (Events-style), then always call emit.

# Changelog

## 1.0.52 - 2026-08-07

- Harden activity-bus emit: resolve `plugin_activity.php` across CMS root candidates (data-volume installs).
- Notification links use MPA admin URLs (`/admin/?page=commerce#…`) instead of legacy `commerce.html`.

## 1.0.51 - 2026-08-07

- P61: emit shop activity on the Birkly plugin activity bus (bell + sidebar mint dot).
- Settings → General: Admin activity toggles for `activity_notify` and `activity_nav_dot`.
- In-plugin tab badges respect `activity_nav_dot` (cleared when disabled).

## 1.0.50 - 2026-08-04

- Commerce admin UX improve (P57): remove redundant tab-echo section headers; wrap tab panels in `u-stack-6`; adopt core `chip` / `segmented` filters; flatten settings hub nav (core `side-nav--track`); dashboard widgets use core `dashboard-widgets-grid` + `dash-metrics`; orders/fulfillment accordion as one list panel; inventory table-first with Set stock / Transfer as cards; orders search in toolbar; quieter fieldtype cards; dead More-menu JS removed.

## 1.0.49 - 2026-08-04

- P56 a11y/token pass on restored Commerce CSS: no mint text (`--accent-text`), ink on mint fills (`--ink-on-accent`), overlays/shadows use `--overlay` / `--elevation-3`, fix settings-nav `var(--surface)` typo, retire dark `data-theme` patches, cutover error uses danger tokens (no `#fca5a5`).
- Prefer core `.tab-count` chrome for tab badges (drop mint count pills).

## 1.0.48 - 2026-08-04

- Restore Settings → Connections / Activity list host IDs (`payments-connections-list`, `payments-activity-list`) so `payments.js` can render tables again (P57 had replaced both with duplicate `id="table-container"`).
- Add `side-nav--track` on the Settings hub aside so the setup nav stacks vertically under core P56 side-nav rules.

## 1.0.47 - 2026-08-04

- Restore primary Commerce IA from 1.0.45: Dashboard · Orders · Fulfillment · Customers · Catalog · Inventory · Subscriptions · Discounts · Gift Cards · Settings (remove Wave-3 More menu / Catalog-first strip).
- Restore full layout CSS from pre-P57 (`commerce.css` / `payments.css`), then tokenize to P56 tokens (zero hex). Keep core `.tabs` / `.tab` / `.table` / `.side-nav` chrome; keep Tier-1 domain layout (settings hub, inventory editor, analytics, fulfillment, orders accordion, import wizard).
- Default open Dashboard; Inventory label restored (not Stock); Dashboard panel title restored (not Analytics).

## 1.0.46 - 2026-08-04

- Adopt P56 admin design language (Tier 0 compose + Tier 1 domain widgets).
- Replace private `payments-tabs` / `payments-tab` dialect with core `.tabs` / `.tab`.
- Restore Wave 3 Commerce IA: Catalog, Orders, Subscriptions, Stock, Discounts, Analytics, Connections, More.
- Migrate tables, badges, empty states, and settings nav to core `.table`, `.badge`, `.empty-state`, `.side-nav`.
- Shrink `commerce.css` (2717 → ~661 lines) and `payments.css` (250 → ~69 lines); eliminate hardcoded hex.

## 1.0.45 - 2026-08-04

- Free shipping from cart amount threshold.
