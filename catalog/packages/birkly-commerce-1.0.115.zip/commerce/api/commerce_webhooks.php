<?php
/**
 * Public webhook handler for:
 * - Live import inventory (platform=shopify|woocommerce)
 * - EasyPost tracking updates (platform=easypost)
 *
 * EasyPost route: /api/index.php?route=commerce_inventory_webhook&platform=easypost
 */

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../cms_paths.php';
$commerceCmsRoot = commerce_cms_root();
ini_set('error_log', $commerceCmsRoot . '/logs/php_errors.log');

header('Content-Type: application/json');

require_once $commerceCmsRoot . '/core/plugins.php';
load_plugins();

require_once __DIR__ . '/../init.php';

if (!commerce_plugin_active()) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'Commerce plugin is not active']);
    exit;
}

commerce_bootstrap_cart_services();

$platform = strtolower(trim((string) ($_GET['platform'] ?? $_POST['platform'] ?? '')));
$rawBody = (string) file_get_contents('php://input');
$payload = json_decode($rawBody, true);
if (!is_array($payload)) {
    // Allow empty body only for probes; otherwise require JSON.
    if ($rawBody !== '') {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload']);
        exit;
    }
    $payload = [];
}

$headers = function_exists('getallheaders') ? getallheaders() : [];
if (empty($headers)) {
    foreach ($_SERVER as $key => $value) {
        if (strpos($key, 'HTTP_') === 0) {
            $headers[str_replace('_', '-', substr($key, 5))] = $value;
        }
    }
}

if ($platform === 'easypost') {
    require_once __DIR__ . '/../includes/FulfillmentAdapterResolver.php';
    require_once __DIR__ . '/../includes/EasyPostTrackingWebhookService.php';

    $connections = FulfillmentAdapterResolver::loadConnections();
    $secret = trim((string) (($connections['easypost']['webhook_secret'] ?? '') ?: ''));
    $service = new EasyPostTrackingWebhookService();

    if (!$service->verifySignature($rawBody, is_array($headers) ? $headers : [], $secret)) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid webhook signature']);
        exit;
    }

    $result = $service->handleTrackerUpdate($payload);
    http_response_code(($result['ok'] ?? false) ? 200 : 400);
    echo json_encode([
        'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
        'data' => $result,
        'message' => $result['error'] ?? 'Processed',
    ]);
    exit;
}

require_once __DIR__ . '/../includes/CommerceImportCredentialStore.php';
require_once __DIR__ . '/../includes/CommerceInventoryWebhookService.php';

if (!in_array($platform, ['shopify', 'woocommerce'], true)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'platform must be shopify, woocommerce, or easypost']);
    exit;
}

if ($payload === []) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload']);
    exit;
}

$credentials = new CommerceImportCredentialStore();
$config = $credentials->getPlatformConfig($platform, true);
$secret = trim((string) ($config['webhook_secret'] ?? ''));
$service = new CommerceInventoryWebhookService();

$verified = false;
if ($platform === 'shopify') {
    $signature = commerce_inventory_header($headers, 'X-Shopify-Hmac-Sha256');
    $verified = $service->verifyShopifyHmac($rawBody, $signature, $secret);
} else {
    $signature = commerce_inventory_header($headers, 'X-WC-Webhook-Signature');
    $verified = $service->verifyWooSignature($rawBody, $signature, $secret);
}

if (!$verified) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Invalid webhook signature']);
    exit;
}

$result = $platform === 'shopify'
    ? $service->handleShopifyInventoryUpdate($payload)
    : $service->handleWooProductUpdated($payload);

http_response_code(($result['ok'] ?? false) ? 200 : 400);
echo json_encode([
    'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
    'data' => $result,
    'message' => $result['error'] ?? ($result['reason'] ?? 'Processed'),
]);

function commerce_inventory_header(array $headers, string $name): string
{
    $target = strtolower($name);
    foreach ($headers as $key => $value) {
        if (is_int($key)) {
            if (stripos((string) $value, $name . ':') === 0) {
                return trim(substr((string) $value, strlen($name) + 1));
            }
            continue;
        }
        if (strtolower((string) $key) === $target) {
            return is_array($value) ? (string) ($value[0] ?? '') : (string) $value;
        }
    }

    return '';
}
