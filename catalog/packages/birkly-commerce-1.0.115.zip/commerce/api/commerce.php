<?php
/**
 * Commerce API — cart, checkout, catalog, orders, discounts, import, mappings, fulfillment.
 */

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);

require_once __DIR__ . '/../cms_paths.php';
$commerceCmsRoot = commerce_cms_root();

require_once $commerceCmsRoot . '/api/session.php';
haru_secure_session_start();
header('Content-Type: application/json');

require_once $commerceCmsRoot . '/api/auth.php';
require_once $commerceCmsRoot . '/core/csrf.php';
require_once __DIR__ . '/../init.php';

if (!commerce_plugin_active()) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'Commerce plugin is not active']);
    exit;
}

commerce_bootstrap();
commerce_bootstrap_cart_services();

$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
if (stripos($contentType, 'multipart/form-data') === 0) {
    $input = $_POST;
    $action = (string) ($input['action'] ?? $_GET['action'] ?? '');
} else {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = (string) ($input['action'] ?? $_GET['action'] ?? '');
}

$cart = new CommerceCartSession();
$catalog = new CommerceCatalog();
$orders = new CommerceOrderStore();
$checkout = new CommerceCheckoutService($orders, $catalog, $cart);
$indexer = new CatalogIndexer();
$discounts = new DiscountEngine();
$import = new ImportService($indexer);
require_once __DIR__ . '/../includes/LegacyMigrationService.php';
$migration = new LegacyMigrationService($indexer);
require_once __DIR__ . '/../includes/CommerceLiveImportService.php';
$liveImport = new CommerceLiveImportService(null, $import);
$mappings = new PurchaseMappingService();
require_once __DIR__ . '/../includes/CommerceFieldtypeProfileStore.php';
$fieldtypeProfiles = new CommerceFieldtypeProfileStore();
require_once __DIR__ . '/../includes/CommerceSubscriptionStore.php';
require_once __DIR__ . '/../includes/CommerceSubscriptionService.php';
require_once __DIR__ . '/../includes/CommerceCustomerSubscriptionService.php';
require_once __DIR__ . '/../includes/SubscriptionUpgradeService.php';
require_once __DIR__ . '/../includes/CommerceOrderOps.php';
$subscriptionStore = new CommerceSubscriptionStore();
$subscriptions = new CommerceSubscriptionService($subscriptionStore, commerce_bootstrap());
$customerSubscriptions = new CommerceCustomerSubscriptionService($subscriptionStore, $subscriptions);
$orderOps = new CommerceOrderOps($orders, $subscriptionStore);
$subscriptionUpgrades = new SubscriptionUpgradeService($subscriptionStore, commerce_bootstrap(), $catalog);
$giftCards = new GiftCardStore();
$customers = new CommerceCustomerStore();
$quoteStore = new CommerceQuoteStore();
$draftOrders = new CommerceDraftOrderService($quoteStore, $catalog, $discounts, $checkout);
$analytics = new CommerceAnalyticsService($orders);

$publicActions=['get','add','update','remove','clear','checkout','confirm_payment','abandon_checkout','set_coupon','set_affiliate','set_gift_card','set_checkout_draft','catalog_item','begin_linked_checkout','upload_linked_checkout_asset','get_quote','accept_quote','quote_checkout','storefront_config','lookup_order','customer_cancel_order','list_my_subscriptions','get_my_subscription','customer_cancel_subscription','customer_pause_subscription','customer_resume_subscription'];

/**
 * Normalize cart API payload from buildCartLines() + session count.
 * When a shipping address is on the checkout draft (or passed in), re-quotes
 * shipping + tax so the storefront can show a full money breakdown before pay.
 *
 * @param array<string, mixed> $built
 * @param array<string, mixed>|null $shippingAddressOverride
 * @return array<string, mixed>
 */
function commerce_cart_payload(array $built, CommerceCartSession $cart, ?CommerceCatalog $catalog = null, ?array $shippingAddressOverride = null): array
{
    $ok = ($built['ok'] ?? true) !== false;
    $groups = $built['groups'] ?? [];
    $draft = $cart->getCheckoutDraft();
    $shippingAddress = $shippingAddressOverride;
    if ($shippingAddress === null && is_array($draft)) {
        $shippingAddress = is_array($draft['shipping_address'] ?? null) ? $draft['shipping_address'] : null;
    }

    $quoted = $built;
    if ($catalog && $ok && !empty($built['lines'])) {
        $taxContext = [
            'currency' => $built['currency'] ?? null,
            'vat_id' => is_array($draft) ? ($draft['vat_id'] ?? ($draft['tax_id'] ?? null)) : null,
            'tax_id' => is_array($draft) ? ($draft['tax_id'] ?? ($draft['vat_id'] ?? null)) : null,
            'billing_address' => is_array($draft) && is_array($draft['billing_address'] ?? null)
                ? $draft['billing_address']
                : null,
        ];
        $quoted = $catalog->enrichCartMoney($built, $shippingAddress, $taxContext);
    }

    $subtotal = (int) ($quoted['subtotal_cents'] ?? 0);
    if ($subtotal <= 0 && !empty($quoted['lines'])) {
        foreach ($quoted['lines'] as $line) {
            $subtotal += (int) ($line['line_total_cents'] ?? 0);
        }
    }

    return [
        'items' => $quoted['lines'] ?? [],
        'count' => $cart->count(),
        'subtotal_cents' => $subtotal,
        'total_cents' => (int) ($quoted['total_cents'] ?? 0),
        'discount_cents' => (int) ($quoted['discount_cents'] ?? 0),
        'shipping_cents' => (int) ($quoted['shipping_cents'] ?? 0),
        'shipping_lines' => is_array($quoted['shipping_lines'] ?? null) ? $quoted['shipping_lines'] : [],
        'tax_cents' => (int) ($quoted['tax_cents'] ?? 0),
        'tax_add_cents' => (int) ($quoted['tax_add_cents'] ?? $quoted['tax_cents'] ?? 0),
        'tax_lines' => is_array($quoted['tax_lines'] ?? null) ? $quoted['tax_lines'] : [],
        'tax_rate' => (float) ($quoted['tax_rate'] ?? 0),
        'tax_country' => (string) ($quoted['tax_country'] ?? ''),
        'tax_included' => !empty($quoted['tax_included']) || !empty($quoted['prices_include_tax']),
        'prices_include_tax' => !empty($quoted['prices_include_tax']) || !empty($quoted['tax_included']),
        'free_shipping' => !empty($quoted['free_shipping']) || !empty($quoted['free_shipping_unlocked']),
        'free_shipping_min_cents' => (int) ($quoted['free_shipping_min_cents'] ?? 0),
        'free_shipping_remaining_cents' => (int) ($quoted['free_shipping_remaining_cents'] ?? 0),
        'free_shipping_unlocked' => !empty($quoted['free_shipping_unlocked']) || !empty($quoted['free_shipping']),
        'currency' => $quoted['currency'] ?? (function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur'),
        'coupon' => $cart->getCouponCode(),
        'affiliate_id' => $cart->getAffiliateId(),
        'gift_card' => $cart->getGiftCardCode(),
        'ok' => $ok,
        'error' => $quoted['error'] ?? null,
        'checkout_allowed' => (bool) ($quoted['checkout_allowed'] ?? $ok),
        'split_required' => (bool) ($quoted['split_required'] ?? (count($groups) > 1)),
        'groups' => $groups,
        'checkout_session_id' => is_array($draft) ? ($draft['id'] ?? null) : null,
        'checkout_draft' => is_array($draft) ? [
            'email' => $draft['email'] ?? null,
            'shipping_address' => $draft['shipping_address'] ?? null,
            'attendee_name' => $draft['attendee_name'] ?? null,
            'vat_id' => $draft['vat_id'] ?? ($draft['tax_id'] ?? null),
            'remaining_group_keys' => $draft['remaining_group_keys'] ?? [],
        ] : null,
        'warnings' => $quoted['warnings'] ?? [],
    ];
}

require_once __DIR__ . '/../includes/CommerceInventoryLedger.php';

/**
 * @return array{id: ?string, email: ?string, name: string, label: string}
 */
function commerce_admin_actor(): array
{
    $user = $_SESSION['user'] ?? [];
    if (!is_array($user)) {
        $user = [];
    }
    $id = trim((string) ($user['id'] ?? ''));
    $email = trim((string) ($user['email'] ?? ''));
    $name = trim((string) ($user['name'] ?? $user['display_name'] ?? ''));
    if ($name === '') {
        if ($email !== '') {
            $name = explode('@', $email)[0];
        } elseif ($id !== '') {
            $name = $id;
        } else {
            $name = 'Admin';
        }
    }
    $label = $name;
    if ($email !== '' && strcasecmp($name, $email) !== 0) {
        $label = $name . ' (' . $email . ')';
    }
    return [
        'id' => $id !== '' ? $id : null,
        'email' => $email !== '' ? $email : null,
        'name' => $name,
        'label' => $label,
    ];
}

$adminActions = [
    'list_catalog', 'reindex_catalog', 'rebuild_catalog', 'reconcile_inventory', 'save_stock_mode',
    'list_orders', 'get_order', 'delete_orders', 'refund_order', 'cancel_order', 'update_order_shipment', 'create_shipment',
    'add_order_note', 'set_order_tags', 'bulk_mark_shipped', 'customer_timeline', 'export_orders_csv',
    'order_invoice', 'issue_invoice', 'packing_slips', 'list_fulfillment_desk',
    'get_invoice_profile', 'save_invoice_profile', 'preview_invoice',
    'list_invoice_templates', 'save_invoice_template', 'duplicate_invoice_template', 'delete_invoice_template',
    'list_email_templates', 'save_email_template', 'save_email_delivery_settings', 'preview_email_template', 'send_test_email', 'list_email_log',
    'list_scheduled_emails', 'process_scheduled_emails',
    'sync_order_payment', 'resend_order_email', 'reconcile_pending_payments', 'activity_counts',
    'list_subscriptions', 'get_subscription', 'cancel_subscription', 'pause_subscription', 'resume_subscription', 'upgrade_subscription',
    'list_subscription_upgrade_options', 'retry_subscription_payment',
    'list_customers', 'get_customer', 'save_customer', 'import_customers_csv', 'delete_customer',
    'list_discounts', 'save_discount', 'delete_discount',
    'import_dry_run', 'import_csv', 'import_sources', 'import_history', 'import_detail', 'import_collections', 'import_rollback',
    'import_live_config', 'import_live_save', 'import_live_test', 'import_live_preview', 'import_live_sync',
    'shopify_cutover_test', 'shopify_cutover_dry_run', 'shopify_cutover_import', 'shopify_cutover_rollback',
    'list_mappings', 'save_mapping', 'delete_mapping', 'create_membership_mapping', 'mapping_wizard_data', 'list_membership_tiers',
    'list_fulfillment', 'test_fulfillment', 'save_fulfillment',
    'list_shipping_zones', 'save_shipping_zones', 'list_shipping_rate_providers',
    'list_tax_rules', 'save_tax_rules', 'list_tax_providers',
    'list_fieldtype_profiles', 'save_fieldtype_profile', 'delete_fieldtype_profile',
    'migration_scan', 'migration_preview', 'migration_import', 'migration_history', 'migration_rollback',
    'list_gift_cards', 'issue_gift_card', 'void_gift_card', 'create_quote', 'list_quotes', 'cancel_quote', 'get_quote_admin',
    'draft_order_create', 'draft_order_update', 'draft_order_preview', 'draft_order_get', 'draft_order_search_catalog', 'draft_order_checkout',
    'list_warehouse_stock', 'save_warehouse_stock',
    'list_warehouses', 'save_warehouse', 'delete_warehouse', 'transfer_warehouse_stock',
    'bundle_validate', 'bundle_preview_price',
    'get_inventory_webhook_config', 'rotate_inventory_webhook_secret',
];
$statsActions=['analytics_summary','analytics_export_csv'];

if (in_array($action, $adminActions, true)) {
    commerce_require_admin_capability('manage_commerce');
}
if (in_array($action, $statsActions, true)) {
    commerce_require_stats_capability();
}

if (in_array($action, ['save_discount', 'delete_discount', 'import_csv', 'import_rollback', 'import_live_save', 'import_live_sync', 'migration_import', 'migration_rollback', 'save_mapping', 'delete_mapping', 'create_membership_mapping', 'save_fulfillment', 'save_shipping_zones', 'save_tax_rules', 'refund_order', 'cancel_order', 'delete_orders', 'update_order_shipment', 'create_shipment', 'add_order_note', 'set_order_tags', 'bulk_mark_shipped', 'export_orders_csv', 'order_invoice', 'issue_invoice', 'packing_slips', 'save_invoice_profile', 'save_invoice_template', 'duplicate_invoice_template', 'delete_invoice_template', 'save_email_template', 'send_test_email', 'process_scheduled_emails', 'sync_order_payment', 'resend_order_email', 'reconcile_pending_payments', 'save_fieldtype_profile', 'delete_fieldtype_profile', 'cancel_subscription', 'pause_subscription', 'resume_subscription', 'upgrade_subscription', 'retry_subscription_payment', 'issue_gift_card', 'void_gift_card', 'create_quote', 'cancel_quote', 'draft_order_create', 'draft_order_update', 'draft_order_checkout', 'save_warehouse_stock', 'save_warehouse', 'delete_warehouse', 'transfer_warehouse_stock', 'save_stock_mode', 'rebuild_catalog', 'reconcile_inventory', 'rotate_inventory_webhook_secret', 'save_customer', 'import_customers_csv', 'delete_customer', 'shopify_cutover_import', 'shopify_cutover_rollback'], true)
    && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $input['_csrf'] ?? $_POST['_csrf'] ?? '';
    if (!validate_csrf_token($csrf)) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
        exit;
    }
}

switch ($action) {
    case 'set_affiliate':
        $ref = $input['ref'] ?? $_GET['ref'] ?? '';
        $cart->setAffiliateId($ref !== '' ? $ref : null);
        echo json_encode(['status' => 'ok', 'affiliate_id' => $cart->getAffiliateId()]);
        break;

    case 'set_coupon':
        $code = $input['code'] ?? $_GET['code'] ?? '';
        $cart->setCouponCode($code !== '' ? $code : null);
        echo json_encode(['status' => 'ok', 'coupon' => $cart->getCouponCode()]);
        break;

    case 'set_gift_card':
        $gc = $input['code'] ?? $_GET['code'] ?? '';
        $cart->setGiftCardCode($gc !== '' ? $gc : null);
        echo json_encode(['status' => 'ok', 'gift_card' => $cart->getGiftCardCode()]);
        break;

    case 'get':
        $built = $catalog->buildCartLines(
            $cart->getItems(),
            $discounts,
            $cart->getCouponCode(),
            $cart->getAffiliateId()
        );
        $payload = commerce_cart_payload($built, $cart, $catalog);
        // Always status=ok for reads; business conflicts are in data.ok / data.error.
        echo json_encode([
            'status' => 'ok',
            'message' => $payload['error'] ?? null,
            'data' => $payload,
        ]);
        break;

    case 'add':
        $entryId = $input['entry_id'] ?? $_GET['entry_id'] ?? '';
        $collection = $input['collection'] ?? $_GET['collection'] ?? '';
        $qty = (int) ($input['quantity'] ?? $_GET['quantity'] ?? 1);
        $purchaseOptionId = $input['purchase_option_id'] ?? $_GET['purchase_option_id'] ?? null;
        $parentId = $input['parent_id'] ?? $_GET['parent_id'] ?? null;
        $amountRaw = $input['amount_cents'] ?? $_GET['amount_cents'] ?? null;
        $amountCents = ($amountRaw === null || $amountRaw === '') ? null : max(0, (int) $amountRaw);
        if ($entryId === '' || $collection === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'entry_id and collection required']);
            break;
        }
        if (!$catalog->getItem($collection, $entryId)) {
            $resolved = $catalog->resolveItem($collection, $entryId);
            if ($resolved !== null) {
                $entryId = (string) ($resolved['entry_id'] ?? $entryId);
            }
            if (!$catalog->getItem($collection, $entryId)) {
                http_response_code(404);
                echo json_encode(['status' => 'error', 'message' => 'Item not in catalog']);
                break;
            }
        }
        // Snapshot first so incompatible mixes (one-time + subscription) can be rolled back.
        $previousItems = $cart->getItems();
        $cart->addItem($collection, $entryId, $qty, $purchaseOptionId, $parentId, $amountCents);
        $built = $catalog->buildCartLines($cart->getItems(), $discounts, $cart->getCouponCode(), $cart->getAffiliateId());
        if (($built['ok'] ?? true) === false) {
            $cart->setItems($previousItems);
            $restored = $catalog->buildCartLines(
                $cart->getItems(),
                $discounts,
                $cart->getCouponCode(),
                $cart->getAffiliateId()
            );
            http_response_code(409);
            echo json_encode([
                'status' => 'error',
                'message' => $built['error'] ?? 'Cannot add this item to the current cart',
                'data' => commerce_cart_payload($restored, $cart, $catalog),
            ]);
            break;
        }
        // Persist resolved purchase_option_id on session rows (Add often omits it; cart UI shows the default).
        $sessionItems = $cart->getItems();
        $dirty = false;
        foreach ($sessionItems as &$sessionItem) {
            if (!empty($sessionItem['purchase_option_id'])) {
                continue;
            }
            foreach (($built['lines'] ?? []) as $line) {
                if (($line['entry_id'] ?? '') === ($sessionItem['entry_id'] ?? '')
                    && (($line['collection_slug'] ?? '') === ($sessionItem['collection'] ?? ''))
                    && !empty($line['purchase_option_id'])
                ) {
                    $sessionItem['purchase_option_id'] = $line['purchase_option_id'];
                    $dirty = true;
                    break;
                }
            }
        }
        unset($sessionItem);
        if ($dirty) {
            $cart->setItems($sessionItems);
        }
        echo json_encode([
            'status' => 'ok',
            'data' => commerce_cart_payload($built, $cart, $catalog),
        ]);
        break;

    case 'update':
        $entryId = $input['entry_id'] ?? '';
        $collection = $input['collection'] ?? '';
        $qty = (int) ($input['quantity'] ?? 0);
        $purchaseOptionId = $input['purchase_option_id'] ?? null;
        if ($entryId === '' || $collection === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'entry_id and collection required']);
            break;
        }
        $cart->updateItem($collection, $entryId, $qty, $purchaseOptionId);
        $built = $catalog->buildCartLines($cart->getItems(), $discounts, $cart->getCouponCode(), $cart->getAffiliateId());
        $payload = commerce_cart_payload($built, $cart, $catalog);
        echo json_encode([
            'status' => 'ok',
            'message' => $payload['error'] ?? null,
            'data' => $payload,
        ]);
        break;

    case 'remove':
        $entryId = $input['entry_id'] ?? $_GET['entry_id'] ?? '';
        $collection = $input['collection'] ?? $_GET['collection'] ?? '';
        $purchaseOptionId = $input['purchase_option_id'] ?? $_GET['purchase_option_id'] ?? null;
        if ($purchaseOptionId === '') {
            $purchaseOptionId = null;
        }
        $cart->removeItem((string) $collection, (string) $entryId, $purchaseOptionId);
        $built = $catalog->buildCartLines($cart->getItems(), $discounts, $cart->getCouponCode(), $cart->getAffiliateId());
        $payload = commerce_cart_payload($built, $cart, $catalog);
        echo json_encode([
            'status' => 'ok',
            'message' => $payload['error'] ?? null,
            'data' => $payload,
        ]);
        break;

    case 'clear':
        $cart->clear();
        echo json_encode([
            'status' => 'ok',
            'data' => commerce_cart_payload([
                'ok' => true,
                'lines' => [],
                'total_cents' => 0,
                'discount_cents' => 0,
                'shipping_cents' => 0,
                'tax_cents' => 0,
                'currency' => function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur',
                'checkout_allowed' => true,
                'warnings' => [],
            ], $cart, $catalog),
        ]);
        break;

    case 'set_checkout_draft':
        $draft = $cart->getCheckoutDraft();
        if (!is_array($draft)) {
            $draft = ['id' => 'cd_' . bin2hex(random_bytes(6))];
        }
        if (array_key_exists('email', $input)) {
            $draft['email'] = trim((string) $input['email']);
        }
        if (array_key_exists('customer_name', $input)) {
            $draft['customer_name'] = trim((string) $input['customer_name']);
        } elseif (array_key_exists('name', $input)) {
            $draft['customer_name'] = trim((string) $input['name']);
        }
        if (array_key_exists('metadata', $input) && is_array($input['metadata'])) {
            $prev = is_array($draft['metadata'] ?? null) ? $draft['metadata'] : [];
            $draft['metadata'] = array_merge($prev, $input['metadata']);
        }
        if (array_key_exists('attendee_name', $input)) {
            $draft['attendee_name'] = $input['attendee_name'];
        }
        if (array_key_exists('shipping_address', $input)) {
            $addr = $input['shipping_address'];
            $draft['shipping_address'] = is_array($addr) ? $addr : null;
        }
        if (array_key_exists('billing_address', $input)) {
            $bill = $input['billing_address'];
            $draft['billing_address'] = is_array($bill) ? $bill : null;
        }
        if (array_key_exists('vat_id', $input) || array_key_exists('tax_id', $input)) {
            $vat = trim((string) ($input['vat_id'] ?? ($input['tax_id'] ?? '')));
            $draft['vat_id'] = $vat !== '' ? $vat : null;
            $draft['tax_id'] = $draft['vat_id'];
        }
        $cart->setCheckoutDraft($draft);
        $built = $catalog->buildCartLines(
            $cart->getItems(),
            $discounts,
            $cart->getCouponCode(),
            $cart->getAffiliateId()
        );
        $payload = commerce_cart_payload($built, $cart, $catalog);
        echo json_encode([
            'status' => 'ok',
            'message' => $payload['error'] ?? null,
            'data' => $payload,
        ]);
        break;

    case 'catalog_item':
        $entryId = trim((string) ($input['entry_id'] ?? $_GET['entry_id'] ?? ''));
        $collection = trim((string) ($input['collection'] ?? $_GET['collection'] ?? ''));
        if ($entryId === '' || $collection === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'entry_id and collection required']);
            break;
        }
        $item = $catalog->resolveItem($collection, $entryId);
        if (!$item) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Item not in catalog']);
            break;
        }
        $entryId = (string) ($item['entry_id'] ?? $entryId);
        $country = trim((string) ($input['country'] ?? $_GET['country'] ?? ''));
        $shippingAddress = $country !== '' ? ['country' => strtoupper($country)] : null;
        $optionId = trim((string) ($input['purchase_option_id'] ?? $_GET['purchase_option_id'] ?? ''));
        $amountOverride = isset($input['amount_cents'])
            ? (int) $input['amount_cents']
            : (isset($_GET['amount_cents']) ? (int) $_GET['amount_cents'] : null);
        $taxEstimate = $catalog->estimateItemTax($item, $shippingAddress, array_filter([
            'purchase_option_id' => $optionId !== '' ? $optionId : null,
            'amount_cents' => $amountOverride,
        ], static fn ($v) => $v !== null));
        $commerce = function_exists('commerce_normalize_value')
            ? commerce_normalize_value($item['commerce'] ?? $item)
            : ($item['commerce'] ?? []);
        $rawOptions = $item['purchase_options'] ?? ($commerce['purchase_options'] ?? []);
        $purchaseOptions = class_exists('CommerceSchema')
            ? CommerceSchema::enrichPurchaseOptionsForStorefront(is_array($rawOptions) ? $rawOptions : [])
            : (is_array($rawOptions) ? $rawOptions : []);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'entry_id' => $item['entry_id'] ?? $entryId,
                'collection_slug' => $item['collection_slug'] ?? $collection,
                'sku' => $item['sku'] ?? null,
                'title' => $item['entry_title'] ?? ($item['title'] ?? null),
                'quantity_available' => array_key_exists('quantity_available', $item) ? $item['quantity_available'] : null,
                'currency' => $item['currency'] ?? (function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur'),
                'fulfillment' => $item['fulfillment'] ?? null,
                'tax_class' => $taxEstimate['tax_class'] ?? ($commerce['tax_class'] ?? 'standard'),
                'tax_included' => !empty($taxEstimate['tax_included']),
                'prices_include_tax' => !empty($taxEstimate['prices_include_tax']),
                'purchase_options' => $purchaseOptions,
                'tax' => $taxEstimate,
            ],
        ]);
        break;

    case 'begin_linked_checkout':
        require_once __DIR__ . '/../includes/CommerceLinkedCheckoutService.php';
        $linkedCheckout = new CommerceLinkedCheckoutService($cart, $catalog, $checkout);
        $result = $linkedCheckout->begin($input);
        echo json_encode([
            'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
            'message' => $result['error'] ?? null,
            'data' => $result,
        ]);
        break;

    case 'upload_linked_checkout_asset':
        require_once __DIR__ . '/../includes/CommerceLinkedCheckoutAssetUpload.php';
        $uploader = new CommerceLinkedCheckoutAssetUpload();
        $field = (string) ($input['field'] ?? 'file');
        $file = is_array($_FILES['file'] ?? null) ? $_FILES['file'] : [];
        $result = $uploader->upload($file, $field);
        echo json_encode([
            'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
            'message' => $result['error'] ?? null,
            'data' => $result,
        ]);
        break;

    case 'storefront_config':
        $pluginJson = [];
        $pluginJsonPath = dirname(__DIR__) . '/plugin.json';
        if (is_file($pluginJsonPath)) {
            $decoded = json_decode((string) file_get_contents($pluginJsonPath), true);
            if (is_array($decoded)) {
                $pluginJson = $decoded;
            }
        }
        $taxRules = $catalog->loadTaxRules();
        $b2b = is_array($taxRules['b2b_reverse_charge'] ?? null) ? $taxRules['b2b_reverse_charge'] : [];
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'plugin_version' => (string) ($pluginJson['version'] ?? ''),
                'api_route' => '/api/index.php?route=commerce',
                'storefront_script' => '/plugins/commerce/assets/commerce-storefront.js',
                'recurring_billing_enabled' => class_exists('CommerceSchema')
                    ? CommerceSchema::recurringBillingEnabled()
                    : true,
                'split_checkout' => true,
                'public_actions' => $publicActions,
                'currency' => function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur',
                'tax_enabled' => !empty($taxRules['enabled']),
                'b2b_reverse_charge_enabled' => !empty($b2b['enabled']),
                'customer_cancel' => class_exists('CommerceCheckoutService')
                    ? CommerceCheckoutService::customerCancelPolicy()
                    : ['enabled' => false, 'window_hours' => 24],
                'customer_subscriptions' => class_exists('CommerceCustomerSubscriptionService')
                    ? CommerceCustomerSubscriptionService::selfServicePolicy()
                    : ['enabled' => false, 'allow_pause' => false, 'allow_cancel' => false],
            ],
        ]);
        break;

    case 'lookup_order':
        $email = (string) ($input['email'] ?? $_GET['email'] ?? '');
        $orderRef = (string) ($input['order_number'] ?? $input['order_id'] ?? $input['id'] ?? $_GET['order_number'] ?? $_GET['id'] ?? '');
        $result = $checkout->lookupOrderForCustomer($email, $orderRef);
        if (!($result['ok'] ?? false)) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Order not found']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'customer_cancel_order':
        $email = (string) ($input['email'] ?? '');
        $orderRef = (string) ($input['order_number'] ?? $input['order_id'] ?? $input['id'] ?? '');
        $reason = (string) ($input['reason'] ?? '');
        $result = $checkout->customerCancelOrder($email, $orderRef, $reason);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Cancel failed']);
            break;
        }
        $lookup = $checkout->lookupOrderForCustomer(
            $email,
            (string) (($result['order']['id'] ?? '') ?: $orderRef)
        );
        echo json_encode(['status' => 'ok', 'data' => [
            'order' => $lookup['order'] ?? [
                'id' => $result['order']['id'] ?? '',
                'status' => 'canceled',
                'can_cancel' => false,
            ],
            'refund' => $result['refund'] ?? null,
        ]]);
        break;

    case 'list_my_subscriptions':
        $result = $customerSubscriptions->listForCustomer();
        if (!($result['ok'] ?? false)) {
            $code = (($result['error'] ?? '') === 'Sign in required') ? 401 : 400;
            http_response_code($code);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'get_my_subscription':
        $id = (string) ($input['id'] ?? $_GET['id'] ?? '');
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $customerSubscriptions->getForCustomer($id);
        if (!($result['ok'] ?? false)) {
            $code = (($result['error'] ?? '') === 'Sign in required') ? 401 : 404;
            http_response_code($code);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Not found']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'customer_cancel_subscription':
        $id = (string) ($input['id'] ?? '');
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $customerSubscriptions->cancelForCustomer($id);
        if (!($result['ok'] ?? false)) {
            $code = (($result['error'] ?? '') === 'Sign in required') ? 401 : 400;
            http_response_code($code);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Cancel failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'customer_pause_subscription':
        $id = (string) ($input['id'] ?? '');
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $customerSubscriptions->pauseForCustomer($id);
        if (!($result['ok'] ?? false)) {
            $code = (($result['error'] ?? '') === 'Sign in required') ? 401 : 400;
            http_response_code($code);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Pause failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'customer_resume_subscription':
        $id = (string) ($input['id'] ?? '');
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $customerSubscriptions->resumeForCustomer($id);
        if (!($result['ok'] ?? false)) {
            $code = (($result['error'] ?? '') === 'Sign in required') ? 401 : 400;
            http_response_code($code);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Resume failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'checkout':
        $email = $input['email'] ?? $input['customer_email'] ?? $_GET['email'] ?? '';
        $returnUrl = $input['return_url'] ?? $input['success_url'] ?? '';
        $cancelUrl = $input['cancel_url'] ?? '';
        $checkoutData = [
            'shipping_address' => $input['shipping_address'] ?? null,
            'billing_address' => $input['billing_address'] ?? null,
            'attendee_name' => $input['attendee_name'] ?? null,
            'vat_id' => $input['vat_id'] ?? ($input['tax_id'] ?? null),
            'tax_id' => $input['tax_id'] ?? ($input['vat_id'] ?? null),
            'group_key' => $input['group_key'] ?? $_GET['group_key'] ?? null,
            'checkout_session_id' => $input['checkout_session_id'] ?? $_GET['checkout_session_id'] ?? null,
            'shipping_rate_id' => $input['shipping_rate_id'] ?? ($input['selected_shipping_rate_id'] ?? null),
            'customer_email' => $email,
            // Donate / simple storefronts opt into Stripe hosted Checkout (redirect_url).
            'hosted_checkout' => !empty($input['hosted_checkout']) || !empty($input['success_url']),
        ];
        $result = $checkout->checkout((string) $email, (string) $returnUrl, (string) $cancelUrl, $checkoutData);
        echo json_encode(['status' => ($result['ok'] ?? false) ? 'ok' : 'error', 'data' => $result]);
        break;

    case 'abandon_checkout':
        $orderId = trim((string) ($input['order_id'] ?? $_GET['order_id'] ?? ''));
        if ($orderId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'order_id required']);
            break;
        }
        $email = $input['email'] ?? $_GET['email'] ?? null;
        $email = is_string($email) && trim($email) !== '' ? trim($email) : null;
        $result = $checkout->abandonCheckoutOrder($orderId, $email);
        echo json_encode([
            'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
            'message' => $result['error'] ?? null,
            'data' => $result,
        ]);
        break;

    case 'confirm_payment':
        $paymentId = (string) ($input['payment_id'] ?? $_GET['payment_id'] ?? '');
        $result = $checkout->confirmLocalPayment($paymentId);
        echo json_encode([
            'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
            'message' => $result['error'] ?? null,
            'data' => $result,
        ]);
        break;

    case 'sync_order_payment':
        $orderId = (string) ($input['id'] ?? $input['order_id'] ?? '');
        if ($orderId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $checkout->syncOrderPayment($orderId);
        echo json_encode([
            'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
            'message' => $result['error'] ?? null,
            'data' => $result,
        ]);
        break;

    case 'resend_order_email':
        $orderId = (string) ($input['id'] ?? $input['order_id'] ?? '');
        if ($orderId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $checkout->resendOrderReceipt($orderId);
        echo json_encode([
            'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
            'message' => $result['error'] ?? null,
            'data' => $result,
        ]);
        break;

    case 'reconcile_pending_payments':
        $limit = (int) ($input['limit'] ?? 25);
        $result = $checkout->reconcilePendingPayments($limit);
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'activity_counts':
        $ordersSeenAt = (string) ($input['orders_seen_at'] ?? $_GET['orders_seen_at'] ?? '');
        $subsSeenAt = (string) ($input['subscriptions_seen_at'] ?? $_GET['subscriptions_seen_at'] ?? '');
        $ordersSeenTs = $ordersSeenAt !== '' ? strtotime($ordersSeenAt) : false;
        $subsSeenTs = $subsSeenAt !== '' ? strtotime($subsSeenAt) : false;
        $ordersNew = 0;
        $ordersPending = 0;
        foreach ($orders->listAll() as $order) {
            $status = (string) ($order['status'] ?? '');
            if ($status === 'abandoned' || $status === 'failed' || $status === 'canceled') {
                continue;
            }
            if ($status === 'pending') {
                $ordersPending++;
            }
            $createdTs = strtotime((string) ($order['created_at'] ?? '')) ?: 0;
            if ($ordersSeenTs === false) {
                if ($status === 'pending' || $status === 'paid') {
                    // Unseen pending/paid since last visit — prefer pending as the urgent signal.
                    if ($status === 'pending') {
                        $ordersNew++;
                    }
                }
            } elseif ($createdTs > $ordersSeenTs) {
                $ordersNew++;
            }
        }
        $subsNew = 0;
        $subsTotal = 0;
        foreach ($subscriptionStore->listAll() as $sub) {
            $subsTotal++;
            $createdTs = strtotime((string) ($sub['created_at'] ?? '')) ?: 0;
            if ($subsSeenTs === false) {
                if (($sub['status'] ?? '') === 'active') {
                    $subsNew++;
                }
            } elseif ($createdTs > $subsSeenTs) {
                $subsNew++;
            }
        }
        $fulfillmentOpen = 0;
        foreach ($orders->listAll() as $order) {
            if (!is_array($order)) {
                continue;
            }
            $enriched = $orderOps->enrichOrder($order);
            if (!empty($enriched['has_open_fulfillment_work'])) {
                $fulfillmentOpen++;
            }
        }
        $activityNavDot = true;
        if (function_exists('get_plugin_setting')) {
            $activityNavDot = (bool) get_plugin_setting(
                function_exists('commerce_active_plugin_id') ? commerce_active_plugin_id() : 'commerce',
                'activity_nav_dot',
                true
            );
        } elseif (function_exists('commerce_get_setting')) {
            $raw = commerce_get_setting('activity_nav_dot', true);
            $activityNavDot = $raw === null ? true : !empty($raw);
        }
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'orders_new' => $ordersNew,
                'orders_pending' => $ordersPending,
                'subscriptions_new' => $subsNew,
                'subscriptions_total' => $subsTotal,
                'fulfillment_open' => $fulfillmentOpen,
                'activity_nav_dot' => $activityNavDot,
            ],
        ]);
        break;

    case 'list_catalog':
        $filters = $input['filters'] ?? [];
        echo json_encode(['status' => 'ok', 'data' => ['catalog' => $catalog->listItems($filters)]]);
        break;

    case 'reindex_catalog':
    case 'rebuild_catalog':
        $count = $indexer->reindexAll();
        $report = commerce_inventory_ledger($indexer)->reconcile(true);
        echo json_encode(['status' => 'ok', 'data' => ['indexed' => $count, 'inventory' => $report]]);
        break;

    case 'save_stock_mode':
        $mode = InventoryLedger::saveMode((string) ($input['mode'] ?? 'simple'));
        $report = commerce_inventory_ledger($indexer)->reconcile(true);
        echo json_encode(['status' => 'ok', 'data' => ['mode' => $mode, 'inventory' => $report]]);
        break;

    case 'reconcile_inventory':
        $apply = !empty($input['apply']) || !empty($_GET['apply']);
        echo json_encode(['status' => 'ok', 'data' => commerce_inventory_ledger($indexer)->reconcile($apply)]);
        break;

    case 'list_orders':
        // Auto-reconcile pending payments so the admin never needs a manual Sync button.
        // Succeeded charges become paid; unfinished Stripe intents / duplicates become abandoned.
        $reconcile = $checkout->reconcilePendingPayments(50);
        $orders->ensureOrderNumbers();
        $includeAbandoned = !empty($input['include_abandoned']) || (($_GET['include_abandoned'] ?? '') === '1');
        $allOrders = $orders->listAll();
        if (!$includeAbandoned) {
            $allOrders = array_values(array_filter($allOrders, static function ($order) {
                return ($order['status'] ?? '') !== 'abandoned';
            }));
        }
        $allOrders = array_map(static function ($order) use ($orderOps) {
            return $orderOps->enrichOrder($order);
        }, $allOrders);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'orders' => $allOrders,
                'reconcile' => $reconcile,
            ],
        ]);
        break;

    case 'delete_orders':
        $ids = $input['ids'] ?? [];
        if (!is_array($ids)) {
            $ids = [];
        }
        $ids = array_values(array_unique(array_filter(array_map('strval', $ids))));
        $purgeStatus = trim((string) ($input['purge_status'] ?? ''));
        $purgeable = ['abandoned', 'canceled', 'failed'];
        if ($purgeStatus !== '' && !in_array($purgeStatus, $purgeable, true)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'purge_status must be abandoned, canceled, or failed']);
            break;
        }
        if ($purgeStatus !== '') {
            foreach ($orders->listAll() as $order) {
                if (($order['status'] ?? '') === $purgeStatus) {
                    $ids[] = (string) ($order['id'] ?? '');
                }
            }
            $ids = array_values(array_unique(array_filter($ids)));
        }
        if (!$ids) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'ids or purge_status required']);
            break;
        }
        $deleted = [];
        $errors = [];
        foreach ($ids as $id) {
            $order = $orders->get($id);
            if (!$order) {
                $errors[] = $id . ': not found';
                continue;
            }
            $status = (string) ($order['status'] ?? '');
            if (!in_array($status, $purgeable, true)) {
                $errors[] = $id . ': only abandoned, canceled, or failed orders can be deleted';
                continue;
            }
            if ($orders->delete($id)) {
                $deleted[] = $id;
            } else {
                $errors[] = $id . ': delete failed';
            }
        }
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'deleted' => $deleted,
                'deleted_count' => count($deleted),
                'errors' => $errors,
            ],
        ]);
        break;

    case 'get_order':
        $id = $input['id'] ?? $_GET['id'] ?? '';
        $order = $orders->get($id);
        if (!$order) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Order not found']);
            break;
        }
        if (empty($order['order_number'])) {
            $number = $orders->allocateOrderNumber($order['created_at'] ?? null);
            $order = $orders->update($id, ['order_number' => $number]) ?? $order;
        }
        echo json_encode(['status' => 'ok', 'data' => ['order' => $orderOps->enrichOrder($order)]]);
        break;

    case 'update_order_shipment':
        $id = (string) ($input['id'] ?? '');
        $lineId = (string) ($input['line_id'] ?? '');
        if ($id === '' || $lineId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id and line_id required']);
            break;
        }
        $result = $orderOps->createShipment($id, [
            'line_id' => $lineId,
            'tracking_number' => (string) ($input['tracking_number'] ?? ''),
            'carrier' => (string) ($input['carrier'] ?? ''),
            'shipped_at' => isset($input['shipped_at']) ? (string) $input['shipped_at'] : null,
            'notify_customer' => !empty($input['notify_customer']),
            'package_count' => (int) ($input['package_count'] ?? 1),
            'items' => is_array($input['items'] ?? null) ? $input['items'] : null,
        ]);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Shipment update failed']);
            break;
        }
        if (!empty($result['order'])) {
            $result['order'] = $orderOps->enrichOrder($result['order']);
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'list_fulfillment_desk':
        $desk = $orderOps->listFulfillmentDesk(
            (string) ($input['view'] ?? $_GET['view'] ?? 'open'),
            (string) ($input['search'] ?? $_GET['search'] ?? ''),
            commerce_admin_actor()
        );
        echo json_encode(['status' => 'ok', 'data' => $desk]);
        break;

    case 'create_shipment':
        $id = (string) ($input['id'] ?? '');
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $orderOps->createShipment($id, [
            'items' => is_array($input['items'] ?? null) ? $input['items'] : [],
            'tracking_number' => (string) ($input['tracking_number'] ?? ''),
            'carrier' => (string) ($input['carrier'] ?? ''),
            'package_count' => (int) ($input['package_count'] ?? 1),
            'notify_customer' => !empty($input['notify_customer']),
            'shipped_at' => isset($input['shipped_at']) ? (string) $input['shipped_at'] : null,
            'acted_by' => commerce_admin_actor(),
        ]);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Shipment failed']);
            break;
        }
        if (!empty($result['order'])) {
            $result['order'] = $orderOps->enrichOrder($result['order']);
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'add_order_note':
        $id = (string) ($input['id'] ?? '');
        $actor = commerce_admin_actor();
        $author = (string) ($input['author'] ?? '');
        if ($author === '') {
            $author = $actor['label'];
        }
        $result = $orderOps->addNote($id, (string) ($input['body'] ?? ''), $author, $actor);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Failed to add note']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['order' => $orderOps->enrichOrder($result['order'] ?? [])]]);
        break;

    case 'set_order_tags':
        $id = (string) ($input['id'] ?? '');
        $tags = $input['tags'] ?? [];
        if (!is_array($tags) && is_string($tags)) {
            $tags = array_map('trim', explode(',', $tags));
        }
        if (!is_array($tags)) {
            $tags = [];
        }
        $result = $orderOps->setTags($id, $tags);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Failed to set tags']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['order' => $orderOps->enrichOrder($result['order'] ?? [])]]);
        break;

    case 'bulk_mark_shipped':
        $ids = $input['ids'] ?? [];
        if (!is_array($ids) || !$ids) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'ids required']);
            break;
        }
        $result = $orderOps->bulkMarkShipped(
            $ids,
            (string) ($input['carrier'] ?? ''),
            (string) ($input['tracking_prefix'] ?? ''),
            !empty($input['notify_customer']),
            commerce_admin_actor()
        );
        $result['updated'] = array_map(static function ($order) use ($orderOps) {
            return $orderOps->enrichOrder($order);
        }, $result['updated'] ?? []);
        echo json_encode(['status' => ($result['ok'] ?? false) ? 'ok' : 'error', 'data' => $result, 'message' => empty($result['updated']) ? 'No orders updated' : null]);
        break;

    case 'customer_timeline':
        $email = (string) ($input['email'] ?? $_GET['email'] ?? '');
        $timeline = $orderOps->customerTimeline($email, $customers);
        $timeline['orders'] = array_map(static function ($order) use ($orderOps) {
            return $orderOps->enrichOrder($order);
        }, $timeline['orders'] ?? []);
        if (!empty($timeline['customer']) && is_array($timeline['customer'])) {
            $timeline['user_management'] = $customers->resolveUserManagementLink($timeline['customer']);
        } else {
            $timeline['user_management'] = [
                'user_id' => null,
                'user_name' => null,
                'user_email' => null,
                'admin_url' => null,
                'active' => function_exists('birkly_is_plugin_active') && birkly_is_plugin_active('user_management'),
            ];
        }
        echo json_encode(['status' => 'ok', 'data' => $timeline]);
        break;

    case 'list_customers':
        $search = (string) ($input['search'] ?? $_GET['search'] ?? '');
        $backfill = [];
        if ($customers->count() === 0) {
            $backfill = $customers->backfillFromOrders($orders, false);
        }
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'customers' => $customers->list($search),
                'backfill' => $backfill,
            ],
        ]);
        break;

    case 'get_customer':
        $id = (string) ($input['id'] ?? $_GET['id'] ?? '');
        $email = (string) ($input['email'] ?? $_GET['email'] ?? '');
        $customer = $id !== '' ? $customers->getById($id) : null;
        if (!$customer && $email !== '') {
            $customer = $customers->getByEmail($email);
        }
        if (!$customer) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Customer not found']);
            break;
        }
        $timeline = $orderOps->customerTimeline((string) $customer['email'], $customers);
        $timeline['orders'] = array_map(static function ($order) use ($orderOps) {
            return $orderOps->enrichOrder($order);
        }, $timeline['orders'] ?? []);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'customer' => $customer,
                'timeline' => $timeline,
                'user_management' => $customers->resolveUserManagementLink($customer),
            ],
        ]);
        break;

    case 'save_customer':
        try {
            $payload = $input['customer'] ?? $input;
            if (!is_array($payload)) {
                throw new InvalidArgumentException('Invalid customer payload');
            }
            unset($payload['action'], $payload['_csrf'], $payload['password'], $payload['password_hash'], $payload['passwd']);
            $id = (string) ($payload['id'] ?? '');
            if ($id !== '' && $customers->getById($id)) {
                $saved = $customers->update($id, $payload);
            } else {
                $saved = $customers->upsert($payload);
            }
            echo json_encode([
                'status' => 'ok',
                'data' => [
                    'customer' => $saved,
                    'user_management' => $customers->resolveUserManagementLink($saved),
                ],
            ]);
        } catch (Throwable $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'import_customers_csv':
        $csv = (string) ($input['csv'] ?? '');
        if ($csv === '' && !empty($_FILES['file']['tmp_name']) && is_uploaded_file($_FILES['file']['tmp_name'])) {
            $csv = (string) file_get_contents($_FILES['file']['tmp_name']);
        }
        if (trim($csv) === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'CSV content is required']);
            break;
        }
        $summary = $customers->importCsv($csv);
        echo json_encode(['status' => 'ok', 'data' => $summary]);
        break;

    case 'delete_customer':
        $id = (string) ($input['id'] ?? '');
        $ok = $id !== '' && $customers->delete($id);
        echo json_encode(['status' => $ok ? 'ok' : 'error', 'message' => $ok ? null : 'Customer not found']);
        break;

    case 'export_orders_csv':
        $ids = $input['ids'] ?? null;
        $selected = [];
        if (is_array($ids) && $ids) {
            foreach ($ids as $oid) {
                $order = $orders->get((string) $oid);
                if ($order) {
                    $selected[] = $order;
                }
            }
        } else {
            $selected = $orders->listAll();
        }
        $csv = $orderOps->exportOrdersCsv($selected);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'filename' => 'orders-' . date('Ymd-His') . '.csv',
                'csv' => $csv,
                'count' => count($selected),
            ],
        ]);
        break;

    case 'order_invoice':
        $id = (string) ($input['id'] ?? $_GET['id'] ?? '');
        $order = $orders->get($id);
        if (!$order) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Order not found']);
            break;
        }
        if (empty($order['order_number'])) {
            $number = $orders->allocateOrderNumber($order['created_at'] ?? null);
            $order = $orders->update($id, ['order_number' => $number]) ?? $order;
        }
        $brand = [];
        if (trim((string) ($input['brand_name'] ?? $_GET['brand_name'] ?? '')) !== '') {
            $brand['name'] = (string) ($input['brand_name'] ?? $_GET['brand_name']);
        }
        if (trim((string) ($input['brand_email'] ?? '')) !== '') {
            $brand['email'] = (string) $input['brand_email'];
        }
        if (trim((string) ($input['brand_address'] ?? '')) !== '') {
            $brand['address'] = (string) $input['brand_address'];
        }
        $html = $orderOps->buildInvoiceHtml($order, $brand);
        $fresh = $orders->get($id) ?? $order;
        if (($input['format'] ?? $_GET['format'] ?? '') === 'html') {
            header('Content-Type: text/html; charset=utf-8');
            echo $html;
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['html' => $html, 'order' => $orderOps->enrichOrder($fresh)]]);
        break;

    case 'issue_invoice':
        $id = (string) ($input['id'] ?? '');
        $invoiceSvc = new CommerceInvoiceService(null, $orders);
        $result = $invoiceSvc->ensureInvoice($id);
        if (!($result['ok'] ?? false)) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Issue failed']);
            break;
        }
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'order' => $orderOps->enrichOrder($result['order'] ?? []),
                'issued' => !empty($result['issued']),
                'invoice_number' => $result['order']['invoice_number'] ?? null,
            ],
        ]);
        break;

    case 'get_invoice_profile':
        $invoiceSvc = new CommerceInvoiceService(null, $orders);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'profile' => $invoiceSvc->getProfile(),
                'templates' => $invoiceSvc->listTemplates(),
                'tokens' => $invoiceSvc->availableTokens(),
                'preset_ids' => CommerceInvoiceService::TEMPLATES,
            ],
        ]);
        break;

    case 'save_invoice_profile':
        $invoiceSvc = new CommerceInvoiceService(null, $orders);
        $profile = $invoiceSvc->saveProfile(is_array($input['profile'] ?? null) ? $input['profile'] : $input);
        echo json_encode(['status' => 'ok', 'data' => ['profile' => $profile]]);
        break;

    case 'list_invoice_templates':
        $invoiceSvc = new CommerceInvoiceService(null, $orders);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'templates' => $invoiceSvc->listTemplates(),
                'tokens' => $invoiceSvc->availableTokens(),
            ],
        ]);
        break;

    case 'save_invoice_template':
        $invoiceSvc = new CommerceInvoiceService(null, $orders);
        $tpl = is_array($input['template'] ?? null) ? $input['template'] : $input;
        $saved = $invoiceSvc->saveTemplate($tpl);
        echo json_encode(['status' => 'ok', 'data' => ['template' => $saved, 'templates' => $invoiceSvc->listTemplates()]]);
        break;

    case 'duplicate_invoice_template':
        $invoiceSvc = new CommerceInvoiceService(null, $orders);
        $dup = $invoiceSvc->duplicateTemplate(
            (string) ($input['id'] ?? ''),
            isset($input['name']) ? (string) $input['name'] : null
        );
        if (!($dup['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $dup['error'] ?? 'Duplicate failed']);
            break;
        }
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'template' => $dup['template'],
                'templates' => $invoiceSvc->listTemplates(),
            ],
        ]);
        break;

    case 'delete_invoice_template':
        $invoiceSvc = new CommerceInvoiceService(null, $orders);
        $del = $invoiceSvc->deleteTemplate((string) ($input['id'] ?? ''));
        if (!($del['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $del['error'] ?? 'Delete failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['templates' => $invoiceSvc->listTemplates()]]);
        break;

    case 'preview_invoice':
        $invoiceSvc = new CommerceInvoiceService(null, $orders);
        $profile = $invoiceSvc->getProfile();
        if (is_array($input['profile'] ?? null)) {
            $profile = array_merge($profile, $input['profile']);
        }
        $bodyOverride = null;
        if (isset($input['body_html']) && is_string($input['body_html'])) {
            $bodyOverride = $input['body_html'];
        }
        if (!empty($input['template_id'])) {
            $profile['template'] = (string) $input['template_id'];
        }
        $sample = [
            'id' => 'cord_preview',
            'order_number' => 'ORD-PREVIEW',
            'invoice_number' => 'INV-' . date('Y') . '-0000',
            'invoice_issued_at' => date('c'),
            'invoice_seller_snapshot' => $profile,
            'status' => 'paid',
            'customer_email' => 'customer@example.com',
            'customer_name' => 'Ada Buyer',
            'vat_id' => 'DE999999999',
            'currency' => 'eur',
            'total_cents' => 4590,
            'shipping_cents' => 450,
            'tax_cents' => 740,
            'discount_cents' => 0,
            'billing_address' => [
                'name' => 'Ada Buyer',
                'line1' => '1 Sample Street',
                'postal_code' => '10115',
                'city' => 'Berlin',
                'country' => 'DE',
            ],
            'shipping_address' => [
                'name' => 'Ada Buyer',
                'line1' => '1 Sample Street',
                'postal_code' => '10115',
                'city' => 'Berlin',
                'country' => 'DE',
            ],
            'lines' => [
                ['title' => 'Ceramic Mug', 'sku' => 'MUG-1', 'quantity' => 1, 'line_total_cents' => 2400],
                ['title' => 'Sticker Pack', 'sku' => 'STK-1', 'quantity' => 2, 'line_total_cents' => 1000],
            ],
        ];
        $html = $invoiceSvc->buildInvoiceHtml($sample, [], false, $bodyOverride);
        echo json_encode(['status' => 'ok', 'data' => ['html' => $html]]);
        break;

    case 'list_email_templates':
        $emailSvc = new CommerceEmailService();
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'templates' => $emailSvc->listTemplates(),
                'tokens' => $emailSvc->availableTokens(),
                'triggers' => CommerceEmailService::TRIGGERS,
                'trigger_labels' => $emailSvc->triggerLabels(),
                'delay_anchors' => CommerceEmailService::DELAY_ANCHORS,
                'scheduled' => $emailSvc->listScheduled(30),
                'delivery_settings' => $emailSvc->getDeliverySettings(),
                'attachment_options' => CommerceEmailService::attachmentOptions(),
            ],
        ]);
        break;

    case 'save_email_delivery_settings':
        $emailSvc = new CommerceEmailService();
        $settings = is_array($input['settings'] ?? null) ? $input['settings'] : $input;
        $saved = $emailSvc->saveDeliverySettings($settings);
        echo json_encode(['status' => 'ok', 'data' => ['settings' => $saved]]);
        break;

    case 'save_email_template':
        $emailSvc = new CommerceEmailService();
        $tpl = is_array($input['template'] ?? null) ? $input['template'] : $input;
        $saved = $emailSvc->saveTemplate($tpl);
        echo json_encode(['status' => 'ok', 'data' => ['template' => $saved]]);
        break;

    case 'list_scheduled_emails':
        $emailSvc = new CommerceEmailService();
        $limit = max(1, min(200, (int) ($input['limit'] ?? $_GET['limit'] ?? 50)));
        echo json_encode(['status' => 'ok', 'data' => ['jobs' => $emailSvc->listScheduled($limit)]]);
        break;

    case 'process_scheduled_emails':
        $emailSvc = new CommerceEmailService();
        $result = $emailSvc->processDueScheduledEmails();
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'preview_email_template':
        $emailSvc = new CommerceEmailService();
        $templateId = (string) ($input['id'] ?? $input['template_id'] ?? '');
        $preview = $emailSvc->preview($templateId);
        if (!($preview['ok'] ?? false)) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => $preview['error'] ?? 'Preview failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $preview]);
        break;

    case 'send_test_email':
        $emailSvc = new CommerceEmailService();
        $templateId = (string) ($input['id'] ?? $input['template_id'] ?? '');
        $to = trim((string) ($input['to'] ?? ''));
        if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Valid to email required']);
            break;
        }
        $tpl = null;
        foreach ($emailSvc->listTemplates() as $row) {
            if (($row['id'] ?? '') === $templateId) {
                $tpl = $row;
                break;
            }
        }
        if (!$tpl) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Template not found']);
            break;
        }
        $testWarning = empty($tpl['enabled'])
            ? 'Template is disabled — live order_paid sends will not use it until Enabled is checked and saved.'
            : null;
        $result = $emailSvc->sendTemplate($tpl, $emailSvc->sampleContext(), $to);
        echo json_encode([
            'status' => !empty($result['ok']) ? 'ok' : 'error',
            'data' => $result,
            'message' => $result['error'] ?? $testWarning,
            'warning' => $testWarning,
        ]);
        break;

    case 'list_email_log':
        $emailSvc = new CommerceEmailService();
        $limit = max(1, min(100, (int) ($input['limit'] ?? $_GET['limit'] ?? 20)));
        echo json_encode(['status' => 'ok', 'data' => ['entries' => $emailSvc->recentLog($limit)]]);
        break;

    case 'packing_slips':
        $ids = $input['ids'] ?? [];
        $shipmentId = isset($input['shipment_id']) ? (string) $input['shipment_id'] : '';
        $remainingOnly = !empty($input['remaining_only']);
        if ((!is_array($ids) || !$ids) && $shipmentId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'ids required']);
            break;
        }
        if ($shipmentId !== '' && (!is_array($ids) || count($ids) !== 1)) {
            // Single-order packing slip for a specific shipment.
            $orderId = (string) ($input['id'] ?? ($ids[0] ?? ''));
            if ($orderId === '') {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => 'id required with shipment_id']);
                break;
            }
            $ids = [$orderId];
        }
        $parts = [];
        foreach ($ids as $oid) {
            $order = $orders->get((string) $oid);
            if (!$order) {
                continue;
            }
            $brand = ['name' => (string) ($input['brand_name'] ?? 'Packing slip')];
            if ($shipmentId !== '') {
                $parts[] = $orderOps->buildPackingSlipHtml($order, $brand, $shipmentId, false);
            } else {
                // Prefer remaining items when any left; otherwise full shippable list.
                $enriched = $orderOps->enrichOrder($order);
                $hasRemaining = false;
                foreach ($enriched['lines'] ?? [] as $line) {
                    if (($line['fulfillment'] ?? '') === 'ship' && (int) ($line['quantity_remaining'] ?? 0) > 0) {
                        $hasRemaining = true;
                        break;
                    }
                }
                $parts[] = $orderOps->buildPackingSlipHtml(
                    $order,
                    $brand,
                    null,
                    $remainingOnly || $hasRemaining
                );
            }
        }
        if (!$parts) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'No orders found']);
            break;
        }
        $html = $parts[0];
        for ($i = 1, $n = count($parts); $i < $n; $i++) {
            if (preg_match('#<body[^>]*>(.*)</body>#si', $parts[$i], $m)) {
                $html = preg_replace('#</body></html>$#', '<div style="page-break-before:always"></div>' . $m[1] . '</body></html>', $html, 1);
            }
        }
        echo json_encode(['status' => 'ok', 'data' => ['html' => $html, 'count' => count($parts)]]);
        break;

    case 'list_subscriptions':
        // Split legacy combined multi-line subscriptions into one-per-line.
        $subscriptions->normalizeToSingleLineSubscriptions();
        echo json_encode(['status' => 'ok', 'data' => ['subscriptions' => $subscriptionStore->listAll()]]);
        break;

    case 'get_subscription':
        $id = $input['id'] ?? $_GET['id'] ?? '';
        $subscription = $subscriptionStore->get($id);
        if (!$subscription) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Subscription not found']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['subscription' => $subscription]]);
        break;

    case 'cancel_subscription':
        $id = $input['id'] ?? '';
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $canceled = $subscriptions->cancel($id);
        if (!$canceled) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Subscription not found']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['subscription' => $canceled]]);
        break;

    case 'pause_subscription':
        $id = $input['id'] ?? '';
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $paused = $subscriptions->pause($id);
        if (!$paused) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Subscription not found or cannot be paused']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['subscription' => $paused]]);
        break;

    case 'resume_subscription':
        $id = $input['id'] ?? '';
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $resumed = $subscriptions->resume($id);
        if (!$resumed) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Subscription not found or not paused']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['subscription' => $resumed]]);
        break;

    case 'list_subscription_upgrade_options':
        $id = $input['id'] ?? $_GET['id'] ?? '';
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $sub = $subscriptionStore->get($id);
        if (!$sub) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Subscription not found']);
            break;
        }
        echo json_encode([
            'status' => 'ok',
            'data' => ['options' => $subscriptionUpgrades->listUpgradeOptions($id)],
        ]);
        break;

    case 'upgrade_subscription':
        $id = $input['id'] ?? '';
        $purchaseOptionId = $input['purchase_option_id'] ?? '';
        if ($id === '' || $purchaseOptionId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id and purchase_option_id required']);
            break;
        }
        $result = $subscriptionUpgrades->upgrade($id, $purchaseOptionId);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Upgrade failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'retry_subscription_payment':
        $id = $input['id'] ?? '';
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $subscriptions->retryPayment($id);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Retry failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'list_discounts':
        echo json_encode(['status' => 'ok', 'data' => ['rules' => array_values($discounts->listRules())]]);
        break;

    case 'save_discount':
        $rule = $input['rule'] ?? [];
        if (!is_array($rule)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid rule payload']);
            break;
        }
        try {
            $saved = $discounts->saveRule($rule);
            echo json_encode(['status' => 'ok', 'data' => ['rule' => $saved]]);
        } catch (Throwable $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'delete_discount':
        $id = $input['id'] ?? '';
        $ok = $discounts->deleteRule($id);
        echo json_encode(['status' => $ok ? 'ok' : 'error']);
        break;

    case 'import_sources':
        echo json_encode(['status' => 'ok', 'data' => ['sources' => ImportService::getImportSources()]]);
        break;

    case 'import_collections':
        echo json_encode(['status' => 'ok', 'data' => ['collections' => $import->listImportCollections()]]);
        break;

    case 'import_history':
        require_once __DIR__ . '/../includes/ImportHistoryStore.php';
        $history = new ImportHistoryStore();
        $limit = max(1, min(100, (int) ($input['limit'] ?? 50)));
        echo json_encode(['status' => 'ok', 'data' => ['imports' => $history->list($limit)]]);
        break;

    case 'import_detail':
        require_once __DIR__ . '/../includes/ImportHistoryStore.php';
        $importId = $input['id'] ?? '';
        if ($importId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $history = new ImportHistoryStore();
        $record = $history->get($importId);
        if ($record === null) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Import not found']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['import' => $record]]);
        break;

    case 'import_rollback':
        $importId = trim((string) ($input['id'] ?? ''));
        if ($importId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $deleteCollection = !array_key_exists('delete_collection', $input) || !empty($input['delete_collection']);
        $result = $import->rollbackImport($importId, $deleteCollection);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Rollback failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'import_dry_run':
        $csv = $input['csv'] ?? '';
        $preset = $input['preset'] ?? 'generic';
        $collection = $input['collection'] ?? 'products';
        $defaultCurrency = $input['default_currency'] ?? 'eur';
        $createCollection = !empty($input['create_collection']);
        $collectionTitle = trim((string) ($input['collection_title'] ?? ''));
        if ($createCollection && $collectionTitle !== '') {
            require_once __DIR__ . '/../includes/ImportCollectionHelper.php';
            $collection = (new ImportCollectionHelper())->previewSlugForTitle($collectionTitle);
        }
        $parsed = $import->parseCsv($csv, $preset);
        if (!($parsed['ok'] ?? false)) {
            echo json_encode(['status' => 'error', 'message' => $parsed['error'] ?? 'Parse failed']);
            break;
        }
        $rows = $import->applyDefaultCurrency($parsed['rows'], $defaultCurrency);
        $dry = $import->dryRun($rows, $collection);
        echo json_encode(['status' => 'ok', 'data' => $dry]);
        break;

    case 'import_csv':
        $csv = $input['csv'] ?? '';
        $preset = $input['preset'] ?? 'generic';
        $collection = $input['collection'] ?? 'products';
        $defaultCurrency = $input['default_currency'] ?? 'eur';
        $dryRun = !empty($input['dry_run']);
        $createCollection = !empty($input['create_collection']);
        $collectionTitle = trim((string) ($input['collection_title'] ?? ''));
        if ($createCollection && $collectionTitle !== '') {
            require_once __DIR__ . '/../includes/ImportCollectionHelper.php';
            $collection = (new ImportCollectionHelper())->previewSlugForTitle($collectionTitle);
        }
        $parsed = $import->parseCsv($csv, $preset);
        if (!($parsed['ok'] ?? false)) {
            echo json_encode(['status' => 'error', 'message' => $parsed['error'] ?? 'Parse failed']);
            break;
        }
        $rows = $import->applyDefaultCurrency($parsed['rows'], $defaultCurrency);
        $result = $import->importRows($rows, $collection, $dryRun, [
            'preset' => $preset,
            'platform' => ImportService::platformName($preset),
            'currency' => $defaultCurrency,
            'file_name' => trim((string) ($input['file_name'] ?? '')) ?: null,
            'create_collection' => $createCollection,
            'collection_title' => $collectionTitle !== '' ? $collectionTitle : null,
        ]);
        if (!($result['ok'] ?? false)) {
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Import failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'import_live_config':
        echo json_encode(['status' => 'ok', 'data' => $liveImport->getPublicConfig()]);
        break;

    case 'import_live_save':
        $platform = trim((string) ($input['platform'] ?? ''));
        $patch = is_array($input['config'] ?? null) ? $input['config'] : $input;
        unset($patch['action'], $patch['_csrf'], $patch['platform']);
        $result = $liveImport->savePlatformConfig($platform, $patch);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Save failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'import_live_test':
        $platform = trim((string) ($input['platform'] ?? ''));
        $result = $liveImport->testConnection($platform);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Connection failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'import_live_preview':
        $platform = trim((string) ($input['platform'] ?? ''));
        $result = $liveImport->preview($platform);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Preview failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'shopify_cutover_test':
        require_once __DIR__ . '/../includes/ShopifyCutoverService.php';
        $cutover = new ShopifyCutoverService();
        $result = $cutover->testConnection();
        echo json_encode(['status' => ($result['ok'] ?? false) ? 'ok' : 'error', 'data' => $result, 'message' => $result['error'] ?? null]);
        break;

    case 'shopify_cutover_dry_run':
        require_once __DIR__ . '/../includes/ShopifyCutoverService.php';
        $cutover = new ShopifyCutoverService();
        $result = $cutover->dryRun($input['resources'] ?? 'all', $input);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Dry-run failed', 'data' => $result]);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'shopify_cutover_import':
        require_once __DIR__ . '/../includes/ShopifyCutoverService.php';
        $cutover = new ShopifyCutoverService();
        $result = $cutover->import($input['resources'] ?? 'all', $input);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Cutover import failed', 'data' => $result]);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'shopify_cutover_rollback':
        require_once __DIR__ . '/../includes/ShopifyCutoverService.php';
        $cutover = new ShopifyCutoverService();
        $batchId = trim((string) ($input['batch_id'] ?? ($input['id'] ?? '')));
        $result = $cutover->rollback($batchId, !empty($input['delete_collection']));
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Rollback failed', 'data' => $result]);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'import_live_sync':
        $platform = trim((string) ($input['platform'] ?? ''));
        if ($platform === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'platform required']);
            break;
        }
        $result = $liveImport->syncPlatform($platform);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Sync failed', 'data' => $result]);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'list_mappings':
        echo json_encode(['status' => 'ok', 'data' => ['mappings' => $mappings->getMappings()]]);
        break;

    case 'save_mapping':
        $key = $input['key'] ?? '';
        $config = $input['config'] ?? [];
        if ($key === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'key required']);
            break;
        }
        $mappings->setMapping($key, $config);
        echo json_encode(['status' => 'ok']);
        break;

    case 'delete_mapping':
        $key = $input['key'] ?? '';
        $ok = $mappings->deleteMapping($key);
        echo json_encode(['status' => $ok ? 'ok' : 'error']);
        break;

    case 'list_membership_tiers':
        $tiers = [];
        if (function_exists('birkly_is_plugin_active') && birkly_is_plugin_active('user_management')) {
            if (function_exists('birkly_plugin_require') && birkly_plugin_require('user_management', 'includes/UserStorage.php')) {
                $userStorage = new UserStorage();
                $tiers = $userStorage->listTiers();
            }
        }
        echo json_encode(['status' => 'ok', 'data' => ['tiers' => $tiers, 'user_management_active' => !empty($tiers)]]);
        break;

    case 'mapping_wizard_data':
        $tiers = [];
        if (function_exists('birkly_is_plugin_active') && birkly_is_plugin_active('user_management')) {
            if (function_exists('birkly_plugin_require') && birkly_plugin_require('user_management', 'includes/UserStorage.php')) {
                $userStorage = new UserStorage();
                $tiers = $userStorage->listTiers();
            }
        }
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'catalog' => $catalog->listItems([]),
                'tiers' => $tiers,
                'mappings' => $mappings->getMappings(),
                'user_management_active' => function_exists('birkly_is_plugin_active') && birkly_is_plugin_active('user_management'),
            ],
        ]);
        break;

    case 'create_membership_mapping':
        $result = $mappings->createMembershipMapping($input);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Failed to create mapping']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'list_fulfillment':
        if (!class_exists('FulfillmentAdapterResolver')) {
            require_once dirname(__DIR__) . '/includes/FulfillmentAdapterResolver.php';
        }
        $connections = FulfillmentAdapterResolver::loadConnections();
        $secretSet = trim((string) (($connections['easypost']['webhook_secret'] ?? '') ?: '')) !== '';
        $connections['easypost'] = [
            'webhook_secret_set' => $secretSet,
            'api_key_set' => FulfillmentAdapterResolver::resolveEasyPostApiKey() !== '',
            'webhook_url' => FulfillmentAdapterResolver::webhookUrl(),
        ];
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'connections' => $connections,
                'available_adapters' => FulfillmentAdapterResolver::listAvailableAdapters(),
            ],
        ]);
        break;

    case 'test_fulfillment':
        if (!class_exists('FulfillmentAdapterResolver')) {
            require_once dirname(__DIR__) . '/includes/FulfillmentAdapterResolver.php';
        }
        $adapterId = FulfillmentAdapterResolver::normalizeAdapterId($input['adapter'] ?? 'manual');
        if (!in_array($adapterId, ['manual', 'easypost'], true)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Unsupported fulfillment adapter']);
            break;
        }
        $adapter = FulfillmentAdapterResolver::resolve($adapterId);
        echo json_encode(['status' => 'ok', 'data' => $adapter->testConnection()]);
        break;

    case 'save_fulfillment':
        if (!class_exists('FulfillmentAdapterResolver')) {
            require_once dirname(__DIR__) . '/includes/FulfillmentAdapterResolver.php';
        }
        $data = $input['connections'] ?? [];
        $saved = FulfillmentAdapterResolver::saveConnections($data);
        $saved['easypost'] = [
            'webhook_secret_set' => trim((string) (($saved['easypost']['webhook_secret'] ?? '') ?: '')) !== '',
            'api_key_set' => FulfillmentAdapterResolver::resolveEasyPostApiKey() !== '',
            'webhook_url' => FulfillmentAdapterResolver::webhookUrl(),
        ];
        echo json_encode(['status' => 'ok', 'data' => ['connections' => $saved]]);
        break;

    case 'refund_order':
        $id = $input['id'] ?? '';
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $amountRaw = $input['amount_cents'] ?? null;
        $amountCents = ($amountRaw === null || $amountRaw === '') ? null : (int) $amountRaw;
        $reason = (string) ($input['reason'] ?? '');
        $lineId = isset($input['line_id']) ? (string) $input['line_id'] : null;
        if ($lineId === '') {
            $lineId = null;
        }
        $result = $checkout->refundOrder($id, $amountCents, $reason, $lineId);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Refund failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'cancel_order':
        $id = (string) ($input['id'] ?? '');
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $refund = array_key_exists('refund', $input) ? !empty($input['refund']) : true;
        $reason = (string) ($input['reason'] ?? '');
        $result = $checkout->cancelOrder($id, [
            'refund' => $refund,
            'reason' => $reason,
            'source' => 'admin',
            'actor' => commerce_admin_actor(),
        ]);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Cancel failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'list_shipping_zones':
        $shipping = $catalog->loadShippingZones();
        // Never echo full API key to the admin UI — indicate presence only.
        $shipping['easypost_api_key_set'] = ($shipping['easypost_api_key'] ?? '') !== '';
        $shipping['easypost_api_key'] = '';
        echo json_encode(['status' => 'ok', 'data' => $shipping]);
        break;

    case 'save_shipping_zones':
        $catalog->saveShippingZones([
            'provider' => $input['provider'] ?? 'manual',
            'easypost_api_key' => $input['easypost_api_key'] ?? '',
            'from_address' => $input['from_address'] ?? [],
            'free_shipping_min_cents' => max(0, (int) ($input['free_shipping_min_cents'] ?? 0)),
            'zones' => $input['zones'] ?? [],
        ]);
        echo json_encode(['status' => 'ok', 'data' => [
            'provider' => $catalog->getShippingRateProviderId(),
            'free_shipping_min_cents' => $catalog->getFreeShippingMinCents(),
        ]]);
        break;

    case 'list_shipping_rate_providers':
        if (!class_exists('ShippingRateProviderResolver')) {
            require_once dirname(__DIR__) . '/includes/ShippingRateProviderResolver.php';
        }
        $resolver = new ShippingRateProviderResolver($catalog);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'providers' => $resolver->listProviders(),
                'active' => $resolver->getProviderId(),
            ],
        ]);
        break;

    case 'list_tax_rules':
        echo json_encode(['status' => 'ok', 'data' => $catalog->loadTaxRules()]);
        break;

    case 'save_tax_rules':
        $catalog->saveTaxRules([
            'enabled' => !empty($input['enabled']),
            'provider' => $input['provider'] ?? 'manual',
            'default_rate' => (float) ($input['default_rate'] ?? 0),
            'country_rates' => $input['country_rates'] ?? [],
            'classes' => $input['classes'] ?? [],
            'class_country_rates' => $input['class_country_rates'] ?? [],
            'b2b_reverse_charge' => is_array($input['b2b_reverse_charge'] ?? null)
                ? $input['b2b_reverse_charge']
                : [],
        ]);
        echo json_encode(['status' => 'ok', 'data' => $catalog->loadTaxRules()]);
        break;

    case 'list_tax_providers':
        if (!class_exists('TaxProviderResolver')) {
            require_once dirname(__DIR__) . '/includes/TaxProviderResolver.php';
        }
        $resolver = new TaxProviderResolver($catalog);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'providers' => $resolver->listProviders(),
                'active' => $resolver->getProviderId(),
            ],
        ]);
        break;

    case 'list_fieldtype_profiles':
        echo json_encode(['status' => 'ok', 'data' => ['profiles' => $fieldtypeProfiles->listProfiles()]]);
        break;

    case 'save_fieldtype_profile':
        $profile = $input['profile'] ?? [];
        if (empty($profile['name'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Profile name required']);
            break;
        }
        $saved = $fieldtypeProfiles->saveProfile($profile);
        commerce_register_fieldtype_profiles();
        echo json_encode(['status' => 'ok', 'data' => ['profile' => $saved]]);
        break;

    case 'delete_fieldtype_profile':
        $id = $input['id'] ?? '';
        if ($id === '' || $id === 'default') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Cannot delete default profile']);
            break;
        }
        $ok = $fieldtypeProfiles->deleteProfile($id);
        if ($ok) {
            commerce_register_fieldtype_profiles();
        }
        echo json_encode(['status' => $ok ? 'ok' : 'error']);
        break;

    case 'migration_scan':
        echo json_encode(['status' => 'ok', 'data' => $migration->scan()]);
        break;

    case 'migration_preview':
        echo json_encode(['status' => 'ok', 'data' => $migration->preview($input)]);
        break;

    case 'migration_import':
        $result = $migration->import($input);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Import failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'migration_history':
        $limit = max(1, min(100, (int) ($input['limit'] ?? 50)));
        echo json_encode(['status' => 'ok', 'data' => ['migrations' => $migration->listHistory($limit)]]);
        break;

    case 'migration_rollback':
        $importId = trim((string) ($input['id'] ?? ''));
        if ($importId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $result = $migration->rollback($importId);
        if (!($result['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $result['error'] ?? 'Rollback failed']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $result]);
        break;

    case 'list_gift_cards':
        echo json_encode(['status' => 'ok', 'data' => ['gift_cards' => $giftCards->listAll()]]);
        break;

    case 'issue_gift_card':
        try {
            $c = $giftCards->issue([
                'code' => $input['code'] ?? null,
                'balance_cents' => (int) ($input['balance_cents'] ?? 0),
                'currency' => $input['currency'] ?? 'eur',
                'expires_at' => $input['expires_at'] ?? null,
                'note' => $input['note'] ?? '',
                'source' => 'admin',
                'issued_by' => 'admin',
            ]);
            echo json_encode(['status' => 'ok', 'data' => ['gift_card' => $c]]);
        } catch (Exception $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'void_gift_card':
        echo json_encode(['status' => $giftCards->voidCard($input['code'] ?? '') ? 'ok' : 'error']);
        break;

    case 'create_quote':
        $b = $catalog->buildCartLines($cart->getItems(), $discounts, $cart->getCouponCode(), $cart->getAffiliateId());
        if (empty($b['lines'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Cart is empty']);
            break;
        }
        $q = $quoteStore->createFromBuiltCart($b, $input['customer_email'] ?? '', [], ['draft_order' => true]);
        echo json_encode(['status' => 'ok', 'data' => ['quote' => $q, 'accept_url' => $quoteStore->acceptUrl($q['token'])]]);
        break;

    case 'list_quotes':
        echo json_encode(['status' => 'ok', 'data' => ['quotes' => $quoteStore->listAll()]]);
        break;

    case 'get_quote_admin':
    case 'draft_order_get':
        $draftId = trim((string) ($input['id'] ?? $_GET['id'] ?? ''));
        if ($draftId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $dq = $draftOrders->get($draftId);
        if (!$dq) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Draft order not found']);
            break;
        }
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'quote' => $dq,
                'accept_url' => $quoteStore->acceptUrl((string) ($dq['token'] ?? '')),
            ],
        ]);
        break;

    case 'draft_order_search_catalog':
        $q = (string) ($input['q'] ?? ($input['query'] ?? ($_GET['q'] ?? '')));
        $limit = max(1, min(50, (int) ($input['limit'] ?? 25)));
        echo json_encode([
            'status' => 'ok',
            'data' => ['items' => $draftOrders->searchCatalog($q, $limit)],
        ]);
        break;

    case 'draft_order_preview':
        $preview = $draftOrders->preview($input);
        echo json_encode([
            'status' => ($preview['ok'] ?? false) ? 'ok' : 'error',
            'message' => $preview['error'] ?? null,
            'data' => $preview,
        ]);
        break;

    case 'draft_order_create':
        $created = $draftOrders->create($input);
        if (!($created['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $created['error'] ?? 'Create failed', 'data' => $created]);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $created]);
        break;

    case 'draft_order_update':
        $updateId = trim((string) ($input['id'] ?? ''));
        if ($updateId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $updated = $draftOrders->update($updateId, $input);
        if (!($updated['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $updated['error'] ?? 'Update failed', 'data' => $updated]);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => $updated]);
        break;

    case 'draft_order_checkout':
        $checkoutId = trim((string) ($input['id'] ?? ''));
        if ($checkoutId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        $paidOut = $draftOrders->checkout($checkoutId, $input);
        echo json_encode([
            'status' => ($paidOut['ok'] ?? false) ? 'ok' : 'error',
            'message' => $paidOut['error'] ?? null,
            'data' => $paidOut,
        ]);
        break;

    case 'cancel_quote':
        $quoteId = trim((string) ($input['id'] ?? ''));
        if ($quoteId === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'id required']);
            break;
        }
        echo json_encode(['status' => $quoteStore->cancel($quoteId) ? 'ok' : 'error']);
        break;

    case 'get_quote':
        $q = $quoteStore->findByToken($input['token'] ?? $_GET['token'] ?? '');
        if (!$q) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Quote not found']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['quote' => $q]]);
        break;

    case 'accept_quote':
        $r = $quoteStore->accept($input['token'] ?? '');
        echo json_encode(['status' => ($r['ok'] ?? false) ? 'ok' : 'error', 'data' => $r]);
        break;

    case 'quote_checkout':
        $r = $checkout->checkoutQuote($input['token'] ?? '', $input['email'] ?? '');
        echo json_encode(['status' => ($r['ok'] ?? false) ? 'ok' : 'error', 'data' => $r]);
        break;

    case 'analytics_summary':
        echo json_encode(['status' => 'ok', 'data' => ['summary' => $analytics->getSummary($input['from'] ?? null, $input['to'] ?? null)]]);
        break;

    case 'analytics_export_csv':
        header('Content-Type: text/csv');
        echo $analytics->exportOrdersCsv($input['from'] ?? null, $input['to'] ?? null);
        exit;

    case 'list_warehouse_stock':
        $ledger = commerce_inventory_ledger($indexer);
        $warehouse = new WarehouseStockStore();
        $warehouseId = trim((string) ($input['warehouse_id'] ?? ''));
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'mode' => $ledger->mode(),
                'stock' => $ledger->listRows($warehouseId !== '' ? $warehouseId : null),
                'warehouses' => $warehouse->listWarehouses(),
            ],
        ]);
        break;

    case 'list_warehouses':
        require_once __DIR__ . '/../includes/WarehouseStockStore.php';
        $warehouse = new WarehouseStockStore();
        echo json_encode(['status' => 'ok', 'data' => ['warehouses' => $warehouse->listWarehouses()]]);
        break;

    case 'save_warehouse':
        require_once __DIR__ . '/../includes/WarehouseStockStore.php';
        if (commerce_inventory_ledger($indexer)->mode() !== InventoryLedger::MODE_LOCATIONS) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Warehouse management is available only in Locations stock mode']);
            break;
        }
        $warehouse = new WarehouseStockStore();
        $id = trim((string) ($input['id'] ?? ''));
        $name = trim((string) ($input['name'] ?? ''));
        try {
            if ($id === '') {
                $row = $warehouse->createWarehouse($name, isset($input['sort_order']) ? (int) $input['sort_order'] : null);
            } else {
                $row = $warehouse->updateWarehouse($id, $name, isset($input['sort_order']) ? (int) $input['sort_order'] : null);
            }
            echo json_encode(['status' => 'ok', 'data' => ['warehouse' => $row]]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'delete_warehouse':
        require_once __DIR__ . '/../includes/WarehouseStockStore.php';
        if (commerce_inventory_ledger($indexer)->mode() !== InventoryLedger::MODE_LOCATIONS) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Warehouse management is available only in Locations stock mode']);
            break;
        }
        $warehouse = new WarehouseStockStore();
        $id = trim((string) ($input['id'] ?? ''));
        try {
            echo json_encode(['status' => $warehouse->deleteWarehouse($id) ? 'ok' : 'error']);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'transfer_warehouse_stock':
        require_once __DIR__ . '/../includes/WarehouseStockStore.php';
        if (commerce_inventory_ledger($indexer)->mode() !== InventoryLedger::MODE_LOCATIONS) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Stock transfers are available only in Locations stock mode']);
            break;
        }
        $warehouse = new WarehouseStockStore();
        try {
            $result = $warehouse->transfer(
                trim((string) ($input['sku'] ?? '')),
                (int) ($input['quantity'] ?? 0),
                trim((string) ($input['from_warehouse_id'] ?? '')),
                trim((string) ($input['to_warehouse_id'] ?? ''))
            );
            echo json_encode(['status' => 'ok', 'data' => $result]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        break;

    case 'save_warehouse_stock':
        $ledger = commerce_inventory_ledger($indexer);
        $sku = trim((string) ($input['sku'] ?? ''));
        if ($sku === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'sku required']);
            break;
        }
        if ($ledger->mode() === InventoryLedger::MODE_UNLIMITED) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Inventory is unlimited; switch to Simple or Locations to set stock']);
            break;
        }
        $warehouseId = trim((string) ($input['warehouse_id'] ?? ''));
        $row = $ledger->setSkuStock(
            $sku,
            (int) ($input['quantity_on_hand'] ?? 0),
            isset($input['low_stock_threshold']) ? (int) $input['low_stock_threshold'] : null,
            $warehouseId !== '' ? $warehouseId : null
        );
        echo json_encode(['status' => 'ok', 'data' => ['row' => $row]]);
        break;

    case 'bundle_validate':
        require_once __DIR__ . '/../includes/CommerceBundleSchema.php';
        $bundle = is_array($input['bundle'] ?? null) ? $input['bundle'] : [];
        $index = $indexer->loadIndex();
        $resolved = CommerceBundleSchema::resolveComponents($bundle, $index['entries'] ?? []);
        $errors = CommerceBundleSchema::validate($bundle);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'valid' => $resolved['valid'] && empty($errors),
                'issues' => array_merge($resolved['issues'] ?? [], $errors),
                'components' => $resolved['items'] ?? [],
            ],
        ]);
        break;

    case 'bundle_preview_price':
        require_once __DIR__ . '/../includes/CommerceBundleSchema.php';
        $bundle = is_array($input['bundle'] ?? null) ? $input['bundle'] : [];
        $index = $indexer->loadIndex();
        $resolved = CommerceBundleSchema::resolveComponents($bundle, $index['entries'] ?? []);
        $priceCents = CommerceBundleSchema::computePriceCents($bundle, $resolved['items'] ?? []);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'price_cents' => $priceCents,
                'currency' => strtolower((string) (commerce_bundle_normalize_value($bundle)['currency'] ?? 'eur')),
                'valid' => $resolved['valid'],
                'issues' => $resolved['issues'] ?? [],
            ],
        ]);
        break;

    case 'get_inventory_webhook_config':
        require_once __DIR__ . '/../includes/CommerceInventoryWebhookService.php';
        $webhooks = new CommerceInventoryWebhookService();
        $public = $liveImport->getPublicConfig();
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'shopify' => [
                    'webhook_url' => $webhooks->webhookUrl('shopify'),
                    'webhook_configured' => !empty($public['shopify']['webhook_configured']),
                ],
                'woocommerce' => [
                    'webhook_url' => $webhooks->webhookUrl('woocommerce'),
                    'webhook_configured' => !empty($public['woocommerce']['webhook_configured']),
                ],
            ],
        ]);
        break;

    case 'rotate_inventory_webhook_secret':
        $platform = strtolower(trim((string) ($input['platform'] ?? '')));
        if (!in_array($platform, ['shopify', 'woocommerce'], true)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'platform must be shopify or woocommerce']);
            break;
        }
        $secret = bin2hex(random_bytes(16));
        $liveImport->savePlatformConfig($platform, ['webhook_secret' => $secret]);
        echo json_encode(['status' => 'ok', 'data' => ['platform' => $platform, 'webhook_secret' => $secret]]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Unknown action']);
        break;
}
