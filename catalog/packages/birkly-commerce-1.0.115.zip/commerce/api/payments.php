<?php
/**
 * Payments admin API — connections CRUD, activity list, stats.
 */

error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../cms_paths.php';
$commerceCmsRoot = commerce_cms_root();
ini_set('error_log', $commerceCmsRoot . '/logs/php_errors.log');

require_once $commerceCmsRoot . '/api/session.php';
haru_secure_session_start();
header('Content-Type: application/json');

require_once $commerceCmsRoot . '/api/auth.php';
require_once $commerceCmsRoot . '/core/csrf.php';
require_once __DIR__ . '/../init.php';

if (!commerce_plugin_active()) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'Commerce plugin is not active']);
    exit;
}

$shelf = commerce_bootstrap();
require_once __DIR__ . '/../includes/InventoryLedger.php';
$store = $GLOBALS['commerce_credential_store'] ?? new PaymentsCredentialStore();
$activityLog = $GLOBALS['commerce_activity_log'] ?? new PaymentsActivityLog($store->getDataDir());

$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? $_GET['action'] ?? '';

$readActions = ['list_connections', 'get_connection', 'list_activity', 'stats', 'list_providers', 'get_webhook_url', 'get_settings'];
$manageActions = ['save_connection', 'delete_connection', 'test_connection', 'save_settings', 'set_default_connection'];

if (!in_array($action, $readActions, true) && !in_array($action, $manageActions, true)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Unknown action']);
    exit;
}

if (in_array($action, ['list_activity', 'stats'], true)) {
    if (!payments_can_view_activity()) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Forbidden']);
        exit;
    }
} elseif (in_array($action, $manageActions, true)) {
    if (!payments_can_manage()) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Forbidden']);
        exit;
    }
} else {
    if (!payments_can_view_activity()) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Forbidden']);
        exit;
    }
}

if (in_array($action, $manageActions, true) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $input['_csrf'] ?? $_POST['_csrf'] ?? '';
    if (!validate_csrf_token($csrf)) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
        exit;
    }
}

switch ($action) {
    case 'list_providers':
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'providers' => $shelf->listProviders(),
            ],
        ]);
        break;

    case 'list_connections':
        $connections = array_values($store->listConnections());
        foreach ($connections as &$conn) {
            $conn['webhook_url'] = $shelf->getWebhookUrl($conn['provider'] ?? '');
        }
        unset($conn);
        echo json_encode(['status' => 'ok', 'data' => ['connections' => $connections]]);
        break;

    case 'get_connection':
        $id = $input['id'] ?? $_GET['id'] ?? '';
        $conn = $store->getConnection($id, false);
        if (!$conn) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Connection not found']);
            break;
        }
        $conn['webhook_url'] = $shelf->getWebhookUrl($conn['provider'] ?? '');
        echo json_encode(['status' => 'ok', 'data' => ['connection' => $conn]]);
        break;

    case 'save_connection':
        $connection = $input['connection'] ?? [];
        if (empty($connection['provider'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Provider required']);
            break;
        }
        $certification = ProviderCertification::validateConnection($connection);
        if (!($certification['ok'] ?? false)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $certification['error'] ?? 'Provider is not certified for this mode']);
            break;
        }
        try {
            $saved = $store->saveConnection($connection);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
            break;
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'Could not save connection: ' . $e->getMessage()]);
            break;
        }
        $saved['webhook_url'] = $shelf->getWebhookUrl($saved['provider'] ?? '');
        echo json_encode(['status' => 'ok', 'data' => ['connection' => $saved]]);
        break;

    case 'delete_connection':
        $id = $input['id'] ?? '';
        $ok = $store->deleteConnection($id);
        echo json_encode(['status' => $ok ? 'ok' : 'error', 'message' => $ok ? 'Deleted' : 'Not found']);
        break;

    case 'set_default_connection':
        $id = $input['id'] ?? '';
        if ($id === '') {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Connection id required']);
            break;
        }
        $saved = $store->setDefaultConnection($id);
        if ($saved === null) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Connection not found or cannot be set as default']);
            break;
        }
        $saved['webhook_url'] = $shelf->getWebhookUrl($saved['provider'] ?? '');
        echo json_encode(['status' => 'ok', 'data' => ['connection' => $saved], 'message' => 'Default checkout connection updated']);
        break;

    case 'test_connection':
        $provider = $input['provider'] ?? '';
        $credentials = $input['credentials'] ?? [];
        if (empty($credentials) && !empty($input['connection_id'])) {
            $credentials = $store->getCredentialsForConnection($input['connection_id']) ?? [];
        }
        $result = $shelf->testConnection($provider, $credentials);
        echo json_encode(['status' => $result['ok'] ? 'ok' : 'error', 'data' => $result]);
        break;

    case 'list_activity':
        $filters = $input['filters'] ?? [];
        $limit = (int) ($input['limit'] ?? 100);
        $offset = (int) ($input['offset'] ?? 0);
        echo json_encode([
            'status' => 'ok',
            'data' => [
                'activity' => $activityLog->list($filters, $limit, $offset),
            ],
        ]);
        break;

    case 'stats':
        if (!payments_can_view_stats()) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'Forbidden']);
            break;
        }
        echo json_encode(['status' => 'ok', 'data' => ['stats' => $activityLog->stats()]]);
        break;

    case 'get_webhook_url':
        $provider = $input['provider'] ?? $_GET['provider'] ?? '';
        echo json_encode([
            'status' => 'ok',
            'data' => ['webhook_url' => $shelf->getWebhookUrl($provider)],
        ]);
        break;

    case 'get_settings':
        $settings = [];
        foreach ([
            'selection_mode', 'default_provider', 'auto_rules', 'enable_dashboard_widget', 'dashboard_widget_roles',
            'dunning_email_enabled', 'dunning_email_subject', 'dunning_email_body', 'commerce_default_currency',
            'commerce_display_currency', 'commerce_fx_rates', 'commerce_stock_mode', 'commerce_tax_provider',
            'commerce_shipping_rate_provider', 'commerce_easypost_api_key', 'commerce_fulfillment_sla_hours',
            'commerce_customer_cancel_enabled', 'commerce_customer_cancel_window_hours',
            'commerce_customer_subscription_self_service_enabled',
            'commerce_customer_subscription_pause_enabled',
            'commerce_customer_subscription_cancel_enabled',
            'commerce_store_name',
            'commerce_entry_sync_entry_id_meta', 'commerce_entry_sync_collection_meta',
            'commerce_entry_sync_consent_meta', 'commerce_entry_sync_order_field',
            'commerce_entry_sync_payment_field', 'commerce_entry_sync_session_field',
            'commerce_entry_sync_paid_value', 'commerce_entry_sync_abandoned_value',
            'activity_notify', 'activity_nav_dot',
        ] as $key) {
            $settings[$key] = commerce_get_setting($key, null);
        }
        if ($settings['activity_notify'] === null) {
            $settings['activity_notify'] = true;
        } else {
            $settings['activity_notify'] = !empty($settings['activity_notify']);
        }
        if ($settings['activity_nav_dot'] === null) {
            $settings['activity_nav_dot'] = true;
        } else {
            $settings['activity_nav_dot'] = !empty($settings['activity_nav_dot']);
        }
        if ($settings['commerce_fulfillment_sla_hours'] === null || (int) $settings['commerce_fulfillment_sla_hours'] < 1) {
            $settings['commerce_fulfillment_sla_hours'] = 48;
        } else {
            $settings['commerce_fulfillment_sla_hours'] = (int) $settings['commerce_fulfillment_sla_hours'];
        }
        if ($settings['commerce_customer_cancel_enabled'] === null) {
            $settings['commerce_customer_cancel_enabled'] = false;
        } else {
            $settings['commerce_customer_cancel_enabled'] = !empty($settings['commerce_customer_cancel_enabled']);
        }
        if ($settings['commerce_customer_cancel_window_hours'] === null) {
            $settings['commerce_customer_cancel_window_hours'] = 24;
        } else {
            $settings['commerce_customer_cancel_window_hours'] = max(0, (int) $settings['commerce_customer_cancel_window_hours']);
        }
        foreach ([
            'commerce_customer_subscription_self_service_enabled' => true,
            'commerce_customer_subscription_pause_enabled' => true,
            'commerce_customer_subscription_cancel_enabled' => true,
        ] as $subKey => $subDefault) {
            if ($settings[$subKey] === null) {
                $settings[$subKey] = $subDefault;
            } else {
                $settings[$subKey] = !empty($settings[$subKey]);
            }
        }
        if ($settings['commerce_tax_provider'] === null) {
            $settings['commerce_tax_provider'] = 'manual';
        }
        if ($settings['commerce_shipping_rate_provider'] === null) {
            $settings['commerce_shipping_rate_provider'] = 'manual';
        }
        if (!empty($settings['commerce_easypost_api_key'])) {
            $settings['commerce_easypost_api_key_set'] = true;
            $settings['commerce_easypost_api_key'] = '';
        } else {
            $settings['commerce_easypost_api_key_set'] = false;
        }
        if ($settings['enable_dashboard_widget'] === null) {
            $settings['enable_dashboard_widget'] = true;
        }
        if ($settings['dashboard_widget_roles'] === null) {
            $settings['dashboard_widget_roles'] = ['admin'];
        }
        if ($settings['dunning_email_enabled'] === null) {
            $settings['dunning_email_enabled'] = false;
        }
        if ($settings['dunning_email_subject'] === null) {
            $settings['dunning_email_subject'] = 'Action required: subscription payment failed';
        }
        if ($settings['dunning_email_body'] === null) {
            $settings['dunning_email_body'] = "Hello,\n\nWe were unable to process your subscription payment. Please update your payment method to avoid interruption.\n\nSubscription: {subscription_id}\nAmount: {amount}\n\nThank you.";
        }
        if ($settings['commerce_default_currency'] === null) {
            $settings['commerce_default_currency'] = commerce_get_default_currency();
        }
        if ($settings['commerce_display_currency'] === null) {
            $settings['commerce_display_currency'] = commerce_get_display_currency() ?? '';
        }
        if ($settings['commerce_stock_mode'] === null) {
            $settings['commerce_stock_mode'] = class_exists('InventoryLedger') ? InventoryLedger::currentMode() : 'simple';
        }
        if ($settings['commerce_fx_rates'] === null) {
            $rates = commerce_get_fx_rates();
            $settings['commerce_fx_rates'] = !empty($rates) ? json_encode($rates) : '';
        } elseif (is_array($settings['commerce_fx_rates'])) {
            $settings['commerce_fx_rates'] = json_encode($settings['commerce_fx_rates']);
        }
        if ($settings['commerce_store_name'] === null) {
            $settings['commerce_store_name'] = '';
        }
        echo json_encode(['status' => 'ok', 'data' => ['settings' => $settings]]);
        break;

    case 'save_settings':
        $settings = $input['settings'] ?? [];
        $allowed = [
            'selection_mode', 'default_provider', 'auto_rules', 'enable_dashboard_widget', 'dashboard_widget_roles',
            'dunning_email_enabled', 'dunning_email_subject', 'dunning_email_body', 'commerce_default_currency',
            'commerce_display_currency', 'commerce_fx_rates', 'commerce_stock_mode', 'commerce_tax_provider',
            'commerce_shipping_rate_provider', 'commerce_easypost_api_key', 'commerce_fulfillment_sla_hours',
            'commerce_customer_cancel_enabled', 'commerce_customer_cancel_window_hours',
            'commerce_customer_subscription_self_service_enabled',
            'commerce_customer_subscription_pause_enabled',
            'commerce_customer_subscription_cancel_enabled',
            'commerce_store_name',
            'commerce_entry_sync_entry_id_meta', 'commerce_entry_sync_collection_meta',
            'commerce_entry_sync_consent_meta', 'commerce_entry_sync_order_field',
            'commerce_entry_sync_payment_field', 'commerce_entry_sync_session_field',
            'commerce_entry_sync_paid_value', 'commerce_entry_sync_abandoned_value',
            'activity_notify', 'activity_nav_dot',
        ];
        $pluginId = commerce_active_plugin_id();
        foreach ($allowed as $key) {
            if (array_key_exists($key, $settings) && function_exists('set_plugin_setting')) {
                if ($key === 'commerce_stock_mode') {
                    InventoryLedger::saveMode((string) $settings[$key]);
                    continue;
                }
                if ($key === 'commerce_fulfillment_sla_hours') {
                    set_plugin_setting($pluginId, $key, max(1, (int) $settings[$key]));
                    continue;
                }
                if ($key === 'commerce_customer_cancel_enabled' || $key === 'activity_notify' || $key === 'activity_nav_dot'
                    || $key === 'commerce_customer_subscription_self_service_enabled'
                    || $key === 'commerce_customer_subscription_pause_enabled'
                    || $key === 'commerce_customer_subscription_cancel_enabled') {
                    set_plugin_setting($pluginId, $key, !empty($settings[$key]));
                    continue;
                }
                if ($key === 'commerce_customer_cancel_window_hours') {
                    set_plugin_setting($pluginId, $key, max(0, (int) $settings[$key]));
                    continue;
                }
                if ($key === 'commerce_store_name') {
                    set_plugin_setting($pluginId, $key, trim((string) $settings[$key]));
                    continue;
                }
                if (str_starts_with($key, 'commerce_entry_sync_')) {
                    set_plugin_setting($pluginId, $key, trim((string) $settings[$key]));
                    continue;
                }
                set_plugin_setting($pluginId, $key, $settings[$key]);
            }
        }
        if (array_key_exists('commerce_stock_mode', $settings)) {
            commerce_bootstrap_cart_services();
            $indexer = new CatalogIndexer();
            $warehouse = new WarehouseStockStore();
            $reservations = new StockReservationStore(commerce_data_dir(), $indexer, $warehouse);
            (new InventoryLedger(commerce_data_dir(), $indexer, $warehouse, $reservations))->reconcile(true);
        }
        if (function_exists('save_plugin_states')) {
            save_plugin_states();
        }
        echo json_encode(['status' => 'ok', 'message' => 'Settings saved']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Unknown action']);
}
