/**
 * Birkly Commerce storefront helper (plugin-owned).
 *
 * Auto-loaded via plugin.json storefront.scripts when Commerce is active.
 * Sites may still include manually (deprecated one release):
 *   <script src="/plugins/commerce/assets/commerce-storefront.js"></script>
 *
 * Minimal cart + split checkout API. Sites keep their own HTML/CSS; this file
 * handles the Commerce route contract so integrators do not reinvent cart UX.
 *
 * window.BirklyCommerce
 *   .api(action, payload?)
 *   .getCart()
 *   .add({ entry_id, collection, qty?, purchase_option_id?, amount_cents? })
 *   .update / .remove / .clear
 *   .checkout(fields)                 // auto-picks first group when split_required
 *   .continueSplitCheckout(fields?)   // after a group pays, start the next group
 *   .confirmPayment(stripe, elements) // Stripe Payment Element confirm
 *   .lookupOrder({ email, order_number })
 *   .cancelOrder({ email, order_number, reason? })  // policy-gated
 *   .bind(root?)                      // data-commerce-* auto wiring
 *   .money(cents, currency)
 *   .cartNeedsShipping(cart?) / .cartNeedsAttendee(cart?)
 *   .on(event, handler)
 */
(function (global) {
  'use strict';

  var SITE_SESSION_KEY = 'birkly_site_session_id';
  var COMMERCE_ROUTE = 'commerce';
  var listeners = {};
  var lastCart = null;
  var lastError = null;
  var split = {
    sessionId: null,
    groups: [],
    currentGroupKey: null,
    nextGroupKey: null,
    confirmMode: false
  };

  function getBirkly() {
    return global.Birkly || null;
  }

  function cmsBase() {
    var Birkly = getBirkly();
    var base = (Birkly && Birkly.cmsUrl) ? String(Birkly.cmsUrl) : '';
    return base.replace(/\/$/, '');
  }

  function withSiteSessionHeaders(headers) {
    headers = headers || {};
    try {
      var sid = localStorage.getItem(SITE_SESSION_KEY) || '';
      if (sid) {
        headers['X-Birkly-Site-Session'] = sid;
      }
    } catch (e) { /* ignore */ }
    return headers;
  }

  function captureSiteSession(json) {
    if (json && json.site_session_id) {
      try {
        localStorage.setItem(SITE_SESSION_KEY, String(json.site_session_id));
      } catch (e) { /* ignore */ }
    }
  }

  function credentialedFetch(url, opts) {
    opts = opts || {};
    opts.credentials = 'include';
    opts.headers = withSiteSessionHeaders(Object.assign({ Accept: 'application/json' }, opts.headers || {}));
    return fetch(url, opts);
  }

  function routeFetch(opts) {
    var Birkly = getBirkly();
    if (Birkly && typeof Birkly.routeFetch === 'function') {
      return Birkly.routeFetch(opts);
    }
    if (Birkly && typeof Birkly.fetch === 'function') {
      return Birkly.fetch(opts);
    }

    var route = String(opts.route || '').trim();
    var action = String(opts.action || '').trim();
    var method = String(opts.method || 'GET').toUpperCase();
    var url = cmsBase() + '/api/index.php?route=' + encodeURIComponent(route)
      + '&action=' + encodeURIComponent(action);
    var headers = Object.assign({ Accept: 'application/json' }, opts.headers || {});
    var fetchOpts = { method: method, credentials: 'include', headers: withSiteSessionHeaders(headers) };

    if (opts.params && typeof opts.params === 'object' && method === 'GET') {
      Object.keys(opts.params).forEach(function (key) {
        var val = opts.params[key];
        if (val !== undefined && val !== null) {
          url += '&' + encodeURIComponent(key) + '=' + encodeURIComponent(String(val));
        }
      });
    }

    if (opts.body !== undefined && method !== 'GET' && method !== 'HEAD') {
      if (opts.body instanceof FormData) {
        fetchOpts.body = opts.body;
      } else if (typeof opts.body === 'string') {
        fetchOpts.body = opts.body;
      } else {
        if (!headers['Content-Type'] && !headers['content-type']) {
          headers['Content-Type'] = 'application/json';
        }
        fetchOpts.body = JSON.stringify(opts.body);
      }
    }

    return credentialedFetch(url, fetchOpts).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (json) {
        captureSiteSession(json);
        if (!res.ok && opts.throwOnError !== false) {
          var err = new Error((json && (json.error || json.message)) || ('HTTP ' + res.status));
          err.status = res.status;
          err.response = json;
          throw err;
        }
        return json;
      });
    });
  }

  function emit(name, detail) {
    (listeners[name] || []).forEach(function (fn) {
      try { fn(detail); } catch (e) { console.error('[BirklyCommerce]', e); }
    });
  }

  function on(name, handler) {
    if (!listeners[name]) listeners[name] = [];
    listeners[name].push(handler);
    return function off() {
      listeners[name] = (listeners[name] || []).filter(function (fn) { return fn !== handler; });
    };
  }

  function clearError() {
    lastError = null;
  }

  function money(cents, currency) {
    var amount = (Number(cents) || 0) / 100;
    var cur = String(currency || 'eur').toUpperCase();
    try {
      return new Intl.NumberFormat(undefined, { style: 'currency', currency: cur }).format(amount);
    } catch (e) {
      return cur + ' ' + amount.toFixed(2);
    }
  }

  function api(action, payload, method) {
    var upper = String(method || 'POST').toUpperCase();
    var opts = {
      route: COMMERCE_ROUTE,
      action: action,
      method: upper,
      throwOnError: false
    };
    if (upper === 'GET') {
      opts.params = Object.assign({}, payload || {});
      opts.headers = { Accept: 'application/json' };
    } else {
      opts.body = Object.assign({ action: action }, payload || {});
      opts.headers = { Accept: 'application/json', 'Content-Type': 'application/json' };
    }
    return routeFetch(opts).then(parseCommerceJson);
  }

  function parseCommerceJson(json) {
    var data = json && json.data != null ? json.data : json;
    if (json && json.status === 'error') {
      var err = new Error((json && (json.message || (data && data.error))) || 'Commerce request failed');
      err.status = json.status_code || 400;
      err.payload = data;
      err.response = json;
      lastError = err;
      throw err;
    }
    clearError();
    return data;
  }

  function resetSplitState() {
    split.sessionId = null;
    split.groups = [];
    split.currentGroupKey = null;
    split.nextGroupKey = null;
    split.confirmMode = false;
  }

  function rememberSplitFromPayload(data) {
    if (!data) return;
    if (data.checkout_session_id) split.sessionId = data.checkout_session_id;
    if (Array.isArray(data.groups)) split.groups = data.groups;
    if (Array.isArray(data.remaining_groups)) split.groups = data.remaining_groups;
    // Keep currentGroupKey on the group being paid; stash next separately.
    if (data.group_key) {
      split.currentGroupKey = data.group_key;
    } else if (data.current_group_key) {
      split.currentGroupKey = data.current_group_key;
    }
    if (Object.prototype.hasOwnProperty.call(data, 'next_group_key')) {
      split.nextGroupKey = data.next_group_key || null;
    }
    if (data.needs_split || data.split_required) {
      split.confirmMode = true;
    }
    if (data.needs_split === false && !data.split_required && (!data.remaining_groups || data.remaining_groups.length === 0)) {
      if (!data.next_group_key) {
        split.confirmMode = false;
        split.nextGroupKey = null;
      }
    }
  }

  function rememberCart(data) {
    lastCart = data || null;
    if (!data) return data;
    rememberSplitFromPayload(data);
    if (data.split_required && data.checkout_draft && data.checkout_draft.email) {
      split.confirmMode = true;
    }
    if (!data.split_required && (!data.groups || data.groups.length <= 1)) {
      split.confirmMode = false;
      split.nextGroupKey = null;
    }
    emit('cart', data);
    return data;
  }

  function lineFulfillment(line) {
    return String((line && line.fulfillment) || '').toLowerCase();
  }

  function cartNeedsShipping(cart) {
    var c = cart || lastCart;
    var lines = (c && (c.items || c.lines)) || [];
    for (var i = 0; i < lines.length; i++) {
      if (lineFulfillment(lines[i]) === 'ship') return true;
      var comps = lines[i].components || [];
      for (var j = 0; j < comps.length; j++) {
        if (lineFulfillment(comps[j]) === 'ship') return true;
      }
    }
    return false;
  }

  function cartNeedsAttendee(cart) {
    var c = cart || lastCart;
    var lines = (c && (c.items || c.lines)) || [];
    for (var i = 0; i < lines.length; i++) {
      if (lineFulfillment(lines[i]) === 'register') return true;
      var comps = lines[i].components || [];
      for (var j = 0; j < comps.length; j++) {
        if (lineFulfillment(comps[j]) === 'register') return true;
      }
    }
    return false;
  }

  function syncCheckoutFieldVisibility(scope) {
    var root = scope || document;
    var needsShip = cartNeedsShipping();
    var needsAttendee = cartNeedsAttendee();
    qsa('[data-commerce-shipping-fields]', root).forEach(function (el) {
      el.hidden = !needsShip;
      el.setAttribute('aria-hidden', needsShip ? 'false' : 'true');
      qsa('input, select, textarea', el).forEach(function (input) {
        if (!needsShip) input.removeAttribute('required');
      });
    });
    qsa('[data-commerce-attendee-fields]', root).forEach(function (el) {
      el.hidden = !needsAttendee;
      el.setAttribute('aria-hidden', needsAttendee ? 'false' : 'true');
      qsa('input, select, textarea', el).forEach(function (input) {
        if (needsAttendee) {
          if (input.getAttribute('data-commerce-required') === '1') input.required = true;
        } else {
          input.removeAttribute('required');
        }
      });
    });
  }

  function getCart() {
    return api('get', {}, 'GET').then(function (data) {
      rememberCart(data);
      syncCheckoutFieldVisibility(document);
      return data;
    });
  }

  /**
   * Persist checkout draft fields (shipping/email/VAT) and return a re-quoted cart
   * with subtotal / shipping_cents / tax_cents for storefront totals UI.
   */
  function setCheckoutDraft(fields) {
    return api('set_checkout_draft', fields || {}).then(function (data) {
      rememberCart(data);
      syncCheckoutFieldVisibility(document);
      return data;
    });
  }

  function catalogItem(entryId, collection, extra) {
    return api('catalog_item', Object.assign({
      entry_id: entryId,
      collection: collection
    }, extra || {}), 'GET');
  }

  /**
   * Server-side linked entry + hosted checkout (P70 begin_linked_checkout).
   */
  function beginLinkedCheckout(payload) {
    return api('begin_linked_checkout', payload || {}).then(function (data) {
      if (data && data.order_id) {
        try { sessionStorage.setItem('birkly_commerce_order_id', String(data.order_id)); } catch (e) { /* ignore */ }
      }
      emit('linked_checkout', data);
      return data;
    });
  }

  function uploadLinkedCheckoutAsset(file, fieldName) {
    var fd = new FormData();
    fd.append('action', 'upload_linked_checkout_asset');
    fd.append('field', fieldName || 'file');
    fd.append('file', file);
    return routeFetch({
      route: COMMERCE_ROUTE,
      action: 'upload_linked_checkout_asset',
      method: 'POST',
      headers: { Accept: 'application/json' },
      body: fd,
      throwOnError: false
    }).then(parseCommerceJson);
  }

  function uploadLinkedCheckoutAssetsFromForm(form) {
    var inputs = form ? form.querySelectorAll('input[type="file"][name]') : [];
    var jobs = [];
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      if (!input.files || !input.files[0]) continue;
      (function (inp) {
        jobs.push(uploadLinkedCheckoutAsset(inp.files[0], inp.name).then(function (data) {
          return { field: (data && data.field) || inp.name, url: data && data.url };
        }));
      })(input);
    }
    if (!jobs.length) return Promise.resolve({});
    return Promise.all(jobs).then(function (rows) {
      var fields = {};
      rows.forEach(function (row) {
        if (row && row.field && row.url) fields[row.field] = row.url;
      });
      return fields;
    });
  }

  function abandonCheckout(orderId, email) {
    var payload = { order_id: orderId || '' };
    if (email) payload.email = email;
    return api('abandon_checkout', payload).then(function (data) {
      try { sessionStorage.removeItem('birkly_commerce_order_id'); } catch (e) { /* ignore */ }
      emit('checkout_abandoned', data);
      return data;
    });
  }

  function absoluteUrl(pathOrUrl) {
    if (!pathOrUrl) return '';
    if (/^https?:\/\//i.test(pathOrUrl)) return pathOrUrl;
    if (pathOrUrl.charAt(0) === '/') return location.origin + pathOrUrl;
    var path = location.pathname || '/';
    var dir = path.slice(0, path.lastIndexOf('/') + 1) || '/';
    return location.origin + dir + pathOrUrl;
  }

  function clearHostedCheckoutQuery() {
    var params = new URLSearchParams(location.search);
    params.delete('canceled');
    params.delete('commerce_cancel');
    params.delete('session_id');
    params.delete('commerce_order');
    var qs = params.toString();
    history.replaceState(null, '', location.pathname + (qs ? '?' + qs : '') + location.hash);
  }

  function getActiveCadenceButton(form) {
    if (!form) return null;
    var buttons = form.querySelectorAll('[data-commerce-cadence], [data-donate-cadence]');
    var pressed = [];
    var active = [];
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      if (btn.getAttribute('aria-pressed') === 'true') pressed.push(btn);
      if (btn.classList.contains('is-active')) active.push(btn);
    }
    if (pressed.length === 1) return pressed[0];
    if (active.length === 1) return active[0];
    if (pressed.length > 1) return pressed[pressed.length - 1];
    if (active.length > 1) return active[active.length - 1];
    return pressed[0] || active[0] || null;
  }

  function cadenceToPurchaseOptionId(form, cadence) {
    if (cadence === 'month' || cadence === 'monthly' || cadence === 'recurring') {
      return form.getAttribute('data-recurring-option-id') || 'monthly';
    }
    return form.getAttribute('data-onetime-option-id') || 'once';
  }

  function syncPurchaseOptionHiddenField(form) {
    if (!form) return;
    var input = form.querySelector('[data-commerce-purchase-option-id], input[name="purchase_option_id"]');
    if (!input) return;
    var optionId = readPurchaseOptionIdFromForm(form);
    if (optionId) input.value = optionId;
  }

  function readPurchaseOptionIdFromForm(form) {
    var fd = new FormData(form);
    var cadenceBtn = getActiveCadenceButton(form);
    if (cadenceBtn) {
      var cadence = cadenceBtn.getAttribute('data-commerce-cadence') || cadenceBtn.getAttribute('data-donate-cadence') || '';
      return cadenceToPurchaseOptionId(form, cadence);
    }

    var fromField = String(fd.get('purchase_option_id') || '').trim();
    if (fromField) return fromField;

    var po = getPurchaseOptionState();
    if (po.optionId) return po.optionId;
    return '';
  }

  function readAmountCentsFromForm(form) {
    var sel = form.querySelector('[data-commerce-amount-select], #amount-select');
    if (sel) {
      var euros;
      if (sel.value === 'custom') {
        var custom = form.querySelector('[data-commerce-custom-amount], #custom-amount');
        euros = parseFloat(custom && custom.value) || 0;
        if (!isFinite(euros) || euros <= 0) return null;
        return Math.round(euros * 100);
      }
      euros = parseFloat(sel.value) || 0;
      if (isFinite(euros) && euros > 0) return Math.round(euros * 100);
    }
    var po = getPurchaseOptionState();
    if (po.amountCents != null) return po.amountCents;
    var fd = new FormData(form);
    var centsRaw = fd.get('amount_cents');
    if (centsRaw != null && String(centsRaw).trim() !== '') return Number(centsRaw);
    var eurosField = fd.get('amount');
    if (eurosField != null && String(eurosField).trim() !== '') {
      var n = parseFloat(String(eurosField).replace(',', '.'));
      if (isFinite(n) && n > 0) return Math.round(n * 100);
    }
    return null;
  }

  function linkedFieldsFromForm(form) {
    var fd = new FormData(form);
    var contactName = String(fd.get('contact_name') || fd.get('name') || '').trim();
    var displayName = String(fd.get('display_name') || fd.get('title') || '').trim();
    var email = String(fd.get('email') || '').trim();
    var kind = String(fd.get('kind') || 'person').trim();
    var organization = String(fd.get('organization') || '').trim();
    var consentField = form.getAttribute('data-consent-field') || 'featured';
    var consentRaw = fd.get(consentField) || fd.get('show') || fd.get('show_public') || fd.get('featured');
    var consented = consentRaw === 'yes' || consentRaw === '1' || consentRaw === 'on' || consentRaw === true;
    if (!displayName) displayName = contactName || 'Anonymous supporter';
    var title = String(fd.get('title') || displayName).trim() || displayName;
    var fields = {
      title: title,
      email: email,
      contact_name: contactName,
      display_name: displayName,
      kind: kind,
      organization: organization,
      featured: consented ? '1' : '',
      show_public: consented ? '1' : '',
      payment_status: 'pending'
    };
    var cadenceBtn = form.querySelector('[data-commerce-cadence].is-active, [data-donate-cadence].is-active');
    if (cadenceBtn) {
      var cadence = cadenceBtn.getAttribute('data-commerce-cadence') || cadenceBtn.getAttribute('data-donate-cadence') || '';
      fields.cadence = cadence === 'month' || cadence === 'monthly' ? 'month' : 'one_time';
    } else if (fd.get('cadence')) {
      fields.cadence = String(fd.get('cadence'));
    }
    var amountCents = readAmountCentsFromForm(form);
    if (amountCents != null) fields.amount = String(amountCents / 100);
    var reserved = {
      title: true,
      email: true,
      contact_name: true,
      name: true,
      display_name: true,
      kind: true,
      organization: true,
      featured: true,
      show: true,
      show_public: true,
      cadence: true,
      amount: true,
      payment_status: true,
      success_url: true,
      cancel_url: true,
      collection: true,
      entry_id: true,
      purchase_option_id: true,
      custom_amount: true
    };
    fd.forEach(function (value, key) {
      if (!key || reserved[key] || fields[key] !== undefined) return;
      if (value instanceof File) return;
      var text = String(value).trim();
      if (text === '') return;
      fields[key] = text;
    });
    return fields;
  }

  function bindLinkedCheckoutForm(form) {
    if (!form || form.getAttribute('data-commerce-linked-bound') === '1') return;
    form.setAttribute('data-commerce-linked-bound', '1');
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var status = qs('[data-commerce-status]', form)
        || qs('[data-commerce-linked-status]', form)
        || qs('#donate-error', form);
      var collection = form.getAttribute('data-product-collection') || '';
      var entry = form.getAttribute('data-product-entry') || '';
      var linkedCollection = form.getAttribute('data-linked-collection') || '';
      if (!collection || !entry) {
        setStatus(status, 'Checkout is missing product configuration.', true);
        return;
      }
      var fd = new FormData(form);
      var email = String(fd.get('email') || '').trim();
      var name = String(fd.get('name') || fd.get('contact_name') || '').trim();
      if (!email) {
        setStatus(status, 'Please enter your email.', true);
        return;
      }
      if (!name) {
        setStatus(status, 'Please enter your name.', true);
        return;
      }
      var consentField = form.getAttribute('data-consent-field') || 'featured';
      var consented = (function () {
        var v = fd.get(consentField) || fd.get('show') || fd.get('featured');
        return v === 'yes' || v === '1' || v === 'on';
      })();
      var displayName = String(fd.get('display_name') || '').trim();
      if (consented && !displayName && !name) {
        setStatus(status, 'Please enter a display name for the public list.', true);
        return;
      }
      var purchaseOptionId = readPurchaseOptionIdFromForm(form);
      syncPurchaseOptionHiddenField(form);
      var amountCents = readAmountCentsFromForm(form);
      if (!purchaseOptionId) {
        setStatus(status, 'Select a purchase option.', true);
        return;
      }
      if (amountCents == null || amountCents <= 0) {
        setStatus(status, 'Enter a valid amount.', true);
        return;
      }
      var submit = form.querySelector('[type="submit"]');
      var submitLabel = submit ? submit.textContent : '';
      if (submit) { submit.disabled = true; submit.textContent = 'Opening payment…'; }
      setStatus(status, '', false);
      clearError();
      var payload = {
        product: {
          collection: collection,
          entry_id: entry,
          purchase_option_id: purchaseOptionId,
          amount_cents: amountCents
        },
        customer: { email: email, name: name },
        hosted_checkout: form.getAttribute('data-hosted-checkout') !== '0',
        success_url: absoluteUrl(form.getAttribute('data-success-url') || fd.get('success_url') || 'thank-you.html'),
        cancel_url: absoluteUrl(form.getAttribute('data-cancel-url') || fd.get('cancel_url') || (location.pathname + '?canceled=1'))
      };
      ['signup_flow_id', 'signup_flow_session_id', 'signup_flow_opt_in', 'club_opt_in'].forEach(function (key) {
        var raw = fd.get(key);
        if (raw != null && String(raw).trim() !== '') {
          payload.metadata = payload.metadata || {};
          payload.metadata[key] = String(raw).trim();
        }
      });
      if (payload.metadata && payload.metadata.club_opt_in && !payload.metadata.signup_flow_opt_in) {
        payload.metadata.signup_flow_opt_in = payload.metadata.club_opt_in;
      }
      uploadLinkedCheckoutAssetsFromForm(form).then(function (assetFields) {
        if (linkedCollection) {
          payload.linked_entry = {
            collection: linkedCollection,
            fields: Object.assign({}, linkedFieldsFromForm(form), assetFields || {}),
            consent_field: consentField
          };
        }
        return beginLinkedCheckout(payload);
      }).then(function (data) {
        if (data.redirect_url) {
          location.href = data.redirect_url;
          return;
        }
        throw new Error((data && data.error) || 'Checkout did not return a payment URL.');
      }).catch(function (err) {
        var msg = err && err.message ? err.message : 'Checkout failed';
        if (/not in catalog/i.test(msg)) {
          msg = 'Product is not in the Commerce catalog. Re-save it in admin or Rebuild catalog.';
        } else if (/Payments not configured/i.test(msg)) {
          msg = 'Card checkout needs a payment connection in CMS admin → Commerce → Connections.';
        } else         if (/minimum/i.test(msg)) {
          msg = msg;
        } else if (/upload/i.test(msg) || /file too large/i.test(msg) || /invalid file/i.test(msg)) {
          msg = msg;
        }
        setStatus(status, msg, true);
        emit('error', err);
        if (submit) { submit.disabled = false; submit.textContent = submitLabel || 'Continue to payment'; }
      });
    });
  }

  /**
   * On cancel return URLs, abandon the pending order; on success, confirm payment locally.
   */
  function handleHostedCheckoutReturn() {
    var params = new URLSearchParams(location.search);
    var canceled = params.get('canceled') === '1';
    var cancelParam = params.get('commerce_cancel') || '';
    if (canceled || cancelParam) {
      var orderId = cancelParam;
      try { orderId = orderId || sessionStorage.getItem('birkly_commerce_order_id') || ''; } catch (e) { /* ignore */ }
      if (!orderId) {
        clearHostedCheckoutQuery();
        return Promise.resolve(null);
      }
      return abandonCheckout(orderId).finally(function () {
        clearHostedCheckoutQuery();
      });
    }
    return confirmHostedCheckoutReturn().then(function (result) {
      if (result) clearHostedCheckoutQuery();
      return result;
    });
  }

  function mountConfirmReturn(el) {
    if (!el || el.getAttribute('data-commerce-confirm-bound') === '1') return;
    el.setAttribute('data-commerce-confirm-bound', '1');
    handleHostedCheckoutReturn().then(function (result) {
      if (!result) return;
      el.hidden = false;
      el.removeAttribute('hidden');
      if (!el.textContent.trim()) {
        el.textContent = 'Thank you — your payment is confirmed.';
      }
      emit('hosted_return', result);
    });
  }

  function wireCadenceToggles(scope) {
    qsa('[data-commerce-cadence], [data-donate-cadence]', scope).forEach(function (btn) {
      if (btn.getAttribute('data-commerce-cadence-bound') === '1') return;
      btn.setAttribute('data-commerce-cadence-bound', '1');
      btn.addEventListener('click', function () {
        var form = btn.closest('form');
        var group = btn.parentElement;
        if (group) {
          qsa('[data-commerce-cadence], [data-donate-cadence]', group).forEach(function (b) {
            b.classList.toggle('is-active', b === btn);
            b.setAttribute('aria-pressed', b === btn ? 'true' : 'false');
          });
        }
        if (form) {
          var optionId = readPurchaseOptionIdFromForm(form);
          var amountCents = readAmountCentsFromForm(form);
          if (optionId) setPurchaseOptionState(optionId, amountCents, purchaseOptionState.currency);
          syncPurchaseOptionHiddenField(form);
        }
      });
    });
  }

  function wireAmountSelect(scope) {
    scope = scope || document;
    var sel = scope.querySelector ? scope.querySelector('[data-commerce-amount-select], #amount-select') : null;
    if (!sel || sel.getAttribute('data-commerce-amount-bound') === '1') return;
    sel.setAttribute('data-commerce-amount-bound', '1');
    var form = sel.closest('form');
    function sync() {
      var wrap = scope.querySelector ? scope.querySelector('#custom-amount-wrap, [data-commerce-custom-wrap]') : null;
      if (wrap) wrap.style.display = sel.value === 'custom' ? '' : 'none';
      if (form) {
        var optionId = readPurchaseOptionIdFromForm(form);
        var amountCents = readAmountCentsFromForm(form);
        if (optionId && amountCents != null) {
          setPurchaseOptionState(optionId, amountCents, purchaseOptionState.currency);
        } else if (sel.value === 'custom') {
          purchaseOptionState.amountCents = null;
        }
      }
    }
    sel.addEventListener('change', sync);
    var custom = scope.querySelector('[data-commerce-custom-amount], #custom-amount');
    if (custom) custom.addEventListener('input', sync);
    sync();
  }

  var purchaseOptionState = {
    optionId: null,
    amountCents: null,
    currency: 'eur'
  };

  function getPurchaseOptionState() {
    return Object.assign({}, purchaseOptionState);
  }

  function setPurchaseOptionState(optionId, amountCents, currency) {
    purchaseOptionState.optionId = optionId;
    purchaseOptionState.amountCents = amountCents;
    purchaseOptionState.currency = currency || purchaseOptionState.currency;
    emit('purchase_option', getPurchaseOptionState());
  }

  function syncPurchaseOptionInputs(form, state) {
    if (!form) return;
    var optInput = form.querySelector('[name="purchase_option_id"], [data-commerce-purchase-option-id]');
    var amtInput = form.querySelector('[name="amount_cents"], [data-commerce-amount-cents]');
    if (optInput) optInput.value = state.optionId || '';
    if (amtInput) amtInput.value = state.amountCents != null ? String(state.amountCents) : '';
  }

  function mountPurchaseOptions(host) {
    if (!host || host.getAttribute('data-commerce-po-bound') === '1') return Promise.resolve(null);
    host.setAttribute('data-commerce-po-bound', '1');
    var collection = host.getAttribute('data-product-collection') || host.getAttribute('data-collection') || '';
    var entryId = host.getAttribute('data-product-entry') || host.getAttribute('data-entry-id') || '';
    if (!collection || !entryId) {
      host.textContent = 'Purchase options: missing product attributes.';
      return Promise.resolve(null);
    }
    host.innerHTML = '<p class="commerce-po-loading">Loading options…</p>';
  return catalogItem(entryId, collection).then(function (data) {
      var item = data || {};
      var options = item.purchase_options || [];
      var currency = item.currency || 'eur';
      if (!options.length) {
        host.innerHTML = '<p class="commerce-po-empty">No purchase options configured.</p>';
        return null;
      }
      var form = host.closest('form');
      var html = '<div class="commerce-purchase-options" role="radiogroup">';
      options.forEach(function (opt, idx) {
        var id = String(opt.id || ('opt_' + (idx + 1)));
        var label = String(opt.label || id);
        var checked = idx === 0 ? ' checked' : '';
        var amount = Number(opt.display_amount_cents != null ? opt.display_amount_cents : opt.price_cents) || 0;
        var custom = !!opt.allows_custom_amount;
        var min = Number(opt.min_price_cents) || 0;
        var max = opt.max_price_cents != null ? Number(opt.max_price_cents) : null;
        var recurring = !!opt.is_recurring;
        var interval = opt.interval ? ' / ' + opt.interval : '';
        html += '<label class="commerce-po-option">';
        html += '<input type="radio" name="commerce_purchase_option" value="' + id + '" data-amount="' + amount + '" data-custom="' + (custom ? '1' : '0') + '" data-min="' + min + '" data-max="' + (max != null ? max : '') + '"' + checked + '>';
        html += '<span class="commerce-po-label">' + label + (recurring ? interval : '') + '</span>';
        if (!custom) {
          html += '<span class="commerce-po-price">' + money(amount, currency) + '</span>';
        }
        html += '</label>';
        if (custom) {
          html += '<div class="commerce-po-custom" data-for-option="' + id + '" hidden>';
          html += '<label>Amount <input type="number" min="' + (min / 100).toFixed(2) + '" step="0.01" data-commerce-custom-amount value="' + ((Number(opt.suggested_amount_cents) || min) / 100).toFixed(2) + '"></label>';
          if (max != null) {
            html += '<span class="commerce-po-hint">Max ' + money(max, currency) + '</span>';
          }
          html += '</div>';
        }
      });
      html += '</div>';
      html += '<p class="commerce-po-error" data-commerce-po-error hidden></p>';
      host.innerHTML = html;

      function selectedRadio() {
        return host.querySelector('input[name="commerce_purchase_option"]:checked');
      }

      function readAmountCents(radio) {
        if (!radio) return 0;
        var custom = radio.getAttribute('data-custom') === '1';
        if (!custom) return Number(radio.getAttribute('data-amount')) || 0;
        var wrap = host.querySelector('.commerce-po-custom[data-for-option="' + radio.value + '"]');
        var input = wrap ? wrap.querySelector('[data-commerce-custom-amount]') : null;
        var euros = input ? parseFloat(String(input.value).replace(',', '.')) : 0;
        if (!isFinite(euros) || euros < 0) euros = 0;
        return Math.round(euros * 100);
      }

      function validateSelection() {
        var radio = selectedRadio();
        var errEl = host.querySelector('[data-commerce-po-error]');
        if (!radio) {
          if (errEl) { errEl.hidden = false; errEl.textContent = 'Select a purchase option.'; }
          return false;
        }
        var min = Number(radio.getAttribute('data-min')) || 0;
        var maxRaw = radio.getAttribute('data-max');
        var max = maxRaw !== '' && maxRaw != null ? Number(maxRaw) : null;
        var cents = readAmountCents(radio);
        if (cents < min) {
          if (errEl) { errEl.hidden = false; errEl.textContent = 'Amount is below the minimum (' + money(min, currency) + ').'; }
          return false;
        }
        if (max != null && cents > max) {
          if (errEl) { errEl.hidden = false; errEl.textContent = 'Amount is above the maximum (' + money(max, currency) + ').'; }
          return false;
        }
        if (errEl) { errEl.hidden = true; errEl.textContent = ''; }
        setPurchaseOptionState(radio.value, cents, currency);
        syncPurchaseOptionInputs(form, getPurchaseOptionState());
        return true;
      }

      function toggleCustomPanels() {
        var radio = selectedRadio();
        qsa('.commerce-po-custom', host).forEach(function (panel) {
          panel.hidden = !radio || panel.getAttribute('data-for-option') !== radio.value;
        });
      }

      host.addEventListener('change', function (ev) {
        if (ev.target && ev.target.name === 'commerce_purchase_option') {
          toggleCustomPanels();
          validateSelection();
        }
      });
      host.addEventListener('input', function (ev) {
        if (ev.target && ev.target.hasAttribute('data-commerce-custom-amount')) {
          validateSelection();
        }
      });

      toggleCustomPanels();
      validateSelection();
      return getPurchaseOptionState();
    }).catch(function (err) {
      host.innerHTML = '<p class="commerce-po-error">' + (err.message || 'Could not load purchase options') + '</p>';
      emit('error', err);
      return null;
    });
  }

  /**
   * Build HTML rows for cart/checkout money breakdown.
   * Sites can inject into [data-commerce-totals] or pass their own host.
   */
  function renderMoneyRows(cart, currency) {
    var c = cart || lastCart || {};
    var cur = currency || c.currency || 'eur';
    var items = c.items || c.lines || [];
    var subtotal = c.subtotal_cents;
    if (subtotal == null) {
      subtotal = 0;
      for (var i = 0; i < items.length; i++) {
        subtotal += Number(items[i].line_total_cents) || 0;
      }
    }
    var shipping = Number(c.shipping_cents) || 0;
    var tax = Number(c.tax_cents) || 0;
    var taxAdd = c.tax_add_cents != null ? Number(c.tax_add_cents) : tax;
    var discount = Number(c.discount_cents) || 0;
    var pricesIncludeTax = !!(c.prices_include_tax || c.tax_included);
    var total = c.total_cents != null
      ? Number(c.total_cents)
      : (subtotal + shipping + taxAdd);
    var rows = '';
    rows += '<div class="commerce-money-row" data-money="subtotal"><span>Subtotal</span><strong>'
      + money(subtotal, cur) + '</strong></div>';
    if (discount > 0) {
      rows += '<div class="commerce-money-row" data-money="discount"><span>Discount</span><strong>−'
        + money(discount, cur) + '</strong></div>';
    }
    if (shipping > 0 || cartNeedsShipping(c) || c.free_shipping_unlocked) {
      var shipLabel = c.free_shipping_unlocked ? 'Free shipping' : 'Shipping';
      rows += '<div class="commerce-money-row" data-money="shipping"><span>' + shipLabel + '</span><strong>'
        + (shipping > 0 ? money(shipping, cur) : (c.free_shipping_unlocked ? money(0, cur) : '—')) + '</strong></div>';
    }
    var remain = Number(c.free_shipping_remaining_cents) || 0;
    var minFree = Number(c.free_shipping_min_cents) || 0;
    if (minFree > 0 && remain > 0 && cartNeedsShipping(c) && !c.free_shipping_unlocked) {
      rows += '<div class="commerce-money-row commerce-money-hint" data-money="free-shipping-progress"><span>'
        + money(remain, cur) + ' away from free shipping</span><strong></strong></div>';
    }
    if (tax > 0 || (Array.isArray(c.tax_lines) && c.tax_lines.length)) {
      var taxLabel = pricesIncludeTax ? 'Tax (included)' : 'Tax';
      if (c.tax_country) {
        taxLabel = pricesIncludeTax
          ? 'Tax included (' + String(c.tax_country).toUpperCase() + ')'
          : 'Tax (' + String(c.tax_country).toUpperCase() + ')';
      }
      rows += '<div class="commerce-money-row" data-money="tax"><span>' + taxLabel + '</span><strong>'
        + money(tax, cur) + '</strong></div>';
    }
    rows += '<div class="commerce-money-row commerce-money-total" data-money="total"><span>Total</span><strong>'
      + money(total, cur) + '</strong></div>';
    return rows;
  }

  function fillMoneyHosts(scope, cart) {
    var root = scope || document;
    var html = renderMoneyRows(cart);
    qsa('[data-commerce-totals], [data-cart-totals]', root).forEach(function (el) {
      el.innerHTML = html;
    });
  }

  function add(item) {
    return api('add', item || {}).then(function (data) {
      rememberCart(data);
      syncCheckoutFieldVisibility(document);
      return data;
    });
  }

  function update(item) {
    return api('update', item || {}).then(function (data) {
      rememberCart(data);
      syncCheckoutFieldVisibility(document);
      return data;
    });
  }

  function remove(item) {
    return api('remove', item || {}).then(function (data) {
      rememberCart(data);
      syncCheckoutFieldVisibility(document);
      return data;
    });
  }

  function clear() {
    return api('clear', {}).then(function (data) {
      resetSplitState();
      clearError();
      rememberCart(data);
      syncCheckoutFieldVisibility(document);
      return data;
    });
  }

  function checkoutFieldsFromForm(form) {
    if (!form) return {};
    var fd = new FormData(form);
    var shipping = null;
    function first() {
      for (var i = 0; i < arguments.length; i++) {
        var v = fd.get(arguments[i]);
        if (v != null && String(v).trim() !== '') return String(v);
      }
      return '';
    }
    var name = first('shipping_name', 'ship_name', 'name');
    var line1 = first('shipping_line1', 'shipping_address', 'ship_line1', 'ship_address', 'address', 'line1');
    var city = first('shipping_city', 'ship_city', 'city');
    var postal = first('shipping_postal_code', 'ship_postal', 'postal_code', 'zip');
    var country = first('shipping_country', 'ship_country', 'country');
    if (name || line1 || city || postal || country) {
      shipping = {
        name: name,
        line1: line1,
        city: city,
        postal_code: postal,
        country: country
      };
    }
    var vatId = first('vat_id', 'tax_id', 'vat', 'eu_vat');
    var fields = {
      email: String(fd.get('email') || ''),
      attendee_name: String(fd.get('attendee_name') || ''),
      shipping_address: shipping,
      return_url: String(fd.get('return_url') || (location.origin + location.pathname + '?checkout=success')),
      cancel_url: String(fd.get('cancel_url') || (location.origin + location.pathname + '?checkout=cancel'))
    };
    if (vatId) {
      fields.vat_id = vatId;
      fields.tax_id = vatId;
    }
    // Omit empty attendee so draft values can fill register-only continues.
    if (!fields.attendee_name) delete fields.attendee_name;
    if (!cartNeedsShipping() && shipping) {
      // Keep address for tax when present, but never invent one.
      fields.shipping_address = shipping;
    }
    if (!cartNeedsShipping() && !shipping) {
      delete fields.shipping_address;
    }
    return fields;
  }

  /**
   * When tax is enabled, ensure checkout forms expose an optional VAT ID field (B2B reverse charge).
   */
  function ensureVatIdField(form) {
    if (!form) return;
    if (form.querySelector('[name="vat_id"], [name="tax_id"], [data-commerce-vat-id]')) return;
    var wrap = document.createElement('div');
    wrap.className = 'commerce-vat-id-field';
    wrap.setAttribute('data-commerce-vat-id', '1');
    var label = document.createElement('label');
    label.textContent = 'VAT ID (optional, B2B)';
    var input = document.createElement('input');
    input.type = 'text';
    input.name = 'vat_id';
    input.autocomplete = 'off';
    input.placeholder = 'e.g. DE123456789';
    wrap.appendChild(label);
    wrap.appendChild(input);
    var submit = form.querySelector('[type="submit"], button');
    if (submit && submit.parentNode === form) {
      form.insertBefore(wrap, submit);
    } else {
      form.appendChild(wrap);
    }
  }

  function ensureAttendeeField(form) {
    if (!form || !cartNeedsAttendee()) return;
    if (form.querySelector('[name="attendee_name"], [data-commerce-attendee-fields]')) return;
    var wrap = document.createElement('div');
    wrap.className = 'commerce-attendee-field';
    wrap.setAttribute('data-commerce-attendee-fields', '1');
    var label = document.createElement('label');
    label.textContent = 'Attendee name';
    var input = document.createElement('input');
    input.type = 'text';
    input.name = 'attendee_name';
    input.autocomplete = 'name';
    input.setAttribute('data-commerce-required', '1');
    input.required = true;
    wrap.appendChild(label);
    wrap.appendChild(input);
    var submit = form.querySelector('[type="submit"], button');
    if (submit && submit.parentNode === form) {
      form.insertBefore(wrap, submit);
    } else {
      form.appendChild(wrap);
    }
  }

  /**
   * Start checkout. For mixed carts, pass group_key or omit to receive needs_split + groups.
   * When autoSplit is true (default), automatically starts the first remaining group.
   * Email/address/attendee are collected once and reused via checkout_session_id.
   */
  function checkout(fields, options) {
    var opts = options || {};
    var autoSplit = opts.autoSplit !== false;
    var payload = Object.assign({}, fields || {});
    clearError();
    if (opts.groupKey) payload.group_key = opts.groupKey;
    if (opts.sessionId || split.sessionId) {
      payload.checkout_session_id = opts.sessionId || split.sessionId;
    }

    return api('checkout', payload).then(function (data) {
      rememberSplitFromPayload(data);

      if (data.needs_split && !payload.group_key && autoSplit) {
        var first = (data.groups && data.groups[0]) || (split.groups && split.groups[0]);
        if (first && first.key) {
          split.currentGroupKey = first.key;
          return checkout(Object.assign({}, payload, {
            group_key: first.key,
            checkout_session_id: data.checkout_session_id || split.sessionId
          }), { autoSplit: false });
        }
      }

      emit('checkout', data);
      return data;
    });
  }

  /**
   * After a group payment succeeds, start the next remaining group using the
   * saved checkout draft (email / address / attendee collected once).
   */
  function continueSplitCheckout(fields, options) {
    var opts = options || {};
    var nextKey = opts.groupKey || split.nextGroupKey;
    if (!nextKey) {
      return Promise.reject(new Error('No remaining checkout group'));
    }
    clearError();
    split.currentGroupKey = nextKey;
    return checkout(Object.assign({}, fields || {}, {
      group_key: nextKey,
      checkout_session_id: opts.sessionId || split.sessionId
    }), { autoSplit: false, groupKey: nextKey, sessionId: opts.sessionId || split.sessionId });
  }

  /**
   * After Stripe hosted Checkout redirect, confirm payment locally so order_paid
   * emails and fulfillment run even when webhooks are delayed or mis-matched.
   */
  function confirmHostedCheckoutReturn() {
    var params = new URLSearchParams(location.search);
    var sessionId = (params.get('session_id') || '').trim();
    var orderId = (params.get('commerce_order') || '').trim();
    if (!sessionId && !orderId) {
      return Promise.resolve(null);
    }
    clearError();
    var promise = sessionId
      ? api('confirm_payment', { payment_id: sessionId })
      : api('sync_order_payment', { id: orderId });
    return promise.then(function (local) {
      rememberSplitFromPayload(local || {});
      emit('payment', { commerce: local, hosted_checkout: true });
      return local;
    }).catch(function (err) {
      lastError = err;
      emit('error', err);
      return null;
    });
  }

  function confirmPayment(stripe, elements, confirmParams) {
    if (!stripe || !elements) {
      return Promise.reject(new Error('Stripe is not ready'));
    }
    clearError();
    var params = confirmParams || { return_url: location.href.split('#')[0] };
    var submit = typeof elements.submit === 'function' ? elements.submit() : Promise.resolve({});
    return submit.then(function (submitResult) {
      if (submitResult && submitResult.error) {
        throw new Error(submitResult.error.message || 'Select a payment method');
      }
      return stripe.confirmPayment({
        elements: elements,
        confirmParams: params,
        redirect: 'if_required'
      });
    }).then(function (result) {
      if (result.error) throw new Error(result.error.message || 'Payment failed');
      var paymentIntent = result.paymentIntent || {};
      var paymentId = paymentIntent.id || '';
      var status = String(paymentIntent.status || '').toLowerCase();
      // Tell Commerce the charge succeeded so orders flip to paid and
      // subscriptions are created even when Stripe webhooks are missing.
      if (paymentId && (status === 'succeeded' || status === 'processing' || status === 'requires_capture')) {
        return api('confirm_payment', { payment_id: paymentId }).then(function (local) {
          result.commerce = local;
          rememberSplitFromPayload(local || {});
          if (local && local.needs_split && local.next_group_key) {
            split.nextGroupKey = local.next_group_key;
            split.confirmMode = true;
          } else if (local && !local.needs_split) {
            split.nextGroupKey = null;
            split.confirmMode = false;
            split.currentGroupKey = null;
          }
          emit('payment', result);
          return result;
        }).catch(function (err) {
          result.commerce_error = err && err.message ? err.message : 'Local payment confirm failed';
          lastError = err;
          emit('payment', result);
          return result;
        });
      }
      emit('payment', result);
      return result;
    });
  }

  function storefrontConfig() {
    return api('storefront_config', {}, 'GET');
  }

  /** Look up an order by email + order number (or id) for status / cancel UI. */
  function lookupOrder(fields) {
    fields = fields || {};
    return api('lookup_order', {
      email: fields.email || '',
      order_number: fields.order_number || fields.order_id || fields.id || ''
    }).then(function (res) {
      emit('order_lookup', res);
      return res;
    });
  }

  /**
   * Customer self-service cancel (requires Settings → General enable).
   * Always refunds remaining paid balance when cancel succeeds.
   */
  function cancelOrder(fields) {
    fields = fields || {};
    return api('customer_cancel_order', {
      email: fields.email || '',
      order_number: fields.order_number || fields.order_id || fields.id || '',
      reason: fields.reason || ''
    }).then(function (res) {
      emit('order_canceled', res);
      return res;
    });
  }

  function listMySubscriptions() {
    return api('list_my_subscriptions', {}, 'GET').then(function (res) {
      emit('subscriptions', res);
      return res;
    });
  }

  function pauseMySubscription(id) {
    return api('customer_pause_subscription', { id: id }).then(function (res) {
      emit('subscription_paused', res);
      return res;
    });
  }

  function resumeMySubscription(id) {
    return api('customer_resume_subscription', { id: id }).then(function (res) {
      emit('subscription_resumed', res);
      return res;
    });
  }

  function cancelMySubscription(id) {
    return api('customer_cancel_subscription', { id: id }).then(function (res) {
      emit('subscription_canceled', res);
      return res;
    });
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderSubscriptionRow(sub) {
    var html = '<article class="commerce-subscription-row" data-subscription-id="' + escapeHtml(sub.id) + '">';
    html += '<h4>' + escapeHtml(sub.label || 'Subscription') + '</h4>';
    html += '<p><span class="badge">' + escapeHtml(sub.status || '') + '</span> ';
    html += escapeHtml(money(sub.amount_cents, sub.currency)) + ' / ' + escapeHtml(sub.interval || 'month');
    if (sub.next_billing_at) {
      html += ' · next ' + escapeHtml(String(sub.next_billing_at).slice(0, 10));
    }
    html += '</p><div class="commerce-subscription-actions">';
    if (sub.can_pause) {
      html += '<button type="button" class="btn btn-secondary" data-commerce-sub-pause="' + escapeHtml(sub.id) + '">Pause</button> ';
    }
    if (sub.can_resume) {
      html += '<button type="button" class="btn btn-primary" data-commerce-sub-resume="' + escapeHtml(sub.id) + '">Resume</button> ';
    }
    if (sub.can_cancel) {
      html += '<button type="button" class="btn btn-danger" data-commerce-sub-cancel="' + escapeHtml(sub.id) + '">Cancel</button>';
    }
    html += '</div></article>';
    return html;
  }

  function bindSubscriptionsHost(host) {
    if (!host || host.getAttribute('data-commerce-subscriptions-bound') === '1') return;
    host.setAttribute('data-commerce-subscriptions-bound', '1');
    var emptyText = host.getAttribute('data-commerce-subscriptions-empty') || 'No subscriptions.';

    function load() {
      host.innerHTML = '<p>Loading subscriptions…</p>';
      return listMySubscriptions().then(function (res) {
        var subs = (res && res.subscriptions) || [];
        if (!subs.length) {
          host.innerHTML = '<p>' + escapeHtml(emptyText) + '</p>';
          return;
        }
        host.innerHTML = subs.map(renderSubscriptionRow).join('');
        host.querySelectorAll('[data-commerce-sub-pause]').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var id = btn.getAttribute('data-commerce-sub-pause');
            var warn = 'Pause billing? Membership access is paused until you resume.';
            if (!window.confirm(warn)) return;
            pauseMySubscription(id).then(function () { load(); });
          });
        });
        host.querySelectorAll('[data-commerce-sub-resume]').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var id = btn.getAttribute('data-commerce-sub-resume');
            if (!window.confirm('Resume billing for this subscription?')) return;
            resumeMySubscription(id).then(function () { load(); });
          });
        });
        host.querySelectorAll('[data-commerce-sub-cancel]').forEach(function (btn) {
          btn.addEventListener('click', function () {
            var id = btn.getAttribute('data-commerce-sub-cancel');
            if (!window.confirm('Cancel this subscription permanently?')) return;
            cancelMySubscription(id).then(function () { load(); });
          });
        });
      }).catch(function (err) {
        if (err && err.status === 401) {
          host.innerHTML = '<p>Sign in to manage subscriptions.</p>';
          return;
        }
        host.innerHTML = '<p class="error">' + escapeHtml(err.message || 'Failed to load subscriptions') + '</p>';
      });
    }

    host.__commerceReloadSubscriptions = load;
    load();
  }

  function refreshSubscriptions(root) {
    var scope = root || document;
    qsa('[data-commerce-subscriptions]', scope).forEach(function (host) {
      if (typeof host.__commerceReloadSubscriptions === 'function') {
        host.__commerceReloadSubscriptions();
      } else {
        bindSubscriptionsHost(host);
      }
    });
  }

  /**
   * Mount Stripe Payment Element for a client_secret.
   * Disables Link by default so shoppers can always enter/change card details.
   */
  function mountPaymentElement(stripe, clientSecret, mountSelector, options) {
    var opts = options || {};
    var mount = typeof mountSelector === 'string' ? document.querySelector(mountSelector) : mountSelector;
    if (!stripe || !clientSecret || !mount) {
      throw new Error('Stripe, client secret, and mount element are required');
    }
    var elements = stripe.elements({
      clientSecret: clientSecret,
      locale: opts.locale || undefined,
      appearance: opts.appearance || {
        theme: 'stripe',
        variables: { colorPrimary: '#b4532a', borderRadius: '10px' }
      }
    });
    mount.innerHTML = '';
    var payment = elements.create('payment', {
      layout: opts.layout || { type: 'tabs' },
      wallets: Object.assign({ applePay: 'auto', googlePay: 'auto', link: 'never' }, opts.wallets || {})
    });
    payment.mount(mount);
    return { elements: elements, paymentElement: payment };
  }


  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }

  function qsa(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  function setStatus(el, message, isError) {
    if (!el) return;
    el.textContent = message || '';
    if (isError) {
      el.setAttribute('data-commerce-error', '1');
    } else {
      el.removeAttribute('data-commerce-error');
    }
  }

  function bind(root) {
    var scope = root || document;

    qsa('[data-commerce-purchase-options]', scope).forEach(function (el) {
      mountPurchaseOptions(el);
    });

    qsa('[data-commerce-linked-checkout]', scope).forEach(function (form) {
      bindLinkedCheckoutForm(form);
    });

    qsa('[data-commerce-subscriptions]', scope).forEach(bindSubscriptionsHost);

    qsa('[data-commerce-confirm-return]', scope).forEach(function (el) {
      mountConfirmReturn(el);
    });

    wireCadenceToggles(scope);
    wireAmountSelect(scope);
    qsa('[data-commerce-linked-checkout]', scope).forEach(function (form) {
      syncPurchaseOptionHiddenField(form);
    });

    qsa('[data-commerce-add]', scope).forEach(function (btn) {
      if (btn.getAttribute('data-commerce-bound') === '1') return;
      btn.setAttribute('data-commerce-bound', '1');
      btn.addEventListener('click', function (ev) {
        ev.preventDefault();
        var payload = {
          entry_id: btn.getAttribute('data-entry-id') || btn.getAttribute('data-commerce-entry'),
          collection: btn.getAttribute('data-collection') || btn.getAttribute('data-commerce-collection'),
          qty: Number(btn.getAttribute('data-qty') || 1) || 1,
          purchase_option_id: btn.getAttribute('data-purchase-option-id') || btn.getAttribute('data-option') || undefined
        };
        var amount = btn.getAttribute('data-amount-cents');
        if (amount) payload.amount_cents = Number(amount);
        btn.disabled = true;
        clearError();
        add(payload).then(function (cart) {
          emit('added', { button: btn, cart: cart });
          if (btn.getAttribute('data-commerce-redirect') === 'cart') {
            var cartUrl = btn.getAttribute('data-cart-url') || '/project/cart.html';
            location.href = cartUrl;
          }
        }).catch(function (err) {
          emit('error', err);
          alert(err.message || 'Could not add to cart');
        }).then(function () {
          btn.disabled = false;
        });
      });
    });

    qsa('[data-commerce-clear]', scope).forEach(function (btn) {
      if (btn.getAttribute('data-commerce-bound') === '1') return;
      btn.setAttribute('data-commerce-bound', '1');
      btn.addEventListener('click', function (ev) {
        ev.preventDefault();
        clear().catch(function (err) {
          emit('error', err);
          alert(err.message || 'Could not clear cart');
        });
      });
    });

    qsa('[data-commerce-checkout-form]', scope).forEach(function (form) {
      if (form.getAttribute('data-commerce-bound') === '1') return;
      form.setAttribute('data-commerce-bound', '1');
      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var fields = checkoutFieldsFromForm(form);
        var status = qs('[data-commerce-status]', form) || qs('[data-commerce-status]', scope);
        setStatus(status, 'Starting checkout…', false);
        clearError();
        ensureAttendeeField(form);
        syncCheckoutFieldVisibility(form);
        checkout(fields, {
          // Prefer the group currently being paid; do not jump ahead to next.
          groupKey: split.currentGroupKey || undefined,
          sessionId: split.sessionId || undefined,
          autoSplit: true
        }).then(function (data) {
          if (data.needs_split) {
            setStatus(status, 'Pay this group, then continue to the next.', false);
          } else {
            setStatus(status, 'Checkout ready — complete payment.', false);
          }
          if (data.redirect_url && !data.client_secret) {
            location.href = data.redirect_url;
            return;
          }
          emit('checkout-ready', data);
        }).catch(function (err) {
          setStatus(status, err.message || 'Checkout failed', true);
          emit('error', err);
        });
      });
    });

    qsa('[data-commerce-cart-count]', scope).forEach(function (el) {
      on('cart', function (cart) {
        el.textContent = String((cart && cart.count) || 0);
      });
    });

    on('cart', function () {
      syncCheckoutFieldVisibility(scope);
    });

    // Optional VAT ID field when tax (or B2B reverse charge) is enabled.
    storefrontConfig().then(function (cfg) {
      var data = (cfg && cfg.data) || cfg || {};
      if (!data.tax_enabled && !data.b2b_reverse_charge_enabled) return;
      qsa('[data-commerce-checkout-form], [data-checkout-form]', scope).forEach(ensureVatIdField);
    }).catch(function () { /* ignore config failures */ });

    // Re-quote tax/shipping as the shopper fills address fields.
    qsa('[data-commerce-checkout-form], [data-checkout-form]', scope).forEach(function (form) {
      if (form.getAttribute('data-commerce-quote-bound') === '1') return;
      form.setAttribute('data-commerce-quote-bound', '1');
      var quoteTimer = null;
      function scheduleQuote() {
        if (quoteTimer) clearTimeout(quoteTimer);
        quoteTimer = setTimeout(function () {
          var fields = checkoutFieldsFromForm(form);
          setCheckoutDraft({
            email: fields.email || undefined,
            shipping_address: fields.shipping_address || null,
            attendee_name: fields.attendee_name || undefined,
            vat_id: fields.vat_id || fields.tax_id || undefined
          }).then(function (cart) {
            fillMoneyHosts(scope, cart);
            emit('quote', cart);
          }).catch(function () { /* ignore draft quote failures */ });
        }, 280);
      }
      form.addEventListener('input', scheduleQuote);
      form.addEventListener('change', scheduleQuote);
    });

    on('cart', function (cart) {
      fillMoneyHosts(scope, cart);
    });

    return getCart().then(function (cart) {
      qsa('[data-commerce-checkout-form], [data-checkout-form]', scope).forEach(ensureAttendeeField);
      syncCheckoutFieldVisibility(scope);
      fillMoneyHosts(scope, cart);
      return cart;
    }).catch(function () { return null; });
  }

  var apiExport = {
    version: '1.0.112',
    api: api,
    getCart: getCart,
    add: add,
    update: update,
    remove: remove,
    clear: clear,
    setCheckoutDraft: setCheckoutDraft,
    catalogItem: catalogItem,
    beginLinkedCheckout: beginLinkedCheckout,
    uploadLinkedCheckoutAsset: uploadLinkedCheckoutAsset,
    uploadLinkedCheckoutAssetsFromForm: uploadLinkedCheckoutAssetsFromForm,
    abandonCheckout: abandonCheckout,
    mountPurchaseOptions: mountPurchaseOptions,
    bindLinkedCheckoutForm: bindLinkedCheckoutForm,
    handleHostedCheckoutReturn: handleHostedCheckoutReturn,
    getPurchaseOptionState: getPurchaseOptionState,
    checkout: checkout,
    continueSplitCheckout: continueSplitCheckout,
    checkoutFieldsFromForm: checkoutFieldsFromForm,
    ensureVatIdField: ensureVatIdField,
    ensureAttendeeField: ensureAttendeeField,
    cartNeedsShipping: cartNeedsShipping,
    cartNeedsAttendee: cartNeedsAttendee,
    syncCheckoutFieldVisibility: syncCheckoutFieldVisibility,
    renderMoneyRows: renderMoneyRows,
    fillMoneyHosts: fillMoneyHosts,
    confirmPayment: confirmPayment,
    confirmHostedCheckoutReturn: confirmHostedCheckoutReturn,
    storefrontConfig: storefrontConfig,
    lookupOrder: lookupOrder,
    cancelOrder: cancelOrder,
    listMySubscriptions: listMySubscriptions,
    pauseMySubscription: pauseMySubscription,
    resumeMySubscription: resumeMySubscription,
    cancelMySubscription: cancelMySubscription,
    refreshSubscriptions: refreshSubscriptions,
    mountPaymentElement: mountPaymentElement,
    bind: bind,
    money: money,
    on: on,
    clearError: clearError,
    getLastError: function () { return lastError; },
    getLastCart: function () { return lastCart; },
    getSplitState: function () {
      return {
        sessionId: split.sessionId,
        groups: split.groups.slice(),
        currentGroupKey: split.currentGroupKey,
        nextGroupKey: split.nextGroupKey,
        confirmMode: split.confirmMode
      };
    }
  };

  global.BirklyCommerce = apiExport;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      handleHostedCheckoutReturn();
      if (document.documentElement.hasAttribute('data-commerce-autobind')) {
        bind(document);
      }
    });
  } else {
    handleHostedCheckoutReturn();
    if (document.documentElement.hasAttribute('data-commerce-autobind')) {
      bind(document);
    }
  }
})(typeof window !== 'undefined' ? window : this);
