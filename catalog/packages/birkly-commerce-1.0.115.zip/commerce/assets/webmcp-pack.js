/**
 * Commerce WebMCP runtime pack (P83-M4).
 * Registers visitor storefront tools when BirklyCommerce is present.
 */
(function () {
    'use strict';

    var api = window.BirklyWebMcp = window.BirklyWebMcp || {};
    api._packs = api._packs || {};

    api._packs.commerce = function (register, toolEnabled) {
        var C = window.BirklyCommerce;
        if (!C || typeof C.getCart !== 'function') return;

        if (toolEnabled('birkly_commerce_get_cart')) {
            register({
                name: 'birkly_commerce_get_cart',
                scope: 'commerce',
                description: 'Get the current shopping cart contents and totals.',
                execute: function () { return C.getCart(); }
            });
        }
        if (toolEnabled('birkly_commerce_add_to_cart')) {
            register({
                name: 'birkly_commerce_add_to_cart',
                scope: 'commerce',
                description: 'Add a product (or variant) to the shopping cart. Asks the visitor to confirm.',
                mutating: true,
                consent: 'confirm',
                inputSchema: {
                    type: 'object',
                    properties: {
                        entry_id: { type: 'string', description: 'Product entry id.' },
                        collection: { type: 'string' },
                        variant: { type: 'string' },
                        quantity: { type: 'number' }
                    },
                    required: ['entry_id']
                },
                confirmMessage: function () { return 'Add this item to your cart?'; },
                execute: function (args) {
                    return C.add({
                        entry_id: args.entry_id,
                        collection: args.collection,
                        variant: args.variant,
                        quantity: args.quantity || 1
                    });
                }
            });
        }
        if (toolEnabled('birkly_commerce_checkout')) {
            register({
                name: 'birkly_commerce_checkout',
                scope: 'commerce',
                description: 'Begin or advance checkout. The payment step always asks the visitor to confirm.',
                mutating: true,
                consent: 'pay',
                inputSchema: {
                    type: 'object',
                    properties: {
                        email: { type: 'string' },
                        group_key: { type: 'string' }
                    }
                },
                confirmMessage: function () { return 'Start checkout and proceed to payment?'; },
                execute: function (args) {
                    return C.checkout(args || {});
                }
            });
        }
    };
})();
