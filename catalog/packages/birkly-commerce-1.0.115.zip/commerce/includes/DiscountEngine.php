<?php
/**
 * Discount / promotions engine (P54 P1-M3).
 * Supports percent, fixed, free shipping; date windows; usage limits;
 * min purchase; stackable vs exclusive rules.
 */

class DiscountEngine
{
    private string $rulesFile;

    public function __construct(?string $dataDir = null)
    {
        $dir = $dataDir ?? commerce_data_dir();
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $this->rulesFile = $dir . '/discount_rules.json';
        if (!is_file($this->rulesFile)) {
            file_put_contents($this->rulesFile, json_encode(['rules' => []], JSON_PRETTY_PRINT), LOCK_EX);
        }
    }

    public function loadRules(): array
    {
        $data = json_decode((string) file_get_contents($this->rulesFile), true);
        return is_array($data) ? $data : ['rules' => []];
    }

    public function saveRules(array $data): void
    {
        file_put_contents($this->rulesFile, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
    }

    /** @return list<array<string, mixed>> */
    public function listRules(): array
    {
        $out = [];
        foreach ($this->loadRules()['rules'] ?? [] as $rule) {
            if (is_array($rule)) {
                $out[] = $this->normalizeRule($rule);
            }
        }
        usort($out, static fn ($a, $b) => strcmp((string) ($a['name'] ?? $a['id']), (string) ($b['name'] ?? $b['id'])));
        return $out;
    }

    public function getRule(string $id): ?array
    {
        $data = $this->loadRules();
        $rule = $data['rules'][$id] ?? null;
        return is_array($rule) ? $this->normalizeRule($rule) : null;
    }

    /**
     * @param array<string, mixed> $rule
     * @return array<string, mixed>
     */
    public function saveRule(array $rule): array
    {
        $normalized = $this->normalizeRule($rule, true);
        $this->validateRule($normalized);
        $data = $this->loadRules();
        $id = (string) ($normalized['id'] ?? '');
        if ($id === '') {
            $id = 'rule_' . bin2hex(random_bytes(4));
            $normalized['id'] = $id;
        }
        if (empty($normalized['created_at'])) {
            $normalized['created_at'] = date('c');
        }
        $normalized['updated_at'] = date('c');
        // Preserve usage_count if updating without explicit value from an older client that omitted it.
        if (isset($data['rules'][$id]) && !array_key_exists('usage_count', $rule)) {
            $existing = $this->normalizeRule($data['rules'][$id]);
            $normalized['usage_count'] = (int) ($existing['usage_count'] ?? 0);
        }
        $data['rules'][$id] = $normalized;
        $this->saveRules($data);
        return $normalized;
    }

    public function deleteRule(string $id): bool
    {
        $data = $this->loadRules();
        if (!isset($data['rules'][$id])) {
            return false;
        }
        unset($data['rules'][$id]);
        $this->saveRules($data);
        return true;
    }

    /**
     * Increment usage_count for applied allocation rule ids / codes after paid order.
     *
     * @param list<array<string, mixed>> $allocations
     */
    public function recordUsageFromAllocations(array $allocations): void
    {
        if ($allocations === []) {
            return;
        }
        $data = $this->loadRules();
        $changed = false;
        foreach ($allocations as $alloc) {
            if (!is_array($alloc)) {
                continue;
            }
            $ruleId = (string) ($alloc['rule_id'] ?? '');
            $code = strtoupper(trim((string) ($alloc['code'] ?? '')));
            foreach ($data['rules'] ?? [] as $id => $raw) {
                if (!is_array($raw)) {
                    continue;
                }
                $rule = $this->normalizeRule($raw);
                $match = ($ruleId !== '' && ($rule['id'] ?? '') === $ruleId)
                    || ($code !== '' && strtoupper((string) ($rule['code'] ?? '')) === $code);
                if (!$match) {
                    continue;
                }
                $raw = $this->normalizeRule($raw);
                $raw['usage_count'] = (int) ($raw['usage_count'] ?? 0) + 1;
                $raw['updated_at'] = date('c');
                $data['rules'][$id] = $raw;
                $changed = true;
            }
        }
        if ($changed) {
            $this->saveRules($data);
        }
    }

    /**
     * Cart-level evaluation with stacking, min purchase, dates, usage, free shipping.
     *
     * Stack semantics:
     * - Among exclusive (stackable=false) candidates, pick the highest customer-savings rule.
     * - Then add every stackable=true rule that still applies.
     * - Coupon + automatic may combine when both are stackable.
     *
     * @param list<array<string, mixed>> $lines priced lines with base_amount_cents / collection / entry
     * @return array{
     *   line_discounts: array<int, int>,
     *   free_shipping: bool,
     *   discount_cents: int,
     *   allocations: list<array<string, mixed>>,
     *   applied_rule_ids: list<string>
     * }
     */
    public function evaluateCart(array $lines, ?string $coupon = null, ?string $affiliateId = null, int $shippingCents = 0, ?int $now = null): array
    {
        $now = $now ?? time();
        $goodsSubtotal = 0;
        foreach ($lines as $line) {
            $goodsSubtotal += (int) ($line['base_amount_cents'] ?? (($line['base_unit_cents'] ?? 0) * max(1, (int) ($line['quantity'] ?? 1))));
        }

        $candidates = [];
        foreach ($this->listRules() as $rule) {
            if (!$this->isRuleCurrentlyValid($rule, $now)) {
                continue;
            }
            if (!$this->ruleMatchesCartContext($rule, $coupon, $affiliateId)) {
                continue;
            }
            $minPurchase = (int) ($rule['min_purchase_cents'] ?? 0);
            if ($minPurchase > 0 && $goodsSubtotal < $minPurchase) {
                continue;
            }
            $matchingIndexes = [];
            foreach ($lines as $idx => $line) {
                if ($this->ruleMatchesItem($rule, $line)) {
                    $matchingIndexes[] = $idx;
                }
            }
            if ($matchingIndexes === [] && ($rule['value_type'] ?? '') !== 'free_shipping') {
                continue;
            }
            // Free shipping can apply cart-wide even without item target match when target empty.
            if (($rule['value_type'] ?? '') === 'free_shipping' && ($rule['target'] ?? '') !== '' && $matchingIndexes === []) {
                continue;
            }
            $savings = $this->estimateRuleSavings($rule, $lines, $matchingIndexes, $shippingCents);
            if ($savings <= 0 && ($rule['value_type'] ?? '') !== 'free_shipping') {
                continue;
            }
            if (($rule['value_type'] ?? '') === 'free_shipping' && $shippingCents <= 0) {
                // Still candidate; savings 0 until shipping known — keep if shipping > 0 later.
                if ($shippingCents <= 0) {
                    $savings = 0;
                }
            }
            $candidates[] = [
                'rule' => $rule,
                'indexes' => $matchingIndexes,
                'savings' => $savings,
            ];
        }

        $exclusive = [];
        $stackable = [];
        foreach ($candidates as $cand) {
            if (!empty($cand['rule']['stackable'])) {
                $stackable[] = $cand;
            } else {
                $exclusive[] = $cand;
            }
        }

        $selected = [];
        if ($exclusive !== []) {
            usort($exclusive, static fn ($a, $b) => ($b['savings'] <=> $a['savings']));
            $selected[] = $exclusive[0];
        }
        foreach ($stackable as $cand) {
            $selected[] = $cand;
        }

        $lineDiscounts = array_fill(0, count($lines), 0);
        $freeShipping = false;
        $allocations = [];
        $appliedIds = [];

        foreach ($selected as $cand) {
            $rule = $cand['rule'];
            $valueType = (string) ($rule['value_type'] ?? 'percent');
            if ($valueType === 'free_shipping') {
                if ($shippingCents > 0) {
                    $freeShipping = true;
                    $allocations[] = $this->makeAllocation($rule, $shippingCents, 'free_shipping');
                    $appliedIds[] = (string) $rule['id'];
                }
                continue;
            }

            $indexes = $cand['indexes'];
            if ($indexes === []) {
                continue;
            }
            $amount = $this->computeRuleAmountForLines($rule, $lines, $indexes);
            if ($amount <= 0) {
                continue;
            }
            $distributed = $this->distributeAmountAcrossLines($amount, $lines, $indexes, $lineDiscounts);
            $appliedAmount = array_sum($distributed);
            if ($appliedAmount <= 0) {
                continue;
            }
            foreach ($distributed as $idx => $cents) {
                $lineDiscounts[$idx] = (int) ($lineDiscounts[$idx] ?? 0) + $cents;
            }
            $allocations[] = $this->makeAllocation($rule, $appliedAmount, $valueType);
            $appliedIds[] = (string) $rule['id'];
        }

        return [
            'line_discounts' => $lineDiscounts,
            'free_shipping' => $freeShipping,
            'discount_cents' => array_sum($lineDiscounts),
            'allocations' => $allocations,
            'applied_rule_ids' => array_values(array_unique($appliedIds)),
        ];
    }

    /**
     * Per-line helper (legacy). Prefer evaluateCart for cart-level constraints.
     *
     * @return array{base_unit_cents: int, effective_unit_cents: int, discount_cents: int}
     */
    public function applyToLine(array $catalogItem, int $qty, ?string $coupon = null, ?string $affiliateId = null): array
    {
        $qty = max(1, $qty);
        $baseUnit = (int) ($catalogItem['price_cents'] ?? 0);
        $line = array_merge($catalogItem, [
            'quantity' => $qty,
            'base_unit_cents' => $baseUnit,
            'base_amount_cents' => $baseUnit * $qty,
        ]);
        $eval = $this->evaluateCart([$line], $coupon, $affiliateId, 0);
        $lineDiscount = (int) ($eval['line_discounts'][0] ?? 0);
        $discountPerUnit = (int) floor($lineDiscount / $qty);
        $discountPerUnit = min($discountPerUnit, $baseUnit);
        $effectiveUnit = max(0, $baseUnit - $discountPerUnit);
        return [
            'base_unit_cents' => $baseUnit,
            'effective_unit_cents' => $effectiveUnit,
            'discount_cents' => $discountPerUnit * $qty,
        ];
    }

    public function applyGiftCardTender(int $amountDueCents, ?string $giftCardCode, ?GiftCardStore $giftCards = null, ?string $orderCurrency = null): array
    {
        $amountDueCents = max(0, $amountDueCents);
        if ($giftCardCode === null || trim($giftCardCode) === '') {
            return ['ok' => true, 'applied_cents' => 0, 'remaining_due_cents' => $amountDueCents];
        }
        if (!class_exists('GiftCardStore')) {
            require_once __DIR__ . '/GiftCardStore.php';
        }
        $store = $giftCards ?? new GiftCardStore();
        $v = $store->validateForRedeem($giftCardCode);
        if (!($v['ok'] ?? false)) {
            return ['ok' => false, 'error' => $v['error'] ?? 'Invalid gift card'];
        }
        $card = $v['card'];
        if ($orderCurrency !== null && $orderCurrency !== '') {
            $cardCurrency = strtolower((string) ($card['currency'] ?? 'eur'));
            if ($cardCurrency !== strtolower($orderCurrency)) {
                return ['ok' => false, 'error' => 'Gift card currency does not match cart currency'];
            }
        }
        $applied = min((int) ($card['balance_cents'] ?? 0), $amountDueCents);
        return [
            'ok' => true,
            'applied_cents' => $applied,
            'remaining_due_cents' => $amountDueCents - $applied,
            'gift_card_code' => $card['code'] ?? $giftCardCode,
            'gift_card_id' => $card['id'] ?? null,
        ];
    }

    /**
     * @param array<string, mixed> $rule
     * @return array<string, mixed>
     */
    public function normalizeRule(array $rule, bool $forSave = false): array
    {
        $id = (string) ($rule['id'] ?? '');
        $type = strtolower(trim((string) ($rule['type'] ?? 'automatic')));
        // Legacy type aliases → modern type + value_type.
        $valueType = strtolower(trim((string) ($rule['value_type'] ?? '')));
        $value = $rule['value'] ?? null;

        if ($type === 'percent_off') {
            $type = 'automatic';
            if ($valueType === '') {
                $valueType = 'percent';
            }
            if ($value === null) {
                $value = (float) ($rule['percent_off'] ?? 0);
            }
        } elseif ($type === 'fixed_off') {
            $type = 'automatic';
            if ($valueType === '') {
                $valueType = 'fixed';
            }
            if ($value === null) {
                $value = (int) ($rule['fixed_off_cents'] ?? 0);
            }
        }

        if (!in_array($type, ['coupon', 'automatic', 'affiliate'], true)) {
            // Unknown legacy types that still carried percent_off.
            if (isset($rule['percent_off'])) {
                $type = ($type === 'coupon' || !empty($rule['code'])) ? 'coupon' : 'automatic';
                $valueType = $valueType !== '' ? $valueType : 'percent';
                $value = $value ?? (float) $rule['percent_off'];
            } else {
                $type = 'automatic';
            }
        }

        if ($valueType === '') {
            if (isset($rule['fixed_off_cents'])) {
                $valueType = 'fixed';
                $value = $value ?? (int) $rule['fixed_off_cents'];
            } elseif (isset($rule['percent_off'])) {
                $valueType = 'percent';
                $value = $value ?? (float) $rule['percent_off'];
            } else {
                $valueType = 'percent';
            }
        }
        if (!in_array($valueType, ['percent', 'fixed', 'free_shipping'], true)) {
            $valueType = 'percent';
        }

        if ($value === null) {
            $value = $valueType === 'fixed' ? 0 : ($valueType === 'percent' ? 0 : 0);
        }
        if ($valueType === 'percent') {
            $value = (float) $value;
        } elseif ($valueType === 'fixed') {
            $value = (int) $value;
        } else {
            $value = 0;
        }

        $usageLimit = $rule['usage_limit'] ?? null;
        if ($usageLimit === '' || $usageLimit === false) {
            $usageLimit = null;
        } elseif ($usageLimit !== null) {
            $usageLimit = max(0, (int) $usageLimit);
        }

        $perCustomer = $rule['per_customer_limit'] ?? null;
        if ($perCustomer === '' || $perCustomer === false) {
            $perCustomer = null;
        } elseif ($perCustomer !== null) {
            $perCustomer = max(0, (int) $perCustomer);
        }

        $starts = $this->normalizeDateField($rule['starts_at'] ?? null, false);
        $ends = $this->normalizeDateField($rule['ends_at'] ?? null, true);

        $out = [
            'id' => $id,
            'enabled' => array_key_exists('enabled', $rule) ? !empty($rule['enabled']) : true,
            'type' => $type,
            'code' => strtoupper(trim((string) ($rule['code'] ?? ''))),
            'name' => trim((string) ($rule['name'] ?? '')),
            'value_type' => $valueType,
            'value' => $value,
            'min_purchase_cents' => max(0, (int) ($rule['min_purchase_cents'] ?? 0)),
            'usage_limit' => $usageLimit,
            'usage_count' => max(0, (int) ($rule['usage_count'] ?? 0)),
            'per_customer_limit' => $perCustomer,
            'starts_at' => $starts,
            'ends_at' => $ends,
            'stackable' => !empty($rule['stackable']),
            'stack_group' => trim((string) ($rule['stack_group'] ?? 'default')) ?: 'default',
            'target' => trim((string) ($rule['target'] ?? '')),
            'affiliate_id' => trim((string) ($rule['affiliate_id'] ?? '')),
            'created_at' => (string) ($rule['created_at'] ?? ''),
            'updated_at' => (string) ($rule['updated_at'] ?? ''),
        ];

        // Keep legacy mirrors so older readers still see values.
        if ($valueType === 'percent') {
            $out['percent_off'] = (float) $value;
        }
        if ($valueType === 'fixed') {
            $out['fixed_off_cents'] = (int) $value;
        }

        return $out;
    }

    /** @param array<string, mixed> $rule */
    private function validateRule(array $rule): void
    {
        if (($rule['type'] ?? '') === 'coupon' && ($rule['code'] ?? '') === '') {
            throw new InvalidArgumentException('Coupon rules require a code');
        }
        if (($rule['type'] ?? '') === 'affiliate' && ($rule['affiliate_id'] ?? '') === '') {
            throw new InvalidArgumentException('Affiliate rules require an affiliate_id');
        }
        $vt = $rule['value_type'] ?? 'percent';
        if ($vt === 'percent') {
            $v = (float) ($rule['value'] ?? 0);
            if ($v < 0 || $v > 100) {
                throw new InvalidArgumentException('Percent value must be between 0 and 100');
            }
        }
        if ($vt === 'fixed' && (int) ($rule['value'] ?? 0) < 0) {
            throw new InvalidArgumentException('Fixed value must be >= 0');
        }
        $starts = $rule['starts_at'] ?? null;
        $ends = $rule['ends_at'] ?? null;
        if ($starts && $ends && strtotime((string) $starts) !== false && strtotime((string) $ends) !== false
            && strtotime((string) $ends) < strtotime((string) $starts)) {
            throw new InvalidArgumentException('ends_at must be after starts_at');
        }
    }

    /** @param array<string, mixed> $rule */
    public function isRuleCurrentlyValid(array $rule, ?int $now = null): bool
    {
        $now = $now ?? time();
        if (empty($rule['enabled'])) {
            return false;
        }
        $starts = $rule['starts_at'] ?? null;
        if (is_string($starts) && $starts !== '') {
            $ts = strtotime($starts);
            if ($ts !== false && $now < $ts) {
                return false;
            }
        }
        $ends = $rule['ends_at'] ?? null;
        if (is_string($ends) && $ends !== '') {
            $ts = strtotime($ends);
            if ($ts !== false && $now > $ts) {
                return false;
            }
        }
        $limit = $rule['usage_limit'] ?? null;
        if ($limit !== null && (int) ($rule['usage_count'] ?? 0) >= (int) $limit) {
            return false;
        }
        return true;
    }

    /** @param array<string, mixed> $rule */
    private function ruleMatchesCartContext(array $rule, ?string $coupon, ?string $affiliateId): bool
    {
        $type = $rule['type'] ?? 'automatic';
        if ($type === 'coupon') {
            $code = strtoupper(trim((string) ($rule['code'] ?? '')));
            return $coupon !== null && strtoupper(trim($coupon)) === $code;
        }
        if ($type === 'affiliate') {
            $ref = (string) ($rule['affiliate_id'] ?? '');
            return $affiliateId !== null && (string) $affiliateId === $ref;
        }
        // automatic
        return true;
    }

    /** @param array<string, mixed> $rule @param array<string, mixed> $item */
    private function ruleMatchesItem(array $rule, array $item): bool
    {
        $target = $rule['target'] ?? '';
        if ($target === '') {
            return true;
        }
        if (str_starts_with($target, 'entry:')) {
            $parts = explode(':', $target, 3);
            $coll = $parts[1] ?? '';
            $entry = $parts[2] ?? '';
            return ($item['collection_slug'] ?? '') === $coll
                && (($item['entry_id'] ?? '') === $entry || ($item['entry_slug'] ?? '') === $entry);
        }
        if (str_starts_with($target, 'collection:')) {
            $coll = substr($target, strlen('collection:'));
            return ($item['collection_slug'] ?? '') === $coll;
        }
        return true;
    }

    /**
     * @param array<string, mixed> $rule
     * @param list<array<string, mixed>> $lines
     * @param list<int> $indexes
     */
    private function estimateRuleSavings(array $rule, array $lines, array $indexes, int $shippingCents): int
    {
        if (($rule['value_type'] ?? '') === 'free_shipping') {
            return max(0, $shippingCents);
        }
        return $this->computeRuleAmountForLines($rule, $lines, $indexes);
    }

    /**
     * @param array<string, mixed> $rule
     * @param list<array<string, mixed>> $lines
     * @param list<int> $indexes
     */
    private function computeRuleAmountForLines(array $rule, array $lines, array $indexes): int
    {
        $eligible = 0;
        foreach ($indexes as $idx) {
            $line = $lines[$idx] ?? null;
            if (!is_array($line)) {
                continue;
            }
            $eligible += (int) ($line['base_amount_cents'] ?? (($line['base_unit_cents'] ?? 0) * max(1, (int) ($line['quantity'] ?? 1))));
        }
        if ($eligible <= 0) {
            return 0;
        }
        $vt = $rule['value_type'] ?? 'percent';
        if ($vt === 'percent') {
            return (int) round($eligible * ((float) ($rule['value'] ?? 0) / 100));
        }
        if ($vt === 'fixed') {
            return min($eligible, max(0, (int) ($rule['value'] ?? 0)));
        }
        return 0;
    }

    /**
     * @param list<array<string, mixed>> $lines
     * @param list<int> $indexes
     * @param array<int, int> $existingDiscounts
     * @return array<int, int>
     */
    private function distributeAmountAcrossLines(int $amount, array $lines, array $indexes, array $existingDiscounts): array
    {
        $remainingCapacity = [];
        $totalCapacity = 0;
        foreach ($indexes as $idx) {
            $line = $lines[$idx] ?? [];
            $base = (int) ($line['base_amount_cents'] ?? 0);
            $cap = max(0, $base - (int) ($existingDiscounts[$idx] ?? 0));
            $remainingCapacity[$idx] = $cap;
            $totalCapacity += $cap;
        }
        if ($totalCapacity <= 0 || $amount <= 0) {
            return [];
        }
        $amount = min($amount, $totalCapacity);
        $out = [];
        $assigned = 0;
        $i = 0;
        $count = count($remainingCapacity);
        foreach ($remainingCapacity as $idx => $cap) {
            $i++;
            if ($i === $count) {
                $share = min($cap, $amount - $assigned);
            } else {
                $share = (int) floor($amount * ($cap / $totalCapacity));
                $share = min($cap, $share);
            }
            if ($share > 0) {
                $out[$idx] = $share;
                $assigned += $share;
            }
        }
        // Fix remainder pennies.
        if ($assigned < $amount) {
            foreach ($remainingCapacity as $idx => $cap) {
                $have = (int) ($out[$idx] ?? 0);
                $room = $cap - $have;
                if ($room <= 0) {
                    continue;
                }
                $add = min($room, $amount - $assigned);
                $out[$idx] = $have + $add;
                $assigned += $add;
                if ($assigned >= $amount) {
                    break;
                }
            }
        }
        return $out;
    }

    /**
     * @param array<string, mixed> $rule
     * @return array<string, mixed>
     */
    private function makeAllocation(array $rule, int $amountCents, string $valueType): array
    {
        $type = (string) ($rule['type'] ?? 'automatic');
        $code = (string) ($rule['code'] ?? '');
        if ($type === 'affiliate') {
            $code = (string) ($rule['affiliate_id'] ?? $code);
        }
        $basis = ($rule['id'] ?? '') . '|' . $type . '|' . $code . '|' . $amountCents . '|' . $valueType;
        return [
            'id' => 'da_' . substr(hash('sha256', $basis), 0, 12),
            'rule_id' => (string) ($rule['id'] ?? ''),
            'code' => $code,
            'type' => $type,
            'value_type' => $valueType,
            'amount_cents' => max(0, $amountCents),
            'name' => (string) ($rule['name'] ?? ''),
            'source' => 'discount_engine',
        ];
    }

    private function normalizeDateField($value, bool $endOfDay = false): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        // Accept date-only as start/end of day.
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return $value . ($endOfDay ? 'T23:59:59' : 'T00:00:00');
        }
        if (strtotime($value) === false) {
            return null;
        }
        return $value;
    }
}
