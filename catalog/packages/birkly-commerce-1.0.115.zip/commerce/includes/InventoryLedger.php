<?php
/**
 * Inventory ledger system of record for Commerce stock.
 *
 * Modes:
 * - unlimited: no countable stock, catalog projection is null.
 * - simple: one logical default warehouse row per SKU.
 * - locations: existing multi-warehouse rows, with availability by location.
 */
class InventoryLedger
{
    public const MODE_UNLIMITED = 'unlimited';
    public const MODE_SIMPLE = 'simple';
    public const MODE_LOCATIONS = 'locations';

    private string $dataDir;
    private CatalogIndexer $indexer;
    private WarehouseStockStore $warehouse;
    private ?StockReservationStore $reservations;
    private ?string $modeOverride;

    public function __construct(
        ?string $dataDir = null,
        ?CatalogIndexer $indexer = null,
        ?WarehouseStockStore $warehouse = null,
        ?StockReservationStore $reservations = null,
        ?string $mode = null
    ) {
        $this->dataDir = $dataDir ?? (function_exists('commerce_data_dir') ? commerce_data_dir() : sys_get_temp_dir());
        $this->indexer = $indexer ?? new CatalogIndexer($this->dataDir);
        $this->warehouse = $warehouse ?? new WarehouseStockStore($this->dataDir);
        if ($reservations === null && (class_exists('StockReservationStore') || is_file(__DIR__ . '/StockReservationStore.php'))) {
            if (!class_exists('StockReservationStore')) {
                require_once __DIR__ . '/StockReservationStore.php';
            }
            $reservations = new StockReservationStore($this->dataDir, $this->indexer, $this->warehouse);
        }
        $this->reservations = $reservations;
        $this->modeOverride = $mode !== null ? self::normalizeMode($mode) : null;
    }

    public static function normalizeMode(?string $mode): string
    {
        $mode = strtolower(trim((string) $mode));
        return in_array($mode, [self::MODE_UNLIMITED, self::MODE_SIMPLE, self::MODE_LOCATIONS], true)
            ? $mode
            : self::MODE_SIMPLE;
    }

    public static function currentMode(): string
    {
        if (isset($GLOBALS['commerce_stock_mode_override'])) {
            return self::normalizeMode((string) $GLOBALS['commerce_stock_mode_override']);
        }
        $env = getenv('COMMERCE_STOCK_MODE');
        if (is_string($env) && $env !== '') {
            return self::normalizeMode($env);
        }
        if (function_exists('commerce_get_setting')) {
            return self::normalizeMode((string) commerce_get_setting('commerce_stock_mode', self::MODE_SIMPLE));
        }
        return self::MODE_SIMPLE;
    }

    public static function saveMode(string $mode): string
    {
        $mode = self::normalizeMode($mode);
        if (function_exists('set_plugin_setting')) {
            $pluginId = function_exists('commerce_active_plugin_id') ? commerce_active_plugin_id() : 'commerce';
            set_plugin_setting($pluginId, 'commerce_stock_mode', $mode);
            if (function_exists('save_plugin_states')) {
                save_plugin_states();
            }
        }
        return $mode;
    }

    public function mode(): string
    {
        return $this->modeOverride ?? self::currentMode();
    }

    public function isUnlimited(): bool
    {
        return $this->mode() === self::MODE_UNLIMITED;
    }

    public function isLocations(): bool
    {
        return $this->mode() === self::MODE_LOCATIONS;
    }

    public function tracksSku(string $sku): bool
    {
        if ($this->isUnlimited()) {
            return false;
        }
        return $this->warehouse->tracksSku($sku);
    }

    /**
     * In Simple mode, if the catalog still has a finite quantity for a SKU but the
     * ledger has no row yet, create that row so checkout cannot project Available
     * back to unlimited (∞) and wipe the merchant's stock count.
     */
    public function ensureSimpleTrackedFromCatalog(string $sku): bool
    {
        if ($this->mode() !== self::MODE_SIMPLE) {
            return false;
        }
        $sku = strtoupper(trim($sku));
        if ($sku === '' || $this->warehouse->tracksSku($sku)) {
            return false;
        }
        $qty = $this->catalogQuantityForSku($sku);
        if ($qty === null) {
            return false;
        }
        $this->warehouse->set($sku, max(0, (int) $qty), null, WarehouseStockStore::DEFAULT_WAREHOUSE_ID);
        return true;
    }

    /**
     * @param array<int, string>|null $skus
     */
    public function seedMissingSimpleFromCatalog(?array $skus = null): int
    {
        if ($this->mode() !== self::MODE_SIMPLE) {
            return 0;
        }
        $wanted = $skus === null
            ? null
            : array_flip(array_map(static fn($s) => strtoupper(trim((string) $s)), $skus));
        $seeded = 0;
        foreach ($this->indexer->loadIndex()['entries'] ?? [] as $row) {
            if (!is_array($row) || !empty($row['is_bundle'])) {
                continue;
            }
            $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
            if ($sku === '') {
                continue;
            }
            if ($wanted !== null && !isset($wanted[$sku])) {
                continue;
            }
            if ($this->ensureSimpleTrackedFromCatalog($sku)) {
                $seeded++;
            }
        }
        return $seeded;
    }

    public function setSkuStock(string $sku, int $onHand, ?int $lowThreshold = null, ?string $warehouseId = null): array
    {
        if ($this->isUnlimited()) {
            throw new InvalidArgumentException('Inventory is unlimited; switch to Simple or Locations before setting stock.');
        }
        if (!$this->isLocations()) {
            $warehouseId = WarehouseStockStore::DEFAULT_WAREHOUSE_ID;
        }
        $row = $this->warehouse->set($sku, $onHand, $lowThreshold, $warehouseId);
        $this->projectCatalogForSkus([$row['sku'] ?? $sku]);
        return $row;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function listRows(?string $warehouseId = null): array
    {
        $mode = $this->mode();
        if ($mode === self::MODE_UNLIMITED) {
            return [];
        }

        $reserved = $this->activeReserved();
        $reservedBySku = $reserved['by_sku'] ?? [];
        $reservedByWarehouse = $reserved['by_sku_warehouse'] ?? [];
        $rows = [];
        $seen = [];
        $sourceRows = $mode === self::MODE_LOCATIONS
            ? $this->warehouse->listAll($warehouseId !== '' ? $warehouseId : null)
            : $this->warehouse->listAll(WarehouseStockStore::DEFAULT_WAREHOUSE_ID);

        foreach ($sourceRows as $row) {
            $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
            if ($sku === '') {
                continue;
            }
            $wh = (string) ($row['warehouse_id'] ?? WarehouseStockStore::DEFAULT_WAREHOUSE_ID);
            $onHand = (int) ($row['quantity_on_hand'] ?? 0);
            $held = $mode === self::MODE_LOCATIONS
                ? (int) ($reservedByWarehouse[$sku][$wh] ?? 0)
                : (int) ($reservedBySku[$sku] ?? 0);
            $rows[] = [
                'warehouse_id' => $wh,
                'sku' => $sku,
                'title' => $this->catalogTitleForSku($sku),
                'quantity_on_hand' => $onHand,
                'reserved' => $held,
                'available' => max(0, $onHand - $held),
                'low_stock_threshold' => (int) ($row['low_stock_threshold'] ?? 0),
                'catalog_quantity_available' => $this->catalogQuantityForSku($sku),
                'tracked' => true,
                'updated_at' => $row['updated_at'] ?? null,
            ];
            $seen[$sku] = true;
        }

        // Simple mode: surface catalog SKUs that still need a ledger row so merchants
        // can set on-hand without typing codes by hand.
        if ($mode === self::MODE_SIMPLE) {
            foreach ($this->indexer->loadIndex()['entries'] ?? [] as $row) {
                if (!is_array($row) || !empty($row['is_bundle'])) {
                    continue;
                }
                $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
                if ($sku === '' || isset($seen[$sku])) {
                    continue;
                }
                $rows[] = [
                    'warehouse_id' => WarehouseStockStore::DEFAULT_WAREHOUSE_ID,
                    'sku' => $sku,
                    'title' => (string) ($row['entry_title'] ?? ''),
                    'quantity_on_hand' => null,
                    'reserved' => 0,
                    'available' => null,
                    'low_stock_threshold' => 0,
                    'catalog_quantity_available' => $row['quantity_available'] ?? null,
                    'tracked' => false,
                    'updated_at' => null,
                ];
                $seen[$sku] = true;
            }
        }

        return $rows;
    }

    public function availableForSku(string $sku, ?string $warehouseId = null, array $heldAdditions = []): ?int
    {
        $sku = strtoupper(trim($sku));
        if ($sku === '' || $this->isUnlimited()) {
            return null;
        }

        if ($this->isLocations() && $warehouseId !== null && $warehouseId !== '') {
            $row = $this->warehouse->getBySku($sku, $warehouseId);
            if ($row === null) {
                return null;
            }
            $reserved = (int) (($this->activeReserved()['by_sku_warehouse'][$sku][$warehouseId] ?? 0)
                + ($heldAdditions[$sku][$warehouseId] ?? 0));
            return max(0, (int) ($row['quantity_on_hand'] ?? 0) - $reserved);
        }

        $row = $this->warehouse->getBySku($sku);
        if ($row === null) {
            return null;
        }
        $reserved = (int) (($this->activeReserved()['by_sku'][$sku] ?? 0) + ($heldAdditions[$sku]['*'] ?? 0));
        return max(0, (int) ($row['quantity_on_hand'] ?? 0) - $reserved);
    }

    public function allocateWarehouse(string $sku, int $qty, array $heldAdditions = []): ?string
    {
        if (!$this->isLocations()) {
            return WarehouseStockStore::DEFAULT_WAREHOUSE_ID;
        }
        $sku = strtoupper(trim($sku));
        $qty = max(1, $qty);
        foreach ($this->warehouse->listWarehouses() as $warehouse) {
            $warehouseId = (string) ($warehouse['id'] ?? '');
            if ($warehouseId === '') {
                continue;
            }
            $available = $this->availableForSku($sku, $warehouseId, $heldAdditions);
            if ($available !== null && $available >= $qty) {
                return $warehouseId;
            }
        }
        return null;
    }

    public function decrementOnHand(string $sku, int $qty, ?string $warehouseId = null): bool
    {
        if ($this->isUnlimited()) {
            return true;
        }
        $warehouseId = $this->isLocations()
            ? $warehouseId
            : WarehouseStockStore::DEFAULT_WAREHOUSE_ID;
        $ok = $this->warehouse->decrement($sku, $qty, $warehouseId);
        $this->projectCatalogForSkus([$sku]);
        return $ok;
    }

    public function incrementOnHand(string $sku, int $qty, ?string $warehouseId = null): bool
    {
        if ($this->isUnlimited()) {
            return true;
        }
        $warehouseId = $this->isLocations()
            ? $warehouseId
            : WarehouseStockStore::DEFAULT_WAREHOUSE_ID;
        $ok = $this->warehouse->increment($sku, $qty, $warehouseId);
        $this->projectCatalogForSkus([$sku]);
        return $ok;
    }

    public function expectedCatalogQuantity(string $sku)
    {
        if ($this->isUnlimited()) {
            return null;
        }
        return $this->availableForSku($sku);
    }

    /**
     * @param array<int, string>|null $skus
     */
    public function projectCatalogForSkus(?array $skus = null): int
    {
        // Recover countable Simple stock before projecting — otherwise a checkout
        // projection turns finite catalog qty into null (shown as ∞).
        $this->seedMissingSimpleFromCatalog($skus);

        $index = $this->indexer->loadIndex();
        $wanted = $skus === null ? null : array_flip(array_map(static fn($s) => strtoupper(trim((string) $s)), $skus));
        $changed = 0;
        foreach ($index['entries'] ?? [] as $key => $row) {
            if (!is_array($row)) {
                continue;
            }
            $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
            if ($sku === '') {
                continue;
            }
            if ($wanted !== null && !isset($wanted[$sku])) {
                continue;
            }
            $expected = $this->expectedCatalogQuantity($sku);
            if (($row['quantity_available'] ?? null) === $expected) {
                continue;
            }
            $row['quantity_available'] = $expected;
            $row['updated_at'] = date('c');
            $index['entries'][$key] = $row;
            $changed++;
        }
        if ($changed > 0) {
            $this->indexer->saveIndex($index);
        }
        // Always sync CMS entries for the projected SKUs — entry fields can lag the
        // catalog index (storefront templates read the entry, not the index).
        $this->indexer->syncProjectedQuantitiesToEntries($wanted);
        // Ops intelligence: evaluate low-stock alerts after catalog projection.
        $this->evaluateLowStockAlerts($skus);
        return $changed;
    }

    /**
     * Fire commerce_low_stock (debounced) when available hits/goes below threshold.
     *
     * @param list<string>|null $skus
     * @return list<array<string, mixed>>
     */
    public function evaluateLowStockAlerts(?array $skus = null): array
    {
        if ($this->isUnlimited()) {
            return [];
        }
        if (!class_exists('CommerceLowStockService')) {
            require_once __DIR__ . '/CommerceLowStockService.php';
        }
        try {
            return (new CommerceLowStockService($this->dataDir, $this))->evaluate($skus);
        } catch (Throwable $e) {
            error_log('Commerce low-stock evaluate failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * @return array<string, mixed>
     */
    public function reconcile(bool $apply = false): array
    {
        if ($this->reservations) {
            $this->reservations->releaseExpired();
        }

        $mode = $this->mode();
        $index = $this->indexer->loadIndex();
        $drift = [];
        foreach ($index['entries'] ?? [] as $key => $row) {
            if (!is_array($row)) {
                continue;
            }
            $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
            if ($sku === '') {
                continue;
            }
            $expected = $mode === self::MODE_UNLIMITED ? null : $this->expectedCatalogQuantity($sku);
            $actual = $row['quantity_available'] ?? null;
            if ($actual !== $expected) {
                $drift[] = [
                    'key' => $key,
                    'sku' => $sku,
                    'catalog_quantity_available' => $actual,
                    'expected_quantity_available' => $expected,
                ];
            }
        }

        $fixed = $apply ? $this->projectCatalogForSkus(null) : 0;
        return [
            'mode' => $mode,
            'drift_count' => count($drift),
            'fixed_count' => $fixed,
            'drift' => $drift,
            'rows' => $this->listRows(null),
        ];
    }

    public function writeThroughSimpleField(array $commerceData): void
    {
        // Skip when projecting ledger → CMS entry (avoids resetting on_hand to available).
        if (!empty($GLOBALS['commerce_skip_inventory_write_through'])) {
            return;
        }
        if ($this->mode() !== self::MODE_SIMPLE) {
            return;
        }
        $sku = trim((string) ($commerceData['sku'] ?? ''));
        if ($sku === '' || ($commerceData['quantity_available'] ?? null) === null) {
            return;
        }
        $this->setSkuStock($sku, (int) $commerceData['quantity_available'], null, WarehouseStockStore::DEFAULT_WAREHOUSE_ID);
    }

    /**
     * @return array{by_sku: array<string, int>, by_sku_warehouse: array<string, array<string, int>>}
     */
    private function activeReserved(): array
    {
        if (!$this->reservations) {
            return ['by_sku' => [], 'by_sku_warehouse' => []];
        }
        return $this->reservations->activeReservedBySku();
    }

    private function catalogQuantityForSku(string $sku)
    {
        $sku = strtoupper(trim($sku));
        foreach ($this->indexer->loadIndex()['entries'] ?? [] as $row) {
            if (is_array($row) && strtoupper(trim((string) ($row['sku'] ?? ''))) === $sku) {
                return $row['quantity_available'] ?? null;
            }
        }
        return null;
    }

    private function catalogTitleForSku(string $sku): string
    {
        $sku = strtoupper(trim($sku));
        foreach ($this->indexer->loadIndex()['entries'] ?? [] as $row) {
            if (is_array($row) && strtoupper(trim((string) ($row['sku'] ?? ''))) === $sku) {
                return (string) ($row['entry_title'] ?? '');
            }
        }
        return '';
    }
}
