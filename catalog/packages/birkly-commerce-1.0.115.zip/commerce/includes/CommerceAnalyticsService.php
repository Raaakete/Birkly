<?php
/** Commerce analytics aggregates (P11-M5) + ops intelligence (P54 P3-M4) */

class CommerceAnalyticsService
{
    private CommerceOrderStore $orders;
    private int $slaHours;

    public function __construct(?CommerceOrderStore $orders = null, ?int $slaHours = null)
    {
        $this->orders = $orders ?? new CommerceOrderStore();
        if ($slaHours !== null) {
            $this->slaHours = max(1, $slaHours);
        } elseif (function_exists('commerce_get_setting')) {
            $this->slaHours = max(1, (int) commerce_get_setting('commerce_fulfillment_sla_hours', 48));
        } else {
            $this->slaHours = 48;
        }
    }

    public function getSlaHours(): int
    {
        return $this->slaHours;
    }

    public function getSummary(?string $from = null, ?string $to = null): array
    {
        $orders = $this->filterOrders($from, $to);
        $allPaidHistory = array_values(array_filter(
            $this->orders->listAll(),
            static fn ($o) => self::isPaidStatus($o['status'] ?? '')
        ));
        usort($allPaidHistory, static function ($a, $b) {
            return strcmp((string) ($a['created_at'] ?? ''), (string) ($b['created_at'] ?? ''));
        });

        $paid = array_values(array_filter($orders, static fn ($o) => self::isPaidStatus($o['status'] ?? '')));
        $revenueByCurrency = [];
        $products = [];
        $affiliates = [];
        foreach ($paid as $order) {
            $orderCurrency = strtolower((string) ($order['currency'] ?? 'eur'));
            $total = (int) ($order['total_cents'] ?? 0);
            $refunded = (int) ($order['refunded_cents'] ?? 0);
            $net = max(0, $total - $refunded);
            if (!isset($revenueByCurrency[$orderCurrency])) {
                $revenueByCurrency[$orderCurrency] = 0;
            }
            $revenueByCurrency[$orderCurrency] += $net;
            foreach ($order['lines'] ?? [] as $line) {
                $key = ($line['collection_slug'] ?? '') . ':' . ($line['entry_id'] ?? '');
                if (!isset($products[$key])) {
                    $products[$key] = ['key' => $key, 'title' => $line['title'] ?? $key, 'quantity' => 0, 'revenue_cents' => 0];
                }
                $products[$key]['quantity'] += (int) ($line['quantity'] ?? 1);
                $products[$key]['revenue_cents'] += (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
            }
            $aff = trim((string) ($order['affiliate_id'] ?? ''));
            if ($aff !== '') {
                if (!isset($affiliates[$aff])) {
                    $affiliates[$aff] = ['affiliate_id' => $aff, 'orders' => 0, 'revenue_cents' => 0];
                }
                $affiliates[$aff]['orders']++;
                $affiliates[$aff]['revenue_cents'] += max(0, $total - $refunded);
            }
        }
        $count = count($paid);
        $top = array_values($products);
        usort($top, static fn ($a, $b) => ($b['revenue_cents'] ?? 0) <=> ($a['revenue_cents'] ?? 0));
        $aff = array_values($affiliates);
        usort($aff, static fn ($a, $b) => ($b['revenue_cents'] ?? 0) <=> ($a['revenue_cents'] ?? 0));

        $customerMetrics = $this->customerCohortMetrics($paid, $allPaidHistory, $from, $to);
        $fulfillment = $this->fulfillmentOpsMetrics($allPaidHistory);

        return [
            'from' => $from,
            'to' => $to,
            'order_count' => $count,
            'revenue_cents' => count($revenueByCurrency) === 1 ? (int) reset($revenueByCurrency) : 0,
            'revenue_by_currency' => $revenueByCurrency,
            'refunded_cents' => array_sum(array_map(static fn ($o) => (int) ($o['refunded_cents'] ?? 0), $paid)),
            'aov_cents' => $count > 0 && count($revenueByCurrency) === 1 ? (int) round(reset($revenueByCurrency) / $count) : 0,
            'top_products' => array_slice($top, 0, 10),
            'affiliates' => $aff,
            'new_customers' => $customerMetrics['new_customers'],
            'returning_customers' => $customerMetrics['returning_customers'],
            'cohorts' => $customerMetrics['cohorts'],
            'cohort_period' => $customerMetrics['cohort_period'],
            'needs_shipping_count' => $fulfillment['needs_shipping_count'],
            'avg_fulfillment_hours' => $fulfillment['avg_fulfillment_hours'],
            'sla_breach_count' => $fulfillment['sla_breach_count'],
            'fulfillment_sla_hours' => $this->slaHours,
        ];
    }

    public function exportOrdersCsv(?string $from = null, ?string $to = null): string
    {
        $out = fopen('php://temp', 'r+');
        fputcsv($out, ['order_id', 'status', 'created_at', 'customer_email', 'currency', 'total_cents', 'refunded_cents', 'affiliate_id']);
        foreach ($this->filterOrders($from, $to) as $o) {
            fputcsv($out, [$o['id'] ?? '', $o['status'] ?? '', $o['created_at'] ?? '', $o['customer_email'] ?? '', $o['currency'] ?? 'eur', (int) ($o['total_cents'] ?? 0), (int) ($o['refunded_cents'] ?? 0), $o['affiliate_id'] ?? '']);
        }
        rewind($out);
        $csv = stream_get_contents($out);
        fclose($out);
        return $csv === false ? '' : $csv;
    }

    public function exportSummaryCsv(?string $from = null, ?string $to = null): string
    {
        $s = $this->getSummary($from, $to);
        $out = fopen('php://temp', 'r+');
        foreach ([
            ['metric', 'value'],
            ['order_count', $s['order_count']],
            ['revenue_cents', $s['revenue_cents']],
            ['refunded_cents', $s['refunded_cents']],
            ['aov_cents', $s['aov_cents']],
            ['new_customers', $s['new_customers']],
            ['returning_customers', $s['returning_customers']],
            ['needs_shipping_count', $s['needs_shipping_count']],
            ['avg_fulfillment_hours', $s['avg_fulfillment_hours']],
            ['sla_breach_count', $s['sla_breach_count']],
            ['fulfillment_sla_hours', $s['fulfillment_sla_hours']],
        ] as $row) {
            fputcsv($out, $row);
        }
        rewind($out);
        $csv = stream_get_contents($out);
        fclose($out);
        return $csv === false ? '' : $csv;
    }

    /**
     * @param list<array<string, mixed>> $paidInPeriod
     * @param list<array<string, mixed>> $allPaidHistory
     * @return array{
     *   new_customers: int,
     *   returning_customers: int,
     *   cohorts: list<array<string, mixed>>,
     *   cohort_period: string
     * }
     */
    private function customerCohortMetrics(array $paidInPeriod, array $allPaidHistory, ?string $from, ?string $to): array
    {
        $firstOrderAt = [];
        foreach ($allPaidHistory as $order) {
            $email = self::normalizeEmail($order['customer_email'] ?? '');
            if ($email === '') {
                continue;
            }
            $created = strtotime((string) ($order['created_at'] ?? ''));
            if ($created === false) {
                continue;
            }
            if (!isset($firstOrderAt[$email]) || $created < $firstOrderAt[$email]) {
                $firstOrderAt[$email] = $created;
            }
        }

        $periodStart = $from ? strtotime($from) : null;
        $new = 0;
        $returning = 0;
        $seen = [];
        foreach ($paidInPeriod as $order) {
            $email = self::normalizeEmail($order['customer_email'] ?? '');
            if ($email === '' || isset($seen[$email])) {
                continue;
            }
            $seen[$email] = true;
            $first = $firstOrderAt[$email] ?? null;
            if ($first === null) {
                continue;
            }
            if ($periodStart !== null && $first < $periodStart) {
                $returning++;
            } else {
                $new++;
            }
        }

        // Prefer monthly cohorts; switch to weekly when the window is short.
        $useWeek = false;
        if ($from && $to) {
            $span = (strtotime($to) ?: 0) - (strtotime($from) ?: 0);
            $useWeek = $span > 0 && $span <= (60 * 60 * 24 * 60);
        }
        $cohortPeriod = $useWeek ? 'week' : 'month';
        $cohorts = [];
        foreach ($paidInPeriod as $order) {
            $email = self::normalizeEmail($order['customer_email'] ?? '');
            if ($email === '' || !isset($firstOrderAt[$email])) {
                continue;
            }
            $bucket = $useWeek
                ? date('o-\WW', $firstOrderAt[$email])
                : date('Y-m', $firstOrderAt[$email]);
            if (!isset($cohorts[$bucket])) {
                $cohorts[$bucket] = [
                    'period' => $bucket,
                    'period_type' => $cohortPeriod,
                    'customers' => [],
                    'orders' => 0,
                    'revenue_cents' => 0,
                ];
            }
            $cohorts[$bucket]['customers'][$email] = true;
            $cohorts[$bucket]['orders']++;
            $total = (int) ($order['total_cents'] ?? 0);
            $refunded = (int) ($order['refunded_cents'] ?? 0);
            $cohorts[$bucket]['revenue_cents'] += max(0, $total - $refunded);
        }

        $rows = [];
        foreach ($cohorts as $row) {
            $rows[] = [
                'period' => $row['period'],
                'period_type' => $row['period_type'],
                'customers' => count($row['customers']),
                'orders' => $row['orders'],
                'revenue_cents' => $row['revenue_cents'],
            ];
        }
        usort($rows, static fn ($a, $b) => strcmp((string) $b['period'], (string) $a['period']));

        return [
            'new_customers' => $new,
            'returning_customers' => $returning,
            'cohorts' => $rows,
            'cohort_period' => $cohortPeriod,
        ];
    }

    /**
     * Ops metrics across all paid orders (not limited to the revenue date filter).
     *
     * @param list<array<string, mixed>> $allPaidHistory
     * @return array{
     *   needs_shipping_count: int,
     *   avg_fulfillment_hours: float|null,
     *   sla_breach_count: int
     * }
     */
    private function fulfillmentOpsMetrics(array $allPaidHistory): array
    {
        if (!class_exists('CommerceOrderOps')) {
            require_once __DIR__ . '/CommerceOrderOps.php';
        }

        $needsShipping = 0;
        $slaBreaches = 0;
        $fulfillHours = [];
        $now = time();
        $slaSeconds = $this->slaHours * 3600;

        foreach ($allPaidHistory as $order) {
            if (!$this->orderHasShipLines($order)) {
                continue;
            }
            $remaining = $this->orderRemainingShipQty($order);
            $paidAt = $this->orderPaidAtTs($order);
            if ($remaining > 0) {
                $needsShipping++;
                if ($paidAt !== null && ($now - $paidAt) > $slaSeconds) {
                    $slaBreaches++;
                }
            }

            $shippedAt = $this->orderFirstShipmentTs($order);
            if ($paidAt !== null && $shippedAt !== null && $shippedAt >= $paidAt) {
                $fulfillHours[] = ($shippedAt - $paidAt) / 3600;
            }
        }

        $avg = null;
        if ($fulfillHours !== []) {
            $avg = round(array_sum($fulfillHours) / count($fulfillHours), 2);
        }

        return [
            'needs_shipping_count' => $needsShipping,
            'avg_fulfillment_hours' => $avg,
            'sla_breach_count' => $slaBreaches,
        ];
    }

    /** @param array<string, mixed> $order */
    private function orderHasShipLines(array $order): bool
    {
        foreach ($order['lines'] ?? [] as $line) {
            if (($line['fulfillment'] ?? '') === 'ship') {
                return true;
            }
        }
        return false;
    }

    /** @param array<string, mixed> $order */
    private function orderRemainingShipQty(array $order): int
    {
        $remaining = 0;
        foreach ($order['lines'] ?? [] as $line) {
            if (($line['fulfillment'] ?? '') !== 'ship') {
                continue;
            }
            if (class_exists('CommerceOrderOps')) {
                $remaining += max(0, CommerceOrderOps::remainingQuantity($order, $line));
            } else {
                $qty = max(1, (int) ($line['quantity'] ?? 1));
                $shipped = (int) ($line['quantity_shipped'] ?? 0);
                if ($shipped <= 0 && (($line['fulfillment_status'] ?? '') === 'shipped' || !empty($line['tracking_number']))) {
                    $shipped = $qty;
                }
                $remaining += max(0, $qty - $shipped);
            }
        }
        // Fully fulfilled orders with no line-level remaining still count as done.
        if ($remaining === 0 && ($order['fulfillment_status'] ?? '') === 'fulfilled') {
            return 0;
        }
        return $remaining;
    }

    /** @param array<string, mixed> $order */
    private function orderPaidAtTs(array $order): ?int
    {
        foreach (['paid_at', 'updated_at', 'created_at'] as $field) {
            if ($field === 'updated_at' && ($order['status'] ?? '') !== 'paid') {
                continue;
            }
            $ts = strtotime((string) ($order[$field] ?? ''));
            if ($ts !== false) {
                return $ts;
            }
        }
        return null;
    }

    /** @param array<string, mixed> $order */
    private function orderFirstShipmentTs(array $order): ?int
    {
        $candidates = [];
        foreach (is_array($order['shipments'] ?? null) ? $order['shipments'] : [] as $shipment) {
            $ts = strtotime((string) ($shipment['created_at'] ?? ''));
            if ($ts !== false) {
                $candidates[] = $ts;
            }
        }
        foreach ($order['lines'] ?? [] as $line) {
            if (($line['fulfillment'] ?? '') !== 'ship') {
                continue;
            }
            $ts = strtotime((string) ($line['shipped_at'] ?? ''));
            if ($ts !== false) {
                $candidates[] = $ts;
            }
        }
        if (($order['fulfillment_status'] ?? '') === 'fulfilled' && isset($order['fulfilled_at'])) {
            $ts = strtotime((string) $order['fulfilled_at']);
            if ($ts !== false) {
                $candidates[] = $ts;
            }
        }
        return $candidates === [] ? null : min($candidates);
    }

    private function filterOrders(?string $from, ?string $to): array
    {
        $fromTs = $from ? strtotime($from) : null;
        $toTs = $to ? strtotime($to) : null;
        return array_values(array_filter($this->orders->listAll(), function ($order) use ($fromTs, $toTs) {
            $created = strtotime($order['created_at'] ?? '');
            if ($created === false) {
                return false;
            }
            if ($fromTs && $created < $fromTs) {
                return false;
            }
            if ($toTs && $created > $toTs) {
                return false;
            }
            return true;
        }));
    }

    private static function isPaidStatus(string $status): bool
    {
        return in_array($status, ['paid', 'partially_refunded', 'refunded'], true);
    }

    private static function normalizeEmail(string $email): string
    {
        return strtolower(trim($email));
    }
}
