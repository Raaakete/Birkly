<?php
/**
 * Shopify Admin REST API import adapter (P12-M3).
 */

if (!class_exists('ImportHttpClient')) {
    require_once __DIR__ . '/ImportHttpClient.php';
}

class ShopifyImportAdapter
{
    public const PLATFORM_ID = 'shopify';
    public const API_VERSION = '2024-01';
    public const PAGE_LIMIT = 50;
    public const MAX_PAGES = 100;

    private ImportHttpClient $http;

    public function __construct(?ImportHttpClient $http = null)
    {
        $this->http = $http ?? new ImportHttpClient();
    }

    /** @param array<string, mixed> $credentials */
    public function testConnection(array $credentials): array
    {
        $shop = $this->normalizeShopDomain((string) ($credentials['shop_domain'] ?? ''));
        $token = trim((string) ($credentials['access_token'] ?? ''));
        if ($shop === '' || $token === '') {
            return ['ok' => false, 'error' => 'Shop domain and access token are required'];
        }

        $url = $this->apiUrl($shop, 'shop.json');
        $response = $this->http->request('GET', $url, [
            'headers' => $this->authHeaders($token),
            'timeout' => 20,
        ]);

        if (!($response['ok'] ?? false)) {
            return ['ok' => false, 'error' => $response['error'] ?? 'Connection failed'];
        }

        $shopName = is_array($response['data']['shop'] ?? null)
            ? (string) ($response['data']['shop']['name'] ?? $shop)
            : $shop;

        return ['ok' => true, 'shop_name' => $shopName];
    }

    /**
     * @param array<string, mixed> $credentials
     * @param array<string, mixed> $options
     * @return array{ok: bool, rows?: list<array<string, mixed>>, product_count?: int, pages_fetched?: int, error?: string}
     */
    public function fetchProductRows(array $credentials, array $options = []): array
    {
        $shop = $this->normalizeShopDomain((string) ($credentials['shop_domain'] ?? ''));
        $token = trim((string) ($credentials['access_token'] ?? ''));
        if ($shop === '' || $token === '') {
            return ['ok' => false, 'error' => 'Shop domain and access token are required'];
        }

        $maxPages = max(1, min(self::MAX_PAGES, (int) ($options['max_pages'] ?? self::MAX_PAGES)));
        $rows = [];
        $pageInfo = null;
        $pagesFetched = 0;

        for ($page = 0; $page < $maxPages; $page++) {
            $query = 'limit=' . self::PAGE_LIMIT;
            if ($pageInfo !== null) {
                $query = 'limit=' . self::PAGE_LIMIT . '&page_info=' . rawurlencode($pageInfo);
            }

            $url = $this->apiUrl($shop, 'products.json?' . $query);
            $response = $this->http->request('GET', $url, [
                'headers' => $this->authHeaders($token),
            ]);
            $pagesFetched++;

            if (!($response['ok'] ?? false)) {
                return [
                    'ok' => false,
                    'error' => $response['error'] ?? 'Failed to fetch products',
                    'rows' => $rows,
                    'product_count' => count($rows),
                    'pages_fetched' => $pagesFetched,
                ];
            }

            $products = is_array($response['data']['products'] ?? null) ? $response['data']['products'] : [];
            foreach ($products as $product) {
                if (!is_array($product)) {
                    continue;
                }
                foreach ($this->mapProductToRows($product) as $row) {
                    $rows[] = $row;
                }
            }

            $pageInfo = $this->nextPageInfo($response['headers'] ?? []);
            if ($pageInfo === null || count($products) < self::PAGE_LIMIT) {
                break;
            }
        }

        return [
            'ok' => true,
            'rows' => $rows,
            'product_count' => count(array_filter($rows, fn ($r) => empty($r['parent_sku']))),
            'pages_fetched' => $pagesFetched,
        ];
    }

    /**
     * Fetch Shopify customers for cutover import (no passwords).
     *
     * @param array<string, mixed> $credentials
     * @param array<string, mixed> $options
     * @return array{ok: bool, customers?: list<array<string, mixed>>, customer_count?: int, pages_fetched?: int, error?: string}
     */
    public function fetchCustomers(array $credentials, array $options = []): array
    {
        $shop = $this->normalizeShopDomain((string) ($credentials['shop_domain'] ?? ''));
        $token = trim((string) ($credentials['access_token'] ?? ''));
        if ($shop === '' || $token === '') {
            return ['ok' => false, 'error' => 'Shop domain and access token are required'];
        }

        $maxPages = max(1, min(self::MAX_PAGES, (int) ($options['max_pages'] ?? self::MAX_PAGES)));
        $customers = [];
        $pageInfo = null;
        $pagesFetched = 0;

        for ($page = 0; $page < $maxPages; $page++) {
            $query = 'limit=' . self::PAGE_LIMIT;
            if ($pageInfo !== null) {
                $query = 'limit=' . self::PAGE_LIMIT . '&page_info=' . rawurlencode($pageInfo);
            }
            $url = $this->apiUrl($shop, 'customers.json?' . $query);
            $response = $this->http->request('GET', $url, [
                'headers' => $this->authHeaders($token),
            ]);
            $pagesFetched++;
            if (!($response['ok'] ?? false)) {
                return [
                    'ok' => false,
                    'error' => $response['error'] ?? 'Failed to fetch customers',
                    'customers' => $customers,
                    'customer_count' => count($customers),
                    'pages_fetched' => $pagesFetched,
                ];
            }
            $batch = is_array($response['data']['customers'] ?? null) ? $response['data']['customers'] : [];
            foreach ($batch as $customer) {
                if (!is_array($customer)) {
                    continue;
                }
                $mapped = $this->mapCustomer($customer);
                if ($mapped !== null) {
                    $customers[] = $mapped;
                }
            }
            $pageInfo = $this->nextPageInfo($response['headers'] ?? []);
            if ($pageInfo === null || count($batch) < self::PAGE_LIMIT) {
                break;
            }
        }

        return [
            'ok' => true,
            'customers' => $customers,
            'customer_count' => count($customers),
            'pages_fetched' => $pagesFetched,
        ];
    }

    /**
     * Fetch Shopify orders for archived historical import.
     *
     * @param array<string, mixed> $credentials
     * @param array<string, mixed> $options
     * @return array{ok: bool, orders?: list<array<string, mixed>>, order_count?: int, pages_fetched?: int, error?: string}
     */
    public function fetchOrders(array $credentials, array $options = []): array
    {
        $shop = $this->normalizeShopDomain((string) ($credentials['shop_domain'] ?? ''));
        $token = trim((string) ($credentials['access_token'] ?? ''));
        if ($shop === '' || $token === '') {
            return ['ok' => false, 'error' => 'Shop domain and access token are required'];
        }

        $maxPages = max(1, min(self::MAX_PAGES, (int) ($options['max_pages'] ?? self::MAX_PAGES)));
        $status = trim((string) ($options['status'] ?? 'any'));
        if ($status === '') {
            $status = 'any';
        }
        $orders = [];
        $pageInfo = null;
        $pagesFetched = 0;

        for ($page = 0; $page < $maxPages; $page++) {
            if ($pageInfo !== null) {
                $query = 'limit=' . self::PAGE_LIMIT . '&page_info=' . rawurlencode($pageInfo);
            } else {
                $query = 'limit=' . self::PAGE_LIMIT . '&status=' . rawurlencode($status);
            }
            $url = $this->apiUrl($shop, 'orders.json?' . $query);
            $response = $this->http->request('GET', $url, [
                'headers' => $this->authHeaders($token),
            ]);
            $pagesFetched++;
            if (!($response['ok'] ?? false)) {
                return [
                    'ok' => false,
                    'error' => $response['error'] ?? 'Failed to fetch orders',
                    'orders' => $orders,
                    'order_count' => count($orders),
                    'pages_fetched' => $pagesFetched,
                ];
            }
            $batch = is_array($response['data']['orders'] ?? null) ? $response['data']['orders'] : [];
            foreach ($batch as $order) {
                if (!is_array($order)) {
                    continue;
                }
                $orders[] = $this->mapOrder($order);
            }
            $pageInfo = $this->nextPageInfo($response['headers'] ?? []);
            if ($pageInfo === null || count($batch) < self::PAGE_LIMIT) {
                break;
            }
        }

        return [
            'ok' => true,
            'orders' => $orders,
            'order_count' => count($orders),
            'pages_fetched' => $pagesFetched,
        ];
    }

    /**
     * @param array<string, mixed> $customer
     * @return array<string, mixed>|null
     */
    public function mapCustomer(array $customer): ?array
    {
        $email = strtolower(trim((string) ($customer['email'] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return null;
        }
        $first = trim((string) ($customer['first_name'] ?? ''));
        $last = trim((string) ($customer['last_name'] ?? ''));
        $name = trim($first . ' ' . $last);
        if ($name === '') {
            $name = trim((string) ($customer['default_address']['name'] ?? ''));
        }
        $tags = [];
        $rawTags = trim((string) ($customer['tags'] ?? ''));
        if ($rawTags !== '') {
            foreach (preg_split('/\s*,\s*/', $rawTags) ?: [] as $tag) {
                $tag = trim((string) $tag);
                if ($tag !== '') {
                    $tags[] = $tag;
                }
            }
        }
        $addresses = [];
        $addrList = is_array($customer['addresses'] ?? null) ? $customer['addresses'] : [];
        if ($addrList === [] && is_array($customer['default_address'] ?? null)) {
            $addrList = [$customer['default_address']];
        }
        foreach ($addrList as $addr) {
            if (!is_array($addr)) {
                continue;
            }
            $addresses[] = [
                'label' => !empty($addr['default']) ? 'Default' : 'Shipping',
                'name' => trim((string) ($addr['name'] ?? ($addr['first_name'] ?? '') . ' ' . ($addr['last_name'] ?? ''))),
                'line1' => (string) ($addr['address1'] ?? ''),
                'line2' => (string) ($addr['address2'] ?? ''),
                'city' => (string) ($addr['city'] ?? ''),
                'region' => (string) ($addr['province'] ?? ($addr['province_code'] ?? '')),
                'postal' => (string) ($addr['zip'] ?? ''),
                'country' => (string) ($addr['country_code'] ?? ($addr['country'] ?? '')),
                'phone' => (string) ($addr['phone'] ?? ''),
                'default' => !empty($addr['default']),
            ];
        }
        // Never map password / password-related fields from Shopify payloads.
        return [
            'email' => $email,
            'name' => $name,
            'phone' => trim((string) ($customer['phone'] ?? ($customer['default_address']['phone'] ?? ''))),
            'tags' => $tags,
            'notes' => trim((string) ($customer['note'] ?? '')),
            'addresses' => $addresses,
            'external_ids' => [
                'shopify' => (string) ($customer['id'] ?? ''),
            ],
            'source' => 'shopify',
            'shopify_customer_id' => (string) ($customer['id'] ?? ''),
        ];
    }

    /**
     * @param array<string, mixed> $order
     * @return array<string, mixed>
     */
    public function mapOrder(array $order): array
    {
        $shopifyId = (string) ($order['id'] ?? '');
        $email = strtolower(trim((string) ($order['email'] ?? ($order['customer']['email'] ?? ''))));
        $currency = strtolower((string) ($order['currency'] ?? ($order['presentment_currency'] ?? 'eur')));
        $totalCents = (int) round(((float) ($order['total_price'] ?? 0)) * 100);
        $subtotalCents = (int) round(((float) ($order['subtotal_price'] ?? 0)) * 100);
        $shippingCents = (int) round(((float) ($order['total_shipping_price_set']['shop_money']['amount']
            ?? $order['shipping_lines'][0]['price']
            ?? 0)) * 100);
        $taxCents = (int) round(((float) ($order['total_tax'] ?? 0)) * 100);
        $discountCents = (int) round(((float) ($order['total_discounts'] ?? 0)) * 100);

        $lines = [];
        foreach (is_array($order['line_items'] ?? null) ? $order['line_items'] : [] as $idx => $item) {
            if (!is_array($item)) {
                continue;
            }
            $qty = max(1, (int) ($item['quantity'] ?? 1));
            $unit = (int) round(((float) ($item['price'] ?? 0)) * 100);
            $fulfilled = strtolower((string) ($item['fulfillment_status'] ?? ($order['fulfillment_status'] ?? ''))) === 'fulfilled';
            $lines[] = [
                'line_id' => 'shopify_line_' . ($item['id'] ?? $idx),
                'title' => (string) ($item['title'] ?? 'Item'),
                'sku' => trim((string) ($item['sku'] ?? '')) ?: null,
                'quantity' => $qty,
                'unit_price_cents' => $unit,
                'line_total_cents' => $unit * $qty,
                'fulfillment_status' => $fulfilled ? 'shipped' : 'none',
                'entry_id' => null,
            ];
        }

        $taxLines = [];
        foreach (is_array($order['tax_lines'] ?? null) ? $order['tax_lines'] : [] as $tax) {
            if (!is_array($tax)) {
                continue;
            }
            $taxLines[] = [
                'title' => (string) ($tax['title'] ?? 'Tax'),
                'rate' => (float) ($tax['rate'] ?? 0),
                'tax_cents' => (int) round(((float) ($tax['price'] ?? 0)) * 100),
            ];
        }
        if ($taxLines === [] && $taxCents > 0) {
            $taxLines[] = ['title' => 'Tax', 'rate' => 0.0, 'tax_cents' => $taxCents];
        }

        $shippingLines = [];
        foreach (is_array($order['shipping_lines'] ?? null) ? $order['shipping_lines'] : [] as $ship) {
            if (!is_array($ship)) {
                continue;
            }
            $shippingLines[] = [
                'title' => (string) ($ship['title'] ?? 'Shipping'),
                'price_cents' => (int) round(((float) ($ship['price'] ?? 0)) * 100),
                'code' => (string) ($ship['code'] ?? ''),
            ];
        }
        if ($shippingLines === [] && $shippingCents > 0) {
            $shippingLines[] = ['title' => 'Shipping', 'price_cents' => $shippingCents, 'code' => ''];
        }

        $discountAllocations = [];
        if ($discountCents > 0) {
            $discountAllocations[] = [
                'code' => (string) ($order['discount_codes'][0]['code'] ?? 'shopify'),
                'amount_cents' => $discountCents,
            ];
        }

        $shipAddr = is_array($order['shipping_address'] ?? null) ? $order['shipping_address'] : null;
        $shippingAddress = null;
        if (is_array($shipAddr)) {
            $shippingAddress = [
                'name' => trim((string) ($shipAddr['name'] ?? (($shipAddr['first_name'] ?? '') . ' ' . ($shipAddr['last_name'] ?? '')))),
                'line1' => (string) ($shipAddr['address1'] ?? ''),
                'line2' => (string) ($shipAddr['address2'] ?? ''),
                'city' => (string) ($shipAddr['city'] ?? ''),
                'region' => (string) ($shipAddr['province'] ?? ''),
                'postal_code' => (string) ($shipAddr['zip'] ?? ''),
                'country' => (string) ($shipAddr['country_code'] ?? ($shipAddr['country'] ?? '')),
                'phone' => (string) ($shipAddr['phone'] ?? ''),
            ];
        }

        $fulfilled = in_array(strtolower((string) ($order['fulfillment_status'] ?? '')), ['fulfilled', 'partial'], true)
            || strtolower((string) ($order['financial_status'] ?? '')) === 'paid';

        return [
            'shopify_order_id' => $shopifyId,
            'name' => (string) ($order['name'] ?? ('#' . $shopifyId)),
            'customer_email' => $email,
            'customer_name' => trim((string) (($order['customer']['first_name'] ?? '') . ' ' . ($order['customer']['last_name'] ?? ''))),
            'currency' => $currency,
            'total_cents' => $totalCents,
            'subtotal_cents' => $subtotalCents,
            'shipping_cents' => $shippingCents,
            'tax_cents' => $taxCents,
            'discount_cents' => $discountCents,
            'tax_lines' => $taxLines,
            'shipping_lines' => $shippingLines,
            'discount_allocations' => $discountAllocations,
            'gift_card_applications' => [],
            'lines' => $lines,
            'shipping_address' => $shippingAddress,
            'created_at' => (string) ($order['created_at'] ?? date('c')),
            'financial_status' => (string) ($order['financial_status'] ?? ''),
            'fulfillment_status' => (string) ($order['fulfillment_status'] ?? ''),
            'tags' => array_values(array_filter(array_map('trim', preg_split('/\s*,\s*/', (string) ($order['tags'] ?? '')) ?: []))),
            'already_fulfilled' => $fulfilled,
        ];
    }

    /** @param array<string, mixed> $product @return list<array<string, mixed>> */
    private function mapProductToRows(array $product): array
    {
        $title = trim((string) ($product['title'] ?? 'Untitled'));
        $handle = trim((string) ($product['handle'] ?? $this->slugify($title)));
        $body = strip_tags((string) ($product['body_html'] ?? ''));
        $variants = is_array($product['variants'] ?? null) ? $product['variants'] : [];
        $images = is_array($product['images'] ?? null) ? $product['images'] : [];
        $imageUrl = is_array($images[0] ?? null) ? (string) ($images[0]['src'] ?? '') : '';

        if ($variants === []) {
            return [[
                'title' => $title,
                'slug' => $handle,
                'sku' => null,
                'body' => $body,
                'image_url' => $imageUrl !== '' ? $imageUrl : null,
                'parent_sku' => null,
                'variant_label' => null,
                'commerce' => $this->buildCommerceValue('0', null),
            ]];
        }

        $rows = [];
        $parentSku = $handle;
        $first = true;

        foreach ($variants as $variant) {
            if (!is_array($variant)) {
                continue;
            }
            $sku = trim((string) ($variant['sku'] ?? '')) ?: null;
            $price = (string) ($variant['price'] ?? '0');
            $qty = $variant['inventory_quantity'] ?? null;
            $label = trim((string) ($variant['title'] ?? ''));
            if ($label === '' || strtolower($label) === 'default title') {
                $label = trim((string) ($variant['option1'] ?? ''));
            }

            if ($first) {
                $rows[] = [
                    'title' => $title,
                    'slug' => $handle,
                    'sku' => $sku,
                    'body' => $body,
                    'image_url' => $imageUrl !== '' ? $imageUrl : null,
                    'parent_sku' => null,
                    'variant_label' => null,
                    'commerce' => $this->buildCommerceValue($price, $qty),
                ];
                $first = false;
                if (count($variants) === 1) {
                    break;
                }
                continue;
            }

            $variantLabel = $label !== '' ? $label : 'Variant';
            $rows[] = [
                'title' => $title . ' — ' . $variantLabel,
                'slug' => $handle . '-' . $this->slugify($variantLabel),
                'sku' => $sku,
                'body' => $body,
                'image_url' => null,
                'parent_sku' => $parentSku,
                'variant_label' => $variantLabel,
                'commerce' => $this->buildCommerceValue($price, $qty),
            ];
        }

        return $rows;
    }

    /** @return array<string, mixed> */
    private function buildCommerceValue(string $price, $quantity): array
    {
        $price = preg_replace('/[^0-9.]/', '', $price);
        $cents = (int) round((float) $price * 100);
        $qtyAvailable = ($quantity === '' || $quantity === null) ? null : (int) $quantity;

        if (!function_exists('commerce_normalize_value')) {
            require_once dirname(__DIR__) . '/init.php';
            commerce_bootstrap_cart_services();
        }

        return commerce_normalize_value([
            'fulfillment' => 'ship',
            'purchase_options' => [[
                'id' => 'import_default',
                'label' => 'Default',
                'billing' => 'one_time',
                'price_cents' => $cents,
            ]],
            'quantity_available' => $qtyAvailable,
        ]);
    }

    /** @param array<string, string> $headers */
    private function nextPageInfo(array $headers): ?string
    {
        $link = $headers['link'] ?? '';
        if ($link === '' || !preg_match('/<[^>]+[?&]page_info=([^>&]+)[^>]*>;\s*rel="next"/i', $link, $matches)) {
            return null;
        }

        return urldecode($matches[1]);
    }

    /** @return list<string> */
    private function authHeaders(string $token): array
    {
        return [
            'X-Shopify-Access-Token: ' . $token,
            'Accept: application/json',
        ];
    }

    private function apiUrl(string $shop, string $path): string
    {
        return 'https://' . $shop . '/admin/api/' . self::API_VERSION . '/' . ltrim($path, '/');
    }

    private function normalizeShopDomain(string $domain): string
    {
        $domain = trim(strtolower($domain));
        $domain = preg_replace('#^https?://#', '', $domain);
        $domain = rtrim($domain, '/');
        if ($domain !== '' && !str_contains($domain, '.')) {
            $domain .= '.myshopify.com';
        }

        return $domain;
    }

    private function slugify(string $text): string
    {
        $text = strtolower(trim($text));
        $text = preg_replace('/[^a-z0-9]+/', '-', $text);

        return trim($text, '-') ?: 'item';
    }
}
