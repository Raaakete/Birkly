<?php
/**
 * EasyPost live shipping rate quotes.
 *
 * Mock mode when credentials say mock, API key missing, or COMMERCE_EASYPOST_MOCK=1.
 * On live API failure → caller/resolver falls back to Manual zones.
 */

require_once __DIR__ . '/ShippingRateProviderInterface.php';
require_once __DIR__ . '/ManualShippingRateProvider.php';

class EasyPostShippingRateProvider implements ShippingRateProviderInterface
{
    private CommerceCatalog $catalog;

    /** @var callable|null */
    private $httpOverride = null;

    public function __construct(CommerceCatalog $catalog, $httpOverride = null)
    {
        $this->catalog = $catalog;
        $this->httpOverride = is_callable($httpOverride) ? $httpOverride : null;
    }

    public function getId(): string
    {
        return 'easypost';
    }

    public function getName(): string
    {
        return 'EasyPost';
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context
     */
    public function quote(array $lines, ?array $shippingAddress = null, array $context = []): array
    {
        if (!$this->catalog->cartHasShippableLines($lines)) {
            return [
                'ok' => true,
                'rates' => [],
                'shipping_lines' => [],
                'shipping_cents' => 0,
                'provider' => 'easypost',
            ];
        }

        $weightError = $this->catalog->validateShippableWeights($lines);
        if ($weightError !== null) {
            return [
                'ok' => false,
                'error' => $weightError,
                'rates' => [],
                'shipping_lines' => [],
                'shipping_cents' => 0,
                'provider' => 'easypost',
            ];
        }

        $country = strtoupper(trim((string) ($shippingAddress['country'] ?? '')));
        if ($country === '') {
            // Cannot quote live without destination — soft-fallback to manual.
            return $this->fallbackManual($lines, $shippingAddress, $context, 'Destination country required for live rates');
        }

        if (!empty($context['force_fail'])) {
            return $this->fallbackManual($lines, $shippingAddress, $context, 'EasyPost forced failure');
        }

        if ($this->wantsMockWithoutCredentials($context)) {
            return $this->selectRate($this->calculateMockRates($lines, $shippingAddress), $context, false);
        }

        $credentials = is_array($context['credentials'] ?? null)
            ? $context['credentials']
            : $this->resolveCredentials();
        if ($this->shouldUseMock($credentials, $context)) {
            return $this->selectRate($this->calculateMockRates($lines, $shippingAddress), $context, false);
        }

        $apiKey = (string) ($credentials['api_key'] ?? $credentials['easypost_api_key'] ?? '');
        if ($apiKey === '') {
            return $this->selectRate($this->calculateMockRates($lines, $shippingAddress), $context, false);
        }

        try {
            $rates = $this->calculateLiveRates($lines, $shippingAddress, $context, $apiKey);
            if ($rates === []) {
                return $this->fallbackManual($lines, $shippingAddress, $context, 'EasyPost returned no rates');
            }
            return $this->selectRate($rates, $context, false);
        } catch (Throwable $e) {
            return $this->fallbackManual($lines, $shippingAddress, $context, $e->getMessage());
        }
    }

    /**
     * @param array<string, mixed> $context
     */
    private function wantsMockWithoutCredentials(array $context): bool
    {
        if (!empty($context['force_mock'])) {
            return true;
        }
        $env = getenv('COMMERCE_EASYPOST_MOCK');
        return $env === '1' || strtolower((string) $env) === 'true';
    }

    /**
     * @param array<string, mixed> $credentials
     * @param array<string, mixed> $context
     */
    public function shouldUseMock(array $credentials, array $context = []): bool
    {
        if ($this->wantsMockWithoutCredentials($context)) {
            return true;
        }
        if (!empty($credentials['mock']) || !empty($credentials['test_mode'])) {
            return true;
        }
        $apiKey = (string) ($credentials['api_key'] ?? $credentials['easypost_api_key'] ?? '');
        return $apiKey === '' || strtolower($apiKey) === 'mock';
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @return list<array<string, mixed>>
     */
    private function calculateMockRates(array $lines, ?array $shippingAddress): array
    {
        $weight = max(1, $this->catalog->calculateCartWeightGrams($lines));
        $country = strtoupper(trim((string) ($shippingAddress['country'] ?? 'XX')));
        $base = 400 + (int) floor($weight / 100) * 50;
        if ($country !== 'US' && $country !== 'DE') {
            $base += 200;
        }

        $rates = [
            [
                'id' => 'ep_mock_ground_' . $country,
                'title' => 'EasyPost Ground',
                'code' => 'Ground',
                'price_cents' => $base,
                'carrier' => 'EasyPostMock',
                'service' => 'Ground',
                'source' => 'easypost',
                'mode' => 'mock',
            ],
            [
                'id' => 'ep_mock_express_' . $country,
                'title' => 'EasyPost Express',
                'code' => 'Express',
                'price_cents' => $base + 350,
                'carrier' => 'EasyPostMock',
                'service' => 'Express',
                'source' => 'easypost',
                'mode' => 'mock',
            ],
        ];
        return $rates;
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context
     * @return list<array<string, mixed>>
     */
    private function calculateLiveRates(array $lines, ?array $shippingAddress, array $context, string $apiKey): array
    {
        $config = $this->catalog->loadShippingZones();
        $from = is_array($config['from_address'] ?? null) ? $config['from_address'] : [];
        $fromAddress = [
            'name' => (string) ($from['name'] ?? 'Warehouse'),
            'street1' => (string) ($from['street1'] ?? ($from['line1'] ?? '1 Market St')),
            'city' => (string) ($from['city'] ?? 'San Francisco'),
            'state' => (string) ($from['state'] ?? 'CA'),
            'zip' => (string) ($from['zip'] ?? ($from['postal_code'] ?? '94105')),
            'country' => strtoupper((string) ($from['country'] ?? 'US')),
        ];

        $toAddress = [
            'name' => (string) ($shippingAddress['name'] ?? 'Customer'),
            'street1' => (string) ($shippingAddress['line1'] ?? ($shippingAddress['street1'] ?? '')),
            'street2' => (string) ($shippingAddress['line2'] ?? ($shippingAddress['street2'] ?? '')),
            'city' => (string) ($shippingAddress['city'] ?? ''),
            'state' => (string) ($shippingAddress['state'] ?? ''),
            'zip' => (string) ($shippingAddress['postal_code'] ?? ($shippingAddress['zip'] ?? ($shippingAddress['postcode'] ?? ''))),
            'country' => strtoupper((string) ($shippingAddress['country'] ?? '')),
        ];

        $weightOz = max(0.1, $this->catalog->calculateCartWeightGrams($lines) / 28.3495);
        $dims = $this->catalog->calculateCartDimensionsMm($lines);
        $parcel = [
            'weight' => round($weightOz, 2),
        ];
        if ($dims['length_mm'] > 0 && $dims['width_mm'] > 0 && $dims['height_mm'] > 0) {
            // EasyPost expects inches.
            $parcel['length'] = round($dims['length_mm'] / 25.4, 2);
            $parcel['width'] = round($dims['width_mm'] / 25.4, 2);
            $parcel['height'] = round($dims['height_mm'] / 25.4, 2);
        }

        $body = [
            'shipment' => [
                'to_address' => $toAddress,
                'from_address' => $fromAddress,
                'parcel' => $parcel,
            ],
        ];

        $resp = $this->requestJson('POST', 'https://api.easypost.com/v2/shipments', $body, [
            'auth' => ['user' => $apiKey, 'pass' => ''],
        ]);
        if (empty($resp['ok']) || !is_array($resp['data'])) {
            throw new RuntimeException((string) ($resp['error'] ?? 'EasyPost rate quote failed'));
        }

        $rawRates = is_array($resp['data']['rates'] ?? null) ? $resp['data']['rates'] : [];
        $rates = [];
        foreach ($rawRates as $raw) {
            if (!is_array($raw)) {
                continue;
            }
            $amount = (float) ($raw['rate'] ?? 0);
            $priceCents = (int) round($amount * 100);
            $id = (string) ($raw['id'] ?? ('ep_' . substr(hash('sha256', json_encode($raw)), 0, 12)));
            $carrier = (string) ($raw['carrier'] ?? 'carrier');
            $service = (string) ($raw['service'] ?? 'service');
            $rates[] = [
                'id' => $id,
                'title' => trim($carrier . ' ' . $service),
                'code' => $service,
                'price_cents' => max(0, $priceCents),
                'carrier' => $carrier,
                'service' => $service,
                'source' => 'easypost',
                'mode' => 'live',
            ];
        }

        usort($rates, static fn ($a, $b) => ($a['price_cents'] <=> $b['price_cents']));
        return $rates;
    }

    /**
     * @param list<array<string, mixed>> $rates
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function selectRate(array $rates, array $context, bool $fallback): array
    {
        if ($rates === []) {
            return [
                'ok' => true,
                'rates' => [],
                'shipping_lines' => [],
                'shipping_cents' => 0,
                'provider' => 'easypost',
                'fallback' => $fallback ?: null,
            ];
        }

        usort($rates, static fn ($a, $b) => ((int) $a['price_cents'] <=> (int) $b['price_cents']));
        $selectedId = trim((string) ($context['selected_rate_id'] ?? ''));
        $selected = $rates[0];
        if ($selectedId !== '') {
            foreach ($rates as $rate) {
                if (($rate['id'] ?? '') === $selectedId) {
                    $selected = $rate;
                    break;
                }
            }
        }

        $line = [
            'id' => $selected['id'],
            'title' => $selected['title'] ?? 'Shipping',
            'code' => $selected['code'] ?? 'shipping',
            'price_cents' => (int) ($selected['price_cents'] ?? 0),
            'carrier' => $selected['carrier'] ?? null,
            'service' => $selected['service'] ?? null,
            'source' => $selected['source'] ?? 'easypost',
        ];

        $out = [
            'ok' => true,
            'rates' => $rates,
            'shipping_lines' => [$line],
            'shipping_cents' => (int) $line['price_cents'],
            'provider' => 'easypost',
        ];
        if ($fallback) {
            $out['fallback'] = true;
        }
        return $out;
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function fallbackManual(array $lines, ?array $shippingAddress, array $context, string $error): array
    {
        $manual = new ManualShippingRateProvider($this->catalog);
        $quote = $manual->quote($lines, $shippingAddress, $context);
        $quote['provider'] = 'easypost';
        $quote['fallback'] = true;
        $quote['error'] = $error;
        $quote['ok'] = true;
        // Keep manual source on lines but mark provider path.
        foreach ($quote['shipping_lines'] as &$line) {
            $line['fallback_from'] = 'easypost';
        }
        unset($line);
        foreach ($quote['rates'] as &$rate) {
            $rate['fallback_from'] = 'easypost';
        }
        unset($rate);
        return $quote;
    }

    /** @return array<string, mixed> */
    private function resolveCredentials(): array
    {
        $config = $this->catalog->loadShippingZones();
        $key = trim((string) ($config['easypost_api_key'] ?? ''));
        if ($key === '' && function_exists('commerce_get_setting')) {
            $key = trim((string) commerce_get_setting('commerce_easypost_api_key', ''));
        } elseif ($key === '' && function_exists('get_plugin_setting')) {
            $key = trim((string) get_plugin_setting('commerce', 'commerce_easypost_api_key', ''));
        }
        if ($key !== '') {
            return ['api_key' => $key];
        }
        return [];
    }

    /**
     * @param array<string, mixed> $body
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function requestJson(string $method, string $url, array $body, array $options = []): array
    {
        if ($this->httpOverride !== null) {
            $fn = $this->httpOverride;
            return $fn($method, $url, array_merge($options, ['body' => $body]));
        }

        $headers = $options['headers'] ?? [];
        $auth = $options['auth'] ?? null;
        if ($auth !== null) {
            if (is_array($auth)) {
                $headers[] = 'Authorization: Basic ' . base64_encode(($auth['user'] ?? '') . ':' . ($auth['pass'] ?? ''));
            } else {
                $headers[] = 'Authorization: Bearer ' . $auth;
            }
        }
        $headers[] = 'Content-Type: application/json';

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => json_encode($body),
            CURLOPT_TIMEOUT => (int) ($options['timeout'] ?? 30),
        ]);

        $response = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return ['ok' => false, 'status' => 0, 'error' => $error ?: 'HTTP request failed', 'data' => null];
        }

        $decoded = json_decode($response, true);
        return [
            'ok' => $status >= 200 && $status < 300,
            'status' => $status,
            'error' => ($status >= 200 && $status < 300)
                ? null
                : (is_array($decoded) ? ($decoded['error']['message'] ?? $decoded['message'] ?? ('HTTP ' . $status)) : ('HTTP ' . $status)),
            'data' => $decoded ?? $response,
        ];
    }
}
