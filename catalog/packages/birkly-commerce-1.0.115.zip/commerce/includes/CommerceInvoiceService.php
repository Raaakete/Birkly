<?php
/**
 * Invoice profiles, sequential numbers, and editable HTML templates.
 *
 * Merchants own legal wording: presets are starting points that can be edited,
 * duplicated, or replaced with custom templates and {{tokens}}.
 */

class CommerceInvoiceService
{
    private string $dataDir;
    private CommerceOrderStore $orders;

    /** @deprecated Use listTemplates() — kept for API compatibility */
    public const TEMPLATES = ['classic', 'compact', 'eu_vat'];

    public function __construct(?string $dataDir = null, ?CommerceOrderStore $orders = null)
    {
        $this->dataDir = rtrim($dataDir ?? commerce_data_dir(), '/');
        if (!is_dir($this->dataDir)) {
            mkdir($this->dataDir, 0755, true);
        }
        $this->orders = $orders ?? new CommerceOrderStore($this->dataDir . '/orders');
    }

    public function profilePath(): string
    {
        return $this->dataDir . '/invoice_profile.json';
    }

    public function sequencePath(): string
    {
        return $this->dataDir . '/invoice_sequence.json';
    }

    public function templatesPath(): string
    {
        return $this->dataDir . '/invoice_templates.json';
    }

    /**
     * @return array<string, mixed>
     */
    public function defaultProfile(): array
    {
        return [
            'company_name' => 'Your Company',
            'address' => '',
            'vat_id' => '',
            'email' => '',
            'phone' => '',
            'bank_iban' => '',
            'logo_url' => '',
            'footer_note' => 'Thank you for your business.',
            'tax_note' => '',
            'template' => 'classic',
            'number_prefix' => 'INV',
            'auto_issue_on_paid' => true,
            'legal_disclaimer_accepted' => false,
            'legal_disclaimer' => 'You are responsible for the legal correctness of invoices generated with this profile (tax IDs, reverse charge wording, local invoice requirements). Birkly provides editable templates only.',
        ];
    }

    /**
     * @return list<array{token: string, label: string}>
     */
    public function availableTokens(): array
    {
        return [
            ['token' => 'company_name', 'label' => 'Company name'],
            ['token' => 'seller_address_html', 'label' => 'Seller address (HTML)'],
            ['token' => 'seller_email', 'label' => 'Seller email'],
            ['token' => 'seller_phone', 'label' => 'Seller phone'],
            ['token' => 'seller_vat', 'label' => 'Seller VAT / tax ID'],
            ['token' => 'bank_iban', 'label' => 'Bank IBAN'],
            ['token' => 'logo_html', 'label' => 'Logo image HTML'],
            ['token' => 'invoice_number', 'label' => 'Invoice number'],
            ['token' => 'order_number', 'label' => 'Order number'],
            ['token' => 'issued_date', 'label' => 'Issue date'],
            ['token' => 'status', 'label' => 'Order status'],
            ['token' => 'customer_name', 'label' => 'Customer name'],
            ['token' => 'customer_email', 'label' => 'Customer email'],
            ['token' => 'bill_to_html', 'label' => 'Bill-to block (HTML)'],
            ['token' => 'ship_to_html', 'label' => 'Ship-to block (HTML)'],
            ['token' => 'buyer_vat', 'label' => 'Buyer VAT ID'],
            ['token' => 'line_items_html', 'label' => 'Line items table rows'],
            ['token' => 'money_html', 'label' => 'Totals block (HTML)'],
            ['token' => 'eu_vat_meta_html', 'label' => 'EU VAT meta box (HTML)'],
            ['token' => 'footer_note', 'label' => 'Footer note'],
            ['token' => 'tax_note', 'label' => 'Tax / reverse-charge note'],
            ['token' => 'legal_disclaimer', 'label' => 'Legal disclaimer'],
            ['token' => 'currency', 'label' => 'Currency'],
            ['token' => 'order_total', 'label' => 'Order total formatted'],
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function defaultTemplates(): array
    {
        return [
            [
                'id' => 'classic',
                'name' => 'Classic',
                'preset' => true,
                'body_html' => $this->presetBodyHtml('classic'),
            ],
            [
                'id' => 'compact',
                'name' => 'Compact',
                'preset' => true,
                'body_html' => $this->presetBodyHtml('compact'),
            ],
            [
                'id' => 'eu_vat',
                'name' => 'EU VAT',
                'preset' => true,
                'body_html' => $this->presetBodyHtml('eu_vat'),
            ],
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listTemplates(): array
    {
        $defaults = $this->defaultTemplates();
        if (!is_file($this->templatesPath())) {
            $this->saveAllTemplates($defaults);
            return $defaults;
        }
        $data = json_decode((string) file_get_contents($this->templatesPath()), true);
        $stored = is_array($data['templates'] ?? null) ? $data['templates'] : [];
        if ($stored === []) {
            $this->saveAllTemplates($defaults);
            return $defaults;
        }

        $byId = [];
        foreach ($stored as $tpl) {
            if (is_array($tpl) && !empty($tpl['id'])) {
                $byId[(string) $tpl['id']] = $this->normalizeTemplate($tpl);
            }
        }
        // Ensure presets exist (upgrade path).
        foreach ($defaults as $def) {
            if (!isset($byId[$def['id']])) {
                $byId[$def['id']] = $def;
            } else {
                $byId[$def['id']]['preset'] = true;
                if (trim((string) ($byId[$def['id']]['name'] ?? '')) === '') {
                    $byId[$def['id']]['name'] = $def['name'];
                }
            }
        }
        return array_values($byId);
    }

    /**
     * @param array<string, mixed> $tpl
     * @return array<string, mixed>
     */
    private function normalizeTemplate(array $tpl): array
    {
        $id = trim((string) ($tpl['id'] ?? ''));
        if ($id === '') {
            $id = 'invtpl_' . bin2hex(random_bytes(4));
        }
        $id = strtolower(preg_replace('/[^a-z0-9_-]/', '-', $id) ?? $id);
        return [
            'id' => $id,
            'name' => trim((string) ($tpl['name'] ?? 'Invoice template')),
            'preset' => !empty($tpl['preset']) || in_array($id, self::TEMPLATES, true),
            'body_html' => (string) ($tpl['body_html'] ?? ''),
        ];
    }

    /**
     * @param list<array<string, mixed>> $templates
     */
    public function saveAllTemplates(array $templates): void
    {
        $clean = [];
        foreach ($templates as $tpl) {
            if (is_array($tpl)) {
                $clean[] = $this->normalizeTemplate($tpl);
            }
        }
        file_put_contents($this->templatesPath(), json_encode([
            'templates' => $clean,
            'updated_at' => date('c'),
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /**
     * @param array<string, mixed> $tpl
     * @return array<string, mixed>
     */
    public function saveTemplate(array $tpl): array
    {
        $normalized = $this->normalizeTemplate($tpl);
        $all = $this->listTemplates();
        $found = false;
        foreach ($all as $i => $existing) {
            if (($existing['id'] ?? '') === $normalized['id']) {
                // Keep preset flag from existing when editing a built-in id.
                $normalized['preset'] = !empty($existing['preset']) || !empty($normalized['preset']);
                $all[$i] = $normalized;
                $found = true;
                break;
            }
        }
        if (!$found) {
            $normalized['preset'] = false;
            $all[] = $normalized;
        }
        $this->saveAllTemplates($all);
        return $normalized;
    }

    /**
     * @return array{ok: bool, error?: string, template?: array}
     */
    public function duplicateTemplate(string $id, ?string $newName = null): array
    {
        $source = null;
        foreach ($this->listTemplates() as $tpl) {
            if (($tpl['id'] ?? '') === $id) {
                $source = $tpl;
                break;
            }
        }
        if (!$source) {
            return ['ok' => false, 'error' => 'Template not found'];
        }
        $copy = $source;
        $copy['id'] = 'invtpl_' . bin2hex(random_bytes(4));
        $copy['name'] = $newName !== null && trim($newName) !== ''
            ? trim($newName)
            : ((string) ($source['name'] ?? 'Template') . ' (copy)');
        $copy['preset'] = false;
        $saved = $this->saveTemplate($copy);
        return ['ok' => true, 'template' => $saved];
    }

    /**
     * @return array{ok: bool, error?: string}
     */
    public function deleteTemplate(string $id): array
    {
        if (in_array($id, self::TEMPLATES, true)) {
            return ['ok' => false, 'error' => 'Built-in presets cannot be deleted — duplicate them to customize freely, or edit in place'];
        }
        $profile = $this->getProfile();
        if (($profile['template'] ?? '') === $id) {
            return ['ok' => false, 'error' => 'Cannot delete the active template — switch active template first'];
        }
        $all = array_values(array_filter(
            $this->listTemplates(),
            static fn($tpl): bool => ($tpl['id'] ?? '') !== $id
        ));
        $this->saveAllTemplates($all);
        return ['ok' => true];
    }

    /**
     * @return array<string, mixed>|null
     */
    public function getTemplate(string $id): ?array
    {
        foreach ($this->listTemplates() as $tpl) {
            if (($tpl['id'] ?? '') === $id) {
                return $tpl;
            }
        }
        return null;
    }

    /**
     * @return array<string, mixed>
     */
    public function getProfile(): array
    {
        $defaults = $this->defaultProfile();
        if (!is_file($this->profilePath())) {
            return $defaults;
        }
        $data = json_decode((string) file_get_contents($this->profilePath()), true);
        if (!is_array($data)) {
            return $defaults;
        }
        $merged = array_merge($defaults, $data);
        $template = strtolower(trim((string) ($merged['template'] ?? 'classic')));
        if ($template === '') {
            $template = 'classic';
        }
        $merged['template'] = $template;
        $merged['auto_issue_on_paid'] = !empty($merged['auto_issue_on_paid']);
        $merged['legal_disclaimer_accepted'] = !empty($merged['legal_disclaimer_accepted']);
        return $merged;
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    public function saveProfile(array $input): array
    {
        $current = $this->getProfile();
        $allowed = array_keys($this->defaultProfile());
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $input)) {
                continue;
            }
            if ($key === 'auto_issue_on_paid' || $key === 'legal_disclaimer_accepted') {
                $current[$key] = !empty($input[$key]);
                continue;
            }
            if ($key === 'template') {
                $t = strtolower(trim((string) $input[$key]));
                $current[$key] = $t !== '' ? $t : 'classic';
                continue;
            }
            if ($key === 'number_prefix') {
                $prefix = strtoupper(preg_replace('/[^A-Z0-9_-]/', '', (string) $input[$key]) ?? '');
                $current[$key] = $prefix !== '' ? substr($prefix, 0, 12) : 'INV';
                continue;
            }
            $current[$key] = is_string($input[$key]) ? trim($input[$key]) : $input[$key];
        }
        file_put_contents($this->profilePath(), json_encode($current, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        return $current;
    }

    /**
     * @return array{ok: bool, order?: array, error?: string, issued?: bool}
     */
    public function ensureInvoice(string $orderId): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        if (!empty($order['invoice_number'])) {
            return ['ok' => true, 'order' => $order, 'issued' => false];
        }

        $profile = $this->getProfile();
        $number = $this->allocateInvoiceNumber((string) ($profile['number_prefix'] ?? 'INV'), $order['paid_at'] ?? $order['created_at'] ?? null);
        $snapshot = [
            'company_name' => $profile['company_name'] ?? '',
            'address' => $profile['address'] ?? '',
            'vat_id' => $profile['vat_id'] ?? '',
            'email' => $profile['email'] ?? '',
            'phone' => $profile['phone'] ?? '',
            'bank_iban' => $profile['bank_iban'] ?? '',
            'logo_url' => $profile['logo_url'] ?? '',
            'footer_note' => $profile['footer_note'] ?? '',
            'tax_note' => $profile['tax_note'] ?? '',
            'template' => $profile['template'] ?? 'classic',
            'legal_disclaimer' => $profile['legal_disclaimer'] ?? '',
        ];
        $updated = $this->orders->update($orderId, [
            'invoice_number' => $number,
            'invoice_issued_at' => date('c'),
            'invoice_seller_snapshot' => $snapshot,
        ]);
        return ['ok' => true, 'order' => $updated ?? $order, 'issued' => true];
    }

    public function allocateInvoiceNumber(string $prefix = 'INV', ?string $anchorDate = null): string
    {
        $ts = $anchorDate ? strtotime($anchorDate) : time();
        if ($ts === false) {
            $ts = time();
        }
        $year = date('Y', $ts);
        $path = $this->sequencePath();
        $data = ['years' => []];
        if (is_file($path)) {
            $decoded = json_decode((string) file_get_contents($path), true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
        }
        if (!isset($data['years']) || !is_array($data['years'])) {
            $data['years'] = [];
        }
        $next = ((int) ($data['years'][$year] ?? 0)) + 1;
        $data['years'][$year] = $next;
        $data['updated_at'] = date('c');
        file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT));
        $prefix = strtoupper(preg_replace('/[^A-Z0-9_-]/', '', $prefix) ?? 'INV');
        if ($prefix === '') {
            $prefix = 'INV';
        }
        return sprintf('%s-%s-%04d', $prefix, $year, $next);
    }

    /**
     * @param array<string, mixed> $brandOverride
     * @param string|null $bodyOverride Unsaved HTML body for admin preview (skips stored template body)
     */
    public function buildInvoiceHtml(array $order, array $brandOverride = [], bool $autoIssue = true, ?string $bodyOverride = null): string
    {
        if ($autoIssue && empty($order['invoice_number']) && !empty($order['id'])) {
            $ensured = $this->ensureInvoice((string) $order['id']);
            if (($ensured['ok'] ?? false) && is_array($ensured['order'] ?? null)) {
                $order = $ensured['order'];
            }
        }

        $profile = $this->getProfile();
        // Freeze seller identity at issue time; keep template + legal notes live so
        // merchants can correct wording and reprint without re-issuing the number.
        $snapshot = is_array($order['invoice_seller_snapshot'] ?? null)
            ? $order['invoice_seller_snapshot']
            : [];
        $seller = $profile;
        foreach (['company_name', 'address', 'vat_id', 'email', 'phone', 'bank_iban', 'logo_url'] as $identityKey) {
            if (array_key_exists($identityKey, $snapshot) && trim((string) $snapshot[$identityKey]) !== '') {
                $seller[$identityKey] = $snapshot[$identityKey];
            }
        }
        if ($brandOverride !== []) {
            if (!empty($brandOverride['name'])) {
                $seller['company_name'] = $brandOverride['name'];
            }
            if (array_key_exists('email', $brandOverride) && $brandOverride['email'] !== '') {
                $seller['email'] = $brandOverride['email'];
            }
            if (array_key_exists('address', $brandOverride) && $brandOverride['address'] !== '') {
                $seller['address'] = $brandOverride['address'];
            }
        }

        $templateId = strtolower((string) ($profile['template'] ?? 'classic'));
        $tpl = $this->getTemplate($templateId);
        if (!$tpl) {
            $tpl = $this->getTemplate('classic') ?? [
                'id' => 'classic',
                'body_html' => $this->presetBodyHtml('classic'),
            ];
            $templateId = (string) ($tpl['id'] ?? 'classic');
        }

        $tokens = $this->buildTokenMap($order, $seller, $profile, $templateId);
        $bodySource = $bodyOverride !== null ? $bodyOverride : (string) ($tpl['body_html'] ?? '');
        // Ensure logo token is present even if Content Editor/custom HTML omitted it.
        if (($tokens['logo_html'] ?? '') !== ''
            && !preg_match('/\{\{\s*logo_html\s*\}\}/i', $bodySource)
            && stripos($bodySource, 'class="logo"') === false
            && stripos($bodySource, "class='logo'") === false
        ) {
            $bodySource = "{{logo_html}}\n" . $bodySource;
        }
        $body = $this->renderString($bodySource, $tokens);
        $css = $this->templateCss($templateId);
        $baseHref = $this->cmsOriginBase();
        $baseTag = $baseHref !== ''
            ? '<base href="' . htmlspecialchars(rtrim($baseHref, '/') . '/', ENT_QUOTES, 'UTF-8') . '">'
            : '';

        return '<!DOCTYPE html><html><head><meta charset="utf-8">' . $baseTag . '<title>Invoice '
            . htmlspecialchars((string) ($tokens['invoice_number'] ?? ''), ENT_QUOTES, 'UTF-8')
            . '</title><style>' . $css . '</style></head><body><div class="wrap tmpl-'
            . htmlspecialchars($templateId, ENT_QUOTES, 'UTF-8') . '">'
            . $body
            . '</div><script>window.onload=function(){window.focus();setTimeout(function(){window.print()},150)}</script></body></html>';
    }

    /**
     * @param array<string, string> $tokens
     */
    public function renderString(string $template, array $tokens): string
    {
        return (string) preg_replace_callback('/\{\{\s*([a-z0-9_]+)\s*\}\}/i', static function ($m) use ($tokens) {
            $key = strtolower($m[1]);
            return array_key_exists($key, $tokens) ? (string) $tokens[$key] : $m[0];
        }, $template);
    }

    /**
     * @param array<string, mixed> $seller
     * @param array<string, mixed> $profile
     * @return array<string, string>
     */
    public function buildTokenMap(array $order, array $seller, array $profile, string $templateId = 'classic'): array
    {
        $addr = is_array($order['shipping_address'] ?? null) ? $order['shipping_address'] : [];
        $billing = is_array($order['billing_address'] ?? null) ? $order['billing_address'] : $addr;
        $customerName = (string) ($billing['name'] ?? $addr['name'] ?? $order['customer_name'] ?? '');
        $billBlock = trim(implode("\n", array_filter([
            $billing['name'] ?? ($order['customer_name'] ?? null),
            $billing['line1'] ?? null,
            $billing['line2'] ?? null,
            trim(($billing['postal_code'] ?? '') . ' ' . ($billing['city'] ?? '')),
            $billing['country'] ?? null,
        ])));
        $shipBlock = trim(implode("\n", array_filter([
            $addr['name'] ?? null,
            $addr['line1'] ?? null,
            $addr['line2'] ?? null,
            trim(($addr['postal_code'] ?? '') . ' ' . ($addr['city'] ?? '')),
            $addr['country'] ?? null,
        ])));

        $currency = strtoupper((string) ($order['currency'] ?? 'EUR'));
        $fmt = static function (int $cents) use ($currency): string {
            return $currency . ' ' . number_format($cents / 100, 2, '.', '');
        };

        $rows = '';
        $subtotal = 0;
        foreach ($order['lines'] ?? [] as $line) {
            if (!is_array($line)) {
                continue;
            }
            $qty = (int) ($line['quantity'] ?? 1);
            $total = (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
            $subtotal += $total;
            $title = htmlspecialchars((string) ($line['title'] ?? 'Item'), ENT_QUOTES, 'UTF-8');
            $sku = htmlspecialchars((string) ($line['sku'] ?? ''), ENT_QUOTES, 'UTF-8');
            $rows .= '<tr><td><strong>' . $title . '</strong>'
                . ($sku !== '' ? '<div class="muted">SKU ' . $sku . '</div>' : '')
                . '</td><td>' . $qty . '</td><td class="right">' . htmlspecialchars($fmt($total), ENT_QUOTES, 'UTF-8') . '</td></tr>';
        }

        $shipping = (int) ($order['shipping_cents'] ?? 0);
        $tax = (int) ($order['tax_cents'] ?? 0);
        $discount = (int) ($order['discount_cents'] ?? 0);
        $gift = (int) ($order['gift_card_cents'] ?? 0);
        $total = (int) ($order['total_cents'] ?? 0);

        $money = '';
        $money .= '<div><span>Items</span><span>' . htmlspecialchars($fmt($subtotal), ENT_QUOTES, 'UTF-8') . '</span></div>';
        if ($discount > 0) {
            $money .= '<div><span>Discount</span><span>−' . htmlspecialchars($fmt($discount), ENT_QUOTES, 'UTF-8') . '</span></div>';
        }
        $money .= '<div><span>Shipping</span><span>' . htmlspecialchars($fmt($shipping), ENT_QUOTES, 'UTF-8') . '</span></div>';
        $taxLabel = ($templateId === 'eu_vat') ? 'VAT / Tax' : 'Tax';
        $money .= '<div><span>' . $taxLabel . '</span><span>' . htmlspecialchars($fmt($tax), ENT_QUOTES, 'UTF-8') . '</span></div>';
        if ($gift > 0) {
            $money .= '<div><span>Gift card</span><span>−' . htmlspecialchars($fmt($gift), ENT_QUOTES, 'UTF-8') . '</span></div>';
        }
        $money .= '<div class="total"><span>Total</span><span>' . htmlspecialchars($fmt($total), ENT_QUOTES, 'UTF-8') . '</span></div>';

        $sellerVat = (string) ($seller['vat_id'] ?? '');
        $vatIdBuyer = (string) ($order['vat_id'] ?? '');
        $iban = (string) ($seller['bank_iban'] ?? '');
        $euBits = '<div class="meta-box">'
            . '<div><strong>Seller VAT:</strong> ' . htmlspecialchars($sellerVat !== '' ? $sellerVat : '—', ENT_QUOTES, 'UTF-8') . '</div>'
            . '<div><strong>Buyer VAT:</strong> ' . htmlspecialchars($vatIdBuyer !== '' ? $vatIdBuyer : '—', ENT_QUOTES, 'UTF-8') . '</div>'
            . ($iban !== '' ? '<div><strong>IBAN:</strong> ' . htmlspecialchars($iban, ENT_QUOTES, 'UTF-8') . '</div>' : '')
            . '</div>';

        $logo = $this->resolveLogoSrc(trim((string) ($seller['logo_url'] ?? '')));
        $logoHtml = $logo !== ''
            ? '<img class="logo" src="' . htmlspecialchars($logo, ENT_QUOTES, 'UTF-8') . '" alt="">'
            : '';

        $taxNote = (string) ($seller['tax_note'] ?? $profile['tax_note'] ?? '');
        $footer = (string) ($seller['footer_note'] ?? $profile['footer_note'] ?? '');
        $disclaimer = (string) ($profile['legal_disclaimer'] ?? '');

        return [
            'company_name' => htmlspecialchars((string) ($seller['company_name'] ?? 'Invoice'), ENT_QUOTES, 'UTF-8'),
            'seller_address_html' => nl2br(htmlspecialchars((string) ($seller['address'] ?? ''), ENT_QUOTES, 'UTF-8')),
            'seller_email' => htmlspecialchars((string) ($seller['email'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'seller_phone' => htmlspecialchars((string) ($seller['phone'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'seller_vat' => htmlspecialchars($sellerVat, ENT_QUOTES, 'UTF-8'),
            'bank_iban' => htmlspecialchars($iban, ENT_QUOTES, 'UTF-8'),
            'logo_html' => $logoHtml,
            'invoice_number' => htmlspecialchars((string) ($order['invoice_number'] ?? $order['order_number'] ?? $order['id'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'order_number' => htmlspecialchars((string) ($order['order_number'] ?? $order['id'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'issued_date' => htmlspecialchars(substr((string) ($order['invoice_issued_at'] ?? $order['paid_at'] ?? $order['created_at'] ?? ''), 0, 10), ENT_QUOTES, 'UTF-8'),
            'status' => htmlspecialchars((string) ($order['status'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'customer_name' => htmlspecialchars($customerName, ENT_QUOTES, 'UTF-8'),
            'customer_email' => htmlspecialchars((string) ($order['customer_email'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'bill_to_html' => nl2br(htmlspecialchars($billBlock !== '' ? $billBlock : ($customerName !== '' ? $customerName : '—'), ENT_QUOTES, 'UTF-8')),
            'ship_to_html' => nl2br(htmlspecialchars($shipBlock !== '' ? $shipBlock : '—', ENT_QUOTES, 'UTF-8')),
            'buyer_vat' => htmlspecialchars($vatIdBuyer, ENT_QUOTES, 'UTF-8'),
            'line_items_html' => $rows,
            'money_html' => $money,
            'eu_vat_meta_html' => $euBits,
            'footer_note' => htmlspecialchars($footer, ENT_QUOTES, 'UTF-8'),
            'tax_note' => nl2br(htmlspecialchars($taxNote, ENT_QUOTES, 'UTF-8')),
            'legal_disclaimer' => htmlspecialchars($disclaimer, ENT_QUOTES, 'UTF-8'),
            'currency' => htmlspecialchars($currency, ENT_QUOTES, 'UTF-8'),
            'order_total' => htmlspecialchars($fmt($total), ENT_QUOTES, 'UTF-8'),
        ];
    }

    private function presetBodyHtml(string $template): string
    {
        $eu = $template === 'eu_vat'
            ? "\n{{eu_vat_meta_html}}\n"
            : '';
        $vatLine = $template === 'eu_vat'
            ? ''
            : "\n<div class=\"sub\">VAT {{seller_vat}}</div>";

        return <<<HTML
<header class="top">
  <div class="seller">
    {{logo_html}}
    <div class="brand">{{company_name}}</div>
    <div class="sub">{{seller_address_html}}</div>
    <div class="sub">{{seller_email}}</div>
    <div class="sub">{{seller_phone}}</div>{$vatLine}
  </div>
  <div class="doc">
    <h1>Invoice</h1>
    <div class="sub">No. {{invoice_number}}</div>
    <div class="sub">Order {{order_number}} · {{issued_date}} · <span class="badge">{{status}}</span></div>
  </div>
</header>
{$eu}<div class="grid">
  <div>
    <h2>Bill to</h2>
    <div class="pre">{{bill_to_html}}</div>
    <div>{{customer_email}}</div>
  </div>
  <div>
    <h2>Ship to</h2>
    <div class="pre">{{ship_to_html}}</div>
  </div>
</div>
<h2>Line items</h2>
<table>
  <thead><tr><th>Item</th><th>Qty</th><th class="right">Amount</th></tr></thead>
  <tbody>{{line_items_html}}</tbody>
</table>
<div class="money">{{money_html}}</div>
<p class="footer">{{footer_note}}</p>
<p class="footer">{{tax_note}}</p>
<p class="disclaimer">{{legal_disclaimer}}</p>
HTML;
    }

    private function templateCss(string $template): string
    {
        $base = 'page,body{margin:0;padding:0;background:#fff;color:#111}'
            . '.wrap{max-width:800px;margin:0 auto;padding:28px 32px}'
            . '.brand{font:700 22px/1.2 "Iowan Old Style",Georgia,serif;margin:0 0 4px}'
            . '.sub{color:#555;font:12px/1.4 system-ui,sans-serif;margin:0 0 4px;white-space:pre-line}'
            . '.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:18px 0 24px}'
            . 'h1{font:700 28px/1.15 "Iowan Old Style",Georgia,serif;margin:0 0 6px}'
            . 'h2{font:650 12px/1.2 system-ui,sans-serif;text-transform:uppercase;letter-spacing:.04em;color:#666;margin:0 0 8px}'
            . 'table{width:100%;border-collapse:collapse;margin:8px 0 18px}'
            . 'th,td{padding:10px 6px;border-bottom:1px solid #e5e7eb;text-align:left;vertical-align:top;font:14px/1.4 Georgia,serif}'
            . 'th{font:650 11px system-ui,sans-serif;text-transform:uppercase;letter-spacing:.03em;color:#666}'
            . '.right{text-align:right}.muted{color:#666;font-size:12px;margin-top:3px}'
            . '.money{width:280px;margin-left:auto;font:14px/1.4 system-ui,sans-serif}'
            . '.money div{display:flex;justify-content:space-between;gap:16px;padding:4px 0}'
            . '.money .total{border-top:1px solid #111;margin-top:8px;padding-top:8px;font-weight:700}'
            . '.badge{display:inline-block;padding:2px 8px;border-radius:999px;background:#f3f4f6;font:600 11px system-ui,sans-serif;text-transform:uppercase}'
            . '.logo{max-height:56px;max-width:180px;display:block;margin:0 0 10px}'
            . '.top{display:flex;justify-content:space-between;gap:24px;margin-bottom:20px}'
            . '.pre{white-space:pre-line}.footer{margin-top:24px;font:13px/1.45 Georgia,serif}'
            . '.disclaimer{margin-top:16px;font:11px/1.4 system-ui,sans-serif;color:#777}'
            . '.meta-box{border:1px solid #ddd;padding:12px 14px;margin:0 0 18px;font:12px/1.45 system-ui,sans-serif;display:grid;gap:4px}'
            . '@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}.wrap{padding:0}}';

        if ($template === 'compact') {
            return $base
                . '.wrap{padding:18px 20px}.brand{font-size:18px}h1{font-size:22px}'
                . 'th,td{padding:6px 4px;font-size:13px}.grid{gap:12px;margin:12px 0 16px}';
        }
        if ($template === 'eu_vat') {
            return $base
                . '.tmpl-eu_vat .brand{font-family:system-ui,sans-serif}'
                . '.tmpl-eu_vat h1{font-family:system-ui,sans-serif;letter-spacing:-.02em}'
                . '.tmpl-eu_vat table{border:1px solid #ddd}'
                . '.tmpl-eu_vat th,.tmpl-eu_vat td{border-bottom:1px solid #ddd}';
        }
        return $base;
    }

    /**
     * Resolve logo for blob/print invoices: prefer data URI for local media,
     * otherwise an absolute http(s) URL (relative /media/ paths cannot load in blob: docs).
     */
    private function resolveLogoSrc(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }
        if (str_starts_with($url, 'data:')) {
            return $url;
        }
        if (str_starts_with($url, '//')) {
            return 'https:' . $url;
        }

        $embedded = $this->embedLocalMediaAsDataUri($url);
        if ($embedded !== '') {
            return $embedded;
        }

        return $this->absolutePublicUrl($url);
    }

    /**
     * Embed a local /media/… file as a data URI so blob invoice windows can show it.
     */
    private function embedLocalMediaAsDataUri(string $url): string
    {
        $path = (string) (parse_url($url, PHP_URL_PATH) ?: $url);
        if (!preg_match('#(?:^|/)media/(.+)$#', $path, $m)) {
            return '';
        }
        $rel = rawurldecode(str_replace('\\', '/', (string) $m[1]));
        if ($rel === '' || str_contains($rel, '..')) {
            return '';
        }

        $candidates = [];
        if (function_exists('birkly_media_dir')) {
            $candidates[] = rtrim((string) birkly_media_dir(), '/') . '/' . $rel;
        }
        if (function_exists('birkly_project_root')) {
            $candidates[] = rtrim((string) birkly_project_root(), '/') . '/media/' . $rel;
        }
        // Plugin path: plugins/commerce/includes → CMS root/media
        $candidates[] = dirname(__DIR__, 3) . '/media/' . $rel;

        $file = '';
        foreach ($candidates as $candidate) {
            if (is_string($candidate) && is_file($candidate) && is_readable($candidate)) {
                $file = $candidate;
                break;
            }
        }
        if ($file === '') {
            return '';
        }

        $size = filesize($file);
        if ($size === false || $size <= 0 || $size > 1500000) {
            return '';
        }
        $bytes = file_get_contents($file);
        if ($bytes === false || $bytes === '') {
            return '';
        }
        $mime = 'application/octet-stream';
        if (function_exists('mime_content_type')) {
            $detected = @mime_content_type($file);
            if (is_string($detected) && $detected !== '') {
                $mime = $detected;
            }
        }
        if (!str_starts_with($mime, 'image/')) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            $map = [
                'png' => 'image/png',
                'jpg' => 'image/jpeg',
                'jpeg' => 'image/jpeg',
                'gif' => 'image/gif',
                'webp' => 'image/webp',
                'svg' => 'image/svg+xml',
            ];
            if (!isset($map[$ext])) {
                return '';
            }
            $mime = $map[$ext];
        }

        return 'data:' . $mime . ';base64,' . base64_encode($bytes);
    }

    /**
     * Make relative media paths absolute for blob/print invoice documents.
     */
    private function absolutePublicUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }
        if (preg_match('#^https?://#i', $url) === 1 || str_starts_with($url, 'data:')) {
            return $url;
        }
        if (str_starts_with($url, '//')) {
            return 'https:' . $url;
        }

        $path = (string) (parse_url($url, PHP_URL_PATH) ?: $url);
        if ($path === '' || $path[0] !== '/') {
            $path = '/' . ltrim($path, '/');
        }
        // Apply install base_path once for bare /media/… paths (avoid double-prefix).
        if (function_exists('birkly_base_path')) {
            $basePath = (string) birkly_base_path();
            if ($basePath !== '' && str_starts_with($path, '/media/')) {
                $path = $basePath . $path;
            } elseif (
                $basePath !== ''
                && !str_starts_with($path, $basePath . '/')
                && $path !== $basePath
                && function_exists('birkly_url')
            ) {
                $path = (string) birkly_url(ltrim($path, '/'));
                if ($path === '' || $path[0] !== '/') {
                    $path = '/' . ltrim($path, '/');
                }
            }
        }

        $base = $this->cmsOriginBase();
        if ($base === '') {
            return $path;
        }
        return rtrim($base, '/') . $path;
    }

    /**
     * CMS origin (scheme://host[/base]) for absolute media URLs and <base href>.
     */
    private function cmsOriginBase(): string
    {
        if (function_exists('birkly_cms_base_url')) {
            $base = trim((string) birkly_cms_base_url());
            if ($base !== '') {
                return rtrim($base, '/');
            }
        }
        if (function_exists('birkly_hosting_build_url_from_request')) {
            $base = trim((string) birkly_hosting_build_url_from_request());
            if ($base !== '') {
                return rtrim($base, '/');
            }
        }
        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
        if ($host === '') {
            return '';
        }
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (isset($_SERVER['SERVER_PORT']) && (string) $_SERVER['SERVER_PORT'] === '443')
            || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string) $_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
        return ($https ? 'https' : 'http') . '://' . $host;
    }
}
