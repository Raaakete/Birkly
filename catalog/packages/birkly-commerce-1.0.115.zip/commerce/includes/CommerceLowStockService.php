<?php
/**
 * Low-stock automation helper (P54 P3-M4).
 *
 * Fires `commerce_low_stock` once per SKU when available crosses at/below the
 * configured low threshold. Clears the debounce flag when stock recovers above
 * the threshold so a future dip can alert again.
 */

class CommerceLowStockService
{
    private string $file;
    private InventoryLedger $ledger;

    public function __construct(?string $dataDir = null, ?InventoryLedger $ledger = null)
    {
        $dir = $dataDir ?? (function_exists('commerce_data_dir') ? commerce_data_dir() : sys_get_temp_dir() . '/commerce');
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $this->file = rtrim($dir, '/') . '/low_stock_alerts.json';
        if (!is_file($this->file)) {
            file_put_contents($this->file, json_encode(['alerts' => []], JSON_PRETTY_PRINT), LOCK_EX);
        }
        if ($ledger !== null) {
            $this->ledger = $ledger;
        } else {
            if (!class_exists('InventoryLedger')) {
                require_once __DIR__ . '/InventoryLedger.php';
            }
            $this->ledger = new InventoryLedger($dir);
        }
    }

    /**
     * Evaluate one or more SKUs and fire/clear low-stock alerts.
     *
     * @param list<string>|null $skus null = all tracked SKUs
     * @return list<array<string, mixed>> Fired payloads (empty when nothing fired)
     */
    public function evaluate(?array $skus = null): array
    {
        if ($this->ledger->isUnlimited()) {
            return [];
        }

        $rows = $this->ledger->listRows();
        $bySku = [];
        foreach ($rows as $row) {
            $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
            if ($sku === '') {
                continue;
            }
            if ($skus !== null) {
                $wanted = array_map(static fn ($s) => strtoupper(trim((string) $s)), $skus);
                if (!in_array($sku, $wanted, true)) {
                    continue;
                }
            }
            if (!isset($bySku[$sku])) {
                $bySku[$sku] = [
                    'sku' => $sku,
                    'on_hand' => 0,
                    'reserved' => 0,
                    'available' => 0,
                    'threshold' => 0,
                ];
            }
            $bySku[$sku]['on_hand'] += (int) ($row['quantity_on_hand'] ?? 0);
            $bySku[$sku]['reserved'] += (int) ($row['reserved'] ?? 0);
            $bySku[$sku]['available'] += (int) ($row['available'] ?? 0);
            $bySku[$sku]['threshold'] = max(
                $bySku[$sku]['threshold'],
                (int) ($row['low_stock_threshold'] ?? 0)
            );
        }

        $state = $this->load();
        $fired = [];
        foreach ($bySku as $sku => $stats) {
            $threshold = (int) $stats['threshold'];
            $available = (int) $stats['available'];
            $isLow = $threshold > 0 && $available <= $threshold;
            $wasAlerted = !empty($state['alerts'][$sku]);

            if ($isLow && !$wasAlerted) {
                $payload = [
                    'sku' => $sku,
                    'on_hand' => (int) $stats['on_hand'],
                    'reserved' => (int) $stats['reserved'],
                    'available' => $available,
                    'threshold' => $threshold,
                    'alerted_at' => date('c'),
                ];
                $state['alerts'][$sku] = [
                    'alerted_at' => $payload['alerted_at'],
                    'available' => $available,
                    'threshold' => $threshold,
                ];
                $this->fire($payload);
                $fired[] = $payload;
            } elseif (!$isLow && $wasAlerted) {
                unset($state['alerts'][$sku]);
            }
        }

        // Drop alerts for SKUs that no longer exist in the ledger.
        if ($skus === null) {
            foreach (array_keys($state['alerts'] ?? []) as $sku) {
                if (!isset($bySku[$sku])) {
                    unset($state['alerts'][$sku]);
                }
            }
        }

        $this->save($state);
        return $fired;
    }

    /** @return array{alerts: array<string, array<string, mixed>>} */
    public function getAlertState(): array
    {
        return $this->load();
    }

    /** @param array<string, mixed> $payload */
    private function fire(array $payload): void
    {
        if (function_exists('broadcast_event')) {
            broadcast_event('commerce_low_stock', $payload, 'commerce');
        }
        if (function_exists('enqueue_automation')) {
            enqueue_automation('commerce_low_stock', $payload);
        }
    }

    /** @return array{alerts: array<string, array<string, mixed>>} */
    private function load(): array
    {
        $data = is_file($this->file) ? json_decode((string) file_get_contents($this->file), true) : [];
        if (!is_array($data)) {
            $data = [];
        }
        if (!isset($data['alerts']) || !is_array($data['alerts'])) {
            $data['alerts'] = [];
        }
        return $data;
    }

    /** @param array{alerts: array<string, array<string, mixed>>} $data */
    private function save(array $data): void
    {
        $data['updated_at'] = date('c');
        file_put_contents($this->file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
    }
}
