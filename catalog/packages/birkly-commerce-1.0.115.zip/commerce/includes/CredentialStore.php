<?php
/**
 * Encrypted credential storage for payment connections.
 * Keys stored in data/plugins/commerce/ — never logged to activity.
 * Legacy data/plugins/payments/ is migrated on first bootstrap via commerce_migrate_legacy_data().
 */

require_once __DIR__ . '/ProviderCertification.php';

class PaymentsCredentialStore
{
    private string $baseDir;
    private string $encryptionKey;

    public function __construct(?string $baseDir = null)
    {
        if ($baseDir !== null) {
            $this->baseDir = rtrim($baseDir, '/');
        } else {
            if (!function_exists('commerce_data_dir')) {
                require_once __DIR__ . '/../cms_paths.php';
                // Lightweight fallback without loading full init (avoids circular requires in tests).
                $this->baseDir = commerce_cms_root() . '/data/plugins/commerce';
            } else {
                $this->baseDir = commerce_data_dir();
            }
            if (function_exists('commerce_migrate_legacy_data')) {
                commerce_migrate_legacy_data();
            }
        }
        $this->ensureDirectories();
        $this->encryptionKey = $this->getEncryptionKey();
    }

    public function getDataDir(): string
    {
        return $this->baseDir;
    }

    private function ensureDirectories(): void
    {
        foreach ([
            $this->baseDir,
            $this->baseDir . '/connections',
            $this->baseDir . '/activity',
            $this->baseDir . '/webhooks',
        ] as $dir) {
            if (function_exists('commerce_ensure_writable_dir')) {
                if (!commerce_ensure_writable_dir($dir)) {
                    throw new RuntimeException(
                        'Commerce data directory is not writable: ' . $dir
                        . ' (check volume permissions for plugin-data/ or plugins/commerce)'
                    );
                }
                continue;
            }
            if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
                throw new RuntimeException('Failed to create Commerce data directory: ' . $dir);
            }
            @chmod($dir, 0775);
        }
    }

    private function getEncryptionKey(): string
    {
        $keyFile = $this->baseDir . '/encryption_key.txt';
        if (is_file($keyFile)) {
            return trim((string) file_get_contents($keyFile));
        }
        $key = hash('sha256', random_bytes(32), true);
        $encoded = base64_encode($key);
        if (@file_put_contents($keyFile, $encoded, LOCK_EX) === false) {
            throw new RuntimeException(
                'Failed to write encryption key in ' . $this->baseDir
                . ' (directory not writable)'
            );
        }
        @chmod($keyFile, 0600);
        return $encoded;
    }

    private function keyBytes(): string
    {
        $raw = base64_decode($this->encryptionKey, true);
        if ($raw === false || strlen($raw) < 32) {
            return hash('sha256', $this->encryptionKey, true);
        }
        return substr($raw, 0, 32);
    }

    public function encrypt(string $plaintext): string
    {
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt($plaintext, 'aes-256-cbc', $this->keyBytes(), OPENSSL_RAW_DATA, $iv);
        return base64_encode($iv . $encrypted);
    }

    public function decrypt(string $ciphertext): string
    {
        $raw = base64_decode($ciphertext, true);
        if ($raw === false || strlen($raw) < 17) {
            return '';
        }
        $iv = substr($raw, 0, 16);
        $encrypted = substr($raw, 16);
        $decrypted = openssl_decrypt($encrypted, 'aes-256-cbc', $this->keyBytes(), OPENSSL_RAW_DATA, $iv);
        return $decrypted === false ? '' : $decrypted;
    }

    public function encryptArray(array $data): string
    {
        return $this->encrypt(json_encode($data));
    }

    public function decryptArray(string $ciphertext): array
    {
        $json = $this->decrypt($ciphertext);
        if ($json === '') {
            return [];
        }
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : [];
    }

    /** @return array<string, mixed> */
    public function listConnections(): array
    {
        $connections = [];
        $dir = $this->baseDir . '/connections';
        if (!is_dir($dir)) {
            return [];
        }
        foreach (glob($dir . '/*.json') as $file) {
            $meta = json_decode((string) file_get_contents($file), true);
            if (!is_array($meta)) {
                continue;
            }
            unset($meta['credentials_enc'], $meta['webhook_secret_enc']);
            $connections[$meta['id']] = ProviderCertification::annotateConnection($meta);
        }
        return $connections;
    }

    public function getConnection(string $id, bool $includeSecrets = false): ?array
    {
        $file = $this->baseDir . '/connections/' . $id . '.json';
        if (!is_file($file)) {
            return null;
        }
        $meta = json_decode((string) file_get_contents($file), true);
        if (!is_array($meta)) {
            return null;
        }
        if ($includeSecrets) {
            if (!empty($meta['credentials_enc'])) {
                $meta['credentials'] = $this->decryptArray($meta['credentials_enc']);
            }
            if (!empty($meta['webhook_secret_enc'])) {
                $meta['webhook_secret'] = $this->decrypt($meta['webhook_secret_enc']);
            }
        }
        unset($meta['credentials_enc'], $meta['webhook_secret_enc']);
        return ProviderCertification::annotateConnection($meta);
    }

    public function saveConnection(array $connection): array
    {
        $certification = ProviderCertification::validateConnection($connection);
        if (!($certification['ok'] ?? false)) {
            throw new InvalidArgumentException($certification['error'] ?? 'Provider is not certified for this mode');
        }

        $id = trim((string) ($connection['id'] ?? ''));
        if ($id === '') {
            $id = 'conn_' . bin2hex(random_bytes(8));
        }
        $now = date('c');

        $existingFile = $this->baseDir . '/connections/' . $id . '.json';
        $existing = null;
        if (is_file($existingFile)) {
            $existing = json_decode((string) file_get_contents($existingFile), true);
            if (!is_array($existing)) {
                $existing = null;
            }
        }

        $provider = (string) ($connection['provider'] ?? ($existing['provider'] ?? ''));
        $enabled = (bool) ($connection['enabled'] ?? ($existing['enabled'] ?? true));
        $wantsDefault = !empty($connection['is_default']) || !empty($connection['set_as_default']);
        $isDefault = (bool) ($existing['is_default'] ?? false);
        if (!$enabled) {
            $isDefault = false;
        } elseif ($wantsDefault) {
            $this->clearDefaultForProvider($provider, $id);
            $isDefault = true;
        } elseif (!$isDefault && $enabled && !$this->providerHasDefaultConnection($provider, $id)) {
            $isDefault = true;
        }

        $stored = [
            'id' => $id,
            'provider' => $provider,
            'label' => $connection['label'] ?? ($existing['label'] ?? ''),
            'mode' => $connection['mode'] ?? ($existing['mode'] ?? 'test'),
            'enabled' => $enabled,
            'is_default' => $isDefault,
            'created_at' => $connection['created_at'] ?? ($existing['created_at'] ?? $now),
            'updated_at' => $now,
        ];

        $incomingCreds = null;
        if (isset($connection['credentials']) && is_array($connection['credentials'])) {
            $incomingCreds = array_filter(
                $connection['credentials'],
                static fn($value) => $value !== null && $value !== ''
            );
        }

        if (!empty($incomingCreds)) {
            $mergedCreds = $incomingCreds;
            if (!empty($existing['credentials_enc'])) {
                $prior = $this->decryptArray($existing['credentials_enc']);
                if (is_array($prior)) {
                    $mergedCreds = array_merge($prior, $incomingCreds);
                }
            }
            $stored['credentials_enc'] = $this->encryptArray($mergedCreds);
        } elseif (!empty($connection['credentials_enc'])) {
            $stored['credentials_enc'] = $connection['credentials_enc'];
        } elseif (!empty($existing['credentials_enc'])) {
            $stored['credentials_enc'] = $existing['credentials_enc'];
        }

        if (isset($connection['webhook_secret']) && $connection['webhook_secret'] !== '') {
            $stored['webhook_secret_enc'] = $this->encrypt((string) $connection['webhook_secret']);
        } elseif (!empty($connection['webhook_secret_enc'])) {
            $stored['webhook_secret_enc'] = $connection['webhook_secret_enc'];
        } elseif (!empty($existing['webhook_secret_enc'])) {
            $stored['webhook_secret_enc'] = $existing['webhook_secret_enc'];
        }

        if (empty($stored['credentials_enc'])) {
            throw new InvalidArgumentException('Secret credentials are required to save a connection');
        }

        $connDir = $this->baseDir . '/connections';
        if (function_exists('commerce_ensure_writable_dir') && !commerce_ensure_writable_dir($connDir)) {
            throw new RuntimeException(
                'Failed to write connection file: directory not writable (' . $connDir . ')'
            );
        }
        $file = $connDir . '/' . $id . '.json';
        $written = @file_put_contents($file, json_encode($stored, JSON_PRETTY_PRINT), LOCK_EX);
        if ($written === false) {
            $hint = is_dir($connDir)
                ? (is_writable($connDir) ? 'disk or open_basedir restriction' : 'not writable by PHP user')
                : 'connections directory missing';
            throw new RuntimeException(
                'Failed to write connection file (' . $file . ' — ' . $hint . ')'
            );
        }
        @chmod($file, 0600);

        unset($stored['credentials_enc'], $stored['webhook_secret_enc']);
        return ProviderCertification::annotateConnection($stored);
    }

    public function deleteConnection(string $id): bool
    {
        $file = $this->baseDir . '/connections/' . $id . '.json';
        if (is_file($file)) {
            return unlink($file);
        }
        return false;
    }

    public function setDefaultConnection(string $id): ?array
    {
        $conn = $this->getConnection($id, false);
        if ($conn === null || empty($conn['enabled']) || !ProviderCertification::isConnectionUsable($conn)) {
            return null;
        }

        $provider = (string) ($conn['provider'] ?? '');
        $this->clearDefaultForProvider($provider, $id);

        $file = $this->baseDir . '/connections/' . $id . '.json';
        if (!is_file($file)) {
            return null;
        }
        $meta = json_decode((string) file_get_contents($file), true);
        if (!is_array($meta)) {
            return null;
        }
        $meta['is_default'] = true;
        $meta['updated_at'] = date('c');
        file_put_contents($file, json_encode($meta, JSON_PRETTY_PRINT), LOCK_EX);
        @chmod($file, 0600);

        unset($meta['credentials_enc'], $meta['webhook_secret_enc']);
        return ProviderCertification::annotateConnection($meta);
    }

    /** @return array<int, array<string, mixed>> */
    private function listUsableConnectionsForProvider(string $providerId): array
    {
        $usable = [];
        foreach ($this->listConnections() as $conn) {
            if (($conn['provider'] ?? '') !== $providerId) {
                continue;
            }
            if (empty($conn['enabled']) || !ProviderCertification::isConnectionUsable($conn)) {
                continue;
            }
            $usable[] = $conn;
        }
        return $usable;
    }

    private function providerHasDefaultConnection(string $providerId, ?string $excludeId = null): bool
    {
        foreach ($this->listConnections() as $conn) {
            if (($conn['provider'] ?? '') !== $providerId) {
                continue;
            }
            if ($excludeId !== null && ($conn['id'] ?? '') === $excludeId) {
                continue;
            }
            if (!empty($conn['enabled']) && !empty($conn['is_default'])) {
                return true;
            }
        }
        return false;
    }

    private function clearDefaultForProvider(string $providerId, ?string $exceptId = null): void
    {
        $dir = $this->baseDir . '/connections';
        if (!is_dir($dir)) {
            return;
        }
        foreach (glob($dir . '/*.json') as $file) {
            $meta = json_decode((string) file_get_contents($file), true);
            if (!is_array($meta)) {
                continue;
            }
            if (($meta['provider'] ?? '') !== $providerId) {
                continue;
            }
            if ($exceptId !== null && ($meta['id'] ?? '') === $exceptId) {
                continue;
            }
            if (empty($meta['is_default'])) {
                continue;
            }
            unset($meta['is_default']);
            $meta['updated_at'] = date('c');
            file_put_contents($file, json_encode($meta, JSON_PRETTY_PRINT), LOCK_EX);
            @chmod($file, 0600);
        }
    }

    /** @param array<int, array<string, mixed>> $candidates */
    private function pickCheckoutConnection(array $candidates): ?array
    {
        if ($candidates === []) {
            return null;
        }

        foreach ($candidates as $conn) {
            if (!empty($conn['is_default'])) {
                return $conn;
            }
        }

        $live = array_values(array_filter(
            $candidates,
            static fn(array $conn): bool => ($conn['mode'] ?? 'test') === 'live'
        ));
        $pool = $live !== [] ? $live : $candidates;

        usort($pool, static function (array $a, array $b): int {
            return strcmp((string) ($b['updated_at'] ?? ''), (string) ($a['updated_at'] ?? ''));
        });

        return $pool[0] ?? null;
    }

    public function getCredentialsForConnection(string $id): ?array
    {
        $conn = $this->getConnection($id, true);
        if (!$conn || empty($conn['credentials'])) {
            return null;
        }
        return $conn['credentials'];
    }

    /** Resolve the checkout connection for a provider (default, then live, then newest). */
    public function getActiveConnectionForProvider(string $providerId): ?array
    {
        return $this->pickConnectionForProvider($providerId);
    }

    /**
     * Pick a provider connection, optionally by stored id or live/test hint from payment ids.
     */
    public function pickConnectionForProvider(string $providerId, ?string $connectionId = null, ?string $modeHint = null): ?array
    {
        $usable = $this->listUsableConnectionsForProvider($providerId);
        if ($usable === []) {
            return null;
        }

        if ($connectionId !== null && $connectionId !== '') {
            foreach ($usable as $conn) {
                if (($conn['id'] ?? '') === $connectionId) {
                    return $this->getConnection($connectionId, true);
                }
            }
        }

        $modeHint = strtolower(trim((string) $modeHint));
        if ($modeHint === 'live' || $modeHint === 'test') {
            $matched = array_values(array_filter(
                $usable,
                static fn(array $conn): bool => ($conn['mode'] ?? 'test') === $modeHint
            ));
            if ($matched !== []) {
                $picked = $this->pickCheckoutConnection($matched);
                if ($picked !== null) {
                    return $this->getConnection((string) ($picked['id'] ?? ''), true);
                }
            }
        }

        $picked = $this->pickCheckoutConnection($usable);
        if ($picked === null) {
            return null;
        }
        return $this->getConnection((string) ($picked['id'] ?? ''), true);
    }

    public static function inferModeFromPaymentId(string $paymentId): ?string
    {
        if (preg_match('/_(live|test)_/', $paymentId, $matches) === 1) {
            return $matches[1];
        }
        return null;
    }

    public function listConfiguredProviders(): array
    {
        $providers = [];
        foreach ($this->listConnections() as $conn) {
            if (!empty($conn['enabled']) && ProviderCertification::isConnectionUsable($conn)) {
                $providers[] = $conn['provider'];
            }
        }
        return array_values(array_unique($providers));
    }
}
