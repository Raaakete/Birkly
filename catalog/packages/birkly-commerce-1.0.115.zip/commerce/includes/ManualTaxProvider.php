<?php
/**
 * Manual tax provider — class×country rate table via CommerceCatalog rules.
 * Supports tax-included (EU) and tax-excluded (US/B2B) line prices, plus
 * B2B reverse charge (P2-M4) when vat_id + eligible countries match.
 */

require_once __DIR__ . '/TaxProviderInterface.php';

class ManualTaxProvider implements TaxProviderInterface
{
    private CommerceCatalog $catalog;

    public function __construct(CommerceCatalog $catalog)
    {
        $this->catalog = $catalog;
    }

    public function getId(): string
    {
        return 'manual';
    }

    public function getName(): string
    {
        return 'Manual';
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context Optional: currency, vat_id / tax_id, billing_address
     */
    public function calculate(array $lines, ?array $shippingAddress = null, array $context = []): array
    {
        $rules = $this->catalog->loadTaxRules();
        $country = $this->resolveCustomerCountry($shippingAddress, $context);

        $reverse = $this->buildReverseChargeResult($lines, $country, $context, $rules);
        if ($reverse !== null) {
            return $reverse;
        }

        /**
         * Bucket by class|rate|included so mixed carts stay correct.
         * @var array<string, array{tax_class: string, rate: float, taxable_cents: int, tax_included: bool}> $buckets
         */
        $buckets = [];
        $taxableTotal = 0;
        $anyIncluded = false;
        $anyExcluded = false;

        foreach ($lines as $line) {
            $amount = (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
            if ($amount <= 0) {
                continue;
            }
            $taxClass = CommerceSchema::normalizeTaxClass(
                $line['tax_class'] ?? ($line['commerce']['tax_class'] ?? null)
            );
            $included = CommerceSchema::lineTaxIncluded($line);
            $rate = $this->catalog->resolveTaxRateForClass($taxClass, $country, $rules);
            $key = $taxClass . '|' . $rate . '|' . ($included ? '1' : '0');
            if (!isset($buckets[$key])) {
                $buckets[$key] = [
                    'tax_class' => $taxClass,
                    'rate' => $rate,
                    'taxable_cents' => 0,
                    'tax_included' => $included,
                ];
            }
            $buckets[$key]['taxable_cents'] += $amount;
            $taxableTotal += $amount;
            if ($included) {
                $anyIncluded = true;
            } else {
                $anyExcluded = true;
            }
        }

        $taxLines = [];
        $taxCents = 0;
        $taxAddCents = 0;
        $primaryRate = 0.0;
        $primaryTaxable = -1;

        foreach ($buckets as $bucket) {
            if (empty($rules['enabled']) || $bucket['taxable_cents'] <= 0) {
                continue;
            }
            $included = !empty($bucket['tax_included']);
            $bucketTax = $included
                ? CommerceSchema::extractIncludedTaxCents($bucket['taxable_cents'], (float) $bucket['rate'])
                : CommerceSchema::exclusiveTaxCents($bucket['taxable_cents'], (float) $bucket['rate']);
            $netCents = $included
                ? max(0, $bucket['taxable_cents'] - $bucketTax)
                : $bucket['taxable_cents'];
            $taxCents += $bucketTax;
            if (!$included) {
                $taxAddCents += $bucketTax;
            }
            $label = (string) ($rules['classes'][$bucket['tax_class']]['label'] ?? ucfirst($bucket['tax_class']));
            $titleParts = [];
            if ($country !== '') {
                $titleParts[] = 'VAT ' . $country;
            } else {
                $titleParts[] = 'Tax';
            }
            $titleParts[] = $label;
            if ($included) {
                $titleParts[] = 'incl.';
            }
            $basis = $country . '|' . $bucket['tax_class'] . '|' . $bucket['rate'] . '|'
                . ($included ? '1' : '0') . '|' . $bucket['taxable_cents'] . '|' . $bucketTax;
            $taxLines[] = [
                'id' => 'tl_' . substr(hash('sha256', $basis), 0, 12),
                'title' => implode(' · ', $titleParts),
                'rate' => $bucket['rate'],
                'country' => $country,
                'tax_class' => $bucket['tax_class'],
                'tax_included' => $included,
                'taxable_cents' => $netCents,
                'gross_cents' => $included ? $bucket['taxable_cents'] : ($bucket['taxable_cents'] + $bucketTax),
                'tax_cents' => $bucketTax,
                'source' => 'manual',
                'provider' => 'manual',
            ];
            if ($bucket['taxable_cents'] > $primaryTaxable) {
                $primaryTaxable = $bucket['taxable_cents'];
                $primaryRate = $bucket['rate'];
            }
        }

        return [
            'tax_cents' => $taxCents,
            'tax_add_cents' => $taxAddCents,
            'rate' => $primaryRate,
            'country' => $country,
            'taxable_cents' => $taxableTotal,
            'tax_lines' => $taxLines,
            'provider' => 'manual',
            'prices_include_tax' => $anyIncluded && !$anyExcluded,
            'tax_included' => $anyIncluded && !$anyExcluded,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed> $context
     * @param array<string, mixed> $rules
     * @return array<string, mixed>|null
     */
    private function buildReverseChargeResult(array $lines, string $customerCountry, array $context, array $rules): ?array
    {
        if (empty($rules['enabled'])) {
            return null;
        }
        $b2b = is_array($rules['b2b_reverse_charge'] ?? null) ? $rules['b2b_reverse_charge'] : [];
        if (empty($b2b['enabled'])) {
            return null;
        }

        $vatId = $this->catalog->normalizeVatId(
            $context['vat_id'] ?? ($context['tax_id'] ?? null)
        );
        if ($vatId === '') {
            return null;
        }

        $merchantCountry = strtoupper(trim((string) ($b2b['merchant_country'] ?? '')));
        if ($customerCountry === '' || $merchantCountry === '') {
            return null;
        }

        $eligible = is_array($b2b['eligible_countries'] ?? null) ? $b2b['eligible_countries'] : [];
        if ($eligible === []) {
            $eligible = CommerceCatalog::defaultEuVatCountries();
        }
        $eligible = array_map(static fn ($c) => strtoupper(trim((string) $c)), $eligible);
        if (!in_array($customerCountry, $eligible, true) || !in_array($merchantCountry, $eligible, true)) {
            return null;
        }

        $requireDifferent = array_key_exists('require_different_country', $b2b)
            ? (bool) $b2b['require_different_country']
            : true;
        if ($requireDifferent && $customerCountry === $merchantCountry) {
            return null;
        }

        /** @var array<string, array{tax_class: string, taxable_cents: int, tax_included: bool}> $buckets */
        $buckets = [];
        $taxableTotal = 0;
        $stripCents = 0;
        $anyIncluded = false;

        foreach ($lines as $line) {
            $amount = (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
            if ($amount <= 0) {
                continue;
            }
            $taxClass = CommerceSchema::normalizeTaxClass(
                $line['tax_class'] ?? ($line['commerce']['tax_class'] ?? null)
            );
            $included = CommerceSchema::lineTaxIncluded($line);
            if ($included) {
                $anyIncluded = true;
                $rate = $this->catalog->resolveTaxRateForClass($taxClass, $customerCountry, $rules);
                $stripCents += CommerceSchema::extractIncludedTaxCents($amount, $rate);
            }
            if (!isset($buckets[$taxClass])) {
                $buckets[$taxClass] = [
                    'tax_class' => $taxClass,
                    'taxable_cents' => 0,
                    'tax_included' => $included,
                ];
            }
            $buckets[$taxClass]['taxable_cents'] += $amount;
            // If mixed included flags share a class, mark included when any line was.
            $buckets[$taxClass]['tax_included'] = $buckets[$taxClass]['tax_included'] || $included;
            $taxableTotal += $amount;
        }

        if ($taxableTotal <= 0) {
            return [
                'tax_cents' => 0,
                'tax_add_cents' => 0,
                'rate' => 0.0,
                'country' => $customerCountry,
                'taxable_cents' => 0,
                'tax_lines' => [],
                'provider' => 'manual',
                'vat_id' => $vatId,
                'reverse_charge' => true,
                'prices_include_tax' => false,
                'tax_included' => false,
            ];
        }

        $taxLines = [];
        foreach ($buckets as $bucket) {
            $label = (string) ($rules['classes'][$bucket['tax_class']]['label'] ?? ucfirst($bucket['tax_class']));
            $basis = 'reverse_charge|' . $customerCountry . '|' . $merchantCountry . '|' . $vatId
                . '|' . $bucket['tax_class'] . '|' . $bucket['taxable_cents'];
            $taxLines[] = [
                'id' => 'tl_' . substr(hash('sha256', $basis), 0, 12),
                'title' => 'Reverse charge',
                'rate' => 0.0,
                'country' => $customerCountry,
                'tax_class' => $bucket['tax_class'],
                'tax_included' => !empty($bucket['tax_included']),
                'taxable_cents' => $bucket['taxable_cents'],
                'tax_cents' => 0,
                'reason' => 'reverse_charge',
                'source' => 'manual',
                'provider' => 'manual',
                'vat_id' => $vatId,
                'merchant_country' => $merchantCountry,
                'label' => $label,
            ];
        }

        return [
            'tax_cents' => 0,
            // Inclusive shelf prices embed VAT — strip it so B2B pays net.
            'tax_add_cents' => $anyIncluded ? -1 * $stripCents : 0,
            'rate' => 0.0,
            'country' => $customerCountry,
            'taxable_cents' => $taxableTotal,
            'tax_lines' => $taxLines,
            'provider' => 'manual',
            'vat_id' => $vatId,
            'reverse_charge' => true,
            'prices_include_tax' => $anyIncluded,
            'tax_included' => $anyIncluded,
            'included_tax_strip_cents' => $stripCents,
        ];
    }

    /**
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context
     */
    private function resolveCustomerCountry(?array $shippingAddress, array $context): string
    {
        $country = strtoupper(trim((string) ($shippingAddress['country'] ?? '')));
        if ($country !== '') {
            return $country;
        }
        $billing = is_array($context['billing_address'] ?? null) ? $context['billing_address'] : null;
        if ($billing !== null) {
            return strtoupper(trim((string) ($billing['country'] ?? '')));
        }
        return '';
    }
}
