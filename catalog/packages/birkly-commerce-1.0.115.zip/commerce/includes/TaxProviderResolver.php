<?php
/**
 * Resolves the active tax calculation provider from settings.
 *
 * Setting: commerce_tax_provider = manual | stripe_tax
 * Also persisted on tax_rules.json as provider for environments without CMS settings.
 */

require_once __DIR__ . '/TaxProviderInterface.php';
require_once __DIR__ . '/ManualTaxProvider.php';
require_once __DIR__ . '/StripeTaxProvider.php';

class TaxProviderResolver
{
    public const PROVIDER_MANUAL = 'manual';
    public const PROVIDER_STRIPE_TAX = 'stripe_tax';

    private CommerceCatalog $catalog;

    /** @var array<string, TaxProviderInterface> */
    private array $providers = [];

    public function __construct(CommerceCatalog $catalog)
    {
        $this->catalog = $catalog;
        $this->providers[self::PROVIDER_MANUAL] = new ManualTaxProvider($catalog);
        $this->providers[self::PROVIDER_STRIPE_TAX] = new StripeTaxProvider($catalog);
    }

    public function register(TaxProviderInterface $provider): void
    {
        $this->providers[$provider->getId()] = $provider;
    }

    public function get(string $providerId): ?TaxProviderInterface
    {
        return $this->providers[$providerId] ?? null;
    }

    /** @return array<string, TaxProviderInterface> */
    public function all(): array
    {
        return $this->providers;
    }

    /**
     * @return array<int, array{id: string, name: string}>
     */
    public function listProviders(): array
    {
        $out = [];
        foreach ($this->providers as $provider) {
            $out[] = [
                'id' => $provider->getId(),
                'name' => $provider->getName(),
            ];
        }
        return $out;
    }

    public function getProviderId(): string
    {
        $fromSetting = null;
        if (function_exists('commerce_get_setting')) {
            $fromSetting = commerce_get_setting('commerce_tax_provider', null);
        } elseif (function_exists('get_plugin_setting')) {
            $fromSetting = get_plugin_setting('commerce', 'commerce_tax_provider', null);
        }
        if ($this->isValidProviderId($fromSetting)) {
            return (string) $fromSetting;
        }

        $rules = $this->catalog->loadTaxRules();
        $fromRules = $rules['provider'] ?? self::PROVIDER_MANUAL;
        if ($this->isValidProviderId($fromRules)) {
            return (string) $fromRules;
        }

        return self::PROVIDER_MANUAL;
    }

    public function resolve(?string $providerId = null): TaxProviderInterface
    {
        $id = $this->isValidProviderId($providerId) ? (string) $providerId : $this->getProviderId();
        return $this->providers[$id] ?? $this->providers[self::PROVIDER_MANUAL];
    }

    /**
     * Persist provider id to plugin setting (when available) and return normalized id.
     */
    public static function normalizeProviderId($providerId): string
    {
        $id = strtolower(trim((string) ($providerId ?? '')));
        return in_array($id, [self::PROVIDER_MANUAL, self::PROVIDER_STRIPE_TAX], true)
            ? $id
            : self::PROVIDER_MANUAL;
    }

    private function isValidProviderId($providerId): bool
    {
        return is_string($providerId) && isset($this->providers[$providerId]);
    }
}
