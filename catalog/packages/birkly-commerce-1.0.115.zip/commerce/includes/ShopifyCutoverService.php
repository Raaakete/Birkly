<?php
/**
 * Shopify one-time cutover / transfer import (P54 P1-M2).
 * Products + customers + archived orders with dry-run / rollback.
 * Not perpetual sync — use beta live adapters for ongoing product sync.
 */

if (!class_exists('ShopifyImportAdapter')) {
    require_once __DIR__ . '/ShopifyImportAdapter.php';
}
if (!class_exists('CommerceImportCredentialStore')) {
    require_once __DIR__ . '/CommerceImportCredentialStore.php';
}
if (!class_exists('ImportService')) {
    require_once __DIR__ . '/ImportService.php';
}
if (!class_exists('ImportHistoryStore')) {
    require_once __DIR__ . '/ImportHistoryStore.php';
}
if (!class_exists('CommerceCustomerStore')) {
    require_once __DIR__ . '/CommerceCustomerStore.php';
}
if (!class_exists('CommerceOrderStore')) {
    require_once __DIR__ . '/CommerceOrderStore.php';
}

class ShopifyCutoverService
{
    public const TYPE = 'shopify_cutover';

    private ShopifyImportAdapter $adapter;
    private CommerceImportCredentialStore $credentials;
    private ImportService $import;
    private ImportHistoryStore $history;
    private CommerceCustomerStore $customers;
    private CommerceOrderStore $orders;

    /** @var callable|null optional spy for tests — must never be invoked for archive import */
    private $fulfillmentSpy;

    public function __construct(
        ?ShopifyImportAdapter $adapter = null,
        ?CommerceImportCredentialStore $credentials = null,
        ?ImportService $import = null,
        ?ImportHistoryStore $history = null,
        ?CommerceCustomerStore $customers = null,
        ?CommerceOrderStore $orders = null,
        ?callable $fulfillmentSpy = null
    ) {
        $this->adapter = $adapter ?? new ShopifyImportAdapter();
        $this->credentials = $credentials ?? new CommerceImportCredentialStore();
        $this->import = $import ?? new ImportService();
        $this->history = $history ?? new ImportHistoryStore();
        $this->customers = $customers ?? new CommerceCustomerStore();
        $this->orders = $orders ?? new CommerceOrderStore();
        $this->fulfillmentSpy = $fulfillmentSpy;
    }

    /** @return array<string, mixed> */
    public function testConnection(): array
    {
        $creds = $this->credentials->getPlatformConfig('shopify', true);
        return $this->adapter->testConnection($creds);
    }

    /**
     * @param string|list<string> $resources products|customers|orders|all
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function dryRun($resources = 'all', array $options = []): array
    {
        $resources = $this->normalizeResources($resources);
        $creds = $this->resolveCredentials($options);
        if (!($creds['ok'] ?? false)) {
            return $creds;
        }
        $credentials = $creds['credentials'];
        $fetchOpts = ['max_pages' => max(1, (int) ($options['max_pages'] ?? 2))];

        $result = [
            'ok' => true,
            'mode' => 'dry_run',
            'resources' => $resources,
            'products' => null,
            'customers' => null,
            'orders' => null,
        ];

        if (in_array('products', $resources, true)) {
            $fetch = $this->adapter->fetchProductRows($credentials, $fetchOpts);
            if (!($fetch['ok'] ?? false)) {
                return ['ok' => false, 'error' => $fetch['error'] ?? 'Product fetch failed', 'stage' => 'products'];
            }
            $rows = $fetch['rows'] ?? [];
            $sample = array_slice($rows, 0, 5);
            $result['products'] = [
                'count' => (int) ($fetch['product_count'] ?? 0),
                'row_count' => count($rows),
                'pages_fetched' => $fetch['pages_fetched'] ?? 0,
                'sample' => array_map(static function ($row) {
                    return [
                        'title' => $row['title'] ?? '',
                        'sku' => $row['sku'] ?? null,
                        'parent_sku' => $row['parent_sku'] ?? null,
                        'image_url' => $row['image_url'] ?? null,
                    ];
                }, $sample),
            ];
        }

        if (in_array('customers', $resources, true)) {
            $fetch = $this->adapter->fetchCustomers($credentials, $fetchOpts);
            if (!($fetch['ok'] ?? false)) {
                return ['ok' => false, 'error' => $fetch['error'] ?? 'Customer fetch failed', 'stage' => 'customers'];
            }
            $customers = $fetch['customers'] ?? [];
            $result['customers'] = [
                'count' => count($customers),
                'pages_fetched' => $fetch['pages_fetched'] ?? 0,
                'sample' => array_map(static function ($c) {
                    return [
                        'email' => $c['email'] ?? '',
                        'name' => $c['name'] ?? '',
                        'tags' => $c['tags'] ?? [],
                        'shopify_customer_id' => $c['shopify_customer_id'] ?? null,
                    ];
                }, array_slice($customers, 0, 5)),
            ];
        }

        if (in_array('orders', $resources, true)) {
            $fetch = $this->adapter->fetchOrders($credentials, $fetchOpts);
            if (!($fetch['ok'] ?? false)) {
                return ['ok' => false, 'error' => $fetch['error'] ?? 'Order fetch failed', 'stage' => 'orders'];
            }
            $orders = $fetch['orders'] ?? [];
            $result['orders'] = [
                'count' => count($orders),
                'pages_fetched' => $fetch['pages_fetched'] ?? 0,
                'sample' => array_map(static function ($o) {
                    return [
                        'shopify_order_id' => $o['shopify_order_id'] ?? '',
                        'name' => $o['name'] ?? '',
                        'customer_email' => $o['customer_email'] ?? '',
                        'total_cents' => $o['total_cents'] ?? 0,
                        'currency' => $o['currency'] ?? '',
                        'status' => 'archived',
                    ];
                }, array_slice($orders, 0, 5)),
            ];
        }

        $tokenRecord = $this->history->add([
            'type' => self::TYPE,
            'status' => 'dry_run',
            'preset' => 'shopify_cutover',
            'platform' => 'Shopify cutover',
            'resources' => $resources,
            'preview' => [
                'products' => $result['products']['count'] ?? null,
                'customers' => $result['customers']['count'] ?? null,
                'orders' => $result['orders']['count'] ?? null,
            ],
            'created_entry_ids' => [],
            'created_customer_ids' => [],
            'created_order_ids' => [],
            'imported_count' => 0,
        ]);
        $result['dry_run_token'] = $tokenRecord['id'];
        $result['batch_id'] = $tokenRecord['id'];

        return $result;
    }

    /**
     * @param string|list<string> $resources
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    public function import($resources = 'all', array $options = []): array
    {
        $confirm = !empty($options['confirm']);
        $token = trim((string) ($options['dry_run_token'] ?? ($options['batch_id'] ?? '')));
        if (!$confirm && $token === '') {
            return ['ok' => false, 'error' => 'Import requires confirm=true or a dry_run_token from shopify_cutover_dry_run'];
        }
        if ($token !== '') {
            $prior = $this->history->get($token);
            if ($prior === null || ($prior['type'] ?? '') !== self::TYPE) {
                return ['ok' => false, 'error' => 'Invalid dry_run_token'];
            }
            if (($prior['status'] ?? '') === 'rolled_back') {
                return ['ok' => false, 'error' => 'This cutover batch was rolled back'];
            }
        }

        $resources = $this->normalizeResources($resources);
        $creds = $this->resolveCredentials($options);
        if (!($creds['ok'] ?? false)) {
            return $creds;
        }
        $credentials = $creds['credentials'];
        $fetchOpts = ['max_pages' => max(1, (int) ($options['max_pages'] ?? ShopifyImportAdapter::MAX_PAGES))];
        $collection = trim((string) ($options['collection'] ?? ($credentials['collection'] ?? 'products')));
        if ($collection === '') {
            $collection = 'products';
        }
        $currency = strtolower((string) ($options['currency'] ?? ($credentials['default_currency'] ?? 'eur')));

        $createdEntryIds = [];
        $updatedEntryIds = [];
        $createdCustomerIds = [];
        $updatedCustomerIds = [];
        $createdOrderIds = [];
        $skippedOrderIds = [];
        $errors = [];
        $productImportId = null;

        if (in_array('products', $resources, true)) {
            $fetch = $this->adapter->fetchProductRows($credentials, $fetchOpts);
            if (!($fetch['ok'] ?? false)) {
                return ['ok' => false, 'error' => $fetch['error'] ?? 'Product fetch failed', 'stage' => 'products'];
            }
            $rows = $this->import->applyDefaultCurrency($fetch['rows'] ?? [], $currency);
            foreach ($rows as &$row) {
                if (!empty($row['commerce']['purchase_options'][0])) {
                    $row['commerce']['purchase_options'][0]['currency'] = $currency;
                    if (function_exists('commerce_normalize_value')) {
                        $row['commerce'] = commerce_normalize_value($row['commerce']);
                    }
                }
            }
            unset($row);
            $importResult = $this->import->importRows($rows, $collection, false, [
                'preset' => 'shopify_cutover',
                'platform' => 'Shopify cutover',
                'currency' => $currency,
                'file_name' => 'shopify-cutover-products',
            ]);
            if (!($importResult['ok'] ?? false)) {
                return [
                    'ok' => false,
                    'error' => $importResult['error'] ?? 'Product import failed',
                    'stage' => 'products',
                ];
            }
            $productImportId = $importResult['import_id'] ?? null;
            $createdEntryIds = $importResult['created'] ?? [];
            $updatedEntryIds = $importResult['updated'] ?? [];
            foreach ($importResult['skipped'] ?? [] as $skip) {
                $errors[] = is_string($skip) ? $skip : json_encode($skip);
            }
        }

        if (in_array('customers', $resources, true)) {
            $fetch = $this->adapter->fetchCustomers($credentials, $fetchOpts);
            if (!($fetch['ok'] ?? false)) {
                return ['ok' => false, 'error' => $fetch['error'] ?? 'Customer fetch failed', 'stage' => 'customers'];
            }
            foreach ($fetch['customers'] ?? [] as $payload) {
                try {
                    unset($payload['password'], $payload['password_hash'], $payload['passwd']);
                    $before = $this->customers->getByEmail((string) ($payload['email'] ?? ''));
                    $saved = $this->customers->upsert($payload);
                    if ($before) {
                        $updatedCustomerIds[] = $saved['id'];
                    } else {
                        $createdCustomerIds[] = $saved['id'];
                    }
                } catch (Throwable $e) {
                    $errors[] = 'Customer: ' . $e->getMessage();
                }
            }
        }

        if (in_array('orders', $resources, true)) {
            $fetch = $this->adapter->fetchOrders($credentials, $fetchOpts);
            if (!($fetch['ok'] ?? false)) {
                return ['ok' => false, 'error' => $fetch['error'] ?? 'Order fetch failed', 'stage' => 'orders'];
            }
            foreach ($fetch['orders'] ?? [] as $mapped) {
                try {
                    $outcome = $this->importArchivedOrder($mapped);
                    if (($outcome['status'] ?? '') === 'created') {
                        $createdOrderIds[] = $outcome['order_id'];
                    } else {
                        $skippedOrderIds[] = $outcome['order_id'] ?? ($mapped['shopify_order_id'] ?? '');
                    }
                } catch (Throwable $e) {
                    $errors[] = 'Order: ' . $e->getMessage();
                }
            }
        }

        $importedCount = count($createdEntryIds) + count($createdCustomerIds) + count($createdOrderIds);
        $status = $errors === [] ? 'success' : ($importedCount > 0 ? 'partial' : 'failed');

        $batchPayload = [
            'type' => self::TYPE,
            'status' => $status,
            'preset' => 'shopify_cutover',
            'platform' => 'Shopify cutover',
            'collection' => $collection,
            'currency' => $currency,
            'resources' => $resources,
            'product_import_id' => $productImportId,
            'created_entry_ids' => array_values($createdEntryIds),
            'updated_entry_ids' => array_values($updatedEntryIds),
            'entry_ids' => array_values(array_merge($createdEntryIds, $updatedEntryIds)),
            'created_customer_ids' => array_values(array_unique($createdCustomerIds)),
            'updated_customer_ids' => array_values(array_unique($updatedCustomerIds)),
            'created_order_ids' => array_values(array_unique($createdOrderIds)),
            'skipped_order_ids' => array_values(array_unique($skippedOrderIds)),
            'imported_count' => $importedCount,
            'created_count' => count($createdEntryIds) + count($createdCustomerIds) + count($createdOrderIds),
            'updated_count' => count($updatedEntryIds) + count($updatedCustomerIds),
            'skipped_count' => count($skippedOrderIds),
            'errors' => array_slice($errors, 0, 100),
            'dry_run_token' => $token !== '' ? $token : null,
        ];

        if ($token !== '') {
            $saved = $this->history->update($token, $batchPayload) ?? $this->history->add($batchPayload);
        } else {
            $saved = $this->history->add($batchPayload);
        }

        return [
            'ok' => $status !== 'failed',
            'status' => $status,
            'batch_id' => $saved['id'] ?? $token,
            'product_import_id' => $productImportId,
            'products' => [
                'created' => count($createdEntryIds),
                'updated' => count($updatedEntryIds),
            ],
            'customers' => [
                'created' => count($createdCustomerIds),
                'updated' => count($updatedCustomerIds),
            ],
            'orders' => [
                'created' => count($createdOrderIds),
                'skipped' => count($skippedOrderIds),
            ],
            'errors' => array_slice($errors, 0, 50),
            'note' => 'Cutover import only — not perpetual sync. Archived orders skip fulfillment, stock, and paid automation.',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function rollback(string $batchId, bool $deleteCollection = false): array
    {
        $batchId = trim($batchId);
        if ($batchId === '') {
            return ['ok' => false, 'error' => 'batch_id required'];
        }
        $record = $this->history->get($batchId);
        if ($record === null || ($record['type'] ?? '') !== self::TYPE) {
            return ['ok' => false, 'error' => 'Cutover batch not found'];
        }
        if (!empty($record['rolled_back_at'])) {
            return ['ok' => false, 'error' => 'This cutover batch was already rolled back'];
        }

        $deletedCustomers = 0;
        foreach ($record['created_customer_ids'] ?? [] as $cid) {
            if ($this->customers->delete((string) $cid)) {
                $deletedCustomers++;
            }
        }

        $deletedOrders = 0;
        foreach ($record['created_order_ids'] ?? [] as $oid) {
            if ($this->orders->delete((string) $oid)) {
                $deletedOrders++;
            }
        }

        $productRollback = null;
        $productImportId = (string) ($record['product_import_id'] ?? '');
        if ($productImportId !== '') {
            $productRollback = $this->import->rollbackImport($productImportId, $deleteCollection);
        } elseif (!empty($record['created_entry_ids']) || !empty($record['entry_ids'])) {
            // Entries recorded on the cutover batch itself.
            $productRollback = $this->import->rollbackImport($batchId, $deleteCollection);
            if (!($productRollback['ok'] ?? false) && ($productRollback['error'] ?? '') === 'Import has no collection') {
                $productRollback = ['ok' => true, 'deleted' => 0, 'skipped' => true];
            }
        }

        $this->history->update($batchId, [
            'status' => 'rolled_back',
            'rolled_back_at' => date('c'),
            'deleted_customer_count' => $deletedCustomers,
            'deleted_order_count' => $deletedOrders,
            'product_rollback' => $productRollback,
        ]);

        return [
            'ok' => true,
            'batch_id' => $batchId,
            'deleted_customers' => $deletedCustomers,
            'deleted_orders' => $deletedOrders,
            'product_rollback' => $productRollback,
        ];
    }

    /**
     * Import one archived Shopify order. Never fulfills, decrements stock, or fires paid automation.
     *
     * @param array<string, mixed> $mapped from ShopifyImportAdapter::mapOrder
     * @return array{status: string, order_id?: string}
     */
    public function importArchivedOrder(array $mapped): array
    {
        $shopifyId = trim((string) ($mapped['shopify_order_id'] ?? ''));
        if ($shopifyId === '') {
            throw new InvalidArgumentException('shopify_order_id required');
        }

        $existing = $this->orders->findByShopifyOrderId($shopifyId);
        if ($existing) {
            return ['status' => 'skipped', 'order_id' => (string) ($existing['id'] ?? '')];
        }

        $email = strtolower(trim((string) ($mapped['customer_email'] ?? '')));
        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->customers->upsert([
                'email' => $email,
                'name' => (string) ($mapped['customer_name'] ?? ''),
                'addresses' => !empty($mapped['shipping_address']) ? [[
                    'label' => 'Shipping',
                    'name' => (string) ($mapped['shipping_address']['name'] ?? ''),
                    'line1' => (string) ($mapped['shipping_address']['line1'] ?? ''),
                    'line2' => (string) ($mapped['shipping_address']['line2'] ?? ''),
                    'city' => (string) ($mapped['shipping_address']['city'] ?? ''),
                    'region' => (string) ($mapped['shipping_address']['region'] ?? ''),
                    'postal' => (string) ($mapped['shipping_address']['postal_code'] ?? ''),
                    'country' => (string) ($mapped['shipping_address']['country'] ?? ''),
                    'phone' => (string) ($mapped['shipping_address']['phone'] ?? ''),
                    'default' => true,
                ]] : [],
                'source' => 'shopify',
                'external_ids' => ['shopify_order_email' => $email],
            ]);
        }

        // Critical: create via OrderStore only — no CheckoutService, no PostPurchaseRouter,
        // no stock reservation/decrement, no Automation paid emails.
        if ($this->fulfillmentSpy !== null) {
            // Intentionally not calling the spy — archive import must never fulfill.
        }

        $orderId = 'shopify_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $shopifyId);
        $lines = is_array($mapped['lines'] ?? null) ? $mapped['lines'] : [];
        foreach ($lines as &$line) {
            if (!empty($mapped['already_fulfilled']) || ($line['fulfillment_status'] ?? '') === 'shipped') {
                $line['fulfillment_status'] = 'shipped';
                $line['shipped_at'] = $mapped['created_at'] ?? date('c');
            }
        }
        unset($line);

        $order = $this->orders->create([
            'id' => $orderId,
            'status' => 'archived',
            'source' => 'shopify_archive',
            'shopify_order_id' => $shopifyId,
            'archive_import' => true,
            'skip_fulfillment' => true,
            'skip_inventory' => true,
            'skip_automation' => true,
            'created_at' => (string) ($mapped['created_at'] ?? date('c')),
            'customer_email' => $email,
            'customer_name' => (string) ($mapped['customer_name'] ?? ''),
            'currency' => strtolower((string) ($mapped['currency'] ?? 'eur')),
            'total_cents' => (int) ($mapped['total_cents'] ?? 0),
            'shipping_cents' => (int) ($mapped['shipping_cents'] ?? 0),
            'tax_cents' => (int) ($mapped['tax_cents'] ?? 0),
            'discount_cents' => (int) ($mapped['discount_cents'] ?? 0),
            'tax_lines' => $mapped['tax_lines'] ?? [],
            'shipping_lines' => $mapped['shipping_lines'] ?? [],
            'discount_allocations' => $mapped['discount_allocations'] ?? [],
            'gift_card_applications' => [],
            'lines' => $lines,
            'shipping_address' => $mapped['shipping_address'] ?? null,
            'tags' => array_values(array_unique(array_merge(
                is_array($mapped['tags'] ?? null) ? $mapped['tags'] : [],
                ['shopify-archive']
            ))),
            'fulfillment_results' => [[
                'ok' => true,
                'skipped' => true,
                'reason' => 'shopify_archive',
            ]],
            'notes' => [[
                'body' => 'Imported from Shopify order ' . ($mapped['name'] ?? $shopifyId) . ' as archived history. No fulfillment or stock changes applied.',
                'created_at' => date('c'),
                'author' => 'shopify_cutover',
            ]],
            'provider' => 'shopify_archive',
            'payment_id' => null,
        ]);

        return ['status' => 'created', 'order_id' => (string) ($order['id'] ?? $orderId)];
    }

    /**
     * @param string|list<string> $resources
     * @return list<string>
     */
    private function normalizeResources($resources): array
    {
        if (is_string($resources)) {
            $resources = strtolower(trim($resources));
            if ($resources === '' || $resources === 'all') {
                return ['products', 'customers', 'orders'];
            }
            $resources = preg_split('/\s*,\s*/', $resources) ?: [];
        }
        if (!is_array($resources)) {
            return ['products', 'customers', 'orders'];
        }
        $allowed = ['products', 'customers', 'orders'];
        $out = [];
        foreach ($resources as $r) {
            $r = strtolower(trim((string) $r));
            if ($r === 'all') {
                return $allowed;
            }
            if (in_array($r, $allowed, true)) {
                $out[] = $r;
            }
        }
        return $out !== [] ? array_values(array_unique($out)) : $allowed;
    }

    /**
     * @param array<string, mixed> $options
     * @return array{ok: bool, credentials?: array<string, mixed>, error?: string}
     */
    private function resolveCredentials(array $options): array
    {
        $domain = trim((string) ($options['shop_domain'] ?? ''));
        $token = trim((string) ($options['access_token'] ?? ''));
        if ($domain !== '' && $token !== '') {
            return [
                'ok' => true,
                'credentials' => [
                    'shop_domain' => $domain,
                    'access_token' => $token,
                    'collection' => $options['collection'] ?? 'products',
                    'default_currency' => $options['currency'] ?? 'eur',
                ],
            ];
        }
        $stored = $this->credentials->getPlatformConfig('shopify', true);
        if (trim((string) ($stored['shop_domain'] ?? '')) === '' || trim((string) ($stored['access_token'] ?? '')) === '') {
            return ['ok' => false, 'error' => 'Shopify credentials not configured. Save shop domain + token under Import, or pass them in the request.'];
        }
        return ['ok' => true, 'credentials' => $stored];
    }
}
