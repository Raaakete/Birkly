<?php
/**
 * EasyPost tracker webhook verification + order shipment updates.
 */

class EasyPostTrackingWebhookService
{
    private CommerceOrderStore $orders;

    /** @var null|callable(string, array): void */
    public static $automationSpy = null;

    public function __construct(?CommerceOrderStore $orders = null)
    {
        if (!class_exists('CommerceOrderStore')) {
            require_once __DIR__ . '/CommerceOrderStore.php';
        }
        $this->orders = $orders ?? new CommerceOrderStore();
    }

    /**
     * Verify webhook authenticity.
     * Accepts:
     * - X-Commerce-Webhook-Secret matching stored secret
     * - HMAC SHA256 of body in X-Hmac-Sha256 / X-EasyPost-Signature using secret
     * - Mock: COMMERCE_EASYPOST_MOCK=1 + X-Commerce-Mock: 1 (or secret "mock")
     *
     * @param array<string, mixed> $headers
     */
    public function verifySignature(string $rawBody, array $headers, string $secret): bool
    {
        $secret = trim($secret);
        $mockHeader = strtolower($this->header($headers, 'X-Commerce-Mock'));
        $env = getenv('COMMERCE_EASYPOST_MOCK');
        $envMock = $env === '1' || strtolower((string) $env) === 'true';

        // Explicit mock path for tests: env mock + X-Commerce-Mock header.
        if ($envMock && ($mockHeader === '1' || $mockHeader === 'true')) {
            return true;
        }

        // Fail closed when no shared secret is configured.
        if ($secret === '') {
            return false;
        }

        $provided = trim($this->header($headers, 'X-Commerce-Webhook-Secret'));
        if ($provided !== '' && hash_equals($secret, $provided)) {
            return true;
        }

        $hmacHeader = trim($this->header($headers, 'X-Hmac-Sha256'));
        if ($hmacHeader === '') {
            $hmacHeader = trim($this->header($headers, 'X-EasyPost-Signature'));
        }
        if ($hmacHeader === '') {
            return false;
        }
        $expected = base64_encode(hash_hmac('sha256', $rawBody, $secret, true));
        $expectedHex = hash_hmac('sha256', $rawBody, $secret);
        return hash_equals($expected, $hmacHeader)
            || hash_equals($expectedHex, $hmacHeader);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array{ok: bool, error?: string, order?: array, shipment?: array, status?: string}
     */
    public function handleTrackerUpdate(array $payload): array
    {
        $result = is_array($payload['result'] ?? null) ? $payload['result'] : $payload;
        if (!is_array($result)) {
            return ['ok' => false, 'error' => 'Invalid tracker payload'];
        }

        $trackerId = trim((string) ($result['id'] ?? ($payload['tracker_id'] ?? '')));
        $tracking = trim((string) ($result['tracking_code'] ?? ($result['tracking_number'] ?? ($payload['tracking_number'] ?? ''))));
        $status = strtolower(trim((string) ($result['status'] ?? ($payload['status'] ?? ''))));
        $carrier = trim((string) ($result['carrier'] ?? ($payload['carrier'] ?? '')));
        $publicUrl = trim((string) ($result['public_url'] ?? ''));
        $orderIdHint = trim((string) ($result['reference'] ?? ($payload['order_id'] ?? ($payload['metadata']['order_id'] ?? ''))));

        if ($tracking === '' && $trackerId === '' && $orderIdHint === '') {
            return ['ok' => false, 'error' => 'No tracking identifier in payload'];
        }

        $match = $this->findOrderAndShipment($orderIdHint, $trackerId, $tracking);
        if ($match === null) {
            return ['ok' => false, 'error' => 'No matching order shipment for tracker'];
        }

        [$order, $shipmentIndex] = $match;
        $shipments = is_array($order['shipments'] ?? null) ? $order['shipments'] : [];
        $shipment = $shipments[$shipmentIndex];
        if ($tracking !== '') {
            $shipment['tracking_number'] = $tracking;
        }
        if ($carrier !== '') {
            $shipment['carrier'] = $carrier;
        }
        if ($trackerId !== '') {
            $shipment['easypost_tracker_id'] = $trackerId;
        }
        if ($publicUrl !== '') {
            $shipment['tracking_url'] = $publicUrl;
        }
        if ($status !== '') {
            $shipment['tracking_status'] = $status;
        }
        $shipment['tracking_updated_at'] = date('c');
        $shipments[$shipmentIndex] = $shipment;

        $lines = is_array($order['lines'] ?? null) ? $order['lines'] : [];
        foreach ($lines as $idx => $line) {
            if (($line['fulfillment'] ?? '') !== 'ship') {
                continue;
            }
            if (($shipment['tracking_number'] ?? '') !== '' && (
                ($line['tracking_number'] ?? '') === ($shipment['tracking_number'] ?? '')
                || $this->shipmentContainsLine($shipment, (string) ($line['line_id'] ?? ''))
            )) {
                if ($tracking !== '') {
                    $lines[$idx]['tracking_number'] = $tracking;
                }
                if ($carrier !== '') {
                    $lines[$idx]['carrier'] = $carrier;
                }
                if ($status === 'delivered') {
                    $lines[$idx]['fulfillment_status'] = 'shipped';
                }
            }
        }

        $patch = [
            'shipments' => $shipments,
            'lines' => $lines,
        ];
        if ($status === 'delivered' && class_exists('CommerceOrderOps')) {
            $patch['fulfillment_status'] = CommerceOrderOps::deriveOrderFulfillmentStatus(array_merge($order, $patch));
        }

        $updated = $this->orders->update((string) $order['id'], $patch);
        if (!$updated) {
            return ['ok' => false, 'error' => 'Failed to update order'];
        }

        $this->fireAutomation('commerce_tracking_updated', [
            'order_id' => $updated['id'] ?? '',
            'order_number' => $updated['order_number'] ?? '',
            'shipment_id' => $shipment['id'] ?? '',
            'tracking_number' => $shipment['tracking_number'] ?? '',
            'tracking_status' => $status,
            'carrier' => $shipment['carrier'] ?? '',
            'customer_email' => $updated['customer_email'] ?? '',
        ]);

        if ($status === 'delivered') {
            $this->fireAutomation('commerce_order_shipped', [
                'order_id' => $updated['id'] ?? '',
                'order_number' => $updated['order_number'] ?? '',
                'customer_email' => $updated['customer_email'] ?? '',
                'shipment' => $shipment,
                'tracking_number' => $shipment['tracking_number'] ?? '',
                'carrier' => $shipment['carrier'] ?? '',
                'notify_customer' => true,
                'source' => 'easypost_webhook',
            ]);
        }

        return [
            'ok' => true,
            'order' => $updated,
            'shipment' => $shipment,
            'status' => $status,
        ];
    }

    /**
     * @return array{0: array<string, mixed>, 1: int}|null
     */
    private function findOrderAndShipment(string $orderIdHint, string $trackerId, string $tracking): ?array
    {
        if ($orderIdHint !== '') {
            $order = $this->orders->get($orderIdHint);
            if (is_array($order)) {
                $idx = $this->matchShipmentIndex($order, $trackerId, $tracking);
                if ($idx !== null) {
                    return [$order, $idx];
                }
                // If order hint matches but no shipment yet, attach to last shipment or fail.
                $shipments = is_array($order['shipments'] ?? null) ? $order['shipments'] : [];
                if ($shipments !== []) {
                    return [$order, count($shipments) - 1];
                }
            }
        }

        foreach ($this->orders->listAll() as $order) {
            if (!is_array($order)) {
                continue;
            }
            $idx = $this->matchShipmentIndex($order, $trackerId, $tracking);
            if ($idx !== null) {
                return [$order, $idx];
            }
        }
        return null;
    }

    private function matchShipmentIndex(array $order, string $trackerId, string $tracking): ?int
    {
        foreach (is_array($order['shipments'] ?? null) ? $order['shipments'] : [] as $i => $shipment) {
            if (!is_array($shipment)) {
                continue;
            }
            if ($trackerId !== '' && ($shipment['easypost_tracker_id'] ?? '') === $trackerId) {
                return (int) $i;
            }
            if ($tracking !== '' && strcasecmp((string) ($shipment['tracking_number'] ?? ''), $tracking) === 0) {
                return (int) $i;
            }
        }
        return null;
    }

    private function shipmentContainsLine(array $shipment, string $lineId): bool
    {
        if ($lineId === '') {
            return false;
        }
        foreach (is_array($shipment['items'] ?? null) ? $shipment['items'] : [] as $item) {
            if ((string) ($item['line_id'] ?? '') === $lineId) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function fireAutomation(string $event, array $payload): void
    {
        if (is_callable(self::$automationSpy)) {
            (self::$automationSpy)($event, $payload);
        }
        if (function_exists('broadcast_event')) {
            broadcast_event($event, $payload, 'commerce');
        }
        if (function_exists('enqueue_automation')) {
            enqueue_automation($event, $payload);
        }
    }

    /**
     * @param array<string, mixed> $headers
     */
    private function header(array $headers, string $name): string
    {
        $target = strtolower($name);
        foreach ($headers as $key => $value) {
            if (is_int($key)) {
                if (stripos((string) $value, $name . ':') === 0) {
                    return trim(substr((string) $value, strlen($name) + 1));
                }
                continue;
            }
            if (strtolower((string) $key) === $target) {
                return is_array($value) ? (string) ($value[0] ?? '') : (string) $value;
            }
        }
        return '';
    }
}
