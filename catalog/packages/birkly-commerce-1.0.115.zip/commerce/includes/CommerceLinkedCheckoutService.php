<?php
/**
 * Server-side linked entry + hosted checkout for storefront binders (P70).
 */

declare(strict_types=1);

if (!class_exists('CommerceSchema')) {
    require_once __DIR__ . '/CommerceSchema.php';
}

class CommerceLinkedCheckoutService
{
    public function __construct(
        private CommerceCartSession $cart,
        private CommerceCatalog $catalog,
        private CommerceCheckoutService $checkout,
    ) {
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    public function begin(array $input): array
    {
        $product = is_array($input['product'] ?? null) ? $input['product'] : [];
        $customer = is_array($input['customer'] ?? null) ? $input['customer'] : [];
        $linked = is_array($input['linked_entry'] ?? null) ? $input['linked_entry'] : null;

        $collection = trim((string) ($product['collection'] ?? ''));
        $entryRef = trim((string) ($product['entry_id'] ?? ''));
        $optionId = trim((string) ($product['purchase_option_id'] ?? ''));
        $amountCents = isset($product['amount_cents']) ? (int) $product['amount_cents'] : null;

        if ($collection === '' || $entryRef === '') {
            return ['ok' => false, 'error' => 'product.collection and product.entry_id required'];
        }

        $item = $this->catalog->resolveItem($collection, $entryRef);
        if ($item === null) {
            return ['ok' => false, 'error' => 'Item not in catalog'];
        }

        $entryId = (string) ($item['entry_id'] ?? $entryRef);
        $commerce = CommerceSchema::normalizeValue($item['commerce'] ?? $item);
        $option = CommerceSchema::findPurchaseOption($commerce, $optionId !== '' ? $optionId : null);
        if ($option === null) {
            return ['ok' => false, 'error' => 'Purchase option not found'];
        }

        $resolved = CommerceSchema::resolveOptionAmountCents($option, $amountCents);
        if (!($resolved['ok'] ?? false)) {
            return ['ok' => false, 'error' => (string) ($resolved['message'] ?? 'Invalid amount')];
        }
        $chargeCents = (int) ($resolved['amount_cents'] ?? 0);
        $purchaseOptionId = (string) ($option['id'] ?? 'default');

        $email = trim((string) ($customer['email'] ?? ''));
        if ($email === '') {
            return ['ok' => false, 'error' => 'customer.email required'];
        }

        $linkedEntryId = null;
        $entrySyncMeta = [];
        if ($linked !== null) {
            $linkedCollection = trim((string) ($linked['collection'] ?? ''));
            $fields = is_array($linked['fields'] ?? null) ? $linked['fields'] : [];
            if ($linkedCollection === '') {
                return ['ok' => false, 'error' => 'linked_entry.collection required'];
            }
            $created = $this->createLinkedEntry($linkedCollection, $fields);
            if (!($created['ok'] ?? false)) {
                return ['ok' => false, 'error' => (string) ($created['error'] ?? 'Failed to create linked entry')];
            }
            $linkedEntryId = (string) ($created['entry_id'] ?? '');
            $consentField = trim((string) ($linked['consent_field'] ?? ''));
            $consentValue = $consentField !== '' ? ($fields[$consentField] ?? false) : false;
            $entrySyncMeta = $this->buildEntrySyncMetadata($linkedCollection, $linkedEntryId, $consentValue);
        }

        $successUrl = trim((string) ($input['success_url'] ?? ''));
        $cancelUrl = trim((string) ($input['cancel_url'] ?? ''));
        $hostedCheckout = !empty($input['hosted_checkout']) || $successUrl !== '';

        $this->cart->clear();
        $this->cart->clearCheckoutDraft();
        $this->cart->addItem($collection, $entryId, 1, $purchaseOptionId, null, $chargeCents);

        $customerName = trim((string) ($customer['name'] ?? ''));
        $draft = ['email' => $email];
        if ($customerName !== '') {
            $draft['customer_name'] = $customerName;
        }
        if ($entrySyncMeta !== []) {
            $draft['metadata'] = $entrySyncMeta;
        }
        $passthroughMeta = $this->extractCheckoutMetadata($input);
        if ($passthroughMeta !== []) {
            $draft['metadata'] = array_merge(is_array($draft['metadata'] ?? null) ? $draft['metadata'] : [], $passthroughMeta);
        }
        $this->cart->setCheckoutDraft($draft);

        $checkoutData = [
            'customer_email' => $email,
            'customer_name' => $customerName,
            'hosted_checkout' => $hostedCheckout,
        ];
        if ($entrySyncMeta !== []) {
            $checkoutData['entry_sync_meta'] = $entrySyncMeta;
            $checkoutData['donor_meta'] = $entrySyncMeta;
        }
        if ($passthroughMeta !== []) {
            $checkoutData['metadata'] = $passthroughMeta;
        }

        $result = $this->checkout->checkout($email, $successUrl, $cancelUrl, $checkoutData);
        if (!($result['ok'] ?? false)) {
            $result['linked_entry_id'] = $linkedEntryId;
            return $result;
        }

        return array_merge($result, array_filter([
            'linked_entry_id' => $linkedEntryId,
        ]));
    }

    /**
     * Passthrough checkout metadata (e.g. signup_flow_* from User plugin).
     *
     * @param array<string, mixed> $input
     * @return array<string, string>
     */
    private function extractCheckoutMetadata(array $input): array
    {
        $raw = is_array($input['metadata'] ?? null) ? $input['metadata'] : [];
        $allowed = ['signup_flow_id', 'signup_flow_session_id', 'signup_flow_opt_in', 'club_opt_in'];
        $meta = [];
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $raw)) {
                continue;
            }
            $value = trim((string) $raw[$key]);
            if ($value !== '') {
                $meta[$key] = $value;
            }
        }
        if (!isset($meta['signup_flow_opt_in']) && isset($meta['club_opt_in'])) {
            $meta['signup_flow_opt_in'] = $meta['club_opt_in'];
        }

        return $meta;
    }

    /**
     * @return array<string, string>
     */
    public static function entrySyncSettingKeys(): array
    {
        return [
            'entry_id_meta' => trim((string) commerce_get_setting('commerce_entry_sync_entry_id_meta', 'supporter_entry_id')),
            'collection_meta' => trim((string) commerce_get_setting('commerce_entry_sync_collection_meta', 'entry_collection')),
            'consent_meta' => trim((string) commerce_get_setting('commerce_entry_sync_consent_meta', 'featured')),
        ];
    }

    /**
     * @return array<string, string>
     */
    public function buildEntrySyncMetadata(string $linkedCollection, string $linkedEntryId, mixed $consentValue): array
    {
        $keys = self::entrySyncSettingKeys();
        $meta = [];
        if ($keys['entry_id_meta'] !== '') {
            $meta[$keys['entry_id_meta']] = $linkedEntryId;
        }
        if ($keys['collection_meta'] !== '') {
            $meta[$keys['collection_meta']] = $linkedCollection;
        }
        if ($keys['consent_meta'] !== '') {
            $meta[$keys['consent_meta']] = self::consentScalar($consentValue);
        }
        return $meta;
    }

    /**
     * @param array<string, mixed> $fields
     * @return array{ok: bool, entry_id?: string, error?: string}
     */
    public function createLinkedEntry(string $collectionSlug, array $fields): array
    {
        require_once dirname(__DIR__) . '/cms_paths.php';
        $dir = $this->collectionEntriesDir($collectionSlug);
        if ($dir === null) {
            return ['ok' => false, 'error' => 'Collection not found: ' . $collectionSlug];
        }

        $title = trim((string) ($fields['title'] ?? 'Supporter'));
        if ($title === '') {
            $title = 'Supporter';
        }
        $entryId = bin2hex(random_bytes(8));
        $slug = $this->slugify($title);
        $now = date('c');

        $entry = array_merge($fields, [
            'id' => $entryId,
            'slug' => $slug,
            'title' => $title,
            'status' => 'draft',
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $path = $dir . '/' . $entryId . '.json';
        if (@file_put_contents($path, json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) === false) {
            return ['ok' => false, 'error' => 'Failed to write linked entry'];
        }

        if (function_exists('do_action')) {
            do_action('after_entry_save', $entry, $collectionSlug, null);
        }

        return ['ok' => true, 'entry_id' => $entryId];
    }

    private static function consentScalar(mixed $value): string
    {
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        $s = strtolower(trim((string) $value));
        return in_array($s, ['1', 'true', 'yes', 'on', 'featured'], true) ? '1' : '0';
    }

    private function slugify(string $text): string
    {
        if (function_exists('birkly_generate_slug')) {
            return birkly_generate_slug($text);
        }
        $text = strtolower(trim($text));
        $text = preg_replace('/[^a-z0-9]+/', '-', $text) ?? '';
        $slug = trim($text, '-');
        return $slug !== '' ? $slug : 'entry';
    }

    private function collectionEntriesDir(string $collection): ?string
    {
        $root = commerce_cms_content_root() . '/collections';
        if (!is_dir($root)) {
            return null;
        }
        foreach (scandir($root) ?: [] as $dir) {
            if ($dir === '.' || $dir === '..') {
                continue;
            }
            $metaPath = $root . '/' . $dir . '/collection.json';
            if (!is_file($metaPath)) {
                continue;
            }
            $meta = json_decode((string) file_get_contents($metaPath), true);
            if (!is_array($meta)) {
                continue;
            }
            if (($meta['slug'] ?? $dir) === $collection) {
                $entries = $root . '/' . $dir . '/entries';
                if (!is_dir($entries)) {
                    @mkdir($entries, 0775, true);
                }
                return is_dir($entries) ? $entries : null;
            }
        }
        $fallback = $root . '/' . $collection . '/entries';
        if (is_dir($fallback) || @mkdir($fallback, 0775, true)) {
            return $fallback;
        }
        return null;
    }
}
