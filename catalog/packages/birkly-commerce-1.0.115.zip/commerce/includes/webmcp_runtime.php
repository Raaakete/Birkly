<?php
/**
 * Commerce WebMCP runtime pack registration (P83-M4).
 */

declare(strict_types=1);

if (!function_exists('birkly_webmcp_register_runtime_pack') || !function_exists('commerce_plugin_active')) {
    return;
}

if (!commerce_plugin_active()) {
    return;
}

birkly_webmcp_register_runtime_pack('commerce', [
    'pack' => 'commerce',
    'label' => 'Shop (Commerce)',
    'note' => 'Appears on pages where your shop is active.',
    'global' => 'BirklyCommerce',
    'surface' => '[data-birkly-commerce], [data-birkly-cart]',
    'script' => '/plugins/commerce/assets/webmcp-pack.js',
    'tools' => [
        'birkly_commerce_get_cart',
        'birkly_commerce_add_to_cart',
        'birkly_commerce_checkout',
    ],
]);
