<?php
/**
 * Customer self-service subscription management (storefront / account pages).
 *
 * Requires a signed-in site user (User Management) whose email owns the subscription.
 */

declare(strict_types=1);

class CommerceCustomerSubscriptionService
{
    private CommerceSubscriptionStore $store;
    private CommerceSubscriptionService $service;

    public function __construct(
        ?CommerceSubscriptionStore $store = null,
        ?CommerceSubscriptionService $service = null
    ) {
        $this->store = $store ?? new CommerceSubscriptionStore();
        $shelf = function_exists('commerce_bootstrap') ? commerce_bootstrap() : null;
        $this->service = $service ?? new CommerceSubscriptionService($this->store, $shelf);
    }

    /**
     * @return array{enabled: bool, allow_pause: bool, allow_cancel: bool}
     */
    public static function selfServicePolicy(): array
    {
        if (isset($GLOBALS['commerce_test_settings']) && is_array($GLOBALS['commerce_test_settings'])) {
            $s = $GLOBALS['commerce_test_settings'];

            return [
                'enabled' => array_key_exists('commerce_customer_subscription_self_service_enabled', $s)
                    ? !empty($s['commerce_customer_subscription_self_service_enabled'])
                    : true,
                'allow_pause' => array_key_exists('commerce_customer_subscription_pause_enabled', $s)
                    ? !empty($s['commerce_customer_subscription_pause_enabled'])
                    : true,
                'allow_cancel' => array_key_exists('commerce_customer_subscription_cancel_enabled', $s)
                    ? !empty($s['commerce_customer_subscription_cancel_enabled'])
                    : true,
            ];
        }

        $enabled = true;
        $allowPause = true;
        $allowCancel = true;
        if (function_exists('commerce_get_setting')) {
            $enabled = (bool) commerce_get_setting('commerce_customer_subscription_self_service_enabled', true);
            $allowPause = (bool) commerce_get_setting('commerce_customer_subscription_pause_enabled', true);
            $allowCancel = (bool) commerce_get_setting('commerce_customer_subscription_cancel_enabled', true);
        }

        return [
            'enabled' => $enabled,
            'allow_pause' => $allowPause,
            'allow_cancel' => $allowCancel,
        ];
    }

    /**
     * @return array{ok: bool, error?: string, email?: string}
     */
    public function resolveCustomerEmail(): array
    {
        if (!empty($GLOBALS['commerce_test_customer_email'])) {
            $email = strtolower(trim((string) $GLOBALS['commerce_test_customer_email']));
            if ($email !== '') {
                return ['ok' => true, 'email' => $email];
            }
        }

        if (!function_exists('get_plugin_state') || !get_plugin_state('user_management')) {
            return ['ok' => false, 'error' => 'Sign in required'];
        }

        $pluginDir = function_exists('user_management_plugin_dir')
            ? user_management_plugin_dir()
            : '';
        if ($pluginDir === '' || !is_file($pluginDir . '/includes/UserAuth.php')) {
            return ['ok' => false, 'error' => 'Sign in required'];
        }
        require_once $pluginDir . '/includes/UserAuth.php';

        $auth = new UserAuth('site');
        $user = $auth->getCurrentUser();
        $email = strtolower(trim((string) ($user['email'] ?? '')));
        if ($email === '' || empty($user['id'])) {
            return ['ok' => false, 'error' => 'Sign in required'];
        }

        return ['ok' => true, 'email' => $email];
    }

    /**
     * @return array{ok: bool, error?: string, subscriptions?: list<array<string, mixed>>, policy?: array<string, mixed>}
     */
    public function listForCustomer(): array
    {
        $policy = self::selfServicePolicy();
        if (!$policy['enabled']) {
            return ['ok' => false, 'error' => 'Subscription self-service is not enabled'];
        }

        $resolved = $this->resolveCustomerEmail();
        if (!($resolved['ok'] ?? false)) {
            return $resolved;
        }

        $email = (string) $resolved['email'];
        $subs = [];
        foreach ($this->store->listAll() as $sub) {
            if (!is_array($sub)) {
                continue;
            }
            if (strtolower(trim((string) ($sub['customer_email'] ?? ''))) !== $email) {
                continue;
            }
            $public = $this->publicSubscription($sub, $policy);
            if ($public !== null) {
                $subs[] = $public;
            }
        }

        return ['ok' => true, 'subscriptions' => $subs, 'policy' => $policy];
    }

    /**
     * @return array{ok: bool, error?: string, subscription?: array<string, mixed>}
     */
    public function getForCustomer(string $subscriptionId): array
    {
        $policy = self::selfServicePolicy();
        if (!$policy['enabled']) {
            return ['ok' => false, 'error' => 'Subscription self-service is not enabled'];
        }

        $resolved = $this->resolveCustomerEmail();
        if (!($resolved['ok'] ?? false)) {
            return $resolved;
        }

        $sub = $this->ownedSubscription((string) $resolved['email'], $subscriptionId);
        if ($sub === null) {
            return ['ok' => false, 'error' => 'Subscription not found'];
        }

        $public = $this->publicSubscription($sub, $policy);
        if ($public === null) {
            return ['ok' => false, 'error' => 'Subscription not found'];
        }

        return ['ok' => true, 'subscription' => $public];
    }

    /**
     * @return array{ok: bool, error?: string, subscription?: array<string, mixed>|null}
     */
    public function cancelForCustomer(string $subscriptionId): array
    {
        $policy = self::selfServicePolicy();
        if (!$policy['enabled'] || !$policy['allow_cancel']) {
            return ['ok' => false, 'error' => 'Subscription cancel is not enabled'];
        }

        $resolved = $this->resolveCustomerEmail();
        if (!($resolved['ok'] ?? false)) {
            return $resolved;
        }

        $sub = $this->ownedSubscription((string) $resolved['email'], $subscriptionId);
        if ($sub === null) {
            return ['ok' => false, 'error' => 'Subscription not found'];
        }

        $status = (string) ($sub['status'] ?? '');
        if (in_array($status, ['canceled', 'cancelled'], true)) {
            return ['ok' => true, 'subscription' => $this->publicSubscription($sub, $policy)];
        }
        if (!in_array($status, ['active', 'paused', 'past_due', 'trialing'], true)) {
            return ['ok' => false, 'error' => 'Subscription cannot be canceled'];
        }

        $updated = $this->service->cancel($subscriptionId);
        if (!$updated) {
            return ['ok' => false, 'error' => 'Cancel failed'];
        }

        $public = $this->publicSubscription($updated, $policy);
        if ($public === null) {
            $public = [
                'id' => (string) ($updated['id'] ?? $subscriptionId),
                'status' => 'canceled',
                'can_pause' => false,
                'can_resume' => false,
                'can_cancel' => false,
            ];
        }

        return ['ok' => true, 'subscription' => $public];
    }

    /**
     * @return array{ok: bool, error?: string, subscription?: array<string, mixed>|null}
     */
    public function pauseForCustomer(string $subscriptionId): array
    {
        $policy = self::selfServicePolicy();
        if (!$policy['enabled'] || !$policy['allow_pause']) {
            return ['ok' => false, 'error' => 'Subscription pause is not enabled'];
        }

        $resolved = $this->resolveCustomerEmail();
        if (!($resolved['ok'] ?? false)) {
            return $resolved;
        }

        $sub = $this->ownedSubscription((string) $resolved['email'], $subscriptionId);
        if ($sub === null) {
            return ['ok' => false, 'error' => 'Subscription not found'];
        }

        $status = (string) ($sub['status'] ?? '');
        if (!in_array($status, ['active', 'past_due', 'trialing'], true)) {
            return ['ok' => false, 'error' => 'Subscription cannot be paused'];
        }

        $updated = $this->service->pause($subscriptionId);
        if (!$updated) {
            return ['ok' => false, 'error' => 'Pause failed'];
        }

        return ['ok' => true, 'subscription' => $this->publicSubscription($updated, $policy)];
    }

    /**
     * @return array{ok: bool, error?: string, subscription?: array<string, mixed>|null}
     */
    public function resumeForCustomer(string $subscriptionId): array
    {
        $policy = self::selfServicePolicy();
        if (!$policy['enabled'] || !$policy['allow_pause']) {
            return ['ok' => false, 'error' => 'Subscription resume is not enabled'];
        }

        $resolved = $this->resolveCustomerEmail();
        if (!($resolved['ok'] ?? false)) {
            return $resolved;
        }

        $sub = $this->ownedSubscription((string) $resolved['email'], $subscriptionId);
        if ($sub === null) {
            return ['ok' => false, 'error' => 'Subscription not found'];
        }
        if ((string) ($sub['status'] ?? '') !== 'paused') {
            return ['ok' => false, 'error' => 'Subscription is not paused'];
        }

        $updated = $this->service->resume($subscriptionId);
        if (!$updated) {
            return ['ok' => false, 'error' => 'Resume failed'];
        }

        return ['ok' => true, 'subscription' => $this->publicSubscription($updated, $policy)];
    }

    /**
     * @param array<string, mixed> $policy
     * @return array<string, mixed>|null
     */
    private function publicSubscription(array $sub, array $policy): ?array
    {
        $status = (string) ($sub['status'] ?? '');
        if (in_array($status, ['canceled', 'cancelled'], true)) {
            return null;
        }

        $line = is_array($sub['lines'][0] ?? null) ? $sub['lines'][0] : [];
        $label = (string) ($line['title'] ?? $line['purchase_option_label'] ?? $line['purchase_option_id'] ?? 'Subscription');
        $canPause = !empty($policy['allow_pause']) && in_array($status, ['active', 'past_due', 'trialing'], true);
        $canResume = !empty($policy['allow_pause']) && $status === 'paused';
        $canCancel = !empty($policy['allow_cancel']) && in_array($status, ['active', 'paused', 'past_due', 'trialing'], true);

        return [
            'id' => (string) ($sub['id'] ?? ''),
            'status' => $status,
            'label' => $label,
            'interval' => (string) ($sub['interval'] ?? ''),
            'amount_cents' => (int) ($sub['amount_cents'] ?? 0),
            'currency' => (string) ($sub['currency'] ?? 'eur'),
            'next_billing_at' => $sub['next_billing_at'] ?? null,
            'paused_at' => $sub['paused_at'] ?? null,
            'past_due_at' => $sub['past_due_at'] ?? null,
            'can_pause' => $canPause,
            'can_resume' => $canResume,
            'can_cancel' => $canCancel,
            'pause_revokes_membership' => true,
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    private function ownedSubscription(string $email, string $subscriptionId): ?array
    {
        $subscriptionId = trim($subscriptionId);
        if ($subscriptionId === '') {
            return null;
        }

        $sub = $this->store->get($subscriptionId);
        if (!$sub || !is_array($sub)) {
            return null;
        }
        if (strtolower(trim((string) ($sub['customer_email'] ?? ''))) !== strtolower(trim($email))) {
            return null;
        }

        return $sub;
    }
}
