<?php
/**
 * Flat-file customer profiles for Commerce (P54 P1-M1).
 * Unique key: normalized email (lowercase + trim). Passwords are never stored.
 */

class CommerceCustomerStore
{
    private string $baseDir;
    private string $lockFile;

    /** @var list<string> */
    private const PASSWORD_COLUMNS = [
        'password', 'passwd', 'pass', 'password_hash', 'passwordhash',
        'hashed_password', 'pwd', 'secret',
    ];

    public function __construct(?string $baseDir = null)
    {
        if ($baseDir !== null) {
            $this->baseDir = rtrim($baseDir, '/');
        } else {
            $this->baseDir = commerce_data_dir() . '/customers';
        }
        if (!is_dir($this->baseDir)) {
            mkdir($this->baseDir, 0755, true);
        }
        $this->lockFile = $this->baseDir . '/customers.lock';
    }

    public function getDataDir(): string
    {
        return $this->baseDir;
    }

    public static function normalizeEmail(string $email): string
    {
        return strtolower(trim($email));
    }

    public function count(): int
    {
        $n = 0;
        foreach (glob($this->baseDir . '/cust_*.json') ?: [] as $file) {
            $data = json_decode((string) file_get_contents($file), true);
            if (is_array($data) && empty($data['deleted_at'])) {
                $n++;
            }
        }
        return $n;
    }

    public function getById(string $id): ?array
    {
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '', $id) ?? '';
        if ($id === '') {
            return null;
        }
        $file = $this->baseDir . '/' . $id . '.json';
        if (!is_file($file)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($file), true);
        if (!is_array($data) || !empty($data['deleted_at'])) {
            return null;
        }
        return $this->normalizeRecord($data);
    }

    public function getByEmail(string $email): ?array
    {
        $email = self::normalizeEmail($email);
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return null;
        }
        foreach ($this->listAll() as $customer) {
            if (($customer['email'] ?? '') === $email) {
                return $customer;
            }
        }
        return null;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listAll(): array
    {
        $rows = [];
        foreach (glob($this->baseDir . '/cust_*.json') ?: [] as $file) {
            $data = json_decode((string) file_get_contents($file), true);
            if (!is_array($data) || !empty($data['deleted_at'])) {
                continue;
            }
            $rows[] = $this->normalizeRecord($data);
        }
        usort($rows, static fn ($a, $b) => strcmp((string) ($b['updated_at'] ?? ''), (string) ($a['updated_at'] ?? '')));
        return $rows;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function list(string $search = ''): array
    {
        $search = strtolower(trim($search));
        $rows = $this->listAll();
        if ($search === '') {
            return $rows;
        }
        return array_values(array_filter($rows, static function (array $c) use ($search): bool {
            $hay = strtolower(implode(' ', [
                (string) ($c['email'] ?? ''),
                (string) ($c['name'] ?? ''),
                (string) ($c['phone'] ?? ''),
                (string) ($c['notes'] ?? ''),
                implode(' ', is_array($c['tags'] ?? null) ? $c['tags'] : []),
            ]));
            return str_contains($hay, $search);
        }));
    }

    /**
     * Upsert by normalized email. Never accepts password fields.
     *
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public function upsert(array $data): array
    {
        return $this->withLock(function () use ($data): array {
            $email = self::normalizeEmail((string) ($data['email'] ?? ''));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new InvalidArgumentException('Valid email is required');
            }

            $existing = null;
            foreach (glob($this->baseDir . '/cust_*.json') ?: [] as $file) {
                $row = json_decode((string) file_get_contents($file), true);
                if (!is_array($row) || !empty($row['deleted_at'])) {
                    continue;
                }
                if (self::normalizeEmail((string) ($row['email'] ?? '')) === $email) {
                    $existing = $row;
                    break;
                }
            }

            $now = date('c');
            if ($existing) {
                $record = $this->mergeProfile($existing, $data, false);
                $record['email'] = $email;
                $record['updated_at'] = $now;
                $this->write((string) $record['id'], $record);
                return $this->normalizeRecord($record);
            }

            $id = 'cust_' . bin2hex(random_bytes(6));
            $record = [
                'id' => $id,
                'email' => $email,
                'name' => trim((string) ($data['name'] ?? '')),
                'phone' => trim((string) ($data['phone'] ?? '')),
                'tags' => $this->normalizeTags($data['tags'] ?? []),
                'notes' => trim((string) ($data['notes'] ?? '')),
                'addresses' => $this->normalizeAddresses($data['addresses'] ?? []),
                'external_ids' => $this->normalizeExternalIds($data['external_ids'] ?? []),
                'user_id' => $data['user_id'] ?? null,
                'created_at' => $now,
                'updated_at' => $now,
                'source' => $this->normalizeSource($data['source'] ?? 'manual'),
            ];
            if ($record['user_id'] !== null) {
                $record['user_id'] = (string) $record['user_id'];
                if ($record['user_id'] === '') {
                    $record['user_id'] = null;
                }
            }
            $this->write($id, $record);
            return $this->normalizeRecord($record);
        });
    }

    /**
     * Update profile fields for an existing customer (by id or email).
     *
     * @param array<string, mixed> $patch
     */
    public function update(string $idOrEmail, array $patch): ?array
    {
        return $this->withLock(function () use ($idOrEmail, $patch): ?array {
            $existing = $this->getById($idOrEmail) ?? $this->getByEmail($idOrEmail);
            if (!$existing) {
                return null;
            }
            // Never allow email collision with another customer.
            if (isset($patch['email'])) {
                $newEmail = self::normalizeEmail((string) $patch['email']);
                if ($newEmail === '' || !filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
                    throw new InvalidArgumentException('Valid email is required');
                }
                $other = null;
                foreach (glob($this->baseDir . '/cust_*.json') ?: [] as $file) {
                    $row = json_decode((string) file_get_contents($file), true);
                    if (!is_array($row) || !empty($row['deleted_at'])) {
                        continue;
                    }
                    if (self::normalizeEmail((string) ($row['email'] ?? '')) === $newEmail
                        && ($row['id'] ?? '') !== ($existing['id'] ?? '')) {
                        $other = $row;
                        break;
                    }
                }
                if ($other) {
                    throw new InvalidArgumentException('Email already belongs to another customer');
                }
                $patch['email'] = $newEmail;
            }

            $record = $this->mergeProfile($existing, $patch, true);
            $record['updated_at'] = date('c');
            $this->write((string) $record['id'], $record);
            return $this->normalizeRecord($record);
        });
    }

    public function delete(string $id): bool
    {
        return $this->withLock(function () use ($id): bool {
            $existing = $this->getById($id);
            if (!$existing) {
                return false;
            }
            $existing['deleted_at'] = date('c');
            $existing['updated_at'] = $existing['deleted_at'];
            $this->write((string) $existing['id'], $existing);
            return true;
        });
    }

    /**
     * Upsert a customer profile from an order record.
     *
     * @param array<string, mixed> $order
     */
    public function ensureCustomerFromOrder(array $order): ?array
    {
        $email = self::normalizeEmail((string) ($order['customer_email'] ?? ''));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return null;
        }
        $addr = is_array($order['shipping_address'] ?? null) ? $order['shipping_address'] : [];
        $name = trim((string) ($order['customer_name'] ?? ($addr['name'] ?? ($order['attendee_name'] ?? ''))));
        $phone = trim((string) ($addr['phone'] ?? ($order['customer_phone'] ?? '')));
        $addresses = [];
        if ($addr) {
            $addresses[] = [
                'label' => 'Shipping',
                'name' => (string) ($addr['name'] ?? $name),
                'line1' => (string) ($addr['line1'] ?? ''),
                'line2' => (string) ($addr['line2'] ?? ''),
                'city' => (string) ($addr['city'] ?? ''),
                'region' => (string) ($addr['region'] ?? ($addr['state'] ?? '')),
                'postal' => (string) ($addr['postal'] ?? ($addr['postal_code'] ?? '')),
                'country' => (string) ($addr['country'] ?? ''),
                'phone' => $phone,
                'default' => true,
            ];
        }
        $payload = [
            'email' => $email,
            'name' => $name,
            'phone' => $phone,
            'addresses' => $addresses,
            'source' => 'order',
        ];
        // Prefer fill-empty merge for order-sourced upserts.
        $existing = $this->getByEmail($email);
        if ($existing) {
            return $this->update((string) $existing['id'], [
                'name' => $name !== '' && ($existing['name'] ?? '') === '' ? $name : ($existing['name'] ?? ''),
                'phone' => $phone !== '' && ($existing['phone'] ?? '') === '' ? $phone : ($existing['phone'] ?? ''),
                'addresses' => $this->mergeAddresses($existing['addresses'] ?? [], $addresses),
            ]);
        }
        return $this->upsert($payload);
    }

    /**
     * One-shot backfill from distinct order emails when the store is empty (or always if $force).
     *
     * @return array{created: int, skipped: int}
     */
    public function backfillFromOrders(CommerceOrderStore $orders, bool $force = false): array
    {
        if (!$force && $this->count() > 0) {
            return ['created' => 0, 'skipped' => 0];
        }
        $created = 0;
        $skipped = 0;
        $seen = [];
        foreach ($orders->listAll() as $order) {
            $email = self::normalizeEmail((string) ($order['customer_email'] ?? ''));
            if ($email === '' || isset($seen[$email])) {
                $skipped++;
                continue;
            }
            $seen[$email] = true;
            $before = $this->getByEmail($email);
            $this->ensureCustomerFromOrder($order);
            if (!$before) {
                $created++;
            } else {
                $skipped++;
            }
        }
        return ['created' => $created, 'skipped' => $skipped];
    }

    /**
     * Import customers from CSV text.
     * Required column: email. Password columns are ignored. Duplicates merge by email.
     *
     * @return array{created: int, updated: int, skipped: int, errors: list<string>}
     */
    public function importCsv(string $csv): array
    {
        $created = 0;
        $updated = 0;
        $skipped = 0;
        $errors = [];

        $csv = preg_replace('/^\xEF\xBB\xBF/', '', $csv) ?? $csv;
        $fh = fopen('php://temp', 'r+');
        if ($fh === false) {
            return ['created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => ['Unable to read CSV']];
        }
        fwrite($fh, $csv);
        rewind($fh);

        $header = fgetcsv($fh);
        if (!is_array($header) || !$header) {
            fclose($fh);
            return ['created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => ['CSV header row is required']];
        }
        $cols = [];
        foreach ($header as $i => $name) {
            $key = strtolower(trim((string) $name));
            $key = str_replace([' ', '-'], '_', $key);
            $cols[$i] = $key;
        }
        if (!in_array('email', $cols, true)) {
            fclose($fh);
            return ['created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => ['CSV must include an email column']];
        }

        $rowNum = 1;
        while (($row = fgetcsv($fh)) !== false) {
            $rowNum++;
            if (!is_array($row) || $this->rowIsEmpty($row)) {
                continue;
            }
            $mapped = [];
            foreach ($cols as $i => $key) {
                if ($key === '' || in_array($key, self::PASSWORD_COLUMNS, true)) {
                    continue;
                }
                $mapped[$key] = isset($row[$i]) ? trim((string) $row[$i]) : '';
            }
            $email = self::normalizeEmail((string) ($mapped['email'] ?? ''));
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Row {$rowNum}: invalid or missing email";
                $skipped++;
                continue;
            }

            $tags = $this->normalizeTags($mapped['tags'] ?? '');
            $addresses = [];
            $hasAddress = ($mapped['line1'] ?? '') !== ''
                || ($mapped['city'] ?? '') !== ''
                || ($mapped['country'] ?? '') !== ''
                || ($mapped['address_line1'] ?? '') !== '';
            if ($hasAddress) {
                $addresses[] = [
                    'label' => (string) ($mapped['address_label'] ?? ($mapped['label'] ?? 'Shipping')),
                    'name' => (string) ($mapped['address_name'] ?? ($mapped['name'] ?? '')),
                    'line1' => (string) ($mapped['line1'] ?? ($mapped['address_line1'] ?? '')),
                    'line2' => (string) ($mapped['line2'] ?? ($mapped['address_line2'] ?? '')),
                    'city' => (string) ($mapped['city'] ?? ''),
                    'region' => (string) ($mapped['region'] ?? ($mapped['state'] ?? '')),
                    'postal' => (string) ($mapped['postal'] ?? ($mapped['postal_code'] ?? ($mapped['zip'] ?? ''))),
                    'country' => (string) ($mapped['country'] ?? ''),
                    'phone' => (string) ($mapped['address_phone'] ?? ($mapped['phone'] ?? '')),
                    'default' => true,
                ];
            }

            $payload = [
                'email' => $email,
                'name' => (string) ($mapped['name'] ?? ''),
                'phone' => (string) ($mapped['phone'] ?? ''),
                'tags' => $tags,
                'notes' => (string) ($mapped['notes'] ?? ($mapped['note'] ?? '')),
                'addresses' => $addresses,
                'source' => 'import',
            ];

            try {
                $before = $this->getByEmail($email);
                if ($before) {
                    // Merge: fill empty scalar fields, union tags, merge addresses.
                    $patch = [
                        'name' => ($payload['name'] !== '' && ($before['name'] ?? '') === '') ? $payload['name'] : ($before['name'] ?? ''),
                        'phone' => ($payload['phone'] !== '' && ($before['phone'] ?? '') === '') ? $payload['phone'] : ($before['phone'] ?? ''),
                        'notes' => ($payload['notes'] !== '' && ($before['notes'] ?? '') === '') ? $payload['notes'] : ($before['notes'] ?? ''),
                        'tags' => array_values(array_unique(array_merge(
                            $this->normalizeTags($before['tags'] ?? []),
                            $tags
                        ))),
                        'addresses' => $this->mergeAddresses($before['addresses'] ?? [], $addresses),
                    ];
                    // If import provides non-empty name/phone/notes and existing empty — already handled.
                    // Also allow overwrite when import has values and we prefer merge-fill only (spec).
                    if ($payload['name'] !== '' && ($before['name'] ?? '') === '') {
                        $patch['name'] = $payload['name'];
                    }
                    if ($payload['phone'] !== '' && ($before['phone'] ?? '') === '') {
                        $patch['phone'] = $payload['phone'];
                    }
                    if ($payload['notes'] !== '' && ($before['notes'] ?? '') === '') {
                        $patch['notes'] = $payload['notes'];
                    }
                    $this->update((string) $before['id'], $patch);
                    $updated++;
                } else {
                    $this->upsert($payload);
                    $created++;
                }
            } catch (Throwable $e) {
                $errors[] = "Row {$rowNum}: " . $e->getMessage();
                $skipped++;
            }
        }
        fclose($fh);

        return [
            'created' => $created,
            'updated' => $updated,
            'skipped' => $skipped,
            'errors' => $errors,
        ];
    }

    /**
     * Resolve linked User Management user when plugin is active.
     *
     * @return array{user_id: ?string, user_name: ?string, user_email: ?string, admin_url: ?string, active: bool}
     */
    public function resolveUserManagementLink(array $customer): array
    {
        $result = [
            'user_id' => $customer['user_id'] ?? null,
            'user_name' => null,
            'user_email' => null,
            'admin_url' => null,
            'active' => false,
        ];
        if (!function_exists('birkly_is_plugin_active') || !birkly_is_plugin_active('user_management')) {
            return $result;
        }
        $result['active'] = true;

        $user = null;
        $email = self::normalizeEmail((string) ($customer['email'] ?? ''));
        $userId = $customer['user_id'] ?? null;

        try {
            if (function_exists('get_plugin_service')) {
                $service = get_plugin_service('user_service', false, 'commerce');
                if (is_object($service)) {
                    if ($userId && method_exists($service, 'getUser')) {
                        $user = $service->getUser((string) $userId);
                    }
                    if (!$user && $email !== '' && method_exists($service, 'getUserByEmail')) {
                        $user = $service->getUserByEmail($email);
                    }
                }
            }
            if (!$user && function_exists('birkly_plugin_require')
                && birkly_plugin_require('user_management', 'includes/UserStorage.php')
                && birkly_plugin_require('user_management', 'includes/UserService.php')) {
                $service = new UserService();
                if ($userId) {
                    $user = $service->getUser((string) $userId);
                }
                if (!$user && $email !== '') {
                    $user = $service->getUserByEmail($email);
                }
            }
        } catch (Throwable $e) {
            $user = null;
        }

        if (is_array($user) && !empty($user['id'])) {
            $result['user_id'] = (string) $user['id'];
            $result['user_name'] = $user['name'] ?? null;
            $result['user_email'] = $user['email'] ?? null;
            // Persist discovered link when missing.
            if (empty($customer['user_id'])) {
                try {
                    $this->update((string) $customer['id'], ['user_id' => $result['user_id']]);
                } catch (Throwable $e) {
                    // non-fatal
                }
            }
        }

        $query = http_build_query(array_filter([
            'page' => 'site_users',
            'q' => $email !== '' ? $email : null,
            'user_id' => $result['user_id'],
        ]));
        $path = '/admin/index.php?' . $query;
        $result['admin_url'] = function_exists('birkly_url') ? birkly_url($path) : $path;

        return $result;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalizeRecord(array $data): array
    {
        return [
            'id' => (string) ($data['id'] ?? ''),
            'email' => self::normalizeEmail((string) ($data['email'] ?? '')),
            'name' => trim((string) ($data['name'] ?? '')),
            'phone' => trim((string) ($data['phone'] ?? '')),
            'tags' => $this->normalizeTags($data['tags'] ?? []),
            'notes' => trim((string) ($data['notes'] ?? '')),
            'addresses' => $this->normalizeAddresses($data['addresses'] ?? []),
            'external_ids' => $this->normalizeExternalIds($data['external_ids'] ?? []),
            'user_id' => isset($data['user_id']) && $data['user_id'] !== '' && $data['user_id'] !== null
                ? (string) $data['user_id'] : null,
            'created_at' => (string) ($data['created_at'] ?? ''),
            'updated_at' => (string) ($data['updated_at'] ?? ''),
            'source' => $this->normalizeSource($data['source'] ?? 'manual'),
        ];
    }

    /**
     * @param array<string, mixed> $existing
     * @param array<string, mixed> $incoming
     * @return array<string, mixed>
     */
    private function mergeProfile(array $existing, array $incoming, bool $overwriteScalars): array
    {
        $record = $existing;
        foreach (['name', 'phone', 'notes'] as $field) {
            if (!array_key_exists($field, $incoming)) {
                continue;
            }
            $val = trim((string) $incoming[$field]);
            if ($overwriteScalars) {
                $record[$field] = $val;
            } elseif ($val !== '' && trim((string) ($record[$field] ?? '')) === '') {
                $record[$field] = $val;
            }
        }
        if (array_key_exists('email', $incoming)) {
            $record['email'] = self::normalizeEmail((string) $incoming['email']);
        }
        if (array_key_exists('tags', $incoming)) {
            if ($overwriteScalars) {
                $record['tags'] = $this->normalizeTags($incoming['tags']);
            } else {
                $record['tags'] = array_values(array_unique(array_merge(
                    $this->normalizeTags($existing['tags'] ?? []),
                    $this->normalizeTags($incoming['tags'])
                )));
            }
        }
        if (array_key_exists('addresses', $incoming)) {
            if ($overwriteScalars) {
                $record['addresses'] = $this->normalizeAddresses($incoming['addresses']);
            } else {
                $record['addresses'] = $this->mergeAddresses(
                    $existing['addresses'] ?? [],
                    $this->normalizeAddresses($incoming['addresses'])
                );
            }
        }
        if (array_key_exists('user_id', $incoming)) {
            $uid = $incoming['user_id'];
            $record['user_id'] = ($uid === null || $uid === '') ? null : (string) $uid;
        }
        if (array_key_exists('external_ids', $incoming)) {
            $record['external_ids'] = array_merge(
                $this->normalizeExternalIds($existing['external_ids'] ?? []),
                $this->normalizeExternalIds($incoming['external_ids'])
            );
        }
        if (array_key_exists('source', $incoming) && empty($existing['source'])) {
            $record['source'] = $this->normalizeSource($incoming['source']);
        }
        // Strip any accidental password keys.
        foreach (self::PASSWORD_COLUMNS as $bad) {
            unset($record[$bad], $incoming[$bad]);
        }
        return $record;
    }

    /**
     * @param mixed $tags
     * @return list<string>
     */
    private function normalizeTags($tags): array
    {
        if (is_string($tags)) {
            $tags = preg_split('/[,;|]/', $tags) ?: [];
        }
        if (!is_array($tags)) {
            return [];
        }
        $out = [];
        foreach ($tags as $tag) {
            $t = trim((string) $tag);
            if ($t !== '') {
                $out[] = $t;
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * @param mixed $addresses
     * @return list<array<string, mixed>>
     */
    private function normalizeAddresses($addresses): array
    {
        if (!is_array($addresses)) {
            return [];
        }
        $out = [];
        foreach ($addresses as $addr) {
            if (!is_array($addr)) {
                continue;
            }
            $line1 = trim((string) ($addr['line1'] ?? ''));
            $city = trim((string) ($addr['city'] ?? ''));
            $country = trim((string) ($addr['country'] ?? ''));
            if ($line1 === '' && $city === '' && $country === '' && trim((string) ($addr['name'] ?? '')) === '') {
                continue;
            }
            $out[] = [
                'id' => (string) ($addr['id'] ?? ('addr_' . bin2hex(random_bytes(4)))),
                'label' => trim((string) ($addr['label'] ?? 'Shipping')),
                'name' => trim((string) ($addr['name'] ?? '')),
                'line1' => $line1,
                'line2' => trim((string) ($addr['line2'] ?? '')),
                'city' => $city,
                'region' => trim((string) ($addr['region'] ?? '')),
                'postal' => trim((string) ($addr['postal'] ?? ($addr['postal_code'] ?? ''))),
                'country' => $country,
                'phone' => trim((string) ($addr['phone'] ?? '')),
                'default' => !empty($addr['default']),
            ];
        }
        if ($out && !array_filter($out, static fn ($a) => !empty($a['default']))) {
            $out[0]['default'] = true;
        }
        return $out;
    }

    /**
     * @param list<array<string, mixed>>|mixed $existing
     * @param list<array<string, mixed>> $incoming
     * @return list<array<string, mixed>>
     */
    private function mergeAddresses($existing, array $incoming): array
    {
        $base = $this->normalizeAddresses($existing);
        foreach ($incoming as $addr) {
            $key = strtolower(($addr['line1'] ?? '') . '|' . ($addr['postal'] ?? '') . '|' . ($addr['country'] ?? ''));
            $found = false;
            foreach ($base as $i => $ex) {
                $exKey = strtolower(($ex['line1'] ?? '') . '|' . ($ex['postal'] ?? '') . '|' . ($ex['country'] ?? ''));
                if ($key !== '||' && $key === $exKey) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $base[] = $addr;
            }
        }
        return $this->normalizeAddresses($base);
    }

    private function normalizeSource($source): string
    {
        $s = strtolower(trim((string) $source));
        return in_array($s, ['manual', 'import', 'order', 'shopify'], true) ? $s : 'manual';
    }

    /**
     * @param mixed $ids
     * @return array<string, string>
     */
    private function normalizeExternalIds($ids): array
    {
        if (!is_array($ids)) {
            return [];
        }
        $out = [];
        foreach ($ids as $key => $value) {
            $k = strtolower(trim((string) $key));
            $v = trim((string) $value);
            if ($k === '' || $v === '') {
                continue;
            }
            $out[$k] = $v;
        }
        return $out;
    }

    /** @param list<string|null> $row */
    private function rowIsEmpty(array $row): bool
    {
        foreach ($row as $cell) {
            if (trim((string) $cell) !== '') {
                return false;
            }
        }
        return true;
    }

    private function write(string $id, array $record): void
    {
        $safe = preg_replace('/[^a-zA-Z0-9_-]/', '', $id) ?? '';
        file_put_contents(
            $this->baseDir . '/' . $safe . '.json',
            json_encode($record, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
            LOCK_EX
        );
    }

    /** @template T @param callable():T $callback @return T */
    private function withLock(callable $callback)
    {
        $handle = fopen($this->lockFile, 'c');
        if ($handle === false) {
            throw new RuntimeException('Unable to open customer lock');
        }
        try {
            if (!flock($handle, LOCK_EX)) {
                throw new RuntimeException('Unable to acquire customer lock');
            }
            return $callback();
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }
}
