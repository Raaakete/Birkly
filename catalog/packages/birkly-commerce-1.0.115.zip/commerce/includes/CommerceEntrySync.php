<?php
/**
 * Write checkout metadata back to a CMS entry referenced by order metadata.
 */

declare(strict_types=1);

class CommerceEntrySync
{
    /**
     * @return array<string, string>
     */
    private static function fieldMap(): array
    {
        return [
            'entry_id_meta' => trim((string) commerce_get_setting('commerce_entry_sync_entry_id_meta', 'supporter_entry_id')),
            'collection_meta' => trim((string) commerce_get_setting('commerce_entry_sync_collection_meta', 'entry_collection')),
            'consent_meta' => trim((string) commerce_get_setting('commerce_entry_sync_consent_meta', 'featured')),
            'order_field' => trim((string) commerce_get_setting('commerce_entry_sync_order_field', 'order_id')),
            'payment_field' => trim((string) commerce_get_setting('commerce_entry_sync_payment_field', 'payment_status')),
            'session_field' => trim((string) commerce_get_setting('commerce_entry_sync_session_field', 'stripe_session')),
            'paid_value' => trim((string) commerce_get_setting('commerce_entry_sync_paid_value', 'paid')),
            'abandoned_value' => trim((string) commerce_get_setting('commerce_entry_sync_abandoned_value', 'abandoned')),
        ];
    }

    /**
     * @param array<string, mixed> $order
     * @return array{ok: bool, entry_id?: string, skipped?: bool, error?: string}
     */
    public static function syncFromPaidOrder(array $order): array
    {
        $map = self::fieldMap();
        $meta = self::orderEntrySyncMeta($order);
        $entryId = self::metaValue($meta, $order, $map['entry_id_meta']);
        $collection = self::metaValue($meta, $order, $map['collection_meta']);
        if ($entryId === '' || $collection === '') {
            return ['ok' => true, 'skipped' => true];
        }

        $dir = self::collectionEntriesDir($collection);
        if ($dir === null) {
            return ['ok' => false, 'error' => 'Collection not found: ' . $collection];
        }

        $path = $dir . '/' . $entryId . '.json';
        $entry = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
        if (!is_array($entry)) {
            return ['ok' => false, 'error' => 'Entry not found'];
        }

        $consent = self::truthy($meta[$map['consent_meta']] ?? false);
        $orderId = (string) ($order['id'] ?? '');
        $sessionId = trim((string) ($order['stripe_checkout_session_id'] ?? ''));
        if ($sessionId === '' && str_starts_with((string) ($order['payment_id'] ?? ''), 'cs_')) {
            $sessionId = (string) ($order['payment_id'] ?? '');
        }

        if ($map['order_field'] !== '') {
            $entry[$map['order_field']] = $orderId;
        }
        if ($map['session_field'] !== '') {
            $entry[$map['session_field']] = $sessionId;
        }
        if ($map['payment_field'] !== '') {
            $entry[$map['payment_field']] = $map['paid_value'] !== '' ? $map['paid_value'] : 'paid';
        }
        $entry['status'] = $consent ? 'published' : 'draft';
        $entry['updated_at'] = date('c');
        if (empty($entry['created_at'])) {
            $entry['created_at'] = date('c');
        }

        if (@file_put_contents($path, json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) === false) {
            return ['ok' => false, 'error' => 'Failed to write entry'];
        }

        return ['ok' => true, 'entry_id' => $entryId];
    }

    /**
     * @param array<string, mixed> $order
     * @return array{ok: bool, skipped?: bool, entry_id?: string, error?: string}
     */
    public static function markAbandonedFromOrder(array $order): array
    {
        $map = self::fieldMap();
        $meta = self::orderEntrySyncMeta($order);
        $entryId = self::metaValue($meta, $order, $map['entry_id_meta']);
        $collection = self::metaValue($meta, $order, $map['collection_meta']);
        if ($entryId === '' || $collection === '') {
            return ['ok' => true, 'skipped' => true];
        }

        $dir = self::collectionEntriesDir($collection);
        if ($dir === null) {
            return ['ok' => false, 'error' => 'Collection not found: ' . $collection];
        }

        $path = $dir . '/' . $entryId . '.json';
        if (!is_file($path)) {
            return ['ok' => true, 'skipped' => true];
        }
        $entry = json_decode((string) file_get_contents($path), true);
        if (!is_array($entry)) {
            return ['ok' => false, 'error' => 'Invalid entry'];
        }
        if ($map['payment_field'] !== '' && (string) ($entry[$map['payment_field']] ?? '') === ($map['paid_value'] !== '' ? $map['paid_value'] : 'paid')) {
            return ['ok' => true, 'skipped' => true];
        }

        if ($map['payment_field'] !== '') {
            $entry[$map['payment_field']] = $map['abandoned_value'] !== '' ? $map['abandoned_value'] : 'abandoned';
        }
        $entry['status'] = 'draft';
        $entry['updated_at'] = date('c');
        if (@file_put_contents($path, json_encode($entry, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) === false) {
            return ['ok' => false, 'error' => 'Failed to update entry'];
        }

        return ['ok' => true, 'entry_id' => $entryId];
    }

    /**
     * @param array<string, mixed> $order
     * @return array<string, mixed>
     */
    public static function orderEntrySyncMeta(array $order): array
    {
        $meta = is_array($order['entry_sync_meta'] ?? null) ? $order['entry_sync_meta'] : [];
        if ($meta === [] && is_array($order['donor_meta'] ?? null)) {
            $meta = $order['donor_meta'];
        }
        if ($meta === [] && is_array($order['metadata'] ?? null)) {
            $meta = $order['metadata'];
        }
        return $meta;
    }

    /**
     * @param array<string, mixed> $meta
     * @param array<string, mixed> $order
     */
    private static function metaValue(array $meta, array $order, string $key): string
    {
        if ($key === '') {
            return '';
        }
        $fromMeta = trim((string) ($meta[$key] ?? ''));
        if ($fromMeta !== '') {
            return $fromMeta;
        }
        return trim((string) ($order[$key] ?? ''));
    }

    private static function truthy(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        $s = strtolower(trim((string) $value));
        return in_array($s, ['1', 'true', 'yes', 'on', 'featured'], true);
    }

    private static function collectionEntriesDir(string $collection): ?string
    {
        if (!function_exists('commerce_cms_content_root')) {
            require_once dirname(__DIR__) . '/cms_paths.php';
        }
        $root = commerce_cms_content_root() . '/collections';
        if (!is_dir($root)) {
            return null;
        }
        foreach (scandir($root) ?: [] as $dir) {
            if ($dir === '.' || $dir === '..') {
                continue;
            }
            $metaPath = $root . '/' . $dir . '/collection.json';
            if (!is_file($metaPath)) {
                continue;
            }
            $meta = json_decode((string) file_get_contents($metaPath), true);
            if (!is_array($meta)) {
                continue;
            }
            if (($meta['slug'] ?? $dir) === $collection) {
                $entries = $root . '/' . $dir . '/entries';
                if (!is_dir($entries)) {
                    @mkdir($entries, 0775, true);
                }
                return is_dir($entries) ? $entries : null;
            }
        }
        $fallback = $root . '/' . $collection . '/entries';
        if (is_dir($fallback) || @mkdir($fallback, 0775, true)) {
            return $fallback;
        }
        return null;
    }
}
