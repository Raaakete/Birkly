<?php
/**
 * Stripe payment provider adapter.
 */

require_once __DIR__ . '/../AbstractProvider.php';

class StripeProvider extends AbstractPaymentProvider
{
    public function getId(): string { return 'stripe'; }
    public function getName(): string { return 'Stripe'; }

    public function getCapabilities(): array
    {
        return [
            'regions' => ['*'],
            'currencies' => ['usd', 'eur', 'gbp', 'jpy', 'aud', 'cad', 'sgd'],
            'methods' => ['card', 'apple_pay', 'google_pay', 'sepa_debit'],
            'features' => [
                'capture' => true,
                'refunds' => true,
                'subscriptions' => true,
                'webhooks' => true,
            ],
        ];
    }

    private function apiBase(array $credentials): string
    {
        return 'https://api.stripe.com/v1';
    }

    private function secret(array $credentials): string
    {
        return $credentials['secret_key'] ?? $credentials['api_key'] ?? '';
    }

    public function testConnection(array $credentials): array
    {
        if ($this->isMockMode($credentials)) {
            return ['ok' => true, 'message' => 'Mock connection successful'];
        }
        $resp = $this->httpRequest('GET', $this->apiBase($credentials) . '/balance', [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        return $resp['ok']
            ? ['ok' => true, 'message' => 'Stripe connection verified']
            : ['ok' => false, 'error' => $resp['error'] ?? 'Connection failed'];
    }

    public function createPayment(array $credentials, array $params): array
    {
        if ($this->isMockMode($credentials)) {
            return $this->mockPaymentResponse($params, $this->getId());
        }

        // Explicit hosted Checkout Session (marketing donations). Default remains PaymentIntent
        // + client_secret for Payment Element storefronts that also pass return_url.
        if (!empty($params['hosted_checkout'])) {
            return $this->createCheckoutSession($credentials, $params);
        }

        $fields = [
            'amount' => (int) ($params['amount_cents'] ?? 0),
            'currency' => strtolower($params['currency'] ?? 'usd'),
        ];
        // Prefer explicit card for Payment Element storefronts so Link does not
        // trap shoppers on a saved wallet they cannot edit. Opt into APM via params.
        if (!empty($params['automatic_payment_methods'])) {
            $fields['automatic_payment_methods[enabled]'] = 'true';
        } else {
            $types = $params['payment_method_types'] ?? ['card'];
            if (!is_array($types) || $types === []) {
                $types = ['card'];
            }
            foreach (array_values($types) as $i => $type) {
                $fields['payment_method_types[' . $i . ']'] = (string) $type;
            }
        }
        if (!empty($params['description'])) {
            $fields['description'] = $params['description'];
        }
        if (!empty($params['metadata']) && is_array($params['metadata'])) {
            foreach ($params['metadata'] as $k => $v) {
                $fields['metadata[' . $k . ']'] = (string) $v;
            }
        }

        $resp = $this->formRequest('POST', $this->apiBase($credentials) . '/payment_intents', $fields, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);

        if (!$resp['ok']) {
            return ['ok' => false, 'error' => $resp['error'] ?? 'Stripe payment failed'];
        }

        $data = $resp['data'];
        return [
            'ok' => true,
            'payment_id' => $data['id'] ?? null,
            'status' => $data['status'] ?? 'pending',
            'client_secret' => $data['client_secret'] ?? null,
            'raw' => $data,
        ];
    }

    /**
     * Stripe Checkout Session (hosted) — returns redirect_url for full-page pay.
     *
     * @param array<string, mixed> $credentials
     * @param array<string, mixed> $params
     * @return array<string, mixed>
     */
    private function createCheckoutSession(array $credentials, array $params): array
    {
        $amount = (int) ($params['amount_cents'] ?? 0);
        if ($amount < 1) {
            return ['ok' => false, 'error' => 'amount_cents required for Checkout Session'];
        }
        $currency = strtolower((string) ($params['currency'] ?? 'eur'));
        $success = (string) ($params['return_url'] ?? $params['success_url'] ?? '');
        $cancel = (string) ($params['cancel_url'] ?? $success);
        if ($success === '') {
            return ['ok' => false, 'error' => 'return_url required for hosted Checkout'];
        }
        // Stripe requires {CHECKOUT_SESSION_ID} for some flows; append if missing.
        if (strpos($success, '{CHECKOUT_SESSION_ID}') === false) {
            $success .= (strpos($success, '?') === false ? '?' : '&') . 'session_id={CHECKOUT_SESSION_ID}';
        }

        $productName = trim((string) ($params['product_name'] ?? $params['description'] ?? 'Payment'));
        if ($productName === '') {
            $productName = 'Payment';
        }

        $billing = strtolower((string) ($params['billing'] ?? 'one_time'));
        $mode = ($billing === 'recurring') ? 'subscription' : 'payment';

        $fields = [
            'mode' => $mode,
            'success_url' => $success,
            'cancel_url' => $cancel !== '' ? $cancel : $success,
            'line_items[0][quantity]' => 1,
            'line_items[0][price_data][currency]' => $currency,
            'line_items[0][price_data][unit_amount]' => $amount,
            'line_items[0][price_data][product_data][name]' => $productName,
        ];
        if ($mode === 'subscription') {
            $interval = strtolower((string) ($params['interval'] ?? 'month'));
            if (!in_array($interval, ['day', 'week', 'month', 'year'], true)) {
                $interval = 'month';
            }
            $fields['line_items[0][price_data][recurring][interval]'] = $interval;
        }
        $customerEmail = '';
        if (!empty($params['customer_email'])) {
            $customerEmail = (string) $params['customer_email'];
        } elseif (!empty($params['email'])) {
            $customerEmail = (string) $params['email'];
        }
        if ($customerEmail !== '') {
            $fields['customer_email'] = $customerEmail;
            // Stripe-hosted receipt for one-time Checkout (does not rely on CMS SMTP).
            if ($mode === 'payment') {
                $fields['payment_intent_data[receipt_email]'] = $customerEmail;
            }
        }
        // Hosted Checkout: omit payment_method_types to use Stripe Dashboard methods.
        // automatic_payment_methods is for PaymentIntents only — not Checkout Sessions.
        $disableLink = !array_key_exists('disable_link', $params) || !empty($params['disable_link']);
        $types = $params['payment_method_types'] ?? null;
        if (is_array($types) && $types !== []) {
            $types = array_values(array_filter(
                array_map('strval', $types),
                static fn(string $t): bool => $t !== '' && $t !== 'link'
            ));
            if ($types === []) {
                $types = ['card'];
            }
            foreach ($types as $i => $type) {
                $fields['payment_method_types[' . $i . ']'] = $type;
            }
            if ($disableLink) {
                $fields['wallet_options[link][display]'] = 'never';
            }
        } elseif (!empty($params['card_only'])) {
            $fields['payment_method_types[0]'] = 'card';
            if ($disableLink) {
                $fields['wallet_options[link][display]'] = 'never';
            }
        }
        if (!empty($params['metadata']) && is_array($params['metadata'])) {
            foreach ($params['metadata'] as $k => $v) {
                $fields['metadata[' . $k . ']'] = (string) $v;
                if ($mode === 'payment') {
                    $fields['payment_intent_data[metadata][' . $k . ']'] = (string) $v;
                } elseif ($mode === 'subscription') {
                    $fields['subscription_data[metadata][' . $k . ']'] = (string) $v;
                }
            }
        }

        $sessionOpts = [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ];
        if ($disableLink && isset($fields['payment_method_types[0]'])) {
            // wallet_options.link.display was added in 2025-04-30.basil
            $sessionOpts['headers'] = ['Stripe-Version: 2025-04-30.basil'];
        }
        $resp = $this->formRequest(
            'POST',
            $this->apiBase($credentials) . '/checkout/sessions',
            $fields,
            $sessionOpts
        );
        if (!$resp['ok']) {
            return ['ok' => false, 'error' => $resp['error'] ?? 'Stripe Checkout Session failed'];
        }
        $data = is_array($resp['data'] ?? null) ? $resp['data'] : [];
        $url = (string) ($data['url'] ?? '');
        if ($url === '') {
            return ['ok' => false, 'error' => 'Stripe Checkout Session missing url', 'raw' => $data];
        }
        return [
            'ok' => true,
            'payment_id' => $data['id'] ?? ($data['payment_intent'] ?? null),
            'status' => $data['status'] ?? 'open',
            'redirect_url' => $url,
            'client_secret' => $data['client_secret'] ?? null,
            'raw' => $data,
        ];
    }

    public function capturePayment(array $credentials, string $paymentId, array $params = []): array
    {
        if ($this->isMockMode($credentials)) {
            return ['ok' => true, 'status' => 'succeeded', 'payment_id' => $paymentId];
        }
        $target = $this->resolveRefundTarget($credentials, $paymentId);
        if (!($target['ok'] ?? false)) {
            return ['ok' => false, 'error' => $target['error'] ?? 'Could not resolve payment for capture'];
        }
        if (($target['field'] ?? '') !== 'payment_intent') {
            return ['ok' => false, 'error' => 'Capture requires a PaymentIntent reference'];
        }
        $intentId = (string) ($target['value'] ?? '');
        $resp = $this->formRequest('POST', $this->apiBase($credentials) . '/payment_intents/' . $intentId . '/capture', [], [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        return $resp['ok']
            ? ['ok' => true, 'status' => $resp['data']['status'] ?? 'succeeded', 'raw' => $resp['data']]
            : ['ok' => false, 'error' => $resp['error'] ?? 'Capture failed'];
    }

    public function refundPayment(array $credentials, string $paymentId, ?int $amountCents = null, array $params = []): array
    {
        if ($this->isMockMode($credentials)) {
            return ['ok' => true, 'status' => 'refunded', 'refund_id' => 'mock_refund_' . $paymentId];
        }
        $target = $this->resolveRefundTarget($credentials, $paymentId);
        if (!($target['ok'] ?? false)) {
            return ['ok' => false, 'error' => $target['error'] ?? 'Could not resolve payment for refund'];
        }
        $field = (string) ($target['field'] ?? 'payment_intent');
        $value = (string) ($target['value'] ?? '');
        if ($value === '') {
            return ['ok' => false, 'error' => 'Could not resolve payment for refund'];
        }
        $fields = [$field => $value];
        if ($amountCents !== null) {
            $fields['amount'] = $amountCents;
        }
        $resp = $this->formRequest('POST', $this->apiBase($credentials) . '/refunds', $fields, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        return $resp['ok']
            ? ['ok' => true, 'status' => 'refunded', 'refund_id' => $resp['data']['id'] ?? null, 'raw' => $resp['data']]
            : ['ok' => false, 'error' => $resp['error'] ?? 'Refund failed'];
    }

    public function getPaymentStatus(array $credentials, string $paymentId): array
    {
        if ($this->isMockMode($credentials)) {
            return ['ok' => true, 'status' => 'succeeded', 'payment_id' => $paymentId];
        }
        if (str_starts_with($paymentId, 'cs_')) {
            $resp = $this->httpRequest('GET', $this->apiBase($credentials) . '/checkout/sessions/' . $paymentId, [
                'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
            ]);
            if (!$resp['ok']) {
                return ['ok' => false, 'error' => $resp['error'] ?? 'Status check failed'];
            }
            $raw = strtolower((string) ($resp['data']['status'] ?? 'unknown'));
            $status = match ($raw) {
                'complete', 'completed' => 'succeeded',
                'expired' => 'canceled',
                'open' => 'open',
                default => (string) ($resp['data']['status'] ?? 'unknown'),
            };
            return [
                'ok' => true,
                'status' => $status,
                'payment_id' => $paymentId,
                'raw' => $resp['data'],
            ];
        }
        $resp = $this->httpRequest('GET', $this->apiBase($credentials) . '/payment_intents/' . $paymentId, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        return $resp['ok']
            ? ['ok' => true, 'status' => $resp['data']['status'] ?? 'unknown', 'raw' => $resp['data']]
            : ['ok' => false, 'error' => $resp['error'] ?? 'Status check failed'];
    }

    public function createSubscription(array $credentials, array $params): array
    {
        if ($this->isMockMode($credentials)) {
            $id = 'mock_sub_' . bin2hex(random_bytes(6));
            return ['ok' => true, 'subscription_id' => $id, 'status' => 'active'];
        }
        $fields = [
            'customer' => $params['customer_id'] ?? '',
            'items[0][price]' => $params['price_id'] ?? '',
        ];
        $resp = $this->formRequest('POST', $this->apiBase($credentials) . '/subscriptions', $fields, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        return $resp['ok']
            ? ['ok' => true, 'subscription_id' => $resp['data']['id'] ?? null, 'status' => $resp['data']['status'] ?? 'active', 'raw' => $resp['data']]
            : ['ok' => false, 'error' => $resp['error'] ?? 'Subscription failed'];
    }

    public function cancelSubscription(array $credentials, string $subscriptionId): array
    {
        if ($this->isMockMode($credentials)) {
            return ['ok' => true, 'status' => 'cancelled', 'subscription_id' => $subscriptionId];
        }
        $resp = $this->formRequest('DELETE', $this->apiBase($credentials) . '/subscriptions/' . $subscriptionId, [], [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        return $resp['ok']
            ? ['ok' => true, 'status' => 'cancelled', 'raw' => $resp['data']]
            : ['ok' => false, 'error' => $resp['error'] ?? 'Cancel failed'];
    }

    public function updateSubscription(array $credentials, string $subscriptionId, array $params): array
    {
        if ($this->isMockMode($credentials)) {
            if (!empty($params['pause'])) {
                return ['ok' => true, 'subscription_id' => $subscriptionId, 'status' => 'paused'];
            }
            if (!empty($params['resume'])) {
                return ['ok' => true, 'subscription_id' => $subscriptionId, 'status' => 'active'];
            }
            $interval = strtolower((string) ($params['interval'] ?? 'month'));
            $seconds = $this->intervalSeconds($interval);
            $amount = (int) ($params['amount_cents'] ?? 0);
            return [
                'ok' => true,
                'subscription_id' => $subscriptionId,
                'status' => 'active',
                'next_billing_at' => date('c', time() + $seconds),
                'proration_cents' => max(0, (int) round($amount * 0.1)),
            ];
        }

        if (!empty($params['pause'])) {
            $fields = ['pause_collection[behavior]' => $params['pause_behavior'] ?? 'void'];
            $resp = $this->formRequest('POST', $this->apiBase($credentials) . '/subscriptions/' . $subscriptionId, $fields, [
                'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
            ]);
            return $resp['ok']
                ? ['ok' => true, 'subscription_id' => $subscriptionId, 'status' => 'paused', 'raw' => $resp['data']]
                : ['ok' => false, 'error' => $resp['error'] ?? 'Pause failed'];
        }

        if (!empty($params['resume'])) {
            $resp = $this->formRequest('POST', $this->apiBase($credentials) . '/subscriptions/' . $subscriptionId, [
                'pause_collection' => '',
            ], [
                'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
            ]);
            return $resp['ok']
                ? ['ok' => true, 'subscription_id' => $subscriptionId, 'status' => 'active', 'raw' => $resp['data']]
                : ['ok' => false, 'error' => $resp['error'] ?? 'Resume failed'];
        }

        $priceId = $params['price_id'] ?? '';
        if ($priceId === '') {
            return ['ok' => false, 'error' => 'price_id required for Stripe subscription update'];
        }

        $fetch = $this->httpRequest('GET', $this->apiBase($credentials) . '/subscriptions/' . $subscriptionId, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        if (!$fetch['ok']) {
            return ['ok' => false, 'error' => $fetch['error'] ?? 'Failed to load subscription'];
        }

        $itemId = $fetch['data']['items']['data'][0]['id'] ?? '';
        if ($itemId === '') {
            return ['ok' => false, 'error' => 'Subscription has no line items'];
        }

        $fields = [
            'items[0][id]' => $itemId,
            'items[0][price]' => $priceId,
            'proration_behavior' => $params['proration_behavior'] ?? 'create_prorations',
        ];

        $resp = $this->formRequest('POST', $this->apiBase($credentials) . '/subscriptions/' . $subscriptionId, $fields, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);

        if (!$resp['ok']) {
            return ['ok' => false, 'error' => $resp['error'] ?? 'Subscription update failed'];
        }

        $data = $resp['data'];
        $periodEnd = $data['current_period_end'] ?? null;

        return [
            'ok' => true,
            'subscription_id' => $data['id'] ?? $subscriptionId,
            'status' => $data['status'] ?? 'active',
            'next_billing_at' => $periodEnd ? date('c', (int) $periodEnd) : null,
            'raw' => $data,
        ];
    }

    public function retrySubscriptionPayment(array $credentials, string $subscriptionId, array $params = []): array
    {
        if ($this->isMockMode($credentials)) {
            return ['ok' => true, 'status' => 'paid', 'subscription_id' => $subscriptionId];
        }

        $invoiceId = $params['invoice_id'] ?? '';
        if ($invoiceId === '') {
            $list = $this->httpRequest(
                'GET',
                $this->apiBase($credentials) . '/invoices?subscription=' . urlencode($subscriptionId) . '&status=open&limit=1',
                ['auth' => ['user' => $this->secret($credentials), 'pass' => '']]
            );
            if (!$list['ok']) {
                return ['ok' => false, 'error' => $list['error'] ?? 'Failed to list invoices'];
            }
            $invoiceId = $list['data']['data'][0]['id'] ?? '';
        }

        if ($invoiceId === '') {
            return ['ok' => false, 'error' => 'No open invoice found for subscription'];
        }

        $resp = $this->formRequest('POST', $this->apiBase($credentials) . '/invoices/' . $invoiceId . '/pay', [], [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);

        return $resp['ok']
            ? ['ok' => true, 'status' => 'paid', 'invoice_id' => $invoiceId, 'raw' => $resp['data']]
            : ['ok' => false, 'error' => $resp['error'] ?? 'Invoice payment retry failed'];
    }

    /**
     * Resolve a Checkout Session or PaymentIntent id to a Stripe refund/capture target.
     *
     * @return array{ok: bool, field?: string, value?: string, checkout_session_id?: string, error?: string}
     */
    private function resolveRefundTarget(array $credentials, string $paymentId): array
    {
        $paymentId = trim($paymentId);
        if ($paymentId === '') {
            return ['ok' => false, 'error' => 'payment_id required'];
        }
        if (str_starts_with($paymentId, 'pi_')) {
            return ['ok' => true, 'field' => 'payment_intent', 'value' => $paymentId];
        }
        if (str_starts_with($paymentId, 'ch_')) {
            return ['ok' => true, 'field' => 'charge', 'value' => $paymentId];
        }
        if (!str_starts_with($paymentId, 'cs_')) {
            return ['ok' => true, 'field' => 'payment_intent', 'value' => $paymentId];
        }

        $session = $this->fetchCheckoutSession($credentials, $paymentId);
        if (!($session['ok'] ?? false)) {
            return ['ok' => false, 'error' => $session['error'] ?? 'Failed to load checkout session'];
        }
        $data = is_array($session['data'] ?? null) ? $session['data'] : [];
        $intentId = $this->paymentIntentIdFromCheckoutSession($data);
        if ($intentId !== null) {
            return [
                'ok' => true,
                'field' => 'payment_intent',
                'value' => $intentId,
                'checkout_session_id' => $paymentId,
            ];
        }

        $invoiceId = $this->stripeObjectId($data['invoice'] ?? null);
        if ($invoiceId !== null) {
            $invoiceIntent = $this->paymentIntentIdFromInvoice($credentials, $invoiceId);
            if ($invoiceIntent !== null) {
                return [
                    'ok' => true,
                    'field' => 'payment_intent',
                    'value' => $invoiceIntent,
                    'checkout_session_id' => $paymentId,
                ];
            }
        }

        $subscriptionId = $this->stripeObjectId($data['subscription'] ?? null);
        if ($subscriptionId !== null) {
            $subscriptionIntent = $this->paymentIntentIdFromSubscription($credentials, $subscriptionId);
            if ($subscriptionIntent !== null) {
                return [
                    'ok' => true,
                    'field' => 'payment_intent',
                    'value' => $subscriptionIntent,
                    'checkout_session_id' => $paymentId,
                ];
            }
        }

        return ['ok' => false, 'error' => 'Checkout session has no refundable payment'];
    }

    /**
     * @return array{ok: bool, data?: array<string, mixed>, error?: string}
     */
    private function fetchCheckoutSession(array $credentials, string $sessionId): array
    {
        $resp = $this->httpRequest('GET', $this->apiBase($credentials) . '/checkout/sessions/' . $sessionId, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        if (!$resp['ok']) {
            return ['ok' => false, 'error' => $resp['error'] ?? 'Failed to load checkout session'];
        }
        return ['ok' => true, 'data' => is_array($resp['data'] ?? null) ? $resp['data'] : []];
    }

    /**
     * @param array<string, mixed> $session
     */
    private function paymentIntentIdFromCheckoutSession(array $session): ?string
    {
        $intentId = $this->stripeObjectId($session['payment_intent'] ?? null);
        if ($intentId !== null) {
            return $intentId;
        }
        return null;
    }

    /**
     * Resolve a Checkout Session or PaymentIntent id to a Stripe PaymentIntent id.
     */
    public function resolvePaymentIntentId(array $credentials, string $paymentId): ?string
    {
        $paymentId = trim($paymentId);
        if ($paymentId === '') {
            return null;
        }
        if (str_starts_with($paymentId, 'pi_')) {
            return $paymentId;
        }
        if (!str_starts_with($paymentId, 'cs_')) {
            return null;
        }

        $session = $this->fetchCheckoutSession($credentials, $paymentId);
        if (!($session['ok'] ?? false)) {
            return null;
        }
        $data = is_array($session['data'] ?? null) ? $session['data'] : [];
        $intentId = $this->paymentIntentIdFromCheckoutSession($data);
        if ($intentId !== null) {
            return $intentId;
        }
        $invoiceId = $this->stripeObjectId($data['invoice'] ?? null);
        if ($invoiceId !== null) {
            return $this->paymentIntentIdFromInvoice($credentials, $invoiceId);
        }
        $subscriptionId = $this->stripeObjectId($data['subscription'] ?? null);
        if ($subscriptionId !== null) {
            return $this->paymentIntentIdFromSubscription($credentials, $subscriptionId);
        }
        return null;
    }

    private function paymentIntentIdFromInvoice(array $credentials, string $invoiceId): ?string
    {
        $resp = $this->httpRequest('GET', $this->apiBase($credentials) . '/invoices/' . $invoiceId, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        if (!$resp['ok']) {
            return null;
        }
        $data = is_array($resp['data'] ?? null) ? $resp['data'] : [];
        return $this->stripeObjectId($data['payment_intent'] ?? null)
            ?? $this->stripeObjectId($data['charge'] ?? null);
    }

    private function paymentIntentIdFromSubscription(array $credentials, string $subscriptionId): ?string
    {
        $resp = $this->httpRequest('GET', $this->apiBase($credentials) . '/subscriptions/' . $subscriptionId, [
            'auth' => ['user' => $this->secret($credentials), 'pass' => ''],
        ]);
        if (!$resp['ok']) {
            return null;
        }
        $data = is_array($resp['data'] ?? null) ? $resp['data'] : [];
        $invoiceId = $this->stripeObjectId($data['latest_invoice'] ?? null);
        if ($invoiceId !== null) {
            return $this->paymentIntentIdFromInvoice($credentials, $invoiceId);
        }
        return $this->stripeObjectId($data['pending_setup_intent'] ?? null);
    }

    private function stripeObjectId(mixed $value): ?string
    {
        if (is_string($value) && $value !== '') {
            return $value;
        }
        if (is_array($value)) {
            $id = $value['id'] ?? '';
            if (is_string($id) && $id !== '') {
                return $id;
            }
        }
        return null;
    }

    private function intervalSeconds(string $interval): int
    {
        $map = [
            'day' => 86400,
            'week' => 604800,
            'month' => 2592000,
            'monthly' => 2592000,
            'year' => 31536000,
            'yearly' => 31536000,
            'annual' => 31536000,
        ];
        return $map[$interval] ?? 2592000;
    }

    public function verifyWebhookSignature(array $credentials, string $payload, array $headers): bool
    {
        if ($this->isMockMode($credentials)) {
            return ($this->getHeader($headers, 'X-Mock-Signature') === 'valid');
        }

        $secret = $credentials['webhook_secret'] ?? '';
        if ($secret === '') {
            return false;
        }

        $sigHeader = $this->getHeader($headers, 'Stripe-Signature');
        if (!$sigHeader) {
            return false;
        }

        $parts = [];
        foreach (explode(',', $sigHeader) as $item) {
            $kv = explode('=', trim($item), 2);
            if (count($kv) === 2) {
                $parts[$kv[0]] = $kv[1];
            }
        }

        $timestamp = $parts['t'] ?? '';
        $signature = $parts['v1'] ?? '';
        if ($timestamp === '' || $signature === '') {
            return false;
        }

        $signed = $timestamp . '.' . $payload;
        $expected = hash_hmac('sha256', $signed, $secret);
        return hash_equals($expected, $signature);
    }

    public function processWebhook(array $credentials, array $payload, array $headers): array
    {
        $type = $payload['type'] ?? '';
        $object = $payload['data']['object'] ?? [];
        $status = 'received';
        $paymentId = $object['id'] ?? null;
        $checkoutSessionId = null;

        if ($type === 'payment_intent.succeeded') {
            $status = 'succeeded';
        } elseif ($type === 'payment_intent.payment_failed') {
            $status = 'failed';
        } elseif ($type === 'checkout.session.completed') {
            $status = 'succeeded';
            $checkoutSessionId = is_string($object['id'] ?? null) ? (string) $object['id'] : null;
            $resolved = $this->paymentIntentIdFromCheckoutSession($object);
            $paymentId = $resolved ?? $checkoutSessionId ?? $paymentId;
        } elseif ($type === 'checkout.session.expired') {
            $status = 'canceled';
            $paymentId = $object['id'] ?? $paymentId;
        }

        $result = [
            'event_type' => $type,
            'status' => $status,
            'payment_id' => $paymentId,
            'amount_cents' => $object['amount'] ?? ($object['amount_total'] ?? null),
            'currency' => $object['currency'] ?? null,
            'provider' => $this->getId(),
            'message' => 'Stripe webhook: ' . $type,
        ];
        if ($type === 'checkout.session.completed' && !empty($checkoutSessionId)) {
            $result['checkout_session_id'] = $checkoutSessionId;
        }

        $subscription = $this->mapSubscriptionEvent($type, $object);
        if ($subscription !== null) {
            $result = array_merge($result, $subscription);
        }

        return $result;
    }

    /**
     * Normalize subscription lifecycle events to a common shape (P8-M4).
     * @return array{subscription_id: ?string, subscription_status: string}|null
     */
    private function mapSubscriptionEvent(string $type, array $object): ?array
    {
        switch ($type) {
            case 'customer.subscription.deleted':
                return [
                    'subscription_id' => $object['id'] ?? null,
                    'subscription_status' => 'canceled',
                ];
            case 'customer.subscription.updated':
                return [
                    'subscription_id' => $object['id'] ?? null,
                    'subscription_status' => $object['status'] ?? 'active',
                ];
            case 'invoice.payment_failed':
                return [
                    'subscription_id' => $object['subscription'] ?? null,
                    'subscription_status' => 'past_due',
                    'payment_failed' => true,
                    'attempt_count' => (int) ($object['attempt_count'] ?? 0),
                    'invoice_id' => $object['id'] ?? null,
                ];
            case 'invoice.paid':
            case 'invoice.payment_succeeded':
                return [
                    'subscription_id' => $object['subscription'] ?? null,
                    'subscription_status' => 'active',
                ];
            default:
                return null;
        }
    }
}
