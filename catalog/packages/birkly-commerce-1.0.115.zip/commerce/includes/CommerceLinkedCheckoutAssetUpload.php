<?php
/**
 * Public image upload for linked-checkout forms (pre-upload before begin_linked_checkout).
 */

declare(strict_types=1);

class CommerceLinkedCheckoutAssetUpload
{
    private const MAX_BYTES = 5_242_880; // 5MB

    /** @var list<string> */
    private const ALLOWED_MIME = [
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/gif',
    ];

    /**
     * @param array<string, mixed> $file $_FILES entry
     * @return array{ok: bool, url?: string, field?: string, error?: string}
     */
    public function upload(array $file, string $fieldName = 'file'): array
    {
        $field = $this->sanitizeFieldName($fieldName);
        if ($field === '') {
            return ['ok' => false, 'error' => 'Invalid field name'];
        }

        if (!$this->checkRateLimit()) {
            return ['ok' => false, 'error' => 'Too many uploads. Please try again shortly.'];
        }

        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'error' => 'Upload failed'];
        }
        $tmp = (string) ($file['tmp_name'] ?? '');
        $testUpload = !empty($GLOBALS['commerce_test_allow_upload']);
        if ($tmp === '' || (!$testUpload && !is_uploaded_file($tmp))) {
            return ['ok' => false, 'error' => 'Invalid upload'];
        }
        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0 || $size > self::MAX_BYTES) {
            return ['ok' => false, 'error' => 'File too large (max 5MB)'];
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? (string) finfo_file($finfo, $tmp) : '';
        if ($finfo) {
            finfo_close($finfo);
        }
        if (!in_array($mime, self::ALLOWED_MIME, true)) {
            return ['ok' => false, 'error' => 'Invalid file type (images only)'];
        }
        if (str_starts_with($mime, 'image/')) {
            $imageInfo = @getimagesize($tmp);
            if ($imageInfo === false) {
                return ['ok' => false, 'error' => 'Invalid image file'];
            }
        }

        $ext = match ($mime) {
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
            default => 'bin',
        };
        $filename = bin2hex(random_bytes(12)) . '.' . $ext;
        $dir = $this->mediaDir();
        if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
            return ['ok' => false, 'error' => 'Upload directory unavailable'];
        }
        $dest = $dir . '/' . $filename;
        $saved = $testUpload ? @copy($tmp, $dest) : move_uploaded_file($tmp, $dest);
        if (!$saved) {
            return ['ok' => false, 'error' => 'Failed to save file'];
        }

        return [
            'ok' => true,
            'field' => $field,
            'url' => '/media/linked_checkout/' . $filename,
        ];
    }

    private function sanitizeFieldName(string $name): string
    {
        $name = strtolower(trim($name));
        if ($name === '') {
            return '';
        }
        $name = preg_replace('/[^a-z0-9_]+/', '_', $name) ?? '';
        return trim($name, '_');
    }

    private function mediaDir(): string
    {
        require_once dirname(__DIR__) . '/cms_paths.php';
        return rtrim(commerce_cms_root(), '/') . '/media/linked_checkout';
    }

    private function checkRateLimit(): bool
    {
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $ratePath = commerce_cms_path('api/rate_limit.php');
        if (!is_file($ratePath)) {
            return true;
        }
        require_once $ratePath;
        if (!class_exists('RateLimiter')) {
            return true;
        }
        $limiter = new RateLimiter('commerce_linked_upload_' . $ip, 10, 60);
        return $limiter->check();
    }
}
