<?php
/**
 * Reads catalog index for cart pricing (v2 — purchase_option_id, shipping zones).
 */

class CommerceCatalog
{
    private CatalogIndexer $indexer;

    public function __construct(?CatalogIndexer $indexer = null)
    {
        $this->indexer = $indexer ?? new CatalogIndexer();
    }

    public function getItem(string $collectionSlug, string $entryId): ?array
    {
        $index = $this->indexer->loadIndex();
        $key = $collectionSlug . ':' . $entryId;
        return $index['entries'][$key] ?? null;
    }

    /**
     * Resolve a catalog row by entry id or slug, lazy-indexing CMS content when hooks were skipped.
     */
    public function resolveItem(string $collectionSlug, string $entryId): ?array
    {
        $item = $this->getItem($collectionSlug, $entryId);
        if ($item !== null) {
            return $item;
        }

        if ($this->lazyIndexEntry($collectionSlug, $entryId)) {
            $item = $this->getItem($collectionSlug, $entryId);
            if ($item !== null) {
                return $item;
            }
            foreach ($this->listItems(['collection' => $collectionSlug]) as $it) {
                if (($it['entry_slug'] ?? '') === $entryId || ($it['entry_id'] ?? '') === $entryId) {
                    $resolvedId = (string) ($it['entry_id'] ?? $entryId);
                    return $this->getItem($collectionSlug, $resolvedId) ?? $it;
                }
            }
        }

        return null;
    }

    private function lazyIndexEntry(string $collectionSlug, string $entryId): bool
    {
        require_once dirname(__DIR__) . '/cms_paths.php';
        if (!is_dir(commerce_cms_content_root() . '/collections')) {
            return false;
        }

        $contentRoot = commerce_cms_content_root();
        $roots = [$contentRoot];
        $legacy = dirname(__DIR__, 2) . '/../../content';
        if ($legacy !== $contentRoot && is_dir($legacy . '/collections')) {
            $roots[] = $legacy;
        }

        foreach ($roots as $root) {
            if (!is_dir($root . '/collections')) {
                continue;
            }
            require_once commerce_cms_path('core/storage/StorageFactory.php');
            require_once commerce_cms_path('core/public_read.php');
            $storage = StorageFactory::createStorage($root);
            $entry = null;
            if (function_exists('birkly_public_get_entry')) {
                $res = birkly_public_get_entry($storage, $collectionSlug, $entryId);
                if (($res['status'] ?? '') === 'ok') {
                    $entry = $res['data']['entry'] ?? $res['data'] ?? null;
                }
            }
            if (!$entry && function_exists('birkly_public_list_entries')) {
                $list = birkly_public_list_entries($storage, $collectionSlug);
                foreach (($list['data']['entries'] ?? []) as $row) {
                    if (($row['id'] ?? '') === $entryId || ($row['slug'] ?? '') === $entryId) {
                        $entry = $row;
                        break;
                    }
                }
            }
            if (is_array($entry) && !empty($entry['id'])) {
                $this->indexer->indexEntry($entry, $collectionSlug);
                return true;
            }
        }

        try {
            $this->indexer->reindexAll($contentRoot);
            return true;
        } catch (Throwable $e) {
            return false;
        }
    }

    public function listItems(array $filters = []): array
    {
        $index = $this->indexer->loadIndex();
        $items = array_values($index['entries'] ?? []);

        if (!empty($filters['collection'])) {
            $items = array_filter($items, fn ($i) => ($i['collection_slug'] ?? '') === $filters['collection']);
        }
        if (!empty($filters['billing'])) {
            $items = array_filter($items, fn ($i) => ($i['billing'] ?? '') === $filters['billing']);
        }
        if (!empty($filters['fulfillment'])) {
            $items = array_filter($items, fn ($i) => ($i['fulfillment'] ?? '') === $filters['fulfillment']);
        }
        if (isset($filters['low_stock']) && $filters['low_stock'] !== '') {
            $threshold = (int) $filters['low_stock'];
            $items = array_filter($items, function ($i) use ($threshold) {
                $qty = $i['quantity_available'] ?? null;
                return $qty !== null && (int) $qty <= $threshold;
            });
        }

        return array_values($items);
    }

    public function buildCartLines(array $cartItems, ?DiscountEngine $discounts = null, ?string $coupon = null, ?string $affiliateId = null): array
    {
        if (!class_exists('CommerceSchema')) {
            require_once __DIR__ . '/CommerceSchema.php';
        }
        if (!class_exists('CommerceBundleSchema')) {
            require_once __DIR__ . '/CommerceBundleSchema.php';
        }

        $lines = [];
        $totalCents = 0;
        $totalDiscount = 0;
        $currency = function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur';
        $discountEngine = $discounts ?? new DiscountEngine();
        $billingModes = [];
        $lineCurrencies = [];
        $errors = [];

        foreach ($cartItems as $item) {
            $collectionSlug = $item['collection'] ?? '';
            $entryId = $item['entry_id'] ?? '';
            $qty = max(1, (int) ($item['quantity'] ?? 1));
            $purchaseOptionId = $item['purchase_option_id'] ?? null;

            $catalogItem = $this->getItem($collectionSlug, $entryId);
            if (!$catalogItem) {
                $errors[] = 'Item not in catalog: ' . $collectionSlug . ':' . $entryId;
                continue;
            }

            if (!empty($catalogItem['is_bundle'])) {
                $bundleLine = $this->buildBundleCartLine($catalogItem, $collectionSlug, $entryId, $qty, $discountEngine, $coupon, $affiliateId);
                if ($bundleLine === null) {
                    $errors[] = 'Bundle unavailable: ' . ($catalogItem['entry_title'] ?? $entryId);
                    continue;
                }
                $billingModes[$bundleLine['billing'] ?? 'one_time'] = true;
                $currency = $bundleLine['currency'] ?: $currency;
                $lineCurrencies[strtolower((string) ($bundleLine['currency'] ?? $currency))] = true;
                $lines[] = $bundleLine;
                continue;
            }

            $qtyAvailable = $catalogItem['quantity_available'] ?? null;
            if ($qtyAvailable !== null && (int) $qtyAvailable < $qty) {
                $errors[] = 'Insufficient stock for ' . ($catalogItem['entry_title'] ?? $entryId);
                continue;
            }

            $commerce = commerce_normalize_value($catalogItem['commerce'] ?? $catalogItem);
            $option = CommerceSchema::findPurchaseOption($commerce, $purchaseOptionId);
            if (!$option) {
                $errors[] = 'Purchase option not available for ' . ($catalogItem['entry_title'] ?? $entryId);
                continue;
            }

            $requestedAmount = isset($item['amount_cents']) ? (int) $item['amount_cents'] : null;
            $resolved = CommerceSchema::resolveOptionAmountCents($option, $requestedAmount);
            if (!($resolved['ok'] ?? false)) {
                $errors[] = ($resolved['message'] ?? 'Invalid amount') . ' for ' . ($catalogItem['entry_title'] ?? $entryId);
                continue;
            }
            $baseUnit = (int) $resolved['amount_cents'];

            $billingModes[$option['billing'] ?? 'one_time'] = true;

            $lineCurrency = strtolower((string) ($option['currency'] ?? $currency));
            $lineCurrencies[$lineCurrency] = true;

            $lines[] = [
                'line_id' => $collectionSlug . ':' . $entryId . ':' . ($option['id'] ?? 'default')
                    . (($option['pricing_mode'] ?? 'fixed') === 'variable' ? (':' . $baseUnit) : ''),
                'entry_id' => $entryId,
                'parent_id' => $item['parent_id'] ?? ($catalogItem['parent_id'] ?? null),
                'collection_slug' => $collectionSlug,
                'entry_slug' => $catalogItem['entry_slug'] ?? $entryId,
                'title' => $catalogItem['entry_title'] ?? $catalogItem['entry_slug'] ?? $entryId,
                'sku' => $catalogItem['sku'] ?? $catalogItem['entry_slug'] ?? '',
                'quantity' => $qty,
                'purchase_option_id' => $option['id'] ?? 'default',
                'purchase_option_label' => $option['label'] ?? '',
                'pricing_mode' => $option['pricing_mode'] ?? 'fixed',
                'amount_cents' => $baseUnit,
                'fulfillment' => $commerce['fulfillment'] ?? 'ship',
                'tax_class' => CommerceSchema::normalizeTaxClass(
                    $commerce['tax_class'] ?? ($catalogItem['tax_class'] ?? null)
                ),
                'tax_included' => CommerceSchema::normalizeTaxIncluded(
                    array_key_exists('tax_included', $commerce)
                        ? $commerce['tax_included']
                        : ($catalogItem['tax_included'] ?? true)
                ),
                'weight_grams' => isset($commerce['weight_grams']) ? (int) $commerce['weight_grams'] : (int) ($catalogItem['weight_grams'] ?? 0),
                'length_mm' => isset($commerce['length_mm']) ? (int) $commerce['length_mm'] : (int) ($catalogItem['length_mm'] ?? 0),
                'width_mm' => isset($commerce['width_mm']) ? (int) $commerce['width_mm'] : (int) ($catalogItem['width_mm'] ?? 0),
                'height_mm' => isset($commerce['height_mm']) ? (int) $commerce['height_mm'] : (int) ($catalogItem['height_mm'] ?? 0),
                'commerce' => $commerce,
                'variant_attrs' => $catalogItem['variant_attrs'] ?? null,
                'base_unit_cents' => $baseUnit,
                'effective_unit_cents' => $baseUnit,
                'base_amount_cents' => $baseUnit * $qty,
                'discount_amount_cents' => 0,
                'effective_amount_cents' => $baseUnit * $qty,
                'line_total_cents' => $baseUnit * $qty,
                'unit_price_cents' => $baseUnit,
                'currency' => $lineCurrency,
                'billing' => $option['billing'] ?? 'one_time',
                'interval' => $option['interval'] ?? null,
            ];
            $currency = $lineCurrency ?: $currency;
        }

        if (count($lineCurrencies) > 1) {
            // Keep lines visible so the shopper can remove the conflicting item.
            return [
                'ok' => false,
                'error' => 'Cannot mix currencies in the same cart',
                'lines' => $lines,
                'groups' => $this->groupCartLines($lines),
                'total_cents' => 0,
                'shipping_cents' => 0,
                'discount_cents' => 0,
                'currency' => $currency,
                'checkout_allowed' => false,
                'warnings' => $errors,
            ];
        }

        if (!empty($errors) && empty($lines)) {
            return [
                'ok' => false,
                'error' => $errors[0],
                'lines' => [],
                'groups' => [],
                'total_cents' => 0,
                'shipping_cents' => 0,
                'discount_cents' => 0,
                'currency' => $currency,
                'checkout_allowed' => false,
                'warnings' => $errors,
            ];
        }

        // Estimate shipping before discount selection so free_shipping savings can compete.
        $shippingSnapshot = $this->calculateShippingSnapshot($lines);
        $shippingCents = (int) ($shippingSnapshot['shipping_cents'] ?? 0);
        $eval = $discountEngine->evaluateCart($lines, $coupon, $affiliateId, $shippingCents);
        $totalDiscount = 0;
        $totalCents = 0;
        foreach ($lines as $idx => &$line) {
            $lineDiscount = (int) ($eval['line_discounts'][$idx] ?? 0);
            $baseAmount = (int) ($line['base_amount_cents'] ?? 0);
            $qty = max(1, (int) ($line['quantity'] ?? 1));
            $lineDiscount = min($lineDiscount, $baseAmount);
            $lineTotal = max(0, $baseAmount - $lineDiscount);
            $effectiveUnit = (int) floor($lineTotal / $qty);
            $line['discount_amount_cents'] = $lineDiscount;
            $line['effective_amount_cents'] = $lineTotal;
            $line['line_total_cents'] = $lineTotal;
            $line['effective_unit_cents'] = $effectiveUnit;
            $line['unit_price_cents'] = $effectiveUnit;
            $totalDiscount += $lineDiscount;
            $totalCents += $lineTotal;
        }
        unset($line);

        // Threshold uses post-discount goods totals; promotions can still force free shipping.
        $shippingSnapshot = $this->applyFreeShippingThreshold($shippingSnapshot, $lines);
        $shippingCents = (int) ($shippingSnapshot['shipping_cents'] ?? 0);
        $freeShipping = !empty($eval['free_shipping']) || !empty($shippingSnapshot['free_shipping_unlocked']);
        if (!empty($eval['free_shipping'])) {
            $shippingCents = 0;
            $shippingSnapshot = [
                'shipping_cents' => 0,
                'shipping_lines' => [[
                    'id' => 'sl_free',
                    'title' => 'Free shipping',
                    'code' => 'free_shipping',
                    'price_cents' => 0,
                ]],
                'free_shipping_min_cents' => (int) ($shippingSnapshot['free_shipping_min_cents'] ?? 0),
                'free_shipping_remaining_cents' => 0,
                'free_shipping_unlocked' => true,
            ];
        }
        $totalCents += $shippingCents;
        $groups = $this->groupCartLines($lines);
        $allocations = $eval['allocations'] ?? [];
        if ($allocations === [] && $totalDiscount > 0) {
            $allocations = $this->buildDiscountAllocations($lines, $coupon, $affiliateId);
        }

        return [
            'ok' => true,
            'lines' => $lines,
            'groups' => $groups,
            'total_cents' => $totalCents,
            'shipping_cents' => $shippingCents,
            'shipping_lines' => $shippingSnapshot['shipping_lines'] ?? [],
            'discount_cents' => $totalDiscount,
            'discount_allocations' => $allocations,
            'free_shipping' => $freeShipping,
            'free_shipping_min_cents' => (int) ($shippingSnapshot['free_shipping_min_cents'] ?? $this->getFreeShippingMinCents()),
            'free_shipping_remaining_cents' => (int) ($shippingSnapshot['free_shipping_remaining_cents'] ?? 0),
            'free_shipping_unlocked' => !empty($shippingSnapshot['free_shipping_unlocked']) || !empty($eval['free_shipping']),
            'applied_rule_ids' => $eval['applied_rule_ids'] ?? [],
            'currency' => $currency,
            // Mixed one-time + subscription is allowed; checkout splits into groups.
            'checkout_allowed' => !empty($lines),
            'split_required' => count($groups) > 1,
            'warnings' => $errors,
        ];
    }

    /**
     * Split cart lines into checkout groups (billing mode + currency + interval).
     * One-time groups come first so physical goods/tax settle before subscriptions.
     *
     * @param array<int, array<string, mixed>> $lines
     * @return array<int, array<string, mixed>>
     */
    public function groupCartLines(array $lines): array
    {
        $buckets = [];
        foreach ($lines as $line) {
            $billing = (string) ($line['billing'] ?? 'one_time');
            if ($billing === '') {
                $billing = 'one_time';
            }
            $currency = strtolower((string) ($line['currency'] ?? 'eur'));
            $interval = $billing === 'recurring' ? (string) ($line['interval'] ?? 'month') : 'once';
            $key = $billing . ':' . $currency . ':' . $interval;
            if (!isset($buckets[$key])) {
                $buckets[$key] = [
                    'key' => $key,
                    'billing' => $billing,
                    'currency' => $currency,
                    'interval' => $billing === 'recurring' ? $interval : null,
                    'label' => $billing === 'recurring'
                        ? ('Subscription' . ($interval ? ' (' . $interval . ')' : ''))
                        : 'One-time items',
                    'lines' => [],
                    'total_cents' => 0,
                    'discount_cents' => 0,
                ];
            }
            $buckets[$key]['lines'][] = $line;
            $buckets[$key]['total_cents'] += (int) ($line['line_total_cents'] ?? 0);
            $buckets[$key]['discount_cents'] += (int) ($line['discount_amount_cents'] ?? 0);
        }

        $groups = array_values($buckets);
        usort($groups, static function (array $a, array $b): int {
            $rank = static function (array $g): int {
                return (($g['billing'] ?? '') === 'recurring') ? 1 : 0;
            };
            $cmp = $rank($a) <=> $rank($b);
            if ($cmp !== 0) {
                return $cmp;
            }
            return strcmp((string) ($a['key'] ?? ''), (string) ($b['key'] ?? ''));
        });

        foreach ($groups as $i => &$group) {
            $group['index'] = $i;
            $shippingSnapshot = $this->applyFreeShippingThreshold(
                $this->calculateShippingSnapshot($group['lines']),
                $group['lines']
            );
            $group['shipping_cents'] = (int) ($shippingSnapshot['shipping_cents'] ?? 0);
            $group['shipping_lines'] = $shippingSnapshot['shipping_lines'] ?? [];
            $group['free_shipping_unlocked'] = !empty($shippingSnapshot['free_shipping_unlocked']);
            $group['total_cents'] += (int) $group['shipping_cents'];
            $group['item_count'] = 0;
            foreach ($group['lines'] as $line) {
                $group['item_count'] += max(1, (int) ($line['quantity'] ?? 1));
            }
        }
        unset($group);

        return $groups;
    }

    /**
     * Shipping cents via the configured rate provider (manual zones or EasyPost).
     *
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context
     */
    public function calculateShipping(array $lines, ?array $shippingAddress = null, array $context = []): int
    {
        $snap = $this->calculateShippingSnapshot($lines, $shippingAddress, $context);
        if (($snap['ok'] ?? true) === false) {
            return 0;
        }
        return (int) ($snap['shipping_cents'] ?? 0);
    }

    /**
     * Quote shipping via the configured rate provider.
     *
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context selected_rate_id, credentials, force_mock, force_fail
     * @return array{
     *   shipping_cents: int,
     *   shipping_lines: array<int, array<string, mixed>>,
     *   rates?: array<int, array<string, mixed>>,
     *   provider?: string,
     *   ok?: bool,
     *   error?: string,
     *   fallback?: bool
     * }
     */
    public function calculateShippingSnapshot(array $lines, ?array $shippingAddress = null, array $context = []): array
    {
        if (!class_exists('ShippingRateProviderResolver')) {
            require_once __DIR__ . '/ShippingRateProviderResolver.php';
        }
        $resolver = new ShippingRateProviderResolver($this);
        $quote = $resolver->resolve()->quote($lines, $shippingAddress, $context);
        if (!isset($quote['shipping_lines']) || !is_array($quote['shipping_lines'])) {
            $quote['shipping_lines'] = [];
        }
        if (!isset($quote['shipping_cents'])) {
            $quote['shipping_cents'] = 0;
        }
        if (!isset($quote['rates']) || !is_array($quote['rates'])) {
            $quote['rates'] = [];
        }
        // Attach threshold metadata; callers with post-discount lines should re-apply.
        return $this->applyFreeShippingThreshold($quote, $lines);
    }

    /**
     * Free shipping when goods subtotal reaches the configured cart amount.
     * 0 / unset = disabled. Uses line_total_cents when present (post-discount), else base.
     *
     * @param array<string, mixed> $quote
     * @param array<int, array<string, mixed>> $lines
     * @return array<string, mixed>
     */
    public function applyFreeShippingThreshold(array $quote, array $lines): array
    {
        $min = $this->getFreeShippingMinCents();
        $goods = $this->goodsSubtotalCents($lines);
        $quote['free_shipping_min_cents'] = $min;
        $quote['free_shipping_remaining_cents'] = ($min > 0) ? max(0, $min - $goods) : 0;
        $quote['free_shipping_unlocked'] = false;

        if ($min <= 0 || !$this->cartHasShippableLines($lines)) {
            return $quote;
        }
        if ($goods < $min) {
            return $quote;
        }

        $quote['shipping_cents'] = 0;
        $quote['shipping_lines'] = [[
            'id' => 'sl_free_threshold',
            'title' => 'Free shipping',
            'code' => 'free_shipping_threshold',
            'price_cents' => 0,
            'source' => 'free_shipping_threshold',
        ]];
        $quote['free_shipping_unlocked'] = true;
        $quote['free_shipping_threshold'] = true;
        $quote['free_shipping_remaining_cents'] = 0;
        return $quote;
    }

    public function getFreeShippingMinCents(): int
    {
        $cfg = $this->loadShippingZones();
        return max(0, (int) ($cfg['free_shipping_min_cents'] ?? 0));
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     */
    public function goodsSubtotalCents(array $lines): int
    {
        $sum = 0;
        foreach ($lines as $line) {
            if (isset($line['line_total_cents'])) {
                $sum += (int) $line['line_total_cents'];
                continue;
            }
            if (isset($line['effective_amount_cents'])) {
                $sum += (int) $line['effective_amount_cents'];
                continue;
            }
            $base = (int) ($line['base_amount_cents'] ?? 0);
            if ($base > 0) {
                $sum += $base;
                continue;
            }
            $qty = max(1, (int) ($line['quantity'] ?? 1));
            $sum += (int) ($line['base_unit_cents'] ?? $line['amount_cents'] ?? $line['price_cents'] ?? 0) * $qty;
        }
        return max(0, $sum);
    }

    public function getShippingRateProviderId(): string
    {
        if (!class_exists('ShippingRateProviderResolver')) {
            require_once __DIR__ . '/ShippingRateProviderResolver.php';
        }
        return (new ShippingRateProviderResolver($this))->getProviderId();
    }

    public function cartHasShippableLines(array $lines): bool
    {
        foreach ($lines as $line) {
            if (($line['fulfillment'] ?? '') === 'ship') {
                return true;
            }
            if (!empty($line['is_bundle'])) {
                foreach ($line['components'] ?? [] as $comp) {
                    if (($comp['fulfillment'] ?? '') === 'ship') {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * When live rates are on, every shippable line must have weight_grams > 0.
     * @return string|null Error message or null when valid.
     */
    public function validateShippableWeights(array $lines): ?string
    {
        foreach ($lines as $line) {
            $title = (string) ($line['title'] ?? $line['entry_slug'] ?? 'item');
            if (($line['fulfillment'] ?? '') === 'ship') {
                $commerce = is_array($line['commerce'] ?? null) ? $line['commerce'] : [];
                $grams = (int) ($commerce['weight_grams'] ?? $line['weight_grams'] ?? 0);
                if ($grams <= 0) {
                    return 'Weight (grams) is required on shippable products when live shipping rates are enabled (missing on: ' . $title . ').';
                }
            }
            if (!empty($line['is_bundle'])) {
                foreach ($line['components'] ?? [] as $comp) {
                    if (($comp['fulfillment'] ?? '') !== 'ship') {
                        continue;
                    }
                    $commerce = is_array($comp['commerce'] ?? null) ? $comp['commerce'] : [];
                    $grams = (int) ($commerce['weight_grams'] ?? $comp['weight_grams'] ?? 0);
                    if ($grams <= 0) {
                        $compTitle = (string) ($comp['title'] ?? $title);
                        return 'Weight (grams) is required on shippable products when live shipping rates are enabled (missing on: ' . $compTitle . ').';
                    }
                }
            }
        }
        return null;
    }

    /** Manual zone/weight calculation (used by ManualShippingRateProvider and EasyPost fallback). */
    public function calculateShippingManualCents(array $lines, ?array $shippingAddress = null): int
    {
        if (!$this->cartHasShippableLines($lines)) {
            return 0;
        }

        $config = $this->loadShippingZones();
        $zones = $config['zones'] ?? [];
        if (empty($zones)) {
            return 0;
        }

        $country = strtoupper(trim((string) ($shippingAddress['country'] ?? '')));
        $totalWeight = $this->calculateCartWeightGrams($lines);
        foreach ($zones as $zone) {
            if (!is_array($zone)) {
                continue;
            }
            $countries = array_map('strtoupper', $zone['countries'] ?? ['*']);
            if (in_array('*', $countries, true) || ($country !== '' && in_array($country, $countries, true))) {
                return $this->resolveZoneRateCents($zone, $totalWeight);
            }
        }

        return $this->resolveZoneRateCents($zones[0], $totalWeight);
    }

    public function calculateCartWeightGrams(array $lines): int
    {
        $total = 0;
        foreach ($lines as $line) {
            $total += $this->lineWeightGrams($line);
            if (!empty($line['is_bundle'])) {
                foreach ($line['components'] ?? [] as $comp) {
                    $total += $this->lineWeightGrams($comp);
                }
            }
        }

        return max(0, $total);
    }

    /**
     * Sum outer dimensions across shippable lines (mm). Used for EasyPost parcels when set.
     *
     * @return array{length_mm: int, width_mm: int, height_mm: int}
     */
    public function calculateCartDimensionsMm(array $lines): array
    {
        $length = 0;
        $width = 0;
        $height = 0;
        foreach ($lines as $line) {
            $dims = $this->lineDimensionsMm($line);
            $length = max($length, $dims['length_mm']);
            $width = max($width, $dims['width_mm']);
            $height += $dims['height_mm'];
            if (!empty($line['is_bundle'])) {
                foreach ($line['components'] ?? [] as $comp) {
                    $cd = $this->lineDimensionsMm($comp);
                    $length = max($length, $cd['length_mm']);
                    $width = max($width, $cd['width_mm']);
                    $height += $cd['height_mm'];
                }
            }
        }
        return [
            'length_mm' => max(0, $length),
            'width_mm' => max(0, $width),
            'height_mm' => max(0, $height),
        ];
    }

    public function lineWeightGrams(array $line): int
    {
        if (($line['fulfillment'] ?? '') !== 'ship' && empty($line['is_bundle'])) {
            return 0;
        }
        $commerce = $line['commerce'] ?? [];
        $grams = (int) ($commerce['weight_grams'] ?? $line['weight_grams'] ?? 0);
        $qty = max(1, (int) ($line['quantity'] ?? 1));

        return max(0, $grams) * $qty;
    }

    /**
     * @return array{length_mm: int, width_mm: int, height_mm: int}
     */
    public function lineDimensionsMm(array $line): array
    {
        if (($line['fulfillment'] ?? '') !== 'ship' && empty($line['is_bundle'])) {
            return ['length_mm' => 0, 'width_mm' => 0, 'height_mm' => 0];
        }
        $commerce = is_array($line['commerce'] ?? null) ? $line['commerce'] : [];
        $qty = max(1, (int) ($line['quantity'] ?? 1));
        $length = (int) ($commerce['length_mm'] ?? $line['length_mm'] ?? 0);
        $width = (int) ($commerce['width_mm'] ?? $line['width_mm'] ?? 0);
        $height = (int) ($commerce['height_mm'] ?? $line['height_mm'] ?? 0);
        return [
            'length_mm' => max(0, $length),
            'width_mm' => max(0, $width),
            'height_mm' => max(0, $height) * $qty,
        ];
    }

    /** @param array<string, mixed> $zone */
    public function resolveZoneRateCents(array $zone, int $totalWeightGrams): int
    {
        $rateType = strtolower((string) ($zone['rate_type'] ?? 'flat'));
        if ($rateType === 'weight_tiers') {
            $tiers = is_array($zone['weight_tiers'] ?? null) ? $zone['weight_tiers'] : [];
            usort($tiers, function ($a, $b) {
                $aMax = $a['max_grams'] ?? null;
                $bMax = $b['max_grams'] ?? null;
                if ($aMax === null) {
                    return 1;
                }
                if ($bMax === null) {
                    return -1;
                }

                return (int) $aMax <=> (int) $bMax;
            });
            foreach ($tiers as $tier) {
                if (!is_array($tier)) {
                    continue;
                }
                $max = $tier['max_grams'] ?? null;
                if ($max === null || $max === '' || (int) $totalWeightGrams <= (int) $max) {
                    return max(0, (int) ($tier['rate_cents'] ?? 0));
                }
            }

            return max(0, (int) ($zone['flat_rate_cents'] ?? 0));
        }

        return max(0, (int) ($zone['flat_rate_cents'] ?? 0));
    }

    /**
     * @return array{
     *   provider: string,
     *   easypost_api_key: string,
     *   from_address: array<string, mixed>,
     *   free_shipping_min_cents: int,
     *   zones: array<int, array<string, mixed>>
     * }
     */
    public function loadShippingZones(): array
    {
        $zonesFile = dirname($this->indexer->getIndexPath()) . '/shipping_zones.json';
        if (!is_file($zonesFile) && function_exists('commerce_data_dir')) {
            $fallback = commerce_data_dir() . '/shipping_zones.json';
            if (is_file($fallback)) {
                $zonesFile = $fallback;
            }
        }
        if (!is_file($zonesFile)) {
            return $this->normalizeShippingConfig([]);
        }
        $data = json_decode((string) file_get_contents($zonesFile), true);
        return $this->normalizeShippingConfig(is_array($data) ? $data : []);
    }

    public function saveShippingZones(array $data): void
    {
        $dir = dirname($this->indexer->getIndexPath());
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $normalized = $this->normalizeShippingConfig($data);
        // Preserve existing API key when blank (edit-without-retype).
        $existing = [];
        $file = $dir . '/shipping_zones.json';
        if (is_file($file)) {
            $raw = json_decode((string) file_get_contents($file), true);
            if (is_array($raw)) {
                $existing = $raw;
            }
        }
        if (($normalized['easypost_api_key'] ?? '') === '' && !empty($existing['easypost_api_key'])) {
            $normalized['easypost_api_key'] = (string) $existing['easypost_api_key'];
        }
        file_put_contents($file, json_encode($normalized, JSON_PRETTY_PRINT));

        if (function_exists('set_plugin_setting')) {
            $pluginId = function_exists('commerce_active_plugin_id') ? commerce_active_plugin_id() : 'commerce';
            set_plugin_setting($pluginId, 'commerce_shipping_rate_provider', $normalized['provider']);
            if (($normalized['easypost_api_key'] ?? '') !== '') {
                set_plugin_setting($pluginId, 'commerce_easypost_api_key', $normalized['easypost_api_key']);
            }
        }
    }

    /**
     * @param array<string, mixed> $data
     * @return array{
     *   provider: string,
     *   easypost_api_key: string,
     *   from_address: array<string, mixed>,
     *   free_shipping_min_cents: int,
     *   zones: array<int, array<string, mixed>>
     * }
     */
    public function normalizeShippingConfig(array $data): array
    {
        if (!class_exists('ShippingRateProviderResolver')) {
            require_once __DIR__ . '/ShippingRateProviderResolver.php';
        }
        $zones = [];
        foreach (is_array($data['zones'] ?? null) ? $data['zones'] : [] as $zone) {
            if (is_array($zone)) {
                $zones[] = $zone;
            }
        }
        $from = is_array($data['from_address'] ?? null) ? $data['from_address'] : [];
        $freeMin = 0;
        if (array_key_exists('free_shipping_min_cents', $data)) {
            $freeMin = max(0, (int) $data['free_shipping_min_cents']);
        } elseif (is_array($data['free_shipping'] ?? null)) {
            $fs = $data['free_shipping'];
            if (!empty($fs['enabled'])) {
                $freeMin = max(0, (int) ($fs['min_subtotal_cents'] ?? $fs['min_purchase_cents'] ?? 0));
            }
        }
        return [
            'provider' => ShippingRateProviderResolver::normalizeProviderId($data['provider'] ?? ShippingRateProviderResolver::PROVIDER_MANUAL),
            'easypost_api_key' => trim((string) ($data['easypost_api_key'] ?? '')),
            'from_address' => [
                'name' => trim((string) ($from['name'] ?? '')),
                'street1' => trim((string) ($from['street1'] ?? ($from['line1'] ?? ''))),
                'city' => trim((string) ($from['city'] ?? '')),
                'state' => trim((string) ($from['state'] ?? '')),
                'zip' => trim((string) ($from['zip'] ?? ($from['postal_code'] ?? ''))),
                'country' => strtoupper(trim((string) ($from['country'] ?? ''))),
            ],
            'free_shipping_min_cents' => $freeMin,
            'zones' => $zones,
        ];
    }

    /**
     * Tax rules — default/country rates plus tax classes and class×country overrides.
     *
     * Resolution for a line: class_country_rates → class default_rate → country_rates → default_rate.
     * Class default_rate null means fall through (not zero).
     *
     * @return array{
     *   enabled: bool,
     *   provider: string,
     *   default_rate: float,
     *   country_rates: array<int, array{country: string, rate: float}>,
     *   classes: array<string, array{label: string, default_rate: float|null}>,
     *   class_country_rates: array<int, array{class: string, country: string, rate: float}>
     * }
     */
    public function loadTaxRules(): array
    {
        $file = dirname($this->indexer->getIndexPath()) . '/tax_rules.json';
        if (!is_file($file) && function_exists('commerce_data_dir')) {
            $file = commerce_data_dir() . '/tax_rules.json';
        }
        if (!is_file($file)) {
            return $this->normalizeTaxRules([]);
        }
        $data = json_decode((string) file_get_contents($file), true);
        if (!is_array($data)) {
            return $this->normalizeTaxRules([]);
        }
        return $this->normalizeTaxRules($data);
    }

    public function saveTaxRules(array $data): void
    {
        $dir = dirname($this->indexer->getIndexPath());
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $normalized = $this->normalizeTaxRules($data);
        file_put_contents($dir . '/tax_rules.json', json_encode($normalized, JSON_PRETTY_PRINT));

        // Mirror provider into plugin settings when CMS helpers exist.
        if (function_exists('set_plugin_setting')) {
            $pluginId = function_exists('commerce_active_plugin_id') ? commerce_active_plugin_id() : 'commerce';
            set_plugin_setting($pluginId, 'commerce_tax_provider', $normalized['provider']);
        }
    }

    /**
     * Default EU country list for simplified B2B reverse-charge eligibility (P2-M4).
     * Live VIES validation is out of scope for P2 — format/normalize only.
     *
     * @return list<string>
     */
    public static function defaultEuVatCountries(): array
    {
        return [
            'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU',
            'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE',
        ];
    }

    /**
     * Normalize a VAT / tax ID for storage and reverse-charge checks (no live VIES).
     */
    public function normalizeVatId(mixed $vatId): string
    {
        $raw = strtoupper(trim((string) $vatId));
        if ($raw === '') {
            return '';
        }
        // Strip common separators; keep alphanumeric only.
        $clean = preg_replace('/[^A-Z0-9]/', '', $raw);
        return is_string($clean) ? $clean : '';
    }

    /**
     * Optional light format check (country prefix + digits/letters). Not a VIES call.
     */
    public function looksLikeVatId(string $vatId): bool
    {
        $vatId = $this->normalizeVatId($vatId);
        if ($vatId === '') {
            return false;
        }
        return (bool) preg_match('/^[A-Z]{2}[A-Z0-9]{2,12}$/', $vatId);
    }

    /**
     * @param array<string, mixed> $data
     * @return array{
     *   enabled: bool,
     *   provider: string,
     *   default_rate: float,
     *   country_rates: array<int, array{country: string, rate: float}>,
     *   classes: array<string, array{label: string, default_rate: float|null}>,
     *   class_country_rates: array<int, array{class: string, country: string, rate: float}>,
     *   b2b_reverse_charge: array{
     *     enabled: bool,
     *     merchant_country: string,
     *     eligible_countries: list<string>,
     *     require_different_country: bool
     *   }
     * }
     */
    public function normalizeTaxRules(array $data): array
    {
        if (!class_exists('TaxProviderResolver')) {
            require_once __DIR__ . '/TaxProviderResolver.php';
        }
        $defaults = $this->defaultTaxClasses();
        $classesIn = is_array($data['classes'] ?? null) ? $data['classes'] : [];
        $classes = $defaults;
        foreach ($classesIn as $key => $meta) {
            if (is_int($key) && is_array($meta)) {
                $code = CommerceSchema::normalizeTaxClass($meta['code'] ?? ($meta['class'] ?? null));
            } else {
                $code = CommerceSchema::normalizeTaxClass($key);
                $meta = is_array($meta) ? $meta : [];
            }
            if ($code === '') {
                continue;
            }
            $defaultRate = $meta['default_rate'] ?? null;
            if ($defaultRate === '' || $defaultRate === false) {
                $defaultRate = null;
            } elseif ($defaultRate !== null) {
                $defaultRate = max(0.0, (float) $defaultRate);
            }
            $classes[$code] = [
                'label' => trim((string) ($meta['label'] ?? ucfirst($code))) ?: ucfirst($code),
                'default_rate' => $defaultRate,
            ];
        }

        $classCountry = [];
        foreach (is_array($data['class_country_rates'] ?? null) ? $data['class_country_rates'] : [] as $row) {
            if (!is_array($row)) {
                continue;
            }
            $class = CommerceSchema::normalizeTaxClass($row['class'] ?? null);
            $country = strtoupper(trim((string) ($row['country'] ?? '')));
            if ($class === '' || $country === '') {
                continue;
            }
            $classCountry[] = [
                'class' => $class,
                'country' => $country,
                'rate' => max(0.0, (float) ($row['rate'] ?? 0.0)),
            ];
        }

        $b2bIn = is_array($data['b2b_reverse_charge'] ?? null) ? $data['b2b_reverse_charge'] : [];
        $eligibleIn = is_array($b2bIn['eligible_countries'] ?? null) ? $b2bIn['eligible_countries'] : null;
        if ($eligibleIn === null || $eligibleIn === []) {
            $eligibleCountries = self::defaultEuVatCountries();
        } else {
            $eligibleCountries = [];
            foreach ($eligibleIn as $code) {
                $cc = strtoupper(trim((string) $code));
                if ($cc !== '' && preg_match('/^[A-Z]{2}$/', $cc) && !in_array($cc, $eligibleCountries, true)) {
                    $eligibleCountries[] = $cc;
                }
            }
            if ($eligibleCountries === []) {
                $eligibleCountries = self::defaultEuVatCountries();
            }
        }
        $merchantCountry = strtoupper(trim((string) ($b2bIn['merchant_country'] ?? '')));
        if ($merchantCountry !== '' && !preg_match('/^[A-Z]{2}$/', $merchantCountry)) {
            $merchantCountry = '';
        }

        return [
            'enabled' => (bool) ($data['enabled'] ?? false),
            'provider' => TaxProviderResolver::normalizeProviderId($data['provider'] ?? TaxProviderResolver::PROVIDER_MANUAL),
            'default_rate' => (float) ($data['default_rate'] ?? 0.0),
            'country_rates' => array_values(array_filter(array_map(function ($r) {
                $country = strtoupper(trim((string) ($r['country'] ?? '')));
                if ($country === '') {
                    return null;
                }
                return ['country' => $country, 'rate' => (float) ($r['rate'] ?? 0.0)];
            }, is_array($data['country_rates'] ?? null) ? $data['country_rates'] : []))),
            'classes' => $classes,
            'class_country_rates' => $classCountry,
            'b2b_reverse_charge' => [
                'enabled' => (bool) ($b2bIn['enabled'] ?? false),
                'merchant_country' => $merchantCountry,
                'eligible_countries' => $eligibleCountries,
                // Simplified EU-to-EU: customer ≠ merchant when both in eligible list.
                'require_different_country' => array_key_exists('require_different_country', $b2bIn)
                    ? (bool) $b2bIn['require_different_country']
                    : true,
            ],
        ];
    }

    /**
     * @return array<string, array{label: string, default_rate: float|null}>
     */
    public function defaultTaxClasses(): array
    {
        return [
            'standard' => ['label' => 'Standard', 'default_rate' => null],
            'reduced' => ['label' => 'Reduced', 'default_rate' => 7.0],
            'zero' => ['label' => 'Zero', 'default_rate' => 0.0],
        ];
    }

    /**
     * Resolve the applicable tax rate (percent) for a destination country (standard class).
     */
    public function resolveTaxRate(?string $country, ?array $rules = null): float
    {
        return $this->resolveTaxRateForClass('standard', $country, $rules);
    }

    /**
     * Resolution order: class×country → class default_rate → country_rates → default_rate.
     * Class default_rate null falls through; 0 is an explicit zero rate.
     */
    public function resolveTaxRateForClass(string $taxClass, ?string $country, ?array $rules = null): float
    {
        $rules = $rules ?? $this->loadTaxRules();
        if (empty($rules['enabled'])) {
            return 0.0;
        }
        $taxClass = CommerceSchema::normalizeTaxClass($taxClass);
        $country = strtoupper(trim((string) $country));

        if ($country !== '') {
            foreach ($rules['class_country_rates'] ?? [] as $entry) {
                if (($entry['class'] ?? '') === $taxClass && ($entry['country'] ?? '') === $country) {
                    return max(0.0, (float) ($entry['rate'] ?? 0.0));
                }
            }
        }

        $classMeta = $rules['classes'][$taxClass] ?? null;
        if (is_array($classMeta) && array_key_exists('default_rate', $classMeta) && $classMeta['default_rate'] !== null) {
            return max(0.0, (float) $classMeta['default_rate']);
        }

        if ($country !== '') {
            foreach ($rules['country_rates'] ?? [] as $entry) {
                if (($entry['country'] ?? '') === $country) {
                    return max(0.0, (float) ($entry['rate'] ?? 0.0));
                }
            }
        }

        return max(0.0, (float) ($rules['default_rate'] ?? 0.0));
    }

    /**
     * Compute tax for cart lines via the configured tax provider.
     * Tax base is post-discount goods subtotal; shipping excluded.
     * Thin facade — Manual / Stripe Tax providers produce the same tax_lines shape.
     * Inclusive prices extract VAT (tax_add_cents=0); exclusive prices add VAT.
     *
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context Optional: currency, vat_id/tax_id, billing_address, credentials
     * @return array{tax_cents: int, tax_add_cents?: int, rate: float, country: string, taxable_cents: int, tax_lines: array<int, array<string, mixed>>, provider?: string}
     */
    public function calculateTax(array $lines, ?array $shippingAddress = null, array $context = []): array
    {
        if (!class_exists('TaxProviderResolver')) {
            require_once __DIR__ . '/TaxProviderResolver.php';
        }
        $resolver = new TaxProviderResolver($this);
        return $resolver->resolve()->calculate($lines, $shippingAddress, $context);
    }

    /**
     * Estimate tax breakdown for a catalog item / commerce value (product page).
     *
     * @param array<string, mixed> $item Catalog row or commerce field value
     * @param array<string, mixed>|null $shippingAddress Country drives the rate (optional)
     * @param array<string, mixed> $context purchase_option_id, amount_cents, currency
     * @return array<string, mixed>
     */
    public function estimateItemTax(array $item, ?array $shippingAddress = null, array $context = []): array
    {
        if (!class_exists('CommerceSchema')) {
            require_once __DIR__ . '/CommerceSchema.php';
        }
        $commerce = commerce_normalize_value($item['commerce'] ?? $item);
        $optionId = isset($context['purchase_option_id']) ? (string) $context['purchase_option_id'] : null;
        $option = CommerceSchema::findPurchaseOption($commerce, $optionId !== '' ? $optionId : null);
        $requested = array_key_exists('amount_cents', $context) ? (int) $context['amount_cents'] : null;
        $resolved = $option
            ? CommerceSchema::resolveOptionAmountCents($option, $requested)
            : ['ok' => true, 'amount_cents' => (int) ($commerce['price_cents'] ?? 0)];
        $amount = (int) ($resolved['amount_cents'] ?? 0);
        $taxClass = CommerceSchema::normalizeTaxClass($commerce['tax_class'] ?? ($item['tax_class'] ?? null));
        $taxIncluded = CommerceSchema::normalizeTaxIncluded($commerce['tax_included'] ?? true);
        $currency = strtolower((string) (
            $context['currency']
            ?? ($option['currency'] ?? ($commerce['currency'] ?? ($item['currency'] ?? 'eur')))
        ));

        $line = [
            'line_total_cents' => $amount,
            'tax_class' => $taxClass,
            'tax_included' => $taxIncluded,
            'commerce' => $commerce,
        ];
        $tax = $this->calculateTax([$line], $shippingAddress, [
            'currency' => $currency,
        ]);
        $taxCents = (int) ($tax['tax_cents'] ?? 0);
        $taxAdd = CommerceSchema::taxAddCentsFromResult($tax);
        $net = $taxIncluded ? max(0, $amount - $taxCents) : $amount;
        $gross = $taxIncluded ? $amount : ($amount + $taxCents);

        return [
            'tax_class' => $taxClass,
            'tax_included' => $taxIncluded,
            'prices_include_tax' => $taxIncluded,
            'amount_cents' => $amount,
            'net_cents' => $net,
            'tax_cents' => $taxCents,
            'gross_cents' => $gross,
            'tax_add_cents' => $taxAdd,
            'rate' => (float) ($tax['rate'] ?? 0),
            'country' => (string) ($tax['country'] ?? ''),
            'tax_lines' => is_array($tax['tax_lines'] ?? null) ? $tax['tax_lines'] : [],
            'currency' => $currency,
            'provider' => $tax['provider'] ?? null,
        ];
    }

    /**
     * Storefront cart money quote: goods subtotal + shipping (+ tax when address/rules allow).
     * Does not mutate the cart session. Safe to call on every cart GET.
     *
     * @param array<string, mixed> $built from buildCartLines()
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $taxContext vat_id / tax_id / billing_address / currency
     * @return array<string, mixed>
     */
    public function enrichCartMoney(array $built, ?array $shippingAddress = null, array $taxContext = []): array
    {
        $lines = is_array($built['lines'] ?? null) ? $built['lines'] : [];
        $subtotal = 0;
        foreach ($lines as $line) {
            $subtotal += (int) ($line['line_total_cents'] ?? 0);
        }

        $shippingCents = (int) ($built['shipping_cents'] ?? 0);
        $shippingLines = is_array($built['shipping_lines'] ?? null) ? $built['shipping_lines'] : [];

        $snapMeta = [
            'free_shipping_min_cents' => $this->getFreeShippingMinCents(),
            'free_shipping_remaining_cents' => 0,
            'free_shipping_unlocked' => false,
        ];
        $hasShip = $this->cartHasShippableLines($lines);
        if ($hasShip) {
            $snap = $this->calculateShippingSnapshot($lines, $shippingAddress, [
                'currency' => $built['currency'] ?? null,
            ]);
            // Re-apply with post-discount line totals from the cart build.
            $snap = $this->applyFreeShippingThreshold($snap, $lines);
            if (($snap['ok'] ?? true) !== false) {
                $shippingCents = (int) ($snap['shipping_cents'] ?? 0);
                $shippingLines = $snap['shipping_lines'] ?? [];
            }
            $snapMeta = [
                'free_shipping_min_cents' => (int) ($snap['free_shipping_min_cents'] ?? 0),
                'free_shipping_remaining_cents' => (int) ($snap['free_shipping_remaining_cents'] ?? 0),
                'free_shipping_unlocked' => !empty($snap['free_shipping_unlocked']),
            ];
        } else {
            $shippingCents = 0;
            $shippingLines = [];
        }

        if (!empty($built['free_shipping'])) {
            $shippingCents = 0;
            $shippingLines = [[
                'id' => 'sl_free',
                'title' => 'Free shipping',
                'code' => 'free_shipping',
                'price_cents' => 0,
            ]];
            $snapMeta['free_shipping_unlocked'] = true;
            $snapMeta['free_shipping_remaining_cents'] = 0;
        }

        $taxContext = array_merge([
            'currency' => $built['currency'] ?? null,
        ], $taxContext);
        $tax = $this->calculateTax($lines, $shippingAddress, $taxContext);
        $taxCents = (int) ($tax['tax_cents'] ?? 0);
        $taxAddCents = CommerceSchema::taxAddCentsFromResult($tax);
        $taxLines = is_array($tax['tax_lines'] ?? null) ? $tax['tax_lines'] : [];

        $discount = (int) ($built['discount_cents'] ?? 0);
        $total = $subtotal + $shippingCents + $taxAddCents;

        $pricesIncludeTax = array_key_exists('prices_include_tax', $tax)
            ? (bool) $tax['prices_include_tax']
            : $this->cartLinesPricesIncludeTax($lines);

        return array_merge($built, [
            'subtotal_cents' => $subtotal,
            'shipping_cents' => $shippingCents,
            'shipping_lines' => $shippingLines,
            'tax_cents' => $taxCents,
            'tax_add_cents' => $taxAddCents,
            'tax_lines' => $taxLines,
            'tax_rate' => (float) ($tax['rate'] ?? 0),
            'tax_country' => (string) ($tax['country'] ?? ''),
            'tax_included' => $pricesIncludeTax,
            'prices_include_tax' => $pricesIncludeTax,
            'discount_cents' => $discount,
            'total_cents' => $total,
            'free_shipping' => !empty($built['free_shipping']) || !empty($snapMeta['free_shipping_unlocked']),
            'free_shipping_min_cents' => (int) $snapMeta['free_shipping_min_cents'],
            'free_shipping_remaining_cents' => (int) $snapMeta['free_shipping_remaining_cents'],
            'free_shipping_unlocked' => !empty($snapMeta['free_shipping_unlocked']),
            'quote_address' => is_array($shippingAddress) ? $shippingAddress : null,
        ]);
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     */
    private function cartLinesPricesIncludeTax(array $lines): bool
    {
        $saw = false;
        foreach ($lines as $line) {
            if ((int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0) <= 0) {
                continue;
            }
            $saw = true;
            if (!CommerceSchema::lineTaxIncluded($line)) {
                return false;
            }
        }
        return $saw;
    }

    /**
     * Resolve the active tax provider id (manual | stripe_tax).
     */
    public function getTaxProviderId(): string
    {
        if (!class_exists('TaxProviderResolver')) {
            require_once __DIR__ . '/TaxProviderResolver.php';
        }
        return (new TaxProviderResolver($this))->getProviderId();
    }

    /**
     * Collapse current line discounts into a persisted order-level allocation.
     *
     * @return array<int, array<string, mixed>>
     */
    public function buildDiscountAllocations(array $lines, ?string $coupon = null, ?string $affiliateId = null): array
    {
        $amount = 0;
        foreach ($lines as $line) {
            $amount += (int) ($line['discount_amount_cents'] ?? 0);
        }
        if ($amount <= 0) {
            return [];
        }

        $code = trim((string) ($coupon ?: $affiliateId ?: ''));
        $type = $coupon ? 'coupon' : ($affiliateId ? 'affiliate' : 'automatic');
        $basis = $type . '|' . $code . '|' . $amount;
        return [[
            'id' => 'da_' . substr(hash('sha256', $basis), 0, 12),
            'code' => $code,
            'type' => $type,
            'amount_cents' => $amount,
            'source' => 'discount_engine',
        ]];
    }

    private function buildBundleCartLine(
        array $catalogItem,
        string $collectionSlug,
        string $entryId,
        int $qty,
        DiscountEngine $discountEngine,
        ?string $coupon,
        ?string $affiliateId
    ): ?array {
        $bundle = commerce_bundle_normalize_value($catalogItem['bundle'] ?? []);
        if ($bundle['billing'] !== 'one_time') {
            return null;
        }

        $index = $this->indexer->loadIndex();
        $resolved = CommerceBundleSchema::resolveComponents($bundle, $index['entries'] ?? []);
        if (!$resolved['valid'] || empty($resolved['items'])) {
            return null;
        }

        $components = $resolved['items'];
        $baseUnit = CommerceBundleSchema::computePriceCents($bundle, $components);
        $quantityAvailable = CommerceBundleSchema::computeQuantityAvailable($bundle, $components);

        if ($quantityAvailable !== null && (int) $quantityAvailable < $qty) {
            return null;
        }
        // Discounts applied later via DiscountEngine::evaluateCart in buildCartLines.
        $effectiveUnit = $baseUnit;
        $lineDiscount = 0;
        $lineTotal = $effectiveUnit * $qty;

        $expandedComponents = [];
        foreach ($components as $comp) {
            if (!($comp['valid'] ?? false)) {
                return null;
            }
            $compQty = max(1, (int) ($comp['quantity'] ?? 1)) * $qty;
            $expandedComponents[] = [
                'collection' => $comp['collection'],
                'entry_id' => $comp['entry_id'],
                'quantity' => $compQty,
                'title' => $comp['title'] ?? $comp['entry_id'],
                'fulfillment' => $comp['fulfillment'] ?? 'ship',
                'commerce' => $comp['commerce'] ?? null,
                'purchase_option_id' => $comp['purchase_option_id'] ?? 'default',
            ];
        }

        // Inherit tax mode from first valid component (bundles have no own tax_class).
        $bundleTaxClass = 'standard';
        $bundleTaxIncluded = true;
        foreach ($components as $comp) {
            if (!($comp['valid'] ?? false)) {
                continue;
            }
            $compCommerce = commerce_normalize_value($comp['commerce'] ?? []);
            $bundleTaxClass = CommerceSchema::normalizeTaxClass($compCommerce['tax_class'] ?? null);
            $bundleTaxIncluded = CommerceSchema::normalizeTaxIncluded($compCommerce['tax_included'] ?? true);
            break;
        }

        return [
            'line_id' => $collectionSlug . ':' . $entryId . ':bundle',
            'entry_id' => $entryId,
            'collection_slug' => $collectionSlug,
            'entry_slug' => $catalogItem['entry_slug'] ?? $entryId,
            'title' => $catalogItem['entry_title'] ?? $entryId,
            'sku' => $catalogItem['sku'] ?? '',
            'quantity' => $qty,
            'purchase_option_id' => 'default',
            'purchase_option_label' => 'Bundle',
            'fulfillment' => $bundle['fulfillment'] ?? ($catalogItem['fulfillment'] ?? 'ship'),
            'tax_class' => $bundleTaxClass,
            'tax_included' => $bundleTaxIncluded,
            'commerce' => $bundle,
            'is_bundle' => true,
            'bundle' => $bundle,
            'components' => $expandedComponents,
            'base_unit_cents' => $baseUnit,
            'effective_unit_cents' => $effectiveUnit,
            'base_amount_cents' => $baseUnit * $qty,
            'discount_amount_cents' => $lineDiscount,
            'effective_amount_cents' => $lineTotal,
            'line_total_cents' => $lineTotal,
            'unit_price_cents' => $effectiveUnit,
            'currency' => $catalogItem['currency'] ?? 'eur',
            'billing' => 'one_time',
            'interval' => null,
        ];
    }
}
