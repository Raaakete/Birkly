<?php
/**
 * Durable stock reservations for pending Commerce orders.
 *
 * A reservation deducts stock immediately under one exclusive lock. Payment
 * success commits the hold; payment failure or timeout releases it.
 */

class StockReservationStore
{
    private string $file;
    private string $lockFile;
    private CatalogIndexer $indexer;
    private WarehouseStockStore $warehouse;
    private int $ttlSeconds;

    public function __construct(
        ?string $dataDir = null,
        ?CatalogIndexer $indexer = null,
        ?WarehouseStockStore $warehouse = null,
        int $ttlSeconds = 1800
    ) {
        $dir = $dataDir ?? commerce_data_dir();
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $this->file = rtrim($dir, '/') . '/stock_reservations.json';
        $this->lockFile = rtrim($dir, '/') . '/stock_reservations.lock';
        $this->indexer = $indexer ?? new CatalogIndexer($dir);
        $this->warehouse = $warehouse ?? new WarehouseStockStore($dir);
        $this->ttlSeconds = max(60, $ttlSeconds);

        if (!is_file($this->file)) {
            file_put_contents($this->file, json_encode(['reservations' => []], JSON_PRETTY_PRINT), LOCK_EX);
        }
    }

    /**
     * @param list<array<string, mixed>> $lines
     * @return array{ok: bool, reservation_id?: string, lines?: array, error?: string}
     */
    public function reserveLines(array $lines, string $orderId): array
    {
        $orderId = trim($orderId);
        if ($orderId === '') {
            return ['ok' => false, 'error' => 'Order id is required for stock reservation'];
        }

        $result = $this->withLock(function () use ($lines, $orderId): array {
            $data = $this->load();
            $this->releaseExpiredInPlace($data);

            $reservedLines = [];
            $heldAdditions = [];
            foreach ($lines as $line) {
                $line = is_array($line) ? $line : [];
                $result = $this->reserveLine($line, $data, $heldAdditions);
                if (!($result['ok'] ?? false)) {
                    foreach (array_reverse($reservedLines) as $reserved) {
                        $this->restoreLine($reserved);
                    }
                    $this->save($data);
                    return ['ok' => false, 'error' => $result['error'] ?? 'Insufficient stock'];
                }
                $reservedLines[] = $result['line'];
            }

            $reservationId = 'cres_' . bin2hex(random_bytes(8));
            $now = date('c');
            $data['reservations'][$reservationId] = [
                'id' => $reservationId,
                'order_id' => $orderId,
                'status' => 'reserved',
                'lines' => $reservedLines,
                'created_at' => $now,
                'updated_at' => $now,
                'expires_at' => date('c', time() + $this->ttlSeconds),
            ];
            $this->save($data);

            return ['ok' => true, 'reservation_id' => $reservationId, 'lines' => $reservedLines];
        });
        if (($result['ok'] ?? false) && !empty($result['lines']) && is_array($result['lines'])) {
            $this->ledger()->projectCatalogForSkus($this->lineSkus($result['lines']));
        }
        return $result;
    }

    public function commit(string $reservationId, string $orderId = ''): bool
    {
        $ok = $this->withLock(function () use ($reservationId, $orderId): bool {
            $data = $this->load();
            if (empty($data['reservations'][$reservationId])) {
                return false;
            }
            $reservation = $data['reservations'][$reservationId];
            if ($orderId !== '' && ($reservation['order_id'] ?? '') !== $orderId) {
                return false;
            }
            if (($reservation['status'] ?? '') !== 'reserved') {
                return in_array($reservation['status'] ?? '', ['committed'], true);
            }
            foreach ($reservation['lines'] ?? [] as $line) {
                if (is_array($line) && !$this->commitLineStock($line)) {
                    return false;
                }
            }
            $data['reservations'][$reservationId]['status'] = 'committed';
            $data['reservations'][$reservationId]['committed_at'] = date('c');
            $data['reservations'][$reservationId]['updated_at'] = date('c');
            $this->save($data);
            return true;
        });
        if ($ok) {
            $this->ledger()->projectCatalogForSkus(null);
        }
        return $ok;
    }

    public function release(string $reservationId, string $reason = 'released'): bool
    {
        $ok = $this->withLock(function () use ($reservationId, $reason): bool {
            $data = $this->load();
            if (empty($data['reservations'][$reservationId])) {
                return false;
            }
            $reservation = $data['reservations'][$reservationId];
            if (($reservation['status'] ?? '') !== 'reserved') {
                return false;
            }
            $lines = is_array($reservation['lines'] ?? null) ? $reservation['lines'] : [];
            foreach (array_reverse($lines) as $line) {
                if (is_array($line)) {
                    $this->restoreLine($line);
                }
            }
            $data['reservations'][$reservationId]['status'] = $reason === 'expired' ? 'expired' : 'released';
            $data['reservations'][$reservationId]['release_reason'] = $reason;
            $data['reservations'][$reservationId]['released_at'] = date('c');
            $data['reservations'][$reservationId]['updated_at'] = date('c');
            $this->save($data);
            return true;
        });
        if ($ok) {
            $this->ledger()->projectCatalogForSkus(null);
        }
        return $ok;
    }

    /**
     * @return array{by_sku: array<string, int>, by_sku_warehouse: array<string, array<string, int>>}
     */
    public function activeReservedBySku(): array
    {
        return $this->withLock(function (): array {
            $data = $this->load();
            $this->releaseExpiredInPlace($data);
            $this->save($data);
            return $this->sumActiveReserved($data);
        });
    }

    public function releaseExpired(): int
    {
        $changed = false;
        $count = $this->withLock(function () use (&$changed): int {
            $data = $this->load();
            $before = json_encode($data['reservations'] ?? []);
            $this->releaseExpiredInPlace($data);
            $after = json_encode($data['reservations'] ?? []);
            if ($before !== $after) {
                $this->save($data);
                $changed = true;
            }
            $count = 0;
            foreach ($data['reservations'] ?? [] as $reservation) {
                if (is_array($reservation) && ($reservation['status'] ?? '') === 'expired') {
                    $count++;
                }
            }
            return $count;
        });
        if ($changed) {
            $this->ledger()->projectCatalogForSkus(null);
        }
        return $count;
    }

    /** @return array<string, mixed>|null */
    public function get(string $reservationId): ?array
    {
        $data = $this->load();
        $reservation = $data['reservations'][$reservationId] ?? null;
        return is_array($reservation) ? $reservation : null;
    }

    /** @return array<string, mixed> */
    private function load(): array
    {
        $data = is_file($this->file) ? json_decode((string) file_get_contents($this->file), true) : [];
        if (!is_array($data)) {
            $data = [];
        }
        if (!isset($data['reservations']) || !is_array($data['reservations'])) {
            $data['reservations'] = [];
        }
        return $data;
    }

    /** @param array<string, mixed> $data */
    private function save(array $data): void
    {
        $data['updated_at'] = date('c');
        file_put_contents($this->file, json_encode($data, JSON_PRETTY_PRINT), LOCK_EX);
    }

    /**
     * Digital / membership lines do not hold warehouse stock. Physical ship and
     * register (capacity) lines still reserve when the SKU is tracked.
     */
    private function fulfillmentHoldsInventory(array $line): bool
    {
        $fulfillment = strtolower(trim((string) ($line['fulfillment'] ?? 'ship')));
        // Bundles expand components; hold only when a component needs inventory.
        if (!empty($line['is_bundle'])) {
            foreach ($line['components'] ?? [] as $component) {
                if (is_array($component) && $this->fulfillmentHoldsInventory($component)) {
                    return true;
                }
            }
            return false;
        }
        return in_array($fulfillment, ['ship', 'register'], true);
    }

    /** @return array{ok: bool, line?: array, error?: string} */
    private function reserveLine(array $line, array $data, array &$heldAdditions): array
    {
        $qty = max(1, (int) ($line['quantity'] ?? 1));
        $sku = trim((string) ($line['sku'] ?? ''));
        $ledger = $this->ledger();
        if ($ledger->isUnlimited()) {
            $line['stock_reserved'] = false;
            $line['stock_mutation'] = 'unlimited';
            return ['ok' => true, 'line' => $line];
        }

        // deliver / gift_card / none: never hold or double-decrement stock.
        if (!$this->fulfillmentHoldsInventory($line) && empty($line['is_bundle'])) {
            $line['stock_reserved'] = false;
            $line['stock_mutation'] = 'digital_skip';
            return ['ok' => true, 'line' => $line];
        }

        if ($sku !== '') {
            $ledger->ensureSimpleTrackedFromCatalog($sku);
        }
        if ($sku !== '' && $ledger->tracksSku($sku) && $this->fulfillmentHoldsInventory($line)) {
            $warehouseId = $ledger->isLocations()
                ? $this->allocateWarehouseFromData($sku, $qty, $data, $heldAdditions)
                : WarehouseStockStore::DEFAULT_WAREHOUSE_ID;
            if ($warehouseId === null) {
                return ['ok' => false, 'error' => 'Insufficient stock for ' . ($line['title'] ?? $sku)];
            }
            $available = $this->availableForSkuFromData($sku, $warehouseId, $data, $heldAdditions, $ledger->isLocations());
            if ($available !== null && $available < $qty) {
                return ['ok' => false, 'error' => 'Insufficient stock for ' . ($line['title'] ?? $sku)];
            }
            $line['warehouse_id'] = $warehouseId;
            $line['stock_reserved'] = true;
            $line['stock_mutation'] = 'hold_only';
            $this->addHeld($heldAdditions, $sku, $qty, $ledger->isLocations() ? $warehouseId : '*');
        } else {
            $line['stock_reserved'] = false;
            $line['stock_mutation'] = 'untracked';
        }

        $reservedComponents = [];
        if (!empty($line['is_bundle'])) {
            foreach ($line['components'] ?? [] as $component) {
                $component = is_array($component) ? $component : [];
                if (!$this->fulfillmentHoldsInventory($component)) {
                    $component['stock_reserved'] = false;
                    $component['stock_mutation'] = 'digital_skip';
                    $reservedComponents[] = $component;
                    continue;
                }
                $componentQty = max(1, (int) ($component['quantity'] ?? 1));
                $componentCollection = (string) ($component['collection'] ?? $component['collection_slug'] ?? '');
                $componentEntry = (string) ($component['entry_id'] ?? '');
                $componentSku = trim((string) ($component['sku'] ?? ''));
                if ($componentSku !== '') {
                    $ledger->ensureSimpleTrackedFromCatalog($componentSku);
                }
                if ($componentSku !== '' && $ledger->tracksSku($componentSku)) {
                    $componentWarehouse = $ledger->isLocations()
                        ? $this->allocateWarehouseFromData($componentSku, $componentQty, $data, $heldAdditions)
                        : WarehouseStockStore::DEFAULT_WAREHOUSE_ID;
                    $available = $componentWarehouse !== null
                        ? $this->availableForSkuFromData($componentSku, $componentWarehouse, $data, $heldAdditions, $ledger->isLocations())
                        : null;
                    if ($componentWarehouse === null || ($available !== null && $available < $componentQty)) {
                        return ['ok' => false, 'error' => 'Insufficient component stock for bundle'];
                    }
                    $component['warehouse_id'] = $componentWarehouse;
                    $component['stock_mutation'] = 'hold_only';
                    $this->addHeld($heldAdditions, $componentSku, $componentQty, $ledger->isLocations() ? $componentWarehouse : '*');
                } else {
                    $component['stock_mutation'] = 'untracked';
                }
                $component['stock_reserved'] = true;
                $reservedComponents[] = $component;
            }
            $line['components'] = $reservedComponents;
        }

        return ['ok' => true, 'line' => $line];
    }

    private function restoreLine(array $line): void
    {
        if (in_array((string) ($line['stock_mutation'] ?? ''), ['hold_only', 'unlimited', 'untracked', 'digital_skip'], true)) {
            return;
        }

        $qty = max(1, (int) ($line['quantity'] ?? 1));
        $sku = trim((string) ($line['sku'] ?? ''));
        if ($sku !== '' && ($line['warehouse_id'] ?? null)) {
            $this->warehouse->increment($sku, $qty, (string) $line['warehouse_id']);
        }

        $this->indexer->incrementQuantity(
            (string) ($line['collection_slug'] ?? $line['collection'] ?? ''),
            (string) ($line['entry_id'] ?? ''),
            $qty
        );

        if (!empty($line['is_bundle'])) {
            foreach ($line['components'] ?? [] as $component) {
                if (!is_array($component)) {
                    continue;
                }
                $this->indexer->incrementQuantity(
                    (string) ($component['collection'] ?? $component['collection_slug'] ?? ''),
                    (string) ($component['entry_id'] ?? ''),
                    max(1, (int) ($component['quantity'] ?? 1))
                );
            }
        }
    }

    /** @param array<string, mixed> $data */
    private function releaseExpiredInPlace(array &$data): void
    {
        $now = time();
        foreach ($data['reservations'] ?? [] as $id => $reservation) {
            if (!is_array($reservation) || ($reservation['status'] ?? '') !== 'reserved') {
                continue;
            }
            $expires = strtotime((string) ($reservation['expires_at'] ?? ''));
            if ($expires === false || $expires > $now) {
                continue;
            }
            foreach (array_reverse($reservation['lines'] ?? []) as $line) {
                if (is_array($line)) {
                    $this->restoreLine($line);
                }
            }
            $data['reservations'][$id]['status'] = 'expired';
            $data['reservations'][$id]['released_at'] = date('c');
            $data['reservations'][$id]['updated_at'] = date('c');
        }
    }

    private function commitLineStock(array $line): bool
    {
        if (($line['stock_mutation'] ?? '') === 'hold_only') {
            $sku = trim((string) ($line['sku'] ?? ''));
            if ($sku !== '' && !$this->warehouse->decrement($sku, max(1, (int) ($line['quantity'] ?? 1)), $line['warehouse_id'] ?? null)) {
                return false;
            }
        }
        if (!empty($line['is_bundle'])) {
            foreach ($line['components'] ?? [] as $component) {
                if (!is_array($component) || ($component['stock_mutation'] ?? '') !== 'hold_only') {
                    continue;
                }
                $componentSku = trim((string) ($component['sku'] ?? ''));
                if ($componentSku !== '' && !$this->warehouse->decrement(
                    $componentSku,
                    max(1, (int) ($component['quantity'] ?? 1)),
                    $component['warehouse_id'] ?? null
                )) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * @return array{by_sku: array<string, int>, by_sku_warehouse: array<string, array<string, int>>}
     */
    private function sumActiveReserved(array $data): array
    {
        $out = ['by_sku' => [], 'by_sku_warehouse' => []];
        foreach ($data['reservations'] ?? [] as $reservation) {
            if (!is_array($reservation) || ($reservation['status'] ?? '') !== 'reserved') {
                continue;
            }
            foreach ($reservation['lines'] ?? [] as $line) {
                if (!is_array($line)) {
                    continue;
                }
                $this->addReservedLine($out, $line);
                foreach (($line['components'] ?? []) as $component) {
                    if (is_array($component)) {
                        $this->addReservedLine($out, $component);
                    }
                }
            }
        }
        return $out;
    }

    /** @param array{by_sku: array<string, int>, by_sku_warehouse: array<string, array<string, int>>} $out */
    private function addReservedLine(array &$out, array $line): void
    {
        if (($line['stock_mutation'] ?? '') !== 'hold_only') {
            return;
        }
        $sku = strtoupper(trim((string) ($line['sku'] ?? '')));
        if ($sku === '') {
            return;
        }
        $qty = max(1, (int) ($line['quantity'] ?? 1));
        $warehouseId = (string) ($line['warehouse_id'] ?? WarehouseStockStore::DEFAULT_WAREHOUSE_ID);
        $out['by_sku'][$sku] = (int) ($out['by_sku'][$sku] ?? 0) + $qty;
        if (!isset($out['by_sku_warehouse'][$sku])) {
            $out['by_sku_warehouse'][$sku] = [];
        }
        $out['by_sku_warehouse'][$sku][$warehouseId] = (int) ($out['by_sku_warehouse'][$sku][$warehouseId] ?? 0) + $qty;
    }

    private function addHeld(array &$heldAdditions, string $sku, int $qty, string $warehouseId): void
    {
        $sku = strtoupper(trim($sku));
        if ($sku === '') {
            return;
        }
        if (!isset($heldAdditions[$sku])) {
            $heldAdditions[$sku] = [];
        }
        $heldAdditions[$sku][$warehouseId] = (int) ($heldAdditions[$sku][$warehouseId] ?? 0) + max(1, $qty);
    }

    private function availableForSkuFromData(string $sku, string $warehouseId, array $data, array $heldAdditions, bool $locations): ?int
    {
        $sku = strtoupper(trim($sku));
        if ($sku === '') {
            return null;
        }
        $reserved = $this->sumActiveReserved($data);
        if ($locations) {
            $row = $this->warehouse->getBySku($sku, $warehouseId);
            if ($row === null) {
                return null;
            }
            $held = (int) ($reserved['by_sku_warehouse'][$sku][$warehouseId] ?? 0)
                + (int) ($heldAdditions[$sku][$warehouseId] ?? 0);
            return max(0, (int) ($row['quantity_on_hand'] ?? 0) - $held);
        }

        $row = $this->warehouse->getBySku($sku);
        if ($row === null) {
            return null;
        }
        $held = (int) ($reserved['by_sku'][$sku] ?? 0) + (int) ($heldAdditions[$sku]['*'] ?? 0);
        return max(0, (int) ($row['quantity_on_hand'] ?? 0) - $held);
    }

    private function allocateWarehouseFromData(string $sku, int $qty, array $data, array $heldAdditions): ?string
    {
        $qty = max(1, $qty);
        foreach ($this->warehouse->listWarehouses() as $warehouse) {
            $warehouseId = (string) ($warehouse['id'] ?? '');
            if ($warehouseId === '') {
                continue;
            }
            $available = $this->availableForSkuFromData($sku, $warehouseId, $data, $heldAdditions, true);
            if ($available !== null && $available >= $qty) {
                return $warehouseId;
            }
        }
        return null;
    }

    /** @param array<int, array<string, mixed>> $lines @return array<int, string> */
    private function lineSkus(array $lines): array
    {
        $skus = [];
        foreach ($lines as $line) {
            if (!is_array($line)) {
                continue;
            }
            $sku = strtoupper(trim((string) ($line['sku'] ?? '')));
            if ($sku !== '') {
                $skus[$sku] = $sku;
            }
            foreach (($line['components'] ?? []) as $component) {
                if (!is_array($component)) {
                    continue;
                }
                $componentSku = strtoupper(trim((string) ($component['sku'] ?? '')));
                if ($componentSku !== '') {
                    $skus[$componentSku] = $componentSku;
                }
            }
        }
        return array_values($skus);
    }

    private function ledger(): InventoryLedger
    {
        if (!class_exists('InventoryLedger')) {
            require_once __DIR__ . '/InventoryLedger.php';
        }
        return new InventoryLedger(dirname($this->file), $this->indexer, $this->warehouse, $this);
    }

    /** @template T @param callable():T $callback @return T */
    private function withLock(callable $callback)
    {
        $handle = fopen($this->lockFile, 'c');
        if ($handle === false) {
            throw new RuntimeException('Unable to open Commerce stock reservation lock');
        }
        try {
            if (!flock($handle, LOCK_EX)) {
                throw new RuntimeException('Unable to acquire Commerce stock reservation lock');
            }
            return $callback();
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }
}
