<?php
/**
 * Transactional Commerce email templates with merge tokens.
 *
 * Immediate triggers send on the event request path.
 * Delayed triggers (review request, after paid/shipped) are queued and swept hourly.
 * Delivery routes through the central Birkly mail pipeline
 * (birkly_send_mail / birkly_notify). When the pipeline is absent,
 * the message is logged locally with an honest not-delivered status.
 *
 * Enabling a template does NOT deliver mail. A healthy Email connection
 * under Settings → Connections is required for inbox delivery.
 */

class CommerceEmailService
{
    private string $dataDir;

    public const TRIGGERS = [
        'order_paid',
        'donation_thanks',
        'order_shipped',
        'order_refunded',
        'order_canceled',
        'subscription_payment_failed',
        'order_review_request',
        'after_order_shipped',
        'after_order_paid',
    ];

    /** Delayed trigger => anchor event that schedules it */
    public const DELAY_ANCHORS = [
        'order_review_request' => 'order_shipped',
        'after_order_shipped' => 'order_shipped',
        'after_order_paid' => 'order_paid',
    ];

    public function __construct(?string $dataDir = null)
    {
        $this->dataDir = rtrim($dataDir ?? commerce_data_dir(), '/');
        if (!is_dir($this->dataDir)) {
            mkdir($this->dataDir, 0755, true);
        }
    }

    public function templatesPath(): string
    {
        return $this->dataDir . '/email_templates.json';
    }

    public function logPath(): string
    {
        return $this->dataDir . '/email_log.json';
    }

    public function schedulePath(): string
    {
        return $this->dataDir . '/email_scheduled.json';
    }

    public function deliverySettingsPath(): string
    {
        return $this->dataDir . '/email_delivery.json';
    }

    /**
     * @return array{email_connection_alias: string}
     */
    public function getDeliverySettings(): array
    {
        $path = $this->deliverySettingsPath();
        if (!is_file($path)) {
            return ['email_connection_alias' => ''];
        }
        $raw = file_get_contents($path);
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data)) {
            return ['email_connection_alias' => ''];
        }

        return [
            'email_connection_alias' => trim((string) ($data['email_connection_alias'] ?? '')),
        ];
    }

    /**
     * @param array<string, mixed> $settings
     * @return array{email_connection_alias: string, updated_at?: string}
     */
    public function saveDeliverySettings(array $settings): array
    {
        $payload = [
            'email_connection_alias' => trim((string) ($settings['email_connection_alias'] ?? '')),
            'updated_at' => date('c'),
        ];
        file_put_contents($this->deliverySettingsPath(), json_encode($payload, JSON_PRETTY_PRINT));

        return $payload;
    }

    public function resolveEmailConnectionAlias(?array $tpl = null): ?string
    {
        $configured = '';
        if (is_array($tpl)) {
            $configured = trim((string) ($tpl['email_connection_alias'] ?? ''));
        }
        if ($configured === '') {
            $configured = $this->getDeliverySettings()['email_connection_alias'] ?? '';
        }
        if (!empty($GLOBALS['commerce_test_passthrough_email_alias'])) {
            return $configured !== '' ? $configured : null;
        }
        if (function_exists('birkly_resolve_email_connection_alias')) {
            return birkly_resolve_email_connection_alias($configured);
        }

        return $configured !== '' ? $configured : null;
    }

    /**
     * @return list<string>
     */
    public static function attachmentOptions(): array
    {
        return ['invoice', 'packing_slip', 'shipping_label'];
    }

    public static function isDelayedTrigger(string $trigger): bool
    {
        return isset(self::DELAY_ANCHORS[$trigger]);
    }

    public static function delayAnchorFor(string $trigger): ?string
    {
        return self::DELAY_ANCHORS[$trigger] ?? null;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function defaultTemplates(): array
    {
        return [
            [
                'id' => 'tpl_order_paid',
                'trigger' => 'order_paid',
                'name' => 'Order paid / receipt',
                'enabled' => true,
                'delay_days' => 0,
                'review_url' => '',
                'subject' => 'Receipt for order {{order_number}}',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>Thanks for your order <strong>{{order_number}}</strong>.</p>\n<p>Total: {{order_total}}</p>\n<p>{{order_lines_html}}</p>\n<p>Invoice: {{invoice_number}}</p>\n<p>— {{site_name}}</p>",
                'body_mode' => 'html',
                'email_connection_alias' => '',
                'attach_invoice' => true,
                'attach_packing_slip' => false,
                'attach_shipping_label' => false,
            ],
            [
                'id' => 'tpl_donation_thanks',
                'trigger' => 'donation_thanks',
                'name' => 'Donation thank you',
                'enabled' => false,
                'delay_days' => 0,
                'review_url' => '',
                'subject' => 'Thank you for supporting {{site_name}}',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>Thank you for supporting <strong>{{site_name}}</strong>.</p>\n<p>Your contribution of <strong>{{order_total}}</strong> helps us keep fair, dependency-free software moving.</p>\n<p>{{order_lines_html}}</p>\n<p>With gratitude,<br>{{site_name}}</p>",
                'body_mode' => 'html',
                'email_connection_alias' => '',
                'attach_invoice' => false,
                'attach_packing_slip' => false,
                'attach_shipping_label' => false,
            ],
            [
                'id' => 'tpl_order_shipped',
                'trigger' => 'order_shipped',
                'name' => 'Order shipped',
                'enabled' => true,
                'delay_days' => 0,
                'review_url' => '',
                'subject' => 'Your order {{order_number}} has shipped',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>Order <strong>{{order_number}}</strong> is on its way.</p>\n<p>Carrier: {{carrier}}<br>Tracking: {{tracking_number}}</p>\n<p>— {{site_name}}</p>",
                'body_mode' => 'html',
                'email_connection_alias' => '',
                'attach_invoice' => false,
                'attach_packing_slip' => true,
                'attach_shipping_label' => true,
            ],
            [
                'id' => 'tpl_order_refunded',
                'trigger' => 'order_refunded',
                'name' => 'Order refunded',
                'enabled' => true,
                'delay_days' => 0,
                'review_url' => '',
                'subject' => 'Refund for order {{order_number}}',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>We processed a refund of {{refund_amount}} for order <strong>{{order_number}}</strong>.</p>\n<p>{{refund_reason}}</p>\n<p>— {{site_name}}</p>",
                'body_mode' => 'html',
            ],
            [
                'id' => 'tpl_order_canceled',
                'trigger' => 'order_canceled',
                'name' => 'Order canceled',
                'enabled' => true,
                'delay_days' => 0,
                'review_url' => '',
                'subject' => 'Order {{order_number}} canceled',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>Order <strong>{{order_number}}</strong> has been canceled.</p>\n<p>{{cancel_reason}}</p>\n<p>— {{site_name}}</p>",
                'body_mode' => 'html',
            ],
            [
                'id' => 'tpl_subscription_payment_failed',
                'trigger' => 'subscription_payment_failed',
                'name' => 'Subscription payment failed',
                'enabled' => true,
                'delay_days' => 0,
                'review_url' => '',
                'subject' => 'Action needed: subscription payment failed',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>We could not process a payment for subscription <strong>{{subscription_id}}</strong> ({{order_total}}).</p>\n<p>Please update your payment method to avoid interruption.</p>\n<p>— {{site_name}}</p>",
                'body_mode' => 'html',
            ],
            [
                'id' => 'tpl_order_review_request',
                'trigger' => 'order_review_request',
                'name' => 'Ask for a review',
                'enabled' => true,
                'delay_days' => 7,
                'review_url' => '',
                'subject' => 'How was your order {{order_number}}?',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>We hope you’re enjoying your purchase from <strong>{{site_name}}</strong>.</p>\n<p>Would you take a minute to leave a quick rating or review? It helps other customers and means a lot to us.</p>\n<p>{{review_link_html}}</p>\n<p>Order: {{order_number}}</p>\n<p>— {{site_name}}</p>",
                'body_mode' => 'html',
            ],
            [
                'id' => 'tpl_after_order_shipped',
                'trigger' => 'after_order_shipped',
                'name' => 'Follow-up after shipping',
                'enabled' => false,
                'delay_days' => 3,
                'review_url' => '',
                'subject' => 'Checking in on order {{order_number}}',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>Your order <strong>{{order_number}}</strong> shipped a few days ago ({{carrier}} / {{tracking_number}}).</p>\n<p>If anything is missing or damaged, just reply to this email — we’re happy to help.</p>\n<p>— {{site_name}}</p>",
                'body_mode' => 'html',
            ],
            [
                'id' => 'tpl_after_order_paid',
                'trigger' => 'after_order_paid',
                'name' => 'Follow-up after purchase',
                'enabled' => false,
                'delay_days' => 1,
                'review_url' => '',
                'subject' => 'Thanks again for order {{order_number}}',
                'body_html' => "<p>Hi {{customer_name}},</p>\n<p>Thanks again for shopping with <strong>{{site_name}}</strong>.</p>\n<p>We’re preparing order <strong>{{order_number}}</strong> ({{order_total}}). You’ll get a shipping update when it goes out.</p>\n<p>— {{site_name}}</p>",
                'body_mode' => 'html',
            ],
        ];
    }

    /**
     * @return list<array{token: string, label: string}>
     */
    public function availableTokens(): array
    {
        return [
            ['token' => 'customer_name', 'label' => 'Customer name'],
            ['token' => 'customer_email', 'label' => 'Customer email'],
            ['token' => 'order_number', 'label' => 'Order number'],
            ['token' => 'order_id', 'label' => 'Order ID'],
            ['token' => 'order_total', 'label' => 'Order total'],
            ['token' => 'order_status', 'label' => 'Order status'],
            ['token' => 'order_lines_html', 'label' => 'Order lines (HTML)'],
            ['token' => 'invoice_number', 'label' => 'Invoice number'],
            ['token' => 'tracking_number', 'label' => 'Tracking number'],
            ['token' => 'carrier', 'label' => 'Carrier'],
            ['token' => 'refund_amount', 'label' => 'Refund amount'],
            ['token' => 'refund_reason', 'label' => 'Refund reason'],
            ['token' => 'cancel_reason', 'label' => 'Cancel reason'],
            ['token' => 'subscription_id', 'label' => 'Subscription ID'],
            ['token' => 'site_name', 'label' => 'Store name'],
            ['token' => 'currency', 'label' => 'Currency'],
            ['token' => 'review_url', 'label' => 'Review URL (from template)'],
            ['token' => 'review_link_html', 'label' => 'Review link HTML button/link'],
            ['token' => 'delay_days', 'label' => 'Configured delay days'],
        ];
    }

    /**
     * Human labels for admin UI.
     *
     * @return array<string, string>
     */
    public function triggerLabels(): array
    {
        return [
            'order_paid' => 'Order paid (immediate)',
            'donation_thanks' => 'Donation thank you (immediate)',
            'order_shipped' => 'Order shipped (immediate)',
            'order_refunded' => 'Order refunded (immediate)',
            'order_canceled' => 'Order canceled (immediate)',
            'subscription_payment_failed' => 'Subscription payment failed (immediate)',
            'order_review_request' => 'Ask for review (after shipping)',
            'after_order_shipped' => 'Custom follow-up (after shipping)',
            'after_order_paid' => 'Custom follow-up (after paid)',
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listTemplates(): array
    {
        $defaults = $this->defaultTemplates();
        if (!is_file($this->templatesPath())) {
            $this->saveAll($defaults);
            return $defaults;
        }
        $data = json_decode((string) file_get_contents($this->templatesPath()), true);
        $stored = is_array($data['templates'] ?? null) ? $data['templates'] : [];
        if ($stored === []) {
            $this->saveAll($defaults);
            return $defaults;
        }

        $byId = [];
        foreach ($stored as $tpl) {
            if (is_array($tpl) && !empty($tpl['id'])) {
                $byId[(string) $tpl['id']] = $this->normalizeTemplate($tpl);
            }
        }
        foreach ($defaults as $def) {
            if (!isset($byId[$def['id']])) {
                $byId[$def['id']] = $def;
            }
        }
        return array_values($byId);
    }

    /**
     * @param array<string, mixed> $tpl
     * @return array<string, mixed>
     */
    private function normalizeTemplate(array $tpl): array
    {
        $trigger = (string) ($tpl['trigger'] ?? '');
        if (!in_array($trigger, self::TRIGGERS, true)) {
            $trigger = 'order_paid';
        }
        $delayDays = (int) ($tpl['delay_days'] ?? 0);
        if (self::isDelayedTrigger($trigger)) {
            if ($delayDays < 0) {
                $delayDays = 0;
            }
            if ($delayDays === 0 && !array_key_exists('delay_days', $tpl)) {
                $delayDays = $trigger === 'order_review_request' ? 7 : ($trigger === 'after_order_paid' ? 1 : 3);
            }
            $delayDays = max(0, min(365, $delayDays));
        } else {
            $delayDays = 0;
        }
        return [
            'id' => (string) ($tpl['id'] ?? ('tpl_' . bin2hex(random_bytes(4)))),
            'trigger' => $trigger,
            'name' => trim((string) ($tpl['name'] ?? 'Email')),
            'enabled' => !empty($tpl['enabled']),
            'delay_days' => $delayDays,
            'review_url' => trim((string) ($tpl['review_url'] ?? '')),
            'subject' => (string) ($tpl['subject'] ?? ''),
            'body_html' => (string) ($tpl['body_html'] ?? ''),
            'body_mode' => (($tpl['body_mode'] ?? '') === 'simple') ? 'simple' : 'html',
            'email_connection_alias' => trim((string) ($tpl['email_connection_alias'] ?? '')),
            'attach_invoice' => !empty($tpl['attach_invoice']),
            'attach_packing_slip' => !empty($tpl['attach_packing_slip']),
            'attach_shipping_label' => !empty($tpl['attach_shipping_label']),
        ];
    }

    /**
     * @param list<array<string, mixed>> $templates
     */
    public function saveAll(array $templates): void
    {
        $clean = [];
        foreach ($templates as $tpl) {
            if (is_array($tpl)) {
                $clean[] = $this->normalizeTemplate($tpl);
            }
        }
        file_put_contents($this->templatesPath(), json_encode([
            'templates' => $clean,
            'updated_at' => date('c'),
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /**
     * @param array<string, mixed> $tpl
     * @return array<string, mixed>
     */
    public function saveTemplate(array $tpl): array
    {
        $normalized = $this->normalizeTemplate($tpl);
        $all = $this->listTemplates();
        $found = false;
        foreach ($all as $i => $existing) {
            if (($existing['id'] ?? '') === $normalized['id']) {
                $all[$i] = $normalized;
                $found = true;
                break;
            }
        }
        if (!$found) {
            $all[] = $normalized;
        }
        $this->saveAll($all);
        return $normalized;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function templatesForTrigger(string $trigger): array
    {
        $out = [];
        foreach ($this->listTemplates() as $tpl) {
            if (($tpl['trigger'] ?? '') === $trigger && !empty($tpl['enabled'])) {
                $out[] = $tpl;
            }
        }
        return $out;
    }

    /**
     * @param array<string, mixed> $context
     * @return array<string, string>
     */
    public function buildTokenMap(array $context, ?array $tpl = null): array
    {
        $order = is_array($context['order'] ?? null) ? $context['order'] : [];
        $shipment = is_array($context['shipment'] ?? null) ? $context['shipment'] : [];
        $refund = is_array($context['refund'] ?? null) ? $context['refund'] : [];
        $subscription = is_array($context['subscription'] ?? null) ? $context['subscription'] : [];

        $currency = strtoupper((string) ($order['currency'] ?? $subscription['currency'] ?? 'EUR'));
        $totalCents = (int) ($order['total_cents'] ?? $subscription['amount_cents'] ?? 0);
        $refundCents = (int) ($refund['amount_cents'] ?? $context['refund_amount_cents'] ?? 0);
        $name = trim((string) (
            $order['customer_name']
            ?? ($order['shipping_address']['name'] ?? '')
            ?? ($order['attendee_name'] ?? '')
            ?? ''
        ));
        if ($name === '') {
            $name = (string) ($order['customer_email'] ?? 'there');
        }

        $site = function_exists('commerce_store_display_name')
            ? commerce_store_display_name($this->dataDir)
            : 'Commerce';

        $linesHtml = '';
        foreach ($order['lines'] ?? [] as $line) {
            if (!is_array($line)) {
                continue;
            }
            $linesHtml .= '<li>' . htmlspecialchars((string) ($line['title'] ?? 'Item'), ENT_QUOTES, 'UTF-8')
                . ' ×' . (int) ($line['quantity'] ?? 1) . '</li>';
        }
        if ($linesHtml !== '') {
            $linesHtml = '<ul>' . $linesHtml . '</ul>';
        }

        $reviewUrl = trim((string) (
            ($tpl['review_url'] ?? null)
            ?? ($context['review_url'] ?? '')
        ));
        $reviewLinkHtml = $reviewUrl !== ''
            ? '<p><a href="' . htmlspecialchars($reviewUrl, ENT_QUOTES, 'UTF-8') . '">Leave a review</a></p>'
            : '<p><em>Add a review URL on this email template to insert a link here.</em></p>';

        return [
            'customer_name' => $name,
            'customer_email' => (string) ($order['customer_email'] ?? $subscription['customer_email'] ?? ''),
            'order_number' => (string) ($order['order_number'] ?? $order['id'] ?? ''),
            'order_id' => (string) ($order['id'] ?? ''),
            'order_total' => $currency . ' ' . number_format($totalCents / 100, 2, '.', ''),
            'order_status' => (string) ($order['status'] ?? ''),
            'order_lines_html' => $linesHtml,
            'invoice_number' => (string) ($order['invoice_number'] ?? ''),
            'tracking_number' => (string) ($shipment['tracking_number'] ?? $context['tracking_number'] ?? ''),
            'carrier' => (string) ($shipment['carrier'] ?? $context['carrier'] ?? ''),
            'refund_amount' => $currency . ' ' . number_format($refundCents / 100, 2, '.', ''),
            'refund_reason' => (string) ($refund['reason'] ?? $context['refund_reason'] ?? ''),
            'cancel_reason' => (string) ($order['cancel_reason'] ?? $context['cancel_reason'] ?? ''),
            'subscription_id' => (string) ($subscription['id'] ?? $context['subscription_id'] ?? ''),
            'site_name' => $site,
            'currency' => $currency,
            'review_url' => $reviewUrl,
            'review_link_html' => $reviewLinkHtml,
            'delay_days' => (string) (int) ($tpl['delay_days'] ?? $context['delay_days'] ?? 0),
        ];
    }

    /**
     * @param array<string, string> $tokens
     */
    public function renderString(string $template, array $tokens): string
    {
        return (string) preg_replace_callback('/\{\{\s*([a-z0-9_]+)\s*\}\}/i', static function ($m) use ($tokens) {
            $key = strtolower($m[1]);
            return array_key_exists($key, $tokens) ? (string) $tokens[$key] : $m[0];
        }, $template);
    }

    /**
     * @param array<string, mixed> $context
     * @return array{ok: bool, subject?: string, body_html?: string, error?: string}
     */
    public function preview(string $templateId, array $context = []): array
    {
        $tpl = null;
        foreach ($this->listTemplates() as $row) {
            if (($row['id'] ?? '') === $templateId) {
                $tpl = $row;
                break;
            }
        }
        if (!$tpl) {
            return ['ok' => false, 'error' => 'Template not found'];
        }
        if ($context === []) {
            $context = $this->sampleContext();
        }
        $tokens = $this->buildTokenMap($context, $tpl);
        return [
            'ok' => true,
            'subject' => $this->renderString((string) $tpl['subject'], $tokens),
            'body_html' => $this->renderString((string) $tpl['body_html'], $tokens),
            'template' => $tpl,
            'tokens' => $tokens,
        ];
    }

    /**
     * @return array{order: array, shipment: array, refund: array, subscription: array}
     */
    public function sampleContext(): array
    {
        return [
            'order' => [
                'id' => 'cord_sample',
                'order_number' => 'ORD-2026-0001',
                'invoice_number' => 'INV-2026-0001',
                'customer_email' => 'customer@example.com',
                'customer_name' => 'Ada Buyer',
                'status' => 'paid',
                'currency' => 'eur',
                'total_cents' => 4590,
                'cancel_reason' => 'Customer request',
                'lines' => [
                    ['title' => 'Ceramic Mug', 'quantity' => 1],
                    ['title' => 'Sticker Pack', 'quantity' => 2],
                ],
            ],
            'shipment' => [
                'tracking_number' => 'JD0123456789',
                'carrier' => 'DHL',
            ],
            'refund' => [
                'amount_cents' => 1500,
                'reason' => 'Partial refund',
            ],
            'subscription' => [
                'id' => 'sub_sample',
                'amount_cents' => 1200,
                'currency' => 'eur',
                'customer_email' => 'customer@example.com',
            ],
        ];
    }

    /**
     * Send all enabled templates for a trigger, and schedule delayed templates
     * whose anchor matches this event.
     *
     * @param array<string, mixed> $context
     * @return list<array<string, mixed>>
     */
    public function sendForTrigger(string $trigger, array $context = []): array
    {
        $results = [];
        $templates = $this->templatesForTrigger($trigger);
        if ($templates === []) {
            $order = is_array($context['order'] ?? null) ? $context['order'] : [];
            $this->appendLog([
                'ok' => false,
                'skipped' => true,
                'error' => 'No enabled email templates for trigger: ' . $trigger,
                'note' => $trigger === 'donation_thanks'
                    ? 'Enable "Donation thank you" under Settings → Emails (donation orders use this trigger instead of Order paid).'
                    : 'Enable a template for this trigger under Settings → Emails.',
                'trigger' => $trigger,
                'to' => (string) ($order['customer_email'] ?? ''),
                'order_id' => (string) ($order['id'] ?? ''),
                'at' => date('c'),
            ]);
            error_log('Commerce email skipped: no enabled templates for trigger ' . $trigger);
        }
        foreach ($templates as $tpl) {
            $results[] = $this->sendTemplate($tpl, $context);
        }
        if (!self::isDelayedTrigger($trigger)) {
            $scheduled = $this->scheduleForAnchor($trigger, $context);
            foreach ($scheduled as $job) {
                $results[] = [
                    'ok' => true,
                    'scheduled' => true,
                    'template_id' => $job['template_id'] ?? '',
                    'trigger' => $job['trigger'] ?? '',
                    'send_at' => $job['send_at'] ?? '',
                ];
            }
        }

        // Fan out to any configured notification channels (Slack, Discord, SMS, extra email aliases).
        if (function_exists('birkly_notify')) {
            try {
                birkly_notify('commerce.' . $trigger, [
                    'order' => $context['order'] ?? null,
                    'shipment' => $context['shipment'] ?? null,
                    'refund' => $context['refund'] ?? null,
                    'subscription' => $context['subscription'] ?? null,
                    'recipient' => is_array($context['order'] ?? null) ? ($context['order']['customer_email'] ?? null) : null,
                ], ['alias' => 'transactional_email']);
            } catch (Throwable $e) {
                error_log('Commerce notify failed (' . $trigger . '): ' . $e->getMessage());
            }
        }

        return $results;
    }

    /**
     * Queue enabled delayed templates anchored to this event.
     *
     * @param array<string, mixed> $context
     * @return list<array<string, mixed>>
     */
    public function scheduleForAnchor(string $anchor, array $context = []): array
    {
        $order = is_array($context['order'] ?? null) ? $context['order'] : [];
        $orderId = (string) ($order['id'] ?? '');
        if ($orderId === '') {
            return [];
        }

        $created = [];
        foreach ($this->listTemplates() as $tpl) {
            $trigger = (string) ($tpl['trigger'] ?? '');
            if (!self::isDelayedTrigger($trigger)) {
                continue;
            }
            if (self::delayAnchorFor($trigger) !== $anchor) {
                continue;
            }
            if (empty($tpl['enabled'])) {
                continue;
            }

            $delayDays = (int) ($tpl['delay_days'] ?? 0);
            if ($delayDays <= 0) {
                // Zero delay = send now as part of this event.
                $this->sendTemplate($tpl, $context);
                continue;
            }

            $job = $this->enqueueScheduledJob($tpl, $context, $delayDays);
            if ($job) {
                $created[] = $job;
            }
        }
        return $created;
    }

    /**
     * @param array<string, mixed> $tpl
     * @param array<string, mixed> $context
     * @return array<string, mixed>|null
     */
    private function enqueueScheduledJob(array $tpl, array $context, int $delayDays): ?array
    {
        $order = is_array($context['order'] ?? null) ? $context['order'] : [];
        $orderId = (string) ($order['id'] ?? '');
        $templateId = (string) ($tpl['id'] ?? '');
        if ($orderId === '' || $templateId === '') {
            return null;
        }

        $jobs = $this->loadSchedule();
        foreach ($jobs as $existing) {
            if (($existing['order_id'] ?? '') !== $orderId || ($existing['template_id'] ?? '') !== $templateId) {
                continue;
            }
            $status = (string) ($existing['status'] ?? '');
            // One review/follow-up per order+template (pending or already sent).
            if (in_array($status, ['pending', 'sent'], true)) {
                return null;
            }
        }

        $shipment = is_array($context['shipment'] ?? null) ? $context['shipment'] : [];
        $sendAt = gmdate('c', time() + ($delayDays * 86400));
        $job = [
            'id' => 'cej_' . bin2hex(random_bytes(6)),
            'template_id' => $templateId,
            'trigger' => (string) ($tpl['trigger'] ?? ''),
            'order_id' => $orderId,
            'send_at' => $sendAt,
            'delay_days' => $delayDays,
            'status' => 'pending',
            'created_at' => date('c'),
            'context' => [
                'shipment' => [
                    'tracking_number' => $shipment['tracking_number'] ?? ($context['tracking_number'] ?? ''),
                    'carrier' => $shipment['carrier'] ?? ($context['carrier'] ?? ''),
                ],
                'tracking_number' => $shipment['tracking_number'] ?? ($context['tracking_number'] ?? ''),
                'carrier' => $shipment['carrier'] ?? ($context['carrier'] ?? ''),
            ],
        ];
        $jobs[] = $job;
        $this->saveSchedule($jobs);
        return $job;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function listScheduled(int $limit = 50): array
    {
        $jobs = $this->loadSchedule();
        usort($jobs, static function ($a, $b) {
            return strcmp((string) ($a['send_at'] ?? ''), (string) ($b['send_at'] ?? ''));
        });
        return array_slice($jobs, 0, max(1, $limit));
    }

    /**
     * Cancel pending delayed emails for an order (e.g. on cancel).
     */
    public function cancelScheduledForOrder(string $orderId, string $reason = 'order_canceled'): int
    {
        $orderId = trim($orderId);
        if ($orderId === '') {
            return 0;
        }
        $jobs = $this->loadSchedule();
        $n = 0;
        foreach ($jobs as $i => $job) {
            if (($job['status'] ?? '') !== 'pending') {
                continue;
            }
            if (($job['order_id'] ?? '') !== $orderId) {
                continue;
            }
            $jobs[$i]['status'] = 'canceled';
            $jobs[$i]['canceled_at'] = date('c');
            $jobs[$i]['cancel_reason'] = $reason;
            $n++;
        }
        if ($n > 0) {
            $this->saveSchedule($jobs);
        }
        return $n;
    }

    /**
     * Send due scheduled emails. Reloads live order data; skips canceled orders.
     *
     * @return array{processed: int, sent: int, skipped: int, results: list<array<string, mixed>>}
     */
    public function processDueScheduledEmails(?int $now = null): array
    {
        $nowTs = $now ?? time();
        $jobs = $this->loadSchedule();
        $orders = null;
        if (class_exists('CommerceOrderStore')) {
            $orders = new CommerceOrderStore($this->dataDir . '/orders');
        }

        $processed = 0;
        $sent = 0;
        $skipped = 0;
        $results = [];

        foreach ($jobs as $i => $job) {
            if (($job['status'] ?? '') !== 'pending') {
                continue;
            }
            $sendAt = strtotime((string) ($job['send_at'] ?? ''));
            if ($sendAt === false || $sendAt > $nowTs) {
                continue;
            }
            $processed++;

            $templateId = (string) ($job['template_id'] ?? '');
            $tpl = null;
            foreach ($this->listTemplates() as $row) {
                if (($row['id'] ?? '') === $templateId) {
                    $tpl = $row;
                    break;
                }
            }
            if (!$tpl || empty($tpl['enabled'])) {
                $jobs[$i]['status'] = 'skipped';
                $jobs[$i]['skipped_at'] = date('c');
                $jobs[$i]['skip_reason'] = 'template_missing_or_disabled';
                $skipped++;
                continue;
            }

            $orderId = (string) ($job['order_id'] ?? '');
            $order = null;
            if ($orders && $orderId !== '') {
                $order = $orders->get($orderId);
            }
            if (!$order) {
                $jobs[$i]['status'] = 'skipped';
                $jobs[$i]['skipped_at'] = date('c');
                $jobs[$i]['skip_reason'] = 'order_not_found';
                $skipped++;
                continue;
            }
            $status = strtolower((string) ($order['status'] ?? ''));
            if (in_array($status, ['canceled', 'cancelled', 'refunded'], true)) {
                $jobs[$i]['status'] = 'canceled';
                $jobs[$i]['canceled_at'] = date('c');
                $jobs[$i]['cancel_reason'] = 'order_status_' . $status;
                $skipped++;
                continue;
            }

            $context = is_array($job['context'] ?? null) ? $job['context'] : [];
            $context['order'] = $order;
            $result = $this->sendTemplate($tpl, $context);
            $results[] = $result;
            if (!empty($result['ok'])) {
                $jobs[$i]['status'] = 'sent';
                $jobs[$i]['sent_at'] = date('c');
                $sent++;
            } else {
                $jobs[$i]['status'] = 'failed';
                $jobs[$i]['failed_at'] = date('c');
                $jobs[$i]['error'] = $result['error'] ?? 'send_failed';
                $skipped++;
            }
        }

        $this->saveSchedule($jobs);
        return [
            'processed' => $processed,
            'sent' => $sent,
            'skipped' => $skipped,
            'results' => $results,
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function loadSchedule(): array
    {
        if (!is_file($this->schedulePath())) {
            return [];
        }
        $data = json_decode((string) file_get_contents($this->schedulePath()), true);
        $jobs = is_array($data['jobs'] ?? null) ? $data['jobs'] : [];
        $clean = [];
        foreach ($jobs as $job) {
            if (is_array($job)) {
                $clean[] = $job;
            }
        }
        // Keep file bounded.
        if (count($clean) > 500) {
            $clean = array_slice($clean, -500);
        }
        return $clean;
    }

    /**
     * @param list<array<string, mixed>> $jobs
     */
    private function saveSchedule(array $jobs): void
    {
        file_put_contents($this->schedulePath(), json_encode([
            'jobs' => array_values($jobs),
            'updated_at' => date('c'),
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /**
     * @param array<string, mixed> $tpl
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    public function sendTemplate(array $tpl, array $context = [], ?string $toOverride = null): array
    {
        $tokens = $this->buildTokenMap($context, $tpl);
        $to = $toOverride ?: (string) ($tokens['customer_email'] ?? '');
        $subject = $this->renderString((string) ($tpl['subject'] ?? ''), $tokens);
        $body = $this->renderString((string) ($tpl['body_html'] ?? ''), $tokens);
        if ($to === '') {
            $result = ['ok' => false, 'error' => 'No recipient email', 'template_id' => $tpl['id'] ?? ''];
            $this->appendLog($result + ['to' => '', 'subject' => $subject, 'trigger' => $tpl['trigger'] ?? '']);
            return $result;
        }

        $send = $this->deliver($to, $subject, $body, $tpl, $this->buildEmailAttachments($tpl, $context));
        $delivered = array_key_exists('delivered', $send)
            ? !empty($send['delivered'])
            : !empty($send['ok']);
        $row = [
            'ok' => !empty($send['ok']),
            'delivered' => $delivered,
            'logged' => $send['logged'] ?? null,
            'queued' => $send['queued'] ?? null,
            'status' => $send['status'] ?? null,
            'message_id' => $send['message_id'] ?? null,
            'provider' => $send['provider'] ?? null,
            'error' => $send['error'] ?? null,
            'method' => $send['method'] ?? null,
            'note' => $send['note'] ?? null,
            'to' => $to,
            'subject' => $subject,
            'body_html' => $send['body_html'] ?? null,
            'template_id' => $tpl['id'] ?? '',
            'trigger' => $tpl['trigger'] ?? '',
            'at' => date('c'),
        ];
        $this->appendLog($row);
        return $row;
    }

    /**
     * @param array<string, mixed> $tpl
     * @param array<string, mixed> $context
     * @return list<array{filename: string, content: string, mime_type: string}>
     */
    public function buildEmailAttachments(array $tpl, array $context): array
    {
        $order = is_array($context['order'] ?? null) ? $context['order'] : [];
        if ($order === []) {
            return [];
        }

        $orderNumber = preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string) ($order['order_number'] ?? $order['id'] ?? 'order')) ?: 'order';
        $attachments = [];

        if (!empty($tpl['attach_invoice']) && class_exists('CommerceInvoiceService')) {
            $invoice = new CommerceInvoiceService($this->dataDir);
            $html = $invoice->buildInvoiceHtml($order);
            if ($html !== '') {
                $attachments[] = [
                    'filename' => 'invoice-' . $orderNumber . '.html',
                    'content' => $html,
                    'mime_type' => 'text/html; charset=UTF-8',
                ];
            }
        }

        if (!empty($tpl['attach_packing_slip']) && class_exists('CommerceOrderOps')) {
            if (!class_exists('CommerceOrderStore')) {
                require_once __DIR__ . '/CommerceOrderStore.php';
            }
            $shipment = is_array($context['shipment'] ?? null) ? $context['shipment'] : [];
            $shipmentId = trim((string) ($shipment['id'] ?? ''));
            $ops = new CommerceOrderOps(new CommerceOrderStore($this->dataDir . '/orders'));
            $brandName = function_exists('commerce_store_display_name')
                ? commerce_store_display_name($this->dataDir)
                : 'Commerce';
            $html = $ops->buildPackingSlipHtml(
                $order,
                ['name' => $brandName],
                $shipmentId !== '' ? $shipmentId : null,
                false
            );
            if ($html !== '') {
                $attachments[] = [
                    'filename' => 'packing-slip-' . $orderNumber . '.html',
                    'content' => $html,
                    'mime_type' => 'text/html; charset=UTF-8',
                ];
            }
        }

        if (!empty($tpl['attach_shipping_label'])) {
            $labelUrl = $this->resolveShippingLabelUrl($order, $context);
            if ($labelUrl !== '') {
                $pdf = $this->fetchRemoteBinary($labelUrl);
                if ($pdf !== '') {
                    $attachments[] = [
                        'filename' => 'shipping-label-' . $orderNumber . '.pdf',
                        'content' => $pdf,
                        'mime_type' => 'application/pdf',
                    ];
                }
            }
        }

        return $attachments;
    }

    /**
     * @param array<string, mixed> $order
     * @param array<string, mixed> $context
     */
    private function resolveShippingLabelUrl(array $order, array $context): string
    {
        $shipment = is_array($context['shipment'] ?? null) ? $context['shipment'] : [];
        $labelUrl = trim((string) ($shipment['label_url'] ?? ''));
        if ($labelUrl !== '') {
            return $labelUrl;
        }

        $shipmentId = trim((string) ($shipment['id'] ?? ''));
        foreach ($order['shipments'] ?? [] as $row) {
            if (!is_array($row)) {
                continue;
            }
            if ($shipmentId !== '' && (string) ($row['id'] ?? '') !== $shipmentId) {
                continue;
            }
            $candidate = trim((string) ($row['label_url'] ?? ''));
            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    private function fetchRemoteBinary(string $url): string
    {
        $url = trim($url);
        if ($url === '' || !preg_match('#^https?://#i', $url)) {
            return '';
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch === false) {
                return '';
            }
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 20);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
            $body = curl_exec($ch);
            curl_close($ch);
            return is_string($body) ? $body : '';
        }

        $context = stream_context_create([
            'http' => [
                'timeout' => 20,
                'follow_location' => 1,
            ],
        ]);
        $body = @file_get_contents($url, false, $context);
        return is_string($body) ? $body : '';
    }

    /**
     * @param array<string, mixed> $tpl
     * @param list<array{filename: string, content: string, mime_type?: string}> $attachments
     * @return array{ok: bool, method?: string, error?: string, delivered?: bool, logged?: bool, queued?: bool, note?: string}
     */
    /**
     * Load the central Birkly mail pipeline when Commerce runs outside
     * endpoints that already require core/mail (e.g. connections.php).
     */
    private function ensureMailPipelineLoaded(): void
    {
        if (!function_exists('commerce_cms_path')) {
            require_once __DIR__ . '/../cms_paths.php';
        }
        if (!function_exists('birkly_send_mail')) {
            $mailPath = commerce_cms_path('core/mail/birkly_send_mail.php');
            if (is_file($mailPath)) {
                require_once $mailPath;
            }
        }
        if (!function_exists('birkly_resolve_email_connection_alias')) {
            $resolvePath = commerce_cms_path('core/connections/resolve.php');
            if (is_file($resolvePath)) {
                require_once $resolvePath;
            }
        }
    }

    private function deliver(string $to, string $subject, string $bodyHtml, ?array $tpl = null, array $attachments = []): array
    {
        if (array_key_exists('commerce_test_birkly_mail_result', $GLOBALS)) {
            if (!isset($GLOBALS['_test_birkly_mail_calls']) || !is_array($GLOBALS['_test_birkly_mail_calls'])) {
                $GLOBALS['_test_birkly_mail_calls'] = [];
            }
            $stubOpts = [
                'alias' => $this->resolveEmailConnectionAlias($tpl),
                'text' => $this->htmlToText($bodyHtml),
            ];
            if ($attachments !== []) {
                $stubOpts['attachments'] = $attachments;
            }
            $GLOBALS['_test_birkly_mail_calls'][] = [
                'to' => $to,
                'subject' => $subject,
                'html' => $bodyHtml,
                'opts' => $stubOpts,
            ];
            $stub = $GLOBALS['commerce_test_birkly_mail_result'];
            if (!is_array($stub)) {
                return ['ok' => (bool) $stub, 'method' => 'commerce_test_stub'];
            }
            return $this->normalizeBirklyMailResult($stub, $bodyHtml);
        }

        $this->ensureMailPipelineLoaded();

        if (empty($GLOBALS['commerce_test_skip_birkly_mail']) && function_exists('birkly_send_mail')) {
            $alias = $this->resolveEmailConnectionAlias($tpl);
            $opts = [
                'alias' => $alias,
                'text' => $this->htmlToText($bodyHtml),
            ];
            if ($attachments !== []) {
                $opts['attachments'] = $attachments;
            }
            $result = birkly_send_mail($to, $subject, $bodyHtml, $opts);
            if (!is_array($result)) {
                return ['ok' => (bool) $result, 'method' => 'birkly_send_mail'];
            }
            return $this->normalizeBirklyMailResult($result, $bodyHtml);
        }

        return [
            'ok' => true,
            'delivered' => false,
            'logged' => true,
            'method' => 'commerce_log',
            'note' => 'Logged only — not delivered. The Birkly mail pipeline is not available; configure an Email connection under Settings → Connections for inbox delivery. Stripe card receipts use Checkout receipt_email when set.',
            'from' => $this->resolveFromAddress(),
            'body_html' => $bodyHtml,
        ];
    }

    /**
     * Convert a simple HTML body to plain text for providers that require both parts.
     */
    private function htmlToText(string $html): string
    {
        $text = preg_replace('/<br\s*\/?>/i', "\n", $html);
        $text = preg_replace('/<\/p>/i', "\n\n", $text ?? $html);
        $text = strip_tags($text ?? $html);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return trim(preg_replace('/\n{3,}/', "\n\n", $text));
    }

    private function resolveFromAddress(): string
    {
        $from = 'noreply@localhost';
        if (class_exists('CommerceInvoiceService')) {
            $email = trim((string) ((new CommerceInvoiceService($this->dataDir))->getProfile()['email'] ?? ''));
            if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $from = $email;
            }
        }
        return $from;
    }

    /**
     * Map a birkly_send_mail result to an honest Commerce delivery row.
     *
     * @param array<string, mixed> $result
     * @return array<string, mixed>
     */
    private function normalizeBirklyMailResult(array $result, string $bodyHtml): array
    {
        $status = (string) ($result['status'] ?? '');
        if ($status === '' && isset($result['ok'])) {
            $status = !empty($result['ok']) ? 'accepted' : 'failed';
        }
        $method = (string) ($result['method'] ?? $result['transport'] ?? 'birkly_send_mail');
        $messageId = $result['message_id'] ?? $result['id'] ?? null;

        switch ($status) {
            case 'accepted':
            case 'delivered':
                return [
                    'ok' => true,
                    'delivered' => true,
                    'method' => $method,
                    'message_id' => $messageId,
                    'provider' => $result['provider'] ?? null,
                    'body_html' => $bodyHtml,
                ];
            case 'queued':
                // Legacy cores returned queued for successful SMTP/ESP handoff; treat as delivered.
                return [
                    'ok' => true,
                    'delivered' => true,
                    'queued' => true,
                    'method' => $method,
                    'message_id' => $messageId,
                    'provider' => $result['provider'] ?? null,
                    'body_html' => $bodyHtml,
                ];
            case 'logged':
                $provider = (string) ($result['provider'] ?? 'log');
                $note = $provider === 'log'
                    ? 'Logged only — not delivered. Your active email connection is Log only. Choose SMTP or an ESP under Settings → Connections for inbox delivery.'
                    : 'Logged only — not delivered. Configure an Email connection under Settings → Connections for inbox delivery.';

                return [
                    'ok' => true,
                    'delivered' => false,
                    'logged' => true,
                    'method' => 'log',
                    'provider' => $provider !== '' ? $provider : 'log',
                    'note' => $note,
                    'body_html' => $bodyHtml,
                ];
            case 'suppressed':
            case 'bounced':
            case 'complained':
                return [
                    'ok' => false,
                    'delivered' => false,
                    'status' => $status,
                    'method' => $method,
                    'error' => $result['error'] ?? ('Status: ' . $status),
                    'body_html' => $bodyHtml,
                ];
            case 'failed':
            default:
                return [
                    'ok' => false,
                    'delivered' => false,
                    'method' => $method,
                    'error' => $result['error'] ?? 'Send failed via birkly_send_mail',
                    'body_html' => $bodyHtml,
                ];
        }
    }

    /**
     * @param array<string, mixed> $row
     */
    private function appendLog(array $row): void
    {
        $data = ['entries' => []];
        if (is_file($this->logPath())) {
            $decoded = json_decode((string) file_get_contents($this->logPath()), true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
        }
        if (!isset($data['entries']) || !is_array($data['entries'])) {
            $data['entries'] = [];
        }
        $data['entries'][] = $row;
        if (count($data['entries']) > 200) {
            $data['entries'] = array_slice($data['entries'], -200);
        }
        file_put_contents($this->logPath(), json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function recentLog(int $limit = 20): array
    {
        if (!is_file($this->logPath())) {
            return [];
        }
        $data = json_decode((string) file_get_contents($this->logPath()), true);
        $entries = is_array($data['entries'] ?? null) ? $data['entries'] : [];
        return array_slice(array_reverse($entries), 0, max(1, $limit));
    }
}
