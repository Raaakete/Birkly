<?php
/**
 * Flat-file order storage for Commerce plugin.
 */

class CommerceOrderStore
{
    private string $baseDir;

    public function __construct(?string $baseDir = null)
    {
        if ($baseDir !== null) {
            $this->baseDir = rtrim($baseDir, '/');
        } else {
            $this->baseDir = commerce_data_dir() . '/orders';
        }
        if (!is_dir($this->baseDir)) {
            mkdir($this->baseDir, 0755, true);
        }
    }

    public function getDataDir(): string
    {
        return $this->baseDir;
    }

    public function create(array $order): array
    {
        $id = $order['id'] ?? ('cord_' . bin2hex(random_bytes(8)));
        $now = date('c');
        $record = array_merge([
            'id' => $id,
            'order_number' => null,
            'status' => 'pending',
            'created_at' => $now,
            'updated_at' => $now,
            'lines' => [],
            'total_cents' => 0,
            'discount_cents' => 0,
            'discount_allocations' => [],
            'shipping_cents' => 0,
            'shipping_lines' => [],
            'tax_cents' => 0,
            'tax_rate' => 0.0,
            'tax_country' => '',
            'tax_lines' => [],
            'gift_card_applications' => [],
            'currency' => 'eur',
            'payment_id' => null,
            'provider' => null,
            'customer_email' => '',
            'coupon_code' => null,
            'affiliate_id' => null,
            'shipping_address' => null,
            'fulfillment_results' => [],
        ], $order);
        $record['id'] = $id;
        if (empty($record['order_number'])) {
            $record['order_number'] = $this->allocateOrderNumber($record['created_at'] ?? $now);
        }
        $this->write($id, $record);
        return $record;
    }

    /**
     * Ensure every stored order has a human-readable order_number (ORD-YYYYMMDD-0001).
     * Safe to call repeatedly.
     *
     * @return int Number of orders updated
     */
    public function ensureOrderNumbers(): int
    {
        $updated = 0;
        foreach ($this->listAll() as $order) {
            if (!empty($order['order_number'])) {
                continue;
            }
            $id = (string) ($order['id'] ?? '');
            if ($id === '') {
                continue;
            }
            $number = $this->allocateOrderNumber($order['created_at'] ?? date('c'));
            $this->update($id, ['order_number' => $number]);
            $updated++;
        }
        return $updated;
    }

    /**
     * Allocate the next merchant-facing order number for a day bucket.
     * Format: ORD-YYYYMMDD-0001
     */
    public function allocateOrderNumber(?string $createdAt = null): string
    {
        $ts = $createdAt ? strtotime($createdAt) : time();
        if ($ts === false) {
            $ts = time();
        }
        $day = date('Ymd', $ts);
        $seqFile = dirname($this->baseDir) . '/order_sequence.json';
        $fp = fopen($seqFile, 'c+');
        if ($fp === false) {
            return 'ORD-' . $day . '-' . strtoupper(substr(bin2hex(random_bytes(2)), 0, 4));
        }
        try {
            flock($fp, LOCK_EX);
            $raw = stream_get_contents($fp);
            $data = is_string($raw) && $raw !== '' ? json_decode($raw, true) : [];
            if (!is_array($data)) {
                $data = [];
            }
            $seq = (int) ($data[$day] ?? 0) + 1;
            $data[$day] = $seq;
            // Keep file small — drop days older than ~90.
            if (count($data) > 120) {
                ksort($data);
                $data = array_slice($data, -90, null, true);
            }
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($data, JSON_PRETTY_PRINT));
            fflush($fp);
            return sprintf('ORD-%s-%04d', $day, $seq);
        } finally {
            flock($fp, LOCK_UN);
            fclose($fp);
        }
    }

    public function get(string $id): ?array
    {
        $file = $this->path($id);
        if (!is_file($file)) {
            return null;
        }
        $data = json_decode((string) file_get_contents($file), true);
        return is_array($data) ? $data : null;
    }

    public function update(string $id, array $patch): ?array
    {
        $existing = $this->get($id);
        if (!$existing) {
            return null;
        }
        $record = array_merge($existing, $patch, ['updated_at' => date('c')]);
        $this->write($id, $record);
        return $record;
    }

    public function findByPaymentId(string $paymentId): ?array
    {
        foreach ($this->listAll() as $order) {
            if (($order['payment_id'] ?? '') === $paymentId) {
                return $order;
            }
            if ($paymentId !== '' && ($order['stripe_checkout_session_id'] ?? '') === $paymentId) {
                return $order;
            }
        }
        return null;
    }

    public function findByOrderNumber(string $orderNumber): ?array
    {
        $needle = strtoupper(trim($orderNumber));
        if ($needle === '') {
            return null;
        }
        foreach ($this->listAll() as $order) {
            $number = strtoupper(trim((string) ($order['order_number'] ?? '')));
            if ($number !== '' && $number === $needle) {
                return $order;
            }
        }
        return null;
    }

    public function findByShopifyOrderId(string $shopifyOrderId): ?array
    {
        $shopifyOrderId = trim($shopifyOrderId);
        if ($shopifyOrderId === '') {
            return null;
        }
        $canonicalId = 'shopify_' . preg_replace('/[^a-zA-Z0-9_-]/', '', $shopifyOrderId);
        $byId = $this->get($canonicalId);
        if ($byId) {
            return $byId;
        }
        foreach ($this->listAll() as $order) {
            if ((string) ($order['shopify_order_id'] ?? '') === $shopifyOrderId) {
                return $order;
            }
        }
        return null;
    }

    public function delete(string $id): bool
    {
        $file = $this->path($id);
        if (!is_file($file)) {
            return false;
        }
        return @unlink($file);
    }

    public function listAll(): array
    {
        $orders = [];
        foreach (glob($this->baseDir . '/*.json') ?: [] as $file) {
            $data = json_decode((string) file_get_contents($file), true);
            if (is_array($data)) {
                $orders[] = $data;
            }
        }
        usort($orders, function ($a, $b) {
            return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
        });
        return $orders;
    }

    private function path(string $id): string
    {
        return $this->baseDir . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $id) . '.json';
    }

    private function write(string $id, array $record): void
    {
        file_put_contents($this->path($id), json_encode($record, JSON_PRETTY_PRINT), LOCK_EX);
    }
}
