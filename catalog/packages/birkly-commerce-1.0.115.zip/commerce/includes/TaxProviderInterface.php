<?php
/**
 * Tax calculation provider interface (orthogonal to payment PSP).
 */

interface TaxProviderInterface
{
    public function getId(): string;

    public function getName(): string;

    /**
     * Calculate tax for cart/checkout lines.
     *
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context Optional: currency, vat_id/tax_id, billing_address, credentials, etc.
     * @return array{
     *   tax_cents: int,
     *   tax_add_cents?: int,
     *   rate: float,
     *   country: string,
     *   taxable_cents: int,
     *   tax_lines: list<array<string, mixed>>,
     *   provider: string,
     *   prices_include_tax?: bool,
     *   tax_included?: bool
     * }
     */
    public function calculate(array $lines, ?array $shippingAddress = null, array $context = []): array;
}
