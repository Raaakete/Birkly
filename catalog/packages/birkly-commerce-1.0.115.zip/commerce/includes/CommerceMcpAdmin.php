<?php
/**
 * Commerce MCP admin dispatch — mirrors api/commerce.php admin/stats actions without HTTP/CSRF/session.
 */

declare(strict_types=1);

require_once __DIR__ . '/CommerceInventoryLedger.php';

/**
 * @return array{id: ?string, email: ?string, name: string, label: string}
 */
function commerce_mcp_admin_actor(array $aiUser): array
{
    $id = trim((string) ($aiUser['id'] ?? ''));
    $email = trim((string) ($aiUser['email'] ?? ''));
    $name = trim((string) ($aiUser['name'] ?? $aiUser['display_name'] ?? ''));
    if ($name === '') {
        if ($email !== '') {
            $name = explode('@', $email)[0];
        } elseif ($id !== '') {
            $name = $id;
        } else {
            $name = 'AI';
        }
    }
    $label = $name;
    if ($email !== '' && strcasecmp($name, $email) !== 0) {
        $label = $name . ' (' . $email . ')';
    }
    return [
        'id' => $id !== '' ? $id : null,
        'email' => $email !== '' ? $email : null,
        'name' => $name,
        'label' => $label,
    ];
}

/** @return array<string, array{description: string, write: bool, scope: string}> */
function commerce_mcp_admin_action_meta(): array
{
    static $meta = null;
    if ($meta !== null) {
        return $meta;
    }
    $meta = [];
    foreach (commerce_mcp_admin_action_catalog() as $group) {
        foreach ($group['actions'] as $row) {
            $meta[$row['action']] = [
                'description' => $row['description'],
                'write' => !empty($row['write']),
                'scope' => (string) ($row['scope'] ?? 'settings'),
            ];
        }
    }
    return $meta;
}

/** @return list<array{group: string, actions: list<array{action: string, description: string, write?: bool, scope?: string}>}> */
function commerce_mcp_admin_action_catalog(): array
{
    return [
        [
            'group' => 'catalog',
            'actions' => [
                ['action' => 'list_catalog', 'description' => 'List indexed sellable catalog items', 'scope' => 'settings'],
                ['action' => 'reindex_catalog', 'description' => 'Rebuild catalog index and reconcile inventory', 'write' => true, 'scope' => 'settings'],
                ['action' => 'rebuild_catalog', 'description' => 'Alias for reindex_catalog', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'inventory',
            'actions' => [
                ['action' => 'save_stock_mode', 'description' => 'Set inventory mode (simple, locations, unlimited)', 'write' => true, 'scope' => 'settings'],
                ['action' => 'reconcile_inventory', 'description' => 'Reconcile catalog stock vs ledger', 'write' => true, 'scope' => 'settings'],
                ['action' => 'list_warehouse_stock', 'description' => 'List warehouse stock rows', 'scope' => 'settings'],
                ['action' => 'save_warehouse_stock', 'description' => 'Set SKU stock quantity/threshold', 'write' => true, 'scope' => 'settings'],
                ['action' => 'list_warehouses', 'description' => 'List warehouses (locations mode)', 'scope' => 'settings'],
                ['action' => 'save_warehouse', 'description' => 'Create or update a warehouse', 'write' => true, 'scope' => 'settings'],
                ['action' => 'delete_warehouse', 'description' => 'Delete a warehouse', 'write' => true, 'scope' => 'settings'],
                ['action' => 'transfer_warehouse_stock', 'description' => 'Transfer stock between warehouses', 'write' => true, 'scope' => 'settings'],
                ['action' => 'get_inventory_webhook_config', 'description' => 'Shopify/Woo inventory webhook URLs and status', 'scope' => 'settings'],
                ['action' => 'rotate_inventory_webhook_secret', 'description' => 'Rotate live import webhook secret', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'orders',
            'actions' => [
                ['action' => 'list_orders', 'description' => 'List orders (auto-reconcile pending payments)', 'scope' => 'orders'],
                ['action' => 'get_order', 'description' => 'Get one order by id', 'scope' => 'orders'],
                ['action' => 'refund_order', 'description' => 'Refund order (full or partial)', 'write' => true, 'scope' => 'orders'],
                ['action' => 'cancel_order', 'description' => 'Cancel order with optional refund', 'write' => true, 'scope' => 'orders'],
                ['action' => 'update_order_shipment', 'description' => 'Ship a single order line', 'write' => true, 'scope' => 'orders'],
                ['action' => 'create_shipment', 'description' => 'Create multi-item shipment on order', 'write' => true, 'scope' => 'orders'],
                ['action' => 'add_order_note', 'description' => 'Append internal order note', 'write' => true, 'scope' => 'orders'],
                ['action' => 'set_order_tags', 'description' => 'Set order tags', 'write' => true, 'scope' => 'orders'],
                ['action' => 'bulk_mark_shipped', 'description' => 'Bulk mark orders shipped', 'write' => true, 'scope' => 'orders'],
                ['action' => 'customer_timeline', 'description' => 'Customer order timeline by email', 'scope' => 'orders'],
                ['action' => 'export_orders_csv', 'description' => 'Export orders as CSV', 'write' => true, 'scope' => 'orders'],
                ['action' => 'sync_order_payment', 'description' => 'Sync order payment state from provider', 'write' => true, 'scope' => 'orders'],
                ['action' => 'resend_order_email', 'description' => 'Resend order receipt email', 'write' => true, 'scope' => 'orders'],
                ['action' => 'reconcile_pending_payments', 'description' => 'Reconcile pending checkout payments', 'write' => true, 'scope' => 'orders'],
                ['action' => 'activity_counts', 'description' => 'Admin attention counts (orders, subs, fulfillment)', 'scope' => 'stats'],
                ['action' => 'list_fulfillment_desk', 'description' => 'Fulfillment desk queue', 'scope' => 'orders'],
                ['action' => 'packing_slips', 'description' => 'Generate packing slip HTML', 'write' => true, 'scope' => 'orders'],
            ],
        ],
        [
            'group' => 'invoices',
            'actions' => [
                ['action' => 'order_invoice', 'description' => 'Build invoice HTML for order', 'scope' => 'orders'],
                ['action' => 'issue_invoice', 'description' => 'Issue invoice number on order', 'write' => true, 'scope' => 'orders'],
                ['action' => 'get_invoice_profile', 'description' => 'Get invoice seller profile and templates', 'scope' => 'settings'],
                ['action' => 'save_invoice_profile', 'description' => 'Save invoice seller profile', 'write' => true, 'scope' => 'settings'],
                ['action' => 'list_invoice_templates', 'description' => 'List invoice templates', 'scope' => 'settings'],
                ['action' => 'save_invoice_template', 'description' => 'Save invoice template', 'write' => true, 'scope' => 'settings'],
                ['action' => 'duplicate_invoice_template', 'description' => 'Duplicate invoice template', 'write' => true, 'scope' => 'settings'],
                ['action' => 'delete_invoice_template', 'description' => 'Delete invoice template', 'write' => true, 'scope' => 'settings'],
                ['action' => 'preview_invoice', 'description' => 'Preview invoice HTML with sample order', 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'emails',
            'actions' => [
                ['action' => 'list_email_templates', 'description' => 'List transactional email templates', 'scope' => 'settings'],
                ['action' => 'save_email_template', 'description' => 'Save email template', 'write' => true, 'scope' => 'settings'],
                ['action' => 'save_email_delivery_settings', 'description' => 'Save email delivery settings', 'write' => true, 'scope' => 'settings'],
                ['action' => 'preview_email_template', 'description' => 'Preview email template', 'scope' => 'settings'],
                ['action' => 'send_test_email', 'description' => 'Send test email for template', 'write' => true, 'scope' => 'settings'],
                ['action' => 'list_email_log', 'description' => 'Recent email send log', 'scope' => 'settings'],
                ['action' => 'list_scheduled_emails', 'description' => 'List scheduled email jobs', 'scope' => 'settings'],
                ['action' => 'process_scheduled_emails', 'description' => 'Process due scheduled emails', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'customers',
            'actions' => [
                ['action' => 'list_customers', 'description' => 'List customers', 'scope' => 'orders'],
                ['action' => 'get_customer', 'description' => 'Get customer by id or email', 'scope' => 'orders'],
                ['action' => 'save_customer', 'description' => 'Create or update customer', 'write' => true, 'scope' => 'orders'],
                ['action' => 'import_customers_csv', 'description' => 'Import customers from CSV', 'write' => true, 'scope' => 'orders'],
                ['action' => 'delete_customer', 'description' => 'Delete customer', 'write' => true, 'scope' => 'orders'],
            ],
        ],
        [
            'group' => 'subscriptions',
            'actions' => [
                ['action' => 'list_subscriptions', 'description' => 'List recurring subscriptions', 'scope' => 'orders'],
                ['action' => 'get_subscription', 'description' => 'Get subscription by id', 'scope' => 'orders'],
                ['action' => 'cancel_subscription', 'description' => 'Cancel subscription', 'write' => true, 'scope' => 'orders'],
                ['action' => 'pause_subscription', 'description' => 'Pause subscription billing', 'write' => true, 'scope' => 'orders'],
                ['action' => 'resume_subscription', 'description' => 'Resume paused subscription', 'write' => true, 'scope' => 'orders'],
                ['action' => 'list_subscription_upgrade_options', 'description' => 'List upgrade options for subscription', 'scope' => 'orders'],
                ['action' => 'upgrade_subscription', 'description' => 'Upgrade subscription purchase option', 'write' => true, 'scope' => 'orders'],
                ['action' => 'retry_subscription_payment', 'description' => 'Retry failed subscription payment', 'write' => true, 'scope' => 'orders'],
            ],
        ],
        [
            'group' => 'discounts',
            'actions' => [
                ['action' => 'list_discounts', 'description' => 'List discount rules', 'scope' => 'settings'],
                ['action' => 'save_discount', 'description' => 'Save discount rule', 'write' => true, 'scope' => 'settings'],
                ['action' => 'delete_discount', 'description' => 'Delete discount rule', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'import',
            'actions' => [
                ['action' => 'import_sources', 'description' => 'List CSV import presets', 'scope' => 'settings'],
                ['action' => 'import_collections', 'description' => 'List import target collections', 'scope' => 'settings'],
                ['action' => 'import_history', 'description' => 'List import history', 'scope' => 'settings'],
                ['action' => 'import_detail', 'description' => 'Get import record detail', 'scope' => 'settings'],
                ['action' => 'import_dry_run', 'description' => 'Dry-run CSV import parse', 'scope' => 'settings'],
                ['action' => 'import_csv', 'description' => 'Run CSV import', 'write' => true, 'scope' => 'settings'],
                ['action' => 'import_rollback', 'description' => 'Rollback import batch', 'write' => true, 'scope' => 'settings'],
                ['action' => 'import_live_config', 'description' => 'Live import platform config', 'scope' => 'settings'],
                ['action' => 'import_live_save', 'description' => 'Save live import config', 'write' => true, 'scope' => 'settings'],
                ['action' => 'import_live_test', 'description' => 'Test live import connection', 'scope' => 'settings'],
                ['action' => 'import_live_preview', 'description' => 'Preview live import sync', 'scope' => 'settings'],
                ['action' => 'import_live_sync', 'description' => 'Run live import sync', 'write' => true, 'scope' => 'settings'],
                ['action' => 'shopify_cutover_test', 'description' => 'Test Shopify cutover connection', 'scope' => 'settings'],
                ['action' => 'shopify_cutover_dry_run', 'description' => 'Shopify cutover dry run', 'scope' => 'settings'],
                ['action' => 'shopify_cutover_import', 'description' => 'Run Shopify cutover import', 'write' => true, 'scope' => 'settings'],
                ['action' => 'shopify_cutover_rollback', 'description' => 'Rollback Shopify cutover batch', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'mappings',
            'actions' => [
                ['action' => 'list_mappings', 'description' => 'List purchase mappings', 'scope' => 'settings'],
                ['action' => 'save_mapping', 'description' => 'Save purchase mapping', 'write' => true, 'scope' => 'settings'],
                ['action' => 'delete_mapping', 'description' => 'Delete purchase mapping', 'write' => true, 'scope' => 'settings'],
                ['action' => 'list_membership_tiers', 'description' => 'List user-management tiers for mappings', 'scope' => 'settings'],
                ['action' => 'mapping_wizard_data', 'description' => 'Mapping wizard catalog/tiers data', 'scope' => 'settings'],
                ['action' => 'create_membership_mapping', 'description' => 'Create membership purchase mapping', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'fulfillment',
            'actions' => [
                ['action' => 'list_fulfillment', 'description' => 'List fulfillment adapter connections', 'scope' => 'settings'],
                ['action' => 'test_fulfillment', 'description' => 'Test fulfillment adapter connection', 'scope' => 'settings'],
                ['action' => 'save_fulfillment', 'description' => 'Save fulfillment connections', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'shipping',
            'actions' => [
                ['action' => 'list_shipping_zones', 'description' => 'List shipping zones and provider', 'scope' => 'settings'],
                ['action' => 'save_shipping_zones', 'description' => 'Save shipping zones', 'write' => true, 'scope' => 'settings'],
                ['action' => 'list_shipping_rate_providers', 'description' => 'List shipping rate providers', 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'tax',
            'actions' => [
                ['action' => 'list_tax_rules', 'description' => 'List tax rules', 'scope' => 'settings'],
                ['action' => 'save_tax_rules', 'description' => 'Save tax rules', 'write' => true, 'scope' => 'settings'],
                ['action' => 'list_tax_providers', 'description' => 'List tax providers', 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'fieldtypes',
            'actions' => [
                ['action' => 'list_fieldtype_profiles', 'description' => 'List commerce fieldtype profiles', 'scope' => 'settings'],
                ['action' => 'save_fieldtype_profile', 'description' => 'Save fieldtype profile', 'write' => true, 'scope' => 'settings'],
                ['action' => 'delete_fieldtype_profile', 'description' => 'Delete fieldtype profile', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'migration',
            'actions' => [
                ['action' => 'migration_scan', 'description' => 'Scan legacy payments data', 'scope' => 'settings'],
                ['action' => 'migration_preview', 'description' => 'Preview legacy migration', 'scope' => 'settings'],
                ['action' => 'migration_import', 'description' => 'Run legacy migration import', 'write' => true, 'scope' => 'settings'],
                ['action' => 'migration_history', 'description' => 'List migration history', 'scope' => 'settings'],
                ['action' => 'migration_rollback', 'description' => 'Rollback migration batch', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'gift_cards',
            'actions' => [
                ['action' => 'list_gift_cards', 'description' => 'List gift cards', 'scope' => 'settings'],
                ['action' => 'issue_gift_card', 'description' => 'Issue gift card', 'write' => true, 'scope' => 'settings'],
                ['action' => 'void_gift_card', 'description' => 'Void gift card', 'write' => true, 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'draft_orders',
            'actions' => [
                ['action' => 'create_quote', 'description' => 'Create quote from session cart', 'write' => true, 'scope' => 'orders'],
                ['action' => 'list_quotes', 'description' => 'List quotes/draft orders', 'scope' => 'orders'],
                ['action' => 'get_quote_admin', 'description' => 'Get quote by id (admin)', 'scope' => 'orders'],
                ['action' => 'cancel_quote', 'description' => 'Cancel quote', 'write' => true, 'scope' => 'orders'],
                ['action' => 'draft_order_create', 'description' => 'Create draft order', 'write' => true, 'scope' => 'orders'],
                ['action' => 'draft_order_update', 'description' => 'Update draft order', 'write' => true, 'scope' => 'orders'],
                ['action' => 'draft_order_preview', 'description' => 'Preview draft order totals', 'scope' => 'orders'],
                ['action' => 'draft_order_get', 'description' => 'Get draft order', 'scope' => 'orders'],
                ['action' => 'draft_order_search_catalog', 'description' => 'Search catalog for draft order lines', 'scope' => 'orders'],
                ['action' => 'draft_order_checkout', 'description' => 'Merchant-assisted draft order checkout', 'write' => true, 'scope' => 'orders'],
            ],
        ],
        [
            'group' => 'bundles',
            'actions' => [
                ['action' => 'bundle_validate', 'description' => 'Validate bundle components', 'scope' => 'settings'],
                ['action' => 'bundle_preview_price', 'description' => 'Preview bundle price', 'scope' => 'settings'],
            ],
        ],
        [
            'group' => 'analytics',
            'actions' => [
                ['action' => 'analytics_summary', 'description' => 'Analytics summary for date range', 'scope' => 'stats'],
                ['action' => 'analytics_export_csv', 'description' => 'Export analytics orders CSV', 'scope' => 'stats'],
            ],
        ],
    ];
}

/** @return array{status: string, message?: string}|null */
function commerce_mcp_admin_require_permission(string $action, array $aiUser): ?array
{
    $meta = commerce_mcp_admin_action_meta();
    if (!isset($meta[$action])) {
        return ['status' => 'error', 'message' => 'Unknown admin action: ' . $action];
    }
    $row = $meta[$action];
    if (!empty($row['write'])) {
        return commerce_mcp_require($aiUser, 'manage_commerce');
    }
    $scope = $row['scope'];
    if ($scope === 'stats') {
        return commerce_mcp_require($aiUser, 'view_commerce_stats');
    }
    if ($scope === 'orders') {
        return commerce_mcp_require($aiUser, 'view_commerce_orders');
    }
    return commerce_mcp_require_any($aiUser, ['manage_commerce', 'view_commerce_orders', 'view_commerce_stats']);
}

/** @return array<string, mixed> */
function commerce_mcp_admin_services(): array
{
    if (!commerce_plugin_active()) {
        throw new RuntimeException('Commerce plugin is not active');
    }
    commerce_bootstrap();
    commerce_bootstrap_cart_services();

    $cart = new CommerceCartSession();
    $catalog = new CommerceCatalog();
    $orders = new CommerceOrderStore();
    $checkout = new CommerceCheckoutService($orders, $catalog, $cart);
    $indexer = new CatalogIndexer();
    $discounts = new DiscountEngine();
    $import = new ImportService($indexer);
    require_once dirname(__DIR__) . '/includes/LegacyMigrationService.php';
    $migration = new LegacyMigrationService($indexer);
    require_once dirname(__DIR__) . '/includes/CommerceLiveImportService.php';
    $liveImport = new CommerceLiveImportService(null, $import);
    $mappings = new PurchaseMappingService();
    require_once dirname(__DIR__) . '/includes/CommerceFieldtypeProfileStore.php';
    $fieldtypeProfiles = new CommerceFieldtypeProfileStore();
    require_once dirname(__DIR__) . '/includes/CommerceSubscriptionStore.php';
    require_once dirname(__DIR__) . '/includes/CommerceSubscriptionService.php';
    require_once dirname(__DIR__) . '/includes/SubscriptionUpgradeService.php';
    require_once dirname(__DIR__) . '/includes/CommerceOrderOps.php';
    $subscriptionStore = new CommerceSubscriptionStore();
    $subscriptions = new CommerceSubscriptionService($subscriptionStore, commerce_bootstrap());
    $orderOps = new CommerceOrderOps($orders, $subscriptionStore);
    $subscriptionUpgrades = new SubscriptionUpgradeService($subscriptionStore, commerce_bootstrap(), $catalog);
    $giftCards = new GiftCardStore();
    $customers = new CommerceCustomerStore();
    $quoteStore = new CommerceQuoteStore();
    $draftOrders = new CommerceDraftOrderService($quoteStore, $catalog, $discounts, $checkout);
    $analytics = new CommerceAnalyticsService($orders);

    return compact(
        'cart',
        'catalog',
        'orders',
        'checkout',
        'indexer',
        'discounts',
        'import',
        'migration',
        'liveImport',
        'mappings',
        'fieldtypeProfiles',
        'subscriptionStore',
        'subscriptions',
        'orderOps',
        'subscriptionUpgrades',
        'giftCards',
        'customers',
        'quoteStore',
        'draftOrders',
        'analytics'
    );
}

// Dispatch implementation continues in commerce_mcp_dispatch_admin() below.

/**
 * @param array<string, mixed> $input
 * @param array<string, mixed> $aiUser
 * @return array{status: string, data?: mixed, message?: string, warning?: string}
 */
function commerce_mcp_dispatch_admin(string $action, array $input, array $aiUser): array
{
    if ($err = commerce_mcp_admin_require_permission($action, $aiUser)) {
        return $err;
    }

    try {
        $s = commerce_mcp_admin_services();
    } catch (Throwable $e) {
        return ['status' => 'error', 'message' => $e->getMessage()];
    }

    extract($s, EXTR_SKIP);
    $actor = commerce_mcp_admin_actor($aiUser);

    switch ($action) {
        case 'list_catalog':
            return ['status' => 'ok', 'data' => ['catalog' => $catalog->listItems($input['filters'] ?? [])]];

        case 'reindex_catalog':
        case 'rebuild_catalog':
            $count = $indexer->reindexAll();
            $report = commerce_inventory_ledger($indexer)->reconcile(true);
            return ['status' => 'ok', 'data' => ['indexed' => $count, 'inventory' => $report]];

        case 'save_stock_mode':
            $mode = InventoryLedger::saveMode((string) ($input['mode'] ?? 'simple'));
            $report = commerce_inventory_ledger($indexer)->reconcile(true);
            return ['status' => 'ok', 'data' => ['mode' => $mode, 'inventory' => $report]];

        case 'reconcile_inventory':
            $apply = !empty($input['apply']);
            return ['status' => 'ok', 'data' => commerce_inventory_ledger($indexer)->reconcile($apply)];

        case 'list_orders':
            $reconcile = $checkout->reconcilePendingPayments(50);
            $orders->ensureOrderNumbers();
            $includeAbandoned = !empty($input['include_abandoned']);
            $allOrders = $orders->listAll();
            if (!$includeAbandoned) {
                $allOrders = array_values(array_filter($allOrders, static fn ($order) => ($order['status'] ?? '') !== 'abandoned'));
            }
            $allOrders = array_map(static fn ($order) => $orderOps->enrichOrder($order), $allOrders);
            return ['status' => 'ok', 'data' => ['orders' => $allOrders, 'reconcile' => $reconcile]];

        case 'get_order':
            $id = (string) ($input['id'] ?? '');
            $order = $orders->get($id);
            if (!$order) {
                return ['status' => 'error', 'message' => 'Order not found'];
            }
            if (empty($order['order_number'])) {
                $number = $orders->allocateOrderNumber($order['created_at'] ?? null);
                $order = $orders->update($id, ['order_number' => $number]) ?? $order;
            }
            return ['status' => 'ok', 'data' => ['order' => $orderOps->enrichOrder($order)]];

        case 'update_order_shipment':
            $id = (string) ($input['id'] ?? '');
            $lineId = (string) ($input['line_id'] ?? '');
            if ($id === '' || $lineId === '') {
                return ['status' => 'error', 'message' => 'id and line_id required'];
            }
            $result = $orderOps->createShipment($id, [
                'line_id' => $lineId,
                'tracking_number' => (string) ($input['tracking_number'] ?? ''),
                'carrier' => (string) ($input['carrier'] ?? ''),
                'shipped_at' => isset($input['shipped_at']) ? (string) $input['shipped_at'] : null,
                'notify_customer' => !empty($input['notify_customer']),
                'package_count' => (int) ($input['package_count'] ?? 1),
                'items' => is_array($input['items'] ?? null) ? $input['items'] : null,
            ]);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Shipment update failed'];
            }
            if (!empty($result['order'])) {
                $result['order'] = $orderOps->enrichOrder($result['order']);
            }
            return ['status' => 'ok', 'data' => $result];

        case 'list_fulfillment_desk':
            $desk = $orderOps->listFulfillmentDesk(
                (string) ($input['view'] ?? 'open'),
                (string) ($input['search'] ?? ''),
                $actor
            );
            return ['status' => 'ok', 'data' => $desk];

        case 'create_shipment':
            $id = (string) ($input['id'] ?? '');
            if ($id === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $result = $orderOps->createShipment($id, [
                'items' => is_array($input['items'] ?? null) ? $input['items'] : [],
                'tracking_number' => (string) ($input['tracking_number'] ?? ''),
                'carrier' => (string) ($input['carrier'] ?? ''),
                'package_count' => (int) ($input['package_count'] ?? 1),
                'notify_customer' => !empty($input['notify_customer']),
                'shipped_at' => isset($input['shipped_at']) ? (string) $input['shipped_at'] : null,
                'acted_by' => $actor,
            ]);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Shipment failed'];
            }
            if (!empty($result['order'])) {
                $result['order'] = $orderOps->enrichOrder($result['order']);
            }
            return ['status' => 'ok', 'data' => $result];

        case 'add_order_note':
            $id = (string) ($input['id'] ?? '');
            $author = (string) ($input['author'] ?? '');
            if ($author === '') {
                $author = $actor['label'];
            }
            $body = (string) ($input['body'] ?? $input['note'] ?? '');
            $result = $orderOps->addNote($id, $body, $author, $actor);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Failed to add note'];
            }
            return ['status' => 'ok', 'data' => ['order' => $orderOps->enrichOrder($result['order'] ?? [])]];

        case 'set_order_tags':
            $id = (string) ($input['id'] ?? '');
            $tags = $input['tags'] ?? [];
            if (!is_array($tags) && is_string($tags)) {
                $tags = array_map('trim', explode(',', $tags));
            }
            if (!is_array($tags)) {
                $tags = [];
            }
            $result = $orderOps->setTags($id, $tags);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Failed to set tags'];
            }
            return ['status' => 'ok', 'data' => ['order' => $orderOps->enrichOrder($result['order'] ?? [])]];

        case 'bulk_mark_shipped':
            $ids = $input['ids'] ?? [];
            if (!is_array($ids) || !$ids) {
                return ['status' => 'error', 'message' => 'ids required'];
            }
            $result = $orderOps->bulkMarkShipped(
                $ids,
                (string) ($input['carrier'] ?? ''),
                (string) ($input['tracking_prefix'] ?? ''),
                !empty($input['notify_customer']),
                $actor
            );
            $result['updated'] = array_map(static fn ($order) => $orderOps->enrichOrder($order), $result['updated'] ?? []);
            return [
                'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
                'data' => $result,
                'message' => empty($result['updated']) ? 'No orders updated' : null,
            ];

        case 'customer_timeline':
            $email = (string) ($input['email'] ?? '');
            $timeline = $orderOps->customerTimeline($email, $customers);
            $timeline['orders'] = array_map(static fn ($order) => $orderOps->enrichOrder($order), $timeline['orders'] ?? []);
            if (!empty($timeline['customer']) && is_array($timeline['customer'])) {
                $timeline['user_management'] = $customers->resolveUserManagementLink($timeline['customer']);
            } else {
                $timeline['user_management'] = [
                    'user_id' => null,
                    'user_name' => null,
                    'user_email' => null,
                    'admin_url' => null,
                    'active' => function_exists('birkly_is_plugin_active') && birkly_is_plugin_active('user_management'),
                ];
            }
            return ['status' => 'ok', 'data' => $timeline];

        case 'list_customers':
            $search = (string) ($input['search'] ?? '');
            $backfill = [];
            if ($customers->count() === 0) {
                $backfill = $customers->backfillFromOrders($orders, false);
            }
            return ['status' => 'ok', 'data' => ['customers' => $customers->list($search), 'backfill' => $backfill]];

        case 'get_customer':
            $id = (string) ($input['id'] ?? '');
            $email = (string) ($input['email'] ?? '');
            $customer = $id !== '' ? $customers->getById($id) : null;
            if (!$customer && $email !== '') {
                $customer = $customers->getByEmail($email);
            }
            if (!$customer) {
                return ['status' => 'error', 'message' => 'Customer not found'];
            }
            $timeline = $orderOps->customerTimeline((string) $customer['email'], $customers);
            $timeline['orders'] = array_map(static fn ($order) => $orderOps->enrichOrder($order), $timeline['orders'] ?? []);
            return [
                'status' => 'ok',
                'data' => [
                    'customer' => $customer,
                    'timeline' => $timeline,
                    'user_management' => $customers->resolveUserManagementLink($customer),
                ],
            ];

        case 'save_customer':
            try {
                $payload = $input['customer'] ?? $input;
                if (!is_array($payload)) {
                    throw new InvalidArgumentException('Invalid customer payload');
                }
                unset($payload['action'], $payload['_csrf'], $payload['password'], $payload['password_hash'], $payload['passwd']);
                $cid = (string) ($payload['id'] ?? '');
                if ($cid !== '' && $customers->getById($cid)) {
                    $saved = $customers->update($cid, $payload);
                } else {
                    $saved = $customers->upsert($payload);
                }
                return [
                    'status' => 'ok',
                    'data' => [
                        'customer' => $saved,
                        'user_management' => $customers->resolveUserManagementLink($saved),
                    ],
                ];
            } catch (Throwable $e) {
                return ['status' => 'error', 'message' => $e->getMessage()];
            }

        case 'import_customers_csv':
            $csv = (string) ($input['csv'] ?? '');
            if (trim($csv) === '') {
                return ['status' => 'error', 'message' => 'CSV content is required'];
            }
            return ['status' => 'ok', 'data' => $customers->importCsv($csv)];

        case 'delete_customer':
            $id = (string) ($input['id'] ?? '');
            $ok = $id !== '' && $customers->delete($id);
            return ['status' => $ok ? 'ok' : 'error', 'message' => $ok ? null : 'Customer not found'];

        case 'export_orders_csv':
            $ids = $input['ids'] ?? null;
            $selected = [];
            if (is_array($ids) && $ids) {
                foreach ($ids as $oid) {
                    $order = $orders->get((string) $oid);
                    if ($order) {
                        $selected[] = $order;
                    }
                }
            } else {
                $selected = $orders->listAll();
            }
            $csv = $orderOps->exportOrdersCsv($selected);
            return [
                'status' => 'ok',
                'data' => [
                    'filename' => 'orders-' . date('Ymd-His') . '.csv',
                    'csv' => $csv,
                    'count' => count($selected),
                ],
            ];

        case 'order_invoice':
            $id = (string) ($input['id'] ?? '');
            $order = $orders->get($id);
            if (!$order) {
                return ['status' => 'error', 'message' => 'Order not found'];
            }
            if (empty($order['order_number'])) {
                $number = $orders->allocateOrderNumber($order['created_at'] ?? null);
                $order = $orders->update($id, ['order_number' => $number]) ?? $order;
            }
            $brand = [];
            if (trim((string) ($input['brand_name'] ?? '')) !== '') {
                $brand['name'] = (string) $input['brand_name'];
            }
            if (trim((string) ($input['brand_email'] ?? '')) !== '') {
                $brand['email'] = (string) $input['brand_email'];
            }
            if (trim((string) ($input['brand_address'] ?? '')) !== '') {
                $brand['address'] = (string) $input['brand_address'];
            }
            $html = $orderOps->buildInvoiceHtml($order, $brand);
            $fresh = $orders->get($id) ?? $order;
            return ['status' => 'ok', 'data' => ['html' => $html, 'order' => $orderOps->enrichOrder($fresh)]];

        case 'issue_invoice':
            $id = (string) ($input['id'] ?? '');
            $invoiceSvc = new CommerceInvoiceService(null, $orders);
            $result = $invoiceSvc->ensureInvoice($id);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Issue failed'];
            }
            return [
                'status' => 'ok',
                'data' => [
                    'order' => $orderOps->enrichOrder($result['order'] ?? []),
                    'issued' => !empty($result['issued']),
                    'invoice_number' => $result['order']['invoice_number'] ?? null,
                ],
            ];

        case 'get_invoice_profile':
            $invoiceSvc = new CommerceInvoiceService(null, $orders);
            return [
                'status' => 'ok',
                'data' => [
                    'profile' => $invoiceSvc->getProfile(),
                    'templates' => $invoiceSvc->listTemplates(),
                    'tokens' => $invoiceSvc->availableTokens(),
                    'preset_ids' => CommerceInvoiceService::TEMPLATES,
                ],
            ];

        case 'save_invoice_profile':
            $invoiceSvc = new CommerceInvoiceService(null, $orders);
            $profile = $invoiceSvc->saveProfile(is_array($input['profile'] ?? null) ? $input['profile'] : $input);
            return ['status' => 'ok', 'data' => ['profile' => $profile]];

        case 'list_invoice_templates':
            $invoiceSvc = new CommerceInvoiceService(null, $orders);
            return [
                'status' => 'ok',
                'data' => [
                    'templates' => $invoiceSvc->listTemplates(),
                    'tokens' => $invoiceSvc->availableTokens(),
                ],
            ];

        case 'save_invoice_template':
            $invoiceSvc = new CommerceInvoiceService(null, $orders);
            $tpl = is_array($input['template'] ?? null) ? $input['template'] : $input;
            $saved = $invoiceSvc->saveTemplate($tpl);
            return ['status' => 'ok', 'data' => ['template' => $saved, 'templates' => $invoiceSvc->listTemplates()]];

        case 'duplicate_invoice_template':
            $invoiceSvc = new CommerceInvoiceService(null, $orders);
            $dup = $invoiceSvc->duplicateTemplate(
                (string) ($input['id'] ?? ''),
                isset($input['name']) ? (string) $input['name'] : null
            );
            if (!($dup['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $dup['error'] ?? 'Duplicate failed'];
            }
            return [
                'status' => 'ok',
                'data' => [
                    'template' => $dup['template'],
                    'templates' => $invoiceSvc->listTemplates(),
                ],
            ];

        case 'delete_invoice_template':
            $invoiceSvc = new CommerceInvoiceService(null, $orders);
            $del = $invoiceSvc->deleteTemplate((string) ($input['id'] ?? ''));
            if (!($del['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $del['error'] ?? 'Delete failed'];
            }
            return ['status' => 'ok', 'data' => ['templates' => $invoiceSvc->listTemplates()]];

        case 'preview_invoice':
            $invoiceSvc = new CommerceInvoiceService(null, $orders);
            $profile = $invoiceSvc->getProfile();
            if (is_array($input['profile'] ?? null)) {
                $profile = array_merge($profile, $input['profile']);
            }
            $bodyOverride = isset($input['body_html']) && is_string($input['body_html']) ? $input['body_html'] : null;
            if (!empty($input['template_id'])) {
                $profile['template'] = (string) $input['template_id'];
            }
            $sample = [
                'id' => 'cord_preview',
                'order_number' => 'ORD-PREVIEW',
                'invoice_number' => 'INV-' . date('Y') . '-0000',
                'invoice_issued_at' => date('c'),
                'invoice_seller_snapshot' => $profile,
                'status' => 'paid',
                'customer_email' => 'customer@example.com',
                'customer_name' => 'Ada Buyer',
                'vat_id' => 'DE999999999',
                'currency' => 'eur',
                'total_cents' => 4590,
                'shipping_cents' => 450,
                'tax_cents' => 740,
                'discount_cents' => 0,
                'billing_address' => [
                    'name' => 'Ada Buyer',
                    'line1' => '1 Sample Street',
                    'postal_code' => '10115',
                    'city' => 'Berlin',
                    'country' => 'DE',
                ],
                'shipping_address' => [
                    'name' => 'Ada Buyer',
                    'line1' => '1 Sample Street',
                    'postal_code' => '10115',
                    'city' => 'Berlin',
                    'country' => 'DE',
                ],
                'lines' => [
                    ['title' => 'Ceramic Mug', 'sku' => 'MUG-1', 'quantity' => 1, 'line_total_cents' => 2400],
                    ['title' => 'Sticker Pack', 'sku' => 'STK-1', 'quantity' => 2, 'line_total_cents' => 1000],
                ],
            ];
            $html = $invoiceSvc->buildInvoiceHtml($sample, [], false, $bodyOverride);
            return ['status' => 'ok', 'data' => ['html' => $html]];

        case 'list_email_templates':
            $emailSvc = new CommerceEmailService();
            return [
                'status' => 'ok',
                'data' => [
                    'templates' => $emailSvc->listTemplates(),
                    'tokens' => $emailSvc->availableTokens(),
                    'triggers' => CommerceEmailService::TRIGGERS,
                    'trigger_labels' => $emailSvc->triggerLabels(),
                    'delay_anchors' => CommerceEmailService::DELAY_ANCHORS,
                    'scheduled' => $emailSvc->listScheduled(30),
                    'delivery_settings' => $emailSvc->getDeliverySettings(),
                    'attachment_options' => CommerceEmailService::attachmentOptions(),
                ],
            ];

        case 'save_email_delivery_settings':
            $emailSvc = new CommerceEmailService();
            $settings = is_array($input['settings'] ?? null) ? $input['settings'] : $input;
            $saved = $emailSvc->saveDeliverySettings($settings);
            return ['status' => 'ok', 'data' => ['settings' => $saved]];

        case 'save_email_template':
            $emailSvc = new CommerceEmailService();
            $tpl = is_array($input['template'] ?? null) ? $input['template'] : $input;
            $saved = $emailSvc->saveTemplate($tpl);
            return ['status' => 'ok', 'data' => ['template' => $saved]];

        case 'list_scheduled_emails':
            $emailSvc = new CommerceEmailService();
            $limit = max(1, min(200, (int) ($input['limit'] ?? 50)));
            return ['status' => 'ok', 'data' => ['jobs' => $emailSvc->listScheduled($limit)]];

        case 'process_scheduled_emails':
            $emailSvc = new CommerceEmailService();
            return ['status' => 'ok', 'data' => $emailSvc->processDueScheduledEmails()];

        case 'preview_email_template':
            $emailSvc = new CommerceEmailService();
            $templateId = (string) ($input['id'] ?? $input['template_id'] ?? '');
            $preview = $emailSvc->preview($templateId);
            if (!($preview['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $preview['error'] ?? 'Preview failed'];
            }
            return ['status' => 'ok', 'data' => $preview];

        case 'send_test_email':
            $emailSvc = new CommerceEmailService();
            $templateId = (string) ($input['id'] ?? $input['template_id'] ?? '');
            $to = trim((string) ($input['to'] ?? ''));
            if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
                return ['status' => 'error', 'message' => 'Valid to email required'];
            }
            $tpl = null;
            foreach ($emailSvc->listTemplates() as $row) {
                if (($row['id'] ?? '') === $templateId) {
                    $tpl = $row;
                    break;
                }
            }
            if (!$tpl) {
                return ['status' => 'error', 'message' => 'Template not found'];
            }
            $testWarning = empty($tpl['enabled'])
                ? 'Template is disabled — live order_paid sends will not use it until Enabled is checked and saved.'
                : null;
            $result = $emailSvc->sendTemplate($tpl, $emailSvc->sampleContext(), $to);
            return [
                'status' => !empty($result['ok']) ? 'ok' : 'error',
                'data' => $result,
                'message' => $result['error'] ?? $testWarning,
                'warning' => $testWarning,
            ];

        case 'list_email_log':
            $emailSvc = new CommerceEmailService();
            $limit = max(1, min(100, (int) ($input['limit'] ?? 20)));
            return ['status' => 'ok', 'data' => ['entries' => $emailSvc->recentLog($limit)]];

        case 'packing_slips':
            $ids = $input['ids'] ?? [];
            $shipmentId = isset($input['shipment_id']) ? (string) $input['shipment_id'] : '';
            $remainingOnly = !empty($input['remaining_only']);
            if ((!is_array($ids) || !$ids) && $shipmentId === '') {
                return ['status' => 'error', 'message' => 'ids required'];
            }
            if ($shipmentId !== '' && (!is_array($ids) || count($ids) !== 1)) {
                $orderId = (string) ($input['id'] ?? ($ids[0] ?? ''));
                if ($orderId === '') {
                    return ['status' => 'error', 'message' => 'id required with shipment_id'];
                }
                $ids = [$orderId];
            }
            $parts = [];
            foreach ($ids as $oid) {
                $order = $orders->get((string) $oid);
                if (!$order) {
                    continue;
                }
                $brand = ['name' => (string) ($input['brand_name'] ?? 'Packing slip')];
                if ($shipmentId !== '') {
                    $parts[] = $orderOps->buildPackingSlipHtml($order, $brand, $shipmentId, false);
                } else {
                    $enriched = $orderOps->enrichOrder($order);
                    $hasRemaining = false;
                    foreach ($enriched['lines'] ?? [] as $line) {
                        if (($line['fulfillment'] ?? '') === 'ship' && (int) ($line['quantity_remaining'] ?? 0) > 0) {
                            $hasRemaining = true;
                            break;
                        }
                    }
                    $parts[] = $orderOps->buildPackingSlipHtml(
                        $order,
                        $brand,
                        null,
                        $remainingOnly || $hasRemaining
                    );
                }
            }
            if (!$parts) {
                return ['status' => 'error', 'message' => 'No orders found'];
            }
            $html = $parts[0];
            for ($i = 1, $n = count($parts); $i < $n; $i++) {
                if (preg_match('#<body[^>]*>(.*)</body>#si', $parts[$i], $m)) {
                    $html = preg_replace('#</body></html>$#', '<div style="page-break-before:always"></div>' . $m[1] . '</body></html>', $html, 1);
                }
            }
            return ['status' => 'ok', 'data' => ['html' => $html, 'count' => count($parts)]];

        case 'list_subscriptions':
            $subscriptions->normalizeToSingleLineSubscriptions();
            return ['status' => 'ok', 'data' => ['subscriptions' => $subscriptionStore->listAll()]];

        case 'get_subscription':
            $id = (string) ($input['id'] ?? '');
            $subscription = $subscriptionStore->get($id);
            if (!$subscription) {
                return ['status' => 'error', 'message' => 'Subscription not found'];
            }
            return ['status' => 'ok', 'data' => ['subscription' => $subscription]];

        case 'cancel_subscription':
            $id = (string) ($input['id'] ?? '');
            if ($id === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $canceled = $subscriptions->cancel($id);
            if (!$canceled) {
                return ['status' => 'error', 'message' => 'Subscription not found'];
            }
            return ['status' => 'ok', 'data' => ['subscription' => $canceled]];

        case 'pause_subscription':
            $id = (string) ($input['id'] ?? '');
            if ($id === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $paused = $subscriptions->pause($id);
            if (!$paused) {
                return ['status' => 'error', 'message' => 'Subscription not found or cannot be paused'];
            }
            return ['status' => 'ok', 'data' => ['subscription' => $paused]];

        case 'resume_subscription':
            $id = (string) ($input['id'] ?? '');
            if ($id === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $resumed = $subscriptions->resume($id);
            if (!$resumed) {
                return ['status' => 'error', 'message' => 'Subscription not found or not paused'];
            }
            return ['status' => 'ok', 'data' => ['subscription' => $resumed]];

        case 'list_subscription_upgrade_options':
            $id = (string) ($input['id'] ?? '');
            if ($id === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $sub = $subscriptionStore->get($id);
            if (!$sub) {
                return ['status' => 'error', 'message' => 'Subscription not found'];
            }
            return ['status' => 'ok', 'data' => ['options' => $subscriptionUpgrades->listUpgradeOptions($id)]];

        case 'upgrade_subscription':
            $id = (string) ($input['id'] ?? '');
            $purchaseOptionId = (string) ($input['purchase_option_id'] ?? '');
            if ($id === '' || $purchaseOptionId === '') {
                return ['status' => 'error', 'message' => 'id and purchase_option_id required'];
            }
            $result = $subscriptionUpgrades->upgrade($id, $purchaseOptionId);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Upgrade failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'retry_subscription_payment':
            $id = (string) ($input['id'] ?? '');
            if ($id === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $result = $subscriptions->retryPayment($id);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Retry failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'list_discounts':
            return ['status' => 'ok', 'data' => ['rules' => array_values($discounts->listRules())]];

        case 'save_discount':
            $rule = $input['rule'] ?? [];
            if (!is_array($rule)) {
                return ['status' => 'error', 'message' => 'Invalid rule payload'];
            }
            try {
                $saved = $discounts->saveRule($rule);
                return ['status' => 'ok', 'data' => ['rule' => $saved]];
            } catch (Throwable $e) {
                return ['status' => 'error', 'message' => $e->getMessage()];
            }

        case 'delete_discount':
            $id = (string) ($input['id'] ?? '');
            $ok = $discounts->deleteRule($id);
            return ['status' => $ok ? 'ok' : 'error'];

        case 'import_sources':
            return ['status' => 'ok', 'data' => ['sources' => ImportService::getImportSources()]];

        case 'import_collections':
            return ['status' => 'ok', 'data' => ['collections' => $import->listImportCollections()]];

        case 'import_history':
            require_once dirname(__DIR__) . '/includes/ImportHistoryStore.php';
            $history = new ImportHistoryStore();
            $limit = max(1, min(100, (int) ($input['limit'] ?? 50)));
            return ['status' => 'ok', 'data' => ['imports' => $history->list($limit)]];

        case 'import_detail':
            require_once dirname(__DIR__) . '/includes/ImportHistoryStore.php';
            $importId = (string) ($input['id'] ?? '');
            if ($importId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $history = new ImportHistoryStore();
            $record = $history->get($importId);
            if ($record === null) {
                return ['status' => 'error', 'message' => 'Import not found'];
            }
            return ['status' => 'ok', 'data' => ['import' => $record]];

        case 'import_rollback':
            $importId = trim((string) ($input['id'] ?? ''));
            if ($importId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $deleteCollection = !array_key_exists('delete_collection', $input) || !empty($input['delete_collection']);
            $result = $import->rollbackImport($importId, $deleteCollection);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Rollback failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'import_dry_run':
            $csv = (string) ($input['csv'] ?? '');
            $preset = (string) ($input['preset'] ?? 'generic');
            $collection = (string) ($input['collection'] ?? 'products');
            $defaultCurrency = (string) ($input['default_currency'] ?? 'eur');
            $createCollection = !empty($input['create_collection']);
            $collectionTitle = trim((string) ($input['collection_title'] ?? ''));
            if ($createCollection && $collectionTitle !== '') {
                require_once dirname(__DIR__) . '/includes/ImportCollectionHelper.php';
                $collection = (new ImportCollectionHelper())->previewSlugForTitle($collectionTitle);
            }
            $parsed = $import->parseCsv($csv, $preset);
            if (!($parsed['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $parsed['error'] ?? 'Parse failed'];
            }
            $rows = $import->applyDefaultCurrency($parsed['rows'], $defaultCurrency);
            return ['status' => 'ok', 'data' => $import->dryRun($rows, $collection)];

        case 'import_csv':
            $csv = (string) ($input['csv'] ?? '');
            $preset = (string) ($input['preset'] ?? 'generic');
            $collection = (string) ($input['collection'] ?? 'products');
            $defaultCurrency = (string) ($input['default_currency'] ?? 'eur');
            $dryRun = !empty($input['dry_run']);
            $createCollection = !empty($input['create_collection']);
            $collectionTitle = trim((string) ($input['collection_title'] ?? ''));
            if ($createCollection && $collectionTitle !== '') {
                require_once dirname(__DIR__) . '/includes/ImportCollectionHelper.php';
                $collection = (new ImportCollectionHelper())->previewSlugForTitle($collectionTitle);
            }
            $parsed = $import->parseCsv($csv, $preset);
            if (!($parsed['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $parsed['error'] ?? 'Parse failed'];
            }
            $rows = $import->applyDefaultCurrency($parsed['rows'], $defaultCurrency);
            $result = $import->importRows($rows, $collection, $dryRun, [
                'preset' => $preset,
                'platform' => ImportService::platformName($preset),
                'currency' => $defaultCurrency,
                'file_name' => trim((string) ($input['file_name'] ?? '')) ?: null,
                'create_collection' => $createCollection,
                'collection_title' => $collectionTitle !== '' ? $collectionTitle : null,
            ]);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Import failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'import_live_config':
            return ['status' => 'ok', 'data' => $liveImport->getPublicConfig()];

        case 'import_live_save':
            $platform = trim((string) ($input['platform'] ?? ''));
            $patch = is_array($input['config'] ?? null) ? $input['config'] : $input;
            unset($patch['action'], $patch['_csrf'], $patch['platform']);
            $result = $liveImport->savePlatformConfig($platform, $patch);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Save failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'import_live_test':
            $platform = trim((string) ($input['platform'] ?? ''));
            $result = $liveImport->testConnection($platform);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Connection failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'import_live_preview':
            $platform = trim((string) ($input['platform'] ?? ''));
            $result = $liveImport->preview($platform);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Preview failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'shopify_cutover_test':
            require_once dirname(__DIR__) . '/includes/ShopifyCutoverService.php';
            $cutover = new ShopifyCutoverService();
            $result = $cutover->testConnection();
            return ['status' => ($result['ok'] ?? false) ? 'ok' : 'error', 'data' => $result, 'message' => $result['error'] ?? null];

        case 'shopify_cutover_dry_run':
            require_once dirname(__DIR__) . '/includes/ShopifyCutoverService.php';
            $cutover = new ShopifyCutoverService();
            $result = $cutover->dryRun($input['resources'] ?? 'all', $input);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Dry-run failed', 'data' => $result];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'shopify_cutover_import':
            require_once dirname(__DIR__) . '/includes/ShopifyCutoverService.php';
            $cutover = new ShopifyCutoverService();
            $result = $cutover->import($input['resources'] ?? 'all', $input);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Cutover import failed', 'data' => $result];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'shopify_cutover_rollback':
            require_once dirname(__DIR__) . '/includes/ShopifyCutoverService.php';
            $cutover = new ShopifyCutoverService();
            $batchId = trim((string) ($input['batch_id'] ?? ($input['id'] ?? '')));
            $result = $cutover->rollback($batchId, !empty($input['delete_collection']));
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Rollback failed', 'data' => $result];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'import_live_sync':
            $platform = trim((string) ($input['platform'] ?? ''));
            if ($platform === '') {
                return ['status' => 'error', 'message' => 'platform required'];
            }
            $result = $liveImport->syncPlatform($platform);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Sync failed', 'data' => $result];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'list_mappings':
            return ['status' => 'ok', 'data' => ['mappings' => $mappings->getMappings()]];

        case 'save_mapping':
            $key = (string) ($input['key'] ?? '');
            $config = $input['config'] ?? [];
            if ($key === '') {
                return ['status' => 'error', 'message' => 'key required'];
            }
            $mappings->setMapping($key, $config);
            return ['status' => 'ok'];

        case 'delete_mapping':
            $key = (string) ($input['key'] ?? '');
            $ok = $mappings->deleteMapping($key);
            return ['status' => $ok ? 'ok' : 'error'];

        case 'list_membership_tiers':
            $tiers = [];
            if (function_exists('birkly_is_plugin_active') && birkly_is_plugin_active('user_management')) {
                if (function_exists('birkly_plugin_require') && birkly_plugin_require('user_management', 'includes/UserStorage.php')) {
                    $userStorage = new UserStorage();
                    $tiers = $userStorage->listTiers();
                }
            }
            return ['status' => 'ok', 'data' => ['tiers' => $tiers, 'user_management_active' => !empty($tiers)]];

        case 'mapping_wizard_data':
            $tiers = [];
            if (function_exists('birkly_is_plugin_active') && birkly_is_plugin_active('user_management')) {
                if (function_exists('birkly_plugin_require') && birkly_plugin_require('user_management', 'includes/UserStorage.php')) {
                    $userStorage = new UserStorage();
                    $tiers = $userStorage->listTiers();
                }
            }
            return [
                'status' => 'ok',
                'data' => [
                    'catalog' => $catalog->listItems([]),
                    'tiers' => $tiers,
                    'mappings' => $mappings->getMappings(),
                    'user_management_active' => function_exists('birkly_is_plugin_active') && birkly_is_plugin_active('user_management'),
                ],
            ];

        case 'create_membership_mapping':
            $result = $mappings->createMembershipMapping($input);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Failed to create mapping'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'list_fulfillment':
            if (!class_exists('FulfillmentAdapterResolver')) {
                require_once dirname(__DIR__) . '/includes/FulfillmentAdapterResolver.php';
            }
            $connections = FulfillmentAdapterResolver::loadConnections();
            $secretSet = trim((string) (($connections['easypost']['webhook_secret'] ?? '') ?: '')) !== '';
            $connections['easypost'] = [
                'webhook_secret_set' => $secretSet,
                'api_key_set' => FulfillmentAdapterResolver::resolveEasyPostApiKey() !== '',
                'webhook_url' => FulfillmentAdapterResolver::webhookUrl(),
            ];
            return [
                'status' => 'ok',
                'data' => [
                    'connections' => $connections,
                    'available_adapters' => FulfillmentAdapterResolver::listAvailableAdapters(),
                ],
            ];

        case 'test_fulfillment':
            if (!class_exists('FulfillmentAdapterResolver')) {
                require_once dirname(__DIR__) . '/includes/FulfillmentAdapterResolver.php';
            }
            $adapterId = FulfillmentAdapterResolver::normalizeAdapterId($input['adapter'] ?? 'manual');
            if (!in_array($adapterId, ['manual', 'easypost'], true)) {
                return ['status' => 'error', 'message' => 'Unsupported fulfillment adapter'];
            }
            $adapter = FulfillmentAdapterResolver::resolve($adapterId);
            return ['status' => 'ok', 'data' => $adapter->testConnection()];

        case 'save_fulfillment':
            if (!class_exists('FulfillmentAdapterResolver')) {
                require_once dirname(__DIR__) . '/includes/FulfillmentAdapterResolver.php';
            }
            $data = $input['connections'] ?? [];
            $saved = FulfillmentAdapterResolver::saveConnections($data);
            $saved['easypost'] = [
                'webhook_secret_set' => trim((string) (($saved['easypost']['webhook_secret'] ?? '') ?: '')) !== '',
                'api_key_set' => FulfillmentAdapterResolver::resolveEasyPostApiKey() !== '',
                'webhook_url' => FulfillmentAdapterResolver::webhookUrl(),
            ];
            return ['status' => 'ok', 'data' => ['connections' => $saved]];

        case 'refund_order':
            $id = (string) ($input['id'] ?? '');
            if ($id === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $amountRaw = $input['amount_cents'] ?? null;
            $amountCents = ($amountRaw === null || $amountRaw === '') ? null : (int) $amountRaw;
            $reason = (string) ($input['reason'] ?? '');
            $lineId = isset($input['line_id']) ? (string) $input['line_id'] : null;
            if ($lineId === '') {
                $lineId = null;
            }
            $result = $checkout->refundOrder($id, $amountCents, $reason, $lineId);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Refund failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'cancel_order':
            $id = (string) ($input['id'] ?? '');
            if ($id === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $refund = array_key_exists('refund', $input) ? !empty($input['refund']) : true;
            $reason = (string) ($input['reason'] ?? '');
            $result = $checkout->cancelOrder($id, [
                'refund' => $refund,
                'reason' => $reason,
                'source' => 'admin',
                'actor' => $actor,
            ]);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Cancel failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'list_shipping_zones':
            $shipping = $catalog->loadShippingZones();
            $shipping['easypost_api_key_set'] = ($shipping['easypost_api_key'] ?? '') !== '';
            $shipping['easypost_api_key'] = '';
            return ['status' => 'ok', 'data' => $shipping];

        case 'save_shipping_zones':
            $catalog->saveShippingZones([
                'provider' => $input['provider'] ?? 'manual',
                'easypost_api_key' => $input['easypost_api_key'] ?? '',
                'from_address' => $input['from_address'] ?? [],
                'free_shipping_min_cents' => max(0, (int) ($input['free_shipping_min_cents'] ?? 0)),
                'zones' => $input['zones'] ?? [],
            ]);
            return ['status' => 'ok', 'data' => [
                'provider' => $catalog->getShippingRateProviderId(),
                'free_shipping_min_cents' => $catalog->getFreeShippingMinCents(),
            ]];

        case 'list_shipping_rate_providers':
            if (!class_exists('ShippingRateProviderResolver')) {
                require_once dirname(__DIR__) . '/includes/ShippingRateProviderResolver.php';
            }
            $resolver = new ShippingRateProviderResolver($catalog);
            return [
                'status' => 'ok',
                'data' => [
                    'providers' => $resolver->listProviders(),
                    'active' => $resolver->getProviderId(),
                ],
            ];

        case 'list_tax_rules':
            return ['status' => 'ok', 'data' => $catalog->loadTaxRules()];

        case 'save_tax_rules':
            $catalog->saveTaxRules([
                'enabled' => !empty($input['enabled']),
                'provider' => $input['provider'] ?? 'manual',
                'default_rate' => (float) ($input['default_rate'] ?? 0),
                'country_rates' => $input['country_rates'] ?? [],
                'classes' => $input['classes'] ?? [],
                'class_country_rates' => $input['class_country_rates'] ?? [],
                'b2b_reverse_charge' => is_array($input['b2b_reverse_charge'] ?? null)
                    ? $input['b2b_reverse_charge']
                    : [],
            ]);
            return ['status' => 'ok', 'data' => $catalog->loadTaxRules()];

        case 'list_tax_providers':
            if (!class_exists('TaxProviderResolver')) {
                require_once dirname(__DIR__) . '/includes/TaxProviderResolver.php';
            }
            $resolver = new TaxProviderResolver($catalog);
            return [
                'status' => 'ok',
                'data' => [
                    'providers' => $resolver->listProviders(),
                    'active' => $resolver->getProviderId(),
                ],
            ];

        case 'list_fieldtype_profiles':
            return ['status' => 'ok', 'data' => ['profiles' => $fieldtypeProfiles->listProfiles()]];

        case 'save_fieldtype_profile':
            $profile = $input['profile'] ?? [];
            if (empty($profile['name'])) {
                return ['status' => 'error', 'message' => 'Profile name required'];
            }
            $saved = $fieldtypeProfiles->saveProfile($profile);
            commerce_register_fieldtype_profiles();
            return ['status' => 'ok', 'data' => ['profile' => $saved]];

        case 'delete_fieldtype_profile':
            $id = (string) ($input['id'] ?? '');
            if ($id === '' || $id === 'default') {
                return ['status' => 'error', 'message' => 'Cannot delete default profile'];
            }
            $ok = $fieldtypeProfiles->deleteProfile($id);
            if ($ok) {
                commerce_register_fieldtype_profiles();
            }
            return ['status' => $ok ? 'ok' : 'error'];

        case 'migration_scan':
            return ['status' => 'ok', 'data' => $migration->scan()];

        case 'migration_preview':
            return ['status' => 'ok', 'data' => $migration->preview($input)];

        case 'migration_import':
            $result = $migration->import($input);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Import failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'migration_history':
            $limit = max(1, min(100, (int) ($input['limit'] ?? 50)));
            return ['status' => 'ok', 'data' => ['migrations' => $migration->listHistory($limit)]];

        case 'migration_rollback':
            $importId = trim((string) ($input['id'] ?? ''));
            if ($importId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $result = $migration->rollback($importId);
            if (!($result['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $result['error'] ?? 'Rollback failed'];
            }
            return ['status' => 'ok', 'data' => $result];

        case 'list_gift_cards':
            return ['status' => 'ok', 'data' => ['gift_cards' => $giftCards->listAll()]];

        case 'issue_gift_card':
            try {
                $c = $giftCards->issue([
                    'code' => $input['code'] ?? null,
                    'balance_cents' => (int) ($input['balance_cents'] ?? 0),
                    'currency' => $input['currency'] ?? 'eur',
                    'expires_at' => $input['expires_at'] ?? null,
                    'note' => $input['note'] ?? '',
                    'source' => 'admin',
                    'issued_by' => 'admin',
                ]);
                return ['status' => 'ok', 'data' => ['gift_card' => $c]];
            } catch (Exception $e) {
                return ['status' => 'error', 'message' => $e->getMessage()];
            }

        case 'void_gift_card':
            return ['status' => $giftCards->voidCard($input['code'] ?? '') ? 'ok' : 'error'];

        case 'create_quote':
            $built = $catalog->buildCartLines($cart->getItems(), $discounts, $cart->getCouponCode(), $cart->getAffiliateId());
            if (empty($built['lines'])) {
                return ['status' => 'error', 'message' => 'Cart is empty'];
            }
            $q = $quoteStore->createFromBuiltCart($built, $input['customer_email'] ?? '', [], ['draft_order' => true]);
            return ['status' => 'ok', 'data' => ['quote' => $q, 'accept_url' => $quoteStore->acceptUrl($q['token'])]];

        case 'list_quotes':
            return ['status' => 'ok', 'data' => ['quotes' => $quoteStore->listAll()]];

        case 'get_quote_admin':
        case 'draft_order_get':
            $draftId = trim((string) ($input['id'] ?? ''));
            if ($draftId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $dq = $draftOrders->get($draftId);
            if (!$dq) {
                return ['status' => 'error', 'message' => 'Draft order not found'];
            }
            return [
                'status' => 'ok',
                'data' => [
                    'quote' => $dq,
                    'accept_url' => $quoteStore->acceptUrl((string) ($dq['token'] ?? '')),
                ],
            ];

        case 'draft_order_search_catalog':
            $q = (string) ($input['q'] ?? ($input['query'] ?? ''));
            $limit = max(1, min(50, (int) ($input['limit'] ?? 25)));
            return ['status' => 'ok', 'data' => ['items' => $draftOrders->searchCatalog($q, $limit)]];

        case 'draft_order_preview':
            $preview = $draftOrders->preview($input);
            return [
                'status' => ($preview['ok'] ?? false) ? 'ok' : 'error',
                'message' => $preview['error'] ?? null,
                'data' => $preview,
            ];

        case 'draft_order_create':
            $created = $draftOrders->create($input);
            if (!($created['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $created['error'] ?? 'Create failed', 'data' => $created];
            }
            return ['status' => 'ok', 'data' => $created];

        case 'draft_order_update':
            $updateId = trim((string) ($input['id'] ?? ''));
            if ($updateId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $updated = $draftOrders->update($updateId, $input);
            if (!($updated['ok'] ?? false)) {
                return ['status' => 'error', 'message' => $updated['error'] ?? 'Update failed', 'data' => $updated];
            }
            return ['status' => 'ok', 'data' => $updated];

        case 'draft_order_checkout':
            $checkoutId = trim((string) ($input['id'] ?? ''));
            if ($checkoutId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $paidOut = $draftOrders->checkout($checkoutId, $input);
            return [
                'status' => ($paidOut['ok'] ?? false) ? 'ok' : 'error',
                'message' => $paidOut['error'] ?? null,
                'data' => $paidOut,
            ];

        case 'cancel_quote':
            $quoteId = trim((string) ($input['id'] ?? ''));
            if ($quoteId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            return ['status' => $quoteStore->cancel($quoteId) ? 'ok' : 'error'];

        case 'analytics_summary':
            return ['status' => 'ok', 'data' => ['summary' => $analytics->getSummary($input['from'] ?? null, $input['to'] ?? null)]];

        case 'analytics_export_csv':
            return [
                'status' => 'ok',
                'data' => [
                    'filename' => 'analytics-' . date('Ymd-His') . '.csv',
                    'csv' => $analytics->exportOrdersCsv($input['from'] ?? null, $input['to'] ?? null),
                ],
            ];

        case 'list_warehouse_stock':
            $ledger = commerce_inventory_ledger($indexer);
            $warehouse = new WarehouseStockStore();
            $warehouseId = trim((string) ($input['warehouse_id'] ?? ''));
            return [
                'status' => 'ok',
                'data' => [
                    'mode' => $ledger->mode(),
                    'stock' => $ledger->listRows($warehouseId !== '' ? $warehouseId : null),
                    'warehouses' => $warehouse->listWarehouses(),
                ],
            ];

        case 'list_warehouses':
            require_once dirname(__DIR__) . '/includes/WarehouseStockStore.php';
            $warehouse = new WarehouseStockStore();
            return ['status' => 'ok', 'data' => ['warehouses' => $warehouse->listWarehouses()]];

        case 'save_warehouse':
            require_once dirname(__DIR__) . '/includes/WarehouseStockStore.php';
            if (commerce_inventory_ledger($indexer)->mode() !== InventoryLedger::MODE_LOCATIONS) {
                return ['status' => 'error', 'message' => 'Warehouse management is available only in Locations stock mode'];
            }
            $warehouse = new WarehouseStockStore();
            $wid = trim((string) ($input['id'] ?? ''));
            $name = trim((string) ($input['name'] ?? ''));
            try {
                if ($wid === '') {
                    $row = $warehouse->createWarehouse($name, isset($input['sort_order']) ? (int) $input['sort_order'] : null);
                } else {
                    $row = $warehouse->updateWarehouse($wid, $name, isset($input['sort_order']) ? (int) $input['sort_order'] : null);
                }
                return ['status' => 'ok', 'data' => ['warehouse' => $row]];
            } catch (InvalidArgumentException $e) {
                return ['status' => 'error', 'message' => $e->getMessage()];
            }

        case 'delete_warehouse':
            require_once dirname(__DIR__) . '/includes/WarehouseStockStore.php';
            if (commerce_inventory_ledger($indexer)->mode() !== InventoryLedger::MODE_LOCATIONS) {
                return ['status' => 'error', 'message' => 'Warehouse management is available only in Locations stock mode'];
            }
            $warehouse = new WarehouseStockStore();
            $wid = trim((string) ($input['id'] ?? ''));
            try {
                return ['status' => $warehouse->deleteWarehouse($wid) ? 'ok' : 'error'];
            } catch (InvalidArgumentException $e) {
                return ['status' => 'error', 'message' => $e->getMessage()];
            }

        case 'transfer_warehouse_stock':
            require_once dirname(__DIR__) . '/includes/WarehouseStockStore.php';
            if (commerce_inventory_ledger($indexer)->mode() !== InventoryLedger::MODE_LOCATIONS) {
                return ['status' => 'error', 'message' => 'Stock transfers are available only in Locations stock mode'];
            }
            $warehouse = new WarehouseStockStore();
            try {
                $result = $warehouse->transfer(
                    trim((string) ($input['sku'] ?? '')),
                    (int) ($input['quantity'] ?? 0),
                    trim((string) ($input['from_warehouse_id'] ?? '')),
                    trim((string) ($input['to_warehouse_id'] ?? ''))
                );
                return ['status' => 'ok', 'data' => $result];
            } catch (InvalidArgumentException $e) {
                return ['status' => 'error', 'message' => $e->getMessage()];
            }

        case 'save_warehouse_stock':
            $ledger = commerce_inventory_ledger($indexer);
            $sku = trim((string) ($input['sku'] ?? ''));
            if ($sku === '') {
                return ['status' => 'error', 'message' => 'sku required'];
            }
            if ($ledger->mode() === InventoryLedger::MODE_UNLIMITED) {
                return ['status' => 'error', 'message' => 'Inventory is unlimited; switch to Simple or Locations to set stock'];
            }
            $warehouseId = trim((string) ($input['warehouse_id'] ?? ''));
            $row = $ledger->setSkuStock(
                $sku,
                (int) ($input['quantity_on_hand'] ?? 0),
                isset($input['low_stock_threshold']) ? (int) $input['low_stock_threshold'] : null,
                $warehouseId !== '' ? $warehouseId : null
            );
            return ['status' => 'ok', 'data' => ['row' => $row]];

        case 'bundle_validate':
            require_once dirname(__DIR__) . '/includes/CommerceBundleSchema.php';
            $bundle = is_array($input['bundle'] ?? null) ? $input['bundle'] : [];
            $index = $indexer->loadIndex();
            $resolved = CommerceBundleSchema::resolveComponents($bundle, $index['entries'] ?? []);
            $errors = CommerceBundleSchema::validate($bundle);
            return [
                'status' => 'ok',
                'data' => [
                    'valid' => $resolved['valid'] && empty($errors),
                    'issues' => array_merge($resolved['issues'] ?? [], $errors),
                    'components' => $resolved['items'] ?? [],
                ],
            ];

        case 'bundle_preview_price':
            require_once dirname(__DIR__) . '/includes/CommerceBundleSchema.php';
            $bundle = is_array($input['bundle'] ?? null) ? $input['bundle'] : [];
            $index = $indexer->loadIndex();
            $resolved = CommerceBundleSchema::resolveComponents($bundle, $index['entries'] ?? []);
            $priceCents = CommerceBundleSchema::computePriceCents($bundle, $resolved['items'] ?? []);
            return [
                'status' => 'ok',
                'data' => [
                    'price_cents' => $priceCents,
                    'currency' => strtolower((string) (commerce_bundle_normalize_value($bundle)['currency'] ?? 'eur')),
                    'valid' => $resolved['valid'],
                    'issues' => $resolved['issues'] ?? [],
                ],
            ];

        case 'get_inventory_webhook_config':
            require_once dirname(__DIR__) . '/includes/CommerceInventoryWebhookService.php';
            $webhooks = new CommerceInventoryWebhookService();
            $public = $liveImport->getPublicConfig();
            return [
                'status' => 'ok',
                'data' => [
                    'shopify' => [
                        'webhook_url' => $webhooks->webhookUrl('shopify'),
                        'webhook_configured' => !empty($public['shopify']['webhook_configured']),
                    ],
                    'woocommerce' => [
                        'webhook_url' => $webhooks->webhookUrl('woocommerce'),
                        'webhook_configured' => !empty($public['woocommerce']['webhook_configured']),
                    ],
                ],
            ];

        case 'rotate_inventory_webhook_secret':
            $platform = strtolower(trim((string) ($input['platform'] ?? '')));
            if (!in_array($platform, ['shopify', 'woocommerce'], true)) {
                return ['status' => 'error', 'message' => 'platform must be shopify or woocommerce'];
            }
            $secret = bin2hex(random_bytes(16));
            $liveImport->savePlatformConfig($platform, ['webhook_secret' => $secret]);
            return ['status' => 'ok', 'data' => ['platform' => $platform, 'webhook_secret' => $secret]];

        case 'sync_order_payment':
            $orderId = (string) ($input['id'] ?? $input['order_id'] ?? '');
            if ($orderId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $result = $checkout->syncOrderPayment($orderId);
            return [
                'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
                'message' => $result['error'] ?? null,
                'data' => $result,
            ];

        case 'resend_order_email':
            $orderId = (string) ($input['id'] ?? $input['order_id'] ?? '');
            if ($orderId === '') {
                return ['status' => 'error', 'message' => 'id required'];
            }
            $result = $checkout->resendOrderReceipt($orderId);
            return [
                'status' => ($result['ok'] ?? false) ? 'ok' : 'error',
                'message' => $result['error'] ?? null,
                'data' => $result,
            ];

        case 'reconcile_pending_payments':
            $limit = (int) ($input['limit'] ?? 25);
            return ['status' => 'ok', 'data' => $checkout->reconcilePendingPayments($limit)];

        case 'activity_counts':
            $ordersSeenAt = (string) ($input['orders_seen_at'] ?? '');
            $subsSeenAt = (string) ($input['subscriptions_seen_at'] ?? '');
            $ordersSeenTs = $ordersSeenAt !== '' ? strtotime($ordersSeenAt) : false;
            $subsSeenTs = $subsSeenAt !== '' ? strtotime($subsSeenAt) : false;
            $ordersNew = 0;
            $ordersPending = 0;
            foreach ($orders->listAll() as $order) {
                $status = (string) ($order['status'] ?? '');
                if ($status === 'abandoned' || $status === 'failed' || $status === 'canceled') {
                    continue;
                }
                if ($status === 'pending') {
                    $ordersPending++;
                }
                $createdTs = strtotime((string) ($order['created_at'] ?? '')) ?: 0;
                if ($ordersSeenTs === false) {
                    if ($status === 'pending' || $status === 'paid') {
                        if ($status === 'pending') {
                            $ordersNew++;
                        }
                    }
                } elseif ($createdTs > $ordersSeenTs) {
                    $ordersNew++;
                }
            }
            $subsNew = 0;
            $subsTotal = 0;
            foreach ($subscriptionStore->listAll() as $sub) {
                $subsTotal++;
                $createdTs = strtotime((string) ($sub['created_at'] ?? '')) ?: 0;
                if ($subsSeenTs === false) {
                    if (($sub['status'] ?? '') === 'active') {
                        $subsNew++;
                    }
                } elseif ($createdTs > $subsSeenTs) {
                    $subsNew++;
                }
            }
            $fulfillmentOpen = 0;
            foreach ($orders->listAll() as $order) {
                if (!is_array($order)) {
                    continue;
                }
                $enriched = $orderOps->enrichOrder($order);
                if (!empty($enriched['has_open_fulfillment_work'])) {
                    $fulfillmentOpen++;
                }
            }
            $activityNavDot = true;
            if (function_exists('get_plugin_setting')) {
                $activityNavDot = (bool) get_plugin_setting(
                    function_exists('commerce_active_plugin_id') ? commerce_active_plugin_id() : 'commerce',
                    'activity_nav_dot',
                    true
                );
            } elseif (function_exists('commerce_get_setting')) {
                $raw = commerce_get_setting('activity_nav_dot', true);
                $activityNavDot = $raw === null ? true : !empty($raw);
            }
            return [
                'status' => 'ok',
                'data' => [
                    'orders_new' => $ordersNew,
                    'orders_pending' => $ordersPending,
                    'subscriptions_new' => $subsNew,
                    'subscriptions_total' => $subsTotal,
                    'fulfillment_open' => $fulfillmentOpen,
                    'activity_nav_dot' => $activityNavDot,
                ],
            ];

        default:
            return ['status' => 'error', 'message' => 'Unknown admin action: ' . $action];
    }
}
