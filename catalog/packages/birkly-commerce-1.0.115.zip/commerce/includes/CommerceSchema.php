<?php
/**
 * Commerce field value schema — v2 normalization and legacy migration.
 */

class CommerceSchema
{
    public const FULFILLMENTS = ['ship', 'deliver', 'register', 'gift_card', 'none'];
    public const BILLING_MODES = ['one_time', 'recurring'];
    public const PRICING_MODES = ['fixed', 'variable'];
    public const INTERVALS = ['week', 'month', 'year'];
    public const DELIVERY_MODES = ['secure_download', 'external_url'];
    /** Common tax class codes (custom codes allowed via normalizeTaxClass). */
    public const TAX_CLASSES = ['standard', 'reduced', 'zero'];

    public static function normalizeValue($value): array
    {
        if (!is_array($value)) {
            return self::withLegacyFields(self::defaultValue());
        }

        if (self::isLegacyValue($value)) {
            $value = self::migrateLegacyValue($value);
        }

        return self::withLegacyFields(self::normalizeV2($value));
    }

    public static function isLegacyValue(array $value): bool
    {
        if (!empty($value['purchase_options']) && is_array($value['purchase_options'])) {
            return false;
        }
        return isset($value['price_cents']) || isset($value['billing']);
    }

    public static function migrateLegacyValue(array $value): array
    {
        $billing = in_array($value['billing'] ?? '', self::BILLING_MODES, true)
            ? $value['billing'] : 'one_time';
        $interval = $value['interval'] ?? null;
        if ($billing === 'recurring' && !self::isValidInterval($interval)) {
            $interval = 'month';
        }
        if ($billing !== 'recurring') {
            $interval = null;
        }

        $priceCents = max(0, (int) ($value['price_cents'] ?? 0));
        if ($priceCents === 0 && isset($value['price']) && is_numeric($value['price'])) {
            $priceCents = (int) round((float) $value['price'] * 100);
        }

        $qty = $value['quantity_available'] ?? null;
        if ($qty === '' || $qty === false) {
            $qty = null;
        } elseif ($qty !== null) {
            $qty = (int) $qty;
        }

        $sku = isset($value['sku']) && $value['sku'] !== '' ? trim((string) $value['sku']) : null;

        return [
            'fulfillment' => in_array($value['fulfillment'] ?? '', self::FULFILLMENTS, true)
                ? $value['fulfillment'] : 'ship',
            'tax_class' => self::normalizeTaxClass($value['tax_class'] ?? null),
            'tax_included' => self::normalizeTaxIncluded($value['tax_included'] ?? true),
            'purchase_options' => [[
                'id' => 'default',
                'label' => 'Default',
                'billing' => $billing,
                'pricing_mode' => 'fixed',
                'price_cents' => $priceCents,
                'min_price_cents' => 0,
                'max_price_cents' => null,
                'currency' => strtolower((string) ($value['currency'] ?? 'eur')),
                'interval' => $interval,
            ]],
            'quantity_available' => $qty,
            'sku' => $sku,
            'weight_grams' => isset($value['weight_grams']) ? (int) $value['weight_grams'] : null,
            'length_mm' => isset($value['length_mm']) && $value['length_mm'] !== '' ? max(0, (int) $value['length_mm']) : null,
            'width_mm' => isset($value['width_mm']) && $value['width_mm'] !== '' ? max(0, (int) $value['width_mm']) : null,
            'height_mm' => isset($value['height_mm']) && $value['height_mm'] !== '' ? max(0, (int) $value['height_mm']) : null,
            'delivery_asset' => isset($value['delivery_asset']) ? trim((string) $value['delivery_asset']) : null,
            'delivery_url' => isset($value['delivery_url']) ? trim((string) $value['delivery_url']) : null,
            'delivery_mode' => in_array($value['delivery_mode'] ?? '', self::DELIVERY_MODES, true)
                ? $value['delivery_mode'] : 'secure_download',
            'custom_fields' => is_array($value['custom_fields'] ?? null) ? $value['custom_fields'] : [],
        ];
    }

    public static function normalizeV2(array $value): array
    {
        $defaults = self::defaultValue();
        $fulfillment = in_array($value['fulfillment'] ?? '', self::FULFILLMENTS, true)
            ? $value['fulfillment'] : $defaults['fulfillment'];

        // Optional free-text override from entry editor (tax_class_custom).
        $customClass = trim((string) ($value['tax_class_custom'] ?? ''));
        if ($customClass !== '') {
            $value['tax_class'] = $customClass;
        }

        $options = [];
        foreach ($value['purchase_options'] ?? [] as $idx => $opt) {
            if (!is_array($opt)) {
                continue;
            }
            $billing = in_array($opt['billing'] ?? '', self::BILLING_MODES, true)
                ? $opt['billing'] : 'one_time';
            $interval = $opt['interval'] ?? null;
            if ($billing === 'recurring' && !self::isValidInterval($interval)) {
                $interval = 'month';
            }
            if ($billing !== 'recurring') {
                $interval = null;
            }

            $id = trim((string) ($opt['id'] ?? ''));
            if ($id === '') {
                $id = 'opt_' . ($idx + 1);
            }

            $pricingMode = in_array($opt['pricing_mode'] ?? '', self::PRICING_MODES, true)
                ? $opt['pricing_mode'] : 'fixed';

            $minCents = $opt['min_price_cents'] ?? null;
            if ($minCents === '' || $minCents === false || $minCents === null) {
                $minCents = $pricingMode === 'variable' ? 100 : 0;
            } else {
                $minCents = max(0, (int) $minCents);
            }

            $maxCents = $opt['max_price_cents'] ?? null;
            if ($maxCents === '' || $maxCents === false) {
                $maxCents = null;
            } elseif ($maxCents !== null) {
                $maxCents = max(0, (int) $maxCents);
            }
            if ($maxCents !== null && $maxCents < $minCents) {
                $maxCents = $minCents;
            }

            $priceCents = max(0, (int) ($opt['price_cents'] ?? 0));
            if ($pricingMode === 'variable' && $priceCents < $minCents) {
                $priceCents = $minCents;
            }

            $options[] = [
                'id' => $id,
                'label' => trim((string) ($opt['label'] ?? $id)),
                'billing' => $billing,
                'pricing_mode' => $pricingMode,
                'price_cents' => $priceCents,
                'min_price_cents' => $minCents,
                'max_price_cents' => $maxCents,
                'currency' => strtolower((string) ($opt['currency'] ?? (function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur'))),
                'interval' => $interval,
            ];
        }

        if (empty($options)) {
            $options = $defaults['purchase_options'];
        }

        $qty = $value['quantity_available'] ?? null;
        if ($qty === '' || $qty === false) {
            $qty = null;
        } elseif ($qty !== null) {
            $qty = (int) $qty;
        }

        $sku = isset($value['sku']) && $value['sku'] !== '' ? trim((string) $value['sku']) : null;
        $weight = $value['weight_grams'] ?? null;
        if ($weight === '' || $weight === false) {
            $weight = null;
        } elseif ($weight !== null) {
            $weight = max(0, (int) $weight);
        }

        $dim = static function ($raw): ?int {
            if ($raw === '' || $raw === false || $raw === null) {
                return null;
            }
            return max(0, (int) $raw);
        };

        return [
            'fulfillment' => $fulfillment,
            'tax_class' => self::normalizeTaxClass($value['tax_class'] ?? null),
            'tax_included' => self::normalizeTaxIncluded(
                array_key_exists('tax_included', $value) ? $value['tax_included'] : true
            ),
            'purchase_options' => $options,
            'quantity_available' => $qty,
            'sku' => $sku,
            'weight_grams' => $weight,
            'length_mm' => $dim($value['length_mm'] ?? null),
            'width_mm' => $dim($value['width_mm'] ?? null),
            'height_mm' => $dim($value['height_mm'] ?? null),
            'delivery_asset' => isset($value['delivery_asset']) && $value['delivery_asset'] !== ''
                ? trim((string) $value['delivery_asset']) : null,
            'delivery_url' => isset($value['delivery_url']) && $value['delivery_url'] !== ''
                ? trim((string) $value['delivery_url']) : null,
            'delivery_mode' => in_array($value['delivery_mode'] ?? '', self::DELIVERY_MODES, true)
                ? $value['delivery_mode'] : 'secure_download',
            'custom_fields' => is_array($value['custom_fields'] ?? null) ? $value['custom_fields'] : [],
        ];
    }

    /**
     * Normalize a product tax class code. Empty / invalid → standard.
     */
    public static function normalizeTaxClass($taxClass): string
    {
        $code = strtolower(trim((string) ($taxClass ?? '')));
        if ($code === '' || !preg_match('/^[a-z0-9][a-z0-9_-]{0,63}$/', $code)) {
            return 'standard';
        }
        return $code;
    }

    /**
     * Whether shelf/line prices already include tax (EU default: true).
     * Accepts checkbox/"0"/"1"/included|excluded aliases.
     */
    public static function normalizeTaxIncluded($value): bool
    {
        if ($value === null || $value === '') {
            return true;
        }
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return (int) $value !== 0;
        }
        $s = strtolower(trim((string) $value));
        if (in_array($s, ['0', 'false', 'no', 'off', 'excluded', 'exclusive'], true)) {
            return false;
        }
        if (in_array($s, ['1', 'true', 'yes', 'on', 'included', 'inclusive'], true)) {
            return true;
        }
        return true;
    }

    /**
     * Extract VAT from a gross (tax-included) amount: round(gross × r / (100 + r)).
     */
    public static function extractIncludedTaxCents(int $grossCents, float $ratePercent): int
    {
        if ($grossCents <= 0 || $ratePercent <= 0) {
            return 0;
        }
        return (int) round($grossCents * $ratePercent / (100 + $ratePercent));
    }

    /**
     * Add-on VAT for a net (tax-excluded) amount: round(net × r / 100).
     */
    public static function exclusiveTaxCents(int $netCents, float $ratePercent): int
    {
        if ($netCents <= 0 || $ratePercent <= 0) {
            return 0;
        }
        return (int) round($netCents * ($ratePercent / 100));
    }

    /**
     * Resolve tax_included from a cart/catalog line (field → commerce → default true).
     *
     * @param array<string, mixed> $line
     */
    public static function lineTaxIncluded(array $line): bool
    {
        if (array_key_exists('tax_included', $line)) {
            return self::normalizeTaxIncluded($line['tax_included']);
        }
        $commerce = is_array($line['commerce'] ?? null) ? $line['commerce'] : [];
        if (array_key_exists('tax_included', $commerce)) {
            return self::normalizeTaxIncluded($commerce['tax_included']);
        }
        return true;
    }

    /**
     * Amount to add to goods+shipping for the customer charge.
     * Inclusive VAT is display-only (0); exclusive VAT is added; reverse-charge
     * on inclusive prices may return a negative strip adjustment.
     *
     * @param array<string, mixed> $taxResult from TaxProviderInterface::calculate
     */
    public static function taxAddCentsFromResult(array $taxResult): int
    {
        if (array_key_exists('tax_add_cents', $taxResult)) {
            return (int) $taxResult['tax_add_cents'];
        }
        return (int) ($taxResult['tax_cents'] ?? 0);
    }

    public static function withLegacyFields(array $value): array
    {
        $first = $value['purchase_options'][0] ?? [];
        $value['price_cents'] = (int) ($first['price_cents'] ?? 0);
        $value['billing'] = $first['billing'] ?? 'one_time';
        $value['currency'] = $first['currency'] ?? 'eur';
        $value['interval'] = $first['interval'] ?? null;
        return $value;
    }

    public static function defaultValue(): array
    {
        $defaultCurrency = function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur';

        return self::withLegacyFields([
            'fulfillment' => 'ship',
            'tax_class' => 'standard',
            'tax_included' => true,
            'purchase_options' => [[
                'id' => 'default',
                'label' => 'Default',
                'billing' => 'one_time',
                'pricing_mode' => 'fixed',
                'price_cents' => 0,
                'min_price_cents' => 0,
                'max_price_cents' => null,
                'currency' => $defaultCurrency,
                'interval' => null,
            ]],
            'quantity_available' => null,
            'sku' => null,
            'weight_grams' => null,
            'length_mm' => null,
            'width_mm' => null,
            'height_mm' => null,
            'delivery_asset' => null,
            'delivery_url' => null,
            'delivery_mode' => 'secure_download',
            'custom_fields' => [],
        ]);
    }

    public static function findPurchaseOption(array $commerce, ?string $optionId): ?array
    {
        $commerce = self::normalizeValue($commerce);
        $options = $commerce['purchase_options'] ?? [];
        if ($optionId === null || $optionId === '') {
            return $options[0] ?? null;
        }
        foreach ($options as $opt) {
            if (($opt['id'] ?? '') === $optionId) {
                return $opt;
            }
        }
        return null;
    }

    public static function priceFrom(array $commerce): int
    {
        $commerce = self::normalizeValue($commerce);
        $min = null;
        foreach ($commerce['purchase_options'] ?? [] as $opt) {
            $price = (int) ($opt['price_cents'] ?? 0);
            if ($min === null || $price < $min) {
                $min = $price;
            }
        }
        return $min ?? 0;
    }

    public static function validate(array $value, bool $required = false): array
    {
        $errors = [];
        $normalized = self::normalizeValue($value);

        if ($required && empty($normalized['purchase_options'])) {
            $errors[] = 'At least one purchase option is required';
        }

        foreach ($normalized['purchase_options'] as $opt) {
            if ((int) ($opt['price_cents'] ?? 0) < 0) {
                $errors[] = 'Price must be zero or greater';
            }
            if (!in_array($opt['billing'] ?? '', self::BILLING_MODES, true)) {
                $errors[] = 'Billing must be one_time or recurring';
            }
            if (($opt['billing'] ?? '') === 'recurring' && !self::recurringBillingEnabled()) {
                $errors[] = 'Recurring billing is disabled on this site';
            }
            if (($opt['billing'] ?? '') === 'recurring' && ($opt['pricing_mode'] ?? 'fixed') === 'variable') {
                $errors[] = 'Variable pricing cannot be combined with subscriptions';
            }
            if (($opt['pricing_mode'] ?? 'fixed') === 'variable') {
                $min = (int) ($opt['min_price_cents'] ?? 0);
                $max = $opt['max_price_cents'] ?? null;
                if ($min < 0) {
                    $errors[] = 'Minimum amount must be zero or greater';
                }
                if ($max !== null && (int) $max < $min) {
                    $errors[] = 'Maximum amount must be greater than or equal to the minimum';
                }
            }
        }

        if (!in_array($normalized['fulfillment'], self::FULFILLMENTS, true)) {
            $errors[] = 'Invalid fulfillment type';
        }

        return $errors;
    }

    public static function isValidInterval(?string $interval): bool
    {
        if ($interval === null || $interval === '') {
            return false;
        }
        if (in_array($interval, self::INTERVALS, true)) {
            return true;
        }
        return (bool) preg_match('/^[a-z0-9_]+$/', $interval);
    }

    public static function recurringBillingEnabled(): bool
    {
        if (defined('COMMERCE_ENABLE_RECURRING_BILLING')) {
            return (bool) COMMERCE_ENABLE_RECURRING_BILLING;
        }
        $enable = getenv('COMMERCE_ENABLE_RECURRING_BILLING');
        if ($enable !== false && $enable !== '') {
            return in_array(strtolower((string) $enable), ['1', 'true', 'yes'], true);
        }
        $disable = getenv('COMMERCE_DISABLE_RECURRING_BILLING');
        if ($disable !== false && $disable !== '') {
            return !in_array(strtolower((string) $disable), ['1', 'true', 'yes'], true);
        }
        // Enabled by default so memberships/subscriptions can be configured in entry editors.
        return true;
    }

    /**
     * Enrich purchase_options for storefront binders (catalog_item SSOT).
     *
     * @param array<int, array<string, mixed>> $options
     * @return array<int, array<string, mixed>>
     */
    public static function enrichPurchaseOptionsForStorefront(array $options): array
    {
        $enriched = [];
        foreach ($options as $opt) {
            if (!is_array($opt)) {
                continue;
            }
            $normalized = self::normalizeValue(['purchase_options' => [$opt]])['purchase_options'][0] ?? [];
            if ($normalized === []) {
                continue;
            }
            $mode = $normalized['pricing_mode'] ?? 'fixed';
            $min = (int) ($normalized['min_price_cents'] ?? 0);
            $suggested = max($min, (int) ($normalized['price_cents'] ?? $min));
            $enriched[] = array_merge($normalized, [
                'allows_custom_amount' => $mode === 'variable',
                'is_recurring' => ($normalized['billing'] ?? '') === 'recurring',
                'display_amount_cents' => $mode === 'fixed' ? $suggested : $suggested,
                'suggested_amount_cents' => $suggested,
            ]);
        }
        return $enriched;
    }

    /**
     * Resolve charge amount for a purchase option, honoring variable (donation) ranges.
     */
    public static function resolveOptionAmountCents(array $option, ?int $requestedCents = null): array
    {
        $option = self::normalizeValue(['purchase_options' => [$option]])['purchase_options'][0] ?? $option;
        $mode = $option['pricing_mode'] ?? 'fixed';
        if ($mode !== 'variable') {
            $amount = max(0, (int) ($option['price_cents'] ?? 0));
            return ['ok' => true, 'amount_cents' => $amount, 'pricing_mode' => 'fixed'];
        }

        $min = max(0, (int) ($option['min_price_cents'] ?? 0));
        $max = $option['max_price_cents'] ?? null;
        $suggested = max($min, (int) ($option['price_cents'] ?? $min));
        $amount = $requestedCents !== null ? max(0, $requestedCents) : $suggested;
        if ($amount < $min) {
            return ['ok' => false, 'message' => 'Amount is below the minimum', 'amount_cents' => $amount];
        }
        if ($max !== null && $amount > (int) $max) {
            return ['ok' => false, 'message' => 'Amount is above the maximum', 'amount_cents' => $amount];
        }
        return ['ok' => true, 'amount_cents' => $amount, 'pricing_mode' => 'variable', 'min_price_cents' => $min, 'max_price_cents' => $max];
    }

    /**
     * Detect open-contribution / linked-supporter orders without site-specific heuristics.
     *
     * @param array<string, mixed> $order
     */
    public static function orderIsOpenContribution(array $order): bool
    {
        if (class_exists('CommerceEntrySync')) {
            $meta = CommerceEntrySync::orderEntrySyncMeta($order);
            if ($meta !== []) {
                $entryKey = function_exists('commerce_get_setting')
                    ? trim((string) commerce_get_setting('commerce_entry_sync_entry_id_meta', 'supporter_entry_id'))
                    : 'supporter_entry_id';
                $collectionKey = function_exists('commerce_get_setting')
                    ? trim((string) commerce_get_setting('commerce_entry_sync_collection_meta', 'entry_collection'))
                    : 'entry_collection';
                if (
                    ($entryKey !== '' && trim((string) ($meta[$entryKey] ?? '')) !== '')
                    || ($collectionKey !== '' && trim((string) ($meta[$collectionKey] ?? '')) !== '')
                ) {
                    return true;
                }
            }
        } elseif (is_array($order['entry_sync_meta'] ?? null) && $order['entry_sync_meta'] !== []) {
            return true;
        } elseif (is_array($order['donor_meta'] ?? null) && $order['donor_meta'] !== []) {
            return true;
        }

        foreach ($order['lines'] ?? [] as $line) {
            if (!is_array($line)) {
                continue;
            }
            if (($line['fulfillment'] ?? '') === 'none') {
                return true;
            }
            if (($line['pricing_mode'] ?? '') === 'variable') {
                return true;
            }
        }

        return false;
    }
}

function commerce_normalize_value($value): array
{
    return CommerceSchema::normalizeValue($value);
}
