<?php
/**
 * Session-backed commerce cart (v2 — purchase_option_id, parent_id).
 */

class CommerceCartSession
{
    private const SESSION_KEY = 'commerce_cart_items';
    private const AFFILIATE_KEY = 'commerce_affiliate_id';
    private const COUPON_KEY = 'commerce_coupon_code';
    private const GIFT_CARD_KEY = 'commerce_gift_card_code';
    private const CHECKOUT_DRAFT_KEY = 'commerce_checkout_draft';

    public function getItems(): array
    {
        return $_SESSION[self::SESSION_KEY] ?? [];
    }

    public function setItems(array $items): void
    {
        $_SESSION[self::SESSION_KEY] = array_values($items);
    }

    public function addItem(
        string $collectionSlug,
        string $entryId,
        int $quantity = 1,
        ?string $purchaseOptionId = null,
        ?string $parentId = null,
        ?int $amountCents = null
    ): array {
        $items = $this->getItems();
        $found = false;
        foreach ($items as &$item) {
            $sameAmount = ($amountCents === null && !isset($item['amount_cents']))
                || (isset($item['amount_cents']) && (int) $item['amount_cents'] === (int) $amountCents);
            if (($item['collection'] ?? '') === $collectionSlug
                && ($item['entry_id'] ?? '') === $entryId
                && ($item['purchase_option_id'] ?? null) === $purchaseOptionId
                && $sameAmount
            ) {
                $item['quantity'] = max(1, (int) ($item['quantity'] ?? 1) + $quantity);
                $found = true;
                break;
            }
        }
        unset($item);
        if (!$found) {
            $row = [
                'collection' => $collectionSlug,
                'entry_id' => $entryId,
                'quantity' => max(1, $quantity),
            ];
            if ($purchaseOptionId !== null && $purchaseOptionId !== '') {
                $row['purchase_option_id'] = $purchaseOptionId;
            }
            if ($parentId !== null && $parentId !== '') {
                $row['parent_id'] = $parentId;
            }
            if ($amountCents !== null) {
                $row['amount_cents'] = max(0, $amountCents);
            }
            $items[] = $row;
        }
        $this->setItems($items);
        return $items;
    }

    public function updateItem(string $collectionSlug, string $entryId, int $quantity, ?string $purchaseOptionId = null): array
    {
        if ($quantity <= 0) {
            return $this->removeItem($collectionSlug, $entryId, $purchaseOptionId);
        }
        $items = $this->getItems();
        foreach ($items as &$item) {
            $match = ($item['collection'] ?? '') === $collectionSlug && ($item['entry_id'] ?? '') === $entryId;
            if ($purchaseOptionId !== null) {
                $match = $match && ($item['purchase_option_id'] ?? null) === $purchaseOptionId;
            }
            if ($match) {
                $item['quantity'] = $quantity;
                break;
            }
        }
        unset($item);
        $this->setItems($items);
        return $items;
    }

    public function removeItem(string $collectionSlug, string $entryId, ?string $purchaseOptionId = null): array
    {
        // Treat "" like null — match any option for that entry (storefront may omit option).
        if ($purchaseOptionId === '') {
            $purchaseOptionId = null;
        }
        $items = array_values(array_filter($this->getItems(), function ($item) use ($collectionSlug, $entryId, $purchaseOptionId) {
            if (($item['collection'] ?? '') !== $collectionSlug || ($item['entry_id'] ?? '') !== $entryId) {
                return true; // keep unrelated lines
            }
            $itemOption = $item['purchase_option_id'] ?? null;
            if ($itemOption === '') {
                $itemOption = null;
            }
            // Request omitted option → remove every option for this entry.
            if ($purchaseOptionId === null) {
                return false;
            }
            // Session row stored without option (common when Add omits purchase_option_id)
            // while the cart API resolves a default like "once" for display — still remove it.
            if ($itemOption === null || $itemOption === $purchaseOptionId) {
                return false;
            }
            return true; // keep a different purchase option on the same entry
        }));
        $this->setItems($items);
        return $items;
    }

    public function clear(): void
    {
        unset($_SESSION[self::SESSION_KEY]);
    }

    /**
     * Remove cart rows that match paid order lines (collection + entry + option).
     *
     * @param array<int, array<string, mixed>> $lines
     */
    public function removeLines(array $lines): array
    {
        $items = $this->getItems();
        foreach ($lines as $line) {
            $collection = (string) ($line['collection_slug'] ?? $line['collection'] ?? '');
            $entryId = (string) ($line['entry_id'] ?? '');
            $optionId = $line['purchase_option_id'] ?? null;
            if ($collection === '' || $entryId === '') {
                continue;
            }
            $items = array_values(array_filter($items, static function ($item) use ($collection, $entryId, $optionId) {
                if (($item['collection'] ?? '') !== $collection || ($item['entry_id'] ?? '') !== $entryId) {
                    return true;
                }
                if ($optionId !== null && $optionId !== '' && ($item['purchase_option_id'] ?? null) !== $optionId) {
                    return true;
                }
                return false;
            }));
        }
        $this->setItems($items);
        return $items;
    }

    public function count(): int
    {
        $total = 0;
        foreach ($this->getItems() as $item) {
            $total += (int) ($item['quantity'] ?? 0);
        }
        return $total;
    }

    /**
     * Persist customer details + split-checkout progress across payment steps.
     *
     * @param array<string, mixed>|null $draft
     */
    public function setCheckoutDraft(?array $draft): void
    {
        if ($draft === null || $draft === []) {
            unset($_SESSION[self::CHECKOUT_DRAFT_KEY]);
            return;
        }
        $_SESSION[self::CHECKOUT_DRAFT_KEY] = $draft;
    }

    /** @return array<string, mixed>|null */
    public function getCheckoutDraft(): ?array
    {
        $draft = $_SESSION[self::CHECKOUT_DRAFT_KEY] ?? null;
        return is_array($draft) ? $draft : null;
    }

    public function clearCheckoutDraft(): void
    {
        unset($_SESSION[self::CHECKOUT_DRAFT_KEY]);
    }

    public function setAffiliateId(?string $affiliateId): void
    {
        if ($affiliateId === null || $affiliateId === '') {
            unset($_SESSION[self::AFFILIATE_KEY]);
            return;
        }
        $_SESSION[self::AFFILIATE_KEY] = $affiliateId;
    }

    public function getAffiliateId(): ?string
    {
        $id = $_SESSION[self::AFFILIATE_KEY] ?? null;
        return is_string($id) && $id !== '' ? $id : null;
    }

    public function setCouponCode(?string $code): void
    {
        if ($code === null || $code === '') {
            unset($_SESSION[self::COUPON_KEY]);
            return;
        }
        $_SESSION[self::COUPON_KEY] = strtoupper(trim($code));
    }

    public function getCouponCode(): ?string
    {
        $code = $_SESSION[self::COUPON_KEY] ?? null;
        return is_string($code) && $code !== '' ? $code : null;
    }

    public function setGiftCardCode(?string $code): void {
        if ($code === null || $code === '') { unset($_SESSION[self::GIFT_CARD_KEY]); return; }
        $_SESSION[self::GIFT_CARD_KEY] = strtoupper(trim($code));
    }
    public function getGiftCardCode(): ?string {
        $code = $_SESSION[self::GIFT_CARD_KEY] ?? null;
        return is_string($code) && $code !== '' ? $code : null;
    }
}
