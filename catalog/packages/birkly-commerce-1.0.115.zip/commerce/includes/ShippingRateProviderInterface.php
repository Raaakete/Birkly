<?php
/**
 * Shipping rate quote provider interface.
 */

interface ShippingRateProviderInterface
{
    public function getId(): string;

    public function getName(): string;

    /**
     * Quote shipping rates for cart lines + destination.
     *
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context selected_rate_id, currency, credentials, force_mock, force_fail
     * @return array{
     *   rates: list<array<string, mixed>>,
     *   shipping_lines: list<array<string, mixed>>,
     *   shipping_cents: int,
     *   provider: string,
     *   ok?: bool,
     *   error?: string,
     *   fallback?: bool
     * }
     */
    public function quote(array $lines, ?array $shippingAddress = null, array $context = []): array;
}
