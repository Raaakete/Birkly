<?php
/**
 * Subscription lifecycle service (P8-M4, P11-M2 dunning).
 *
 * - Creates a subscription record when a recurring order is paid.
 * - Cancels a subscription (admin action), optionally through the provider.
 * - Applies provider webhook events to move status to past_due / canceled / active.
 * - Dunning metadata and recovery triggers (P11-M2).
 */

class CommerceSubscriptionService
{
    private CommerceSubscriptionStore $store;
    private ?PaymentShelf $shelf;
    private ?CommerceDunningNotifier $dunningNotifier;

    /** @var array<string, int> interval => seconds */
    private const INTERVAL_SECONDS = [
        'day' => 86400,
        'daily' => 86400,
        'week' => 604800,
        'weekly' => 604800,
        'month' => 2592000,
        'monthly' => 2592000,
        'quarter' => 7776000,
        'year' => 31536000,
        'yearly' => 31536000,
        'annual' => 31536000,
    ];

    public function __construct(
        ?CommerceSubscriptionStore $store = null,
        ?PaymentShelf $shelf = null,
        ?CommerceDunningNotifier $dunningNotifier = null
    ) {
        $this->store = $store ?? new CommerceSubscriptionStore();
        $this->shelf = $shelf;
        $this->dunningNotifier = $dunningNotifier;
    }

    public function getStore(): CommerceSubscriptionStore
    {
        return $this->store;
    }

    /**
     * Create subscription record(s) from a paid recurring order.
     * One subscription per recurring line item (never a combined multi-item sub).
     * Idempotent per order line. Returns the first subscription for backward compatibility.
     */
    public function createFromOrder(array $order): ?array
    {
        $created = $this->createAllFromOrder($order);
        return $created[0] ?? null;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function createAllFromOrder(array $order): array
    {
        $this->normalizeToSingleLineSubscriptions();

        $orderId = (string) ($order['id'] ?? '');
        if ($orderId === '') {
            return [];
        }

        $recurringLines = $this->recurringLinesFromOrder($order);
        if (!$recurringLines) {
            return [];
        }

        $now = time();
        $out = [];
        foreach ($recurringLines as $line) {
            $lineId = $this->lineIdFor($line);
            $existing = $this->store->findByOrderLineId($orderId, $lineId);
            if ($existing) {
                $out[] = $existing;
                continue;
            }

            $interval = (string) ($line['interval'] ?? $order['billing_interval'] ?? 'month');
            $amount = (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? $line['unit_price_cents'] ?? 0);
            if ($amount <= 0 && count($recurringLines) === 1) {
                $amount = (int) ($order['total_cents'] ?? 0);
            }

            $created = $this->store->create([
                'order_id' => $orderId,
                'line_id' => $lineId,
                'payment_id' => $order['payment_id'] ?? null,
                'provider' => $order['provider'] ?? null,
                'provider_subscription_id' => $order['provider_subscription_id'] ?? null,
                'customer_email' => $order['customer_email'] ?? '',
                'purchase_option_id' => $line['purchase_option_id'] ?? null,
                'interval' => $interval,
                'amount_cents' => $amount,
                'currency' => $line['currency'] ?? ($order['currency'] ?? 'eur'),
                'lines' => [$line],
                'status' => 'active',
                'current_period_start' => date('c', $now),
                'next_billing_at' => date('c', $this->advance($now, $interval)),
            ]);
            $this->broadcast('commerce_subscription_created', $created);
            if (class_exists('CommerceNotify')) {
                CommerceNotify::subscriptionCreated($created);
            }
            $out[] = $created;
        }
        return $out;
    }

    /**
     * Split legacy combined subscriptions (multiple lines on one record) into
     * one subscription per recurring line. Safe to call repeatedly.
     *
     * @return int Number of subscriptions rewritten or created
     */
    public function normalizeToSingleLineSubscriptions(): int
    {
        $changed = 0;
        foreach ($this->store->listAll() as $sub) {
            $lines = is_array($sub['lines'] ?? null) ? array_values($sub['lines']) : [];
            if (!$lines) {
                continue;
            }

            $recurring = [];
            foreach ($lines as $line) {
                if (($line['billing'] ?? 'one_time') === 'recurring') {
                    $recurring[] = $line;
                }
            }
            if (!$recurring) {
                // Legacy combined rows stored every order line; if the sub exists, treat all as recurring.
                $recurring = $lines;
            }

            if (count($recurring) === 1 && count($lines) === 1 && !empty($sub['line_id'])) {
                continue;
            }

            if (count($recurring) === 1 && count($lines) === 1 && empty($sub['line_id'])) {
                $line = $recurring[0];
                $this->store->update($sub['id'], [
                    'line_id' => $this->lineIdFor($line),
                    'purchase_option_id' => $line['purchase_option_id'] ?? ($sub['purchase_option_id'] ?? null),
                    'interval' => $line['interval'] ?? ($sub['interval'] ?? 'month'),
                    'amount_cents' => (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? $sub['amount_cents'] ?? 0),
                ]);
                $changed++;
                continue;
            }

            $keep = $recurring[0];
            $keepId = $this->lineIdFor($keep);
            $this->store->update($sub['id'], [
                'line_id' => $keepId,
                'lines' => [$keep],
                'purchase_option_id' => $keep['purchase_option_id'] ?? ($sub['purchase_option_id'] ?? null),
                'interval' => $keep['interval'] ?? ($sub['interval'] ?? 'month'),
                'amount_cents' => (int) ($keep['line_total_cents'] ?? $keep['effective_amount_cents'] ?? 0),
                'split_from_combined' => true,
            ]);
            $changed++;

            $orderId = (string) ($sub['order_id'] ?? '');
            for ($i = 1, $n = count($recurring); $i < $n; $i++) {
                $line = $recurring[$i];
                $lineId = $this->lineIdFor($line);
                if ($orderId !== '' && $this->store->findByOrderLineId($orderId, $lineId)) {
                    continue;
                }
                $interval = (string) ($line['interval'] ?? $sub['interval'] ?? 'month');
                $this->store->create([
                    'order_id' => $orderId !== '' ? $orderId : null,
                    'line_id' => $lineId,
                    'payment_id' => $sub['payment_id'] ?? null,
                    'provider' => $sub['provider'] ?? null,
                    'provider_subscription_id' => null,
                    'customer_email' => $sub['customer_email'] ?? '',
                    'purchase_option_id' => $line['purchase_option_id'] ?? null,
                    'interval' => $interval,
                    'amount_cents' => (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0),
                    'currency' => $line['currency'] ?? ($sub['currency'] ?? 'eur'),
                    'lines' => [$line],
                    'status' => $sub['status'] ?? 'active',
                    'current_period_start' => $sub['current_period_start'] ?? date('c'),
                    'next_billing_at' => $sub['next_billing_at'] ?? null,
                    'canceled_at' => $sub['canceled_at'] ?? null,
                    'past_due_at' => $sub['past_due_at'] ?? null,
                    'dunning' => $sub['dunning'] ?? null,
                    'split_from' => $sub['id'] ?? null,
                ]);
                $changed++;
            }
        }
        return $changed;
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function recurringLinesFromOrder(array $order): array
    {
        $lines = is_array($order['lines'] ?? null) ? $order['lines'] : [];
        $recurring = [];
        foreach ($lines as $line) {
            if (($line['billing'] ?? 'one_time') === 'recurring') {
                $recurring[] = $line;
            }
        }
        if (!$recurring && ($order['billing_mode'] ?? 'one_time') === 'recurring') {
            foreach ($lines as $line) {
                $recurring[] = $line;
            }
        }
        return $recurring;
    }

    private function lineIdFor(array $line): string
    {
        $id = (string) ($line['line_id'] ?? '');
        if ($id !== '') {
            return $id;
        }
        return (string) (($line['collection_slug'] ?? '') . ':' . ($line['entry_id'] ?? '') . ':' . ($line['purchase_option_id'] ?? 'default'));
    }

    /**
     * Cancel a subscription. Sets status=canceled and clears next billing.
     * Attempts a provider cancel when a provider subscription id + shelf are present.
     */
    public function cancel(string $subscriptionId): ?array
    {
        $sub = $this->store->get($subscriptionId);
        if (!$sub) {
            return null;
        }
        if (($sub['status'] ?? '') === 'canceled') {
            return $sub;
        }

        $providerSubId = $sub['provider_subscription_id'] ?? '';
        if ($providerSubId && $this->shelf) {
            $provider = $sub['provider'] ?? '';
            try {
                $this->shelf->cancelSubscription($provider, $providerSubId);
            } catch (\Throwable $e) {
                // Provider cancel is best-effort; local record is still canceled below.
            }
        }

        $updated = $this->store->update($subscriptionId, [
            'status' => 'canceled',
            'canceled_at' => date('c'),
            'next_billing_at' => null,
            'dunning' => null,
        ]);
        $this->broadcast('commerce_subscription_canceled', $updated);
        return $updated;
    }

    /**
     * Pause billing for a subscription (local record + best-effort provider pause).
     */
    public function pause(string $subscriptionId): ?array
    {
        $sub = $this->store->get($subscriptionId);
        if (!$sub) {
            return null;
        }
        $status = (string) ($sub['status'] ?? '');
        if ($status === 'paused') {
            return $sub;
        }
        if (!in_array($status, ['active', 'past_due', 'trialing'], true)) {
            return null;
        }

        $providerSubId = $sub['provider_subscription_id'] ?? '';
        if ($providerSubId && $this->shelf) {
            $provider = $sub['provider'] ?? '';
            try {
                $this->shelf->updateSubscription($provider, $providerSubId, ['pause' => true], [
                    'source_plugin' => 'commerce',
                    'source_ref' => $subscriptionId,
                ]);
            } catch (\Throwable $e) {
                // Provider pause is best-effort; local record is still paused below.
            }
        }

        $patch = [
            'status' => 'paused',
            'paused_at' => date('c'),
            'resume_next_billing_at' => $sub['next_billing_at'] ?? null,
            'next_billing_at' => null,
            'dunning' => null,
        ];
        $updated = $this->store->update($subscriptionId, $patch);
        $this->broadcast('commerce_subscription_paused', $updated);

        return $updated;
    }

    /**
     * Resume a paused subscription.
     */
    public function resume(string $subscriptionId): ?array
    {
        $sub = $this->store->get($subscriptionId);
        if (!$sub) {
            return null;
        }
        if (($sub['status'] ?? '') !== 'paused') {
            return null;
        }

        $providerSubId = $sub['provider_subscription_id'] ?? '';
        if ($providerSubId && $this->shelf) {
            $provider = $sub['provider'] ?? '';
            try {
                $this->shelf->updateSubscription($provider, $providerSubId, ['resume' => true], [
                    'source_plugin' => 'commerce',
                    'source_ref' => $subscriptionId,
                ]);
            } catch (\Throwable $e) {
                // Provider resume is best-effort.
            }
        }

        $now = time();
        $interval = (string) ($sub['interval'] ?? 'month');
        $nextBilling = $sub['resume_next_billing_at'] ?? null;
        if ($nextBilling === null || $nextBilling === '') {
            $nextBilling = date('c', $this->advance($now, $interval));
        }

        $updated = $this->store->update($subscriptionId, [
            'status' => 'active',
            'paused_at' => null,
            'resume_next_billing_at' => null,
            'next_billing_at' => $nextBilling,
            'current_period_start' => date('c', $now),
        ]);
        $this->broadcast('commerce_subscription_resumed', $updated);

        return $updated;
    }

    /**
     * Retry payment for a past_due subscription via the provider.
     */
    public function retryPayment(string $subscriptionId): array
    {
        $sub = $this->store->get($subscriptionId);
        if (!$sub) {
            return ['ok' => false, 'error' => 'Subscription not found'];
        }
        if (($sub['status'] ?? '') !== 'past_due') {
            return ['ok' => false, 'error' => 'Only past_due subscriptions can be retried'];
        }

        $provider = $sub['provider'] ?? '';
        $providerSubId = $sub['provider_subscription_id'] ?? '';
        if ($provider === '' || $providerSubId === '' || !$this->shelf) {
            return ['ok' => false, 'error' => 'No provider subscription linked'];
        }

        $params = [];
        $invoiceId = $sub['dunning']['last_invoice_id'] ?? null;
        if ($invoiceId) {
            $params['invoice_id'] = $invoiceId;
        }

        $result = $this->shelf->retrySubscriptionPayment($provider, $providerSubId, $params, [
            'source_plugin' => 'commerce',
            'source_ref' => $subscriptionId,
        ]);

        if (!($result['ok'] ?? false)) {
            return ['ok' => false, 'error' => $result['error'] ?? 'Payment retry failed'];
        }

        $now = time();
        $updated = $this->store->update($subscriptionId, [
            'status' => 'active',
            'past_due_at' => null,
            'dunning' => null,
            'current_period_start' => date('c', $now),
            'next_billing_at' => date('c', $this->advance($now, $sub['interval'] ?? 'month')),
        ]);
        $this->broadcast('commerce_subscription_recovered', $updated);
        $this->broadcast('commerce_subscription_renewed', $updated);

        return ['ok' => true, 'subscription' => $updated, 'provider' => $result];
    }

    /**
     * Apply a normalized provider webhook result to the matching subscription.
     * Expects keys produced by a provider's processWebhook(): subscription_status,
     * subscription_id (provider id), and optionally payment_id.
     */
    public function applyProviderEvent(array $result): ?array
    {
        $status = $this->normalizeStatus($result['subscription_status'] ?? '');
        if ($status === null) {
            return null;
        }

        $sub = $this->matchSubscription($result);
        if (!$sub) {
            return null;
        }

        $id = $sub['id'];
        $wasPastDue = ($sub['status'] ?? '') === 'past_due' || !empty($sub['past_due_at']);

        if ($status === 'past_due') {
            $patch = [
                'status' => 'past_due',
                'past_due_at' => $sub['past_due_at'] ?? date('c'),
            ];

            $attemptCount = (int) ($result['attempt_count'] ?? 0);
            $dunning = is_array($sub['dunning'] ?? null) ? $sub['dunning'] : [];
            if ($attemptCount > 0) {
                $dunning['attempt_count'] = $attemptCount;
            } else {
                $dunning['attempt_count'] = (int) ($dunning['attempt_count'] ?? 0) + 1;
            }
            $dunning['last_failed_at'] = date('c');
            if (!empty($result['invoice_id'])) {
                $dunning['last_invoice_id'] = $result['invoice_id'];
            }
            $patch['dunning'] = $dunning;

            $updated = $this->store->update($id, $patch);
            $this->broadcast('commerce_subscription_past_due', $updated);
            $this->broadcast('commerce_subscription_payment_failed', $updated);
            $this->notifyDunning($updated);
            return $updated;
        }

        if ($status === 'canceled') {
            $updated = $this->store->update($id, [
                'status' => 'canceled',
                'canceled_at' => date('c'),
                'next_billing_at' => null,
                'dunning' => null,
            ]);
            $this->broadcast('commerce_subscription_canceled', $updated);
            return $updated;
        }

        // active — renewal succeeded; advance the billing period.
        $now = time();
        $patch = [
            'status' => 'active',
            'past_due_at' => null,
            'dunning' => null,
            'current_period_start' => date('c', $now),
            'next_billing_at' => date('c', $this->advance($now, $sub['interval'] ?? 'month')),
        ];
        $updated = $this->store->update($id, $patch);
        if ($wasPastDue) {
            $this->broadcast('commerce_subscription_recovered', $updated);
        }
        $this->broadcast('commerce_subscription_renewed', $updated);
        return $updated;
    }

    private function matchSubscription(array $result): ?array
    {
        $providerSubId = $result['subscription_id'] ?? '';
        if ($providerSubId !== '') {
            $sub = $this->store->findByProviderSubscriptionId($providerSubId);
            if ($sub) {
                return $sub;
            }
        }
        $paymentId = $result['payment_id'] ?? '';
        if ($paymentId !== '') {
            $sub = $this->store->findByPaymentId($paymentId);
            if ($sub) {
                return $sub;
            }
        }
        $orderId = $result['order_id'] ?? ($result['metadata']['order_id'] ?? '');
        if ($orderId !== '') {
            return $this->store->findByOrderId($orderId);
        }
        return null;
    }

    private function normalizeStatus(string $raw): ?string
    {
        switch (strtolower($raw)) {
            case 'past_due':
            case 'unpaid':
            case 'payment_failed':
                return 'past_due';
            case 'canceled':
            case 'cancelled':
            case 'deleted':
                return 'canceled';
            case 'active':
            case 'paid':
            case 'renewed':
                return 'active';
            default:
                return null;
        }
    }

    private function advance(int $from, string $interval): int
    {
        $seconds = self::INTERVAL_SECONDS[strtolower($interval)] ?? self::INTERVAL_SECONDS['month'];
        return $from + $seconds;
    }

    private function notifyDunning(?array $subscription): void
    {
        if (!$subscription) {
            return;
        }
        if ($this->dunningNotifier === null) {
            if (!class_exists('CommerceDunningNotifier')) {
                require_once __DIR__ . '/CommerceDunningNotifier.php';
            }
            $this->dunningNotifier = new CommerceDunningNotifier();
        }
        $this->dunningNotifier->sendPaymentFailedEmail($subscription);

        try {
            if (!class_exists('CommerceEmailService')) {
                require_once __DIR__ . '/CommerceEmailService.php';
            }
            $dataDir = function_exists('commerce_data_dir') ? commerce_data_dir() : dirname(__DIR__) . '/data';
            if (method_exists($this->store, 'getDataDir')) {
                $dataDir = dirname($this->store->getDataDir());
            }
            (new CommerceEmailService($dataDir))->sendForTrigger('subscription_payment_failed', [
                'subscription' => $subscription,
                'order' => [
                    'customer_email' => $subscription['customer_email'] ?? '',
                    'customer_name' => $subscription['customer_name'] ?? '',
                    'currency' => $subscription['currency'] ?? 'eur',
                    'total_cents' => (int) ($subscription['amount_cents'] ?? 0),
                ],
                'subscription_id' => $subscription['id'] ?? '',
            ]);
        } catch (Throwable $e) {
            error_log('Commerce subscription payment-failed email failed: ' . $e->getMessage());
        }
    }

    private function broadcast(string $event, ?array $subscription): void
    {
        if (!$subscription) {
            return;
        }
        $ctx = [
            'subscription_id' => $subscription['id'] ?? null,
            'order_id' => $subscription['order_id'] ?? null,
            'status' => $subscription['status'] ?? null,
            'customer_email' => $subscription['customer_email'] ?? null,
            'dunning' => $subscription['dunning'] ?? null,
            'attempt_count' => $subscription['dunning']['attempt_count'] ?? null,
        ];
        if (function_exists('broadcast_event')) {
            broadcast_event($event, $ctx, 'commerce');
        }
        if (function_exists('enqueue_automation')) {
            enqueue_automation($event, $ctx);
        }
    }
}
