<?php
/**
 * Stripe Tax Calculations API provider.
 *
 * Orthogonal to charge PSP: Stripe Tax can calculate tax even when checkout
 * charges via Mollie/PayPal/etc. Uses Stripe secret from Connections (or
 * context credentials). Mock mode when credentials say mock, secret missing,
 * or COMMERCE_STRIPE_TAX_MOCK=1.
 */

require_once __DIR__ . '/TaxProviderInterface.php';
require_once __DIR__ . '/ManualTaxProvider.php';

class StripeTaxProvider implements TaxProviderInterface
{
    private CommerceCatalog $catalog;

    /** @var callable|null Optional HTTP override for tests: fn(string $method, string $url, array $opts): array */
    private $httpOverride = null;

    public function __construct(CommerceCatalog $catalog, $httpOverride = null)
    {
        $this->catalog = $catalog;
        $this->httpOverride = is_callable($httpOverride) ? $httpOverride : null;
    }

    public function getId(): string
    {
        return 'stripe_tax';
    }

    public function getName(): string
    {
        return 'Stripe Tax';
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context currency, vat_id (B2B hook), credentials, force_mock
     */
    public function calculate(array $lines, ?array $shippingAddress = null, array $context = []): array
    {
        // Prefer explicit mock flags before touching Connections / filesystem.
        if ($this->wantsMockWithoutCredentials($context)) {
            return $this->calculateMock($lines, $shippingAddress, $context);
        }

        $credentials = is_array($context['credentials'] ?? null) ? $context['credentials'] : $this->resolveCredentials();
        if ($this->shouldUseMock($credentials, $context)) {
            return $this->calculateMock($lines, $shippingAddress, $context);
        }

        $secret = (string) ($credentials['secret_key'] ?? $credentials['api_key'] ?? '');
        if ($secret === '') {
            return $this->calculateMock($lines, $shippingAddress, $context);
        }

        try {
            return $this->calculateLive($lines, $shippingAddress, $context, $secret);
        } catch (Throwable $e) {
            // Fail soft to mock-shaped result rather than breaking checkout.
            $mock = $this->calculateMock($lines, $shippingAddress, $context);
            $mock['error'] = $e->getMessage();
            $mock['mode'] = 'mock_fallback';
            return $mock;
        }
    }

    /**
     * @param array<string, mixed> $context
     */
    private function wantsMockWithoutCredentials(array $context): bool
    {
        if (!empty($context['force_mock'])) {
            return true;
        }
        $env = getenv('COMMERCE_STRIPE_TAX_MOCK');
        return $env === '1' || strtolower((string) $env) === 'true';
    }

    /**
     * @param array<string, mixed> $credentials
     * @param array<string, mixed> $context
     */
    public function shouldUseMock(array $credentials, array $context = []): bool
    {
        if ($this->wantsMockWithoutCredentials($context)) {
            return true;
        }
        if (!empty($credentials['mock']) || !empty($credentials['test_mode'])) {
            return true;
        }
        $secret = (string) ($credentials['secret_key'] ?? $credentials['api_key'] ?? '');
        return $secret === '' || strtolower($secret) === 'mock';
    }

    /**
     * Deterministic tax_lines from the local rate table with source stripe_tax.
     *
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function calculateMock(array $lines, ?array $shippingAddress, array $context): array
    {
        $manual = new ManualTaxProvider($this->catalog);
        $result = $manual->calculate($lines, $shippingAddress, $context);
        $taxLines = [];
        foreach ($result['tax_lines'] as $line) {
            $line['source'] = 'stripe_tax';
            $line['provider'] = 'stripe_tax';
            $line['mode'] = 'mock';
            $taxLines[] = $line;
        }
        $result['tax_lines'] = $taxLines;
        $result['provider'] = 'stripe_tax';
        $result['mode'] = 'mock';
        return $result;
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context
     * @return array<string, mixed>
     */
    private function calculateLive(array $lines, ?array $shippingAddress, array $context, string $secret): array
    {
        $country = strtoupper(trim((string) ($shippingAddress['country'] ?? '')));
        $currency = strtolower(trim((string) ($context['currency'] ?? 'eur')));
        if (!preg_match('/^[a-z]{3}$/', $currency)) {
            $currency = 'eur';
        }

        $fields = [
            'currency' => $currency,
            'customer_details[address_source]' => 'shipping',
        ];
        if ($country !== '') {
            $fields['customer_details[address][country]'] = $country;
        }
        foreach (['line1', 'line2', 'city', 'state', 'postal_code'] as $addrKey) {
            $val = trim((string) ($shippingAddress[$addrKey] ?? ''));
            if ($addrKey === 'postal_code' && $val === '') {
                $val = trim((string) ($shippingAddress['zip'] ?? ($shippingAddress['postcode'] ?? '')));
            }
            if ($val !== '') {
                $fields['customer_details[address][' . $addrKey . ']'] = $val;
            }
        }

        // B2B VAT hook (P2-M4): pass tax_id when present; Stripe may validate later.
        $vatId = trim((string) ($context['vat_id'] ?? ($shippingAddress['vat_id'] ?? '')));
        if ($vatId !== '' && $country !== '') {
            $fields['customer_details[tax_ids][0][type]'] = 'eu_vat';
            $fields['customer_details[tax_ids][0][value]'] = $vatId;
        }

        $lineIndex = 0;
        $taxableTotal = 0;
        $refMap = [];
        foreach ($lines as $i => $line) {
            $amount = (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
            if ($amount <= 0) {
                continue;
            }
            $taxClass = CommerceSchema::normalizeTaxClass(
                $line['tax_class'] ?? ($line['commerce']['tax_class'] ?? null)
            );
            $included = CommerceSchema::lineTaxIncluded($line);
            $ref = 'line_' . $lineIndex;
            $fields['line_items[' . $lineIndex . '][amount]'] = $amount;
            $fields['line_items[' . $lineIndex . '][reference]'] = $ref;
            $fields['line_items[' . $lineIndex . '][tax_behavior]'] = $included ? 'inclusive' : 'exclusive';
            $taxCode = $this->mapTaxClassToStripeCode($taxClass, $line);
            if ($taxCode !== '') {
                $fields['line_items[' . $lineIndex . '][tax_code]'] = $taxCode;
            }
            $refMap[$ref] = [
                'tax_class' => $taxClass,
                'taxable_cents' => $amount,
                'tax_included' => $included,
                'index' => $i,
            ];
            $taxableTotal += $amount;
            $lineIndex++;
        }

        if ($lineIndex === 0) {
            return [
                'tax_cents' => 0,
                'rate' => 0.0,
                'country' => $country,
                'taxable_cents' => 0,
                'tax_lines' => [],
                'provider' => 'stripe_tax',
                'mode' => 'live',
            ];
        }

        $resp = $this->requestForm('POST', 'https://api.stripe.com/v1/tax/calculations', $fields, [
            'auth' => ['user' => $secret, 'pass' => ''],
        ]);
        if (empty($resp['ok']) || !is_array($resp['data'])) {
            throw new RuntimeException((string) ($resp['error'] ?? 'Stripe Tax calculation failed'));
        }

        return $this->mapStripeResponse($resp['data'], $country, $taxableTotal, $refMap);
    }

    /**
     * @param array<string, mixed> $data
     * @param array<string, array{tax_class: string, taxable_cents: int, index: int|string}> $refMap
     * @return array<string, mixed>
     */
    private function mapStripeResponse(array $data, string $country, int $taxableTotal, array $refMap): array
    {
        $taxExclusive = (int) ($data['tax_amount_exclusive'] ?? 0);
        $taxInclusive = (int) ($data['tax_amount_inclusive'] ?? 0);
        $taxCentsFallback = $taxExclusive + $taxInclusive;
        if ($taxCentsFallback <= 0) {
            $taxCentsFallback = (int) ($data['tax_amount_exclusive'] ?? $data['tax_amount_inclusive'] ?? 0);
        }
        $stripeLines = is_array($data['line_items']['data'] ?? null)
            ? $data['line_items']['data']
            : (is_array($data['line_items'] ?? null) ? $data['line_items'] : []);

        /** @var array<string, array{tax_class: string, rate: float, taxable_cents: int, tax_cents: int, tax_included: bool}> $buckets */
        $buckets = [];
        foreach ($stripeLines as $sLine) {
            if (!is_array($sLine)) {
                continue;
            }
            $ref = (string) ($sLine['reference'] ?? '');
            $meta = $refMap[$ref] ?? [
                'tax_class' => 'standard',
                'taxable_cents' => (int) ($sLine['amount'] ?? 0),
                'tax_included' => false,
            ];
            $lineTax = (int) ($sLine['amount_tax'] ?? 0);
            $taxable = (int) ($meta['taxable_cents'] ?? ($sLine['amount'] ?? 0));
            $included = !empty($meta['tax_included']);
            $rate = 0.0;
            $taxBreakdown = $sLine['tax_breakdown'] ?? [];
            if (is_array($taxBreakdown) && isset($taxBreakdown[0]) && is_array($taxBreakdown[0])) {
                $ratePercent = $taxBreakdown[0]['tax_rate_details']['percentage_decimal']
                    ?? $taxBreakdown[0]['percentage_decimal']
                    ?? null;
                if ($ratePercent !== null) {
                    $rate = (float) $ratePercent;
                }
            }
            if ($rate <= 0 && $taxable > 0 && $lineTax > 0) {
                $rate = $included
                    ? round(($lineTax / max(1, $taxable - $lineTax)) * 100, 4)
                    : round(($lineTax / $taxable) * 100, 4);
            }
            $taxClass = (string) ($meta['tax_class'] ?? 'standard');
            $key = $taxClass . '|' . $rate . '|' . ($included ? '1' : '0');
            if (!isset($buckets[$key])) {
                $buckets[$key] = [
                    'tax_class' => $taxClass,
                    'rate' => $rate,
                    'taxable_cents' => 0,
                    'tax_cents' => 0,
                    'tax_included' => $included,
                ];
            }
            $buckets[$key]['taxable_cents'] += $taxable;
            $buckets[$key]['tax_cents'] += $lineTax;
        }

        if ($buckets === [] && $taxCentsFallback > 0) {
            $buckets['standard|0|0'] = [
                'tax_class' => 'standard',
                'rate' => $taxableTotal > 0 ? round(($taxCentsFallback / $taxableTotal) * 100, 4) : 0.0,
                'taxable_cents' => $taxableTotal,
                'tax_cents' => $taxCentsFallback,
                'tax_included' => false,
            ];
        }

        $taxLines = [];
        $sumTax = 0;
        $taxAddCents = 0;
        $primaryRate = 0.0;
        $primaryTaxable = -1;
        $anyIncluded = false;
        $anyExcluded = false;
        foreach ($buckets as $bucket) {
            $sumTax += (int) $bucket['tax_cents'];
            $included = !empty($bucket['tax_included']);
            if ($included) {
                $anyIncluded = true;
            } else {
                $anyExcluded = true;
                $taxAddCents += (int) $bucket['tax_cents'];
            }
            $label = ucfirst($bucket['tax_class']);
            $title = ($country !== '' ? 'VAT ' . $country : 'Tax') . ' · ' . $label
                . ($included ? ' · incl.' : '');
            $basis = 'stripe_tax|' . $country . '|' . $bucket['tax_class'] . '|' . $bucket['rate'] . '|'
                . ($included ? '1' : '0') . '|' . $bucket['taxable_cents'] . '|' . $bucket['tax_cents'];
            $taxLines[] = [
                'id' => 'tl_' . substr(hash('sha256', $basis), 0, 12),
                'title' => $title,
                'rate' => $bucket['rate'],
                'country' => $country,
                'tax_class' => $bucket['tax_class'],
                'tax_included' => $included,
                'taxable_cents' => $bucket['taxable_cents'],
                'tax_cents' => $bucket['tax_cents'],
                'source' => 'stripe_tax',
                'provider' => 'stripe_tax',
            ];
            if ($bucket['taxable_cents'] > $primaryTaxable) {
                $primaryTaxable = $bucket['taxable_cents'];
                $primaryRate = $bucket['rate'];
            }
        }

        // Prefer Stripe's exclusive total when present (amount to add to charge).
        if (array_key_exists('tax_amount_exclusive', $data)) {
            $taxAddCents = $taxExclusive;
        }

        return [
            'tax_cents' => $sumTax > 0 ? $sumTax : $taxCentsFallback,
            'tax_add_cents' => $taxAddCents,
            'rate' => $primaryRate,
            'country' => $country,
            'taxable_cents' => $taxableTotal,
            'tax_lines' => $taxLines,
            'provider' => 'stripe_tax',
            'mode' => 'live',
            'stripe_calculation_id' => $data['id'] ?? null,
            'prices_include_tax' => $anyIncluded && !$anyExcluded,
            'tax_included' => $anyIncluded && !$anyExcluded,
        ];
    }

    /**
     * Map catalog tax_class to a Stripe tax_code when possible.
     *
     * @param array<string, mixed> $line
     */
    private function mapTaxClassToStripeCode(string $taxClass, array $line): string
    {
        $explicit = trim((string) ($line['tax_code'] ?? ($line['stripe_tax_code'] ?? '')));
        if ($explicit !== '' && strpos($explicit, 'txcd_') === 0) {
            return $explicit;
        }
        // Stripe general tangible goods / services codes — override via line tax_code when needed.
        $map = [
            'standard' => 'txcd_99999999',
            'reduced' => 'txcd_99999999',
            'zero' => 'txcd_00000000',
        ];
        return $map[$taxClass] ?? 'txcd_99999999';
    }

    /** @return array<string, mixed> */
    private function resolveCredentials(): array
    {
        if (!class_exists('PaymentsCredentialStore')) {
            require_once __DIR__ . '/CredentialStore.php';
        }
        try {
            $store = new PaymentsCredentialStore();
            $conn = $store->getActiveConnectionForProvider('stripe');
            if (is_array($conn) && is_array($conn['credentials'] ?? null)) {
                return $conn['credentials'];
            }
        } catch (Throwable $e) {
            // no credentials available
        }
        return [];
    }

    /**
     * Form-encoded HTTP helper (mirrors AbstractPaymentProvider::formRequest).
     *
     * @param array<string, mixed> $fields
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function requestForm(string $method, string $url, array $fields, array $options = []): array
    {
        if ($this->httpOverride !== null) {
            $fn = $this->httpOverride;
            return $fn($method, $url, array_merge($options, ['body' => $fields]));
        }

        $headers = $options['headers'] ?? [];
        $auth = $options['auth'] ?? null;
        if ($auth !== null) {
            if (is_array($auth)) {
                $headers[] = 'Authorization: Basic ' . base64_encode(($auth['user'] ?? '') . ':' . ($auth['pass'] ?? ''));
            } else {
                $headers[] = 'Authorization: Bearer ' . $auth;
            }
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => array_merge($headers, ['Content-Type: application/x-www-form-urlencoded']),
            CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_TIMEOUT => (int) ($options['timeout'] ?? 30),
        ]);

        $response = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return ['ok' => false, 'status' => 0, 'error' => $error ?: 'HTTP request failed', 'data' => null];
        }

        $decoded = json_decode($response, true);
        return [
            'ok' => $status >= 200 && $status < 300,
            'status' => $status,
            'error' => ($status >= 200 && $status < 300) ? null : 'HTTP ' . $status,
            'data' => $decoded ?? $response,
        ];
    }
}
