<?php
/**
 * Commerce notification shelf registrations (P83-M3).
 */

declare(strict_types=1);

if (!function_exists('register_broadcast_actor') || !function_exists('register_notification_formatter')) {
    return;
}

if (!function_exists('commerce_plugin_active') || !commerce_plugin_active()) {
    return;
}

register_broadcast_actor('commerce', ['commerce'], ['commerce_']);

$commerceAdminLink = static function (string $hash = 'orders'): string {
    if (function_exists('birkly_admin_url')) {
        return birkly_admin_url('commerce') . '#' . $hash;
    }

    return '/admin/?page=commerce#' . $hash;
};

register_notification_formatter('commerce', 'commerce_order_created', static function (array $entry, string $currentUserEmail) use ($commerceAdminLink): array {
    $details = $entry['details'] ?? [];
    return [
        'message' => $details['message'] ?? sprintf('New order %s', $details['order_id'] ?? ''),
        'icon' => '🛒',
        'color' => 'blue',
        'category' => 'commerce',
        'link' => $details['link'] ?? $commerceAdminLink('orders'),
    ];
});

register_notification_formatter('commerce', 'commerce_order_paid', static function (array $entry, string $currentUserEmail) use ($commerceAdminLink): array {
    $details = $entry['details'] ?? [];
    return [
        'message' => $details['message'] ?? sprintf('Order %s paid', $details['order_id'] ?? ''),
        'icon' => '💳',
        'color' => 'green',
        'category' => 'commerce',
        'link' => $details['link'] ?? $commerceAdminLink('orders'),
    ];
});

register_notification_formatter('commerce', 'commerce_subscription_created', static function (array $entry, string $currentUserEmail) use ($commerceAdminLink): array {
    $details = $entry['details'] ?? [];
    return [
        'message' => $details['message'] ?? sprintf('New subscription %s', $details['subscription_id'] ?? ''),
        'icon' => '🔁',
        'color' => 'green',
        'category' => 'commerce',
        'link' => $details['link'] ?? $commerceAdminLink('subscriptions'),
    ];
});

register_notification_formatter('commerce', 'commerce_shipment_created', static function (array $entry, string $currentUserEmail) use ($commerceAdminLink): array {
    $details = $entry['details'] ?? [];
    return [
        'message' => $details['message'] ?? sprintf('Shipment created for order %s', $details['order_id'] ?? ''),
        'icon' => '📦',
        'color' => 'blue',
        'category' => 'commerce',
        'link' => $details['link'] ?? $commerceAdminLink('orders'),
    ];
});
