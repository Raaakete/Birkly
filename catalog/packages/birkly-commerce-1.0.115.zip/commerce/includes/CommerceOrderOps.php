<?php
/**
 * Order operations helpers — notes/tags, bulk ship, customer timeline,
 * CSV export, invoice HTML, and carrier tracking URLs.
 */

class CommerceOrderOps
{
    private CommerceOrderStore $orders;
    private CommerceSubscriptionStore $subscriptions;

    /** @var null|callable(array, array, bool): void Test/automation spy */
    public static $automationSpy = null;

    /** @var array<string, string> */
    private const TRACKING_URLS = [
        'dhl' => 'https://www.dhl.com/global-en/home/tracking.html?tracking-id={num}',
        'dhl express' => 'https://www.dhl.com/global-en/home/tracking.html?tracking-id={num}',
        'ups' => 'https://www.ups.com/track?tracknum={num}',
        'fedex' => 'https://www.fedex.com/fedextrack/?trknbr={num}',
        'usps' => 'https://tools.usps.com/go/TrackConfirmAction?tLabels={num}',
        'dpd' => 'https://tracking.dpd.de/status/en_US/parcel/{num}',
        'gls' => 'https://gls-group.com/GROUP/en/parcel-tracking?match={num}',
        'hermes' => 'https://www.myhermes.de/empfangen/sendungsverfolgung/sendungsinformation#{num}',
        'royal mail' => 'https://www.royalmail.com/track-your-item#/tracking-results/{num}',
        'postnl' => 'https://www.postnl.nl/tracktrace/?B={num}',
        'austria post' => 'https://www.post.at/sv/sendungsdetails?snr={num}',
        'swiss post' => 'https://www.post.ch/swisspost-tracking?formattedParcelCodes={num}',
    ];

    public function __construct(
        ?CommerceOrderStore $orders = null,
        ?CommerceSubscriptionStore $subscriptions = null
    ) {
        $this->orders = $orders ?? new CommerceOrderStore();
        if ($subscriptions === null) {
            if (!class_exists('CommerceSubscriptionStore')) {
                require_once __DIR__ . '/CommerceSubscriptionStore.php';
            }
            $subscriptions = new CommerceSubscriptionStore();
        }
        $this->subscriptions = $subscriptions;
    }

    public function getOrdersStore(): CommerceOrderStore
    {
        return $this->orders;
    }

    /**
     * @return array{ok: bool, error?: string, order?: array}
     */
    public function addNote(string $orderId, string $body, string $author = '', ?array $actedBy = null): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        $text = trim($body);
        if ($text === '') {
            return ['ok' => false, 'error' => 'Note cannot be empty'];
        }
        $authorLabel = trim($author);
        if ($authorLabel === '' && is_array($actedBy)) {
            $authorLabel = trim((string) ($actedBy['label'] ?? $actedBy['name'] ?? $actedBy['email'] ?? ''));
        }
        if ($authorLabel === '') {
            $authorLabel = 'admin';
        }
        $notes = is_array($order['notes'] ?? null) ? $order['notes'] : [];
        $notes[] = [
            'id' => 'note_' . bin2hex(random_bytes(4)),
            'body' => $text,
            'author' => $authorLabel,
            'author_id' => is_array($actedBy) && !empty($actedBy['id']) ? (string) $actedBy['id'] : null,
            'created_at' => date('c'),
        ];
        $activity = is_array($order['fulfillment_activity'] ?? null) ? $order['fulfillment_activity'] : [];
        $activity[] = [
            'id' => 'fact_' . bin2hex(random_bytes(4)),
            'at' => date('c'),
            'action' => 'note_added',
            'actor_label' => $authorLabel,
            'actor_id' => is_array($actedBy) && !empty($actedBy['id']) ? (string) $actedBy['id'] : null,
            'actor_email' => is_array($actedBy) && !empty($actedBy['email']) ? (string) $actedBy['email'] : null,
            'detail' => mb_substr($text, 0, 160),
        ];
        $updated = $this->orders->update($orderId, [
            'notes' => $notes,
            'fulfillment_activity' => $activity,
        ]);
        return ['ok' => true, 'order' => $updated];
    }

    /**
     * @param list<string> $tags
     * @return array{ok: bool, error?: string, order?: array}
     */
    public function setTags(string $orderId, array $tags): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        $clean = [];
        foreach ($tags as $tag) {
            $t = strtolower(trim((string) $tag));
            $t = preg_replace('/[^a-z0-9_\\-\\s]/', '', $t) ?? '';
            $t = trim(preg_replace('/\\s+/', ' ', $t) ?? '');
            if ($t === '' || in_array($t, $clean, true)) {
                continue;
            }
            $clean[] = $t;
        }
        $updated = $this->orders->update($orderId, ['tags' => array_values($clean)]);
        return ['ok' => true, 'order' => $updated];
    }

    /**
     * Quantity already shipped for a line (from structured shipments + legacy fields).
     */
    public static function shippedQuantity(array $order, string $lineId): int
    {
        $lineId = (string) $lineId;
        if ($lineId === '') {
            return 0;
        }
        $sum = 0;
        $legacyHit = false;
        foreach (is_array($order['shipments'] ?? null) ? $order['shipments'] : [] as $shipment) {
            if (!is_array($shipment)) {
                continue;
            }
            if (!empty($shipment['items']) && is_array($shipment['items'])) {
                foreach ($shipment['items'] as $item) {
                    if (!is_array($item)) {
                        continue;
                    }
                    if ((string) ($item['line_id'] ?? '') === $lineId) {
                        $sum += max(0, (int) ($item['quantity'] ?? 0));
                    }
                }
                continue;
            }
            if ((string) ($shipment['line_id'] ?? '') === $lineId) {
                $legacyHit = true;
            }
        }
        if ($sum > 0) {
            return $sum;
        }
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            if ((string) ($line['line_id'] ?? '') !== $lineId) {
                continue;
            }
            if (isset($line['quantity_shipped'])) {
                return max(0, (int) $line['quantity_shipped']);
            }
            $qty = max(1, (int) ($line['quantity'] ?? 1));
            if ($legacyHit || ($line['fulfillment_status'] ?? '') === 'shipped' || !empty($line['tracking_number'])) {
                return $qty;
            }
            if (($line['fulfillment_status'] ?? '') === 'partial') {
                return max(0, (int) ($line['quantity_shipped'] ?? 0));
            }
            return 0;
        }
        return 0;
    }

    public static function lineQuantity(array $line): int
    {
        return max(1, (int) ($line['quantity'] ?? 1));
    }

    public static function remainingQuantity(array $order, array $line): int
    {
        if (self::normalizeLineFulfillment($line['fulfillment'] ?? null) !== 'ship') {
            return 0;
        }
        $lineId = (string) ($line['line_id'] ?? '');
        return max(0, self::lineQuantity($line) - self::shippedQuantity($order, $lineId));
    }

    /**
     * Missing / invalid fulfillment defaults to ship. Only explicit `none` opts out.
     */
    public static function normalizeLineFulfillment($fulfillment): string
    {
        $f = strtolower(trim((string) $fulfillment));
        if (in_array($f, ['ship', 'deliver', 'register', 'gift_card', 'none'], true)) {
            return $f;
        }
        return 'ship';
    }

    public static function lineRequiresFulfillment(array $line): bool
    {
        return self::normalizeLineFulfillment($line['fulfillment'] ?? null) !== 'none';
    }

    public static function orderRequiresFulfillment(array $order): bool
    {
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            if (is_array($line) && self::lineRequiresFulfillment($line)) {
                return true;
            }
        }
        return false;
    }

    /**
     * True when any units have already left the warehouse (cancel no longer safe).
     */
    public static function orderHasShipmentProgress(array $order): bool
    {
        $shipments = is_array($order['shipments'] ?? null) ? $order['shipments'] : [];
        if ($shipments !== []) {
            return true;
        }
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            if (!is_array($line)) {
                continue;
            }
            if (self::normalizeLineFulfillment($line['fulfillment'] ?? null) !== 'ship') {
                continue;
            }
            if (self::shippedQuantity($order, (string) ($line['line_id'] ?? '')) > 0) {
                return true;
            }
            if ((int) ($line['quantity_shipped'] ?? 0) > 0) {
                return true;
            }
        }
        $fulfillmentStatus = strtolower(trim((string) ($order['fulfillment_status'] ?? '')));
        return in_array($fulfillmentStatus, ['partial', 'fulfilled'], true);
    }

    public static function orderCanBeCanceled(array $order): bool
    {
        $status = (string) ($order['status'] ?? '');
        if (!in_array($status, ['pending', 'paid', 'partially_refunded'], true)) {
            return false;
        }
        return !self::orderHasShipmentProgress($order);
    }

    /**
     * Whether an auto-fulfilled line (deliver / register / gift_card) looks complete.
     */
    public static function autoLineFulfilled(array $order, array $line): bool
    {
        $type = self::normalizeLineFulfillment($line['fulfillment'] ?? null);
        if ($type === 'ship' || $type === 'none') {
            return $type === 'none';
        }
        if ($type === 'gift_card' && !empty($line['gift_card_codes'])) {
            return true;
        }
        if ($type === 'deliver' && (!empty($line['delivery_token']) || !empty($line['download_url']))) {
            return true;
        }
        if ($type === 'register' && (!empty($line['registration_id']) || !empty($line['attendee_id']))) {
            return true;
        }

        $lineId = (string) ($line['line_id'] ?? '');
        $entryId = (string) ($line['entry_id'] ?? '');
        $matchedType = false;
        foreach (is_array($order['fulfillment_results'] ?? null) ? $order['fulfillment_results'] : [] as $result) {
            if (!is_array($result) || empty($result['ok'])) {
                continue;
            }
            $resultType = self::normalizeLineFulfillment($result['fulfillment'] ?? null);
            if ($resultType !== $type) {
                continue;
            }
            $matchedType = true;
            if ($lineId !== '' && (string) ($result['line_id'] ?? '') === $lineId) {
                return true;
            }
            if ($entryId !== '' && (string) ($result['entry_id'] ?? '') === $entryId) {
                return true;
            }
        }
        // Legacy: a successful post-pay result of this type on a paid order.
        return $matchedType && in_array(($order['status'] ?? ''), ['paid', 'partially_refunded', 'refunded'], true);
    }

    public static function lineIsComplete(array $order, array $line): bool
    {
        $type = self::normalizeLineFulfillment($line['fulfillment'] ?? null);
        if ($type === 'none') {
            return true;
        }
        if ($type === 'ship') {
            return self::remainingQuantity($order, $line) <= 0;
        }
        return self::autoLineFulfilled($order, $line);
    }

    /**
     * Open work remains for paid orders that still need packing or unfinished auto steps.
     */
    public static function orderHasOpenFulfillmentWork(array $order): bool
    {
        $status = (string) ($order['status'] ?? '');
        if (!in_array($status, ['paid', 'partially_refunded'], true)) {
            return false;
        }
        if (!self::orderRequiresFulfillment($order)) {
            return false;
        }
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            if (!is_array($line) || !self::lineRequiresFulfillment($line)) {
                continue;
            }
            if (!self::lineIsComplete($order, $line)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @return array{label: string, next_action: string, status: string, key: string}
     */
    public static function lineFulfillmentGuide(array $order, array $line): array
    {
        $type = self::normalizeLineFulfillment($line['fulfillment'] ?? null);
        $complete = self::lineIsComplete($order, $line);
        $guides = [
            'ship' => [
                'label' => 'Ship',
                'open' => 'Pack and ship remaining units, then record tracking.',
                'done' => 'Shipped.',
            ],
            'deliver' => [
                'label' => 'Digital delivery',
                'open' => 'Confirm the download/token was issued to the customer.',
                'done' => 'Digital delivery issued.',
            ],
            'register' => [
                'label' => 'Registration',
                'open' => 'Confirm the attendee/ticket registration completed.',
                'done' => 'Registration completed.',
            ],
            'gift_card' => [
                'label' => 'Gift card',
                'open' => 'Confirm the gift card code was issued.',
                'done' => 'Gift card issued.',
            ],
            'none' => [
                'label' => 'No fulfillment',
                'open' => 'No fulfillment required.',
                'done' => 'No fulfillment required.',
            ],
        ];
        $guide = $guides[$type] ?? $guides['ship'];
        $status = $complete ? 'done' : 'open';
        if ($type === 'ship' && !$complete) {
            $rem = self::remainingQuantity($order, $line);
            $shipped = self::shippedQuantity($order, (string) ($line['line_id'] ?? ''));
            if ($shipped > 0 && $rem > 0) {
                $status = 'partial';
                $guide['open'] = 'Ship remaining ' . $rem . ' unit(s).';
            } elseif ($rem > 0) {
                $guide['open'] = 'Ship ' . $rem . ' unit(s). Add carrier + tracking when ready.';
            }
        }
        return [
            'key' => $type,
            'label' => $guide['label'],
            'status' => $status,
            'next_action' => $complete ? $guide['done'] : $guide['open'],
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public static function orderFulfillmentActors(array $order): array
    {
        $actors = [];
        $seen = [];
        foreach (is_array($order['shipments'] ?? null) ? $order['shipments'] : [] as $shipment) {
            if (!is_array($shipment)) {
                continue;
            }
            $label = trim((string) ($shipment['created_by'] ?? $shipment['acted_by_label'] ?? ''));
            $id = (string) ($shipment['created_by_id'] ?? $shipment['acted_by_id'] ?? '');
            $key = $id !== '' ? 'id:' . $id : 'label:' . strtolower($label);
            if ($label === '' || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $actors[] = [
                'label' => $label,
                'id' => $id !== '' ? $id : null,
                'email' => $shipment['created_by_email'] ?? $shipment['acted_by_email'] ?? null,
                'last_at' => $shipment['created_at'] ?? null,
                'source' => 'shipment',
            ];
        }
        foreach (is_array($order['fulfillment_activity'] ?? null) ? $order['fulfillment_activity'] : [] as $row) {
            if (!is_array($row)) {
                continue;
            }
            $label = trim((string) ($row['actor_label'] ?? ''));
            $id = (string) ($row['actor_id'] ?? '');
            $key = $id !== '' ? 'id:' . $id : 'label:' . strtolower($label);
            if ($label === '' || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $actors[] = [
                'label' => $label,
                'id' => $id !== '' ? $id : null,
                'email' => $row['actor_email'] ?? null,
                'last_at' => $row['at'] ?? null,
                'source' => 'activity',
            ];
        }
        return $actors;
    }

    /**
     * @param array{id?: ?string, email?: ?string, name?: string, label?: string}|null $actor
     * @return array{ok: bool, open: list<array>, history: list<array>, counts: array{open: int, history: int, all: int}}
     */
    public function listFulfillmentDesk(string $view = 'open', string $search = '', ?array $actor = null): array
    {
        $view = in_array($view, ['open', 'history', 'all'], true) ? $view : 'open';
        $search = trim($search);
        $open = [];
        $history = [];

        foreach ($this->orders->listAll() as $order) {
            if (!is_array($order)) {
                continue;
            }
            $status = (string) ($order['status'] ?? '');
            if (in_array($status, ['abandoned', 'failed', 'canceled', 'pending'], true)) {
                continue;
            }
            $order = $this->enrichOrder($order);
            if (!self::orderRequiresFulfillment($order)) {
                continue;
            }
            $card = $this->buildFulfillmentCard($order);
            if ($search !== '' && !$this->fulfillmentCardMatchesSearch($card, $search)) {
                continue;
            }
            if (!empty($card['has_open_work'])) {
                $open[] = $card;
            } else {
                $history[] = $card;
            }
        }

        usort($open, static function ($a, $b) {
            return strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? ''));
        });
        usort($history, static function ($a, $b) {
            $aAt = (string) ($a['fulfilled_at'] ?? $a['updated_at'] ?? $a['created_at'] ?? '');
            $bAt = (string) ($b['fulfilled_at'] ?? $b['updated_at'] ?? $b['created_at'] ?? '');
            return strcmp($bAt, $aAt);
        });

        $items = $view === 'history' ? $history : ($view === 'all' ? array_merge($open, $history) : $open);
        return [
            'ok' => true,
            'view' => $view,
            'items' => $items,
            'open' => $open,
            'history' => $history,
            'counts' => [
                'open' => count($open),
                'history' => count($history),
                'all' => count($open) + count($history),
            ],
            'viewer' => $actor,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function buildFulfillmentCard(array $order): array
    {
        $order = $this->enrichOrder($order);
        $lines = [];
        $typeCounts = [];
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            if (!is_array($line) || !self::lineRequiresFulfillment($line)) {
                continue;
            }
            $guide = self::lineFulfillmentGuide($order, $line);
            $typeCounts[$guide['key']] = ($typeCounts[$guide['key']] ?? 0) + 1;
            $lines[] = [
                'line_id' => $line['line_id'] ?? '',
                'title' => $line['title'] ?? '',
                'sku' => $line['sku'] ?? '',
                'quantity' => self::lineQuantity($line),
                'quantity_shipped' => $line['quantity_shipped'] ?? self::shippedQuantity($order, (string) ($line['line_id'] ?? '')),
                'quantity_remaining' => $line['quantity_remaining'] ?? self::remainingQuantity($order, $line),
                'fulfillment' => $guide['key'],
                'fulfillment_label' => $guide['label'],
                'status' => $guide['status'],
                'next_action' => $guide['next_action'],
            ];
        }

        $hasOpen = self::orderHasOpenFulfillmentWork($order);
        $actors = self::orderFulfillmentActors($order);
        $lastActor = $actors !== [] ? $actors[array_key_last($actors)] : null;
        // Prefer most recent shipment actor when available.
        $shipments = is_array($order['shipments'] ?? null) ? $order['shipments'] : [];
        if ($shipments !== []) {
            $lastShipment = $shipments[array_key_last($shipments)];
            if (is_array($lastShipment) && trim((string) ($lastShipment['created_by'] ?? '')) !== '') {
                $lastActor = [
                    'label' => (string) $lastShipment['created_by'],
                    'id' => $lastShipment['created_by_id'] ?? null,
                    'email' => $lastShipment['created_by_email'] ?? null,
                    'last_at' => $lastShipment['created_at'] ?? null,
                    'source' => 'shipment',
                ];
            }
        }
        $primaryAction = 'open_order';
        $primaryLabel = 'Open order';
        if ($hasOpen && (($typeCounts['ship'] ?? 0) > 0)) {
            foreach ($lines as $line) {
                if (($line['fulfillment'] ?? '') === 'ship' && ($line['status'] ?? '') !== 'done') {
                    $primaryAction = 'ship';
                    $primaryLabel = ($line['status'] ?? '') === 'partial' ? 'Ship remaining' : 'Mark shipped';
                    break;
                }
            }
        }

        return [
            'id' => $order['id'] ?? '',
            'order_number' => $order['order_number'] ?? ($order['id'] ?? ''),
            'status' => $order['status'] ?? '',
            'fulfillment_status' => $order['fulfillment_status'] ?? self::deriveOrderFulfillmentStatus($order),
            'has_open_work' => $hasOpen,
            'customer_email' => $order['customer_email'] ?? '',
            'customer_name' => $order['customer_name'] ?? (($order['shipping_address']['name'] ?? '') ?: ''),
            'currency' => $order['currency'] ?? 'eur',
            'total_cents' => $order['total_cents'] ?? 0,
            'created_at' => $order['created_at'] ?? null,
            'updated_at' => $order['updated_at'] ?? null,
            'fulfilled_at' => $order['fulfilled_at'] ?? null,
            'shipping_address' => $order['shipping_address'] ?? null,
            'type_counts' => $typeCounts,
            'lines' => $lines,
            'shipments' => $order['shipments'] ?? [],
            'fulfillment_activity' => $order['fulfillment_activity'] ?? [],
            'actors' => $actors,
            'last_actor' => $lastActor,
            'primary_action' => $primaryAction,
            'primary_label' => $primaryLabel,
            'summary' => $this->fulfillmentCardSummary($typeCounts, $hasOpen, $order),
        ];
    }

    /**
     * @param array<string, int> $typeCounts
     */
    private function fulfillmentCardSummary(array $typeCounts, bool $hasOpen, array $order): string
    {
        $bits = [];
        foreach (['ship' => 'Ship', 'deliver' => 'Digital', 'register' => 'Register', 'gift_card' => 'Gift card'] as $key => $label) {
            if (!empty($typeCounts[$key])) {
                $bits[] = $label . ($typeCounts[$key] > 1 ? ' ×' . $typeCounts[$key] : '');
            }
        }
        $types = $bits !== [] ? implode(' · ', $bits) : 'Fulfillment';
        if ($hasOpen) {
            return $types . ' — action needed';
        }
        return $types . ' — complete';
    }

    private function fulfillmentCardMatchesSearch(array $card, string $search): bool
    {
        $hay = strtolower(implode(' ', [
            $card['order_number'] ?? '',
            $card['id'] ?? '',
            $card['customer_email'] ?? '',
            $card['customer_name'] ?? '',
            $card['summary'] ?? '',
            json_encode($card['lines'] ?? []),
            json_encode($card['actors'] ?? []),
        ]));
        return str_contains($hay, strtolower($search));
    }

    /**
     * @return 'unfulfilled'|'partial'|'fulfilled'
     */
    public static function deriveOrderFulfillmentStatus(array $order): string
    {
        $total = 0;
        $complete = 0;
        $hasPartialProgress = false;
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            if (!is_array($line) || !self::lineRequiresFulfillment($line)) {
                continue;
            }
            $total++;
            $type = self::normalizeLineFulfillment($line['fulfillment'] ?? null);
            if ($type === 'ship') {
                $qty = self::lineQuantity($line);
                $shipped = self::shippedQuantity($order, (string) ($line['line_id'] ?? ''));
                if ($shipped >= $qty && $qty > 0) {
                    $complete++;
                } elseif ($shipped > 0) {
                    $hasPartialProgress = true;
                }
                continue;
            }
            if (self::lineIsComplete($order, $line)) {
                $complete++;
            }
        }
        if ($total === 0) {
            return 'unfulfilled';
        }
        if ($complete >= $total) {
            return 'fulfilled';
        }
        if ($complete > 0 || $hasPartialProgress) {
            return 'partial';
        }
        return 'unfulfilled';
    }

    /**
     * Create a structured shipment (partial or full). Only ship fulfillment lines.
     *
     * @param array{
     *   items?: list<array{line_id?: string, quantity?: int}>,
     *   line_id?: string,
     *   tracking_number?: string,
     *   carrier?: string,
     *   package_count?: int,
     *   notify_customer?: bool,
     *   shipped_at?: string|null
     * } $input
     * @return array{ok: bool, error?: string, order?: array, shipment?: array}
     */
    public function createShipment(string $orderId, array $input): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        if (($order['status'] ?? '') === 'abandoned') {
            return ['ok' => false, 'error' => 'Abandoned orders cannot be shipped'];
        }

        $itemsIn = is_array($input['items'] ?? null) ? $input['items'] : [];
        if ($itemsIn === [] && trim((string) ($input['line_id'] ?? '')) !== '') {
            $lineId = (string) $input['line_id'];
            $remaining = 0;
            foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
                if ((string) ($line['line_id'] ?? '') === $lineId) {
                    $remaining = self::remainingQuantity($order, $line);
                    break;
                }
            }
            if ($remaining <= 0) {
                return ['ok' => false, 'error' => 'No remaining quantity to ship for this line'];
            }
            $itemsIn = [['line_id' => $lineId, 'quantity' => $remaining]];
        }

        if ($itemsIn === []) {
            // Ship all remaining shippable qty.
            foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
                $rem = self::remainingQuantity($order, $line);
                if ($rem > 0) {
                    $itemsIn[] = ['line_id' => (string) ($line['line_id'] ?? ''), 'quantity' => $rem];
                }
            }
        }

        $resolved = [];
        $linesById = [];
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            $linesById[(string) ($line['line_id'] ?? '')] = $line;
        }

        foreach ($itemsIn as $item) {
            if (!is_array($item)) {
                continue;
            }
            $lineId = trim((string) ($item['line_id'] ?? ''));
            $qty = max(0, (int) ($item['quantity'] ?? 0));
            if ($lineId === '' || $qty <= 0) {
                continue;
            }
            $line = $linesById[$lineId] ?? null;
            if ($line === null) {
                return ['ok' => false, 'error' => 'Line item not found on order: ' . $lineId];
            }
            if (self::normalizeLineFulfillment($line['fulfillment'] ?? null) !== 'ship') {
                return ['ok' => false, 'error' => 'Line is not shippable: ' . $lineId];
            }
            $remaining = self::remainingQuantity($order, $line);
            if ($qty > $remaining) {
                return ['ok' => false, 'error' => 'Cannot ship more than remaining quantity for ' . ($line['title'] ?? $lineId)];
            }
            if (isset($resolved[$lineId])) {
                $resolved[$lineId]['quantity'] += $qty;
                if ($resolved[$lineId]['quantity'] > $remaining) {
                    return ['ok' => false, 'error' => 'Cannot ship more than remaining quantity for ' . ($line['title'] ?? $lineId)];
                }
            } else {
                $resolved[$lineId] = [
                    'line_id' => $lineId,
                    'quantity' => $qty,
                    'title' => (string) ($line['title'] ?? $lineId),
                    'sku' => (string) ($line['sku'] ?? ''),
                ];
            }
        }

        if ($resolved === []) {
            return ['ok' => false, 'error' => 'No shippable items selected'];
        }

        // Re-validate combined qty against remaining (for duplicate line entries).
        foreach ($resolved as $lineId => $item) {
            $remaining = self::remainingQuantity($order, $linesById[$lineId]);
            if ($item['quantity'] > $remaining) {
                return ['ok' => false, 'error' => 'Cannot ship more than remaining quantity for ' . $item['title']];
            }
        }

        $tracking = trim((string) ($input['tracking_number'] ?? ''));
        $carrier = trim((string) ($input['carrier'] ?? ''));
        $packageCount = max(1, (int) ($input['package_count'] ?? 1));
        $notify = !empty($input['notify_customer']);
        $when = trim((string) ($input['shipped_at'] ?? ''));
        if ($when === '') {
            $when = date('c');
        }

        $actor = is_array($input['acted_by'] ?? null) ? $input['acted_by'] : [];
        $actorLabel = trim((string) ($actor['label'] ?? $actor['name'] ?? ''));
        if ($actorLabel === '') {
            $actorLabel = trim((string) ($actor['email'] ?? '')) ?: 'admin';
        }
        $shipment = [
            'id' => 'ship_' . bin2hex(random_bytes(6)),
            'created_at' => $when,
            'tracking_number' => $tracking,
            'carrier' => $carrier,
            'package_count' => $packageCount,
            'items' => array_values($resolved),
            'notify_customer' => $notify,
            'created_by' => $actorLabel,
            'created_by_id' => isset($actor['id']) && $actor['id'] !== '' && $actor['id'] !== null
                ? (string) $actor['id'] : null,
            'created_by_email' => isset($actor['email']) && $actor['email'] !== '' && $actor['email'] !== null
                ? (string) $actor['email'] : null,
        ];

        // When EasyPost is active, create_shipment / mark shipped triggers pushOrder
        // for a tracker/label and stores tracking on the shipment.
        $pushResult = null;
        if (empty($input['skip_external_push'])) {
            $pushResult = $this->maybePushEasyPostShipment($order, $resolved, $shipment, $input);
            if (is_array($pushResult)) {
                if (!empty($pushResult['tracking_number']) && $tracking === '') {
                    $tracking = (string) $pushResult['tracking_number'];
                    $shipment['tracking_number'] = $tracking;
                }
                if (!empty($pushResult['carrier']) && $carrier === '') {
                    $carrier = (string) $pushResult['carrier'];
                    $shipment['carrier'] = $carrier;
                }
                if (!empty($pushResult['label_url'])) {
                    $shipment['label_url'] = $pushResult['label_url'];
                }
                if (!empty($pushResult['tracker_id'])) {
                    $shipment['easypost_tracker_id'] = $pushResult['tracker_id'];
                }
                if (!empty($pushResult['public_url'])) {
                    $shipment['tracking_url'] = $pushResult['public_url'];
                }
                $shipment['source'] = 'easypost';
                $shipment['external_push'] = $pushResult;
            }
        }

        $shipments = is_array($order['shipments'] ?? null) ? $order['shipments'] : [];
        $shipments[] = $shipment;

        // Apply to a synthetic order for qty math, then rewrite lines.
        $orderWithShipments = $order;
        $orderWithShipments['shipments'] = $shipments;

        $lines = is_array($order['lines'] ?? null) ? $order['lines'] : [];
        foreach ($lines as $idx => $line) {
            if (self::normalizeLineFulfillment($line['fulfillment'] ?? null) !== 'ship') {
                continue;
            }
            $lineId = (string) ($line['line_id'] ?? '');
            $shipped = self::shippedQuantity($orderWithShipments, $lineId);
            $qty = self::lineQuantity($line);
            $lines[$idx]['quantity_shipped'] = $shipped;
            if ($shipped <= 0) {
                $lines[$idx]['fulfillment_status'] = 'unfulfilled';
            } elseif ($shipped >= $qty) {
                $lines[$idx]['fulfillment_status'] = 'shipped';
                if ($tracking !== '') {
                    $lines[$idx]['tracking_number'] = $tracking;
                }
                if ($carrier !== '') {
                    $lines[$idx]['carrier'] = $carrier;
                }
                $lines[$idx]['shipped_at'] = $when;
            } else {
                $lines[$idx]['fulfillment_status'] = 'partial';
                if ($tracking !== '') {
                    $lines[$idx]['tracking_number'] = $tracking;
                }
                if ($carrier !== '') {
                    $lines[$idx]['carrier'] = $carrier;
                }
                $lines[$idx]['shipped_at'] = $when;
            }
        }

        $mergedForStatus = array_merge($order, [
            'lines' => $lines,
            'shipments' => $shipments,
        ]);
        $orderFulfillment = self::deriveOrderFulfillmentStatus($mergedForStatus);

        $activity = is_array($order['fulfillment_activity'] ?? null) ? $order['fulfillment_activity'] : [];
        $activity[] = [
            'id' => 'fact_' . bin2hex(random_bytes(4)),
            'at' => $when,
            'action' => 'shipment_created',
            'actor_label' => $actorLabel,
            'actor_id' => $shipment['created_by_id'],
            'actor_email' => $shipment['created_by_email'],
            'detail' => 'Shipment ' . ($shipment['id'] ?? '') . ($tracking !== '' ? (' · ' . $tracking) : ''),
            'shipment_id' => $shipment['id'] ?? null,
        ];

        $patch = [
            'lines' => $lines,
            'shipments' => $shipments,
            'fulfillment_status' => $orderFulfillment,
            'fulfillment_activity' => $activity,
        ];
        if ($orderFulfillment === 'fulfilled' && empty($order['fulfilled_at'])) {
            $patch['fulfilled_at'] = $when;
        }
        if (is_array($pushResult)) {
            $results = is_array($order['fulfillment_results'] ?? null) ? $order['fulfillment_results'] : [];
            $results[] = [
                'ok' => !empty($pushResult['ok']),
                'adapter' => 'easypost',
                'shipment_id' => $shipment['id'],
                'tracking_number' => $shipment['tracking_number'] ?? '',
                'carrier' => $shipment['carrier'] ?? '',
                'label_url' => $shipment['label_url'] ?? null,
                'tracker_id' => $shipment['easypost_tracker_id'] ?? null,
                'mode' => $pushResult['mode'] ?? null,
                'at' => date('c'),
                'acted_by' => $actorLabel,
            ];
            $patch['fulfillment_results'] = $results;
        }

        $updated = $this->orders->update($orderId, $patch);

        if (!$updated) {
            return ['ok' => false, 'error' => 'Failed to save shipment'];
        }

        $this->fireShipmentAutomation($updated, $shipment, $notify);

        return ['ok' => true, 'order' => $updated, 'shipment' => $shipment];
    }

    /**
     * Push to EasyPost when that adapter is active.
     *
     * @param array<string, mixed> $order
     * @param array<string, array<string, mixed>> $resolved
     * @param array<string, mixed> $shipment
     * @param array<string, mixed> $input
     * @return array<string, mixed>|null
     */
    private function maybePushEasyPostShipment(array $order, array $resolved, array $shipment, array $input): ?array
    {
        if (!class_exists('FulfillmentAdapterResolver')) {
            require_once __DIR__ . '/FulfillmentAdapterResolver.php';
        }
        if (FulfillmentAdapterResolver::getActiveAdapterId() !== FulfillmentAdapterResolver::PROVIDER_EASYPOST) {
            return null;
        }
        $adapter = FulfillmentAdapterResolver::resolve(FulfillmentAdapterResolver::PROVIDER_EASYPOST);
        if (!$adapter->isConfigured()) {
            return null;
        }

        $shipLines = [];
        $linesById = [];
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            $linesById[(string) ($line['line_id'] ?? '')] = $line;
        }
        foreach ($resolved as $lineId => $item) {
            $base = $linesById[$lineId] ?? ['line_id' => $lineId, 'fulfillment' => 'ship'];
            $shipLines[] = array_merge($base, [
                'quantity' => (int) ($item['quantity'] ?? 1),
                'fulfillment' => 'ship',
            ]);
        }

        $pushOrder = $order;
        $pushOrder['lines'] = $shipLines;
        if (!empty($input['force_mock'])) {
            $pushOrder['force_mock'] = true;
        }
        if (!empty($shipment['tracking_number'])) {
            $pushOrder['tracking_number'] = $shipment['tracking_number'];
        }

        $push = $adapter->pushOrder($pushOrder);
        return is_array($push) ? $push : null;
    }

    /**
     * Mark all remaining shippable quantity on each order as shipped (one shipment per order).
     *
     * @param list<string> $orderIds
     * @return array{ok: bool, updated: list<array>, errors: list<string>}
     */
    /**
     * @param array{id?: ?string, email?: ?string, name?: string, label?: string}|null $actedBy
     */
    public function bulkMarkShipped(
        array $orderIds,
        string $carrier = '',
        string $trackingPrefix = '',
        bool $notifyCustomer = false,
        ?array $actedBy = null
    ): array {
        $updated = [];
        $errors = [];
        $carrier = trim($carrier);
        $prefix = trim($trackingPrefix);

        foreach ($orderIds as $orderId) {
            $orderId = (string) $orderId;
            $order = $this->orders->get($orderId);
            if (!$order) {
                $errors[] = $orderId . ': not found';
                continue;
            }
            if (($order['status'] ?? '') === 'abandoned') {
                $errors[] = $orderId . ': abandoned';
                continue;
            }

            $items = [];
            foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $idx => $line) {
                $rem = self::remainingQuantity($order, $line);
                if ($rem <= 0) {
                    continue;
                }
                $items[] = [
                    'line_id' => (string) ($line['line_id'] ?? ''),
                    'quantity' => $rem,
                ];
            }
            if ($items === []) {
                $errors[] = ($order['order_number'] ?? $orderId) . ': no shippable lines to update';
                continue;
            }

            $tracking = '';
            if ($prefix !== '') {
                $tracking = $prefix . '-' . substr(preg_replace('/[^a-zA-Z0-9]/', '', $orderId) ?? $orderId, -6);
            }
            if ($tracking === '') {
                $tracking = 'MANUAL-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
            }

            $payload = [
                'items' => $items,
                'tracking_number' => $tracking,
                'carrier' => $carrier !== '' ? $carrier : 'Manual',
                'package_count' => 1,
                'notify_customer' => $notifyCustomer,
            ];
            if (is_array($actedBy)) {
                $payload['acted_by'] = $actedBy;
            }
            $result = $this->createShipment($orderId, $payload);
            if (!($result['ok'] ?? false)) {
                $errors[] = ($order['order_number'] ?? $orderId) . ': ' . ($result['error'] ?? 'ship failed');
                continue;
            }
            $updated[] = $result['order'];
        }

        return ['ok' => count($updated) > 0, 'updated' => $updated, 'errors' => $errors];
    }

    /**
     * @param array<string, mixed> $shipment
     */
    private function fireShipmentAutomation(array $order, array $shipment, bool $notifyCustomer): void
    {
        $payload = [
            'order_id' => $order['id'] ?? '',
            'order_number' => $order['order_number'] ?? '',
            'customer_email' => $order['customer_email'] ?? '',
            'fulfillment_status' => $order['fulfillment_status'] ?? self::deriveOrderFulfillmentStatus($order),
            'shipment' => $shipment,
            'shipment_id' => $shipment['id'] ?? '',
            'tracking_number' => $shipment['tracking_number'] ?? '',
            'carrier' => $shipment['carrier'] ?? '',
            'package_count' => (int) ($shipment['package_count'] ?? 1),
            'lines' => $shipment['items'] ?? [],
            'notify_customer' => $notifyCustomer,
        ];

        if (is_callable(self::$automationSpy)) {
            (self::$automationSpy)('commerce_shipment_created', $payload);
            if ($notifyCustomer) {
                (self::$automationSpy)('commerce_order_shipped', $payload);
            }
        }

        if (function_exists('broadcast_event')) {
            broadcast_event('commerce_shipment_created', $payload, 'commerce');
        }
        if (function_exists('enqueue_automation')) {
            enqueue_automation('commerce_shipment_created', $payload);
            if ($notifyCustomer) {
                enqueue_automation('commerce_order_shipped', $payload);
            }
        }
        if (class_exists('CommerceNotify')) {
            CommerceNotify::shipmentCreated($order, $shipment, $notifyCustomer);
        }

        if ($notifyCustomer) {
            $this->sendTransactionalEmail('order_shipped', [
                'order' => $order,
                'shipment' => $shipment,
                'tracking_number' => $shipment['tracking_number'] ?? '',
                'carrier' => $shipment['carrier'] ?? '',
            ]);
        }
    }

    /**
     * @param array<string, mixed> $context
     */
    private function sendTransactionalEmail(string $trigger, array $context): void
    {
        try {
            if (!class_exists('CommerceEmailService')) {
                require_once __DIR__ . '/CommerceEmailService.php';
            }
            $dataDir = dirname($this->orders->getDataDir());
            (new CommerceEmailService($dataDir))->sendForTrigger($trigger, $context);
        } catch (Throwable $e) {
            error_log('Commerce transactional email failed (' . $trigger . '): ' . $e->getMessage());
        }
    }

    /**
     * @return array{email: string, orders: list<array>, subscriptions: list<array>, customer: ?array}
     */
    public function customerTimeline(string $email, ?CommerceCustomerStore $customers = null): array
    {
        $email = strtolower(trim($email));
        $orders = [];
        $subs = [];
        if ($email === '') {
            return ['email' => '', 'orders' => [], 'subscriptions' => [], 'customer' => null];
        }
        foreach ($this->orders->listAll() as $order) {
            if (strtolower((string) ($order['customer_email'] ?? '')) === $email) {
                $orders[] = $order;
            }
        }
        foreach ($this->subscriptions->listAll() as $sub) {
            if (strtolower((string) ($sub['customer_email'] ?? '')) === $email) {
                $subs[] = $sub;
            }
        }
        $customer = null;
        if ($customers === null && class_exists('CommerceCustomerStore')) {
            $customers = new CommerceCustomerStore();
        }
        if ($customers instanceof CommerceCustomerStore) {
            $customer = $customers->getByEmail($email);
        }
        return [
            'email' => $email,
            'orders' => $orders,
            'subscriptions' => $subs,
            'customer' => $customer,
        ];
    }

    /**
     * @param list<array<string, mixed>> $orders
     */
    public function exportOrdersCsv(array $orders): string
    {
        $out = fopen('php://temp', 'r+');
        if ($out === false) {
            return '';
        }
        fputcsv($out, [
            'order_number', 'id', 'status', 'created_at', 'customer_name', 'customer_email',
            'currency', 'subtotal_cents', 'shipping_cents', 'tax_cents', 'tax_rate', 'tax_country',
            'discount_cents', 'total_cents', 'refunded_cents', 'payment_id', 'provider',
            'shipping_country', 'tags', 'item_titles', 'tracking_numbers',
        ]);
        foreach ($orders as $o) {
            $addr = is_array($o['shipping_address'] ?? null) ? $o['shipping_address'] : [];
            $lines = is_array($o['lines'] ?? null) ? $o['lines'] : [];
            $titles = [];
            $tracking = [];
            $subtotal = 0;
            foreach ($lines as $line) {
                $titles[] = ($line['title'] ?? $line['entry_id'] ?? 'Item')
                    . (isset($line['quantity']) && (int) $line['quantity'] > 1 ? (' x' . (int) $line['quantity']) : '');
                if (!empty($line['tracking_number'])) {
                    $tracking[] = trim(($line['carrier'] ?? '') . ' ' . $line['tracking_number']);
                }
                $subtotal += (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
            }
            $shipping = self::sumOrderMoneySnapshot($o, 'shipping_lines', 'price_cents', 'shipping_cents');
            $tax = self::sumOrderMoneySnapshot($o, 'tax_lines', 'tax_cents', 'tax_cents');
            $discount = self::sumOrderMoneySnapshot($o, 'discount_allocations', 'amount_cents', 'discount_cents');
            fputcsv($out, [
                $o['order_number'] ?? '',
                $o['id'] ?? '',
                $o['status'] ?? '',
                $o['created_at'] ?? '',
                $addr['name'] ?? ($o['customer_name'] ?? ''),
                $o['customer_email'] ?? '',
                $o['currency'] ?? 'eur',
                $subtotal,
                $shipping,
                $tax,
                $o['tax_rate'] ?? '',
                $o['tax_country'] ?? '',
                $discount,
                (int) ($o['total_cents'] ?? 0),
                (int) ($o['refunded_cents'] ?? 0),
                $o['payment_id'] ?? '',
                $o['provider'] ?? '',
                $addr['country'] ?? '',
                implode('|', is_array($o['tags'] ?? null) ? $o['tags'] : []),
                implode('; ', $titles),
                implode('; ', $tracking),
            ]);
        }
        rewind($out);
        $csv = stream_get_contents($out) ?: '';
        fclose($out);
        return $csv;
    }

    public static function trackingUrl(?string $carrier, ?string $trackingNumber): ?string
    {
        $num = trim((string) $trackingNumber);
        if ($num === '') {
            return null;
        }
        $key = strtolower(trim((string) $carrier));
        $template = null;
        if ($key !== '' && isset(self::TRACKING_URLS[$key])) {
            $template = self::TRACKING_URLS[$key];
        } else {
            foreach (self::TRACKING_URLS as $name => $url) {
                if ($key !== '' && str_contains($key, $name)) {
                    $template = $url;
                    break;
                }
            }
        }
        if ($template === null) {
            // Generic fallback search.
            return 'https://www.google.com/search?q=' . rawurlencode(trim($carrier . ' ' . $num));
        }
        return str_replace('{num}', rawurlencode($num), $template);
    }

    /**
     * Enrich order lines with tracking_url, shipped/remaining qty, and fulfillment_status.
     */
    public function enrichOrder(array $order): array
    {
        $lines = is_array($order['lines'] ?? null) ? $order['lines'] : [];
        foreach ($lines as $idx => $line) {
            $type = self::normalizeLineFulfillment($line['fulfillment'] ?? null);
            $lines[$idx]['fulfillment'] = $type;
            $url = self::trackingUrl($line['carrier'] ?? null, $line['tracking_number'] ?? null);
            if ($url) {
                $lines[$idx]['tracking_url'] = $url;
            }
            if ($type === 'ship') {
                $shipped = self::shippedQuantity($order, (string) ($line['line_id'] ?? ''));
                $qty = self::lineQuantity($line);
                $lines[$idx]['quantity_shipped'] = $shipped;
                $lines[$idx]['quantity_remaining'] = max(0, $qty - $shipped);
                if ($shipped <= 0) {
                    $lines[$idx]['fulfillment_status'] = 'unfulfilled';
                } elseif ($shipped >= $qty) {
                    $lines[$idx]['fulfillment_status'] = 'shipped';
                } else {
                    $lines[$idx]['fulfillment_status'] = 'partial';
                }
            } elseif ($type !== 'none') {
                $lines[$idx]['fulfillment_status'] = self::autoLineFulfilled($order, $line) ? 'fulfilled' : 'pending';
            }
        }
        $order['lines'] = $lines;
        $order['fulfillment_status'] = self::deriveOrderFulfillmentStatus($order);
        if (!isset($order['shipments']) || !is_array($order['shipments'])) {
            $order['shipments'] = [];
        }
        foreach ($order['shipments'] as $sidx => $shipment) {
            if (!is_array($shipment)) {
                continue;
            }
            $url = self::trackingUrl($shipment['carrier'] ?? null, $shipment['tracking_number'] ?? null);
            if ($url) {
                $order['shipments'][$sidx]['tracking_url'] = $url;
            }
        }
        if (!isset($order['notes']) || !is_array($order['notes'])) {
            $order['notes'] = [];
        }
        if (!isset($order['tags']) || !is_array($order['tags'])) {
            $order['tags'] = [];
        }
        if (!isset($order['fulfillment_activity']) || !is_array($order['fulfillment_activity'])) {
            $order['fulfillment_activity'] = [];
        }
        $order['has_open_fulfillment_work'] = self::orderHasOpenFulfillmentWork($order);
        $order['requires_fulfillment'] = self::orderRequiresFulfillment($order);
        $order['fulfillment_actors'] = self::orderFulfillmentActors($order);
        return $order;
    }

    /**
     * Packing slip HTML for a shipment or remaining unshipped items.
     *
     * @param array{name?: string, email?: string, address?: string} $brand
     */
    public function buildPackingSlipHtml(array $order, array $brand = [], ?string $shipmentId = null, bool $remainingOnly = false): string
    {
        $order = $this->enrichOrder($order);
        $brandName = trim((string) ($brand['name'] ?? 'Packing slip'));
        $number = htmlspecialchars((string) ($order['order_number'] ?? $order['id'] ?? ''), ENT_QUOTES, 'UTF-8');
        $email = htmlspecialchars((string) ($order['customer_email'] ?? ''), ENT_QUOTES, 'UTF-8');
        $addr = is_array($order['shipping_address'] ?? null) ? $order['shipping_address'] : [];
        $shipBlock = htmlspecialchars(trim(implode(', ', array_filter([
            $addr['name'] ?? null,
            $addr['line1'] ?? null,
            trim(($addr['postal_code'] ?? '') . ' ' . ($addr['city'] ?? '')),
            $addr['country'] ?? null,
        ]))), ENT_QUOTES, 'UTF-8');

        $shipment = null;
        if ($shipmentId !== null && $shipmentId !== '') {
            foreach ($order['shipments'] ?? [] as $s) {
                if (is_array($s) && (string) ($s['id'] ?? '') === $shipmentId) {
                    $shipment = $s;
                    break;
                }
            }
        }

        $rows = '';
        $meta = '';
        if ($shipment !== null) {
            $pkg = max(1, (int) ($shipment['package_count'] ?? 1));
            $meta = '<div class="sub">Shipment ' . htmlspecialchars((string) ($shipment['id'] ?? ''), ENT_QUOTES, 'UTF-8')
                . ' · Packages: ' . $pkg;
            if (!empty($shipment['carrier']) || !empty($shipment['tracking_number'])) {
                $meta .= ' · ' . htmlspecialchars(trim(($shipment['carrier'] ?? '') . ' ' . ($shipment['tracking_number'] ?? '')), ENT_QUOTES, 'UTF-8');
            }
            $meta .= '</div>';
            foreach ($shipment['items'] ?? [] as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $title = htmlspecialchars((string) ($item['title'] ?? $item['line_id'] ?? 'Item'), ENT_QUOTES, 'UTF-8');
                $qty = (int) ($item['quantity'] ?? 0);
                $sku = htmlspecialchars((string) ($item['sku'] ?? ''), ENT_QUOTES, 'UTF-8');
                $rows .= '<tr><td><strong>' . $title . '</strong>'
                    . ($sku !== '' ? '<div class="muted">SKU ' . $sku . '</div>' : '')
                    . '</td><td>' . $qty . '</td></tr>';
            }
        } else {
            $meta = '<div class="sub">' . ($remainingOnly ? 'Remaining items to ship' : 'Ship items')
                . ' · Order fulfillment: ' . htmlspecialchars((string) ($order['fulfillment_status'] ?? ''), ENT_QUOTES, 'UTF-8')
                . '</div>';
            foreach ($order['lines'] ?? [] as $line) {
                if (($line['fulfillment'] ?? '') !== 'ship') {
                    continue;
                }
                $qty = $remainingOnly
                    ? (int) ($line['quantity_remaining'] ?? self::remainingQuantity($order, $line))
                    : self::lineQuantity($line);
                if ($qty <= 0) {
                    continue;
                }
                $title = htmlspecialchars((string) ($line['title'] ?? 'Item'), ENT_QUOTES, 'UTF-8');
                $sku = htmlspecialchars((string) ($line['sku'] ?? ''), ENT_QUOTES, 'UTF-8');
                $rows .= '<tr><td><strong>' . $title . '</strong>'
                    . ($sku !== '' ? '<div class="muted">SKU ' . $sku . '</div>' : '')
                    . '</td><td>' . $qty . '</td></tr>';
            }
        }

        if ($rows === '') {
            $rows = '<tr><td colspan="2">No items for this packing slip.</td></tr>';
        }

        $brandNameEsc = htmlspecialchars($brandName, ENT_QUOTES, 'UTF-8');
        return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Packing slip '
            . $number . '</title><style>
body{margin:0;padding:24px;font:14px/1.45 system-ui,sans-serif;color:#111}
.brand{font-weight:700;font-size:20px;margin:0 0 4px}
.sub{color:#555;font-size:12px;margin:0 0 14px}
h1{font-size:22px;margin:0 0 8px}
table{width:100%;border-collapse:collapse;margin-top:12px}
th,td{padding:8px 6px;border-bottom:1px solid #e5e7eb;text-align:left}
th{font-size:12px;text-transform:uppercase;color:#666}
.muted{color:#666;font-size:12px}
@media print{body{padding:0}}
</style></head><body>
<div class="brand">' . $brandNameEsc . '</div>
<h1>Packing slip ' . $number . '</h1>
' . $meta . '
<div class="sub">Ship to: ' . ($shipBlock !== '' ? $shipBlock : '—') . ' · ' . $email . '</div>
<table><thead><tr><th>Item</th><th>Qty</th></tr></thead><tbody>' . $rows . '</tbody></table>
<script>window.onload=function(){window.focus();setTimeout(function(){window.print()},150)}</script>
</body></html>';
    }

    /**
     * Print-ready branded invoice HTML (browser Print → Save as PDF).
     * Issues a stable invoice number on first print when auto-issue is enabled.
     */
    public function buildInvoiceHtml(array $order, array $brand = []): string
    {
        $order = $this->enrichOrder($order);
        if (!class_exists('CommerceInvoiceService')) {
            require_once __DIR__ . '/CommerceInvoiceService.php';
        }
        $dataDir = dirname($this->orders->getDataDir());
        return (new CommerceInvoiceService($dataDir, $this->orders))->buildInvoiceHtml($order, $brand, true);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private static function moneySnapshotLines(array $order, string $field): array
    {
        $lines = is_array($order[$field] ?? null) ? $order[$field] : [];
        return array_values(array_filter($lines, static fn($line): bool => is_array($line)));
    }

    private static function sumOrderMoneySnapshot(array $order, string $field, string $amountKey, string $fallbackKey): int
    {
        $lines = self::moneySnapshotLines($order, $field);
        if (empty($lines)) {
            return (int) ($order[$fallbackKey] ?? 0);
        }
        $sum = 0;
        foreach ($lines as $line) {
            $sum += (int) ($line[$amountKey] ?? 0);
        }
        return $sum;
    }
}
