<?php
/**
 * Admin draft order / quote editor (P2-M5).
 * Builds quotes from catalog lines without a storefront cart session.
 */

require_once __DIR__ . '/CommerceQuoteStore.php';
require_once __DIR__ . '/CommerceCatalog.php';
require_once __DIR__ . '/DiscountEngine.php';

class CommerceDraftOrderService
{
    private CommerceQuoteStore $quotes;
    private CommerceCatalog $catalog;
    private DiscountEngine $discounts;
    private ?CommerceCheckoutService $checkout;

    public function __construct(
        CommerceQuoteStore $quotes,
        CommerceCatalog $catalog,
        ?DiscountEngine $discounts = null,
        ?CommerceCheckoutService $checkout = null
    ) {
        $this->quotes = $quotes;
        $this->catalog = $catalog;
        $this->discounts = $discounts ?? new DiscountEngine();
        $this->checkout = $checkout;
    }

    /**
     * Search catalog for the draft line picker.
     *
     * @return list<array<string, mixed>>
     */
    public function searchCatalog(string $query, int $limit = 25): array
    {
        $q = strtolower(trim($query));
        $items = $this->catalog->listItems();
        if ($q === '') {
            return array_slice(array_values($items), 0, max(1, $limit));
        }
        $matched = [];
        foreach ($items as $item) {
            $hay = strtolower(implode(' ', array_filter([
                (string) ($item['entry_title'] ?? ''),
                (string) ($item['entry_slug'] ?? ''),
                (string) ($item['entry_id'] ?? ''),
                (string) ($item['sku'] ?? ''),
                (string) ($item['collection_slug'] ?? ''),
                (string) (($item['commerce']['sku'] ?? '') ?: ''),
            ])));
            if (strpos($hay, $q) !== false) {
                $matched[] = $this->catalogPickerRow($item);
            }
            if (count($matched) >= $limit) {
                break;
            }
        }
        return $matched;
    }

    /**
     * Preview totals (no persist).
     *
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function preview(array $payload): array
    {
        $built = $this->buildFromPayload($payload);
        if (!($built['ok'] ?? false)) {
            return $built;
        }
        return [
            'ok' => true,
            'preview' => $this->snapshotFromBuilt($built, $payload),
        ];
    }

    /**
     * Create a draft quote from scratch (no cart session).
     *
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function create(array $payload): array
    {
        $built = $this->buildFromPayload($payload);
        if (!($built['ok'] ?? false)) {
            return $built;
        }
        $snap = $this->snapshotFromBuilt($built, $payload);
        $quote = $this->quotes->create(array_merge($snap, [
            'status' => 'quote',
            'draft_order' => true,
            'created_by' => $payload['created_by'] ?? 'admin',
        ]));
        return [
            'ok' => true,
            'quote' => $quote,
            'accept_url' => $this->quotes->acceptUrl((string) ($quote['token'] ?? '')),
        ];
    }

    /**
     * Patch an open draft/quote (lines, email, note, address, vat_id).
     *
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function update(string $id, array $payload): array
    {
        $existing = $this->quotes->get($id);
        if (!$existing) {
            return ['ok' => false, 'error' => 'Draft order not found'];
        }
        $status = (string) ($existing['status'] ?? '');
        if (in_array($status, ['paid', 'canceled', 'expired'], true)) {
            return ['ok' => false, 'error' => 'Draft order is not editable (' . $status . ')'];
        }

        $merged = [
            'customer_email' => array_key_exists('customer_email', $payload)
                ? trim((string) $payload['customer_email'])
                : ($existing['customer_email'] ?? ''),
            'note' => array_key_exists('note', $payload)
                ? trim((string) $payload['note'])
                : ($existing['note'] ?? ''),
            'shipping_address' => array_key_exists('shipping_address', $payload)
                ? $payload['shipping_address']
                : ($existing['shipping_address'] ?? null),
            'billing_address' => array_key_exists('billing_address', $payload)
                ? $payload['billing_address']
                : ($existing['billing_address'] ?? null),
            'vat_id' => array_key_exists('vat_id', $payload)
                ? $payload['vat_id']
                : ($payload['tax_id'] ?? ($existing['vat_id'] ?? ($existing['tax_id'] ?? null))),
            'lines' => array_key_exists('lines', $payload)
                ? $payload['lines']
                : $this->lineSpecsFromStoredLines($existing['lines'] ?? []),
            'shipping_rate_id' => $payload['shipping_rate_id']
                ?? ($payload['selected_shipping_rate_id'] ?? null),
            'coupon' => $payload['coupon'] ?? null,
        ];

        $built = $this->buildFromPayload($merged);
        if (!($built['ok'] ?? false)) {
            return $built;
        }
        $snap = $this->snapshotFromBuilt($built, $merged);
        $quote = $this->quotes->update($id, array_merge($snap, [
            'draft_order' => true,
        ]));
        if (!$quote) {
            return ['ok' => false, 'error' => 'Failed to update draft order'];
        }
        return [
            'ok' => true,
            'quote' => $quote,
            'accept_url' => $this->quotes->acceptUrl((string) ($quote['token'] ?? '')),
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    public function get(string $id): ?array
    {
        return $this->quotes->get($id);
    }

    /**
     * Merchant-assisted: accept quote and start payment checkout (no storefront cart).
     *
     * @param array<string, mixed> $opts
     * @return array<string, mixed>
     */
    public function checkout(string $id, array $opts = []): array
    {
        if ($this->checkout === null) {
            return ['ok' => false, 'error' => 'Checkout service unavailable'];
        }
        $quote = $this->quotes->get($id);
        if (!$quote) {
            return ['ok' => false, 'error' => 'Draft order not found'];
        }
        if (in_array($quote['status'] ?? '', ['paid', 'canceled', 'expired'], true)) {
            return ['ok' => false, 'error' => 'Draft order cannot be checked out'];
        }
        if (empty($quote['lines'])) {
            return ['ok' => false, 'error' => 'Draft order has no lines'];
        }
        $email = trim((string) ($opts['email'] ?? ($opts['customer_email'] ?? ($quote['customer_email'] ?? ''))));
        $token = (string) ($quote['token'] ?? '');
        if ($token === '') {
            return ['ok' => false, 'error' => 'Draft order has no accept token'];
        }
        // Ensure accepted / pending_payment before creating a payment.
        if (($quote['status'] ?? '') === 'quote') {
            $accepted = $this->quotes->accept($token);
            if (!($accepted['ok'] ?? false)) {
                return ['ok' => false, 'error' => $accepted['error'] ?? 'Could not accept draft'];
            }
        }
        return $this->checkout->checkoutQuote(
            $token,
            $email,
            (string) ($opts['return_url'] ?? ''),
            (string) ($opts['cancel_url'] ?? '')
        );
    }

    /**
     * Build lines + shipping/tax from admin payload (no session cart).
     *
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function buildFromPayload(array $payload): array
    {
        $lineSpecs = is_array($payload['lines'] ?? null) ? $payload['lines'] : [];
        $cartItems = [];
        $priceOverrides = []; // keyed by resolved cart index
        $errors = [];

        foreach ($lineSpecs as $idx => $spec) {
            if (!is_array($spec)) {
                continue;
            }
            // Allow removing a line by qty 0.
            if (array_key_exists('quantity', $spec) && (int) $spec['quantity'] <= 0) {
                continue;
            }
            $resolved = $this->resolveLineSpec($spec);
            if (!($resolved['ok'] ?? false)) {
                $errors[] = $resolved['error'] ?? ('Unknown line #' . $idx);
                continue;
            }
            $item = $resolved['item'];
            $cartItems[] = $item;
            if (isset($spec['unit_price_cents']) && $spec['unit_price_cents'] !== '' && $spec['unit_price_cents'] !== null) {
                $priceOverrides[count($cartItems) - 1] = max(0, (int) $spec['unit_price_cents']);
            } elseif (isset($spec['custom_price_cents']) && $spec['custom_price_cents'] !== '' && $spec['custom_price_cents'] !== null) {
                $priceOverrides[count($cartItems) - 1] = max(0, (int) $spec['custom_price_cents']);
            } elseif (isset($spec['amount_cents']) && ($spec['pricing_mode'] ?? '') !== 'variable'
                && $spec['amount_cents'] !== '' && $spec['amount_cents'] !== null
                && !empty($spec['custom_price'])) {
                $priceOverrides[count($cartItems) - 1] = max(0, (int) $spec['amount_cents']);
            }
        }

        if (!empty($errors) && empty($cartItems) && !empty($lineSpecs)) {
            return ['ok' => false, 'error' => $errors[0], 'warnings' => $errors];
        }

        $coupon = isset($payload['coupon']) ? trim((string) $payload['coupon']) : null;
        if ($coupon === '') {
            $coupon = null;
        }

        if (empty($cartItems)) {
            $currency = function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur';
            return [
                'ok' => true,
                'lines' => [],
                'subtotal_cents' => 0,
                'shipping_cents' => 0,
                'shipping_lines' => [],
                'tax_cents' => 0,
                'tax_rate' => 0.0,
                'tax_country' => '',
                'tax_lines' => [],
                'discount_cents' => 0,
                'discount_allocations' => [],
                'total_cents' => 0,
                'currency' => $currency,
                'warnings' => $errors,
            ];
        }

        $built = $this->catalog->buildCartLines($cartItems, $this->discounts, $coupon, null);
        if (($built['ok'] ?? true) === false && empty($built['lines'])) {
            return [
                'ok' => false,
                'error' => $built['error'] ?? 'Could not build draft lines',
                'warnings' => $built['warnings'] ?? $errors,
            ];
        }

        $lines = $built['lines'] ?? [];
        foreach ($priceOverrides as $i => $unit) {
            if (!isset($lines[$i])) {
                continue;
            }
            $qty = max(1, (int) ($lines[$i]['quantity'] ?? 1));
            $lineTotal = $unit * $qty;
            $lines[$i]['unit_price_cents'] = $unit;
            $lines[$i]['effective_unit_cents'] = $unit;
            $lines[$i]['base_unit_cents'] = $unit;
            $lines[$i]['amount_cents'] = $unit;
            $lines[$i]['base_amount_cents'] = $lineTotal;
            $lines[$i]['line_total_cents'] = $lineTotal;
            $lines[$i]['effective_amount_cents'] = $lineTotal;
            $lines[$i]['discount_amount_cents'] = 0;
            $lines[$i]['custom_price'] = true;
        }

        $shippingAddress = is_array($payload['shipping_address'] ?? null) ? $payload['shipping_address'] : null;
        $billingAddress = is_array($payload['billing_address'] ?? null) ? $payload['billing_address'] : null;
        $vatId = $this->catalog->normalizeVatId(
            $payload['vat_id'] ?? ($payload['tax_id'] ?? null)
        );

        $shipContext = [
            'selected_rate_id' => $payload['shipping_rate_id']
                ?? ($payload['selected_shipping_rate_id'] ?? null),
        ];
        $shippingSnap = $this->catalog->calculateShippingSnapshot($lines, $shippingAddress, $shipContext);
        if (($shippingSnap['ok'] ?? true) === false && !empty($shippingSnap['error'])) {
            // Soft-fail: keep preview usable with 0 shipping when address/weight incomplete.
            $shippingSnap = [
                'shipping_cents' => 0,
                'shipping_lines' => [],
                'ok' => false,
                'error' => $shippingSnap['error'],
            ];
        }

        $tax = $this->catalog->calculateTax($lines, $shippingAddress, [
            'currency' => $built['currency'] ?? null,
            'vat_id' => $vatId !== '' ? $vatId : null,
            'billing_address' => $billingAddress,
        ]);

        $subtotal = 0;
        foreach ($lines as $line) {
            $subtotal += (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
        }
        $shippingCents = (int) ($shippingSnap['shipping_cents'] ?? 0);
        $taxCents = (int) ($tax['tax_cents'] ?? 0);
        $taxAddCents = class_exists('CommerceSchema')
            ? CommerceSchema::taxAddCentsFromResult($tax)
            : (int) ($tax['tax_add_cents'] ?? $taxCents);

        return [
            'ok' => true,
            'lines' => $lines,
            'subtotal_cents' => $subtotal,
            'shipping_cents' => $shippingCents,
            'shipping_lines' => $shippingSnap['shipping_lines'] ?? [],
            'shipping_rates' => $shippingSnap['rates'] ?? [],
            'shipping_error' => $shippingSnap['error'] ?? null,
            'tax_cents' => $taxCents,
            'tax_add_cents' => $taxAddCents,
            'tax_rate' => $tax['rate'] ?? 0.0,
            'tax_country' => $tax['country'] ?? '',
            'tax_lines' => $tax['tax_lines'] ?? [],
            'tax_included' => !empty($tax['tax_included']) || !empty($tax['prices_include_tax']),
            'prices_include_tax' => !empty($tax['prices_include_tax']) || !empty($tax['tax_included']),
            'discount_cents' => (int) ($built['discount_cents'] ?? 0),
            'discount_allocations' => $built['discount_allocations'] ?? [],
            'total_cents' => $subtotal + $shippingCents + $taxAddCents,
            'currency' => $built['currency'] ?? 'eur',
            'vat_id' => $vatId !== '' ? $vatId : null,
            'warnings' => array_values(array_merge($errors, $built['warnings'] ?? [])),
        ];
    }

    /**
     * @param array<string, mixed> $built
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function snapshotFromBuilt(array $built, array $payload): array
    {
        $vatId = $built['vat_id'] ?? $this->catalog->normalizeVatId($payload['vat_id'] ?? ($payload['tax_id'] ?? null));
        $snap = [
            'customer_email' => trim((string) ($payload['customer_email'] ?? '')),
            'note' => trim((string) ($payload['note'] ?? '')),
            'lines' => $built['lines'] ?? [],
            'subtotal_cents' => (int) ($built['subtotal_cents'] ?? 0),
            'total_cents' => (int) ($built['total_cents'] ?? 0),
            'shipping_cents' => (int) ($built['shipping_cents'] ?? 0),
            'shipping_lines' => $built['shipping_lines'] ?? [],
            'tax_cents' => (int) ($built['tax_cents'] ?? 0),
            'tax_add_cents' => (int) ($built['tax_add_cents'] ?? (
                class_exists('CommerceSchema')
                    ? CommerceSchema::taxAddCentsFromResult($built)
                    : ($built['tax_cents'] ?? 0)
            )),
            'tax_rate' => $built['tax_rate'] ?? 0.0,
            'tax_country' => $built['tax_country'] ?? '',
            'tax_lines' => $built['tax_lines'] ?? [],
            'tax_included' => !empty($built['tax_included']) || !empty($built['prices_include_tax']),
            'prices_include_tax' => !empty($built['prices_include_tax']) || !empty($built['tax_included']),
            'discount_cents' => (int) ($built['discount_cents'] ?? 0),
            'discount_allocations' => $built['discount_allocations'] ?? [],
            'gift_card_applications' => [],
            'currency' => $built['currency'] ?? 'eur',
            'shipping_address' => is_array($payload['shipping_address'] ?? null) ? $payload['shipping_address'] : null,
            'billing_address' => is_array($payload['billing_address'] ?? null) ? $payload['billing_address'] : null,
        ];
        if (is_string($vatId) && $vatId !== '') {
            $snap['vat_id'] = $vatId;
            $snap['tax_id'] = $vatId;
        } else {
            $snap['vat_id'] = null;
            $snap['tax_id'] = null;
        }
        return $snap;
    }

    /**
     * @param array<string, mixed> $spec
     * @return array{ok: bool, item?: array<string, mixed>, error?: string}
     */
    private function resolveLineSpec(array $spec): array
    {
        $qty = max(1, (int) ($spec['quantity'] ?? 1));
        $collection = trim((string) ($spec['collection'] ?? ($spec['collection_slug'] ?? '')));
        $entryId = trim((string) ($spec['entry_id'] ?? ''));
        $sku = trim((string) ($spec['sku'] ?? ''));
        $optionId = $spec['purchase_option_id'] ?? null;

        if ($collection === '' || $entryId === '') {
            $found = $this->findCatalogItem($sku, $collection, $entryId, (string) ($spec['entry_slug'] ?? ''));
            if ($found === null) {
                return ['ok' => false, 'error' => 'Catalog item not found'
                    . ($sku !== '' ? ' for SKU ' . $sku : '')];
            }
            $collection = (string) ($found['collection_slug'] ?? $collection);
            $entryId = (string) ($found['entry_id'] ?? $entryId);
        } elseif (!$this->catalog->getItem($collection, $entryId)) {
            $found = $this->findCatalogItem($sku, $collection, $entryId, '');
            if ($found === null) {
                return ['ok' => false, 'error' => 'Catalog item not found: ' . $collection . ':' . $entryId];
            }
            $collection = (string) ($found['collection_slug'] ?? $collection);
            $entryId = (string) ($found['entry_id'] ?? $entryId);
        }

        $item = [
            'collection' => $collection,
            'entry_id' => $entryId,
            'quantity' => $qty,
            'purchase_option_id' => $optionId,
        ];
        // Variable pricing still uses amount_cents through buildCartLines.
        if (isset($spec['amount_cents']) && empty($spec['custom_price']) && !isset($spec['unit_price_cents'])) {
            $item['amount_cents'] = (int) $spec['amount_cents'];
        }
        return ['ok' => true, 'item' => $item];
    }

    /**
     * @return array<string, mixed>|null
     */
    private function findCatalogItem(string $sku, string $collection, string $entryId, string $entrySlug): ?array
    {
        $skuNorm = strtolower(trim($sku));
        $entrySlugNorm = strtolower(trim($entrySlug));
        foreach ($this->catalog->listItems() as $item) {
            $itemSku = strtolower(trim((string) ($item['sku'] ?? (($item['commerce']['sku'] ?? '') ?: ''))));
            $itemEntry = (string) ($item['entry_id'] ?? '');
            $itemColl = (string) ($item['collection_slug'] ?? '');
            $itemSlug = strtolower(trim((string) ($item['entry_slug'] ?? '')));
            if ($skuNorm !== '' && $itemSku === $skuNorm) {
                return $item;
            }
            if ($collection !== '' && $entryId !== '' && $itemColl === $collection && $itemEntry === $entryId) {
                return $item;
            }
            if ($entrySlugNorm !== '' && $itemSlug === $entrySlugNorm
                && ($collection === '' || $itemColl === $collection)) {
                return $item;
            }
        }
        return null;
    }

    /**
     * @param list<array<string, mixed>> $lines
     * @return list<array<string, mixed>>
     */
    private function lineSpecsFromStoredLines(array $lines): array
    {
        $specs = [];
        foreach ($lines as $line) {
            if (!is_array($line)) {
                continue;
            }
            $spec = [
                'collection' => $line['collection_slug'] ?? ($line['collection'] ?? ''),
                'entry_id' => $line['entry_id'] ?? '',
                'sku' => $line['sku'] ?? '',
                'purchase_option_id' => $line['purchase_option_id'] ?? null,
                'quantity' => max(1, (int) ($line['quantity'] ?? 1)),
            ];
            if (!empty($line['custom_price']) || isset($line['unit_price_cents'])) {
                $spec['unit_price_cents'] = (int) ($line['unit_price_cents'] ?? $line['effective_unit_cents'] ?? 0);
                $spec['custom_price'] = true;
            }
            $specs[] = $spec;
        }
        return $specs;
    }

    /**
     * @param array<string, mixed> $item
     * @return array<string, mixed>
     */
    private function catalogPickerRow(array $item): array
    {
        $commerce = is_array($item['commerce'] ?? null) ? $item['commerce'] : [];
        $options = is_array($commerce['purchase_options'] ?? null) ? $commerce['purchase_options'] : [];
        $first = $options[0] ?? null;
        $price = is_array($first) ? (int) ($first['price_cents'] ?? 0) : 0;
        return [
            'collection_slug' => $item['collection_slug'] ?? '',
            'entry_id' => $item['entry_id'] ?? '',
            'entry_slug' => $item['entry_slug'] ?? '',
            'entry_title' => $item['entry_title'] ?? ($item['title'] ?? ''),
            'sku' => $item['sku'] ?? ($commerce['sku'] ?? ''),
            'price_cents' => $price,
            'currency' => is_array($first) ? ($first['currency'] ?? 'eur') : 'eur',
            'purchase_option_id' => is_array($first) ? ($first['id'] ?? 'default') : 'default',
            'fulfillment' => $commerce['fulfillment'] ?? ($item['fulfillment'] ?? 'ship'),
        ];
    }
}
