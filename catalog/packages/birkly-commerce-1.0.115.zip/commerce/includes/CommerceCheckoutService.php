<?php
/**
 * Checkout flow — creates pending order and charges via commerce_shelf (v2).
 */

class CommerceCheckoutService
{
    private CommerceOrderStore $orders;
    private CommerceCatalog $catalog;
    private CommerceCartSession $cart;
    private CatalogIndexer $indexer;
    private DiscountEngine $discounts;
    private PurchaseMappingService $mappings;
    private PostPurchaseRouter $router;
    private ?CommerceSubscriptionService $subscriptionService = null;
    private ?GiftCardStore $giftCards = null;
    private ?CommerceCustomerStore $customers = null;
    private ?CommerceQuoteStore $quotes = null;
    private ?WarehouseStockStore $warehouse = null;
    private ?StockReservationStore $reservations = null;

    public function __construct(
        ?CommerceOrderStore $orders = null,
        ?CommerceCatalog $catalog = null,
        ?CommerceCartSession $cart = null,
        ?CatalogIndexer $indexer = null,
        ?DiscountEngine $discounts = null,
        ?PurchaseMappingService $mappings = null,
        ?PostPurchaseRouter $router = null,
        ?CommerceSubscriptionService $subscriptionService = null,
        ?GiftCardStore $giftCards = null,
        ?CommerceQuoteStore $quotes = null,
        ?WarehouseStockStore $warehouse = null,
        ?StockReservationStore $reservations = null,
        ?CommerceCustomerStore $customers = null
    ) {
        $this->orders = $orders ?? new CommerceOrderStore();
        $this->indexer = $indexer ?? new CatalogIndexer();
        $this->catalog = $catalog ?? new CommerceCatalog($this->indexer);
        $this->cart = $cart ?? new CommerceCartSession();
        $this->discounts = $discounts ?? new DiscountEngine();
        $this->mappings = $mappings ?? new PurchaseMappingService();
        $this->router = $router ?? new PostPurchaseRouter();
        $this->subscriptionService = $subscriptionService;
        $this->giftCards = $giftCards;
        $this->quotes = $quotes;
        $this->warehouse = $warehouse;
        $this->reservations = $reservations;
        $this->customers = $customers;
    }

    private function customerStore(): CommerceCustomerStore
    {
        if ($this->customers === null) {
            if (!class_exists('CommerceCustomerStore')) {
                require_once __DIR__ . '/CommerceCustomerStore.php';
            }
            $this->customers = new CommerceCustomerStore(dirname($this->orders->getDataDir()) . '/customers');
        }
        return $this->customers;
    }

    private function warehouseStore(): WarehouseStockStore
    {
        if ($this->warehouse === null) {
            if (!class_exists('WarehouseStockStore')) {
                require_once __DIR__ . '/WarehouseStockStore.php';
            }
            $this->warehouse = new WarehouseStockStore(dirname($this->orders->getDataDir()));
        }
        return $this->warehouse;
    }

    /**
     * Lazily build the subscription service, colocating its store next to the
     * order store so custom (test) data directories are respected.
     */
    private function subscriptions(): CommerceSubscriptionService
    {
        if ($this->subscriptionService === null) {
            if (!class_exists('CommerceSubscriptionStore')) {
                require_once __DIR__ . '/CommerceSubscriptionStore.php';
            }
            if (!class_exists('CommerceSubscriptionService')) {
                require_once __DIR__ . '/CommerceSubscriptionService.php';
            }
            $subDir = dirname($this->orders->getDataDir()) . '/subscriptions';
            $this->subscriptionService = new CommerceSubscriptionService(
                new CommerceSubscriptionStore($subDir),
                $this->getShelf()
            );
        }
        return $this->subscriptionService;
    }


    private function giftCardStore(): GiftCardStore {
        if ($this->giftCards === null) { if (!class_exists('GiftCardStore')) require_once __DIR__ . '/GiftCardStore.php';
            $this->giftCards = new GiftCardStore(dirname($this->orders->getDataDir()) . '/gift_cards'); }
        return $this->giftCards;
    }
    private function quoteStore(): CommerceQuoteStore {
        if ($this->quotes === null) { if (!class_exists('CommerceQuoteStore')) require_once __DIR__ . '/CommerceQuoteStore.php';
            $this->quotes = new CommerceQuoteStore(dirname($this->orders->getDataDir()) . '/quotes'); }
        return $this->quotes;
    }

    private function stockReservations(): StockReservationStore
    {
        if ($this->reservations === null) {
            if (!class_exists('StockReservationStore')) {
                require_once __DIR__ . '/StockReservationStore.php';
            }
            $this->reservations = new StockReservationStore(
                dirname($this->orders->getDataDir()),
                $this->indexer,
                $this->warehouseStore()
            );
        }
        return $this->reservations;
    }

    public function getShelf(): ?PaymentShelf
    {
        if (function_exists('get_plugin_service')) {
            $shelf = get_plugin_service('commerce_shelf', false);
            if ($shelf instanceof PaymentShelf) {
                return $shelf;
            }
            $shelf = get_plugin_service('payment_shelf', false);
            if ($shelf instanceof PaymentShelf) {
                return $shelf;
            }
        }
        if (function_exists('commerce_bootstrap')) {
            return commerce_bootstrap();
        }
        return null;
    }

    public function createPendingOrder(string $customerEmail = '', array $checkoutData = []): array
    {
        $coupon = $this->cart->getCouponCode();
        $affiliate = $this->cart->getAffiliateId();
        $draft = $this->resolveCheckoutDraft($checkoutData);
        $customerEmail = trim($customerEmail) !== '' ? trim($customerEmail) : (string) ($draft['email'] ?? '');
        $shippingAddress = $checkoutData['shipping_address'] ?? ($draft['shipping_address'] ?? null);
        $attendeeName = $checkoutData['attendee_name'] ?? ($draft['attendee_name'] ?? null);
        $customerName = trim((string) ($checkoutData['customer_name'] ?? ($draft['customer_name'] ?? '')));
        $entrySyncMeta = [];
        if (is_array($draft['metadata'] ?? null)) {
            $entrySyncMeta = $draft['metadata'];
        }
        if (is_array($checkoutData['metadata'] ?? null)) {
            $entrySyncMeta = array_merge($entrySyncMeta, $checkoutData['metadata']);
        }
        if (is_array($checkoutData['entry_sync_meta'] ?? null)) {
            $entrySyncMeta = array_merge($entrySyncMeta, $checkoutData['entry_sync_meta']);
        }
        if (is_array($checkoutData['donor_meta'] ?? null)) {
            $entrySyncMeta = array_merge($entrySyncMeta, $checkoutData['donor_meta']);
        }

        $groupKey = trim((string) ($checkoutData['group_key'] ?? ''));
        // Peek groups without tenders so we know whether this call is for a recurring group.
        $preview = $this->catalog->buildCartLines($this->cart->getItems(), $this->discounts, null, $affiliate);
        if (($preview['ok'] ?? true) === false) {
            return ['ok' => false, 'error' => $preview['error'] ?? 'Cart error'];
        }
        if (empty($preview['lines'])) {
            return ['ok' => false, 'error' => 'Cart is empty'];
        }
        $groups = $preview['groups'] ?? $this->catalog->groupCartLines($preview['lines']);
        $splitCheckout = count($groups) > 1;
        $targetBilling = '';
        if ($groupKey !== '') {
            $peek = $this->findCheckoutGroup($groups, $groupKey);
            if ($peek === null) {
                return ['ok' => false, 'error' => 'Checkout group not found in cart'];
            }
            $targetBilling = (string) ($peek['billing'] ?? '');
        } elseif (!$splitCheckout && !empty($groups[0]['billing'])) {
            $targetBilling = (string) $groups[0]['billing'];
        }
        // Coupons settle with one-time groups only — never discount subscription groups.
        if ($targetBilling === 'recurring') {
            $coupon = null;
        }

        $built = $this->catalog->buildCartLines($this->cart->getItems(), $this->discounts, $coupon, $affiliate);
        if (($built['ok'] ?? true) === false) {
            return ['ok' => false, 'error' => $built['error'] ?? 'Cart error'];
        }
        if (empty($built['lines'])) {
            return ['ok' => false, 'error' => 'Cart is empty'];
        }

        $groups = $built['groups'] ?? $this->catalog->groupCartLines($built['lines']);
        $splitCheckout = count($groups) > 1;
        if ($groupKey !== '') {
            $group = $this->findCheckoutGroup($groups, $groupKey);
            if ($group === null) {
                return ['ok' => false, 'error' => 'Checkout group not found in cart'];
            }
            $built = $this->scopeBuiltToGroup($built, $group);
        } elseif ($splitCheckout) {
            // Mixed carts must checkout one billing group at a time.
            return ['ok' => false, 'error' => 'This cart requires split checkout', 'needs_split' => true, 'groups' => $groups];
        }

        $needsShipping = false;
        $needsAttendee = false;
        foreach ($built['lines'] as $line) {
            if (($line['fulfillment'] ?? '') === 'ship') {
                $needsShipping = true;
            }
            if (($line['fulfillment'] ?? '') === 'register') {
                $needsAttendee = true;
            }
            if (!empty($line['is_bundle'])) {
                foreach ($line['components'] ?? [] as $comp) {
                    if (($comp['fulfillment'] ?? '') === 'ship') {
                        $needsShipping = true;
                    }
                    if (($comp['fulfillment'] ?? '') === 'register') {
                        $needsAttendee = true;
                    }
                }
            }
        }

        if ($needsShipping && empty($shippingAddress)) {
            return ['ok' => false, 'error' => 'Shipping address required'];
        }
        if ($needsAttendee && ($attendeeName === null || trim((string) $attendeeName) === '')) {
            return ['ok' => false, 'error' => 'Attendee name required'];
        }

        // Digital / register-only groups never charge shipping (even if a prior
        // full-cart estimate suggested otherwise). Address may still be used for tax.
        if (!$needsShipping) {
            $built['shipping_cents'] = 0;
            $built['shipping_lines'] = [];
            $goodsOnly = 0;
            foreach ($built['lines'] as $line) {
                $goodsOnly += (int) ($line['line_total_cents'] ?? 0);
            }
            $built['total_cents'] = $goodsOnly;
        }

        if ($needsShipping && is_array($shippingAddress)) {
            $oldShipping = (int) ($built['shipping_cents'] ?? 0);
            $shippingContext = [
                'selected_rate_id' => $checkoutData['shipping_rate_id']
                    ?? ($checkoutData['selected_shipping_rate_id'] ?? null),
                'currency' => $built['currency'] ?? null,
            ];
            $shippingSnapshot = $this->catalog->calculateShippingSnapshot(
                $built['lines'],
                $shippingAddress,
                $shippingContext
            );
            if (($shippingSnapshot['ok'] ?? true) === false && !empty($shippingSnapshot['error'])) {
                return ['ok' => false, 'error' => (string) $shippingSnapshot['error'], 'shipping' => $shippingSnapshot];
            }
            $newShipping = (int) ($shippingSnapshot['shipping_cents'] ?? 0);
            $built['shipping_rates'] = $shippingSnapshot['rates'] ?? [];
            if (!empty($shippingSnapshot['fallback'])) {
                $built['shipping_fallback'] = true;
            }

            // Re-run promotions with address-specific shipping so free_shipping can compete.
            if (method_exists($this->discounts, 'evaluateCart')) {
                $linesForEval = [];
                foreach ($built['lines'] ?? [] as $line) {
                    $baseAmount = (int) ($line['base_amount_cents'] ?? 0);
                    if ($baseAmount <= 0) {
                        $qty = max(1, (int) ($line['quantity'] ?? 1));
                        $baseAmount = (int) ($line['base_unit_cents'] ?? $line['amount_cents'] ?? 0) * $qty;
                    }
                    $linesForEval[] = array_merge($line, ['base_amount_cents' => $baseAmount]);
                }
                $eval = $this->discounts->evaluateCart($linesForEval, $coupon, $affiliate, $newShipping);
                $goodsTotal = 0;
                $discountTotal = 0;
                foreach ($built['lines'] as $idx => &$line) {
                    $baseAmount = (int) ($linesForEval[$idx]['base_amount_cents'] ?? 0);
                    $qty = max(1, (int) ($line['quantity'] ?? 1));
                    $lineDiscount = min($baseAmount, (int) ($eval['line_discounts'][$idx] ?? 0));
                    $lineTotal = max(0, $baseAmount - $lineDiscount);
                    $effectiveUnit = (int) floor($lineTotal / $qty);
                    $line['base_amount_cents'] = $baseAmount;
                    $line['discount_amount_cents'] = $lineDiscount;
                    $line['effective_amount_cents'] = $lineTotal;
                    $line['line_total_cents'] = $lineTotal;
                    $line['effective_unit_cents'] = $effectiveUnit;
                    $line['unit_price_cents'] = $effectiveUnit;
                    $goodsTotal += $lineTotal;
                    $discountTotal += $lineDiscount;
                }
                unset($line);
                $built['discount_cents'] = $discountTotal;
                $built['discount_allocations'] = $eval['allocations'] ?? [];
                $built['free_shipping'] = !empty($eval['free_shipping']);
                $built['applied_rule_ids'] = $eval['applied_rule_ids'] ?? [];
                if (!empty($eval['free_shipping'])) {
                    $newShipping = 0;
                    $shippingSnapshot = [
                        'shipping_cents' => 0,
                        'shipping_lines' => [[
                            'id' => 'sl_free',
                            'title' => 'Free shipping',
                            'code' => 'free_shipping',
                            'price_cents' => 0,
                        ]],
                    ];
                } else {
                    // Re-check cart-amount threshold against post-discount goods totals.
                    $shippingSnapshot = $this->catalog->applyFreeShippingThreshold($shippingSnapshot, $built['lines']);
                    $newShipping = (int) ($shippingSnapshot['shipping_cents'] ?? 0);
                    if (!empty($shippingSnapshot['free_shipping_unlocked'])) {
                        $built['free_shipping'] = true;
                    }
                }
                $built['total_cents'] = $goodsTotal + $newShipping;
            } else {
                $shippingSnapshot = $this->catalog->applyFreeShippingThreshold($shippingSnapshot, $built['lines']);
                $newShipping = (int) ($shippingSnapshot['shipping_cents'] ?? 0);
                if (!empty($shippingSnapshot['free_shipping_unlocked'])) {
                    $built['free_shipping'] = true;
                }
                $built['total_cents'] = (int) $built['total_cents'] - $oldShipping + $newShipping;
            }

            $built['shipping_cents'] = $newShipping;
            $built['shipping_lines'] = $shippingSnapshot['shipping_lines'] ?? [];
            $built['free_shipping_min_cents'] = (int) ($shippingSnapshot['free_shipping_min_cents'] ?? 0);
            $built['free_shipping_remaining_cents'] = (int) ($shippingSnapshot['free_shipping_remaining_cents'] ?? 0);
            $built['free_shipping_unlocked'] = !empty($shippingSnapshot['free_shipping_unlocked']) || !empty($built['free_shipping']);
        }

        $vatSource = $checkoutData;
        if (($vatSource['vat_id'] ?? $vatSource['tax_id'] ?? null) === null && !empty($draft['vat_id'])) {
            $vatSource['vat_id'] = $draft['vat_id'];
        }
        $vatId = $this->resolveVatId($vatSource, is_array($shippingAddress) ? $shippingAddress : null);
        $billingAddress = $checkoutData['billing_address'] ?? ($draft['billing_address'] ?? null);
        $taxContext = [
            'currency' => $built['currency'] ?? null,
            // B2B VAT (P2-M4) — vat_id / tax_id + optional billing country for reverse charge.
            'vat_id' => $vatId !== '' ? $vatId : null,
            'tax_id' => $vatId !== '' ? $vatId : null,
            'billing_address' => is_array($billingAddress) ? $billingAddress : null,
        ];
        $tax = $this->catalog->calculateTax(
            $built['lines'],
            is_array($shippingAddress) ? $shippingAddress : null,
            $taxContext
        );
        $built['tax_lines'] = $tax['tax_lines'] ?? [];
        $built['tax_cents'] = $this->sumMoneySnapshotLines($built['tax_lines'], 'tax_cents');
        $built['tax_add_cents'] = CommerceSchema::taxAddCentsFromResult($tax);
        $built['tax_rate'] = $tax['rate'];
        $built['tax_country'] = $tax['country'];
        $built['tax_included'] = !empty($tax['tax_included']) || !empty($tax['prices_include_tax']);
        $built['prices_include_tax'] = !empty($tax['prices_include_tax']) || !empty($tax['tax_included']);
        // Inclusive VAT is already in line totals — only add exclusive (or reverse-charge strip).
        $built['total_cents'] += (int) $built['tax_add_cents'];
        $built['discount_allocations'] = $built['discount_allocations']
            ?? $this->catalog->buildDiscountAllocations($built['lines'], $coupon, $affiliate);
        if (!is_array($built['shipping_lines'] ?? null)) {
            $built['shipping_lines'] = $this->wrapShippingScalar((int) ($built['shipping_cents'] ?? 0));
        }
        if (empty($built['shipping_lines']) && (int) ($built['shipping_cents'] ?? 0) > 0) {
            $built['shipping_lines'] = $this->wrapShippingScalar((int) $built['shipping_cents']);
        }
        if (!is_array($built['discount_allocations'] ?? null)) {
            $built['discount_allocations'] = [];
        }
        if (empty($built['discount_allocations']) && (int) ($built['discount_cents'] ?? 0) > 0) {
            $built['discount_allocations'] = $this->wrapDiscountScalar([
                'discount_cents' => (int) $built['discount_cents'],
                'coupon_code' => $coupon,
            ]);
        }
        $built['shipping_cents'] = $this->sumMoneySnapshotLines($built['shipping_lines'], 'price_cents');
        $built['discount_cents'] = $this->sumMoneySnapshotLines($built['discount_allocations'], 'amount_cents');

        // Gift cards/coupons settle with one-time groups only — never on recurring,
        // including when the subscription group is the last remaining cart group.
        $billingMode = (string) ($built['billing'] ?? '');
        if ($billingMode === '' && !empty($built['lines'][0]) && is_array($built['lines'][0])) {
            $billingMode = (string) ($built['lines'][0]['billing'] ?? 'one_time');
        }
        if ($billingMode === '') {
            $billingMode = 'one_time';
        }
        $applyTenders = $billingMode !== 'recurring';
        $giftCardCents = 0;
        $giftCardCode = $this->cart->getGiftCardCode();
        if ($applyTenders) {
            $giftTender = $this->discounts->applyGiftCardTender((int) $built['total_cents'], $giftCardCode, $this->giftCardStore(), $built['currency'] ?? null);
            if (!($giftTender['ok'] ?? false)) {
                return ['ok' => false, 'error' => $giftTender['error'] ?? 'Gift card error'];
            }
            $giftCardCents = (int) ($giftTender['applied_cents'] ?? 0);
            if ($giftCardCents > 0) {
                $built['gift_card_cents'] = $giftCardCents;
                $built['gift_card_code'] = $giftTender['gift_card_code'] ?? $giftCardCode;
                $built['gift_card_applications'] = $this->buildGiftCardApplications(
                    $built['gift_card_code'] ?? $giftCardCode,
                    $giftCardCents
                );
                $built['total_cents'] -= $giftCardCents;
            }
        } else {
            $coupon = null;
        }

        if ($this->containsRecurringLines($built['lines']) && !CommerceSchema::recurringBillingEnabled()) {
            return ['ok' => false, 'error' => 'Recurring billing is disabled on this site. Use one-time purchase options.'];
        }

        $orderId = 'cord_' . bin2hex(random_bytes(8));
        $reservation = $this->stockReservations()->reserveLines($built['lines'], $orderId);
        if (!($reservation['ok'] ?? false)) {
            return ['ok' => false, 'error' => $reservation['error'] ?? 'Insufficient stock'];
        }
        $built['lines'] = $reservation['lines'] ?? $built['lines'];

        $orderPayload = [
            'id' => $orderId,
            'status' => 'pending',
            'lines' => $built['lines'],
            'total_cents' => $built['total_cents'],
            'shipping_cents' => $built['shipping_cents'] ?? 0,
            'shipping_lines' => $built['shipping_lines'] ?? [],
            'tax_cents' => $built['tax_cents'] ?? 0,
            'tax_rate' => $built['tax_rate'] ?? 0.0,
            'tax_country' => $built['tax_country'] ?? '',
            'tax_lines' => $built['tax_lines'] ?? [],
            'discount_cents' => $built['discount_cents'] ?? 0,
            'discount_allocations' => $built['discount_allocations'] ?? [],
            'gift_card_applications' => $built['gift_card_applications'] ?? [],
            'currency' => $built['currency'],
            'customer_email' => $customerEmail,
            'coupon_code' => $coupon,
            'affiliate_id' => $affiliate,
            'stock_reservation_id' => $reservation['reservation_id'] ?? null,
            'checkout_group_key' => $groupKey !== '' ? $groupKey : ($groups[0]['key'] ?? null),
        ];
        if ($customerName !== '') {
            $orderPayload['customer_name'] = $customerName;
        }
        if ($entrySyncMeta !== []) {
            $orderPayload['entry_sync_meta'] = $entrySyncMeta;
            $orderPayload['donor_meta'] = $entrySyncMeta;
            $orderPayload['metadata'] = $entrySyncMeta;
            $entryIdKey = trim((string) commerce_get_setting('commerce_entry_sync_entry_id_meta', 'supporter_entry_id'));
            $linkedEntryId = $entryIdKey !== '' ? (string) ($entrySyncMeta[$entryIdKey] ?? '') : '';
            if ($linkedEntryId === '' && !empty($entrySyncMeta['supporter_entry_id'])) {
                $linkedEntryId = (string) $entrySyncMeta['supporter_entry_id'];
            }
            if ($linkedEntryId !== '') {
                $orderPayload['supporter_entry_id'] = $linkedEntryId;
            }
        }
        if ($vatId !== '') {
            $orderPayload['vat_id'] = $vatId;
            $orderPayload['tax_id'] = $vatId; // alias for integrators
        }
        if ($giftCardCents > 0) {
            $orderPayload['gift_card_code'] = $built['gift_card_code'] ?? $giftCardCode;
            $orderPayload['gift_card_cents'] = $giftCardCents;
        }
        if (is_array($shippingAddress)) {
            $orderPayload['shipping_address'] = $shippingAddress;
        }
        if (is_array($billingAddress)) {
            $orderPayload['billing_address'] = $billingAddress;
        }
        if ($attendeeName !== null && trim((string) $attendeeName) !== '') {
            $orderPayload['attendee_name'] = trim((string) $attendeeName);
        }

        $billingMode = $built['lines'][0]['billing'] ?? 'one_time';
        $orderPayload['billing_mode'] = $billingMode;
        if ($billingMode === 'recurring') {
            $orderPayload['billing_interval'] = $built['lines'][0]['interval'] ?? 'month';
        }

        $order = $this->orders->create($orderPayload);
        try {
            $this->customerStore()->ensureCustomerFromOrder($order);
        } catch (Throwable $e) {
            error_log('Commerce customer upsert on order create failed: ' . $e->getMessage());
        }
        $this->fireOrderCreated($order);
        return ['ok' => true, 'order' => $order];
    }

    /**
     * Start checkout. Mixed one-time + subscription carts are split into sequential
     * groups: collect details once, then confirm/pay each group.
     *
     * @return array<string, mixed>
     */
    public function checkout(string $customerEmail = '', string $returnUrl = '', string $cancelUrl = '', array $checkoutData = []): array
    {
        $shelf = $this->getShelf();
        if (!$shelf || !$shelf->isConfigured()) {
            return ['ok' => false, 'error' => 'Payments not configured'];
        }

        $built = $this->catalog->buildCartLines(
            $this->cart->getItems(),
            $this->discounts,
            $this->cart->getCouponCode(),
            $this->cart->getAffiliateId()
        );
        if (($built['ok'] ?? true) === false) {
            return [
                'ok' => false,
                'error' => $built['error'] ?? 'Cart error',
                'checkout_allowed' => $built['checkout_allowed'] ?? false,
            ];
        }
        if (empty($built['lines'])) {
            return ['ok' => false, 'error' => 'Cart is empty'];
        }

        $groups = $built['groups'] ?? $this->catalog->groupCartLines($built['lines']);
        $groupKey = trim((string) ($checkoutData['group_key'] ?? ''));

        // Multi-group cart without an explicit group → return a split plan.
        // The storefront collects email/address once, then calls checkout per group.
        if (count($groups) > 1 && $groupKey === '') {
            $draft = $this->saveCheckoutDraft($customerEmail, $checkoutData, $groups);
            return [
                'ok' => true,
                'needs_split' => true,
                'split_required' => true,
                'checkout_session_id' => $draft['id'] ?? null,
                'groups' => $groups,
                'current_group_key' => $groups[0]['key'] ?? null,
                'currency' => $built['currency'] ?? 'eur',
                'total_cents' => (int) ($built['total_cents'] ?? 0),
                'message' => 'This cart needs split checkout. Pay one group at a time — details are reused after the first step.',
            ];
        }

        if ($groupKey === '' && count($groups) === 1) {
            $groupKey = (string) ($groups[0]['key'] ?? '');
            $checkoutData['group_key'] = $groupKey;
        }

        $pending = $this->createPendingOrder($customerEmail, $checkoutData);
        if (!($pending['ok'] ?? false)) {
            return $pending;
        }
        $order = $pending['order'];

        $params = [
            'amount_cents' => (int) $order['total_cents'],
            'currency' => $order['currency'],
            'description' => 'Order ' . $order['id'],
            'metadata' => [
                'order_id' => $order['id'],
                'line_count' => count($order['lines']),
                'billing_mode' => $order['billing_mode'] ?? 'one_time',
                'checkout_group_key' => $order['checkout_group_key'] ?? $groupKey,
            ],
        ];
        $orderMeta = [];
        if (class_exists('CommerceEntrySync')) {
            $orderMeta = CommerceEntrySync::orderEntrySyncMeta($order);
        } elseif (is_array($order['donor_meta'] ?? null)) {
            $orderMeta = $order['donor_meta'];
        }
        if ($orderMeta !== []) {
            foreach ($orderMeta as $metaKey => $metaVal) {
                if (is_scalar($metaVal) || $metaVal === null) {
                    $params['metadata'][(string) $metaKey] = (string) $metaVal;
                }
            }
        }
        if (($order['billing_mode'] ?? '') === 'recurring') {
            $params['billing'] = 'recurring';
            $params['interval'] = $order['billing_interval'] ?? 'month';
        }
        if ($returnUrl !== '') {
            $params['return_url'] = $returnUrl;
        }
        if ($cancelUrl !== '') {
            $params['cancel_url'] = $cancelUrl;
        }
        $emailForCheckout = trim((string) ($order['customer_email'] ?? $customerEmail));
        if ($emailForCheckout !== '') {
            $params['customer_email'] = $emailForCheckout;
            $params['email'] = $emailForCheckout;
        }
        if (!empty($checkoutData['hosted_checkout'])) {
            $params['hosted_checkout'] = true;
            $params['product_name'] = (string) (($order['lines'][0]['title'] ?? null) ?: ($params['description'] ?? 'Order'));
            $cancelUrl = $this->appendUrlQueryParam($cancelUrl, 'commerce_cancel', (string) $order['id']);
            if ($returnUrl !== '') {
                $returnUrl = $this->appendUrlQueryParam($returnUrl, 'commerce_order', (string) $order['id']);
            }
        }
        if ($cancelUrl !== '') {
            $params['cancel_url'] = $cancelUrl;
        }
        if ($returnUrl !== '') {
            $params['return_url'] = $returnUrl;
        }

        $result = $shelf->createPayment('auto', $params, [
            'source_plugin' => 'commerce',
            'source_ref' => $order['id'],
        ]);

        if (!($result['ok'] ?? false)) {
            $this->orders->update($order['id'], ['status' => 'failed', 'error' => $result['error'] ?? 'Payment failed']);
            if (!empty($order['stock_reservation_id'])) {
                $this->stockReservations()->release((string) $order['stock_reservation_id'], 'payment_failed');
            }
            return ['ok' => false, 'error' => $result['error'] ?? 'Payment failed', 'order_id' => $order['id']];
        }

        $this->orders->update($order['id'], [
            'payment_id' => $result['payment_id'] ?? null,
            'provider' => $result['provider'] ?? null,
            'payment_connection_id' => $result['connection_id'] ?? null,
            'status' => 'pending',
            'stripe_checkout_session_id' => !empty($checkoutData['hosted_checkout'])
                && is_string($result['payment_id'] ?? null)
                && str_starts_with((string) $result['payment_id'], 'cs_')
                ? (string) $result['payment_id']
                : ($order['stripe_checkout_session_id'] ?? null),
        ]);
        // A new checkout attempt supersedes earlier unfinished ones for the same cart.
        $this->abandonSupersededPendingOrders($order);

        // Refresh draft so later groups can confirm without re-entering details.
        $remaining = [];
        foreach ($groups as $g) {
            if (($g['key'] ?? '') !== $groupKey) {
                $remaining[] = $g;
            }
        }
        $draftOut = $this->saveCheckoutDraft(
            (string) ($order['customer_email'] ?? $customerEmail),
            array_merge($checkoutData, [
                'shipping_address' => $order['shipping_address'] ?? ($checkoutData['shipping_address'] ?? null),
                'attendee_name' => $order['attendee_name'] ?? ($checkoutData['attendee_name'] ?? null),
            ]),
            $remaining,
            $this->cart->getCheckoutDraft()['id'] ?? null
        );

        $goodsSubtotal = 0;
        foreach ($order['lines'] ?? [] as $oline) {
            $goodsSubtotal += (int) ($oline['line_total_cents'] ?? 0);
        }

        return [
            'ok' => true,
            'order_id' => $order['id'],
            'payment_id' => $result['payment_id'] ?? null,
            'redirect_url' => $result['redirect_url'] ?? null,
            'client_secret' => $result['client_secret'] ?? null,
            'provider' => $result['provider'] ?? null,
            'group_key' => $groupKey !== '' ? $groupKey : ($order['checkout_group_key'] ?? null),
            'checkout_session_id' => $draftOut['id'] ?? null,
            'remaining_groups' => $remaining,
            'needs_split' => count($remaining) > 0,
            'next_group_key' => $remaining[0]['key'] ?? null,
            // Money snapshot for storefront totals (tax/shipping) before payment confirms.
            'currency' => $order['currency'] ?? ($built['currency'] ?? 'eur'),
            'subtotal_cents' => $goodsSubtotal,
            'shipping_cents' => (int) ($order['shipping_cents'] ?? 0),
            'shipping_lines' => $order['shipping_lines'] ?? [],
            'tax_cents' => (int) ($order['tax_cents'] ?? 0),
            'tax_lines' => $order['tax_lines'] ?? [],
            'discount_cents' => (int) ($order['discount_cents'] ?? 0),
            'total_cents' => (int) ($order['total_cents'] ?? 0),
        ];
    }

    /** @param array<int, array<string, mixed>> $groups */
    private function findCheckoutGroup(array $groups, string $groupKey): ?array
    {
        foreach ($groups as $group) {
            if (($group['key'] ?? '') === $groupKey) {
                return $group;
            }
        }
        return null;
    }

    /**
     * Narrow a full cart build to one checkout group (lines + totals).
     *
     * @param array<string, mixed> $built
     * @param array<string, mixed> $group
     * @return array<string, mixed>
     */
    private function scopeBuiltToGroup(array $built, array $group): array
    {
        $lines = $group['lines'] ?? [];
        $subtotal = 0;
        $discount = 0;
        foreach ($lines as $line) {
            $subtotal += (int) ($line['line_total_cents'] ?? 0);
            $discount += (int) ($line['discount_amount_cents'] ?? 0);
        }
        $shipping = (int) ($group['shipping_cents'] ?? $this->catalog->calculateShipping($lines));
        $shippingLines = is_array($group['shipping_lines'] ?? null)
            ? $group['shipping_lines']
            : $this->wrapShippingScalar($shipping);
        return [
            'ok' => true,
            'lines' => $lines,
            'groups' => [$group],
            'total_cents' => $subtotal + $shipping,
            'shipping_cents' => $shipping,
            'shipping_lines' => $shippingLines,
            'discount_cents' => $discount,
            'discount_allocations' => $this->catalog->buildDiscountAllocations(
                $lines,
                $this->cart->getCouponCode(),
                $this->cart->getAffiliateId()
            ),
            'currency' => $built['currency'] ?? ($group['currency'] ?? 'eur'),
            'billing' => $group['billing'] ?? 'one_time',
            'checkout_allowed' => true,
            'split_required' => false,
            'warnings' => [],
        ];
    }

    /**
     * @param array<string, mixed> $checkoutData
     * @param array<int, array<string, mixed>> $remainingGroups
     * @return array<string, mixed>
     */
    private function saveCheckoutDraft(string $email, array $checkoutData, array $remainingGroups, ?string $existingId = null): array
    {
        $draft = $this->resolveCheckoutDraft($checkoutData);
        $id = $existingId ?: ((string) ($draft['id'] ?? '') !== '' ? (string) $draft['id'] : ('cs_' . bin2hex(random_bytes(8))));
        $email = trim($email) !== '' ? trim($email) : (string) ($draft['email'] ?? '');
        $out = [
            'id' => $id,
            'email' => $email,
            'shipping_address' => $checkoutData['shipping_address'] ?? ($draft['shipping_address'] ?? null),
            'billing_address' => $checkoutData['billing_address'] ?? ($draft['billing_address'] ?? null),
            'attendee_name' => $checkoutData['attendee_name'] ?? ($draft['attendee_name'] ?? null),
            'vat_id' => $this->resolveVatId($checkoutData, is_array($checkoutData['shipping_address'] ?? null) ? $checkoutData['shipping_address'] : null)
                ?: ($draft['vat_id'] ?? null),
            'remaining_group_keys' => array_values(array_map(static fn($g) => $g['key'] ?? '', $remainingGroups)),
            'updated_at' => date('c'),
        ];
        $this->cart->setCheckoutDraft($out);
        return $out;
    }

    /**
     * Resolve VAT / tax ID from checkout payload (vat_id or tax_id aliases).
     *
     * @param array<string, mixed> $checkoutData
     * @param array<string, mixed>|null $shippingAddress
     */
    private function resolveVatId(array $checkoutData, ?array $shippingAddress): string
    {
        $raw = $checkoutData['vat_id']
            ?? ($checkoutData['tax_id']
            ?? (is_array($shippingAddress) ? ($shippingAddress['vat_id'] ?? ($shippingAddress['tax_id'] ?? null)) : null));
        if (($raw === null || trim((string) $raw) === '') && is_array($checkoutData['billing_address'] ?? null)) {
            $billing = $checkoutData['billing_address'];
            $raw = $billing['vat_id'] ?? ($billing['tax_id'] ?? null);
        }
        return $this->catalog->normalizeVatId($raw);
    }

    /** @param array<string, mixed> $checkoutData @return array<string, mixed> */
    private function resolveCheckoutDraft(array $checkoutData): array
    {
        $draft = $this->cart->getCheckoutDraft();
        if (!is_array($draft)) {
            return [];
        }
        $sessionId = trim((string) ($checkoutData['checkout_session_id'] ?? ''));
        if ($sessionId !== '' && ($draft['id'] ?? '') !== $sessionId) {
            return [];
        }
        return $draft;
    }

    public function checkoutQuote(string $token, string $customerEmail = '', string $returnUrl = '', string $cancelUrl = ''): array {
        $qs = $this->quoteStore(); $quote = $qs->findByToken($token);
        if (!$quote) return ['ok'=>false,'error'=>'Quote not found'];
        if (($quote['status']??'')==='quote') { $a=$qs->accept($token); if(!($a['ok']??false)) return $a; $quote=$a['quote']; }
        if (($quote['status']??'')!=='pending_payment') return ['ok'=>false,'error'=>'Quote not available'];
        $pending = $this->createPendingOrderFromQuote($quote, trim($customerEmail)!==''?trim($customerEmail):(string)($quote['customer_email']??''));
        if (!($pending['ok']??false)) return $pending; $order=$pending['order']; $shelf=$this->getShelf();
        if (!$shelf||!$shelf->isConfigured()) { if(!empty($order['stock_reservation_id'])) $this->stockReservations()->release((string)$order['stock_reservation_id'],'payments_not_configured'); return ['ok'=>false,'error'=>'Payments not configured','order_id'=>$order['id']]; }
        $params=['amount_cents'=>(int)$order['total_cents'],'currency'=>$order['currency'],'description'=>'Quote '.($quote['id']??'')];
        if ($returnUrl!=='') $params['return_url']=$returnUrl; if ($cancelUrl!=='') $params['cancel_url']=$cancelUrl;
        $result=$shelf->createPayment('auto',$params,['source_plugin'=>'commerce','source_ref'=>$order['id']]);
        if (!($result['ok']??false)) { $this->orders->update($order['id'],['status'=>'failed']); if(!empty($order['stock_reservation_id'])) $this->stockReservations()->release((string)$order['stock_reservation_id'],'payment_failed'); return ['ok'=>false,'error'=>$result['error']??'Payment failed','order_id'=>$order['id']]; }
        $this->orders->update($order['id'], [
            'payment_id' => $result['payment_id'] ?? null,
            'provider' => $result['provider'] ?? null,
            'payment_connection_id' => $result['connection_id'] ?? null,
            'status' => 'pending',
            'stripe_checkout_session_id' => is_string($result['payment_id'] ?? null) && str_starts_with((string) $result['payment_id'], 'cs_')
                ? (string) $result['payment_id']
                : null,
        ]);
        return ['ok'=>true,'order_id'=>$order['id'],'quote_id'=>$quote['id']??null,'payment_id'=>$result['payment_id']??null,'redirect_url'=>$result['redirect_url']??null];
    }
    public function createPendingOrderFromQuote(array $quote, string $customerEmail=''): array {
        $lines=$quote['lines']??[]; if(empty($lines)) return ['ok'=>false,'error'=>'Quote has no lines'];
        if ($this->containsRecurringLines($lines) && !CommerceSchema::recurringBillingEnabled()) {
            return ['ok' => false, 'error' => 'Recurring billing is disabled on this site. Use one-time purchase options.'];
        }
        $orderId='cord_'.bin2hex(random_bytes(8));
        $reservation=$this->stockReservations()->reserveLines($lines,$orderId);
        if(!($reservation['ok']??false)) return ['ok'=>false,'error'=>$reservation['error']??'Insufficient stock'];
        $lines=$reservation['lines']??$lines;
        $taxLines = is_array($quote['tax_lines'] ?? null) ? $quote['tax_lines'] : $this->wrapTaxScalar($quote);
        $shippingLines = is_array($quote['shipping_lines'] ?? null) ? $quote['shipping_lines'] : $this->wrapShippingScalar((int) ($quote['shipping_cents'] ?? 0));
        $discountAllocations = is_array($quote['discount_allocations'] ?? null) ? $quote['discount_allocations'] : $this->wrapDiscountScalar($quote);
        if (empty($taxLines)) {
            $taxLines = $this->wrapTaxScalar($quote);
        }
        if (empty($shippingLines)) {
            $shippingLines = $this->wrapShippingScalar((int) ($quote['shipping_cents'] ?? 0));
        }
        if (empty($discountAllocations)) {
            $discountAllocations = $this->wrapDiscountScalar($quote);
        }
        $orderPayload=[
            'id'=>$orderId,
            'status'=>'pending',
            'lines'=>$lines,
            'total_cents'=>(int)($quote['total_cents']??0),
            'shipping_cents'=>$this->sumMoneySnapshotLines($shippingLines, 'price_cents'),
            'shipping_lines'=>$shippingLines,
            'tax_cents'=>$this->sumMoneySnapshotLines($taxLines, 'tax_cents'),
            'tax_rate'=>$quote['tax_rate'] ?? 0.0,
            'tax_country'=>$quote['tax_country'] ?? '',
            'tax_lines'=>$taxLines,
            'discount_cents'=>$this->sumMoneySnapshotLines($discountAllocations, 'amount_cents'),
            'discount_allocations'=>$discountAllocations,
            'gift_card_applications'=>is_array($quote['gift_card_applications'] ?? null) ? $quote['gift_card_applications'] : [],
            'currency'=>$quote['currency']??'eur',
            'customer_email'=>$customerEmail,
            'quote_id'=>$quote['id']??null,
            'stock_reservation_id'=>$reservation['reservation_id']??null,
        ];
        if (is_array($quote['shipping_address'] ?? null)) {
            $orderPayload['shipping_address'] = $quote['shipping_address'];
        }
        if (is_array($quote['billing_address'] ?? null)) {
            $orderPayload['billing_address'] = $quote['billing_address'];
        }
        $vatId = trim((string) ($quote['vat_id'] ?? ($quote['tax_id'] ?? '')));
        if ($vatId !== '') {
            $orderPayload['vat_id'] = $vatId;
            $orderPayload['tax_id'] = $vatId;
        }
        $order=$this->orders->create($orderPayload);
        $this->quoteStore()->update($quote['id'],['order_id'=>$order['id']]);
        try {
            $this->customerStore()->ensureCustomerFromOrder($order);
        } catch (Throwable $e) {
            error_log('Commerce customer upsert on quote order failed: ' . $e->getMessage());
        }
        $this->fireOrderCreated($order);
        return ['ok'=>true,'order'=>$order];
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     */
    private function sumMoneySnapshotLines(array $lines, string $amountKey): int
    {
        $sum = 0;
        foreach ($lines as $line) {
            if (!is_array($line)) {
                continue;
            }
            $sum += (int) ($line[$amountKey] ?? 0);
        }
        return $sum;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function wrapTaxScalar(array $source): array
    {
        $taxCents = (int) ($source['tax_cents'] ?? 0);
        if ($taxCents <= 0) {
            return [];
        }
        $country = strtoupper(trim((string) ($source['tax_country'] ?? '')));
        $rate = (float) ($source['tax_rate'] ?? 0.0);
        $taxable = (int) ($source['taxable_cents'] ?? 0);
        $basis = $country . '|' . $rate . '|' . $taxable . '|' . $taxCents;
        return [[
            'id' => 'tl_' . substr(hash('sha256', $basis), 0, 12),
            'title' => $country !== '' ? ('VAT ' . $country) : 'Tax',
            'rate' => $rate,
            'country' => $country,
            'taxable_cents' => $taxable,
            'tax_cents' => $taxCents,
            'source' => 'manual',
        ]];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function wrapShippingScalar(int $shippingCents): array
    {
        if ($shippingCents <= 0) {
            return [];
        }
        return [[
            'id' => 'sl_' . substr(hash('sha256', 'manual|' . $shippingCents), 0, 12),
            'title' => 'Manual shipping',
            'code' => 'manual',
            'price_cents' => $shippingCents,
            'source' => 'manual_zones',
        ]];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function wrapDiscountScalar(array $source): array
    {
        $discountCents = (int) ($source['discount_cents'] ?? 0);
        if ($discountCents <= 0) {
            return [];
        }
        $code = trim((string) ($source['coupon_code'] ?? ''));
        return [[
            'id' => 'da_' . substr(hash('sha256', $code . '|' . $discountCents), 0, 12),
            'code' => $code,
            'type' => $code !== '' ? 'coupon' : 'manual',
            'amount_cents' => $discountCents,
            'source' => 'discount_engine',
        ]];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function buildGiftCardApplications(?string $code, int $amountCents): array
    {
        $clean = strtoupper(trim((string) $code));
        if ($amountCents <= 0 || $clean === '') {
            return [];
        }
        return [[
            'id' => 'gca_' . substr(hash('sha256', $clean . '|' . $amountCents), 0, 12),
            'code_hash' => hash('sha256', $clean),
            'code_last4' => substr($clean, -4),
            'amount_cents' => $amountCents,
            'source' => 'gift_card_store',
        ]];
    }

    public function markPaidByPaymentId(string $paymentId): ?array
    {
        $order = $this->findOrderForPaymentId($paymentId);
        if (!$order) {
            return null;
        }
        $order = $this->normalizeOrderPaymentReference($order, $paymentId);
        if (($order['status'] ?? '') === 'paid') {
            return $this->ensureSubscriptionForOrder($order);
        }

        if (!empty($order['stock_reservation_id'])) {
            $this->stockReservations()->commit((string) $order['stock_reservation_id'], (string) $order['id']);
        } else {
            foreach ($order['lines'] ?? [] as $line) {
                $this->decrementLineStock($line);
            }
        }

        $updated = $this->orders->update($order['id'], [
            'status' => 'paid',
            'paid_at' => date('c'),
        ]);
        // Split checkout: remove only the paid group's lines so remaining groups stay in cart.
        $this->cart->removeLines($updated['lines'] ?? []);
        if ($this->cart->count() === 0) {
            $this->cart->clear();
            $this->cart->clearCheckoutDraft();
        } else {
            $draft = $this->cart->getCheckoutDraft();
            if (is_array($draft)) {
                $paidKey = (string) ($updated['checkout_group_key'] ?? '');
                $remainingKeys = array_values(array_filter(
                    $draft['remaining_group_keys'] ?? [],
                    static fn($k) => (string) $k !== $paidKey && (string) $k !== ''
                ));
                $draft['remaining_group_keys'] = $remainingKeys;
                $draft['updated_at'] = date('c');
                $this->cart->setCheckoutDraft($draft);
            }
        }
        if ((int)($updated['gift_card_cents']??0)>0 && ($updated['gift_card_code']??'')!=='') {
            $this->giftCardStore()->redeem($updated['gift_card_code'],(int)$updated['gift_card_cents'],$order['id']);
            // Spent tender must not block later split groups (e.g. subscribe).
            if ($this->cart->getGiftCardCode() !== null) {
                $this->cart->setGiftCardCode(null);
            }
        }
        if (($updated['billing_mode'] ?? '') === 'one_time' && $this->cart->count() > 0 && $this->cart->getCouponCode() !== null) {
            // Coupons settle with the one-time group; clear before recurring continues.
            $this->cart->setCouponCode(null);
        }
        if (!empty($updated['quote_id'])) $this->quoteStore()->markPaid((string)$updated['quote_id'],$order['id']);
        try {
            $this->customerStore()->ensureCustomerFromOrder($updated);
        } catch (Throwable $e) {
            error_log('Commerce customer upsert on order paid failed: ' . $e->getMessage());
        }
        try {
            if (method_exists($this->discounts, 'recordUsageFromAllocations')) {
                $this->discounts->recordUsageFromAllocations($updated['discount_allocations'] ?? []);
            }
        } catch (Throwable $e) {
            error_log('Commerce discount usage increment failed: ' . $e->getMessage());
        }
        $updated = $this->enrichOrderFromPaymentProvider($updated, $paymentId);
        $this->fireOrderPaid($updated);
        // Subscription must exist before PostPurchaseRouter so membership entitlement
        // checks (club activation email) succeed in the same request.
        $updated = $this->ensureSubscriptionForOrder($updated ?? $order);
        $fulfillmentResults = $this->router->route($updated);
        $this->mappings->applyPurchaseMappings($updated);

        if (!empty($fulfillmentResults)) {
            $updated = $this->orders->update($order['id'], ['fulfillment_results' => $fulfillmentResults]);
        }

        return $updated ?? $order;
    }

    /**
     * Verify provider payment status and mark the local order paid when succeeded.
     * Storefronts should call this after Stripe Elements confirm (webhooks are optional).
     *
     * @return array{ok: bool, error?: string, order?: array, payment_status?: string, already_paid?: bool}
     */
    public function confirmLocalPayment(string $paymentId): array
    {
        $paymentId = trim($paymentId);
        if ($paymentId === '') {
            return ['ok' => false, 'error' => 'payment_id required'];
        }

        $order = $this->findOrderForPaymentId($paymentId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found for payment'];
        }

        if (($order['status'] ?? '') === 'paid') {
            $order = $this->ensureSubscriptionForOrder($order);
            return array_merge(
                ['ok' => true, 'order' => $order, 'already_paid' => true, 'payment_status' => 'succeeded'],
                $this->splitContinuationPayload()
            );
        }

        $provider = (string) ($order['provider'] ?? '');
        $shelf = $this->getShelf();
        if (!$shelf || $provider === '') {
            return ['ok' => false, 'error' => 'Payments not configured', 'order' => $order];
        }

        $status = $shelf->getPaymentStatus($provider, $paymentId, array_filter([
            'connection_id' => $order['payment_connection_id'] ?? null,
            'payment_id' => $paymentId,
        ]));
        if (!($status['ok'] ?? false)) {
            return ['ok' => false, 'error' => $status['error'] ?? 'Could not verify payment', 'order' => $order];
        }

        $normalized = strtolower((string) ($status['status'] ?? ''));
        $paidStatuses = ['succeeded', 'paid', 'complete', 'completed', 'captured'];
        if (!in_array($normalized, $paidStatuses, true)) {
            return [
                'ok' => false,
                'error' => 'Payment not completed yet',
                'payment_status' => $normalized,
                'order' => $order,
            ];
        }

        $updated = $this->markPaidByPaymentId($paymentId);
        return array_merge(
            [
                'ok' => true,
                'order' => $updated,
                'payment_status' => $normalized,
                'already_paid' => false,
            ],
            $this->splitContinuationPayload()
        );
    }

    /**
     * Remaining split-checkout groups after a successful payment (storefront continue).
     *
     * @return array{
     *   needs_split: bool,
     *   next_group_key: ?string,
     *   checkout_session_id: ?string,
     *   remaining_groups: array<int, array<string, mixed>>,
     *   cart_count: int
     * }
     */
    private function splitContinuationPayload(): array
    {
        $draft = $this->cart->getCheckoutDraft();
        $remainingKeys = is_array($draft) ? ($draft['remaining_group_keys'] ?? []) : [];
        $built = $this->catalog->buildCartLines(
            $this->cart->getItems(),
            $this->discounts,
            $this->cart->getCouponCode(),
            $this->cart->getAffiliateId()
        );
        $groups = $built['groups'] ?? $this->catalog->groupCartLines($built['lines'] ?? []);
        $remaining = [];
        foreach ($groups as $group) {
            $key = (string) ($group['key'] ?? '');
            if ($key !== '' && in_array($key, $remainingKeys, true)) {
                $remaining[] = $group;
            }
        }
        // Fall back to all remaining cart groups when draft keys are stale.
        if ($remaining === [] && count($groups) > 0 && $this->cart->count() > 0) {
            $remaining = $groups;
        }
        return [
            'needs_split' => count($remaining) > 0,
            'next_group_key' => $remaining[0]['key'] ?? null,
            'checkout_session_id' => is_array($draft) ? ($draft['id'] ?? null) : null,
            'remaining_groups' => $remaining,
            'cart_count' => $this->cart->count(),
        ];
    }

    /**
     * Confirm a pending order by id (admin recovery / diagnostics).
     *
     * @return array{ok: bool, error?: string, order?: array, payment_status?: string}
     */
    public function syncOrderPayment(string $orderId): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        $paymentId = trim((string) ($order['payment_id'] ?? ''));
        if ($paymentId === '') {
            $abandoned = $this->orders->update($orderId, [
                'status' => 'abandoned',
                'abandoned_reason' => 'missing_payment_id',
            ]);
            return ['ok' => false, 'error' => 'Order has no payment_id', 'order' => $abandoned ?? $order];
        }
        return $this->confirmLocalPayment($paymentId);
    }

    /**
     * Resend order receipt / donation thanks for a paid order (admin recovery).
     *
     * @return array{ok: bool, error?: string, trigger?: string, to?: string, results?: list<array<string, mixed>>}
     */
    public function resendOrderReceipt(string $orderId): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        $status = (string) ($order['status'] ?? '');
        if (!in_array($status, ['paid', 'partially_refunded'], true)) {
            return [
                'ok' => false,
                'error' => 'Receipt emails send only for paid orders (current status: ' . ($status !== '' ? $status : 'unknown') . ')',
            ];
        }
        $email = trim((string) ($order['customer_email'] ?? ''));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'error' => 'Order has no customer email'];
        }
        $trigger = 'order_paid';
        try {
            if (!class_exists('CommerceEmailService')) {
                require_once __DIR__ . '/CommerceEmailService.php';
            }
            $dataDir = dirname($this->orders->getDataDir());
            $emailSvc = new CommerceEmailService($dataDir);
            $results = $emailSvc->sendForTrigger($trigger, ['order' => $order]);
            $sent = false;
            foreach ($results as $row) {
                if (!empty($row['ok']) && empty($row['scheduled'])) {
                    $sent = true;
                    break;
                }
            }
            if (!$sent) {
                return [
                    'ok' => false,
                    'error' => 'No enabled email templates for trigger: ' . $trigger,
                    'trigger' => $trigger,
                    'to' => $email,
                    'results' => $results,
                ];
            }
            return ['ok' => true, 'trigger' => $trigger, 'to' => $email, 'results' => $results];
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Abandon a pending hosted-checkout order (e.g. shopper canceled on Stripe).
     *
     * @return array{ok: bool, error?: string, order?: array}
     */
    public function abandonCheckoutOrder(string $orderId, ?string $email = null): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        if (($order['status'] ?? '') !== 'pending') {
            return ['ok' => false, 'error' => 'Order is not pending', 'order' => $order];
        }
        if ($email !== null && trim($email) !== '') {
            $expected = strtolower(trim($email));
            $actual = strtolower(trim((string) ($order['customer_email'] ?? '')));
            if ($actual !== '' && $actual !== $expected) {
                return ['ok' => false, 'error' => 'Email does not match'];
            }
        }
        if (!empty($order['stock_reservation_id'])) {
            $this->stockReservations()->release((string) $order['stock_reservation_id'], 'checkout_canceled');
        }
        $updated = $this->orders->update($orderId, [
            'status' => 'abandoned',
            'abandoned_reason' => 'checkout_canceled',
        ]);
        if (class_exists('CommerceEntrySync')) {
            CommerceEntrySync::markAbandonedFromOrder($updated ?? $order);
        } elseif (class_exists('CommerceDonorSync')) {
            CommerceDonorSync::markAbandonedFromOrder($updated ?? $order);
        }
        return ['ok' => true, 'order' => $updated ?? $order];
    }

    /**
     * Reconcile pending orders against the payment provider.
     * Succeeded charges become paid (+ subscription). Unpaid / canceled
     * PaymentIntents and superseded checkout duplicates become abandoned.
     *
     * @return array{
     *   ok: bool,
     *   synced_order_ids: array<int, string>,
     *   abandoned_order_ids: array<int, string>,
     *   count: int,
     *   abandoned_count: int
     * }
     */
    public function reconcilePendingPayments(int $limit = 50): array
    {
        $synced = [];
        $abandoned = [];
        $checked = 0;
        $limit = max(1, min(100, $limit));
        $paidFingerprints = [];
        foreach ($this->orders->listAll() as $order) {
            if (($order['status'] ?? '') === 'paid') {
                $paidFingerprints[$this->orderFingerprint($order)] = (string) ($order['id'] ?? '');
            }
        }

        foreach ($this->orders->listAll() as $order) {
            if ($checked >= $limit) {
                break;
            }
            if (($order['status'] ?? '') !== 'pending') {
                continue;
            }
            $checked++;
            $orderId = (string) ($order['id'] ?? '');
            $paymentId = trim((string) ($order['payment_id'] ?? ''));

            // Newer successful checkout for the same cart → this pending row is a duplicate.
            $fp = $this->orderFingerprint($order);
            if ($fp !== '' && isset($paidFingerprints[$fp]) && $paidFingerprints[$fp] !== $orderId) {
                $this->orders->update($orderId, [
                    'status' => 'abandoned',
                    'abandoned_reason' => 'superseded_by_paid_order',
                    'superseded_by' => $paidFingerprints[$fp],
                ]);
                $abandoned[] = $orderId;
                continue;
            }

            if ($paymentId === '') {
                $this->orders->update($orderId, [
                    'status' => 'abandoned',
                    'abandoned_reason' => 'missing_payment_id',
                ]);
                $abandoned[] = $orderId;
                continue;
            }

            $result = $this->confirmLocalPayment($paymentId);
            if (($result['ok'] ?? false) && empty($result['already_paid'])) {
                $synced[] = (string) (($result['order']['id'] ?? null) ?: $orderId);
                $paidOrder = $result['order'] ?? null;
                if (is_array($paidOrder)) {
                    $paidFingerprints[$this->orderFingerprint($paidOrder)] = (string) ($paidOrder['id'] ?? $orderId);
                }
                continue;
            }

            $paymentStatus = strtolower((string) ($result['payment_status'] ?? ''));
            $abandonStatuses = [
                'requires_payment_method',
                'requires_confirmation',
                'canceled',
                'cancelled',
                'expired',
                'incomplete',
                'incomplete_expired',
            ];
            if (in_array($paymentStatus, $abandonStatuses, true)) {
                if (!empty($order['stock_reservation_id'])) {
                    $this->stockReservations()->release((string) $order['stock_reservation_id'], 'payment_' . $paymentStatus);
                }
                $this->orders->update($orderId, [
                    'status' => 'abandoned',
                    'abandoned_reason' => 'payment_' . $paymentStatus,
                    'payment_status' => $paymentStatus,
                ]);
                $abandoned[] = $orderId;
            }
        }

        // Backfill subscriptions for paid recurring orders that somehow missed creation.
        foreach ($this->orders->listAll() as $order) {
            if (($order['status'] ?? '') !== 'paid') {
                continue;
            }
            $this->ensureSubscriptionForOrder($order);
        }

        return [
            'ok' => true,
            'synced_order_ids' => array_values(array_filter($synced)),
            'abandoned_order_ids' => array_values(array_filter($abandoned)),
            'count' => count($synced),
            'abandoned_count' => count($abandoned),
        ];
    }

    /**
     * Fingerprint used to detect duplicate checkout attempts for the same cart.
     */
    private function orderFingerprint(array $order): string
    {
        $email = strtolower(trim((string) ($order['customer_email'] ?? '')));
        $entryKeys = [];
        foreach ($order['lines'] ?? [] as $line) {
            if (!is_array($line)) {
                continue;
            }
            $entryKeys[] = implode(':', [
                (string) ($line['entry_id'] ?? ''),
                (string) ($line['purchase_option_id'] ?? ''),
                (string) ((int) ($line['quantity'] ?? 1)),
                (string) ((int) ($line['unit_price_cents'] ?? $line['effective_unit_cents'] ?? 0)),
            ]);
        }
        sort($entryKeys);
        if ($email === '' && empty($entryKeys)) {
            return '';
        }
        return hash('sha256', $email . '|' . implode(',', $entryKeys) . '|' . (int) ($order['total_cents'] ?? 0));
    }

    /**
     * When a shopper starts a new checkout, mark earlier unfinished attempts for
     * the same cart as abandoned so the Orders tab does not fill with duplicates.
     */
    private function abandonSupersededPendingOrders(array $newOrder): void
    {
        $newId = (string) ($newOrder['id'] ?? '');
        $fp = $this->orderFingerprint($newOrder);
        if ($newId === '' || $fp === '') {
            return;
        }
        foreach ($this->orders->listAll() as $order) {
            if (($order['status'] ?? '') !== 'pending') {
                continue;
            }
            $id = (string) ($order['id'] ?? '');
            if ($id === '' || $id === $newId) {
                continue;
            }
            if ($this->orderFingerprint($order) !== $fp) {
                continue;
            }
            $this->orders->update($id, [
                'status' => 'abandoned',
                'abandoned_reason' => 'superseded_by_new_checkout',
                'superseded_by' => $newId,
            ]);
        }
    }

    /**
     * Ensure subscription records exist for a paid recurring order.
     * Creates one subscription per recurring line item.
     */
    private function ensureSubscriptionForOrder(array $order): array
    {
        $isRecurring = ($order['billing_mode'] ?? 'one_time') === 'recurring'
            || $this->containsRecurringLines($order['lines'] ?? []);
        if (!$isRecurring) {
            return $order;
        }
        if (($order['status'] ?? '') !== 'paid') {
            return $order;
        }

        // Normalize billing_mode so createFromOrder accepts line-inferred recurring carts.
        if (($order['billing_mode'] ?? 'one_time') !== 'recurring') {
            $order = $this->orders->update($order['id'], [
                'billing_mode' => 'recurring',
                'billing_interval' => $order['billing_interval']
                    ?? ($order['lines'][0]['interval'] ?? 'month'),
            ]) ?? $order;
        }

        $subscriptions = $this->subscriptions()->createAllFromOrder($order);
        if ($subscriptions) {
            $ids = array_values(array_filter(array_map(static function ($sub) {
                return $sub['id'] ?? null;
            }, $subscriptions)));
            $order = $this->orders->update($order['id'], [
                'subscription_id' => $ids[0] ?? null,
                'subscription_ids' => $ids,
            ]) ?? $order;
        }
        return $order;
    }

    /**
     * Cancel an order: stop fulfillment work, optionally refund, restore stock / entitlements.
     *
     * @param array{
     *   refund?: bool,
     *   reason?: string,
     *   source?: string,
     *   actor?: array{id?: ?string, email?: ?string, name?: string, label?: string}|null
     * } $options
     * @return array{ok: bool, error?: string, order?: array, refund?: array|null, canceled?: bool}
     */
    public function cancelOrder(string $orderId, array $options = []): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }

        $status = (string) ($order['status'] ?? '');
        if ($status === 'canceled') {
            return ['ok' => true, 'order' => $order, 'canceled' => true, 'refund' => null];
        }
        if (in_array($status, ['abandoned', 'failed', 'refunded'], true)) {
            return ['ok' => false, 'error' => 'Order cannot be canceled (status: ' . $status . ')'];
        }

        if (!class_exists('CommerceOrderOps')) {
            require_once __DIR__ . '/CommerceOrderOps.php';
        }
        if (CommerceOrderOps::orderHasShipmentProgress($order)) {
            return ['ok' => false, 'error' => 'Order has already been shipped — use refund / return instead of cancel'];
        }

        $source = trim((string) ($options['source'] ?? 'admin'));
        if ($source === '') {
            $source = 'admin';
        }
        $reason = trim((string) ($options['reason'] ?? ''));
        $actor = is_array($options['actor'] ?? null) ? $options['actor'] : null;
        $refundRequested = array_key_exists('refund', $options)
            ? (bool) $options['refund']
            : ($status === 'paid' || $status === 'partially_refunded');

        // Customer cancels always refund remaining paid balance when cancel is allowed.
        if ($source === 'customer') {
            $refundRequested = in_array($status, ['paid', 'partially_refunded'], true);
        }

        $refundRecord = null;
        $stockAlreadyRestored = false;
        $remaining = max(0, (int) ($order['total_cents'] ?? 0) - (int) ($order['refunded_cents'] ?? 0));

        if ($refundRequested && in_array($status, ['paid', 'partially_refunded'], true) && $remaining > 0) {
            $refundResult = $this->refundOrder(
                $orderId,
                null,
                $reason !== '' ? $reason : 'Order canceled',
                null
            );
            if (!($refundResult['ok'] ?? false)) {
                return ['ok' => false, 'error' => $refundResult['error'] ?? 'Refund failed; order was not canceled'];
            }
            $refundRecord = $refundResult['refund'] ?? null;
            $stockAlreadyRestored = true;
            $order = $refundResult['order'] ?? $this->orders->get($orderId) ?? $order;
        }

        if ($status === 'pending' && !empty($order['stock_reservation_id'])) {
            $this->stockReservations()->release((string) $order['stock_reservation_id'], 'order_canceled');
        } elseif (!$stockAlreadyRestored && in_array($status, ['paid', 'partially_refunded'], true)) {
            foreach ($order['lines'] ?? [] as $line) {
                if (is_array($line)) {
                    $this->restoreLineStock($line);
                }
            }
        }

        if (!class_exists('EventRegistrationStore')) {
            require_once __DIR__ . '/EventRegistrationStore.php';
        }
        if (!class_exists('DigitalDeliveryStore')) {
            require_once __DIR__ . '/DigitalDeliveryStore.php';
        }
        $dataDir = dirname($this->orders->getDataDir());
        $regsCanceled = (new EventRegistrationStore($dataDir))->cancelByOrder($orderId, $reason);
        $tokensRevoked = (new DigitalDeliveryStore($dataDir))->revokeByOrder($orderId, $reason !== '' ? $reason : 'order_canceled');

        $cancelMeta = [
            'canceled_at' => date('c'),
            'cancel_reason' => $reason,
            'cancel_source' => $source,
            'cancel_refunded' => $refundRecord !== null,
            'fulfillment_status' => 'canceled',
        ];
        if (is_array($actor)) {
            $cancelMeta['canceled_by'] = $actor['label'] ?? ($actor['name'] ?? 'Admin');
            $cancelMeta['canceled_by_id'] = $actor['id'] ?? null;
            $cancelMeta['canceled_by_email'] = $actor['email'] ?? null;
        }

        $activity = is_array($order['fulfillment_activity'] ?? null) ? $order['fulfillment_activity'] : [];
        $activity[] = [
            'action' => 'order_canceled',
            'at' => $cancelMeta['canceled_at'],
            'detail' => $reason !== '' ? $reason : ('Canceled via ' . $source),
            'actor_label' => $cancelMeta['canceled_by'] ?? ($source === 'customer' ? 'Customer' : 'Admin'),
            'actor_id' => $cancelMeta['canceled_by_id'] ?? null,
            'actor_email' => $cancelMeta['canceled_by_email'] ?? null,
            'source' => $source,
        ];
        $cancelMeta['fulfillment_activity'] = $activity;

        $updated = $this->orders->update($orderId, array_merge($cancelMeta, [
            'status' => 'canceled',
        ]));

        $this->fireOrderCanceled($updated ?? $order, [
            'reason' => $reason,
            'source' => $source,
            'refund' => $refundRecord,
            'registrations_canceled' => count($regsCanceled),
            'tokens_revoked' => count($tokensRevoked),
        ]);

        return [
            'ok' => true,
            'canceled' => true,
            'order' => $updated,
            'refund' => $refundRecord,
        ];
    }

    /**
     * Customer self-service cancel (policy-gated).
     *
     * @return array{ok: bool, error?: string, order?: array, refund?: array|null}
     */
    public function customerCancelOrder(string $email, string $orderRef, string $reason = ''): array
    {
        $policy = self::customerCancelPolicy();
        if (!$policy['enabled']) {
            return ['ok' => false, 'error' => 'Customer order cancel is not enabled'];
        }
        $found = $this->findOrderForCustomer($email, $orderRef);
        if (!($found['ok'] ?? false)) {
            return $found;
        }
        /** @var array<string, mixed> $order */
        $order = $found['order'];
        $eligibility = $this->customerCancelEligibility($order, $policy);
        if (!($eligibility['ok'] ?? false)) {
            return ['ok' => false, 'error' => $eligibility['error'] ?? 'Order cannot be canceled'];
        }
        return $this->cancelOrder((string) $order['id'], [
            'refund' => true,
            'reason' => $reason !== '' ? $reason : 'Customer canceled',
            'source' => 'customer',
            'actor' => [
                'label' => 'Customer',
                'email' => strtolower(trim($email)),
                'name' => 'Customer',
            ],
        ]);
    }

    /**
     * Public order lookup for status / cancel UI (email + order number or id).
     *
     * @return array{ok: bool, error?: string, order?: array<string, mixed>}
     */
    public function lookupOrderForCustomer(string $email, string $orderRef): array
    {
        $found = $this->findOrderForCustomer($email, $orderRef);
        if (!($found['ok'] ?? false)) {
            return $found;
        }
        /** @var array<string, mixed> $order */
        $order = $found['order'];
        $policy = self::customerCancelPolicy();
        $eligibility = $this->customerCancelEligibility($order, $policy);
        return [
            'ok' => true,
            'order' => $this->publicOrderSummary($order, $eligibility),
        ];
    }

    /**
     * @return array{enabled: bool, window_hours: int}
     */
    public static function customerCancelPolicy(): array
    {
        if (isset($GLOBALS['commerce_test_settings']) && is_array($GLOBALS['commerce_test_settings'])) {
            $s = $GLOBALS['commerce_test_settings'];
            return [
                'enabled' => !empty($s['commerce_customer_cancel_enabled']),
                'window_hours' => max(0, (int) ($s['commerce_customer_cancel_window_hours'] ?? 24)),
            ];
        }
        $enabled = false;
        $hours = 24;
        if (function_exists('commerce_get_setting')) {
            $enabled = (bool) commerce_get_setting('commerce_customer_cancel_enabled', false);
            $hours = max(0, (int) commerce_get_setting('commerce_customer_cancel_window_hours', 24));
        }
        return ['enabled' => $enabled, 'window_hours' => $hours];
    }

    /**
     * @param array{enabled: bool, window_hours: int} $policy
     * @return array{ok: bool, error?: string, can_cancel?: bool}
     */
    private function customerCancelEligibility(array $order, array $policy): array
    {
        if (!$policy['enabled']) {
            return ['ok' => false, 'can_cancel' => false, 'error' => 'Customer order cancel is not enabled'];
        }
        $status = (string) ($order['status'] ?? '');
        if ($status === 'canceled') {
            return ['ok' => false, 'can_cancel' => false, 'error' => 'Order is already canceled'];
        }
        if (!in_array($status, ['paid', 'partially_refunded', 'pending'], true)) {
            return ['ok' => false, 'can_cancel' => false, 'error' => 'Order cannot be canceled'];
        }
        if (!class_exists('CommerceOrderOps')) {
            require_once __DIR__ . '/CommerceOrderOps.php';
        }
        if (CommerceOrderOps::orderHasShipmentProgress($order)) {
            return ['ok' => false, 'can_cancel' => false, 'error' => 'Order has already been shipped'];
        }
        $window = (int) ($policy['window_hours'] ?? 0);
        if ($window > 0) {
            $anchor = (string) ($order['paid_at'] ?? $order['created_at'] ?? '');
            $ts = $anchor !== '' ? strtotime($anchor) : false;
            if ($ts !== false && (time() - $ts) > ($window * 3600)) {
                return ['ok' => false, 'can_cancel' => false, 'error' => 'Cancel window has expired'];
            }
        }
        return ['ok' => true, 'can_cancel' => true];
    }

    /**
     * @return array{ok: bool, error?: string, order?: array<string, mixed>}
     */
    private function findOrderForCustomer(string $email, string $orderRef): array
    {
        $email = strtolower(trim($email));
        $orderRef = trim($orderRef);
        if ($email === '' || $orderRef === '') {
            return ['ok' => false, 'error' => 'Email and order number are required'];
        }
        $order = $this->orders->get($orderRef);
        if (!$order) {
            $order = $this->orders->findByOrderNumber($orderRef);
        }
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        $orderEmail = strtolower(trim((string) ($order['customer_email'] ?? '')));
        if ($orderEmail === '' || !hash_equals($orderEmail, $email)) {
            return ['ok' => false, 'error' => 'Order not found'];
        }
        return ['ok' => true, 'order' => $order];
    }

    /**
     * @param array{ok?: bool, can_cancel?: bool, error?: string} $eligibility
     * @return array<string, mixed>
     */
    private function publicOrderSummary(array $order, array $eligibility): array
    {
        $lines = [];
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            if (!is_array($line)) {
                continue;
            }
            $lines[] = [
                'title' => $line['title'] ?? 'Item',
                'quantity' => (int) ($line['quantity'] ?? 1),
                'fulfillment' => $line['fulfillment'] ?? null,
            ];
        }
        return [
            'id' => $order['id'] ?? '',
            'order_number' => $order['order_number'] ?? '',
            'status' => $order['status'] ?? '',
            'currency' => $order['currency'] ?? 'eur',
            'total_cents' => (int) ($order['total_cents'] ?? 0),
            'refunded_cents' => (int) ($order['refunded_cents'] ?? 0),
            'created_at' => $order['created_at'] ?? null,
            'paid_at' => $order['paid_at'] ?? null,
            'canceled_at' => $order['canceled_at'] ?? null,
            'fulfillment_status' => $order['fulfillment_status'] ?? null,
            'lines' => $lines,
            'can_cancel' => !empty($eligibility['can_cancel']),
            'cancel_blocked_reason' => empty($eligibility['can_cancel']) ? ($eligibility['error'] ?? null) : null,
        ];
    }

    private function fireOrderCanceled(array $order, array $extra = []): void
    {
        $ctx = array_merge($this->buildOrderPayload($order), [
            'cancel_reason' => $extra['reason'] ?? ($order['cancel_reason'] ?? ''),
            'cancel_source' => $extra['source'] ?? ($order['cancel_source'] ?? 'admin'),
            'cancel_refunded' => !empty($extra['refund']) || !empty($order['cancel_refunded']),
            'registrations_canceled' => (int) ($extra['registrations_canceled'] ?? 0),
            'tokens_revoked' => (int) ($extra['tokens_revoked'] ?? 0),
        ]);
        if (function_exists('broadcast_event')) {
            broadcast_event('commerce_order_canceled', $ctx, 'commerce');
        }
        if (function_exists('enqueue_automation')) {
            enqueue_automation('commerce_order_canceled', $ctx);
        }
        $this->sendTransactionalEmail('order_canceled', [
            'order' => $order,
            'cancel_reason' => $ctx['cancel_reason'] ?? '',
        ]);
        try {
            if (!class_exists('CommerceEmailService')) {
                require_once __DIR__ . '/CommerceEmailService.php';
            }
            $dataDir = dirname($this->orders->getDataDir());
            (new CommerceEmailService($dataDir))->cancelScheduledForOrder((string) ($order['id'] ?? ''), 'order_canceled');
        } catch (Throwable $e) {
            error_log('Commerce cancel scheduled emails failed: ' . $e->getMessage());
        }
    }

    /**
     * Refund an order (full, partial, or per line) via the commerce shelf.
     *
     * @param int|null $amountCents Null = refund the full remaining balance (or the line remainder when $lineId is set).
     * @return array{ok: bool, error?: string, order?: array, refund?: array}
     */
    public function refundOrder(string $orderId, ?int $amountCents = null, string $reason = '', ?string $lineId = null): array
    {
        $order = $this->orders->get($orderId);
        if (!$order) {
            return ['ok' => false, 'error' => 'Order not found'];
        }

        $status = $order['status'] ?? '';
        if (!in_array($status, ['paid', 'partially_refunded'], true)) {
            return ['ok' => false, 'error' => 'Order is not refundable (status: ' . ($status ?: 'unknown') . ')'];
        }

        $paymentId = (string) ($order['payment_id'] ?? '');
        $provider = (string) ($order['provider'] ?? '');
        if ($paymentId === '' || $provider === '') {
            return ['ok' => false, 'error' => 'Order has no captured payment to refund'];
        }

        $order = $this->normalizeOrderPaymentReference($order, $paymentId);
        $paymentId = $this->resolveRefundablePaymentId($order);
        if ($paymentId === '') {
            return ['ok' => false, 'error' => 'Order has no captured payment to refund'];
        }

        $total = (int) ($order['total_cents'] ?? 0);
        $alreadyRefunded = (int) ($order['refunded_cents'] ?? 0);
        $remaining = max(0, $total - $alreadyRefunded);
        if ($remaining <= 0) {
            return ['ok' => false, 'error' => 'Order is already fully refunded'];
        }

        $lines = is_array($order['lines'] ?? null) ? $order['lines'] : [];
        $targetLineIndex = null;
        $lineRemaining = null;
        if ($lineId !== null && $lineId !== '') {
            foreach ($lines as $idx => $line) {
                if (($line['line_id'] ?? '') === $lineId) {
                    $targetLineIndex = $idx;
                    $lineTotal = (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
                    $lineRefunded = (int) ($line['refunded_cents'] ?? 0);
                    $lineRemaining = max(0, $lineTotal - $lineRefunded);
                    break;
                }
            }
            if ($targetLineIndex === null) {
                return ['ok' => false, 'error' => 'Line item not found on order'];
            }
            if ($lineRemaining <= 0) {
                return ['ok' => false, 'error' => 'Line item is already fully refunded'];
            }
        }

        $refundAmount = $amountCents === null
            ? ($lineRemaining !== null ? $lineRemaining : $remaining)
            : (int) $amountCents;
        if ($refundAmount <= 0) {
            return ['ok' => false, 'error' => 'Refund amount must be greater than zero'];
        }
        if ($refundAmount > $remaining) {
            return ['ok' => false, 'error' => 'Refund amount exceeds remaining balance'];
        }
        if ($lineRemaining !== null && $refundAmount > $lineRemaining) {
            return ['ok' => false, 'error' => 'Refund amount exceeds remaining balance for this line'];
        }

        $shelf = $this->getShelf();
        if (!$shelf) {
            return ['ok' => false, 'error' => 'Payments not configured'];
        }

        $isFullOrder = $refundAmount >= $remaining;
        $result = $shelf->refundPayment($provider, $paymentId, $isFullOrder ? null : $refundAmount, [
            'source_plugin' => 'commerce',
            'source_ref' => $orderId,
            'connection_id' => $order['payment_connection_id'] ?? null,
            'payment_id' => $paymentId,
        ]);

        if (!($result['ok'] ?? false)) {
            return ['ok' => false, 'error' => $this->stringifyProviderError($result['error'] ?? 'Refund failed')];
        }

        $refundRecord = [
            'amount_cents' => $refundAmount,
            'reason' => trim($reason),
            'provider' => $provider,
            'refund_id' => $result['refund_id'] ?? ($result['payment_id'] ?? null),
            'line_id' => $lineId ?: null,
            'created_at' => date('c'),
        ];

        $refunds = $order['refunds'] ?? [];
        $refunds[] = $refundRecord;
        $newRefunded = $alreadyRefunded + $refundAmount;
        $newStatus = $newRefunded >= $total ? 'refunded' : 'partially_refunded';

        if ($targetLineIndex !== null) {
            $lines[$targetLineIndex]['refunded_cents'] = (int) ($lines[$targetLineIndex]['refunded_cents'] ?? 0) + $refundAmount;
        }

        $updated = $this->orders->update($orderId, [
            'lines' => $lines,
            'refunds' => $refunds,
            'refunded_cents' => $newRefunded,
            'status' => $newStatus,
        ]);

        if ($isFullOrder) {
            foreach ($order['lines'] ?? [] as $line) {
                $this->restoreLineStock($line);
            }
        } elseif ($targetLineIndex !== null) {
            $line = $lines[$targetLineIndex];
            $lineTotal = (int) ($line['line_total_cents'] ?? $line['effective_amount_cents'] ?? 0);
            if ((int) ($line['refunded_cents'] ?? 0) >= $lineTotal && $lineTotal > 0) {
                $this->restoreLineStock($line);
            }
        }

        $this->fireOrderRefunded($updated ?? $order, $refundRecord);

        return ['ok' => true, 'order' => $updated, 'refund' => $refundRecord];
    }

    private function fireOrderRefunded(array $order, array $refund): void
    {
        $ctx = array_merge($this->buildOrderPayload($order), [
            'refund_amount_cents' => $refund['amount_cents'] ?? 0,
            'refund_reason' => $refund['reason'] ?? '',
            'refunded_cents' => (int) ($order['refunded_cents'] ?? 0),
        ]);
        if (function_exists('broadcast_event')) {
            broadcast_event('commerce_order_refunded', $ctx, 'commerce');
        }
        if (function_exists('enqueue_automation')) {
            enqueue_automation('commerce_order_refunded', $ctx);
        }
        $this->sendTransactionalEmail('order_refunded', [
            'order' => $order,
            'refund' => $refund,
            'refund_amount_cents' => $refund['amount_cents'] ?? 0,
            'refund_reason' => $refund['reason'] ?? '',
        ]);
    }

    /** @param list<array<string, mixed>>|mixed $allocations */
    private function allocationsIncludeFreeShipping($allocations): bool
    {
        if (!is_array($allocations)) {
            return false;
        }
        foreach ($allocations as $alloc) {
            if (!is_array($alloc)) {
                continue;
            }
            if (($alloc['value_type'] ?? '') === 'free_shipping' || ($alloc['code'] ?? '') === 'free_shipping') {
                return true;
            }
        }
        return false;
    }

    /**
     * Attach carrier + tracking to a shippable line (ships remaining qty for that line).
     *
     * @return array{ok: bool, error?: string, order?: array, shipment?: array}
     */
    public function updateShipment(
        string $orderId,
        string $lineId,
        string $trackingNumber,
        string $carrier = '',
        ?string $shippedAt = null,
        bool $notifyCustomer = false,
        int $packageCount = 1
    ): array {
        if (!class_exists('CommerceOrderOps')) {
            require_once __DIR__ . '/CommerceOrderOps.php';
        }
        $ops = new CommerceOrderOps($this->orders);
        return $ops->createShipment($orderId, [
            'line_id' => $lineId,
            'tracking_number' => $trackingNumber,
            'carrier' => $carrier,
            'shipped_at' => $shippedAt,
            'notify_customer' => $notifyCustomer,
            'package_count' => $packageCount,
        ]);
    }

    public function markFailedByPaymentId(string $paymentId): ?array
    {
        $order = $this->findOrderForPaymentId($paymentId);
        if (!$order) {
            return null;
        }
        if (!empty($order['stock_reservation_id'])) {
            $this->stockReservations()->release((string) $order['stock_reservation_id'], 'payment_failed');
        }
        return $this->orders->update($order['id'], ['status' => 'failed']);
    }

    private function appendUrlQueryParam(string $url, string $key, string $value): string
    {
        if ($url === '' || $key === '') {
            return $url;
        }
        $hash = '';
        $hashPos = strpos($url, '#');
        if ($hashPos !== false) {
            $hash = substr($url, $hashPos);
            $url = substr($url, 0, $hashPos);
        }
        $sep = strpos($url, '?') === false ? '?' : '&';
        return $url . $sep . rawurlencode($key) . '=' . rawurlencode($value) . $hash;
    }

    /**
     * Resolve a Commerce order from a provider payment id (cs_, pi_, etc.).
     */
    private function findOrderForPaymentId(string $paymentId): ?array
    {
        $paymentId = trim($paymentId);
        if ($paymentId === '') {
            return null;
        }
        $order = $this->orders->findByPaymentId($paymentId);
        if ($order) {
            return $order;
        }
        return $this->findOrderViaProviderPayment($paymentId);
    }

    /**
     * Stripe hosted Checkout stores cs_ on the order while webhooks may send pi_.
     */
    private function findOrderViaProviderPayment(string $paymentId): ?array
    {
        $shelf = $this->getShelf();
        if (!$shelf) {
            return null;
        }
        foreach (['stripe', 'mollie', 'paypal', 'square', 'razorpay', 'komoju', 'payssion', 'adyen'] as $provider) {
            $status = $shelf->getPaymentStatus($provider, $paymentId, ['payment_id' => $paymentId]);
            if (!($status['ok'] ?? false)) {
                continue;
            }
            $raw = is_array($status['raw'] ?? null) ? $status['raw'] : [];
            $meta = is_array($raw['metadata'] ?? null) ? $raw['metadata'] : [];
            $orderId = trim((string) (
                $meta['order_id']
                ?? $raw['client_reference_id']
                ?? ''
            ));
            if ($orderId === '') {
                continue;
            }
            $order = $this->orders->get($orderId);
            if (!$order) {
                continue;
            }
            $order = $this->normalizeOrderPaymentReference($order, $paymentId);
            return $order;
        }
        return null;
    }

    /**
     * Hosted Checkout stores cs_ on the order; refunds and webhooks need pi_ while
     * storefront confirm still looks up by session id.
     *
     * @param array<string, mixed> $order
     * @return array<string, mixed>
     */
    private function normalizeOrderPaymentReference(array $order, string $incomingPaymentId): array
    {
        $orderId = (string) ($order['id'] ?? '');
        if ($orderId === '') {
            return $order;
        }

        $current = trim((string) ($order['payment_id'] ?? ''));
        $incoming = trim($incomingPaymentId);
        $sessionId = trim((string) ($order['stripe_checkout_session_id'] ?? ''));
        foreach ([$incoming, $current] as $candidate) {
            if (str_starts_with($candidate, 'cs_')) {
                $sessionId = $sessionId !== '' ? $sessionId : $candidate;
            }
        }

        $canonical = $incoming !== '' ? $incoming : $current;
        if (str_starts_with($canonical, 'cs_')) {
            $resolved = $this->resolveStripePaymentIntentId($canonical);
            if ($resolved !== null) {
                $canonical = $resolved;
            }
        } elseif (str_starts_with($current, 'cs_') && str_starts_with($incoming, 'pi_')) {
            $canonical = $incoming;
        }

        $patch = [];
        if ($sessionId !== '' && ($order['stripe_checkout_session_id'] ?? '') !== $sessionId) {
            $patch['stripe_checkout_session_id'] = $sessionId;
        }
        if ($canonical !== '' && $current !== $canonical) {
            $patch['payment_id'] = $canonical;
        }
        if ($patch === []) {
            return $order;
        }
        return $this->orders->update($orderId, $patch) ?? $order;
    }

    /**
     * @param array<string, mixed> $order
     */
    private function resolveRefundablePaymentId(array $order): string
    {
        $paymentId = trim((string) ($order['payment_id'] ?? ''));
        $sessionId = trim((string) ($order['stripe_checkout_session_id'] ?? ''));
        if ($paymentId === '' && $sessionId !== '') {
            $paymentId = $sessionId;
        }
        if (str_starts_with($paymentId, 'cs_')) {
            $normalized = $this->normalizeOrderPaymentReference($order, $paymentId);
            $resolved = trim((string) ($normalized['payment_id'] ?? ''));
            if ($resolved !== '' && !str_starts_with($resolved, 'cs_')) {
                return $resolved;
            }
        }
        return $paymentId;
    }

    private function stringifyProviderError(mixed $error): string
    {
        if (is_string($error)) {
            return $error;
        }
        if (is_array($error)) {
            if (!empty($error['message']) && is_string($error['message'])) {
                return $error['message'];
            }
            $encoded = json_encode($error, JSON_UNESCAPED_UNICODE);
            return is_string($encoded) && $encoded !== '' ? $encoded : 'Refund failed';
        }
        return 'Refund failed';
    }

    private function resolveStripePaymentIntentId(string $paymentId): ?string
    {
        $paymentId = trim($paymentId);
        if ($paymentId === '') {
            return null;
        }
        if (str_starts_with($paymentId, 'pi_')) {
            return $paymentId;
        }
        if (!str_starts_with($paymentId, 'cs_')) {
            return null;
        }
        $shelf = $this->getShelf();
        if (!$shelf) {
            return null;
        }
        $order = $this->findOrderForPaymentId($paymentId);
        $status = $shelf->getPaymentStatus('stripe', $paymentId, array_filter([
            'connection_id' => is_array($order) ? ($order['payment_connection_id'] ?? null) : null,
            'payment_id' => $paymentId,
        ]));
        if (!($status['ok'] ?? false)) {
            return null;
        }
        $raw = is_array($status['raw'] ?? null) ? $status['raw'] : [];
        $intent = $raw['payment_intent'] ?? null;
        if (is_string($intent) && str_starts_with($intent, 'pi_')) {
            return $intent;
        }
        if (is_array($intent) && is_string($intent['id'] ?? null) && str_starts_with((string) $intent['id'], 'pi_')) {
            return (string) $intent['id'];
        }
        return null;
    }

    /**
     * Fill missing customer_email from Stripe Checkout / PaymentIntent when available.
     *
     * @param array<string, mixed> $order
     * @return array<string, mixed>
     */
    private function enrichOrderFromPaymentProvider(array $order, string $paymentId): array
    {
        if (trim((string) ($order['customer_email'] ?? '')) !== '') {
            return $order;
        }
        $provider = (string) ($order['provider'] ?? '');
        $shelf = $this->getShelf();
        if ($provider === '' || !$shelf) {
            return $order;
        }
        $status = $shelf->getPaymentStatus($provider, $paymentId, array_filter([
            'connection_id' => $order['payment_connection_id'] ?? null,
            'payment_id' => $paymentId,
        ]));
        if (!($status['ok'] ?? false)) {
            return $order;
        }
        $raw = is_array($status['raw'] ?? null) ? $status['raw'] : [];
        $email = trim((string) (
            $raw['customer_details']['email']
            ?? $raw['customer_email']
            ?? $raw['receipt_email']
            ?? ''
        ));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $order;
        }
        $updated = $this->orders->update((string) ($order['id'] ?? ''), ['customer_email' => $email]);
        return $updated ?? $order;
    }

    private function fireOrderCreated(array $order): void
    {
        $ctx = ['order_id' => $order['id'], 'total_cents' => $order['total_cents']];
        if (function_exists('broadcast_event')) {
            broadcast_event('commerce_order_created', $ctx, 'commerce');
        }
        if (function_exists('enqueue_automation')) {
            enqueue_automation('commerce_order_created', $ctx);
        }
        if (class_exists('CommerceNotify')) {
            CommerceNotify::orderCreated($order);
        }
    }

    private function fireOrderPaid(array $order): void
    {
        $order = $this->maybeAutoIssueInvoice($order);

        $payload = $this->buildOrderPayload($order);

        if (function_exists('broadcast_event')) {
            broadcast_event('commerce_order_paid', $payload, 'commerce');
        }
        if (function_exists('enqueue_automation')) {
            // Core paid trigger plus dedicated order-email triggers (P8-D5).
            enqueue_automation('commerce_order_paid', $payload);
            enqueue_automation('commerce_order_receipt', $payload);
            enqueue_automation('commerce_order_admin_notify', $payload);
        }
        if (class_exists('CommerceNotify')) {
            CommerceNotify::orderPaid($order);
        }
        try {
            if (!class_exists('CommerceEntrySync')) {
                require_once __DIR__ . '/CommerceEntrySync.php';
            }
            $entrySync = CommerceEntrySync::syncFromPaidOrder($order);
            if (!($entrySync['ok'] ?? false) && empty($entrySync['skipped'])) {
                error_log('Commerce entry sync failed: ' . (string) ($entrySync['error'] ?? 'unknown'));
            }
        } catch (Throwable $e) {
            error_log('Commerce entry sync exception: ' . $e->getMessage());
        }
        $this->sendTransactionalEmail('order_paid', ['order' => $order]);
    }

    /**
     * @deprecated Use order_paid for paid receipts.
     *
     * @param array<string, mixed> $order
     */
    private function sendPaidReceiptEmail(array $order): void
    {
        $this->sendTransactionalEmail('order_paid', ['order' => $order]);
    }

    /**
     * @return array<string, mixed>
     */
    private function maybeAutoIssueInvoice(array $order): array
    {
        try {
            if (!class_exists('CommerceInvoiceService')) {
                require_once __DIR__ . '/CommerceInvoiceService.php';
            }
            $dataDir = dirname($this->orders->getDataDir());
            $invoice = new CommerceInvoiceService($dataDir, $this->orders);
            $profile = $invoice->getProfile();
            if (empty($profile['auto_issue_on_paid'])) {
                return $order;
            }
            $ensured = $invoice->ensureInvoice((string) ($order['id'] ?? ''));
            if (($ensured['ok'] ?? false) && is_array($ensured['order'] ?? null)) {
                return $ensured['order'];
            }
        } catch (Throwable $e) {
            error_log('Commerce invoice auto-issue failed: ' . $e->getMessage());
        }
        return $order;
    }

    /**
     * @param array<string, mixed> $context
     */
    private function sendTransactionalEmail(string $trigger, array $context): void
    {
        try {
            if (!class_exists('CommerceEmailService')) {
                require_once __DIR__ . '/CommerceEmailService.php';
            }
            $dataDir = dirname($this->orders->getDataDir());
            (new CommerceEmailService($dataDir))->sendForTrigger($trigger, $context);
        } catch (Throwable $e) {
            error_log('Commerce transactional email failed (' . $trigger . '): ' . $e->getMessage());
        }
    }

    /**
     * Build the automation/event payload for an order — includes line items,
     * totals, tax, and customer email so email triggers can render receipts.
     */
    private function buildOrderPayload(array $order): array
    {
        $lines = [];
        foreach ($order['lines'] ?? [] as $line) {
            $lines[] = [
                'title' => $line['title'] ?? ($line['entry_id'] ?? ''),
                'quantity' => (int) ($line['quantity'] ?? 1),
                'unit_price_cents' => (int) ($line['unit_price_cents'] ?? $line['effective_unit_cents'] ?? 0),
                'line_total_cents' => (int) ($line['line_total_cents'] ?? 0),
                'fulfillment' => $line['fulfillment'] ?? '',
            ];
        }

        $payload = [
            'order_id' => $order['id'] ?? '',
            'payment_id' => $order['payment_id'] ?? null,
            'provider' => $order['provider'] ?? null,
            'status' => $order['status'] ?? 'paid',
            'customer_email' => $order['customer_email'] ?? '',
            'currency' => $order['currency'] ?? 'eur',
            'subtotal_cents' => max(0, (int) ($order['total_cents'] ?? 0)
                - (int) ($order['tax_cents'] ?? 0) - (int) ($order['shipping_cents'] ?? 0)),
            'shipping_cents' => (int) ($order['shipping_cents'] ?? 0),
            'tax_cents' => (int) ($order['tax_cents'] ?? 0),
            'tax_rate' => (float) ($order['tax_rate'] ?? 0.0),
            'discount_cents' => (int) ($order['discount_cents'] ?? 0),
            'total_cents' => (int) ($order['total_cents'] ?? 0),
            'shipping_address' => $order['shipping_address'] ?? null,
            'lines' => $lines,
        ];

        $metadata = [];
        foreach (['metadata', 'entry_sync_meta', 'donor_meta'] as $metaKey) {
            if (!is_array($order[$metaKey] ?? null)) {
                continue;
            }
            foreach ($order[$metaKey] as $key => $value) {
                if (!is_string($key) || $key === '') {
                    continue;
                }
                $trimmed = trim((string) $value);
                if ($trimmed !== '') {
                    $metadata[$key] = $trimmed;
                }
            }
        }
        if ($metadata !== []) {
            $payload['metadata'] = $metadata;
            foreach (['signup_flow_id', 'signup_flow_session_id', 'signup_flow_opt_in', 'club_opt_in'] as $passthroughKey) {
                if (isset($metadata[$passthroughKey])) {
                    $payload[$passthroughKey] = $metadata[$passthroughKey];
                }
            }
        }

        return $payload;
    }

    private function containsRecurringLines(array $lines): bool
    {
        foreach ($lines as $line) {
            if (($line['billing'] ?? 'one_time') === 'recurring') {
                return true;
            }
            foreach ($line['components'] ?? [] as $component) {
                if (is_array($component) && ($component['billing'] ?? 'one_time') === 'recurring') {
                    return true;
                }
            }
        }
        return false;
    }

    private function reserveLineStock(array &$line): bool
    {
        $sku = trim((string) ($line['sku'] ?? ''));
        if ($sku !== '' && $this->warehouseStore()->tracksSku($sku)) {
            $warehouseId = $this->warehouseStore()->allocateWarehouse($sku, (int) ($line['quantity'] ?? 1));
            if ($warehouseId === null) {
                return false;
            }
            $line['warehouse_id'] = $warehouseId;
        }

        if (!$this->indexer->reserveQuantity(
            $line['collection_slug'] ?? '',
            $line['entry_id'] ?? '',
            (int) ($line['quantity'] ?? 1)
        )) {
            return false;
        }

        if (!empty($line['is_bundle'])) {
            foreach ($line['components'] ?? [] as $comp) {
                if (!$this->indexer->reserveQuantity(
                    $comp['collection'] ?? '',
                    $comp['entry_id'] ?? '',
                    (int) ($comp['quantity'] ?? 1)
                )) {
                    return false;
                }
            }
        }

        return true;
    }

    private function restoreLineStock(array $line): void
    {
        $sku = trim((string) ($line['sku'] ?? ''));
        if ($sku !== '') {
            $this->inventoryLedger()->incrementOnHand($sku, (int) ($line['quantity'] ?? 1), $line['warehouse_id'] ?? null);
        }

        if (!empty($line['is_bundle'])) {
            foreach ($line['components'] ?? [] as $comp) {
                $componentSku = trim((string) ($comp['sku'] ?? ''));
                if ($componentSku !== '') {
                    $this->inventoryLedger()->incrementOnHand($componentSku, (int) ($comp['quantity'] ?? 1), $comp['warehouse_id'] ?? null);
                }
            }
        }
    }

    private function decrementLineStock(array $line): void
    {
        $sku = trim((string) ($line['sku'] ?? ''));
        if ($sku !== '') {
            $this->inventoryLedger()->decrementOnHand($sku, (int) ($line['quantity'] ?? 1), $line['warehouse_id'] ?? null);
        }

        if (!empty($line['is_bundle'])) {
            foreach ($line['components'] ?? [] as $comp) {
                $componentSku = trim((string) ($comp['sku'] ?? ''));
                if ($componentSku !== '') {
                    $this->inventoryLedger()->decrementOnHand($componentSku, (int) ($comp['quantity'] ?? 1), $comp['warehouse_id'] ?? null);
                }
            }
        }
    }

    private function inventoryLedger(): InventoryLedger
    {
        if (!class_exists('InventoryLedger')) {
            require_once __DIR__ . '/InventoryLedger.php';
        }
        return new InventoryLedger(dirname($this->orders->getDataDir()), $this->indexer, $this->warehouseStore(), $this->stockReservations());
    }
}
