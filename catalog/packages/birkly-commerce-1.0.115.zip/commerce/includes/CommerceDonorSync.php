<?php
/**
 * @deprecated 1.0.97 Use CommerceEntrySync.
 */

declare(strict_types=1);

require_once __DIR__ . '/CommerceEntrySync.php';

/** @deprecated 1.0.97 Use CommerceEntrySync */
class CommerceDonorSync extends CommerceEntrySync
{
}
