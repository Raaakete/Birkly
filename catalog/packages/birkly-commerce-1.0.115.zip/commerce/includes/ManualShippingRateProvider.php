<?php
/**
 * Manual shipping rate provider — zone flat rates / weight tiers.
 */

require_once __DIR__ . '/ShippingRateProviderInterface.php';

class ManualShippingRateProvider implements ShippingRateProviderInterface
{
    private CommerceCatalog $catalog;

    public function __construct(CommerceCatalog $catalog)
    {
        $this->catalog = $catalog;
    }

    public function getId(): string
    {
        return 'manual';
    }

    public function getName(): string
    {
        return 'Manual zones';
    }

    /**
     * @param array<int, array<string, mixed>> $lines
     * @param array<string, mixed>|null $shippingAddress
     * @param array<string, mixed> $context
     */
    public function quote(array $lines, ?array $shippingAddress = null, array $context = []): array
    {
        if (!$this->catalog->cartHasShippableLines($lines)) {
            return [
                'ok' => true,
                'rates' => [],
                'shipping_lines' => [],
                'shipping_cents' => 0,
                'provider' => 'manual',
            ];
        }

        $shippingCents = $this->catalog->calculateShippingManualCents($lines, $shippingAddress);
        $country = strtoupper(trim((string) ($shippingAddress['country'] ?? '')));
        $basis = $shippingCents . '|' . $country . '|' . count($lines);
        $rateId = 'sl_' . substr(hash('sha256', $basis), 0, 12);
        $rate = [
            'id' => $rateId,
            'title' => 'Manual shipping',
            'code' => 'manual',
            'price_cents' => $shippingCents,
            'carrier' => 'manual',
            'service' => 'zone',
            'source' => 'manual_zones',
        ];

        if ($shippingCents <= 0) {
            return [
                'ok' => true,
                'rates' => [],
                'shipping_lines' => [],
                'shipping_cents' => 0,
                'provider' => 'manual',
            ];
        }

        return [
            'ok' => true,
            'rates' => [$rate],
            'shipping_lines' => [$rate],
            'shipping_cents' => $shippingCents,
            'provider' => 'manual',
        ];
    }
}
