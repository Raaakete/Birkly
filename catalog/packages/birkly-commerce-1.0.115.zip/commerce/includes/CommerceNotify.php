<?php
/**
 * Commerce → Birkly notification bridge.
 *
 * Writes security-log events that the admin notification bell reads.
 * Actor is always "commerce" so admins see shopper activity even when
 * they place a test order while logged in.
 */

class CommerceNotify
{
    public static function orderCreated(array $order): void
    {
        $currency = strtoupper((string) ($order['currency'] ?? 'eur'));
        $total = number_format(((int) ($order['total_cents'] ?? 0)) / 100, 2);
        $billing = ($order['billing_mode'] ?? 'one_time') === 'recurring' ? 'subscription order' : 'order';
        self::log('commerce_order_created', [
            'message' => 'New ' . $billing . ' ' . ($order['id'] ?? '') . ' — ' . $currency . ' ' . $total,
            'link' => self::adminLink('orders'),
            'order_id' => $order['id'] ?? null,
            'total_cents' => (int) ($order['total_cents'] ?? 0),
            'currency' => $order['currency'] ?? 'eur',
            'customer_email' => $order['customer_email'] ?? '',
            'billing_mode' => $order['billing_mode'] ?? 'one_time',
            'status' => $order['status'] ?? 'pending',
        ]);
    }

    public static function orderPaid(array $order): void
    {
        $currency = strtoupper((string) ($order['currency'] ?? 'eur'));
        $total = number_format(((int) ($order['total_cents'] ?? 0)) / 100, 2);
        self::log('commerce_order_paid', [
            'message' => 'Order ' . ($order['id'] ?? '') . ' paid — ' . $currency . ' ' . $total,
            'link' => self::adminLink('orders'),
            'order_id' => $order['id'] ?? null,
            'total_cents' => (int) ($order['total_cents'] ?? 0),
            'currency' => $order['currency'] ?? 'eur',
            'customer_email' => $order['customer_email'] ?? '',
            'billing_mode' => $order['billing_mode'] ?? 'one_time',
        ]);
    }

    public static function subscriptionCreated(array $subscription): void
    {
        $currency = strtoupper((string) ($subscription['currency'] ?? 'eur'));
        $amount = number_format(((int) ($subscription['amount_cents'] ?? 0)) / 100, 2);
        $interval = (string) ($subscription['interval'] ?? 'month');
        self::log('commerce_subscription_created', [
            'message' => 'New subscription ' . ($subscription['id'] ?? '') . ' — ' . $currency . ' ' . $amount . '/' . $interval,
            'link' => self::adminLink('subscriptions'),
            'subscription_id' => $subscription['id'] ?? null,
            'order_id' => $subscription['order_id'] ?? null,
            'amount_cents' => (int) ($subscription['amount_cents'] ?? 0),
            'currency' => $subscription['currency'] ?? 'eur',
            'interval' => $interval,
            'customer_email' => $subscription['customer_email'] ?? '',
        ]);
    }

    public static function shipmentCreated(array $order, array $shipment, bool $notifyCustomer = false): void
    {
        $tracking = trim((string) ($shipment['tracking_number'] ?? ''));
        $carrier = trim((string) ($shipment['carrier'] ?? ''));
        $pkg = max(1, (int) ($shipment['package_count'] ?? 1));
        $label = trim($carrier . ' ' . $tracking);
        if ($label === '') {
            $label = (string) ($shipment['id'] ?? 'shipment');
        }
        self::log('commerce_shipment_created', [
            'message' => 'Shipment for order ' . ($order['order_number'] ?? $order['id'] ?? '')
                . ' — ' . $label . ($pkg > 1 ? (' · ' . $pkg . ' packages') : '')
                . ($notifyCustomer ? ' · customer notified' : ''),
            'link' => self::adminLink('orders'),
            'order_id' => $order['id'] ?? null,
            'shipment_id' => $shipment['id'] ?? null,
            'tracking_number' => $tracking,
            'carrier' => $carrier,
            'package_count' => $pkg,
            'customer_email' => $order['customer_email'] ?? '',
            'notify_customer' => $notifyCustomer,
            'fulfillment_status' => $order['fulfillment_status'] ?? null,
        ]);
    }

    private static function adminLink(string $hash = 'orders'): string
    {
        if (function_exists('birkly_admin_url')) {
            return birkly_admin_url('commerce') . '#' . $hash;
        }

        return '/admin/?page=commerce#' . $hash;
    }

    /**
     * @return list<string>
     */
    private static function cmsRootCandidates(): array
    {
        $roots = [];
        if (function_exists('commerce_cms_root')) {
            $roots[] = (string) commerce_cms_root();
        }
        if (defined('BIRKLY_ROOT') && is_string(BIRKLY_ROOT)) {
            $roots[] = BIRKLY_ROOT;
        }
        if (function_exists('birkly_project_root')) {
            $roots[] = (string) birkly_project_root();
        }
        // includes/ → commerce → plugins → cms root
        $roots[] = dirname(__DIR__, 3);
        // includes/ → commerce → data/plugins-style layouts sometimes nest deeper
        $roots[] = dirname(__DIR__, 4);

        $out = [];
        foreach ($roots as $root) {
            $root = rtrim((string) $root, '/');
            if ($root !== '' && !in_array($root, $out, true)) {
                $out[] = $root;
            }
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $details
     */
    private static function log(string $event, array $details): void
    {
        $cmsRoots = self::cmsRootCandidates();
        $cmsRoot = $cmsRoots[0] ?? dirname(__DIR__, 3);
        $logDir = rtrim((string) $cmsRoot, '/') . '/logs';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0700, true);
        }

        $entry = [
            'timestamp' => date('c'),
            'user' => 'commerce',
            'event' => $event,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'details' => $details,
        ];
        @file_put_contents(
            $logDir . '/security.log',
            json_encode($entry, JSON_UNESCAPED_UNICODE) . "\n",
            FILE_APPEND | LOCK_EX
        );

        // P61: plugin activity bus (bell + sidebar mint dot)
        if (!function_exists('birkly_plugin_activity_emit')) {
            foreach ($cmsRoots as $root) {
                $activityPhp = $root . '/core/plugin_activity.php';
                if (!is_file($activityPhp)) {
                    continue;
                }
                require_once $activityPhp;
                if (function_exists('birkly_plugin_activity_emit')) {
                    break;
                }
            }
        }
        if (function_exists('birkly_plugin_activity_emit')) {
            $meta = $details;
            unset($meta['message'], $meta['link']);
            birkly_plugin_activity_emit([
                'plugin' => 'commerce',
                'event' => $event,
                'title' => (string) ($details['message'] ?? $event),
                'body' => '',
                'link' => (string) ($details['link'] ?? self::adminLink('orders')),
                'notify' => true,
                'nav_attention' => true,
                'meta' => $meta,
            ]);
        }

        // Also use the core helper when available (keeps audit tooling consistent).
        if (!function_exists('log_security_event')) {
            $logPhp = rtrim((string) $cmsRoot, '/') . '/api/log.php';
            if (is_file($logPhp)) {
                require_once $logPhp;
            }
        }
        if (function_exists('log_security_event')) {
            try {
                $ref = new ReflectionFunction('log_security_event');
                if ($ref->getNumberOfParameters() >= 3) {
                    // Skip duplicate write when core can set actor=commerce.
                    // Direct write above already landed; avoid double-notify.
                    return;
                }
            } catch (Throwable $e) {
                // ignore
            }
        }
    }
}
