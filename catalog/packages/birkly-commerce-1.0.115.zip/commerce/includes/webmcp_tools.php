<?php
/**
 * Commerce WebMCP catalog — visitor tools on the public storefront.
 *
 * This is NOT inbound Birkly MCP (`register_plugin_mcp_tools` / docs/mcp_tools.php).
 * WebMCP tools are registered with `birkly_webmcp_register_tools()` so they appear
 * in Discovery → WebMCP and can be enabled for the live public site.
 *
 * Runtime handlers live in `assets/webmcp-pack.js` (registered via
 * `includes/webmcp_runtime.php`) and call `window.BirklyCommerce`.
 */

declare(strict_types=1);

/**
 * @return list<array{id:string,kind:string,mutating:bool,consent:string,default:bool,label:string,description:string}>
 */
function commerce_webmcp_tool_catalog(): array
{
    return [
        [
            'id' => 'birkly_commerce_get_cart',
            'kind' => 'read',
            'mutating' => false,
            'consent' => 'none',
            'default' => false,
            'label' => 'Read the cart',
            'description' => 'Lets an AI helper see what’s in the shopping cart.',
        ],
        [
            'id' => 'birkly_commerce_add_to_cart',
            'kind' => 'write',
            'mutating' => true,
            'consent' => 'confirm',
            'default' => false,
            'label' => 'Add to cart',
            'description' => 'Lets an AI helper add a product to the cart — after the visitor confirms.',
        ],
        [
            'id' => 'birkly_commerce_checkout',
            'kind' => 'write',
            'mutating' => true,
            'consent' => 'pay',
            'default' => false,
            'label' => 'Start checkout',
            'description' => 'Lets an AI helper begin checkout. Paying always asks the visitor to confirm.',
        ],
    ];
}
