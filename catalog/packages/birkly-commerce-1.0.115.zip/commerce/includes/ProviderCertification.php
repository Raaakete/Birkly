<?php
/**
 * Marketplace v1 certification matrix for Commerce payment providers.
 */

class ProviderCertification
{
    /** @return array<string, array<string, mixed>> */
    public static function matrix(): array
    {
        return [
            'stripe' => [
                'provider' => 'stripe',
                'name' => 'Stripe',
                'status' => 'certified_v1',
                'live_mode' => true,
                'test_mode' => true,
                'certified_features' => ['one_time_payments', 'refunds', 'webhooks'],
                'blocked_features' => ['subscriptions'],
                'notes' => 'Marketplace v1 live-certified for one-time card payments, refunds, and signed webhooks. Recurring remains gated globally.',
            ],
            'mollie' => [
                'provider' => 'mollie',
                'name' => 'Mollie',
                'status' => 'certified_v1',
                'live_mode' => true,
                'test_mode' => true,
                'certified_features' => ['one_time_payments', 'refunds', 'webhooks'],
                'blocked_features' => ['subscriptions', 'separate_capture'],
                'notes' => 'Marketplace v1 live-certified for one-time hosted payments, refunds, and signed webhooks. Recurring remains gated globally.',
            ],
            'paypal' => [
                'provider' => 'paypal',
                'name' => 'PayPal',
                'status' => 'sandbox_only',
                'live_mode' => false,
                'test_mode' => true,
                'certified_features' => ['test_connection', 'sandbox_payments'],
                'blocked_features' => ['live_payments', 'subscriptions'],
                'notes' => 'Sandbox capture/refund flow implemented. Live checkout remains gated until certification completes.',
            ],
            'adyen' => [
                'provider' => 'adyen',
                'name' => 'Adyen',
                'status' => 'sandbox_only',
                'live_mode' => false,
                'test_mode' => true,
                'certified_features' => ['test_connection', 'sandbox_payments'],
                'blocked_features' => ['live_payments'],
                'notes' => 'Adapter exists but live credentials/webhook flow is not certified for Marketplace v1.',
            ],
            'square' => [
                'provider' => 'square',
                'name' => 'Square',
                'status' => 'sandbox_only',
                'live_mode' => false,
                'test_mode' => true,
                'certified_features' => ['test_connection', 'sandbox_payments'],
                'blocked_features' => ['live_payments'],
                'notes' => 'Adapter exists but live credentials/webhook flow is not certified for Marketplace v1.',
            ],
            'razorpay' => [
                'provider' => 'razorpay',
                'name' => 'Razorpay',
                'status' => 'sandbox_only',
                'live_mode' => false,
                'test_mode' => true,
                'certified_features' => ['test_connection', 'sandbox_payments'],
                'blocked_features' => ['live_payments'],
                'notes' => 'Adapter exists but live credentials/webhook flow is not certified for Marketplace v1.',
            ],
            'komoju' => [
                'provider' => 'komoju',
                'name' => 'Komoju',
                'status' => 'sandbox_only',
                'live_mode' => false,
                'test_mode' => true,
                'certified_features' => ['test_connection', 'sandbox_payments'],
                'blocked_features' => ['live_payments'],
                'notes' => 'Adapter exists but live credentials/webhook flow is not certified for Marketplace v1.',
            ],
            'payssion' => [
                'provider' => 'payssion',
                'name' => 'Payssion',
                'status' => 'sandbox_only',
                'live_mode' => false,
                'test_mode' => true,
                'certified_features' => ['test_connection', 'sandbox_payments'],
                'blocked_features' => ['live_payments'],
                'notes' => 'Adapter exists but live credentials/webhook flow is not certified for Marketplace v1.',
            ],
        ];
    }

    /** @return array<string, mixed> */
    public static function forProvider(string $providerId): array
    {
        $providerId = strtolower(trim($providerId));
        $matrix = self::matrix();

        return $matrix[$providerId] ?? [
            'provider' => $providerId,
            'name' => $providerId,
            'status' => 'uncertified',
            'live_mode' => false,
            'test_mode' => false,
            'certified_features' => [],
            'blocked_features' => ['live_payments', 'test_payments'],
            'notes' => 'Provider is not in the Marketplace v1 certification matrix.',
        ];
    }

    public static function isLiveCertified(string $providerId): bool
    {
        return (bool) (self::forProvider($providerId)['live_mode'] ?? false);
    }

    public static function isConnectionUsable(array $connection): bool
    {
        $provider = (string) ($connection['provider'] ?? '');
        $mode = strtolower((string) ($connection['mode'] ?? 'test'));
        if ($mode === 'live') {
            return self::isLiveCertified($provider);
        }

        return (bool) (self::forProvider($provider)['test_mode'] ?? false);
    }

    /** @return array{ok: bool, error?: string} */
    public static function validateConnection(array $connection): array
    {
        $provider = (string) ($connection['provider'] ?? '');
        $mode = strtolower((string) ($connection['mode'] ?? 'test'));
        $enabled = (bool) ($connection['enabled'] ?? true);
        if ($enabled && $mode === 'live' && !self::isLiveCertified($provider)) {
            $name = self::forProvider($provider)['name'] ?? $provider;
            return [
                'ok' => false,
                'error' => $name . ' is not live-certified for Marketplace v1. Use test mode or choose a certified live provider.',
            ];
        }

        return ['ok' => true];
    }

    /** @param array<string, mixed> $provider */
    public static function annotateProvider(array $provider): array
    {
        $provider['certification'] = self::forProvider((string) ($provider['id'] ?? ''));
        return $provider;
    }

    /** @param array<string, mixed> $connection */
    public static function annotateConnection(array $connection): array
    {
        $connection['certification'] = self::forProvider((string) ($connection['provider'] ?? ''));
        $connection['live_mode_allowed'] = self::isLiveCertified((string) ($connection['provider'] ?? ''));
        $connection['usable_for_checkout'] = self::isConnectionUsable($connection);
        return $connection;
    }
}
