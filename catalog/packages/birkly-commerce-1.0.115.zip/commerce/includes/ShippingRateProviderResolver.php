<?php
/**
 * Resolves the active shipping rate provider from settings.
 *
 * Setting: commerce_shipping_rate_provider = manual | easypost
 * Also persisted on shipping_zones.json as provider.
 */

require_once __DIR__ . '/ShippingRateProviderInterface.php';
require_once __DIR__ . '/ManualShippingRateProvider.php';
require_once __DIR__ . '/EasyPostShippingRateProvider.php';

class ShippingRateProviderResolver
{
    public const PROVIDER_MANUAL = 'manual';
    public const PROVIDER_EASYPOST = 'easypost';

    private CommerceCatalog $catalog;

    /** @var array<string, ShippingRateProviderInterface> */
    private array $providers = [];

    public function __construct(CommerceCatalog $catalog)
    {
        $this->catalog = $catalog;
        $this->providers[self::PROVIDER_MANUAL] = new ManualShippingRateProvider($catalog);
        $this->providers[self::PROVIDER_EASYPOST] = new EasyPostShippingRateProvider($catalog);
    }

    public function register(ShippingRateProviderInterface $provider): void
    {
        $this->providers[$provider->getId()] = $provider;
    }

    public function get(string $providerId): ?ShippingRateProviderInterface
    {
        return $this->providers[$providerId] ?? null;
    }

    /** @return array<string, ShippingRateProviderInterface> */
    public function all(): array
    {
        return $this->providers;
    }

    /**
     * @return array<int, array{id: string, name: string}>
     */
    public function listProviders(): array
    {
        $out = [];
        foreach ($this->providers as $provider) {
            $out[] = [
                'id' => $provider->getId(),
                'name' => $provider->getName(),
            ];
        }
        return $out;
    }

    public function getProviderId(): string
    {
        $fromSetting = null;
        if (function_exists('commerce_get_setting')) {
            $fromSetting = commerce_get_setting('commerce_shipping_rate_provider', null);
        } elseif (function_exists('get_plugin_setting')) {
            $fromSetting = get_plugin_setting('commerce', 'commerce_shipping_rate_provider', null);
        }
        if ($this->isValidProviderId($fromSetting)) {
            return (string) $fromSetting;
        }

        $config = $this->catalog->loadShippingZones();
        $fromConfig = $config['provider'] ?? self::PROVIDER_MANUAL;
        if ($this->isValidProviderId($fromConfig)) {
            return (string) $fromConfig;
        }

        return self::PROVIDER_MANUAL;
    }

    public function resolve(?string $providerId = null): ShippingRateProviderInterface
    {
        $id = $this->isValidProviderId($providerId) ? (string) $providerId : $this->getProviderId();
        return $this->providers[$id] ?? $this->providers[self::PROVIDER_MANUAL];
    }

    public static function normalizeProviderId($providerId): string
    {
        $id = strtolower(trim((string) ($providerId ?? '')));
        return in_array($id, [self::PROVIDER_MANUAL, self::PROVIDER_EASYPOST], true)
            ? $id
            : self::PROVIDER_MANUAL;
    }

    private function isValidProviderId($providerId): bool
    {
        return is_string($providerId) && isset($this->providers[$providerId]);
    }
}
