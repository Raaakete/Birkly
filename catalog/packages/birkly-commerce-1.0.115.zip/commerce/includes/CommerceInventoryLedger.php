<?php
/**
 * Shared inventory ledger factory for HTTP API and MCP admin dispatch.
 */

declare(strict_types=1);

if (!function_exists('commerce_inventory_ledger')) {
    function commerce_inventory_ledger(CatalogIndexer $indexer): InventoryLedger
    {
        $warehouse = new WarehouseStockStore();
        $reservations = new StockReservationStore(commerce_data_dir(), $indexer, $warehouse);
        return new InventoryLedger(commerce_data_dir(), $indexer, $warehouse, $reservations);
    }
}
