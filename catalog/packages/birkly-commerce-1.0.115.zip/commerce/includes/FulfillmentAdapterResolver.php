<?php
/**
 * Resolve the active physical fulfillment adapter (Manual | EasyPost).
 * ShipStation remains an internal stub and is never offered.
 */

require_once __DIR__ . '/FulfillmentAdapterInterface.php';
require_once __DIR__ . '/ManualFulfillmentAdapter.php';
require_once __DIR__ . '/EasyPostFulfillmentAdapter.php';

class FulfillmentAdapterResolver
{
    public const PROVIDER_MANUAL = 'manual';
    public const PROVIDER_EASYPOST = 'easypost';

    /** @var string|null Test override for connections JSON path */
    public static ?string $connectionsFileOverride = null;

    /**
     * @return array{active_adapter: string, easypost?: array<string, mixed>}
     */
    public static function loadConnections(): array
    {
        $file = self::connectionsFile();
        $data = is_file($file) ? json_decode((string) file_get_contents($file), true) : [];
        if (!is_array($data)) {
            $data = [];
        }
        $adapter = self::normalizeAdapterId($data['active_adapter'] ?? self::PROVIDER_MANUAL);
        $data['active_adapter'] = $adapter;
        if (!isset($data['easypost']) || !is_array($data['easypost'])) {
            $data['easypost'] = [];
        }
        return $data;
    }

    /**
     * @param array<string, mixed> $data
     */
    public static function saveConnections(array $data): array
    {
        $normalized = self::loadConnections();
        $adapter = self::normalizeAdapterId($data['active_adapter'] ?? $normalized['active_adapter']);
        $normalized['active_adapter'] = $adapter;
        unset($normalized['shipstation'], $data['shipstation']);

        $ep = is_array($data['easypost'] ?? null) ? $data['easypost'] : [];
        $existingEp = is_array($normalized['easypost'] ?? null) ? $normalized['easypost'] : [];
        $secret = trim((string) ($ep['webhook_secret'] ?? ''));
        if ($secret === '' && !empty($existingEp['webhook_secret'])) {
            $secret = (string) $existingEp['webhook_secret'];
        }
        $normalized['easypost'] = [
            'webhook_secret' => $secret,
        ];

        $file = self::connectionsFile();
        $dir = dirname($file);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        file_put_contents($file, json_encode($normalized, JSON_PRETTY_PRINT));
        return $normalized;
    }

    public static function normalizeAdapterId($id): string
    {
        $id = strtolower(trim((string) ($id ?? '')));
        return in_array($id, [self::PROVIDER_MANUAL, self::PROVIDER_EASYPOST], true)
            ? $id
            : self::PROVIDER_MANUAL;
    }

    public static function getActiveAdapterId(): string
    {
        return self::loadConnections()['active_adapter'] ?? self::PROVIDER_MANUAL;
    }

    public static function resolve(?string $adapterId = null): FulfillmentAdapterInterface
    {
        $id = self::normalizeAdapterId($adapterId ?? self::getActiveAdapterId());
        if ($id === self::PROVIDER_EASYPOST) {
            return new EasyPostFulfillmentAdapter();
        }
        return new ManualFulfillmentAdapter();
    }

    /**
     * Merchant-selectable adapters (ShipStation intentionally omitted).
     *
     * @return list<array{id: string, name: string, certified: bool, configured: bool}>
     */
    public static function listAvailableAdapters(): array
    {
        $manual = new ManualFulfillmentAdapter();
        $easypost = new EasyPostFulfillmentAdapter();
        return [
            [
                'id' => $manual->getId(),
                'name' => $manual->getName(),
                'certified' => true,
                'configured' => $manual->isConfigured(),
            ],
            [
                'id' => $easypost->getId(),
                'name' => $easypost->getName(),
                'certified' => true,
                'configured' => $easypost->isConfigured(),
            ],
        ];
    }

    public static function connectionsFile(): string
    {
        if (self::$connectionsFileOverride !== null && self::$connectionsFileOverride !== '') {
            return self::$connectionsFileOverride;
        }
        if (function_exists('commerce_data_dir')) {
            return commerce_data_dir() . '/fulfillment_connections.json';
        }
        return sys_get_temp_dir() . '/commerce-fulfillment_connections.json';
    }

    /**
     * Resolve EasyPost API key from shipping settings / plugin setting.
     */
    public static function resolveEasyPostApiKey(): string
    {
        if (class_exists('CommerceCatalog')) {
            try {
                $catalog = new CommerceCatalog();
                $config = $catalog->loadShippingZones();
                $key = trim((string) ($config['easypost_api_key'] ?? ''));
                if ($key !== '') {
                    return $key;
                }
            } catch (Throwable $e) {
                // fall through
            }
        }
        if (function_exists('commerce_get_setting')) {
            $key = trim((string) commerce_get_setting('commerce_easypost_api_key', ''));
            if ($key !== '') {
                return $key;
            }
        } elseif (function_exists('get_plugin_setting')) {
            $key = trim((string) get_plugin_setting('commerce', 'commerce_easypost_api_key', ''));
            if ($key !== '') {
                return $key;
            }
        }
        return '';
    }

    public static function webhookUrl(): string
    {
        if (function_exists('commerce_cms_root')) {
            // Public inventory webhook router also accepts platform=easypost.
            $base = '';
            if (!empty($_SERVER['HTTP_HOST'])) {
                $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                $base = $scheme . '://' . $_SERVER['HTTP_HOST'];
            }
            return rtrim($base, '/') . '/api/index.php?route=commerce_inventory_webhook&platform=easypost';
        }
        return '/api/index.php?route=commerce_inventory_webhook&platform=easypost';
    }
}
