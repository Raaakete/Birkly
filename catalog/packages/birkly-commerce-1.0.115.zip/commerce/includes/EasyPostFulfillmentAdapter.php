<?php
/**
 * EasyPost live fulfillment adapter — create tracker/label and return tracking.
 *
 * Reuses EasyPost API key from Settings → Shipping when present.
 * Mock mode: COMMERCE_EASYPOST_MOCK=1, mock credentials, or missing key.
 */

require_once __DIR__ . '/FulfillmentAdapterInterface.php';

class EasyPostFulfillmentAdapter implements FulfillmentAdapterInterface
{
    private array $config;

    /** @var callable|null */
    private $httpOverride = null;

    /**
     * @param array<string, mixed>|null $config
     * @param callable|null $httpOverride
     */
    public function __construct(?array $config = null, $httpOverride = null)
    {
        if ($config !== null) {
            $this->config = $config;
        } else {
            $this->config = [
                'api_key' => class_exists('FulfillmentAdapterResolver')
                    ? FulfillmentAdapterResolver::resolveEasyPostApiKey()
                    : '',
                'mock' => false,
            ];
        }
        $this->httpOverride = is_callable($httpOverride) ? $httpOverride : null;
    }

    public function getId(): string
    {
        return 'easypost';
    }

    public function getName(): string
    {
        return 'EasyPost';
    }

    public function isConfigured(): bool
    {
        if ($this->wantsMock()) {
            return true;
        }
        return $this->apiKey() !== '';
    }

    public function testConnection(): array
    {
        if ($this->wantsMock()) {
            return ['ok' => true, 'message' => 'EasyPost mock connection OK', 'mode' => 'mock'];
        }
        $key = $this->apiKey();
        if ($key === '') {
            return [
                'ok' => false,
                'error' => 'EasyPost API key missing — set it under Settings → Shipping',
            ];
        }
        $resp = $this->requestJson('GET', 'https://api.easypost.com/v2/users', null, [
            'auth' => ['user' => $key, 'pass' => ''],
        ]);
        return !empty($resp['ok'])
            ? ['ok' => true, 'message' => 'EasyPost connection verified', 'mode' => 'live']
            : ['ok' => false, 'error' => (string) ($resp['error'] ?? 'Connection failed')];
    }

    /**
     * Create an EasyPost shipment/tracker for the order's ship lines.
     *
     * @param array<string, mixed> $order
     * @return array{
     *   ok: bool,
     *   provider?: string,
     *   tracking_number?: string,
     *   carrier?: string,
     *   label_url?: string|null,
     *   tracker_id?: string,
     *   mode?: string,
     *   error?: string
     * }
     */
    public function pushOrder(array $order): array
    {
        if (!$this->isConfigured()) {
            return ['ok' => false, 'error' => 'EasyPost not configured'];
        }

        if ($this->wantsMock() || !empty($order['force_mock'])) {
            return $this->pushMock($order);
        }

        try {
            return $this->pushLive($order);
        } catch (Throwable $e) {
            // Soft-fail to mock-shaped tracking so ops can continue offline.
            $mock = $this->pushMock($order);
            $mock['mode'] = 'mock_fallback';
            $mock['error'] = $e->getMessage();
            return $mock;
        }
    }

    /**
     * @param array<string, mixed> $order
     * @return array<string, mixed>
     */
    private function pushMock(array $order): array
    {
        $orderId = preg_replace('/[^a-zA-Z0-9]/', '', (string) ($order['id'] ?? 'order')) ?: 'order';
        $suffix = strtoupper(substr(hash('sha256', $orderId . '|easypost'), 0, 8));
        $tracking = 'EZ' . $suffix;
        $trackerId = 'trk_mock_' . strtolower($suffix);
        return [
            'ok' => true,
            'provider' => 'easypost',
            'tracking_number' => $tracking,
            'carrier' => 'USPS',
            'label_url' => 'https://easypost.example/mock/labels/' . $trackerId . '.pdf',
            'tracker_id' => $trackerId,
            'mode' => 'mock',
            'public_url' => 'https://track.easypost.com/' . $tracking,
        ];
    }

    /**
     * @param array<string, mixed> $order
     * @return array<string, mixed>
     */
    private function pushLive(array $order): array
    {
        $key = $this->apiKey();
        if ($key === '') {
            return $this->pushMock($order);
        }

        $to = is_array($order['shipping_address'] ?? null) ? $order['shipping_address'] : [];
        $fromConfig = [];
        if (class_exists('CommerceCatalog')) {
            try {
                $fromConfig = (new CommerceCatalog())->loadShippingZones()['from_address'] ?? [];
            } catch (Throwable $e) {
                $fromConfig = [];
            }
        }
        $from = is_array($fromConfig) ? $fromConfig : [];

        $weightGrams = 0;
        foreach (is_array($order['lines'] ?? null) ? $order['lines'] : [] as $line) {
            if (($line['fulfillment'] ?? '') !== 'ship') {
                continue;
            }
            $grams = (int) (($line['commerce']['weight_grams'] ?? null) ?? ($line['weight_grams'] ?? 100));
            $qty = max(1, (int) ($line['quantity'] ?? 1));
            $weightGrams += max(1, $grams) * $qty;
        }
        if ($weightGrams <= 0) {
            $weightGrams = 100;
        }

        $body = [
            'shipment' => [
                'to_address' => [
                    'name' => (string) ($to['name'] ?? 'Customer'),
                    'street1' => (string) ($to['line1'] ?? ($to['street1'] ?? '1 Main St')),
                    'city' => (string) ($to['city'] ?? 'City'),
                    'state' => (string) ($to['state'] ?? ''),
                    'zip' => (string) ($to['postal_code'] ?? ($to['zip'] ?? '')),
                    'country' => strtoupper((string) ($to['country'] ?? 'US')),
                ],
                'from_address' => [
                    'name' => (string) ($from['name'] ?? 'Warehouse'),
                    'street1' => (string) ($from['street1'] ?? '1 Market St'),
                    'city' => (string) ($from['city'] ?? 'San Francisco'),
                    'state' => (string) ($from['state'] ?? 'CA'),
                    'zip' => (string) ($from['zip'] ?? '94105'),
                    'country' => strtoupper((string) ($from['country'] ?? 'US')),
                ],
                'parcel' => [
                    'weight' => round(max(0.1, $weightGrams / 28.3495), 2),
                ],
                'reference' => (string) ($order['id'] ?? ''),
            ],
        ];

        $resp = $this->requestJson('POST', 'https://api.easypost.com/v2/shipments', $body, [
            'auth' => ['user' => $key, 'pass' => ''],
        ]);
        if (empty($resp['ok']) || !is_array($resp['data'])) {
            throw new RuntimeException((string) ($resp['error'] ?? 'EasyPost shipment create failed'));
        }

        $shipment = $resp['data'];
        $shipmentId = (string) ($shipment['id'] ?? '');
        $rates = is_array($shipment['rates'] ?? null) ? $shipment['rates'] : [];
        usort($rates, static fn ($a, $b) => ((float) ($a['rate'] ?? 0) <=> (float) ($b['rate'] ?? 0)));
        $rateId = (string) (($rates[0]['id'] ?? ''));

        $bought = $shipment;
        if ($shipmentId !== '' && $rateId !== '') {
            $buy = $this->requestJson('POST', 'https://api.easypost.com/v2/shipments/' . rawurlencode($shipmentId) . '/buy', [
                'rate' => ['id' => $rateId],
            ], ['auth' => ['user' => $key, 'pass' => '']]);
            if (!empty($buy['ok']) && is_array($buy['data'])) {
                $bought = $buy['data'];
            }
        }

        $tracker = is_array($bought['tracker'] ?? null) ? $bought['tracker'] : [];
        $postage = is_array($bought['postage_label'] ?? null) ? $bought['postage_label'] : [];
        $selectedRate = is_array($bought['selected_rate'] ?? null) ? $bought['selected_rate'] : ($rates[0] ?? []);

        $tracking = (string) ($bought['tracking_code'] ?? ($tracker['tracking_code'] ?? ''));
        if ($tracking === '') {
            // Fallback: create a tracker only.
            $tracking = 'EP' . strtoupper(substr(hash('sha256', $shipmentId ?: (string) ($order['id'] ?? 'x')), 0, 10));
            $trk = $this->requestJson('POST', 'https://api.easypost.com/v2/trackers', [
                'tracker' => [
                    'tracking_code' => $tracking,
                    'carrier' => (string) ($selectedRate['carrier'] ?? 'USPS'),
                ],
            ], ['auth' => ['user' => $key, 'pass' => '']]);
            if (!empty($trk['ok']) && is_array($trk['data'])) {
                $tracker = $trk['data'];
            }
        }

        return [
            'ok' => true,
            'provider' => 'easypost',
            'tracking_number' => $tracking,
            'carrier' => (string) ($selectedRate['carrier'] ?? ($tracker['carrier'] ?? 'EasyPost')),
            'label_url' => $postage['label_url'] ?? ($postage['label_pdf_url'] ?? null),
            'tracker_id' => (string) ($tracker['id'] ?? ($bought['id'] ?? '')),
            'mode' => 'live',
            'public_url' => $tracker['public_url'] ?? null,
            'shipment_id' => $shipmentId,
        ];
    }

    public function wantsMock(): bool
    {
        if (!empty($this->config['mock']) || !empty($this->config['force_mock'])) {
            return true;
        }
        $env = getenv('COMMERCE_EASYPOST_MOCK');
        if ($env === '1' || strtolower((string) $env) === 'true') {
            return true;
        }
        $key = $this->apiKey();
        return $key === '' || strtolower($key) === 'mock';
    }

    private function apiKey(): string
    {
        return trim((string) ($this->config['api_key'] ?? $this->config['easypost_api_key'] ?? ''));
    }

    /**
     * @param array<string, mixed>|null $body
     * @param array<string, mixed> $options
     * @return array<string, mixed>
     */
    private function requestJson(string $method, string $url, ?array $body, array $options = []): array
    {
        if ($this->httpOverride !== null) {
            $fn = $this->httpOverride;
            return $fn($method, $url, array_merge($options, ['body' => $body]));
        }

        $headers = $options['headers'] ?? [];
        $auth = $options['auth'] ?? null;
        if ($auth !== null) {
            if (is_array($auth)) {
                $headers[] = 'Authorization: Basic ' . base64_encode(($auth['user'] ?? '') . ':' . ($auth['pass'] ?? ''));
            } else {
                $headers[] = 'Authorization: Bearer ' . $auth;
            }
        }
        if ($body !== null) {
            $headers[] = 'Content-Type: application/json';
        }

        $ch = curl_init($url);
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => (int) ($options['timeout'] ?? 30),
        ];
        if ($body !== null) {
            $opts[CURLOPT_POSTFIELDS] = json_encode($body);
        }
        curl_setopt_array($ch, $opts);

        $response = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return ['ok' => false, 'status' => 0, 'error' => $error ?: 'HTTP request failed', 'data' => null];
        }
        $decoded = json_decode($response, true);
        return [
            'ok' => $status >= 200 && $status < 300,
            'status' => $status,
            'error' => ($status >= 200 && $status < 300)
                ? null
                : (is_array($decoded) ? ($decoded['error']['message'] ?? $decoded['message'] ?? ('HTTP ' . $status)) : ('HTTP ' . $status)),
            'data' => $decoded ?? $response,
        ];
    }
}
