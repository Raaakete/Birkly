<?php
/**
 * Catalog index — purchasable entries with Commerce fieldtype values (v2).
 */

if (!function_exists('commerce_cms_content_root')) {
    require_once __DIR__ . '/../cms_paths.php';
}

class CatalogIndexer
{
    private string $indexFile;

    public function __construct(?string $dataDir = null)
    {
        $dir = $dataDir ?? commerce_data_dir();
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $this->indexFile = $dir . '/catalog_index.json';
        if (!is_file($this->indexFile)) {
            file_put_contents($this->indexFile, json_encode(['entries' => []], JSON_PRETTY_PRINT), LOCK_EX);
        }
    }

    public function getIndexPath(): string
    {
        return $this->indexFile;
    }

    public function loadIndex(): array
    {
        if (!is_file($this->indexFile)) {
            return ['entries' => []];
        }
        $data = json_decode((string) file_get_contents($this->indexFile), true);
        return is_array($data) ? $data : ['entries' => []];
    }

    public function saveIndex(array $index): void
    {
        file_put_contents($this->indexFile, json_encode($index, JSON_PRETTY_PRINT), LOCK_EX);
    }

    /**
     * Write catalog quantity_available back onto CMS entry commerce fields.
     * Used after ledger projection so storefront templates (and admin entry forms)
     * show live Available — not a stale seed value.
     *
     * @param array<string, int>|null $wantedSkuFlip uppercase SKUs as keys, or null for all
     */
    public function syncProjectedQuantitiesToEntries(?array $wantedSkuFlip = null): int
    {
        $index = $this->loadIndex();
        $synced = 0;
        foreach ($index['entries'] ?? [] as $row) {
            if (!is_array($row) || !empty($row['is_bundle'])) {
                continue;
            }
            $sku = strtoupper(trim((string) ($row['sku'] ?? '')));
            if ($sku === '') {
                continue;
            }
            if ($wantedSkuFlip !== null && !isset($wantedSkuFlip[$sku])) {
                continue;
            }
            $collection = (string) ($row['collection_slug'] ?? '');
            $entryId = (string) ($row['entry_id'] ?? '');
            if ($collection === '' || $entryId === '') {
                continue;
            }
            $qty = array_key_exists('quantity_available', $row) ? $row['quantity_available'] : null;
            if ($this->persistQuantityToEntry($collection, $entryId, $qty === null ? null : (int) $qty)) {
                $synced++;
            }
        }
        return $synced;
    }

    /**
     * Persist Available onto the commerce field of a CMS entry (or variant sub-entry).
     * Sets commerce_skip_inventory_write_through so after_entry_save reindex does not
     * overwrite warehouse on_hand with available (reserved stock).
     */
    public function persistQuantityToEntry(string $collectionSlug, string $entryId, ?int $quantityAvailable): bool
    {
        $collectionSlug = trim($collectionSlug);
        $entryId = trim($entryId);
        if ($collectionSlug === '' || $entryId === '') {
            return false;
        }

        $root = commerce_cms_content_root();
        $storageFile = commerce_cms_path('core/storage/StorageFactory.php');
        if (!is_file($storageFile)) {
            return false;
        }
        require_once $storageFile;
        if (!class_exists('StorageFactory')) {
            return false;
        }

        $storage = StorageFactory::createStorage($root);
        $entryPath = "collections/{$collectionSlug}/entries/{$entryId}.json";
        $entry = $storage->read($entryPath);
        $isSubEntry = false;
        $parentId = null;

        // Variant sellable units live as sub-entries under the parent product.
        if (!is_array($entry)) {
            $subFile = commerce_cms_path('core/sub_entries.php');
            if (!is_file($subFile)) {
                return false;
            }
            require_once $subFile;
            if (!function_exists('getSubEntry') && !function_exists('getSubEntries')) {
                return false;
            }
            // Scan catalog index for parent_id when this entry_id is a variant.
            $index = $this->loadIndex();
            $key = $collectionSlug . ':' . $entryId;
            $row = $index['entries'][$key] ?? null;
            $parentId = is_array($row) ? ($row['parent_id'] ?? null) : null;
            if ($parentId && function_exists('getSubEntry')) {
                $entry = getSubEntry($collectionSlug, (string) $parentId, 'variants', $entryId);
                $isSubEntry = is_array($entry);
            }
            if (!is_array($entry)) {
                return false;
            }
        }

        $fieldKey = $this->findCommerceFieldKey($entry);
        if ($fieldKey === null) {
            return false;
        }
        $commerce = $entry[$fieldKey] ?? null;
        if (!is_array($commerce)) {
            return false;
        }
        $current = array_key_exists('quantity_available', $commerce) ? $commerce['quantity_available'] : null;
        if ($current === $quantityAvailable) {
            return false;
        }

        $commerce['quantity_available'] = $quantityAvailable;
        $entry[$fieldKey] = $commerce;
        if (isset($entry['data']) && is_array($entry['data']) && isset($entry['data'][$fieldKey])) {
            $entry['data'][$fieldKey] = $commerce;
        }
        $entry['updated_at'] = date('c');

        $GLOBALS['commerce_skip_inventory_write_through'] = true;
        try {
            if ($isSubEntry && $parentId && function_exists('updateSubEntry')) {
                updateSubEntry($collectionSlug, (string) $parentId, 'variants', $entryId, $entry);
            } elseif ($isSubEntry && $parentId) {
                // Fallback: write sub-entry JSON directly when helper is unavailable.
                $subPath = "collections/{$collectionSlug}/entries/{$parentId}/sub_entries/variants/{$entryId}.json";
                if (!$storage->write($subPath, $entry)) {
                    return false;
                }
            } else {
                if (!$storage->write($entryPath, $entry)) {
                    return false;
                }
            }
            if (function_exists('do_action')) {
                do_action('after_entry_save', $entry, $collectionSlug, null);
            }
        } finally {
            unset($GLOBALS['commerce_skip_inventory_write_through']);
        }

        return true;
    }

    /**
     * @param array<string, mixed> $entry
     */
    private function findCommerceFieldKey(array $entry): ?string
    {
        foreach ($entry as $fieldKey => $fieldVal) {
            if (!is_string($fieldKey) || !is_array($fieldVal)) {
                continue;
            }
            if ($fieldKey === 'data') {
                continue;
            }
            if ($this->isBundleFieldValue($fieldVal)) {
                continue;
            }
            if (isset($fieldVal['purchase_options']) || isset($fieldVal['price_cents'])
                || isset($fieldVal['billing']) || isset($fieldVal['fulfillment'])) {
                return $fieldKey;
            }
        }
        if (isset($entry['commerce']) && is_array($entry['commerce']) && !$this->isBundleFieldValue($entry['commerce'])) {
            return 'commerce';
        }
        if (isset($entry['data']) && is_array($entry['data'])) {
            foreach ($entry['data'] as $fieldKey => $fieldVal) {
                if (!is_string($fieldKey) || !is_array($fieldVal)) {
                    continue;
                }
                if ($this->isBundleFieldValue($fieldVal)) {
                    continue;
                }
                if (isset($fieldVal['purchase_options']) || isset($fieldVal['price_cents'])
                    || isset($fieldVal['billing']) || isset($fieldVal['fulfillment'])) {
                    return $fieldKey;
                }
            }
        }
        return null;
    }

    public function indexEntry(array $entry, string $collectionSlug): void
    {
        $entryId = $entry['id'] ?? '';
        if ($entryId === '' || $collectionSlug === '') {
            return;
        }

        $index = $this->loadIndex();
        $parentKey = $collectionSlug . ':' . $entryId;

        $variants = $this->loadVariantSubEntries($collectionSlug, $entryId);
        if (!empty($variants)) {
            unset($index['entries'][$parentKey]);
            foreach ($variants as $variant) {
                $this->indexSellableUnit($index, $variant, $collectionSlug, $entryId, $entry);
            }
            $this->saveIndex($index);
            return;
        }

        $bundleData = $this->extractBundleFromEntry($entry);
        if ($bundleData !== null) {
            $index['entries'][$parentKey] = $this->buildBundleIndexRow($bundleData, $entry, $collectionSlug, $index['entries']);
            $this->saveIndex($index);
            return;
        }

        $commerceData = $this->extractCommerceFromEntry($entry);
        if ($commerceData === null) {
            unset($index['entries'][$parentKey]);
            $this->saveIndex($index);
            return;
        }

        $this->writeThroughSimpleInventory($commerceData);
        $index['entries'][$parentKey] = $this->projectIndexRow($this->buildIndexRow($commerceData, $entry, $collectionSlug));
        $this->saveIndex($index);
    }

    public function removeEntry(string $entryId, string $collectionSlug): void
    {
        if ($entryId === '' || $collectionSlug === '') {
            return;
        }
        $index = $this->loadIndex();
        $key = $collectionSlug . ':' . $entryId;
        unset($index['entries'][$key]);

        foreach (array_keys($index['entries']) as $existingKey) {
            $row = $index['entries'][$existingKey];
            if (($row['parent_id'] ?? '') === $entryId && ($row['collection_slug'] ?? '') === $collectionSlug) {
                unset($index['entries'][$existingKey]);
            }
        }

        $this->saveIndex($index);
    }

    public function reindexAll(?string $contentRoot = null): int
    {
        $root = $contentRoot ?? commerce_cms_content_root();
        require_once commerce_cms_path('core/storage/StorageFactory.php');
        require_once commerce_cms_path('core/public_read.php');
        require_once commerce_cms_path('core/sub_entries.php');

        $storage = StorageFactory::createStorage($root);
        $collectionsDir = $root . '/collections';
        $index = ['entries' => []];

        if (!is_dir($collectionsDir)) {
            $this->saveIndex($index);
            return 0;
        }

        foreach (scandir($collectionsDir) ?: [] as $slug) {
            if ($slug === '.' || $slug === '..') {
                continue;
            }
            $result = birkly_public_list_entries($storage, $slug);
            if (($result['status'] ?? '') !== 'ok') {
                continue;
            }
            foreach ($result['data']['entries'] ?? [] as $entry) {
                $entryId = $entry['id'] ?? '';
                if ($entryId === '') {
                    continue;
                }

                $variants = getSubEntries($slug, $entryId, 'variants');
                if (!empty($variants)) {
                    foreach ($variants as $variant) {
                        $commerceData = $this->extractCommerceFromEntry($variant);
                        if ($commerceData === null) {
                            continue;
                        }
                        $variantId = $variant['id'] ?? '';
                        $key = $slug . ':' . $variantId;
                        $index['entries'][$key] = $this->buildIndexRow($commerceData, $variant, $slug, $entryId, $entry);
                    }
                    continue;
                }

                $commerceData = $this->extractCommerceFromEntry($entry);
                if ($commerceData === null) {
                    continue;
                }
                $key = $slug . ':' . $entryId;
                $index['entries'][$key] = $this->buildIndexRow($commerceData, $entry, $slug);
            }
        }

        foreach (scandir($collectionsDir) ?: [] as $slug) {
            if ($slug === '.' || $slug === '..') {
                continue;
            }
            $result = birkly_public_list_entries($storage, $slug);
            if (($result['status'] ?? '') !== 'ok') {
                continue;
            }
            foreach ($result['data']['entries'] ?? [] as $entry) {
                $entryId = $entry['id'] ?? '';
                if ($entryId === '') {
                    continue;
                }
                if (!empty(getSubEntries($slug, $entryId, 'variants'))) {
                    continue;
                }
                $bundleData = $this->extractBundleFromEntry($entry);
                if ($bundleData === null) {
                    continue;
                }
                $key = $slug . ':' . $entryId;
                $index['entries'][$key] = $this->buildBundleIndexRow($bundleData, $entry, $slug, $index['entries']);
            }
        }

        $this->saveIndex($index);
        if (class_exists('InventoryLedger') || is_file(__DIR__ . '/InventoryLedger.php')) {
            if (!class_exists('InventoryLedger')) {
                require_once __DIR__ . '/InventoryLedger.php';
            }
            (new InventoryLedger(dirname($this->indexFile), $this))->projectCatalogForSkus(null);
        }
        return count($index['entries']);
    }

    public function decrementQuantity(string $collectionSlug, string $entryId, int $qty): bool
    {
        $index = $this->loadIndex();
        $key = $collectionSlug . ':' . $entryId;
        if (!isset($index['entries'][$key])) {
            return false;
        }
        $row = $index['entries'][$key];
        if (($row['quantity_available'] ?? null) === null) {
            return true;
        }
        $available = (int) $row['quantity_available'];
        if ($available < $qty) {
            return false;
        }
        $row['quantity_available'] = max(0, $available - $qty);
        $row['updated_at'] = date('c');
        $index['entries'][$key] = $row;
        $this->saveIndex($index);
        return true;
    }

    public function incrementQuantity(string $collectionSlug, string $entryId, int $qty): bool
    {
        $index = $this->loadIndex();
        $key = $collectionSlug . ':' . $entryId;
        if (!isset($index['entries'][$key])) {
            return false;
        }
        $row = $index['entries'][$key];
        if (($row['quantity_available'] ?? null) === null) {
            return true;
        }
        $available = (int) $row['quantity_available'];
        $row['quantity_available'] = $available + max(1, $qty);
        $row['updated_at'] = date('c');
        $index['entries'][$key] = $row;
        $this->saveIndex($index);

        return true;
    }

    public function reserveQuantity(string $collectionSlug, string $entryId, int $qty): bool
    {
        $index = $this->loadIndex();
        $key = $collectionSlug . ':' . $entryId;
        if (!isset($index['entries'][$key])) {
            return false;
        }
        $row = $index['entries'][$key];
        if (($row['quantity_available'] ?? null) === null) {
            return true;
        }
        return (int) $row['quantity_available'] >= $qty;
    }

    public function normalizeCommerceRow(array $value): array
    {
        if (!class_exists('CommerceSchema')) {
            require_once __DIR__ . '/CommerceSchema.php';
        }
        return commerce_normalize_value($value);
    }

    private function indexSellableUnit(array &$index, array $variant, string $collectionSlug, string $parentId, array $parentEntry): void
    {
        $commerceData = $this->extractCommerceFromEntry($variant);
        $variantId = $variant['id'] ?? '';
        if ($variantId === '' || $commerceData === null) {
            return;
        }
        $key = $collectionSlug . ':' . $variantId;
        $this->writeThroughSimpleInventory($commerceData);
        $index['entries'][$key] = $this->projectIndexRow($this->buildIndexRow($commerceData, $variant, $collectionSlug, $parentId, $parentEntry));
    }

    private function buildIndexRow(array $commerceData, array $entry, string $collectionSlug, ?string $parentId = null, ?array $parentEntry = null): array
    {
        $entryId = $entry['id'] ?? '';
        $variantAttrs = $this->extractVariantAttrs($entry);

        $row = array_merge($commerceData, [
            'entry_id' => $entryId,
            'collection_slug' => $collectionSlug,
            'entry_slug' => $entry['slug'] ?? $entryId,
            'entry_title' => $entry['title'] ?? ($parentEntry['title'] ?? '') . ($variantAttrs ? ' — ' . implode(', ', $variantAttrs) : ''),
            'commerce' => $commerceData,
            'updated_at' => date('c'),
        ]);

        if ($parentId !== null) {
            $row['parent_id'] = $parentId;
            $row['parent_slug'] = $parentEntry['slug'] ?? $parentId;
            $row['parent_title'] = $parentEntry['title'] ?? '';
            $row['variant_attrs'] = $variantAttrs;
        }

        return $row;
    }

    private function writeThroughSimpleInventory(array $commerceData): void
    {
        if (!class_exists('InventoryLedger')) {
            $file = __DIR__ . '/InventoryLedger.php';
            if (!is_file($file)) {
                return;
            }
            require_once $file;
        }
        (new InventoryLedger(dirname($this->indexFile), $this))->writeThroughSimpleField($commerceData);
    }

    private function projectIndexRow(array $row): array
    {
        $sku = trim((string) ($row['sku'] ?? ''));
        if ($sku === '') {
            return $row;
        }
        if (!class_exists('InventoryLedger')) {
            $file = __DIR__ . '/InventoryLedger.php';
            if (!is_file($file)) {
                return $row;
            }
            require_once $file;
        }
        $row['quantity_available'] = (new InventoryLedger(dirname($this->indexFile), $this))->expectedCatalogQuantity($sku);
        return $row;
    }

    private function extractVariantAttrs(array $entry): array
    {
        $skip = ['id', 'slug', 'title', 'status', 'collection', 'commerce', 'pricing', 'created_at', 'updated_at'];
        $attrs = [];
        foreach ($entry as $key => $val) {
            if (in_array($key, $skip, true) || !is_scalar($val) || $val === '') {
                continue;
            }
            if (is_array($val) && (isset($val['price_cents']) || isset($val['purchase_options']))) {
                continue;
            }
            $attrs[$key] = (string) $val;
        }
        return $attrs;
    }

    private function loadVariantSubEntries(string $collectionSlug, string $entryId): array
    {
        $subFile = commerce_cms_path('core/sub_entries.php');
        if (!is_file($subFile)) {
            return [];
        }
        require_once $subFile;
        if (!function_exists('getSubEntries')) {
            return [];
        }
        return getSubEntries($collectionSlug, $entryId, 'variants') ?: [];
    }

    private function extractCommerceFromEntry(array $entry): ?array
    {
        foreach ($entry as $fieldKey => $fieldVal) {
            if (!is_array($fieldVal)) {
                continue;
            }
            if ($this->isBundleFieldValue($fieldVal)) {
                continue;
            }
            if (isset($fieldVal['purchase_options']) || isset($fieldVal['price_cents']) || isset($fieldVal['billing']) || isset($fieldVal['fulfillment'])) {
                return $this->normalizeCommerceRow($fieldVal);
            }
        }
        if (isset($entry['commerce']) && is_array($entry['commerce']) && !$this->isBundleFieldValue($entry['commerce'])) {
            return $this->normalizeCommerceRow($entry['commerce']);
        }
        return null;
    }

    private function extractBundleFromEntry(array $entry): ?array
    {
        foreach ($entry as $fieldVal) {
            if (!is_array($fieldVal)) {
                continue;
            }
            if ($this->isBundleFieldValue($fieldVal)) {
                return $this->normalizeBundleRow($fieldVal);
            }
        }
        if (isset($entry['commerce_bundle']) && is_array($entry['commerce_bundle'])) {
            return $this->normalizeBundleRow($entry['commerce_bundle']);
        }
        return null;
    }

    private function isBundleFieldValue(array $value): bool
    {
        if (!class_exists('CommerceBundleSchema')) {
            require_once __DIR__ . '/CommerceBundleSchema.php';
        }
        return CommerceBundleSchema::isBundleValue($value);
    }

    private function normalizeBundleRow(array $value): array
    {
        if (!class_exists('CommerceBundleSchema')) {
            require_once __DIR__ . '/CommerceBundleSchema.php';
        }
        return commerce_bundle_normalize_value($value);
    }

    private function buildBundleIndexRow(array $bundleData, array $entry, string $collectionSlug, array $catalogEntries): array
    {
        if (!class_exists('CommerceBundleSchema')) {
            require_once __DIR__ . '/CommerceBundleSchema.php';
        }

        $entryId = $entry['id'] ?? '';
        $resolved = CommerceBundleSchema::resolveComponents($bundleData, $catalogEntries);
        $priceCents = CommerceBundleSchema::computePriceCents($bundleData, $resolved['items']);
        $quantityAvailable = CommerceBundleSchema::computeQuantityAvailable($bundleData, $resolved['items']);

        return [
            'is_bundle' => true,
            'entry_id' => $entryId,
            'collection_slug' => $collectionSlug,
            'entry_slug' => $entry['slug'] ?? $entryId,
            'entry_title' => $entry['title'] ?? $entryId,
            'bundle' => $bundleData,
            'components' => $resolved['items'],
            'component_valid' => $resolved['valid'],
            'component_issues' => $resolved['issues'],
            'price_cents' => $priceCents,
            'currency' => $bundleData['currency'] ?? 'eur',
            'billing' => 'one_time',
            'interval' => null,
            'fulfillment' => $bundleData['fulfillment'] ?? 'ship',
            'quantity_available' => $quantityAvailable,
            'purchase_options' => [[
                'id' => 'default',
                'label' => 'Bundle',
                'billing' => 'one_time',
                'price_cents' => $priceCents,
                'currency' => $bundleData['currency'] ?? 'eur',
                'interval' => null,
            ]],
            'updated_at' => date('c'),
        ];
    }
}
