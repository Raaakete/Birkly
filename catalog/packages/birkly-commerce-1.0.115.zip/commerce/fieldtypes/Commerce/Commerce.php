<?php
/**
 * Commerce fieldtype v2 — fulfillment + purchase_options[] (fixed or variable).
 */

namespace Birkly\FieldTypes\Commerce;

if (!class_exists('Birkly\FieldTypes\BaseField')) {
    require_once __DIR__ . '/../../cms_paths.php';
    commerce_require_cms('fieldtypes/BaseField.php');
}
if (!class_exists('CommerceSchema')) {
    require_once __DIR__ . '/../../includes/CommerceSchema.php';
}
if (!class_exists('CommerceFieldtypeProfileStore')) {
    require_once __DIR__ . '/../../includes/CommerceFieldtypeProfileStore.php';
}

use Birkly\FieldTypes\BaseField;

class Commerce extends BaseField
{
    private array $commerceSettings;

    public function __construct(array $config)
    {
        parent::__construct($config);
        $this->commerceSettings = $this->resolveCommerceSettings($config);
    }

    public function getType(): string
    {
        return 'commerce';
    }

    public function getCategory(): string
    {
        return 'Commerce';
    }

    public function render(): string
    {
        $value = \commerce_normalize_value($this->value);
        $name = htmlspecialchars($this->name);
        $settings = $this->commerceSettings;
        $fulfillments = $settings['enabled_fulfillments'] ?? \CommerceSchema::FULFILLMENTS;
        $intervals = $settings['interval_options'] ?? ['week', 'month', 'year'];
        $currencies = $settings['currency_options'] ?? ['eur', 'usd', 'gbp', 'jpy'];
        $recurringEnabled = \CommerceSchema::recurringBillingEnabled();

        $taxClass = \CommerceSchema::normalizeTaxClass($value['tax_class'] ?? 'standard');
        $taxIncluded = \CommerceSchema::normalizeTaxIncluded($value['tax_included'] ?? true);
        $taxOptions = \CommerceSchema::TAX_CLASSES;
        $taxClassInStandard = in_array($taxClass, $taxOptions, true);
        if (!$taxClassInStandard) {
            $taxOptions[] = $taxClass;
        }
        $taxCustomDisplay = $taxClassInStandard ? '' : $taxClass;

        $html = '<div class="commerce-fieldtype commerce-ft-shell" data-field-name="' . $name . '"'
            . ' data-recurring="' . ($recurringEnabled ? '1' : '0') . '">';
        $html .= '<div class="commerce-ft-shell-header">';
        $html .= '<span class="commerce-ft-shell-title">Commerce &amp; pricing</span>';
        $html .= '<span class="commerce-ft-shell-sub">Fulfillment, tax, purchase options, and product details for checkout</span>';
        $html .= '</div>';
        $html .= '<div class="commerce-ft-shell-body">';

        $html .= '<div class="commerce-ft-section">';
        $html .= '<div class="commerce-ft-section-label">Checkout setup</div>';
        $html .= '<div class="commerce-ft-row">';

        if ($settings['enable_fulfillment'] ?? true) {
            $html .= '<div class="commerce-ft-block commerce-ft-block-inset">';
            $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">Fulfillment</span>';
            $html .= '<span class="commerce-ft-block-hint">What happens after payment</span></div>';
            $html .= '<select name="' . $name . '[fulfillment]" class="form-control commerce-fulfillment-select">';
            foreach ($fulfillments as $f) {
                $sel = $value['fulfillment'] === $f ? ' selected' : '';
                $label = match ($f) {
                    'ship' => 'Ship — physical goods',
                    'deliver' => 'Deliver — digital download',
                    'register' => 'Register — events & tickets',
                    'gift_card' => 'Gift card — issue store credit on pay',
                    'none' => 'None — membership / donation',
                    default => ucfirst((string) $f),
                };
                $html .= '<option value="' . htmlspecialchars($f) . '"' . $sel . '>' . htmlspecialchars($label) . '</option>';
            }
            $html .= '</select></div>';
        }

        $html .= '<div class="commerce-ft-block commerce-ft-block-inset">';
        $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">Tax</span>';
        $html .= '<span class="commerce-ft-block-hint">Rates from Settings → Tax · EU default is tax included</span></div>';
        $html .= '<label class="commerce-ft-field"><span>Price tax mode</span>';
        $html .= '<select name="' . $name . '[tax_included]" class="form-control">';
        $html .= '<option value="1"' . ($taxIncluded ? ' selected' : '') . '>Tax included in price</option>';
        $html .= '<option value="0"' . (!$taxIncluded ? ' selected' : '') . '>Tax excluded (added at checkout)</option>';
        $html .= '</select></label>';
        $html .= '<label class="commerce-ft-field"><span>Tax class</span>';
        $html .= '<select name="' . $name . '[tax_class]" class="form-control">';
        foreach ($taxOptions as $tc) {
            $sel = $taxClass === $tc ? ' selected' : '';
            $tcLabel = match ($tc) {
                'standard' => 'Standard',
                'reduced' => 'Reduced',
                'zero' => 'Zero-rated',
                default => $tc,
            };
            $html .= '<option value="' . htmlspecialchars($tc) . '"' . $sel . '>' . htmlspecialchars($tcLabel) . '</option>';
        }
        $html .= '</select></label>';
        $html .= '<label class="commerce-ft-field"><span>Custom class code</span>';
        $html .= '<input type="text" class="form-control" name="' . $name . '[tax_class_custom]" value="'
            . htmlspecialchars($taxCustomDisplay) . '" placeholder="e.g. books" pattern="[a-z0-9_-]+"></label>';
        $html .= '</div>';

        $html .= '</div></div>';

        if ($settings['enable_purchase_options'] ?? true) {
            $html .= '<div class="commerce-ft-section commerce-purchase-options">';
            $html .= '<div class="commerce-ft-section-label">Purchase options</div>';
            $html .= '<div class="commerce-ft-block commerce-ft-block-inset commerce-ft-options-panel">';
            $html .= '<div class="commerce-ft-block-head">';
            $html .= '<span class="commerce-ft-block-title">Prices &amp; billing</span>';
            $html .= '<span class="commerce-ft-block-hint">Fixed prices, subscriptions, or pay-what-you-want / donations</span>';
            $html .= '</div>';
            $html .= '<div class="commerce-options-list" data-field="' . $name . '">';
            foreach ($value['purchase_options'] as $idx => $opt) {
                $html .= $this->renderPurchaseOptionRow($name, $idx, $opt, $intervals, $currencies);
            }
            $html .= '</div>';
            $html .= '<button type="button" class="btn btn-secondary commerce-add-option" data-field="' . $name . '">Add option</button>';
            $html .= '<template class="commerce-option-template">';
            $html .= $this->renderPurchaseOptionRow($name, 9999, [
                'id' => '',
                'label' => '',
                'billing' => 'one_time',
                'pricing_mode' => 'fixed',
                'price_cents' => 0,
                'min_price_cents' => 100,
                'max_price_cents' => null,
                'currency' => $currencies[0] ?? 'eur',
                'interval' => 'month',
            ], $intervals, $currencies);
            $html .= '</template>';
            $html .= '</div></div>';
        }

        $html .= '<div class="commerce-ft-section commerce-ft-details">';
        $html .= '<div class="commerce-ft-section-label">Product details</div>';

        if ($settings['enable_quantity'] ?? true) {
            $qtyVal = $value['quantity_available'] === null ? '' : (string) (int) $value['quantity_available'];
            $html .= '<div class="commerce-ft-block commerce-ft-block-inset commerce-panel commerce-panel-register"'
                . ($value['fulfillment'] !== 'register' ? ' style="display:none"' : '') . '>';
            $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">Capacity</span>';
            $html .= '<span class="commerce-ft-block-hint">Leave blank for unlimited spots</span></div>';
            $html .= '<input type="number" min="0" class="form-control" name="' . $name . '[quantity_available]" '
                . 'placeholder="Unlimited" value="' . htmlspecialchars($qtyVal) . '">';
            $html .= '</div>';
        }

        if ($settings['enable_sku'] ?? true) {
            $html .= '<div class="commerce-ft-block commerce-ft-block-inset">';
            $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">SKU</span>';
            $html .= '<span class="commerce-ft-block-hint">Optional inventory identifier</span></div>';
            $html .= '<input type="text" class="form-control" name="' . $name . '[sku]" value="'
                . htmlspecialchars($value['sku'] ?? '') . '">';
            $html .= '</div>';
        }

        $html .= '<div class="commerce-panel commerce-panel-gift_card commerce-ft-block-inset"'
            . ($value['fulfillment'] !== 'gift_card' ? ' style="display:none"' : '') . '>';
        $html .= '<div class="commerce-ft-block">';
        $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">Sellable gift card</span>';
        $html .= '<span class="commerce-ft-block-hint">Purchase option price is the face value issued after payment. No shipping.</span></div>';
        $html .= '</div></div>';

        $html .= '<div class="commerce-panel commerce-panel-ship commerce-ft-block-inset"'
            . ($value['fulfillment'] !== 'ship' ? ' style="display:none"' : '') . '>';
        if ($settings['enable_weight'] ?? true) {
            $weight = $value['weight_grams'] === null ? '' : (string) (int) $value['weight_grams'];
            $html .= '<div class="commerce-ft-block">';
            $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">Weight (grams)</span>';
            $html .= '<span class="commerce-ft-block-hint">Required for live shipping rates (EasyPost)</span></div>';
            $html .= '<input type="number" min="0" class="form-control" name="' . $name . '[weight_grams]" value="'
                . htmlspecialchars($weight) . '">';
            $html .= '</div>';
            $len = $value['length_mm'] === null ? '' : (string) (int) $value['length_mm'];
            $wid = $value['width_mm'] === null ? '' : (string) (int) $value['width_mm'];
            $hei = $value['height_mm'] === null ? '' : (string) (int) $value['height_mm'];
            $html .= '<div class="commerce-ft-block">';
            $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">Dimensions (mm)</span>';
            $html .= '<span class="commerce-ft-block-hint">Optional — used for live rate parcels when set</span></div>';
            $html .= '<div class="commerce-ft-grid">';
            $html .= '<label class="commerce-ft-field"><span>Length</span><input type="number" min="0" class="form-control" name="'
                . $name . '[length_mm]" value="' . htmlspecialchars($len) . '"></label>';
            $html .= '<label class="commerce-ft-field"><span>Width</span><input type="number" min="0" class="form-control" name="'
                . $name . '[width_mm]" value="' . htmlspecialchars($wid) . '"></label>';
            $html .= '<label class="commerce-ft-field"><span>Height</span><input type="number" min="0" class="form-control" name="'
                . $name . '[height_mm]" value="' . htmlspecialchars($hei) . '"></label>';
            $html .= '</div></div>';
        }
        $html .= '</div>';

        $html .= '<div class="commerce-panel commerce-panel-deliver commerce-ft-block-inset"'
            . ($value['fulfillment'] !== 'deliver' ? ' style="display:none"' : '') . '>';
        $html .= '<div class="commerce-ft-block">';
        $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">Digital delivery</span></div>';
        $html .= '<div class="commerce-ft-grid">';
        $html .= '<label class="commerce-ft-field"><span>Mode</span>';
        $html .= '<select name="' . $name . '[delivery_mode]" class="form-control">';
        foreach (['secure_download' => 'Secure download', 'external_url' => 'External URL'] as $mode => $label) {
            $sel = ($value['delivery_mode'] ?? '') === $mode ? ' selected' : '';
            $html .= '<option value="' . $mode . '"' . $sel . '>' . $label . '</option>';
        }
        $html .= '</select></label>';
        $html .= '<label class="commerce-ft-field"><span>Asset path</span>';
        $html .= '<input type="text" class="form-control" name="' . $name . '[delivery_asset]" value="'
            . htmlspecialchars($value['delivery_asset'] ?? '') . '"></label>';
        $html .= '<label class="commerce-ft-field commerce-ft-field-wide"><span>External URL</span>';
        $html .= '<input type="url" class="form-control" name="' . $name . '[delivery_url]" value="'
            . htmlspecialchars($value['delivery_url'] ?? '') . '"></label>';
        $html .= '</div></div></div>';

        foreach ($settings['custom_fields'] ?? [] as $cfIdx => $cf) {
            $cfKey = htmlspecialchars($cf['key'] ?? 'field_' . $cfIdx);
            $cfLabel = htmlspecialchars($cf['label'] ?? $cfKey);
            $cfVal = htmlspecialchars((string) ($value['custom_fields'][$cf['key'] ?? ''] ?? ''));
            $html .= '<div class="commerce-ft-block commerce-ft-block-inset">';
            $html .= '<div class="commerce-ft-block-head"><span class="commerce-ft-block-title">' . $cfLabel . '</span></div>';
            $html .= '<input type="text" class="form-control" name="' . $name . '[custom_fields][' . $cfKey . ']" value="' . $cfVal . '">';
            $html .= '</div>';
        }

        $html .= '</div>';
        $html .= '</div></div>';
        return $html;
    }

    private function renderPurchaseOptionRow(string $name, int $idx, array $opt, array $intervals, array $currencies): string
    {
        $id = htmlspecialchars($opt['id'] ?? 'opt_' . ($idx + 1));
        $label = htmlspecialchars($opt['label'] ?? '');
        $billing = htmlspecialchars($opt['billing'] ?? 'one_time');
        $pricingMode = htmlspecialchars($opt['pricing_mode'] ?? 'fixed');
        $priceDisplay = number_format((int) ($opt['price_cents'] ?? 0) / 100, 2, '.', '');
        $minDisplay = number_format((int) ($opt['min_price_cents'] ?? 100) / 100, 2, '.', '');
        $maxRaw = $opt['max_price_cents'] ?? null;
        $maxDisplay = $maxRaw === null || $maxRaw === '' ? '' : number_format((int) $maxRaw / 100, 2, '.', '');
        $currency = htmlspecialchars(strtolower($opt['currency'] ?? 'eur'));
        $interval = htmlspecialchars($opt['interval'] ?? 'month');
        $centsId = $name . '_opt_' . $idx . '_price_cents';
        $minCentsId = $name . '_opt_' . $idx . '_min_cents';
        $maxCentsId = $name . '_opt_' . $idx . '_max_cents';
        $recurringEnabled = \CommerceSchema::recurringBillingEnabled();
        $isVariable = ($opt['pricing_mode'] ?? 'fixed') === 'variable';

        $html = '<div class="commerce-option-row" data-option-index="' . $idx . '">';
        $html .= '<div class="commerce-option-row-top">';
        $html .= '<strong class="commerce-option-row-title">Option ' . ($idx + 1) . '</strong>';
        $html .= '<button type="button" class="btn btn-secondary commerce-remove-option">Remove</button>';
        $html .= '</div>';
        $html .= '<input type="hidden" name="' . $name . '[purchase_options][' . $idx . '][id]" value="' . $id . '" class="commerce-option-id">';

        $html .= '<div class="commerce-ft-grid">';
        $html .= '<label class="commerce-ft-field commerce-ft-field-wide"><span>Label</span>';
        $html .= '<input type="text" class="form-control" name="' . $name . '[purchase_options][' . $idx . '][label]" '
            . 'value="' . $label . '" placeholder="e.g. Standard, Monthly, Donate"></label>';

        $html .= '<label class="commerce-ft-field"><span>Pricing</span>';
        $html .= '<select name="' . $name . '[purchase_options][' . $idx . '][pricing_mode]" class="form-control commerce-pricing-mode">';
        $html .= '<option value="fixed"' . ($pricingMode === 'fixed' ? ' selected' : '') . '>Fixed price</option>';
        $html .= '<option value="variable"' . ($pricingMode === 'variable' ? ' selected' : '') . '>Variable (donation / PWYW)</option>';
        $html .= '</select></label>';

        $html .= '<label class="commerce-ft-field"><span>Currency</span><select name="'
            . $name . '[purchase_options][' . $idx . '][currency]" class="form-control">';
        foreach ($currencies as $cur) {
            $sel = strtolower($opt['currency'] ?? 'eur') === $cur ? ' selected' : '';
            $html .= '<option value="' . htmlspecialchars($cur) . '"' . $sel . '>' . strtoupper($cur) . '</option>';
        }
        $html .= '</select></label>';

        $html .= '<label class="commerce-ft-field commerce-fixed-price-fields"'
            . ($isVariable ? ' style="display:none"' : '') . '><span>Price</span>';
        $html .= '<input type="number" step="0.01" min="0" class="form-control commerce-price-input" '
            . 'data-cents-target="' . htmlspecialchars($centsId) . '" value="' . htmlspecialchars($priceDisplay) . '">';
        $html .= '<input type="hidden" name="' . $name . '[purchase_options][' . $idx . '][price_cents]" id="'
            . htmlspecialchars($centsId) . '" class="commerce-price-cents" value="'
            . (int) ($opt['price_cents'] ?? 0) . '"></label>';

        $html .= '<label class="commerce-ft-field commerce-variable-price-fields"'
            . (!$isVariable ? ' style="display:none"' : '') . '><span>Suggested amount</span>';
        $html .= '<input type="number" step="0.01" min="0" class="form-control commerce-price-input" '
            . 'data-cents-target="' . htmlspecialchars($centsId) . '" value="' . htmlspecialchars($priceDisplay) . '">';
        $html .= '</label>';

        $html .= '<label class="commerce-ft-field commerce-variable-price-fields"'
            . (!$isVariable ? ' style="display:none"' : '') . '><span>Minimum</span>';
        $html .= '<input type="number" step="0.01" min="0" class="form-control commerce-price-input" '
            . 'data-cents-target="' . htmlspecialchars($minCentsId) . '" value="' . htmlspecialchars($minDisplay) . '">';
        $html .= '<input type="hidden" name="' . $name . '[purchase_options][' . $idx . '][min_price_cents]" id="'
            . htmlspecialchars($minCentsId) . '" value="' . (int) ($opt['min_price_cents'] ?? 100) . '"></label>';

        $html .= '<label class="commerce-ft-field commerce-variable-price-fields"'
            . (!$isVariable ? ' style="display:none"' : '') . '><span>Maximum (optional)</span>';
        $html .= '<input type="number" step="0.01" min="0" class="form-control commerce-price-input" '
            . 'data-cents-target="' . htmlspecialchars($maxCentsId) . '" value="' . htmlspecialchars($maxDisplay) . '" placeholder="No max">';
        $html .= '<input type="hidden" name="' . $name . '[purchase_options][' . $idx . '][max_price_cents]" id="'
            . htmlspecialchars($maxCentsId) . '" value="'
            . ($maxRaw === null || $maxRaw === '' ? '' : (int) $maxRaw) . '"></label>';

        // Duplicate hidden price_cents for variable mode when fixed field is hidden — keep one shared hidden via fixed label above.
        // When variable, the suggested amount inputs share data-cents-target with the same hidden from fixed block.
        // Ensure hidden exists even if fixed block is hidden (it still exists in DOM).

        $html .= '<label class="commerce-ft-field"><span>Billing</span>';
        $html .= '<select name="' . $name . '[purchase_options][' . $idx . '][billing]" class="form-control commerce-billing-select">';
        $html .= '<option value="one_time"' . ($billing === 'one_time' ? ' selected' : '') . '>One-time</option>';
        if ($recurringEnabled) {
            $html .= '<option value="recurring"' . ($billing === 'recurring' ? ' selected' : '') . '>Subscription (recurring)</option>';
        }
        $html .= '</select>';
        if (!$recurringEnabled) {
            $html .= '<small class="form-text">Recurring billing is disabled on this site.</small>';
        }
        $html .= '</label>';

        $html .= '<label class="commerce-ft-field commerce-interval-row"'
            . (!$recurringEnabled || $billing !== 'recurring' ? ' style="display:none"' : '') . '><span>Interval</span>';
        $html .= '<select name="' . $name . '[purchase_options][' . $idx . '][interval]" class="form-control">';
        foreach ($intervals as $iv) {
            $ivVal = is_array($iv) ? ($iv['value'] ?? '') : (string) $iv;
            if ($ivVal === '') {
                continue;
            }
            $ivLabel = is_array($iv)
                ? ($iv['label'] ?? \CommerceFieldtypeProfileStore::intervalLabelFromValue($ivVal))
                : \CommerceFieldtypeProfileStore::intervalLabelFromValue($ivVal);
            $sel = ($opt['interval'] ?? 'month') === $ivVal ? ' selected' : '';
            $html .= '<option value="' . htmlspecialchars($ivVal) . '"' . $sel . '>' . htmlspecialchars($ivLabel) . '</option>';
        }
        $html .= '</select></label>';
        $html .= '</div></div>';
        return $html;
    }

    public function validate($value): array
    {
        return \CommerceSchema::validate(is_array($value) ? $value : [], $this->required);
    }

    public function getJavaScript(): string
    {
        return <<<'JS'
(function(){
  function syncPriceInputs(root) {
    (root || document).querySelectorAll('.commerce-price-input').forEach(function(input) {
      var targetId = input.getAttribute('data-cents-target');
      var hidden = document.getElementById(targetId);
      if (!hidden) return;
      var raw = String(input.value || '').trim();
      if (raw === '') {
        hidden.value = '';
        return;
      }
      var val = parseFloat(raw);
      hidden.value = isNaN(val) ? '0' : String(Math.round(val * 100));
    });
  }

  function reindexOptions(list) {
    var field = list.getAttribute('data-field');
    if (!field) return;
    list.querySelectorAll('.commerce-option-row').forEach(function(row, idx) {
      row.setAttribute('data-option-index', String(idx));
      row.querySelectorAll('[name]').forEach(function(el) {
        el.name = el.name.replace(
          new RegExp('^' + field.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\[purchase_options\\]\\[\\d+\\]'),
          field + '[purchase_options][' + idx + ']'
        );
      });
      row.querySelectorAll('[id]').forEach(function(el) {
        if (!el.id) return;
        var newId = el.id.replace(/_opt_\d+_/, '_opt_' + idx + '_');
        var oldId = el.id;
        el.id = newId;
        row.querySelectorAll('[data-cents-target="' + oldId + '"]').forEach(function(inp) {
          inp.setAttribute('data-cents-target', newId);
        });
      });
      var idInput = row.querySelector('.commerce-option-id');
      if (idInput && !String(idInput.value || '').trim()) {
        idInput.value = 'opt_' + (idx + 1);
      }
    });
  }

  function togglePricingMode(row) {
    var mode = row.querySelector('.commerce-pricing-mode');
    if (!mode) return;
    var variable = mode.value === 'variable';
    row.querySelectorAll('.commerce-variable-price-fields').forEach(function(el) {
      el.style.display = variable ? '' : 'none';
    });
    row.querySelectorAll('.commerce-fixed-price-fields').forEach(function(el) {
      el.style.display = variable ? 'none' : '';
    });
  }

  function toggleBilling(row) {
    var billing = row.querySelector('.commerce-billing-select');
    if (!billing) return;
    var intervalRow = row.querySelector('.commerce-interval-row');
    if (intervalRow) {
      intervalRow.style.display = billing.value === 'recurring' ? '' : 'none';
    }
  }

  function syncOnePriceInput(input) {
    if (!input || !input.classList.contains('commerce-price-input')) return;
    var targetId = input.getAttribute('data-cents-target');
    var hidden = document.getElementById(targetId);
    if (!hidden) return;
    var raw = String(input.value || '').trim();
    if (raw === '') {
      hidden.value = '';
      return;
    }
    var val = parseFloat(raw);
    hidden.value = isNaN(val) ? '0' : String(Math.round(val * 100));
  }

  document.addEventListener('beforeSaveEntry', function() {
    syncPriceInputs(document);
  });

  document.addEventListener('input', function(e) {
    syncOnePriceInput(e.target);
  });

  document.addEventListener('change', function(e) {
    syncOnePriceInput(e.target);
    if (e.target.classList.contains('commerce-pricing-mode')) {
      var row = e.target.closest('.commerce-option-row');
      if (row) togglePricingMode(row);
    }
    if (e.target.classList.contains('commerce-billing-select')) {
      var brow = e.target.closest('.commerce-option-row');
      if (brow) toggleBilling(brow);
    }
    if (e.target.classList.contains('commerce-fulfillment-select')) {
      var root = e.target.closest('.commerce-fieldtype');
      if (!root) return;
      var f = e.target.value;
      root.querySelectorAll('.commerce-panel').forEach(function(p){ p.style.display = 'none'; });
      var panel = root.querySelector('.commerce-panel-' + f);
      if (panel) panel.style.display = '';
      var regQty = root.querySelector('.commerce-panel-register');
      if (regQty && f === 'register') regQty.style.display = '';
    }
  });

  document.addEventListener('click', function(e) {
    var addBtn = e.target.closest('.commerce-add-option');
    if (addBtn) {
      e.preventDefault();
      var field = addBtn.getAttribute('data-field');
      var root = addBtn.closest('.commerce-fieldtype') || document;
      var list = root.querySelector('.commerce-options-list[data-field="' + field + '"]');
      var tpl = root.querySelector('template.commerce-option-template');
      if (!list || !tpl) return;
      var node = tpl.content.cloneNode(true);
      var row = node.querySelector('.commerce-option-row');
      if (!row) return;
      list.appendChild(row);
      reindexOptions(list);
      togglePricingMode(row);
      toggleBilling(row);
      syncPriceInputs(row);
      var label = row.querySelector('input[name*="[label]"]');
      if (label) label.focus();
      return;
    }
    if (e.target.closest('.commerce-remove-option')) {
      e.preventDefault();
      var row = e.target.closest('.commerce-option-row');
      if (!row) return;
      var list = row.parentNode;
      if (!list || list.querySelectorAll('.commerce-option-row').length <= 1) return;
      row.remove();
      reindexOptions(list);
    }
  });

  document.addEventListener('submit', function() {
    syncPriceInputs(document);
  }, true);
})();
JS;
    }

    public function getCSS(): string
    {
        return '
        .commerce-fieldtype.commerce-ft-shell {
          max-width: 52rem;
          border: 1px solid var(--border-color, #e5e7eb);
          border-radius: 12px;
          background: var(--surface-secondary, #f9fafb);
          overflow: hidden;
        }
        .commerce-ft-shell-header {
          padding: 0.85rem 1.1rem;
          border-bottom: 1px solid var(--border-color, #e5e7eb);
          background: var(--surface, #fff);
        }
        .commerce-ft-shell-title {
          display: block;
          font-weight: 650;
          font-size: 0.95rem;
          color: var(--text-primary, #111827);
        }
        .commerce-ft-shell-sub {
          display: block;
          margin-top: 0.2rem;
          font-size: 0.8rem;
          color: var(--text-secondary, #6b7280);
        }
        .commerce-ft-shell-body {
          display: flex;
          flex-direction: column;
          gap: 1rem;
          padding: 1rem 1.1rem 1.15rem;
        }
        .commerce-ft-section {
          display: flex;
          flex-direction: column;
          gap: 0.55rem;
        }
        .commerce-ft-section-label {
          font-size: 0.72rem;
          font-weight: 700;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: var(--text-secondary, #6b7280);
        }
        .commerce-ft-row {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 0.75rem;
        }
        .commerce-ft-block { display: flex; flex-direction: column; gap: 0.4rem; }
        .commerce-ft-block-inset {
          padding: 0.75rem 0.85rem;
          border: 1px solid var(--border-color, #e5e7eb);
          border-radius: 10px;
          background: var(--surface, #fff);
        }
        .commerce-ft-block-head { display: flex; flex-wrap: wrap; align-items: baseline; gap: 0.35rem 0.75rem; }
        .commerce-ft-block-title { font-weight: 650; font-size: 0.9rem; color: var(--text-primary, #111827); }
        .commerce-ft-block-hint { font-size: 0.78rem; color: var(--text-secondary, #6b7280); }
        .commerce-ft-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.65rem 0.75rem; }
        .commerce-ft-field { display: flex; flex-direction: column; gap: 0.25rem; margin: 0; }
        .commerce-ft-field > span { font-size: 0.8rem; font-weight: 600; color: var(--text-secondary, #4b5563); }
        .commerce-ft-field-wide { grid-column: 1 / -1; }
        .commerce-ft-options-panel .commerce-options-list { margin-top: 0.15rem; }
        .commerce-option-row {
          border: 1px solid var(--border-color, #e5e7eb);
          background: var(--surface-secondary, #f9fafb);
          padding: 0.85rem 1rem;
          border-radius: 10px;
          margin-bottom: 0.65rem;
        }
        .commerce-option-row-top {
          display: flex; justify-content: space-between; align-items: center;
          margin-bottom: 0.65rem; gap: 0.5rem;
        }
        .commerce-option-row-title { font-size: 0.82rem; font-weight: 650; color: var(--text-secondary, #4b5563); }
        .commerce-purchase-options .commerce-add-option { margin-top: 0.15rem; align-self: flex-start; }
        .commerce-ft-details { display: flex; flex-direction: column; gap: 0.65rem; }
        .commerce-fieldtype template { display: none; }
        @media (max-width: 720px) {
          .commerce-ft-row,
          .commerce-ft-grid { grid-template-columns: 1fr; }
        }
        ';
    }

    public function getAdminConfig(): array
    {
        return ['commerce_settings' => $this->commerceSettings];
    }

    public function getSchema(): array
    {
        return [
            'fulfillment' => 'string',
            'tax_class' => 'string',
            'tax_included' => 'boolean',
            'purchase_options' => 'array',
            'quantity_available' => 'integer|null',
            'sku' => 'string|null',
            'weight_grams' => 'integer|null',
            'length_mm' => 'integer|null',
            'width_mm' => 'integer|null',
            'height_mm' => 'integer|null',
            'delivery_asset' => 'string|null',
            'delivery_url' => 'string|null',
            'delivery_mode' => 'string',
            'custom_fields' => 'array',
            'price_cents' => 'integer',
            'currency' => 'string',
            'billing' => 'string',
            'interval' => 'string|null',
        ];
    }

    public function getDefaultValue()
    {
        return \CommerceSchema::defaultValue();
    }

    public function processValue($value)
    {
        return \commerce_normalize_value($value);
    }

    public function processLoadedValue($value)
    {
        return \commerce_normalize_value($value);
    }

    public function migrateLegacyValue(array $value): array
    {
        return \CommerceSchema::migrateLegacyValue($value);
    }

    public function renderListCell($value, array $context = []): string
    {
        $v = \commerce_normalize_value($value);
        $opt = $v['purchase_options'][0] ?? [];
        $cur = strtoupper((string) ($opt['currency'] ?? $v['currency'] ?? 'eur'));
        $fulfillment = $v['fulfillment'] ?? '';
        if (($opt['pricing_mode'] ?? 'fixed') === 'variable') {
            $min = number_format(((int) ($opt['min_price_cents'] ?? 0)) / 100, 2);
            $label = $cur . ' from ' . $min . ' · variable';
        } else {
            $price = number_format(((int) ($opt['price_cents'] ?? $v['price_cents'] ?? 0)) / 100, 2);
            $billing = ($opt['billing'] ?? '') === 'recurring'
                ? (' / ' . ($opt['interval'] ?? 'month'))
                : '';
            $label = $cur . ' ' . $price . $billing;
        }
        return '<span class="ft-list-text">' . htmlspecialchars($label . ' · ' . $fulfillment) . '</span>';
    }

    public function getConfigUI($fieldIndex, $existingData = []): string
    {
        return <<<'HTML'
            <div class="field-config-section commerce-field-config">
                <p class="form-text"><strong>Profiles</strong> control fulfillment, intervals, and panels. Manage them in <strong>Commerce → Settings → Fieldtypes</strong>, then pick the matching type (e.g. <code>commerce_donation</code>) when adding this field.</p>
                <p class="form-text">On each entry you can set fixed prices, subscriptions, or <strong>variable pricing</strong> for donations / pay-what-you-want.</p>
            </div>
        HTML;
    }

    private function resolveCommerceSettings(array $config): array
    {
        $typeKey = $config['field_type'] ?? 'commerce';
        if (function_exists('commerce_profile_settings_for_type')) {
            $fromProfile = commerce_profile_settings_for_type($typeKey);
            if (!empty($config['commerce_settings']) && is_array($config['commerce_settings'])) {
                return \CommerceFieldtypeProfileStore::normalizeSettings(
                    array_merge($fromProfile, $config['commerce_settings'])
                );
            }
            return $fromProfile;
        }

        $defaults = \CommerceFieldtypeProfileStore::defaultSettings();
        $fromConfig = $config['commerce_settings'] ?? [];
        if (!is_array($fromConfig)) {
            return $defaults;
        }
        return \CommerceFieldtypeProfileStore::normalizeSettings(array_merge($defaults, $fromConfig));
    }
}
