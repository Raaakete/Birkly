(function () {
  'use strict';

  var API = (typeof Birkly !== 'undefined' && typeof Birkly.url === 'function')
    ? Birkly.url('/api/index.php?route=payments')
    : '/api/index.php?route=payments';
  var providers = [];
  var connections = [];

  var CREDENTIAL_SCHEMAS = {
    stripe: [
      { key: 'secret_key', label: 'Secret Key', type: 'password', required: true },
    ],
    mollie: [
      { key: 'api_key', label: 'API Key', type: 'password', required: true },
    ],
    paypal: [
      { key: 'client_id', label: 'Client ID', type: 'text', required: true },
      { key: 'client_secret', label: 'Client Secret', type: 'password', required: true },
    ],
    adyen: [
      { key: 'api_key', label: 'API Key', type: 'password', required: true },
      { key: 'merchant_account', label: 'Merchant Account', type: 'text', required: true },
      { key: 'hmac_key', label: 'HMAC Key (webhooks)', type: 'password' },
    ],
    square: [
      { key: 'access_token', label: 'Access Token', type: 'password', required: true },
      { key: 'location_id', label: 'Location ID', type: 'text', required: true },
    ],
    razorpay: [
      { key: 'key_id', label: 'Key ID', type: 'text', required: true },
      { key: 'key_secret', label: 'Key Secret', type: 'password', required: true },
    ],
    komoju: [
      { key: 'secret_key', label: 'Secret Key', type: 'password', required: true },
    ],
    payssion: [
      { key: 'api_key', label: 'API Key', type: 'text', required: true },
      { key: 'secret_key', label: 'Secret Key', type: 'password', required: true },
    ],
  };

  function csrfToken() {
    return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
  }

  function showFeedback(message, type) {
    type = type || 'info';
    if (window.Birkly && Birkly.Utils && typeof Birkly.Utils.showToast === 'function') {
      Birkly.Utils.showToast(message, type);
      return;
    }
    if (window.Birkly && Birkly.Utils && typeof Birkly.Utils.showMessage === 'function') {
      Birkly.Utils.showMessage(message, type);
      return;
    }
    alert(message);
  }

  function apiCall(action, data, method) {
    method = method || 'POST';
    var url = API + '&action=' + encodeURIComponent(action);
    var opts = {
      method: method,
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
    };
    if (method === 'POST') {
      opts.body = JSON.stringify(Object.assign({ action: action, _csrf: csrfToken() }, data || {}));
    }
    return fetch(url, opts).then(function (r) {
      return r.text().then(function (text) {
        var parsed = null;
        try {
          parsed = text ? JSON.parse(text) : null;
        } catch (e) {
          throw new Error('Payments API returned non-JSON (HTTP ' + r.status + '). Redeploy/sync Commerce if Save does nothing.');
        }
        if (!r.ok && (!parsed || !parsed.message)) {
          throw new Error('Payments API failed (HTTP ' + r.status + ')');
        }
        return parsed || { status: 'error', message: 'Empty response' };
      });
    });
  }

  function initTabs() {
    // Standalone Payments page only — Commerce owns its own tab switcher.
    if (document.querySelector('.commerce-page')) return;
    var topTabs = document.querySelectorAll('.payments-page > .tabs-root .tab[data-tab]');
    if (!topTabs.length) return;
    topTabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var name = tab.getAttribute('data-tab');
        topTabs.forEach(function (t) {
          var on = t === tab;
          t.classList.toggle('active', on);
          t.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        document.querySelectorAll('.payments-page > .tab-panel').forEach(function (panel) {
          var isActive = panel.id === 'payments-tab-' + name;
          panel.classList.toggle('active', isActive);
          panel.hidden = !isActive;
        });
      });
    });
  }

  function providerIsConfigured(providerId) {
    if (connections.some(function (c) {
      return c.provider === providerId && c.enabled !== false;
    })) {
      return true;
    }
    var provider = providers.find(function (p) { return p.id === providerId; });
    return !!(provider && provider.configured);
  }

  function renderProviderMatrix() {
    var el = document.getElementById('payments-providers-matrix');
    if (!el) return;
    if (!providers.length) {
      el.innerHTML = '<div class="empty-state">No providers registered</div>';
      return;
    }
    el.innerHTML = providers.map(function (p) {
      var caps = p.capabilities || {};
      var features = caps.features || {};
      var cert = p.certification || {};
      var configured = providerIsConfigured(p.id);
      var featList = [];
      if (features.refunds) featList.push('Refunds');
      if (features.subscriptions) featList.push('Subscriptions');
      if (features.capture) featList.push('Capture');
      return (
        '<div class="payments-provider-card ' + escapeHtml(certClass(cert)) + '">' +
        '<h3>' + escapeHtml(p.name) + '</h3>' +
        '<div class="payments-provider-card__badges">' +
        '<span class="badge ' + (configured ? 'badge-success' : 'badge-neutral') + '">' +
        (configured ? 'Connected' : 'Not connected') + '</span>' +
        '<span class="badge ' + escapeHtml(certBadgeTone(cert)) + '">' + escapeHtml(certLabel(cert)) + '</span>' +
        '</div>' +
        '<ul><li>Currencies: ' + escapeHtml((caps.currencies || []).slice(0, 4).join(', ')) + '</li>' +
        '<li>Methods: ' + escapeHtml((caps.methods || []).slice(0, 4).join(', ')) + '</li>' +
        (featList.length ? '<li>' + escapeHtml(featList.join(', ')) + '</li>' : '') +
        '<li>' + escapeHtml(cert.notes || 'No certification note') + '</li>' +
        '</ul></div>'
      );
    }).join('');
  }

  function renderConnections() {
    var el = document.getElementById('payments-connections-list');
    if (!el) return;
    if (!connections.length) {
      el.innerHTML = '<div class="empty-state">No connections yet. Add one to get started.</div>';
      return;
    }
    el.innerHTML =
      '<table class="table payments-connections-table"><thead><tr>' +
      '<th>Label</th><th>Provider</th><th>Mode</th><th>Certification</th><th>Status</th><th>Webhook URL</th><th></th>' +
      '</tr></thead><tbody>' +
      connections.map(function (c) {
        var cert = c.certification || {};
        var labelCell =
          '<div class="payments-conn-label">' +
          '<span class="payments-conn-label__text">' + escapeHtml(c.label || '') + '</span>' +
          (c.is_default ? '<span class="badge badge-success payments-conn-checkout-badge">Checkout</span>' : '') +
          '</div>';
        var menuItems = '';
        if (!c.is_default && c.enabled) {
          menuItems +=
            '<button type="button" class="payments-conn-menu-item" role="menuitem" data-default="' + escapeHtml(c.id) + '">Set as checkout</button>';
        }
        menuItems +=
          '<button type="button" class="payments-conn-menu-item" role="menuitem" data-toggle-enabled="' + escapeHtml(c.id) + '" data-enabled="' + (c.enabled ? '0' : '1') + '">' +
          (c.enabled ? 'Deactivate' : 'Activate') + '</button>';
        menuItems +=
          '<button type="button" class="payments-conn-menu-item payments-conn-menu-item--danger" role="menuitem" data-delete="' + escapeHtml(c.id) + '">Delete</button>';
        return (
          '<tr class="' + (c.is_default ? 'payments-conn-row--checkout' : '') + '">' +
          '<td>' + labelCell + '</td>' +
          '<td>' + escapeHtml(c.provider || '') + '</td>' +
          '<td>' + escapeHtml(c.mode || 'test') + '</td>' +
          '<td><span class="badge ' + escapeHtml(certBadgeTone(cert)) + '">' + escapeHtml(certLabel(cert)) + '</span></td>' +
          '<td>' + (c.enabled ? 'Enabled' : 'Disabled') + '</td>' +
          '<td><code class="payments-webhook-code">' + escapeHtml(c.webhook_url || '') + '</code></td>' +
          '<td class="payments-actions cell-actions">' +
          '<div class="cell-actions-inner">' +
          '<button type="button" class="btn btn-secondary btn-sm" data-edit="' + escapeHtml(c.id) + '">Edit</button>' +
          '<div class="payments-conn-more-menu">' +
          '<button type="button" class="payments-conn-menu-trigger btn-icon btn-icon-sm" aria-label="Connection actions" title="More actions" aria-expanded="false" aria-haspopup="true">' +
          dotsIcon() +
          '</button>' +
          '<div class="payments-conn-menu" role="menu">' + menuItems + '</div>' +
          '</div></div></td></tr>'
        );
      }).join('') +
      '</tbody></table>';

    el.querySelectorAll('[data-edit]').forEach(function (btn) {
      btn.addEventListener('click', function () { openConnectionModal(btn.getAttribute('data-edit')); });
    });
    el.querySelectorAll('[data-delete]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (confirm('Delete this connection?')) deleteConnection(btn.getAttribute('data-delete'));
      });
    });
    el.querySelectorAll('[data-default]').forEach(function (btn) {
      btn.addEventListener('click', function () { setDefaultConnection(btn.getAttribute('data-default')); });
    });
    el.querySelectorAll('[data-toggle-enabled]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        toggleConnectionEnabled(btn.getAttribute('data-toggle-enabled'), btn.getAttribute('data-enabled') === '1');
      });
    });
    bindConnectionRowMenus(el);
  }

  function clearConnectionMenuPosition(wrap) {
    var menu = wrap.querySelector('.payments-conn-menu');
    if (!menu) return;
    menu.style.top = '';
    menu.style.left = '';
    menu.style.right = '';
    menu.style.bottom = '';
    menu.style.visibility = '';
  }

  function positionConnectionMenu(wrap) {
    var menu = wrap.querySelector('.payments-conn-menu');
    var trigger = wrap.querySelector('.payments-conn-menu-trigger');
    if (!menu || !trigger) return;

    menu.style.visibility = 'hidden';
    menu.style.top = '0';
    menu.style.left = '0';

    var menuRect = menu.getBoundingClientRect();
    var triggerRect = trigger.getBoundingClientRect();
    var gap = 4;
    var margin = 8;
    var spaceBelow = window.innerHeight - triggerRect.bottom - gap;
    var spaceAbove = triggerRect.top - gap;
    var openBelow = spaceBelow >= menuRect.height || spaceBelow >= spaceAbove;
    var top = openBelow
      ? triggerRect.bottom + gap
      : triggerRect.top - menuRect.height - gap;
    var left = triggerRect.right - menuRect.width;
    left = Math.max(margin, Math.min(left, window.innerWidth - menuRect.width - margin));
    top = Math.max(margin, Math.min(top, window.innerHeight - menuRect.height - margin));

    menu.style.top = top + 'px';
    menu.style.left = left + 'px';
    menu.style.visibility = '';
  }

  function closeAllConnectionMenus() {
    document.querySelectorAll('.payments-conn-more-menu.is-open').forEach(function (wrap) {
      wrap.classList.remove('is-open');
      clearConnectionMenuPosition(wrap);
      var trigger = wrap.querySelector('.payments-conn-menu-trigger');
      if (trigger) trigger.setAttribute('aria-expanded', 'false');
    });
  }

  function bindConnectionRowMenus(root) {
    if (!root) return;
    root.querySelectorAll('.payments-conn-more-menu').forEach(function (wrap) {
      var trigger = wrap.querySelector('.payments-conn-menu-trigger');
      if (!trigger || trigger.getAttribute('data-menu-bound') === '1') return;
      trigger.setAttribute('data-menu-bound', '1');
      trigger.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        var isOpen = wrap.classList.contains('is-open');
        closeAllConnectionMenus();
        if (!isOpen) {
          wrap.classList.add('is-open');
          trigger.setAttribute('aria-expanded', 'true');
          positionConnectionMenu(wrap);
        }
      });
    });
  }

  if (!window.__paymentsConnMenuGlobalBound) {
    window.__paymentsConnMenuGlobalBound = true;
    document.addEventListener('click', function () { closeAllConnectionMenus(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeAllConnectionMenus();
    });
    window.addEventListener('resize', function () { closeAllConnectionMenus(); });
    window.addEventListener('scroll', function () { closeAllConnectionMenus(); }, true);
  }

  function dotsIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>';
  }

  function loadProviders() {
    return apiCall('list_providers', {}, 'POST').then(function (res) {
      if (res.status === 'ok') {
        providers = res.data.providers || [];
        renderProviderMatrix();
        populateProviderSelects();
      }
    });
  }

  function loadConnections() {
    return apiCall('list_connections', {}, 'POST').then(function (res) {
      if (res.status === 'ok') {
        connections = res.data.connections || [];
        renderConnections();
        renderProviderMatrix();
      }
    });
  }

  function populateProviderSelects() {
    var selects = [
      document.getElementById('payments-conn-provider'),
      document.getElementById('payments-default-provider'),
      document.getElementById('payments-filter-provider'),
    ];
    selects.forEach(function (sel, idx) {
      if (!sel) return;
      var current = sel.value;
      var opts = idx === 2
        ? '<option value="">All providers</option>'
        : '';
      providers.forEach(function (p) {
        opts += '<option value="' + escapeHtml(p.id) + '">' + escapeHtml(p.name + ' — ' + certLabel(p.certification || {})) + '</option>';
      });
      sel.innerHTML = opts;
      if (current) sel.value = current;
    });
  }

  function renderCredentialFields(providerId, isEdit) {
    var el = document.getElementById('payments-credential-fields');
    if (!el) return;
    var schema = CREDENTIAL_SCHEMAS[providerId] || [{ key: 'api_key', label: 'API Key', type: 'password', required: true }];
    el.innerHTML = schema.map(function (field) {
      var requireField = !!field.required && !isEdit;
      var help = isEdit && field.required
        ? '<p class="form-help">Leave blank to keep the existing secret.</p>'
        : '';
      return (
        '<div class="form-group">' +
        '<label for="cred-' + escapeHtml(field.key) + '">' + escapeHtml(field.label) +
        (requireField ? ' <span class="required">*</span>' : '') + '</label>' +
        '<input type="' + (field.type || 'text') + '" id="cred-' + escapeHtml(field.key) + '" ' +
        'class="input" data-cred-key="' + escapeHtml(field.key) + '" autocomplete="off"' +
        (requireField ? ' required' : '') + '>' +
        help +
        '</div>'
      );
    }).join('');

    var webhookDisplay = document.getElementById('payments-webhook-url-display');
    if (webhookDisplay && providerId) {
      apiCall('get_webhook_url', { provider: providerId }, 'POST').then(function (res) {
        if (res.status === 'ok') {
          webhookDisplay.hidden = false;
          webhookDisplay.innerHTML = '<strong>Webhook URL:</strong><br>' + escapeHtml(res.data.webhook_url);
        }
      }).catch(function () { /* non-fatal */ });
    }
  }

  function showConnectionModal() {
    var modal = document.getElementById('payments-connection-modal');
    if (!modal) return;
    modal.hidden = false;
    modal.classList.add('active');
  }

  function hideConnectionModal() {
    var modal = document.getElementById('payments-connection-modal');
    if (!modal) return;
    modal.classList.remove('active');
    modal.hidden = true;
  }

  function openConnectionModal(id) {
    var modal = document.getElementById('payments-connection-modal');
    var title = document.getElementById('payments-modal-title');
    if (!modal || !title) return;

    document.getElementById('payments-connection-form').reset();
    var testResult = document.getElementById('payments-test-result');
    if (testResult) testResult.hidden = true;

    if (id) {
      title.textContent = 'Edit Connection';
      var conn = connections.find(function (c) { return c.id === id; });
      if (conn) {
        document.getElementById('payments-conn-id').value = conn.id;
        document.getElementById('payments-conn-provider').value = conn.provider;
        document.getElementById('payments-conn-label').value = conn.label || '';
        document.getElementById('payments-conn-mode').value = conn.mode || 'test';
        renderCredentialFields(conn.provider, true);
      }
    } else {
      title.textContent = 'Add Connection';
      document.getElementById('payments-conn-id').value = '';
      var firstProvider = (providers[0] && providers[0].id) ? providers[0].id : 'stripe';
      document.getElementById('payments-conn-provider').value = firstProvider;
      renderCredentialFields(firstProvider, false);
    }

    updateCertificationNotice();
    showConnectionModal();
  }

  function closeConnectionModal() {
    hideConnectionModal();
  }

  function collectCredentials() {
    var creds = {};
    document.querySelectorAll('[data-cred-key]').forEach(function (input) {
      if (input.value) creds[input.getAttribute('data-cred-key')] = input.value;
    });
    return creds;
  }

  function saveConnection(e) {
    e.preventDefault();
    var providerId = document.getElementById('payments-conn-provider').value;
    var mode = document.getElementById('payments-conn-mode').value;
    var existingId = document.getElementById('payments-conn-id').value || '';
    if (mode === 'live' && !isLiveCertified(providerId)) {
      updateCertificationNotice();
      showFeedback(providerName(providerId) + ' is not live-certified for Marketplace v1. Use test mode or choose Stripe/Mollie live.', 'error');
      return;
    }
    var credentials = collectCredentials();
    var connection = {
      id: existingId || undefined,
      provider: providerId,
      label: document.getElementById('payments-conn-label').value,
      mode: mode,
    };
    if (existingId) {
      var existing = connections.find(function (c) { return c.id === existingId; });
      connection.enabled = existing ? existing.enabled !== false : true;
    } else {
      connection.enabled = true;
    }
    // On edit, omit empty credentials so the server keeps existing secrets.
    if (Object.keys(credentials).length > 0) {
      connection.credentials = credentials;
    } else if (!existingId) {
      showFeedback('Enter the provider secret key before saving.', 'error');
      return;
    }
    var webhookSecret = document.getElementById('payments-webhook-secret').value;
    if (webhookSecret) connection.webhook_secret = webhookSecret;

    var saveBtn = document.querySelector('#payments-connection-form button[type="submit"]');
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.textContent = 'Saving…';
    }

    apiCall('save_connection', { connection: connection }).then(function (res) {
      if (res.status === 'ok') {
        closeConnectionModal();
        showFeedback(providerName(providerId) + ' connection saved.', 'success');
        return Promise.all([loadConnections(), loadProviders()]);
      }
      showFeedback(res.message || 'Save failed', 'error');
    }).catch(function (err) {
      showFeedback(err && err.message ? err.message : 'Save failed', 'error');
    }).finally(function () {
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save Connection';
      }
    });
  }

  function testConnection() {
    var provider = document.getElementById('payments-conn-provider').value;
    var creds = collectCredentials();
    if (Object.keys(creds).length === 0) {
      creds.mock = true;
    }
    var resultEl = document.getElementById('payments-test-result');
    apiCall('test_connection', { provider: provider, credentials: creds }).then(function (res) {
      resultEl.hidden = false;
      var ok = res.status === 'ok' && res.data && res.data.ok;
      resultEl.className = 'payments-test-result ' + (ok ? 'success' : 'error');
      resultEl.textContent = ok ? (res.data.message || 'Connection successful') : (res.data?.error || res.message || 'Test failed');
    });
  }

  function deleteConnection(id) {
    apiCall('delete_connection', { id: id }).then(function () { loadConnections(); });
  }

  function setDefaultConnection(id) {
    apiCall('set_default_connection', { id: id }).then(function (res) {
      if (res.status === 'ok') {
        showFeedback(res.message || 'Checkout connection updated.', 'success');
        return loadConnections();
      }
      showFeedback(res.message || 'Could not set checkout connection', 'error');
    }).catch(function (err) {
      showFeedback(err && err.message ? err.message : 'Could not set checkout connection', 'error');
    });
  }

  function toggleConnectionEnabled(id, enable) {
    var conn = connections.find(function (c) { return c.id === id; });
    if (!conn) return;
    apiCall('save_connection', {
      connection: {
        id: conn.id,
        provider: conn.provider,
        label: conn.label,
        mode: conn.mode || 'test',
        enabled: !!enable,
      },
    }).then(function (res) {
      if (res.status === 'ok') {
        showFeedback(enable ? 'Connection activated.' : 'Connection deactivated.', 'success');
        return loadConnections();
      }
      showFeedback(res.message || 'Could not update connection', 'error');
    }).catch(function (err) {
      showFeedback(err && err.message ? err.message : 'Could not update connection', 'error');
    });
  }

  function loadActivity() {
    var provider = document.getElementById('payments-filter-provider')?.value || '';
    var status = document.getElementById('payments-filter-status')?.value || '';
    var filters = {};
    if (provider) filters.provider = provider;
    if (status) filters.status = status;

    apiCall('list_activity', { filters: filters, limit: 100 }).then(function (res) {
      var el = document.getElementById('payments-activity-list');
      if (!el) return;
      var items = (res.data && res.data.activity) || [];
      if (!items.length) {
        el.innerHTML = '<div class="empty-state">No activity yet</div>';
        return;
      }
      el.innerHTML =
        '<table class="table"><thead><tr>' +
        '<th>Time</th><th>Type</th><th>Provider</th><th>Status</th><th>Source</th><th>Message</th>' +
        '</tr></thead><tbody>' +
        items.map(function (a) {
          var statusClass = (a.status || '').toLowerCase();
          return (
            '<tr>' +
            '<td>' + escapeHtml(formatTime(a.timestamp)) + '</td>' +
            '<td>' + escapeHtml(a.type || '') + '</td>' +
            '<td>' + escapeHtml(a.provider || '—') + '</td>' +
            '<td><span class="badge ' + escapeHtml(statusBadgeTone(a.status)) + '">' + escapeHtml(a.status || '—') + '</span></td>' +
            '<td>' + escapeHtml((a.source_plugin || '—') + (a.source_ref ? ':' + a.source_ref : '')) + '</td>' +
            '<td>' + escapeHtml(a.message || '') + '</td>' +
            '</tr>'
          );
        }).join('') +
        '</tbody></table>';
    });
  }

  function saveSettings(e) {
    e.preventDefault();
    var roleSelect = document.getElementById('payments-widget-roles');
    var selectedRoles = roleSelect
      ? Array.from(roleSelect.selectedOptions).map(function (o) { return o.value; })
      : ['admin'];
    if (!selectedRoles.length) {
      selectedRoles = ['admin'];
    }
    var settings = {
      selection_mode: document.getElementById('payments-selection-mode').value,
      default_provider: document.getElementById('payments-default-provider').value,
      enable_dashboard_widget: document.getElementById('payments-enable-widget').checked,
      dashboard_widget_roles: selectedRoles,
      dunning_email_enabled: document.getElementById('payments-dunning-email-enabled')?.checked || false,
      dunning_email_subject: document.getElementById('payments-dunning-email-subject')?.value || '',
      dunning_email_body: document.getElementById('payments-dunning-email-body')?.value || '',
      commerce_default_currency: document.getElementById('payments-default-currency')?.value || 'eur',
      commerce_stock_mode: document.getElementById('commerce-stock-mode')?.value || 'simple',
      commerce_fulfillment_sla_hours: parseInt(document.getElementById('commerce-fulfillment-sla-hours')?.value || '48', 10) || 48,
      commerce_customer_cancel_enabled: !!document.getElementById('commerce-customer-cancel-enabled')?.checked,
      commerce_customer_cancel_window_hours: parseInt(document.getElementById('commerce-customer-cancel-window-hours')?.value || '24', 10) || 0,
      commerce_customer_subscription_self_service_enabled: !!document.getElementById('commerce-customer-subscription-self-service')?.checked,
      commerce_customer_subscription_pause_enabled: !!document.getElementById('commerce-customer-subscription-pause')?.checked,
      commerce_customer_subscription_cancel_enabled: !!document.getElementById('commerce-customer-subscription-cancel')?.checked,
      commerce_store_name: document.getElementById('commerce-store-name')?.value?.trim() || '',
      commerce_display_currency: document.getElementById('payments-display-currency')?.value || '',
      commerce_fx_rates: document.getElementById('payments-fx-rates')?.value || '',
      activity_notify: document.getElementById('commerce-activity-notify')
        ? !!document.getElementById('commerce-activity-notify').checked
        : true,
      activity_nav_dot: document.getElementById('commerce-activity-nav-dot')
        ? !!document.getElementById('commerce-activity-nav-dot').checked
        : true,
      commerce_entry_sync_entry_id_meta: document.getElementById('commerce-entry-sync-entry-id-meta')?.value?.trim() || '',
      commerce_entry_sync_collection_meta: document.getElementById('commerce-entry-sync-collection-meta')?.value?.trim() || '',
      commerce_entry_sync_consent_meta: document.getElementById('commerce-entry-sync-consent-meta')?.value?.trim() || '',
      commerce_entry_sync_order_field: document.getElementById('commerce-entry-sync-order-field')?.value?.trim() || '',
      commerce_entry_sync_payment_field: document.getElementById('commerce-entry-sync-payment-field')?.value?.trim() || '',
      commerce_entry_sync_session_field: document.getElementById('commerce-entry-sync-session-field')?.value?.trim() || '',
      commerce_entry_sync_paid_value: document.getElementById('commerce-entry-sync-paid-value')?.value?.trim() || '',
      commerce_entry_sync_abandoned_value: document.getElementById('commerce-entry-sync-abandoned-value')?.value?.trim() || '',
    };
    apiCall('save_settings', { settings: settings }).then(function (res) {
      if (res.status === 'ok') {
        alert('Settings saved');
      }
    });
  }

  function loadSettings() {
    apiCall('get_settings', {}, 'GET').then(function (res) {
      if (res.status !== 'ok' || !res.data || !res.data.settings) return;
      var s = res.data.settings;
      var modeEl = document.getElementById('payments-selection-mode');
      if (modeEl && s.selection_mode) modeEl.value = s.selection_mode;
      var defEl = document.getElementById('payments-default-provider');
      if (defEl && s.default_provider) defEl.value = s.default_provider;
      var widgetEl = document.getElementById('payments-enable-widget');
      if (widgetEl) widgetEl.checked = !!s.enable_dashboard_widget;
      var rolesEl = document.getElementById('payments-widget-roles');
      if (rolesEl && Array.isArray(s.dashboard_widget_roles)) {
        Array.from(rolesEl.options).forEach(function (opt) {
          opt.selected = s.dashboard_widget_roles.indexOf(opt.value) !== -1;
        });
      }
      var dunningEnabled = document.getElementById('payments-dunning-email-enabled');
      if (dunningEnabled) dunningEnabled.checked = !!s.dunning_email_enabled;
      var dunningSubject = document.getElementById('payments-dunning-email-subject');
      if (dunningSubject && s.dunning_email_subject) dunningSubject.value = s.dunning_email_subject;
      var dunningBody = document.getElementById('payments-dunning-email-body');
      if (dunningBody && s.dunning_email_body) dunningBody.value = s.dunning_email_body;
      var defaultCurrency = document.getElementById('payments-default-currency');
      if (defaultCurrency && s.commerce_default_currency) defaultCurrency.value = s.commerce_default_currency;
      var stockMode = document.getElementById('commerce-stock-mode');
      if (stockMode && s.commerce_stock_mode) stockMode.value = s.commerce_stock_mode;
      var slaHours = document.getElementById('commerce-fulfillment-sla-hours');
      if (slaHours) slaHours.value = String(s.commerce_fulfillment_sla_hours || 48);
      var customerCancel = document.getElementById('commerce-customer-cancel-enabled');
      if (customerCancel) customerCancel.checked = !!s.commerce_customer_cancel_enabled;
      var customerCancelWindow = document.getElementById('commerce-customer-cancel-window-hours');
      if (customerCancelWindow) {
        customerCancelWindow.value = String(
          s.commerce_customer_cancel_window_hours === null || s.commerce_customer_cancel_window_hours === undefined
            ? 24
            : s.commerce_customer_cancel_window_hours
        );
      }
      var customerSubSelf = document.getElementById('commerce-customer-subscription-self-service');
      if (customerSubSelf) customerSubSelf.checked = s.commerce_customer_subscription_self_service_enabled !== false;
      var customerSubPause = document.getElementById('commerce-customer-subscription-pause');
      if (customerSubPause) customerSubPause.checked = s.commerce_customer_subscription_pause_enabled !== false;
      var customerSubCancel = document.getElementById('commerce-customer-subscription-cancel');
      if (customerSubCancel) customerSubCancel.checked = s.commerce_customer_subscription_cancel_enabled !== false;
      var storeName = document.getElementById('commerce-store-name');
      if (storeName) storeName.value = s.commerce_store_name || '';
      var displayCurrency = document.getElementById('payments-display-currency');
      if (displayCurrency) displayCurrency.value = s.commerce_display_currency || '';
      var fxRates = document.getElementById('payments-fx-rates');
      if (fxRates) {
        if (typeof s.commerce_fx_rates === 'string') fxRates.value = s.commerce_fx_rates;
        else if (s.commerce_fx_rates && typeof s.commerce_fx_rates === 'object') fxRates.value = JSON.stringify(s.commerce_fx_rates);
      }
      var activityNotify = document.getElementById('commerce-activity-notify');
      if (activityNotify) activityNotify.checked = s.activity_notify !== false;
      var activityNavDot = document.getElementById('commerce-activity-nav-dot');
      if (activityNavDot) activityNavDot.checked = s.activity_nav_dot !== false;
      var entrySyncFields = [
        ['commerce-entry-sync-entry-id-meta', 'commerce_entry_sync_entry_id_meta', 'supporter_entry_id'],
        ['commerce-entry-sync-collection-meta', 'commerce_entry_sync_collection_meta', 'entry_collection'],
        ['commerce-entry-sync-consent-meta', 'commerce_entry_sync_consent_meta', 'featured'],
        ['commerce-entry-sync-order-field', 'commerce_entry_sync_order_field', 'order_id'],
        ['commerce-entry-sync-payment-field', 'commerce_entry_sync_payment_field', 'payment_status'],
        ['commerce-entry-sync-session-field', 'commerce_entry_sync_session_field', 'stripe_session'],
        ['commerce-entry-sync-paid-value', 'commerce_entry_sync_paid_value', 'paid'],
        ['commerce-entry-sync-abandoned-value', 'commerce_entry_sync_abandoned_value', 'abandoned'],
      ];
      entrySyncFields.forEach(function (row) {
        var el = document.getElementById(row[0]);
        if (!el) return;
        var val = s[row[1]];
        el.value = (val != null && String(val).trim() !== '') ? String(val) : row[2];
      });
    });
  }

  function formatTime(ts) {
    if (!ts) return '—';
    try { return new Date(ts).toLocaleString(); } catch (e) { return ts; }
  }

  function escapeHtml(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function providerById(id) {
    return providers.find(function (p) { return p.id === id; }) || null;
  }

  function providerName(id) {
    var provider = providerById(id);
    return provider ? (provider.name || id) : id;
  }

  function certLabel(cert) {
    if (cert.live_mode) return 'Live certified';
    if (cert.test_mode) return 'Sandbox only';
    return 'Uncertified';
  }

  function statusBadgeTone(status) {
    var s = String(status || '').toLowerCase();
    if (s === 'succeeded' || s === 'paid' || s === 'captured') return 'badge-success';
    if (s === 'pending' || s === 'open') return 'badge-warning';
    if (s === 'failed' || s === 'refunded') return 'badge-danger';
    return 'badge-neutral';
  }

  function certBadgeTone(cert) {
    var c = certClass(cert);
    if (c === 'certified') return 'badge-success';
    if (c === 'sandbox-only') return 'badge-warning';
    if (c === 'uncertified') return 'badge-danger';
    return 'badge-neutral';
  }

  function certClass(cert) {
    if (cert.live_mode) return 'certified';
    if (cert.test_mode) return 'sandbox-only';
    return 'uncertified';
  }

  function isLiveCertified(providerId) {
    var provider = providerById(providerId);
    return !!(provider && provider.certification && provider.certification.live_mode);
  }

  function updateCertificationNotice() {
    var notice = document.getElementById('payments-certification-notice');
    var providerSel = document.getElementById('payments-conn-provider');
    var modeSel = document.getElementById('payments-conn-mode');
    if (!notice || !providerSel || !modeSel) return;
    var provider = providerById(providerSel.value);
    var cert = (provider && provider.certification) || {};
    notice.hidden = false;
    notice.className = 'payments-certification-notice ' + certClass(cert);
    if (modeSel.value === 'live' && !cert.live_mode) {
      notice.textContent = cert.notes || 'This provider is not live-certified for Marketplace v1. Save is blocked in live mode.';
      return;
    }
    if (modeSel.value === 'live') {
      notice.textContent = 'Live mode is certified for Marketplace v1 one-time payments. Recurring remains globally gated.';
      return;
    }
    notice.textContent = cert.test_mode
      ? 'Test/sandbox mode is available. Live mode requires Marketplace v1 certification.'
      : 'This provider is not certified for Marketplace v1.';
  }

  function init() {
    initTabs();
    loadProviders().then(function () {
      loadConnections();
      loadSettings();
    });

    document.getElementById('payments-add-connection')?.addEventListener('click', function () { openConnectionModal(null); });
    document.getElementById('payments-modal-close')?.addEventListener('click', closeConnectionModal);
    document.getElementById('payments-connection-form')?.addEventListener('submit', saveConnection);
    document.getElementById('payments-test-conn')?.addEventListener('click', testConnection);
    document.getElementById('payments-conn-provider')?.addEventListener('change', function (e) {
      var editing = !!(document.getElementById('payments-conn-id')?.value);
      renderCredentialFields(e.target.value, editing);
      updateCertificationNotice();
    });
    document.getElementById('payments-conn-mode')?.addEventListener('change', updateCertificationNotice);
    document.getElementById('payments-refresh-activity')?.addEventListener('click', loadActivity);
    document.getElementById('payments-settings-form')?.addEventListener('submit', saveSettings);

    document.getElementById('payments-connection-modal')?.addEventListener('click', function (e) {
      if (e.target === e.currentTarget) closeConnectionModal();
    });
  }

  window.loadPaymentsActivity = loadActivity;
  window.loadCommercePaymentsData = function () {
    return loadProviders().then(function () {
      return Promise.all([loadConnections(), loadSettings()]);
    });
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
