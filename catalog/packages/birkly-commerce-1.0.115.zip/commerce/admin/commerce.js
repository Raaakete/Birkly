(function () {
  'use strict';

  var COMMERCE_API = (typeof Birkly !== 'undefined' && typeof Birkly.url === 'function')
    ? Birkly.url('/api/index.php?route=commerce')
    : '/api/index.php?route=commerce';

  function commercePost(action, body) {
    body = body || {};
    body.action = action;
    var csrf = (typeof Birkly !== 'undefined' && Birkly.csrfToken)
      ? Birkly.csrfToken
      : (document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '');
    if (csrf) {
      body._csrf = csrf;
    }
    return fetch(COMMERCE_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(body),
    }).then(function (r) {
      return r.text().then(function (text) {
        var data;
        try {
          data = text ? JSON.parse(text) : {};
        } catch (err) {
          throw new Error(text ? text.slice(0, 180) : ('HTTP ' + r.status));
        }
        if (r.status === 403 && data && data.message) {
          data.status = data.status || 'error';
          data.permission_denied = true;
        }
        if (!r.ok && (!data || !data.status)) {
          data = data || {};
          data.status = data.status || 'error';
          data.message = data.message || ('HTTP ' + r.status);
        }
        return data;
      });
    });
  }

  function commerceToast(message, isError) {
    if (typeof Birkly !== 'undefined' && typeof Birkly.toast === 'function') {
      Birkly.toast(message, isError ? 'error' : 'success');
      return;
    }
    if (isError) {
      alert(message);
    }
  }

  function commerceErrorMessage(res) {
    if (!res) return 'Unknown error';
    var msg = res.message || res.error;
    if (msg && typeof msg === 'object') {
      msg = msg.message || msg.error || JSON.stringify(msg);
    }
    return String(msg || 'Unknown error');
  }

  function formatCents(cents, currency) {
    return (currency || 'EUR').toUpperCase() + ' ' + (Number(cents) / 100).toFixed(2);
  }

  var SEEN_ORDERS_KEY = 'commerce_orders_seen_at';
  var SEEN_SUBS_KEY = 'commerce_subscriptions_seen_at';
  var activityPollTimer = null;

  function getSeenAt(key) {
    try { return localStorage.getItem(key) || ''; } catch (e) { return ''; }
  }

  function markSeenAt(key) {
    try { localStorage.setItem(key, new Date().toISOString()); } catch (e) { /* ignore */ }
  }

  function setTabBadge(name, count) {
    var badge = document.querySelector('.commerce-tabs .commerce-tab-badge[data-badge="' + name + '"]');
    var tab = document.querySelector('.commerce-tabs .tab[data-tab="' + name + '"]');
    if (!badge || !tab) return;
    var n = Number(count) || 0;
    if (n > 0) {
      badge.textContent = n > 99 ? '99+' : String(n);
      badge.hidden = false;
      tab.classList.add('has-new-activity');
    } else {
      badge.textContent = '';
      badge.hidden = true;
      tab.classList.remove('has-new-activity');
    }
  }

  function refreshActivityBadges() {
    return commercePost('activity_counts', {
      orders_seen_at: getSeenAt(SEEN_ORDERS_KEY),
      subscriptions_seen_at: getSeenAt(SEEN_SUBS_KEY),
    }).then(function (res) {
      var data = (res && res.data) || {};
      // P61: when sidebar/nav activity is disabled, clear in-plugin badges too.
      if (data.activity_nav_dot === false) {
        setTabBadge('orders', 0);
        setTabBadge('subscriptions', 0);
        setTabBadge('fulfillment', 0);
        return data;
      }
      setTabBadge('orders', data.orders_new || 0);
      setTabBadge('subscriptions', data.subscriptions_new || 0);
      setTabBadge('fulfillment', data.fulfillment_open || 0);
      return data;
    }).catch(function () { /* non-fatal */ });
  }

  function startActivityPolling() {
    if (activityPollTimer) return;
    refreshActivityBadges();
    activityPollTimer = setInterval(refreshActivityBadges, 30000);
  }

  function adminPageUrl(page, params) {
    var url = new URL(window.location.href);
    url.hash = '';
    url.search = '';
    url.searchParams.set('page', page);
    Object.keys(params || {}).forEach(function (key) {
      if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
        url.searchParams.set(key, params[key]);
      }
    });
    return url.pathname + url.search;
  }

  function catalogEntryUrl(item) {
    var collection = item && item.collection_slug;
    var entry = item && (item.entry_id || item.entry_slug);
    if (!collection || !entry) return '';
    return adminPageUrl('entry-detail', { collection: collection, entry: entry });
  }

  function inventorySkuHash(sku) {
    if (!sku) return '#inventory';
    return '#inventory/sku/' + encodeURIComponent(sku);
  }

  function renderCatalogActions(item) {
    var links = [];
    var entryUrl = catalogEntryUrl(item);
    if (entryUrl) {
      links.push('<a href="' + escapeHtml(entryUrl) + '">CMS entry</a>');
    }
    if (item && item.sku) {
      links.push('<a href="' + escapeHtml(inventorySkuHash(item.sku)) + '">Inventory</a>');
    }
    return links.length ? links.join(' · ') : '—';
  }

  function loadCatalog() {
    var el = document.getElementById('commerce-catalog-list');
    if (!el) return;
    el.innerHTML = '<div class="loading-state"><p>Loading catalog…</p></div>';
    commercePost('list_catalog').then(function (res) {
      if (res.status !== 'ok') {
        el.innerHTML = '<p class="error">Failed to load catalog</p>';
        return;
      }
      var items = (res.data && res.data.catalog) || [];
      if (!items.length) {
        el.innerHTML = '<p class="field-help">No sellable CMS entries are indexed yet. Add a Commerce field to an entry, publish it, then rebuild the catalog if needed.</p>';
        return;
      }
      var html = '<p class="field-help">Available is projected from Inventory. ∞ means unlimited (no stock row, or Unlimited mode). Stock code is the SKU used to count inventory.</p>';
      html += '<div class="table-container"><table class="table"><thead><tr><th>Title</th><th>Collection</th><th>Price</th><th>Available</th><th>Stock code</th><th>Links</th></tr></thead><tbody>';
      items.forEach(function (item) {
        var available = item.quantity_available === null || item.quantity_available === undefined
          ? '∞'
          : item.quantity_available;
        var entryUrl = catalogEntryUrl(item);
        var title = escapeHtml(item.entry_title || item.entry_slug || item.entry_id || 'Untitled');
        if (entryUrl) title = '<a href="' + escapeHtml(entryUrl) + '">' + title + '</a>';
        html += '<tr><td>' + title + '</td><td>' + escapeHtml(item.collection_slug || '—') + '</td><td>'
          + escapeHtml(formatCents(item.price_cents, item.currency)) + '</td><td>' + escapeHtml(available) + '</td><td><code class="commerce-sku">'
          + escapeHtml(item.sku || '—') + '</code></td><td>' + renderCatalogActions(item) + '</td></tr>';
      });
      html += '</tbody></table></div>';
      el.innerHTML = html;
    });
  }

  var ordersCache = [];
  var ordersFilter = 'active';
  var ordersSearch = '';
  var selectedOrderIds = {};
  var subscriptionsCache = [];
  var subscriptionsSearch = '';
  var subscriptionsFilter = 'all';
  var expandedOrders = {};
  var expandedSubs = {};
  var currentOrderDetail = null;
  var currentSubscriptionDetail = null;

  function eventEl(e) {
    var t = e && e.target;
    if (!t) return null;
    if (t instanceof Element) return t;
    return t.parentElement || null;
  }

  function orderStatusBadge(status) {
    var s = status || 'unknown';
    var tone = 'neutral';
    if (s === 'paid' || s === 'fulfilled' || s === 'completed' || s === 'active' || s === 'captured') tone = 'success';
    else if (s === 'pending' || s === 'processing' || s === 'partially_fulfilled' || s === 'on_hold') tone = 'warning';
    else if (s === 'cancelled' || s === 'canceled' || s === 'failed' || s === 'refunded') tone = 'danger';
    else if (s === 'open' || s === 'needs_shipping') tone = 'info';
    return '<span class="badge badge-' + tone + '">' + escapeHtml(String(s || '').replace(/_/g, ' ')) + '</span>';
  }

  function orderItemsSummary(order) {
    var lines = order.lines || [];
    if (!lines.length) return 'No items';
    var titles = lines.map(function (line) {
      return (line.title || line.entry_id || 'Item') + (Number(line.quantity) > 1 ? ' ×' + line.quantity : '');
    });
    if (titles.length === 1) return titles[0];
    return titles[0] + ' +' + (titles.length - 1) + ' more';
  }

  function customerName(record) {
    var addr = record && record.shipping_address;
    if (addr && addr.name) return String(addr.name).trim();
    if (record && record.customer_name) return String(record.customer_name).trim();
    if (record && record.attendee_name) return String(record.attendee_name).trim();
    return '';
  }

  function customerEmail(record) {
    return (record && record.customer_email) ? String(record.customer_email).trim() : '';
  }

  function customerSummary(record) {
    var name = customerName(record);
    var email = customerEmail(record);
    if (name && email) return name + ' · ' + email;
    return name || email || 'No customer';
  }

  function renderCustomerBlock(record, options) {
    options = options || {};
    var name = customerName(record);
    var email = customerEmail(record);
    var addr = record.shipping_address || null;
    var html = '<div class="commerce-customer-block">';
    if (!options.skipHeading) html += '<h4>Customer</h4>';
    html += '<p><strong>' + escapeHtml(name || '—') + '</strong></p>';
    html += '<p class="commerce-order-meta">' + escapeHtml(email || 'No email') + '</p>';
    if (addr) {
      html += '<p class="commerce-order-meta">' + escapeHtml(formatShippingAddress(addr)) + '</p>';
    } else if (!options.allowMissingAddress) {
      html += '<p class="commerce-order-meta">No shipping address on file.</p>';
    }
    if (record.attendee_name && record.attendee_name !== name) {
      html += '<p class="commerce-order-meta">Attendee: ' + escapeHtml(record.attendee_name) + '</p>';
    }
    if (record.vat_id || record.tax_id) {
      html += '<p class="commerce-order-meta"><strong>VAT ID:</strong> '
        + escapeHtml(record.vat_id || record.tax_id) + '</p>';
    }
    html += '</div>';
    return html;
  }

  function productIdParts(line) {
    var parts = [];
    if (line.entry_id) parts.push('ID ' + line.entry_id);
    if (line.sku) parts.push('SKU ' + line.sku);
    if (line.collection_slug) parts.push(line.collection_slug);
    if (line.entry_slug) parts.push(line.entry_slug);
    if (line.purchase_option_id) parts.push('option ' + line.purchase_option_id);
    if (line.line_id) parts.push('line ' + line.line_id);
    return parts;
  }

  function renderProductIds(line) {
    var parts = productIdParts(line);
    if (!parts.length) return '';
    return '<div class="commerce-product-ids">' + escapeHtml(parts.join(' · ')) + '</div>';
  }

  function haystackForOrder(order) {
    var chunks = [
      order.id, order.order_number, order.customer_email, order.customer_name, order.attendee_name,
      order.payment_id, order.status, order.coupon_code, order.vat_id, order.tax_id
    ];
    var addr = order.shipping_address || {};
    chunks.push(addr.name, addr.line1, addr.city, addr.postal_code, addr.country);
    if (Array.isArray(order.tags)) chunks = chunks.concat(order.tags);
    (order.notes || []).forEach(function (n) { if (n && n.body) chunks.push(n.body); });
    (order.lines || []).forEach(function (line) {
      chunks.push(line.title, line.entry_id, line.sku, line.collection_slug, line.entry_slug,
        line.purchase_option_id, line.purchase_option_label, line.line_id, line.tracking_number, line.carrier);
      chunks = chunks.concat(productIdParts(line));
    });
    return chunks.filter(Boolean).join(' ').toLowerCase();
  }

  function haystackForSubscription(sub) {
    var chunks = [
      sub.id, sub.customer_email, sub.customer_name, sub.order_id, sub.status,
      sub.interval, sub.purchase_option_id, sub.line_id, sub.provider
    ];
    (sub.lines || []).forEach(function (line) {
      chunks.push(line.title, line.entry_id, line.sku, line.collection_slug, line.entry_slug,
        line.purchase_option_id, line.purchase_option_label, line.line_id);
      chunks = chunks.concat(productIdParts(line));
    });
    return chunks.filter(Boolean).join(' ').toLowerCase();
  }

  function matchesSearch(haystack, query) {
    query = String(query || '').trim().toLowerCase();
    if (!query) return true;
    return query.split(/\s+/).every(function (token) {
      return !token || haystack.indexOf(token) !== -1;
    });
  }

  /**
   * Print/invoice documents via blob URLs (not document.write on about:blank).
   *
   * Never pass `noopener` in windowFeatures — browsers then return null from
   * window.open while still opening an empty tab, which caused the false
   * "Pop-up blocked" toast and blank packing slips.
   */
  function htmlBlobUrl(html) {
    return URL.createObjectURL(new Blob([html], { type: 'text/html;charset=utf-8' }));
  }

  function revokeLater(url) {
    setTimeout(function () {
      try { URL.revokeObjectURL(url); } catch (e) { /* ignore */ }
    }, 120000);
  }

  function openBlankDocumentWindow() {
    // No feature string: some browsers treat feature lists as a different open path.
    var win = window.open('about:blank', '_blank');
    if (win) {
      try { win.opener = null; } catch (e) { /* ignore */ }
    }
    return win;
  }

  function navigateWindowToHtml(win, html) {
    if (!win || win.closed) return false;
    try {
      var url = htmlBlobUrl(html);
      win.location.href = url;
      revokeLater(url);
      try { win.focus(); } catch (e) { /* ignore */ }
      return true;
    } catch (err) {
      return false;
    }
  }

  /** Last resort: same-page iframe print (no second window). */
  function printHtmlInPage(html) {
    var iframe = document.getElementById('commerce-print-frame');
    if (!iframe) {
      iframe = document.createElement('iframe');
      iframe.id = 'commerce-print-frame';
      iframe.title = 'Print preview';
      iframe.setAttribute('aria-hidden', 'true');
      iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none';
      document.body.appendChild(iframe);
    }
    var idoc = iframe.contentDocument || (iframe.contentWindow && iframe.contentWindow.document);
    if (!idoc) {
      downloadTextFile('commerce-document.html', html, 'text/html;charset=utf-8');
      alert('Opened as a download instead — open the HTML file to print.');
      return;
    }
    idoc.open();
    idoc.write(html);
    idoc.close();
    setTimeout(function () {
      try {
        iframe.contentWindow.focus();
        iframe.contentWindow.print();
      } catch (e) {
        downloadTextFile('commerce-document.html', html, 'text/html;charset=utf-8');
        alert('Could not print in-page — downloaded the HTML file instead.');
      }
    }, 250);
  }

  function presentHtmlDocument(html, filename, reservedWin) {
    if (reservedWin && !reservedWin.closed && navigateWindowToHtml(reservedWin, html)) {
      return;
    }
    if (reservedWin && !reservedWin.closed) {
      try { reservedWin.close(); } catch (e) { /* ignore */ }
    }
    var url = htmlBlobUrl(html);
    var opened = window.open(url, '_blank');
    if (opened) {
      try { opened.opener = null; } catch (e) { /* ignore */ }
      revokeLater(url);
      return;
    }
    try { URL.revokeObjectURL(url); } catch (e2) { /* ignore */ }
    printHtmlInPage(html);
  }

  function openHtmlDocument(html, filename) {
    presentHtmlDocument(html, filename, null);
  }

  /**
   * Reserve a tab on click (user gesture), then navigate it to a blob URL
   * when the async packing-slip/invoice HTML arrives.
   */
  function openHtmlDocumentAsync(promise, filename) {
    var win = openBlankDocumentWindow();
    if (win) {
      try {
        win.document.open();
        win.document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Loading…</title></head>'
          + '<body style="font-family:system-ui,sans-serif;padding:2rem;color:#444">Preparing document…</body></html>');
        win.document.close();
      } catch (e) { /* ignore — blob navigation still works */ }
    }
    return Promise.resolve(promise).then(function (html) {
      if (!html) {
        if (win) try { win.close(); } catch (e) { /* ignore */ }
        throw new Error('Empty document');
      }
      presentHtmlDocument(html, filename, win);
    }, function (err) {
      if (win) try { win.close(); } catch (e) { /* ignore */ }
      throw err;
    });
  }

  function openPrintWindow(title, bodyHtml) {
    var html = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>'
      + escapeHtml(title) + '</title><style>'
      + 'body{font-family:Georgia,serif;color:#111;margin:24px;line-height:1.45}'
      + 'h1,h2,h3{font-family:system-ui,sans-serif;margin:0 0 .5rem}'
      + '.meta{color:#444;font-size:13px;margin-bottom:1rem}'
      + 'table{width:100%;border-collapse:collapse;margin:1rem 0}'
      + 'th,td{border-bottom:1px solid #ddd;padding:8px 6px;text-align:left;font-size:13px;vertical-align:top}'
      + '.right{text-align:right}'
      + '.section{margin:1.25rem 0}'
      + '.muted{color:#666;font-size:12px}'
      + '@media print{body{margin:12mm}}'
      + '</style></head><body class="commerce-print-root">'
      + bodyHtml + '<script>window.onload=function(){window.focus();window.print();}<\/script></body></html>';
    openHtmlDocument(html, 'commerce-print.html');
  }

  function printOrderDocument(order) {
    if (!order) return;
    var rows = (order.lines || []).map(function (line) {
      return '<tr><td><strong>' + escapeHtml(line.title || 'Item') + '</strong><div class="muted">'
        + escapeHtml(productIdParts(line).join(' · ')) + '</div></td><td>'
        + escapeHtml(String(line.quantity || 1)) + '</td><td class="right">'
        + escapeHtml(formatCents(lineAmount(line), order.currency)) + '</td></tr>';
    }).join('');
    var html = '<h1>Order ' + escapeHtml(orderDisplayNumber(order)) + '</h1>'
      + '<div class="meta">' + escapeHtml(order.status || '') + ' · '
      + escapeHtml(formatOrderDate(order.created_at)) + '<br>Internal: '
      + escapeHtml(order.id || '') + '</div>'
      + '<div class="section"><h2>Customer</h2>'
      + '<div>' + escapeHtml(customerName(order) || '—') + '</div>'
      + '<div>' + escapeHtml(customerEmail(order) || '') + '</div>'
      + '<div>' + escapeHtml(formatShippingAddress(order.shipping_address || {}) || 'No shipping address') + '</div></div>'
      + '<div class="section"><h2>Items</h2><table><thead><tr><th>Product</th><th>Qty</th><th class="right">Amount</th></tr></thead><tbody>'
      + rows + '</tbody></table></div>'
      + '<div class="section"><h2>Totals</h2>' + renderMoneyBreakdown(order) + '</div>';
    openPrintWindow('Order ' + orderDisplayNumber(order), html);
  }

  function printSubscriptionDocument(sub) {
    if (!sub) return;
    var line = (sub.lines && sub.lines[0]) || {};
    var html = '<h1>Subscription</h1>'
      + '<div class="meta">' + escapeHtml(sub.status || '') + ' · '
      + escapeHtml(formatCents(sub.amount_cents, sub.currency)) + ' / ' + escapeHtml(sub.interval || 'month')
      + '<br>ID: ' + escapeHtml(sub.id || '') + '</div>'
      + '<div class="section"><h2>Customer</h2>'
      + '<div>' + escapeHtml(customerName(sub) || '—') + '</div>'
      + '<div>' + escapeHtml(customerEmail(sub) || '') + '</div></div>'
      + '<div class="section"><h2>Product</h2>'
      + '<div><strong>' + escapeHtml(line.title || subscriptionTitle(sub)) + '</strong></div>'
      + '<div class="muted">' + escapeHtml(productIdParts(line).join(' · ')) + '</div>'
      + '<div>Next billing: ' + escapeHtml(sub.next_billing_at ? String(sub.next_billing_at).slice(0, 10) : '—') + '</div>'
      + (sub.order_id ? ('<div>Source order: ' + escapeHtml(sub.order_id) + '</div>') : '')
      + '</div>';
    openPrintWindow('Subscription ' + (sub.id || ''), html);
  }

  function printOrdersListDocument(orders) {
    var rows = (orders || []).map(function (o) {
      return '<tr><td>' + escapeHtml(orderDisplayNumber(o)) + '</td><td>'
        + escapeHtml(customerSummary(o)) + '</td><td>'
        + escapeHtml(orderItemsSummary(o)) + '</td><td>'
        + escapeHtml(o.status || '') + '</td><td class="right">'
        + escapeHtml(formatCents(o.total_cents, o.currency)) + '</td></tr>';
    }).join('');
    openPrintWindow('Orders list', '<h1>Orders</h1><table><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Status</th><th class="right">Total</th></tr></thead><tbody>'
      + (rows || '<tr><td colspan="5">No orders</td></tr>') + '</tbody></table>');
  }

  function printSubscriptionsListDocument(subs) {
    var rows = (subs || []).map(function (s) {
      var line = (s.lines && s.lines[0]) || {};
      return '<tr><td>' + escapeHtml(s.id || '') + '</td><td>'
        + escapeHtml(customerSummary(s)) + '</td><td>'
        + escapeHtml(subscriptionTitle(s))
        + '<div class="muted">' + escapeHtml(productIdParts(line).join(' · ')) + '</div></td><td>'
        + escapeHtml(s.status || '') + '</td><td class="right">'
        + escapeHtml(formatCents(s.amount_cents, s.currency)) + ' / ' + escapeHtml(s.interval || 'month') + '</td></tr>';
    }).join('');
    openPrintWindow('Subscriptions list', '<h1>Subscriptions</h1><table><thead><tr><th>ID</th><th>Customer</th><th>Product</th><th>Status</th><th class="right">Amount</th></tr></thead><tbody>'
      + (rows || '<tr><td colspan="5">No subscriptions</td></tr>') + '</tbody></table>');
  }


  function subscriptionTitle(sub) {
    var lines = sub.lines || [];
    if (lines.length === 1) {
      var line = lines[0];
      return (line.title || line.entry_id || 'Subscription')
        + (Number(line.quantity) > 1 ? ' ×' + line.quantity : '');
    }
    return orderItemsSummary(sub);
  }

  function detectOrderTypes(order) {
    var lines = order.lines || [];
    var hasBundle = false;
    var hasRecurring = (order.billing_mode || '') === 'recurring';
    var hasOneTimeLine = false;
    lines.forEach(function (line) {
      if (!line) return;
      if (line.is_bundle) hasBundle = true;
      if ((line.billing || 'one_time') === 'recurring') hasRecurring = true;
      else hasOneTimeLine = true;
    });
    var tags = [];
    if (hasRecurring) {
      tags.push({
        key: 'subscription',
        label: order.billing_interval ? ('Subscription · ' + order.billing_interval) : 'Subscription'
      });
    }
    if (!hasRecurring || hasOneTimeLine) {
      tags.push({ key: 'one_time', label: 'One-time' });
    }
    if (hasBundle) tags.push({ key: 'bundle', label: 'Bundle' });
    if (!tags.length) tags.push({ key: 'one_time', label: 'One-time' });
    return tags;
  }

  function typeTagsHtml(tags) {
    return (tags || []).map(function (tag) {
      return '<span class="commerce-type-tag commerce-type-tag-' + escapeHtml(tag.key) + '">' + escapeHtml(tag.label) + '</span>';
    }).join('');
  }

  function formatOrderDate(iso) {
    if (!iso) return '—';
    var d = String(iso);
    return d.length >= 16 ? d.slice(0, 16).replace('T', ' ') : d.slice(0, 10);
  }


  function orderDisplayNumber(order) {
    return order.order_number || order.id || '—';
  }

  function orderSubtotalCents(order) {
    var lines = order.lines || [];
    var sum = 0;
    lines.forEach(function (line) { sum += lineAmount(line); });
    if (sum > 0) return sum;
    return Math.max(0, (Number(order.total_cents) || 0)
      - (Number(order.tax_cents) || 0)
      - (Number(order.shipping_cents) || 0)
      + (Number(order.discount_cents) || 0)
      + (Number(order.gift_card_cents) || 0));
  }

  function orderFulfillmentSummary(order) {
    var lines = order.lines || [];
    var ship = 0, shipped = 0, digital = 0, needs = 0;
    lines.forEach(function (line) {
      // Missing fulfillment defaults to ship (same as CMS schema).
      var f = line.fulfillment || 'ship';
      if (f === 'ship') {
        ship++;
        var rem = lineRemainingShipQty(line);
        if (rem <= 0) shipped++;
        else needs++;
      } else if (f === 'deliver' || f === 'register' || f === 'gift_card') {
        digital++;
      }
    });
    if (order.fulfillment_status === 'partial') return { key: 'partial_ship', label: 'Partially shipped' };
    if (order.fulfillment_status === 'fulfilled') return { key: 'shipped', label: ship === 1 ? 'Shipped' : 'All shipped' };
    if (ship && needs) return { key: 'needs_ship', label: needs === 1 ? 'Needs shipping' : (needs + ' need shipping') };
    if (ship && shipped === ship) return { key: 'shipped', label: ship === 1 ? 'Shipped' : 'All shipped' };
    if (ship) return { key: 'partial_ship', label: 'Partially shipped' };
    if (digital) return { key: 'digital', label: 'Digital fulfillment' };
    return null;
  }

  function formatShippingAddress(addr) {
    if (!addr || typeof addr !== 'object') return '';
    var parts = [addr.name, addr.line1, [addr.postal_code, addr.city].filter(Boolean).join(' '), addr.country];
    return parts.filter(Boolean).join(', ');
  }

  function sumMoneyLines(lines, amountKey) {
    if (!Array.isArray(lines) || !lines.length) return null;
    return lines.reduce(function (sum, line) {
      return sum + Number((line && line[amountKey]) || 0);
    }, 0);
  }

  function addMoneyLineRows(rows, lines, amountKey, currency, labelBuilder, negative) {
    if (!Array.isArray(lines) || !lines.length) return false;
    var added = false;
    lines.forEach(function (line) {
      var amount = Number((line && line[amountKey]) || 0);
      // Keep zero-rate reverse-charge tax lines visible on the order snapshot.
      var keepZeroTax = amountKey === 'tax_cents' && line
        && (line.reason === 'reverse_charge' || line.reason === 'zero_rate');
      if (amount <= 0 && !keepZeroTax) return;
      rows.push([labelBuilder(line || {}), (negative ? '−' : '') + formatCents(amount, currency)]);
      added = true;
    });
    return added;
  }

  function renderMoneyBreakdown(order, options) {
    options = options || {};
    var currency = order.currency;
    var rows = [];
    rows.push(['Items', formatCents(orderSubtotalCents(order), currency)]);
    var discountRows = addMoneyLineRows(rows, order.discount_allocations, 'amount_cents', currency, function (line) {
      var label = 'Discount';
      if (line.code) label += ' ' + line.code;
      else if (line.type) label += ' (' + line.type + ')';
      return label;
    }, true);
    if (!discountRows && Number(order.discount_cents) > 0) rows.push(['Discount', '−' + formatCents(order.discount_cents, currency)]);

    var shippingRows = addMoneyLineRows(rows, order.shipping_lines, 'price_cents', currency, function (line) {
      return line.title || 'Shipping';
    }, false);
    if (!shippingRows && (Number(order.shipping_cents) > 0 || options.alwaysShipping)) {
      rows.push(['Shipping', formatCents(order.shipping_cents || 0, currency)]);
    }

    var taxRows = addMoneyLineRows(rows, order.tax_lines, 'tax_cents', currency, function (line) {
      var label = line.title || 'Tax';
      if (line.reason === 'reverse_charge') {
        label = line.title || 'Reverse charge';
        if (line.vat_id) label += ' · ' + line.vat_id;
        if (line.tax_class) label += ' [' + line.tax_class + ']';
        return label;
      }
      if (line.tax_class && label.indexOf(line.tax_class) === -1) {
        label += ' [' + line.tax_class + ']';
      }
      if (line.rate || line.country) {
        label += ' (';
        if (line.rate != null && line.rate !== '') label += Number(line.rate) + '%';
        if (line.country) label += (line.rate != null && line.rate !== '' ? ', ' : '') + String(line.country).toUpperCase();
        label += ')';
      }
      return label;
    }, false);
    if (!taxRows && (Number(order.tax_cents) > 0 || Number(order.tax_rate) > 0)) {
      var taxLabel = 'Tax';
      if (order.tax_rate) taxLabel += ' (' + Number(order.tax_rate) + '%';
      if (order.tax_country) taxLabel += (order.tax_rate ? ', ' : ' (') + String(order.tax_country).toUpperCase();
      if (order.tax_rate || order.tax_country) taxLabel += ')';
      rows.push([taxLabel, formatCents(order.tax_cents || 0, currency)]);
    }

    var giftRows = addMoneyLineRows(rows, order.gift_card_applications, 'amount_cents', currency, function (line) {
      return line.code_last4 ? ('Gift card ••••' + line.code_last4) : 'Gift card';
    }, true);
    if (!giftRows && Number(order.gift_card_cents) > 0) rows.push(['Gift card', '−' + formatCents(order.gift_card_cents, currency)]);
    if (Number(order.refunded_cents) > 0) rows.push(['Refunded', '−' + formatCents(order.refunded_cents, currency)]);
    rows.push(['Total', formatCents(order.total_cents, currency)]);
    var html = '<div class="commerce-money-breakdown' + (options.compact ? ' is-compact' : '') + '">';
    rows.forEach(function (row, idx) {
      var isTotal = idx === rows.length - 1;
      html += '<div class="commerce-money-row' + (isTotal ? ' is-total' : '') + '">';
      html += '<span>' + escapeHtml(row[0]) + '</span><strong>' + escapeHtml(row[1]) + '</strong>';
      html += '</div>';
    });
    if ((sumMoneyLines(order.tax_lines, 'tax_cents') !== null)
      || (sumMoneyLines(order.shipping_lines, 'price_cents') !== null)
      || (sumMoneyLines(order.discount_allocations, 'amount_cents') !== null)) {
      html += '<p class="commerce-order-meta">Frozen order snapshot; tax, shipping, and discounts are not recalculated from current settings.</p>';
    }
    html += '</div>';
    return html;
  }

  function renderGiftCardFulfillmentCards(order, results) {
    var lines = (order.lines || []).filter(function (l) { return (l.fulfillment || '') === 'gift_card'; });
    if (!lines.length) return '';
    var html = '';
    lines.forEach(function (line) {
      var fr = results.find(function (r) { return r.line_id === line.line_id; }) || {};
      var cards = fr.gift_cards || [];
      html += '<div class="commerce-fulfillment-card">';
      html += '<div class="commerce-fulfillment-card-head">';
      html += '<strong>' + escapeHtml(line.title || line.line_id || 'Gift card') + '</strong>';
      html += '<span class="commerce-type-tag commerce-fulfill-tag-' + escapeHtml(lineFulfillmentState(order, line)) + '">gift card</span>';
      html += '</div>';
      if (!cards.length) {
        html += '<p class="commerce-order-meta">' + (fr.error ? escapeHtml(fr.error) : 'No gift card codes issued yet.') + '</p>';
      } else {
        html += '<ul class="commerce-timeline-list">';
        cards.forEach(function (c) {
          html += '<li><code>' + escapeHtml(c.code || ('••••' + (c.code_last4 || ''))) + '</code>';
          if (c.balance_cents != null) {
            html += ' · ' + escapeHtml(formatCents(c.balance_cents, c.currency || order.currency));
          }
          html += '</li>';
        });
        html += '</ul>';
      }
      html += '</div>';
    });
    return html;
  }

  function lineRemainingShipQty(line) {
    if ((line.fulfillment || '') !== 'ship') return 0;
    if (line.quantity_remaining != null) return Math.max(0, Number(line.quantity_remaining) || 0);
    var qty = Math.max(1, Number(line.quantity) || 1);
    var shipped = Number(line.quantity_shipped) || 0;
    if (!shipped && (line.fulfillment_status === 'shipped' || line.tracking_number)) shipped = qty;
    return Math.max(0, qty - shipped);
  }

  function renderShipmentHistory(order) {
    var shipments = order.shipments || [];
    if (!shipments.length) return '';
    var html = '<div class="commerce-shipment-history"><h5>Shipments</h5><ul class="commerce-timeline-list">';
    shipments.forEach(function (s) {
      var items = (s.items || []).map(function (it) {
        return escapeHtml((it.title || it.line_id || 'Item') + ' ×' + (it.quantity || 0));
      }).join(', ');
      html += '<li>';
      html += '<strong>' + escapeHtml(s.id || 'shipment') + '</strong>';
      html += ' · ' + escapeHtml(String(s.package_count || 1)) + ' pkg';
      if (s.carrier || s.tracking_number) {
        html += ' · ' + escapeHtml(trimJoin([s.carrier, s.tracking_number]));
      }
      if (s.created_at) html += ' · ' + escapeHtml(formatOrderDate(s.created_at));
      if (items) html += '<div class="commerce-order-meta">' + items + '</div>';
      if (s.id) {
        html += ' <button type="button" class="btn btn-secondary btn-sm commerce-packing-slip-shipment" data-order-id="'
          + escapeHtml(order.id) + '" data-shipment-id="' + escapeHtml(s.id) + '">Packing slip</button>';
      }
      html += '</li>';
    });
    html += '</ul></div>';
    return html;
  }

  function trimJoin(parts) {
    return parts.filter(Boolean).join(' ').trim();
  }

  function renderFulfillmentPanel(order, options) {
    options = options || {};
    var lines = order.lines || [];
    var results = order.fulfillment_results || [];
    var shipLines = lines.filter(function (l) { return (l.fulfillment || '') === 'ship'; });
    var giftLines = lines.filter(function (l) { return (l.fulfillment || '') === 'gift_card'; });
    if (!shipLines.length && !giftLines.length && !results.length && !options.force) return '';
    var html = '<div class="commerce-fulfillment-panel">';
    html += '<h4>Fulfillment';
    if (order.fulfillment_status) {
      html += ' <span class="commerce-type-tag commerce-fulfill-tag-' + escapeHtml(order.fulfillment_status) + '">'
        + escapeHtml(order.fulfillment_status) + '</span>';
    }
    html += '</h4>';
    if (!shipLines.length && !giftLines.length && !results.length) {
      html += '<p class="commerce-order-meta">No shipping or gift card lines on this order.</p></div>';
      return html;
    }

    shipLines.forEach(function (line) {
      var fr = results.find(function (r) { return r.line_id === line.line_id; }) || {};
      var rem = lineRemainingShipQty(line);
      var shipped = Number(line.quantity_shipped) || 0;
      var qty = Math.max(1, Number(line.quantity) || 1);
      html += '<div class="commerce-fulfillment-card">';
      html += '<div class="commerce-fulfillment-card-head">';
      html += '<strong>' + escapeHtml(line.title || line.line_id || 'Item') + '</strong>';
      html += '<span class="commerce-type-tag commerce-fulfill-tag-' + escapeHtml(line.fulfillment_status || lineFulfillmentState(order, line)) + '">'
        + escapeHtml(line.fulfillment_status || (rem <= 0 ? 'shipped' : 'unfulfilled')) + '</span>';
      html += '</div>';
      html += '<p class="commerce-order-meta">Qty ' + escapeHtml(qty) + ' · Shipped ' + escapeHtml(shipped)
        + ' · Remaining ' + escapeHtml(rem) + '</p>';
      if (line.tracking_number) {
        html += trackingLinkHtml(line);
        if (line.shipped_at) html += '<p class="commerce-order-meta">Last ship ' + escapeHtml(formatOrderDate(line.shipped_at)) + '</p>';
      }
      if (fr.export_path) {
        html += '<p class="commerce-order-meta">Export: ' + escapeHtml(String(fr.export_path).split('/').pop()) + '</p>';
      }
      if (fr.adapter) html += '<p class="commerce-order-meta">Adapter: ' + escapeHtml(fr.adapter) + '</p>';
      html += '</div>';
    });

    var canShip = options.editable && (order.status === 'paid' || order.status === 'partially_refunded');
    var remainingLines = shipLines.filter(function (l) { return lineRemainingShipQty(l) > 0; });
    if (canShip && remainingLines.length) {
      html += '<div class="commerce-shipment-form commerce-create-shipment-form" data-order-id="' + escapeHtml(order.id) + '">';
      html += '<h5>Ship items</h5>';
      remainingLines.forEach(function (line) {
        var rem = lineRemainingShipQty(line);
        html += '<div class="commerce-ship-item-row" data-line-id="' + escapeHtml(line.line_id || '') + '">';
        html += '<label><input type="checkbox" class="commerce-ship-item-check" checked> '
          + escapeHtml(line.title || line.line_id || 'Item') + '</label>';
        html += '<input type="number" class="input commerce-ship-item-qty" min="1" max="' + rem + '" value="' + rem + '">';
        html += '<span class="commerce-order-meta">of ' + rem + ' remaining</span></div>';
      });
      html += '<input type="text" class="input commerce-ship-carrier" placeholder="Carrier (DHL, UPS…)">';
      html += '<input type="text" class="input commerce-ship-tracking" placeholder="Tracking / shipping number">';
      html += '<label>Packages <input type="number" class="input commerce-ship-packages" min="1" value="1" style="width:4rem"></label>';
      html += '<label class="commerce-ship-notify"><input type="checkbox" class="commerce-ship-notify-cb" checked> Notify customer</label>';
      html += '<div class="commerce-detail-actions">';
      html += '<button type="button" class="btn btn-primary btn-sm commerce-create-shipment">Mark shipped</button> ';
      html += '<button type="button" class="btn btn-secondary btn-sm commerce-packing-slip-remaining" data-order-id="'
        + escapeHtml(order.id) + '">Packing slip (remaining)</button>';
      html += '</div></div>';
    } else if (canShip && shipLines.length) {
      html += '<p class="commerce-order-meta">All shippable items have been shipped.</p>';
      html += '<button type="button" class="btn btn-secondary btn-sm commerce-packing-slip-remaining" data-order-id="'
        + escapeHtml(order.id) + '" data-all="1">Packing slip</button>';
    }

    html += renderShipmentHistory(order);
    html += renderGiftCardFulfillmentCards(order, results);
    html += '</div>';
    return html;
  }


  function formatVariantAttrs(attrs) {
    if (!attrs) return '';
    if (typeof attrs === 'string') return attrs;
    if (Array.isArray(attrs)) {
      return attrs.map(function (a) {
        if (!a) return '';
        if (typeof a === 'string') return a;
        if (a.label && a.value) return a.label + ': ' + a.value;
        if (a.name && a.value) return a.name + ': ' + a.value;
        return JSON.stringify(a);
      }).filter(Boolean).join(' · ');
    }
    if (typeof attrs === 'object') {
      return Object.keys(attrs).map(function (k) {
        return k + ': ' + attrs[k];
      }).join(' · ');
    }
    return String(attrs);
  }

  function lineAmount(line) {
    var qty = Number(line.quantity) || 1;
    var unit = Number(line.unit_price_cents || line.effective_unit_cents || 0);
    return Number(line.line_total_cents || line.effective_amount_cents || (unit * qty));
  }

  function lineRefunded(line) {
    return Number(line.refunded_cents || 0);
  }

  function lineRemaining(line) {
    return Math.max(0, lineAmount(line) - lineRefunded(line));
  }

  function orderSubscriptionIds(order) {
    var ids = [];
    if (Array.isArray(order.subscription_ids)) {
      order.subscription_ids.forEach(function (id) {
        if (id && ids.indexOf(id) === -1) ids.push(id);
      });
    }
    if (order.subscription_id && ids.indexOf(order.subscription_id) === -1) {
      ids.push(order.subscription_id);
    }
    return ids;
  }

  function findSubscriptionForLine(order, line) {
    var lineId = line && line.line_id;
    if (!lineId) return null;
    var orderId = order && order.id;
    var match = (subscriptionsCache || []).find(function (s) {
      return (s.order_id === orderId) && ((s.line_id === lineId)
        || ((s.lines || []).length === 1 && (s.lines[0].line_id === lineId)));
    });
    return match || null;
  }

  function orderNeedsShipping(order) {
    if (order.fulfillment_status === 'fulfilled' || order.status === 'canceled') return false;
    return (order.lines || []).some(function (line) {
      return (line.fulfillment || 'ship') === 'ship' && lineRemainingShipQty(line) > 0;
    });
  }

  function orderHasShipmentProgress(order) {
    if (!order) return false;
    if ((order.shipments || []).length) return true;
    var fs = String(order.fulfillment_status || '').toLowerCase();
    if (fs === 'partial' || fs === 'fulfilled') return true;
    return (order.lines || []).some(function (line) {
      if ((line.fulfillment || 'ship') !== 'ship') return false;
      return (Number(line.quantity_shipped) || 0) > 0;
    });
  }

  function orderCanBeCanceled(order) {
    var status = order && order.status;
    if (!(status === 'pending' || status === 'paid' || status === 'partially_refunded')) return false;
    return !orderHasShipmentProgress(order);
  }

  function filterOrders(orders, filter, search) {
    filter = filter || 'active';
    return (orders || []).filter(function (o) {
      var status = o.status || '';
      var statusOk = true;
      if (filter === 'all') statusOk = true;
      else if (filter === 'active') statusOk = status === 'paid' || status === 'pending' || status === 'partially_refunded';
      else if (filter === 'unpaid') statusOk = status === 'pending';
      else if (filter === 'needs_shipping') statusOk = (status === 'paid' || status === 'partially_refunded') && orderNeedsShipping(o);
      else if (filter === 'refunded') statusOk = status === 'refunded' || status === 'partially_refunded';
      else if (filter === 'canceled') statusOk = status === 'canceled';
      else if (filter === 'paid') statusOk = status === 'paid' || status === 'partially_refunded' || status === 'refunded';
      else if (filter === 'pending') statusOk = status === 'pending';
      else if (filter === 'abandoned') statusOk = status === 'abandoned' || status === 'failed';
      else if (filter === 'archived') statusOk = status === 'archived' || !!(o.source === 'shopify_archive' || o.archive_import);
      if (!statusOk) return false;
      return matchesSearch(haystackForOrder(o), search);
    });
  }

  function filterSubscriptions(subs, search, filter) {
    filter = filter || 'all';
    return (subs || []).filter(function (s) {
      var status = s.status || '';
      if (filter === 'active' && status !== 'active') return false;
      if (filter === 'past_due' && status !== 'past_due') return false;
      if (filter === 'canceled' && status !== 'canceled') return false;
      return matchesSearch(haystackForSubscription(s), search);
    });
  }

  function visibleOrders() {
    return filterOrders(ordersCache, ordersFilter, ordersSearch);
  }

  function visibleSubscriptions() {
    return filterSubscriptions(subscriptionsCache, subscriptionsSearch, subscriptionsFilter);
  }

  function selectedOrderIdList() {
    return Object.keys(selectedOrderIds).filter(function (id) { return !!selectedOrderIds[id]; });
  }

  function updateOrdersBulkBar() {
    var bar = document.getElementById('commerce-orders-bulk');
    var countEl = document.getElementById('commerce-orders-bulk-count');
    var ids = selectedOrderIdList();
    if (bar) bar.hidden = false;
    if (countEl) countEl.textContent = ids.length + ' selected';
    var all = document.getElementById('commerce-orders-select-all');
    if (all) {
      var visible = visibleOrders();
      all.checked = visible.length > 0 && visible.every(function (o) { return !!selectedOrderIds[o.id]; });
      all.indeterminate = !all.checked && visible.some(function (o) { return !!selectedOrderIds[o.id]; });
    }
  }

  function trackingLinkHtml(line) {
    if (!line || !line.tracking_number) return '';
    var url = line.tracking_url || '';
    var label = escapeHtml((line.carrier ? (line.carrier + ' ') : '') + line.tracking_number);
    if (!url) {
      return '<div class="commerce-line-variants">Tracking: ' + label + '</div>';
    }
    return '<div class="commerce-line-variants">Tracking: <a class="commerce-tracking-link" href="'
      + escapeHtml(url) + '" target="_blank" rel="noopener noreferrer">' + label + '</a></div>';
  }

  function downloadTextFile(filename, text, mime) {
    var blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function renderOrderTags(order) {
    var tags = order.tags || [];
    if (!tags.length) return '<span class="commerce-order-meta">No tags</span>';
    return tags.map(function (tag) {
      return '<span class="commerce-tag">' + escapeHtml(tag) + '</span>';
    }).join(' ');
  }

  function renderOrderNotes(order) {
    var notes = order.notes || [];
    var html = '<div class="commerce-notes-panel">';
    html += '<h3>Support notes & tags</h3>';
    html += '<div class="commerce-tags-row">' + renderOrderTags(order) + '</div>';
    html += '<div class="commerce-tags-edit">';
    html += '<input type="text" class="input" id="commerce-order-tags-input" placeholder="tags, comma-separated" value="'
      + escapeHtml((order.tags || []).join(', ')) + '">';
    html += '<button type="button" class="btn btn-secondary btn-sm" id="commerce-order-tags-save" data-id="'
      + escapeHtml(order.id) + '">Save tags</button>';
    html += '</div>';
    if (!notes.length) {
      html += '<p class="commerce-order-meta">No notes yet.</p>';
    } else {
      html += '<ul class="commerce-notes-list">';
      notes.slice().reverse().forEach(function (n) {
        html += '<li><div class="commerce-note-meta">' + escapeHtml(n.author || 'admin')
          + ' · ' + escapeHtml(formatOrderDate(n.created_at)) + '</div>';
        html += '<div>' + escapeHtml(n.body || '') + '</div></li>';
      });
      html += '</ul>';
    }
    html += '<div class="commerce-note-compose">';
    html += '<textarea class="input" id="commerce-order-note-body" rows="3" placeholder="Add an internal support note…"></textarea>';
    html += '<button type="button" class="btn btn-secondary btn-sm" id="commerce-order-note-add" data-id="'
      + escapeHtml(order.id) + '">Add note</button>';
    html += '</div></div>';
    return html;
  }

  function showCustomerTimelineView() {
    var listView = document.getElementById('commerce-orders-list-view');
    var draftView = document.getElementById('commerce-draft-orders-view');
    var detailView = document.getElementById('commerce-order-detail-view');
    var timelineView = document.getElementById('commerce-customer-timeline-view');
    if (listView) listView.hidden = true;
    if (draftView) draftView.hidden = true;
    if (detailView) detailView.hidden = true;
    if (timelineView) timelineView.hidden = false;
  }

  function openCustomerTimeline(email) {
    email = String(email || '').trim();
    if (!email) return;
    activateCommerceTab('orders');
    showCustomerTimelineView();
    setCommerceHash('customer/' + encodeURIComponent(email));
    var el = document.getElementById('commerce-customer-timeline');
    if (!el) return;
    el.innerHTML = '<div class="loading-state"><p>Loading customer timeline…</p></div>';
    commercePost('customer_timeline', { email: email }).then(function (res) {
      var data = (res && res.data) || {};
      var orders = data.orders || [];
      var subs = data.subscriptions || [];
      var profile = data.customer || null;
      var um = data.user_management || {};
      var html = '<div class="commerce-detail-card">';
      html += '<div class="commerce-detail-header"><div><h2>Customer timeline</h2>';
      html += '<p class="commerce-order-id">' + escapeHtml(data.email || email) + '</p></div></div>';
      if (profile && profile.id) {
        html += '<p><button type="button" class="btn btn-secondary btn-sm commerce-open-customer-profile" data-id="'
          + escapeHtml(profile.id) + '">Open customer profile</button></p>';
        if (profile.name) html += '<p class="commerce-order-meta">' + escapeHtml(profile.name) + '</p>';
        if ((profile.tags || []).length) html += renderCustomerTags(profile.tags);
      } else {
        html += '<p><button type="button" class="btn btn-secondary btn-sm commerce-open-customer-profile" data-email="'
          + escapeHtml(data.email || email) + '">Open in Customers</button></p>';
      }
      if (um.active && um.admin_url) {
        html += '<p class="commerce-customer-um-link"><a href="' + escapeHtml(um.admin_url)
          + '">User Management</a></p>';
      }
      html += '<div class="commerce-detail-grid">';
      html += '<div><span class="label">Orders</span><strong>' + orders.length + '</strong></div>';
      html += '<div><span class="label">Subscriptions</span><strong>' + subs.length + '</strong></div></div>';
      html += '<h3>Orders</h3>';
      if (!orders.length) html += '<p class="commerce-order-meta">No orders.</p>';
      else {
        html += '<ul class="commerce-timeline-list">';
        orders.forEach(function (o) {
          html += '<li><button type="button" class="linkish commerce-open-order" data-id="' + escapeHtml(o.id) + '">'
            + escapeHtml(orderDisplayNumber(o)) + '</button> · ' + escapeHtml(o.status || '')
            + ' · ' + escapeHtml(formatCents(o.total_cents, o.currency))
            + ' · ' + escapeHtml(formatOrderDate(o.created_at));
          if ((o.tags || []).length) html += ' · ' + renderOrderTags(o);
          html += '</li>';
        });
        html += '</ul>';
      }
      html += '<h3>Subscriptions</h3>';
      if (!subs.length) html += '<p class="commerce-order-meta">No subscriptions.</p>';
      else {
        html += '<ul class="commerce-timeline-list">';
        subs.forEach(function (s) {
          html += '<li><button type="button" class="linkish commerce-open-subscription" data-id="' + escapeHtml(s.id) + '">'
            + escapeHtml(s.id) + '</button> · ' + escapeHtml(s.status || '')
            + ' · ' + escapeHtml(formatCents(s.amount_cents, s.currency)) + ' / ' + escapeHtml(s.interval || 'month')
            + ' · ' + escapeHtml(subscriptionTitle(s)) + '</li>';
        });
        html += '</ul>';
      }
      html += '</div>';
      el.innerHTML = html;
      el.querySelector('.commerce-open-customer-profile')?.addEventListener('click', function (ev) {
        var btn = ev.currentTarget;
        var id = btn.getAttribute('data-id');
        var em = btn.getAttribute('data-email');
        if (id) openCustomerProfile(id, false);
        else if (em) openCustomerProfile(em, true);
      });
    }).catch(function () {
      el.innerHTML = '<p class="error">Failed to load customer timeline</p>';
    });
  }


  function lineFulfillmentState(order, line) {
    var fr = (order.fulfillment_results || []).find(function (r) { return r.line_id === line.line_id; }) || {};
    if (fr.skipped) return 'done';
    if (fr.ok === false) return 'error';
    if (fr.ok) return 'fulfilled';
    return order.status === 'paid' ? 'paid' : 'pending';
  }

  function renderLineItems(orderOrSub, options) {
    options = options || {};
    var lines = orderOrSub.lines || [];
    if (!lines.length) return '<p class="commerce-order-meta">No line items.</p>';
    var detailed = !!options.detailed;
    var canRefund = !!options.canRefund;
    var currency = orderOrSub.currency;
    var html = '<ul class="commerce-line-list' + (detailed ? ' commerce-line-list-detailed' : '') + '">';
    lines.forEach(function (line) {
      var qty = Number(line.quantity) || 1;
      var unit = Number(line.unit_price_cents || line.effective_unit_cents || 0);
      var total = lineAmount(line);
      var refunded = lineRefunded(line);
      var remaining = lineRemaining(line);
      var variants = formatVariantAttrs(line.variant_attrs);
      var optionLabel = line.purchase_option_label || line.purchase_option_id || '';
      var interval = line.interval || '';
      html += '<li class="commerce-line-item' + (line.is_bundle ? ' is-bundle' : '') + '" data-line-id="' + escapeHtml(line.line_id || '') + '">';
      html += '<div class="commerce-line-main">';
      html += '<div class="commerce-line-title">' + escapeHtml(line.title || line.entry_id || 'Item');
      if (line.is_bundle) html += ' <span class="commerce-type-tag commerce-type-tag-bundle">Bundle</span>';
      if ((line.billing || '') === 'recurring') html += ' <span class="commerce-type-tag commerce-type-tag-subscription">Subscription</span>';
      else if (detailed) html += ' <span class="commerce-type-tag commerce-type-tag-one_time">One-time</span>';
      html += '</div>';
      html += '<div class="commerce-line-meta">';
      html += 'Qty ' + escapeHtml(qty);
      if (detailed && unit) html += ' · Unit ' + escapeHtml(formatCents(unit, currency));
      if (optionLabel) html += ' · ' + escapeHtml(optionLabel);
      if (interval) html += ' · Every ' + escapeHtml(interval);
      if (line.sku) html += ' · SKU ' + escapeHtml(line.sku);
      if (line.fulfillment) html += ' · ' + escapeHtml(line.fulfillment);
      if (!options.skipState) html += ' · ' + escapeHtml(lineFulfillmentState(orderOrSub, line));
      html += '</div>';
      html += renderProductIds(line);
      if (variants) {
        html += '<div class="commerce-line-variants">Variant: ' + escapeHtml(variants) + '</div>';
      }
      html += trackingLinkHtml(line);
      if (detailed && Number(line.discount_amount_cents) > 0) {
        html += '<div class="commerce-line-meta">Discount: −' + escapeHtml(formatCents(line.discount_amount_cents, currency)) + '</div>';
      }
      if (detailed && refunded > 0) {
        html += '<div class="commerce-line-meta">Refunded: ' + escapeHtml(formatCents(refunded, currency));
        if (remaining > 0) html += ' · Remaining: ' + escapeHtml(formatCents(remaining, currency));
        html += '</div>';
      }
      if (line.is_bundle && Array.isArray(line.components) && line.components.length) {
        html += '<ul class="commerce-line-components">';
        line.components.forEach(function (comp) {
          html += '<li>' + escapeHtml(comp.title || comp.entry_id || 'Component')
            + (Number(comp.quantity) > 1 ? ' ×' + escapeHtml(comp.quantity) : '')
            + '</li>';
        });
        html += '</ul>';
      }
      if (detailed && options.order) {
        var linkedSub = findSubscriptionForLine(options.order, line);
        if (linkedSub) {
          html += '<div class="commerce-line-actions">';
          html += '<button type="button" class="btn btn-secondary btn-sm commerce-open-subscription" data-id="'
            + escapeHtml(linkedSub.id) + '">Open subscription</button>';
          html += '</div>';
        }
      }
      if (canRefund && remaining > 0 && line.line_id) {
        html += '<div class="commerce-line-actions">';
        html += '<button type="button" class="btn btn-secondary btn-sm commerce-refund-order" data-order-id="'
          + escapeHtml(orderOrSub.id) + '" data-line-id="' + escapeHtml(line.line_id)
          + '" data-remaining="' + escapeHtml(remaining) + '" data-currency="'
          + escapeHtml(currency || 'eur') + '">Refund item…</button>';
        html += '</div>';
      }
      html += '</div>';
      html += '<div class="commerce-line-price">' + escapeHtml(formatCents(total, currency));
      if (detailed && qty > 1 && unit) {
        html += '<div class="commerce-line-price-sub">' + escapeHtml(formatCents(unit, currency)) + ' each</div>';
      }
      html += '</div>';
      html += '</li>';
    });
    html += '</ul>';
    return html;
  }

  function renderRefundHistory(order) {
    var refunds = order.refunds || [];
    if (!refunds.length) return '';
    var html = '<h3>Refund history</h3><ul class="commerce-refund-list">';
    refunds.forEach(function (r) {
      html += '<li><strong>' + escapeHtml(formatCents(r.amount_cents, order.currency)) + '</strong>';
      if (r.line_id) html += ' · line ' + escapeHtml(r.line_id);
      if (r.reason) html += ' · ' + escapeHtml(r.reason);
      if (r.created_at) html += ' · ' + escapeHtml(formatOrderDate(r.created_at));
      if (r.refund_id) html += ' · <span class="commerce-order-id">' + escapeHtml(r.refund_id) + '</span>';
      html += '</li>';
    });
    html += '</ul>';
    return html;
  }

  function showOrdersListView() {
    var listView = document.getElementById('commerce-orders-list-view');
    var draftView = document.getElementById('commerce-draft-orders-view');
    var detailView = document.getElementById('commerce-order-detail-view');
    var timelineView = document.getElementById('commerce-customer-timeline-view');
    if (listView) listView.hidden = false;
    if (draftView) draftView.hidden = true;
    if (detailView) detailView.hidden = true;
    if (timelineView) timelineView.hidden = true;
  }

  function showOrderDetailView() {
    var listView = document.getElementById('commerce-orders-list-view');
    var draftView = document.getElementById('commerce-draft-orders-view');
    var detailView = document.getElementById('commerce-order-detail-view');
    var timelineView = document.getElementById('commerce-customer-timeline-view');
    if (listView) listView.hidden = true;
    if (draftView) draftView.hidden = true;
    if (detailView) detailView.hidden = false;
    if (timelineView) timelineView.hidden = true;
  }

  function showDraftOrdersView() {
    var listView = document.getElementById('commerce-orders-list-view');
    var draftView = document.getElementById('commerce-draft-orders-view');
    var detailView = document.getElementById('commerce-order-detail-view');
    var timelineView = document.getElementById('commerce-customer-timeline-view');
    if (listView) listView.hidden = true;
    if (draftView) draftView.hidden = false;
    if (detailView) detailView.hidden = true;
    if (timelineView) timelineView.hidden = true;
  }

  function showSubscriptionsListView() {
    var listView = document.getElementById('commerce-subscriptions-list-view');
    var detailView = document.getElementById('commerce-subscription-detail-view');
    if (listView) listView.hidden = false;
    if (detailView) detailView.hidden = true;
  }

  function showSubscriptionDetailView() {
    var listView = document.getElementById('commerce-subscriptions-list-view');
    var detailView = document.getElementById('commerce-subscription-detail-view');
    if (listView) listView.hidden = true;
    if (detailView) detailView.hidden = false;
  }

  function setCommerceHash(hash) {
    if ((location.hash || '') === '#' + hash) return;
    history.replaceState(null, '', '#' + hash);
  }

  function focusInventorySku(sku) {
    if (!sku) return;
    var input = document.getElementById('commerce-stock-sku');
    if (input) {
      input.value = sku;
      input.focus();
      input.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  }

  function commercePanelAlias(name) {
    if (name === 'analytics' || name === 'dashboard') return 'dashboard';
    if (name === 'stock' || name === 'inventory') return 'inventory';
    if (name === 'docs' || name === 'documentation' || name === 'help') return 'docs';
    if (name === 'connections' || name === 'fieldtypes' || name === 'mappings'
      || name === 'shipping' || name === 'tax' || name === 'invoices' || name === 'emails'
      || name === 'import' || name === 'migration' || name === 'activity'
      || name === 'settings' || name === 'general' || name === 'fulfillment-settings') {
      return 'settings';
    }
    return name;
  }

  function commerceSettingsPanelForTab(name) {
    if (name === 'connections') return 'connections';
    if (name === 'general') return 'general';
    // Top-level Settings / Docs tabs keep their own panels.
    if (name === 'settings' || name === 'docs' || name === 'documentation') return null;
    if (name === 'migration') return 'import';
    if (name === 'fulfillment-settings') return 'fulfillment';
    if (name === 'fieldtypes' || name === 'mappings' || name === 'shipping' || name === 'tax'
      || name === 'invoices' || name === 'emails' || name === 'import' || name === 'activity'
      || name === 'fulfillment') {
      // "fulfillment" is also a primary ops tab — only deep-link settings when hash says so.
      return name === 'fulfillment' ? null : name;
    }
    return null;
  }

  function showCommercePanel(name) {
    var panelId = 'payments-tab-' + commercePanelAlias(name);
    document.querySelectorAll('.commerce-page > .tab-panel').forEach(function (panel) {
      var isActive = panel.id === panelId;
      panel.classList.toggle('active', isActive);
      panel.hidden = !isActive;
    });
  }

  function activateCommerceTab(name) {
    var resolved = commercePanelAlias(name);
    var tab = document.querySelector('.commerce-page .tab[data-tab="' + resolved + '"]');
    if (!tab) {
      // Alias fallbacks for Wave-3 / legacy hash names
      if (resolved === 'dashboard') tab = document.querySelector('.commerce-page .tab[data-tab="analytics"]');
      if (resolved === 'inventory') tab = document.querySelector('.commerce-page .tab[data-tab="stock"]');
    }
    if (!tab) {
      tab = document.querySelector('.commerce-page .tab[data-tab="' + name + '"]');
    }
    if (!tab) return;
    var settingsKey = commerceSettingsPanelForTab(name);
    if (!tab.classList.contains('active')) {
      tab.click();
      // After clicking Settings (or a buried setup alias), open the requested hub panel.
      if (settingsKey && name !== 'settings') {
        activateSettingsPanel(settingsKey, { skipHash: true });
      }
      return;
    }
    showCommercePanel(resolved);
    if (settingsKey) activateSettingsPanel(settingsKey, { skipHash: true });
  }

  function renderOrdersList() {
    var el = document.getElementById('commerce-orders-list');
    if (!el) return;
    var hashNow = location.hash || '';
    if (hashNow.indexOf('#order/') === 0 || hashNow.indexOf('#customer/') === 0
      || hashNow === '#draft-orders' || hashNow === '#quotes') return;
    showOrdersListView();
    var orders = visibleOrders();
    if (!orders.length) {
      var emptyMsg = ordersSearch
        ? 'No orders match your search.'
        : (ordersFilter === 'abandoned'
          ? 'No abandoned checkout attempts.'
          : (ordersFilter === 'needs_shipping'
            ? 'No orders need shipping.'
            : (ordersFilter === 'unpaid'
              ? 'No unpaid orders.'
              : (ordersFilter === 'refunded'
                ? 'No refunded orders.'
                : (ordersFilter === 'pending' ? 'No pending orders.' : 'No orders yet.')))));
      el.innerHTML = '<p class="empty-state">' + emptyMsg + '</p>';
      updateOrdersBulkBar();
      return;
    }

    var html = '';
    orders.forEach(function (o) {
      var open = !!expandedOrders[o.id];
      var tags = detectOrderTypes(o);
      var fulfill = orderFulfillmentSummary(o);
      var checked = !!selectedOrderIds[o.id];
      html += '<article class="commerce-accordion-item' + (open ? ' is-open' : '') + '" data-order-id="' + escapeHtml(o.id) + '">';
      html += '<div class="commerce-accordion-summary-row">';
      html += '<label class="commerce-row-check" title="Select order"><input type="checkbox" class="commerce-order-select" data-id="'
        + escapeHtml(o.id) + '"' + (checked ? ' checked' : '') + '></label>';
      html += '<div class="commerce-accordion-summary-stack">';
      html += '<button type="button" class="commerce-accordion-summary" data-accordion-toggle="order" data-id="'
        + escapeHtml(o.id) + '" aria-expanded="' + (open ? 'true' : 'false') + '">';
      html += '<span class="commerce-accordion-chevron" aria-hidden="true"></span>';
      html += '<div class="commerce-accordion-main">';
      html += '<div class="commerce-accordion-tags">' + orderStatusBadge(o.status) + typeTagsHtml(tags);
      if (fulfill) {
        html += '<span class="commerce-type-tag commerce-fulfill-tag-' + escapeHtml(fulfill.key) + '">'
          + escapeHtml(fulfill.label) + '</span>';
      }
      (o.tags || []).slice(0, 3).forEach(function (tag) {
        html += '<span class="commerce-tag">' + escapeHtml(tag) + '</span>';
      });
      html += '</div>';
      html += '<div class="commerce-accordion-title"><span class="commerce-order-number">'
        + escapeHtml(orderDisplayNumber(o)) + '</span><span class="commerce-order-items-sep">·</span>'
        + escapeHtml(orderItemsSummary(o)) + '</div>';
      html += '</div>';
      html += '<div class="commerce-accordion-total">' + escapeHtml(formatCents(o.total_cents, o.currency)) + '</div>';
      html += '</button>';
      html += '<div class="commerce-accordion-meta">';
      html += '<div class="commerce-accordion-meta-line">';
      var cName = customerName(o);
      var cEmail = customerEmail(o);
      if (cEmail) {
        html += '<span class="linkish commerce-open-customer" role="link" tabindex="0" data-email="'
          + escapeHtml(cEmail) + '">' + escapeHtml(cName || cEmail) + '</span>';
      } else {
        html += '<span class="commerce-accordion-meta-name">' + escapeHtml(cName || 'No customer') + '</span>';
      }
      html += '<span class="commerce-accordion-meta-date">' + escapeHtml(formatOrderDate(o.created_at)) + '</span>';
      html += '</div>';
      if (cEmail && cName) {
        html += '<div class="commerce-accordion-meta-email">' + escapeHtml(cEmail) + '</div>';
      }
      if (Number(o.tax_cents) > 0 || Number(o.shipping_cents) > 0) {
        html += '<div class="commerce-accordion-meta-extras">';
        if (Number(o.tax_cents) > 0) html += '<span>Tax ' + escapeHtml(formatCents(o.tax_cents, o.currency)) + '</span>';
        if (Number(o.shipping_cents) > 0) html += '<span>Ship ' + escapeHtml(formatCents(o.shipping_cents, o.currency)) + '</span>';
        html += '</div>';
      }
      html += '</div></div></div>';
      html += '<div class="commerce-accordion-body"' + (open ? '' : ' hidden') + '>';
      html += '<div class="commerce-accordion-section commerce-accordion-meta-grid">';
      html += '<div>' + renderCustomerBlock(o, { allowMissingAddress: true });
      if (customerEmail(o)) {
        html += '<button type="button" class="btn btn-secondary btn-sm commerce-open-customer" data-email="'
          + escapeHtml(customerEmail(o)) + '">Customer timeline</button>';
      }
      html += '</div>';
      html += '<div><h4>Totals</h4>' + renderMoneyBreakdown(o, { compact: true }) + '</div>';
      html += '</div>';
      html += '<div class="commerce-accordion-section">';
      html += '<h4>Line items</h4>';
      html += renderLineItems(o, { detailed: true });
      html += '</div>';
      var shipPreview = renderFulfillmentPanel(o, { editable: false });
      if (shipPreview) {
        html += '<div class="commerce-accordion-section">' + shipPreview + '</div>';
      }
      html += '<div class="commerce-accordion-actions">';
      html += '<button type="button" class="btn btn-primary btn-sm commerce-open-order" data-id="' + escapeHtml(o.id) + '">Open full details</button>';
      html += ' <button type="button" class="btn btn-secondary btn-sm commerce-print-order" data-id="' + escapeHtml(o.id) + '">Print</button>';
      html += ' <button type="button" class="btn btn-secondary btn-sm commerce-invoice-order" data-id="' + escapeHtml(o.id) + '">Invoice PDF</button>';
      orderSubscriptionIds(o).forEach(function (sid) {
        html += ' <button type="button" class="btn btn-secondary btn-sm commerce-open-subscription" data-id="'
          + escapeHtml(sid) + '">View subscription</button>';
      });
      html += '</div></div></article>';
    });
    el.innerHTML = html;
    updateOrdersBulkBar();
  }

  function loadOrders() {
    var el = document.getElementById('commerce-orders-list');
    if (!el) return;
    markSeenAt(SEEN_ORDERS_KEY);
    setTabBadge('orders', 0);
    var hash = location.hash || '';
    var keepDetail = hash.indexOf('#order/') === 0;
    if (!keepDetail) {
      showOrdersListView();
      el.innerHTML = '<div class="loading-state"><p>Updating payment status…</p></div>';
    }
    var includeAbandoned = ordersFilter === 'abandoned' || ordersFilter === 'all';
    commercePost('list_orders', { include_abandoned: includeAbandoned ? 1 : 0 }).then(function (res) {
      ordersCache = (res.data && res.data.orders) || [];
      if ((location.hash || '').indexOf('#order/') === 0) {
        var oid = (location.hash || '').slice('#order/'.length);
        if (oid) viewOrder(oid);
        refreshActivityBadges();
        return;
      }
      renderOrdersList();
      refreshActivityBadges();
    }).catch(function () {
      if ((location.hash || '').indexOf('#order/') !== 0) {
        el.innerHTML = '<p class="error">Failed to load orders</p>';
      }
    });
  }

  function ensureSubscriptionsCached() {
    if (subscriptionsCache && subscriptionsCache.length) {
      return Promise.resolve(subscriptionsCache);
    }
    return commercePost('list_subscriptions').then(function (res) {
      subscriptionsCache = (res.data && res.data.subscriptions) || [];
      return subscriptionsCache;
    }).catch(function () {
      return subscriptionsCache || [];
    });
  }

  function viewOrder(id) {
    var detail = document.getElementById('commerce-order-detail');
    if (!detail) return;
    showOrderDetailView();
    setCommerceHash('order/' + id);
    detail.innerHTML = '<div class="loading-state"><p>Loading order…</p></div>';
    Promise.all([
      commercePost('get_order', { id: id }),
      ensureSubscriptionsCached(),
    ]).then(function (results) {
      var res = results[0];
      var o = res.data && res.data.order;
      if (!o) {
        detail.innerHTML = '<p class="error">Order not found</p>';
        return;
      }
      currentOrderDetail = o;
      var refundable = (o.status === 'paid' || o.status === 'partially_refunded');
      var cancelable = orderCanBeCanceled(o);
      var remaining = (Number(o.total_cents) || 0) - (Number(o.refunded_cents) || 0);
      var tags = detectOrderTypes(o);
      var subIds = orderSubscriptionIds(o);
      var fulfill = orderFulfillmentSummary(o);
      var html = '<div class="commerce-detail-card">';
      html += '<div class="commerce-detail-header">';
      html += '<div><h2>' + escapeHtml(orderDisplayNumber(o)) + '</h2>';
      html += '<p class="commerce-order-id">Internal ID: ' + escapeHtml(o.id) + '</p></div>';
      html += '<div class="commerce-detail-header-tags">' + orderStatusBadge(o.status) + typeTagsHtml(tags);
      if (fulfill) {
        html += '<span class="commerce-type-tag commerce-fulfill-tag-' + escapeHtml(fulfill.key) + '">'
          + escapeHtml(fulfill.label) + '</span>';
      }
      html += '</div></div>';
      html += '<div class="commerce-detail-grid">';
      html += '<div><span class="label">Customer</span><strong>' + escapeHtml(customerName(o) || customerEmail(o) || '—') + '</strong></div>';
      html += '<div><span class="label">Total</span><strong>' + escapeHtml(formatCents(o.total_cents, o.currency)) + '</strong></div>';
      html += '<div><span class="label">Created</span><strong>' + escapeHtml(formatOrderDate(o.created_at)) + '</strong></div>';
      html += '<div><span class="label">Type</span><strong>' + escapeHtml(tags.map(function (t) { return t.label; }).join(', ')) + '</strong></div>';
      html += '</div>';
      html += '<div class="commerce-detail-columns">';
      html += '<div><h3>Money</h3>' + renderMoneyBreakdown(o) + '</div>';
      html += '<div><h3>Customer & delivery</h3>' + renderCustomerBlock(o, { skipHeading: true });
      if (o.coupon_code) {
        html += '<p class="commerce-order-meta"><strong>Coupon:</strong> ' + escapeHtml(o.coupon_code) + '</p>';
      }
      html += '</div></div>';
      if (subIds.length) {
        html += '<p class="commerce-order-meta">Linked subscriptions: ';
        subIds.forEach(function (sid, idx) {
          if (idx) html += ', ';
          html += '<button type="button" class="linkish commerce-open-subscription" data-id="'
            + escapeHtml(sid) + '">' + escapeHtml(sid) + '</button>';
        });
        html += '</p>';
      }
      if (o.payment_id) {
        html += '<p class="commerce-order-meta">Payment: ' + escapeHtml(o.payment_id)
          + (o.provider ? ' · ' + escapeHtml(o.provider) : '') + '</p>';
      }
      if (o.billing_mode) {
        html += '<p class="commerce-order-meta">Billing mode: ' + escapeHtml(o.billing_mode)
          + (o.billing_interval ? ' · ' + escapeHtml(o.billing_interval) : '') + '</p>';
      }
      if (o.abandoned_reason) {
        html += '<p class="commerce-order-meta">Abandoned: ' + escapeHtml(String(o.abandoned_reason).replace(/_/g, ' '));
        if (o.superseded_by) html += ' · replaced by ' + escapeHtml(o.superseded_by);
        html += '</p>';
      }
      html += '<h3>Line items</h3>';
      html += '<p class="field-help">Refund returns money. Cancel stops fulfillment (and can refund). Shipping tracking is managed in Fulfillment.</p>';
      if (o.status === 'canceled') {
        html += '<p class="commerce-order-meta">Canceled'
          + (o.canceled_at ? (' ' + escapeHtml(formatOrderDate(o.canceled_at))) : '')
          + (o.canceled_by ? (' · by ' + escapeHtml(o.canceled_by)) : '')
          + (o.cancel_reason ? (' — ' + escapeHtml(o.cancel_reason)) : '')
          + '</p>';
      }
      html += renderLineItems(o, {
        detailed: true,
        canRefund: refundable && remaining > 0,
        order: o,
      });
      html += renderFulfillmentPanel(o, { editable: o.status !== 'canceled', force: true });
      html += renderRefundHistory(o);
      html += renderOrderNotes(o);
      html += '<div class="commerce-detail-actions">';
      if (o.status === 'pending' && o.payment_id) {
        html += '<button type="button" class="btn btn-primary commerce-sync-order-payment" data-id="'
          + escapeHtml(o.id) + '">Confirm payment &amp; send receipt</button> ';
      } else if (o.status === 'pending') {
        html += '<p class="field-help commerce-order-meta">Payment not confirmed — receipt email sends when status becomes <strong>paid</strong>. If Stripe already charged, upgrade Commerce to 1.0.75+ or use Confirm payment when a payment id is present.</p>';
      }
      if ((o.status === 'paid' || o.status === 'partially_refunded') && customerEmail(o)) {
        html += '<button type="button" class="btn btn-secondary commerce-resend-receipt" data-id="'
          + escapeHtml(o.id) + '">Resend receipt email</button> ';
      }
      if (customerEmail(o)) {
        html += '<button type="button" class="btn btn-secondary commerce-open-customer" data-email="'
          + escapeHtml(customerEmail(o)) + '">Customer timeline</button> ';
      }
      html += '<button type="button" class="btn btn-secondary commerce-open-email-log">View email log</button> ';
      html += '<button type="button" class="btn btn-secondary commerce-invoice-order" data-id="'
        + escapeHtml(o.id) + '">Invoice PDF</button> ';
      if (cancelable) {
        html += '<button type="button" class="btn btn-danger commerce-cancel-order" data-order-id="'
          + escapeHtml(o.id) + '" data-remaining="' + escapeHtml(remaining) + '" data-currency="'
          + escapeHtml(o.currency || 'eur') + '" data-status="' + escapeHtml(o.status || '')
          + '">Cancel order…</button> ';
      }
      if (refundable && remaining > 0) {
        html += '<button type="button" class="btn btn-secondary commerce-refund-order" data-order-id="'
          + escapeHtml(o.id) + '" data-remaining="' + escapeHtml(remaining) + '" data-currency="'
          + escapeHtml(o.currency || 'eur') + '">Refund remaining…</button>';
      }
      subIds.forEach(function (sid) {
        html += ' <button type="button" class="btn btn-secondary commerce-open-subscription" data-id="'
          + escapeHtml(sid) + '">Open subscription</button>';
      });
      html += '</div></div>';
      detail.innerHTML = html;

      document.getElementById('commerce-order-tags-save')?.addEventListener('click', function () {
        var raw = document.getElementById('commerce-order-tags-input')?.value || '';
        var tags = raw.split(',').map(function (t) { return t.trim(); }).filter(Boolean);
        commercePost('set_order_tags', { id: o.id, tags: tags }).then(function (res) {
          if (res.status !== 'ok') { alert(res.message || 'Failed to save tags'); return; }
          viewOrder(o.id);
          loadOrders();
        });
      });
      document.getElementById('commerce-order-note-add')?.addEventListener('click', function () {
        var body = document.getElementById('commerce-order-note-body')?.value || '';
        commercePost('add_order_note', { id: o.id, body: body }).then(function (res) {
          if (res.status !== 'ok') { alert(res.message || 'Failed to add note'); return; }
          viewOrder(o.id);
        });
      });
    }).catch(function () {
      detail.innerHTML = '<p class="error">Failed to load order</p>';
    });
  }

  function setChipFilterActive(selector, activeBtn) {
    document.querySelectorAll(selector).forEach(function (c) {
      var on = c === activeBtn;
      c.classList.toggle('chip--selected', on);
      c.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }

  function setSegmentedFilterActive(selector, activeBtn) {
    document.querySelectorAll(selector).forEach(function (c) {
      var on = c === activeBtn;
      c.classList.toggle('active', on);
      c.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }

  function initOrdersFilters() {
    document.querySelectorAll('[data-orders-filter]').forEach(function (chip) {
      chip.addEventListener('click', function () {
        ordersFilter = chip.getAttribute('data-orders-filter') || 'active';
        setChipFilterActive('[data-orders-filter]', chip);
        if (ordersFilter === 'abandoned' || ordersFilter === 'all') {
          loadOrders();
        } else {
          renderOrdersList();
        }
      });
    });

    document.querySelectorAll('[data-subs-filter]').forEach(function (chip) {
      chip.addEventListener('click', function () {
        subscriptionsFilter = chip.getAttribute('data-subs-filter') || 'all';
        setSegmentedFilterActive('[data-subs-filter]', chip);
        renderSubscriptionsList();
      });
    });

    var ordersSearchInput = document.getElementById('commerce-orders-search');
    if (ordersSearchInput) {
      ordersSearchInput.addEventListener('input', function () {
        ordersSearch = ordersSearchInput.value || '';
        renderOrdersList();
      });
    }
    var subsSearchInput = document.getElementById('commerce-subscriptions-search');
    if (subsSearchInput) {
      subsSearchInput.addEventListener('input', function () {
        subscriptionsSearch = subsSearchInput.value || '';
        renderSubscriptionsList();
      });
    }

    document.getElementById('commerce-orders-print-list')?.addEventListener('click', function () {
      printOrdersListDocument(visibleOrders());
    });
    document.getElementById('commerce-subscriptions-print-list')?.addEventListener('click', function () {
      printSubscriptionsListDocument(visibleSubscriptions());
    });
    document.getElementById('commerce-order-print')?.addEventListener('click', function () {
      if (currentOrderDetail) printOrderDocument(currentOrderDetail);
      else alert('Open an order first');
    });
    document.getElementById('commerce-order-invoice')?.addEventListener('click', function () {
      if (!currentOrderDetail) { alert('Open an order first'); return; }
      openHtmlDocumentAsync(
        commercePost('order_invoice', { id: currentOrderDetail.id }).then(function (res) {
          if (res.status !== 'ok' || !res.data || !res.data.html) {
            throw new Error(res.message || 'Failed to build invoice');
          }
          if (res.data.order) currentOrderDetail = res.data.order;
          return res.data.html;
        }),
        'invoice.html'
      ).catch(function (err) {
        alert((err && err.message) || 'Failed to build invoice');
      });
    });
    document.getElementById('commerce-subscription-print')?.addEventListener('click', function () {
      if (currentSubscriptionDetail) printSubscriptionDocument(currentSubscriptionDetail);
      else alert('Open a subscription first');
    });

    document.getElementById('commerce-orders-select-all')?.addEventListener('change', function (e) {
      var on = !!e.target.checked;
      visibleOrders().forEach(function (o) {
        if (on) selectedOrderIds[o.id] = true;
        else delete selectedOrderIds[o.id];
      });
      renderOrdersList();
    });
    document.getElementById('commerce-orders-bulk-ship')?.addEventListener('click', function () {
      var ids = selectedOrderIdList();
      if (!ids.length) { alert('Select at least one order'); return; }
      var carrier = prompt('Carrier for bulk ship (optional, e.g. DHL / UPS):', 'Manual') || '';
      commercePost('bulk_mark_shipped', { ids: ids, carrier: carrier }).then(function (res) {
        var data = res.data || {};
        var updated = (data.updated || []).length;
        var errors = data.errors || [];
        alert('Marked shipped: ' + updated + (errors.length ? ('\nSkipped/errors:\n' + errors.join('\n')) : ''));
        selectedOrderIds = {};
        loadOrders();
      });
    });
    document.getElementById('commerce-orders-bulk-packing')?.addEventListener('click', function () {
      var ids = selectedOrderIdList();
      if (!ids.length) { alert('Select at least one order'); return; }
      openHtmlDocumentAsync(
        commercePost('packing_slips', { ids: ids, brand_name: 'Packing slip' }).then(function (res) {
          if (res.status !== 'ok' || !res.data || !res.data.html) {
            throw new Error(res.message || 'Failed to build packing slips');
          }
          return res.data.html;
        }),
        'packing-slips.html'
      ).catch(function (err) {
        alert((err && err.message) || 'Failed to build packing slips');
      });
    });
    document.getElementById('commerce-orders-bulk-csv')?.addEventListener('click', function () {
      var ids = selectedOrderIdList();
      var payload = ids.length ? { ids: ids } : { ids: visibleOrders().map(function (o) { return o.id; }) };
      if (!payload.ids.length) { alert('No orders to export'); return; }
      commercePost('export_orders_csv', payload).then(function (res) {
        if (res.status !== 'ok' || !res.data) {
          alert(res.message || 'Export failed');
          return;
        }
        downloadTextFile(res.data.filename || 'orders.csv', res.data.csv || '', 'text/csv;charset=utf-8');
      });
    });
    document.getElementById('commerce-orders-bulk-delete')?.addEventListener('click', function () {
      var ids = selectedOrderIdList();
      if (!ids.length) { alert('Select at least one order'); return; }
      var selected = ids.map(function (id) {
        return ordersCache.find(function (o) { return o.id === id; });
      }).filter(Boolean);
      var blocked = selected.filter(function (o) {
        var s = o.status || '';
        return s !== 'abandoned' && s !== 'canceled' && s !== 'failed';
      });
      if (blocked.length) {
        alert('Only abandoned, canceled, or failed orders can be deleted. Deselect paid or pending orders first.');
        return;
      }
      if (!confirm('Permanently delete ' + ids.length + ' order(s)? This cannot be undone.')) return;
      commercePost('delete_orders', { ids: ids }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Delete failed');
          return;
        }
        var data = res.data || {};
        var deleted = data.deleted_count || 0;
        var errors = data.errors || [];
        alert('Deleted: ' + deleted + (errors.length ? ('\nSkipped/errors:\n' + errors.join('\n')) : ''));
        selectedOrderIds = {};
        loadOrders();
      });
    });

    document.getElementById('commerce-order-back')?.addEventListener('click', function () {
      setCommerceHash('orders');
      showOrdersListView();
      renderOrdersList();
    });
    document.getElementById('commerce-customer-back')?.addEventListener('click', function () {
      setCommerceHash('orders');
      showOrdersListView();
      renderOrdersList();
    });
    document.getElementById('commerce-open-draft-orders')?.addEventListener('click', function () {
      setCommerceHash('draft-orders');
      showDraftOrdersView();
      loadQuotes();
    });
    document.getElementById('commerce-draft-orders-back')?.addEventListener('click', function () {
      setCommerceHash('orders');
      showOrdersListView();
      renderOrdersList();
    });
    document.getElementById('commerce-subscription-back')?.addEventListener('click', function () {
      setCommerceHash('subscriptions');
      showSubscriptionsListView();
      renderSubscriptionsList();
    });
  }

  function subStatusBadge(status, sub) {
    var cls = 'badge ' + (function(st){ st=st||'unknown'; if(st==='active')return 'badge-success'; if(st==='paused'||st==='past_due'||st==='trialing')return 'badge-warning'; if(st==='cancelled'||st==='canceled'||st==='failed')return 'badge-danger'; return 'badge-neutral'; })(status);
    var label = status || 'unknown';
    if (status === 'past_due' && sub && sub.dunning && sub.dunning.attempt_count) {
      label = 'past due (' + sub.dunning.attempt_count + ')';
    }
    return '<span class="' + cls + '">' + label + '</span>';
  }

  function dunningBadge(sub) {
    if ((sub.status || '') !== 'past_due') return '';
    var count = (sub.dunning && sub.dunning.attempt_count) || 1;
    return '<span class="commerce-dunning-badge" title="Payment failed">Dunning · attempt ' + count + '</span>';
  }

  function renderSubscriptionsList() {
    var el = document.getElementById('commerce-subscriptions-list');
    if (!el) return;
    if ((location.hash || '').indexOf('#subscription/') === 0) return;
    showSubscriptionsListView();
    var subs = visibleSubscriptions();
    if (!subs.length) {
      el.innerHTML = '<p class="empty-state">'
        + (subscriptionsSearch
          ? 'No subscriptions match your search.'
          : 'No subscriptions yet. Recurring purchases create a subscription when the order is paid.')
        + '</p>';
      return;
    }
    var html = '';
    subs.forEach(function (s) {
      var open = !!expandedSubs[s.id];
      var line = (s.lines && s.lines[0]) || {};
      var tags = [{ key: 'subscription', label: s.interval ? ('Subscription · ' + s.interval) : 'Subscription' }];
      if (line.is_bundle) tags.push({ key: 'bundle', label: 'Bundle' });
      var summary = subscriptionTitle(s);
      html += '<article class="commerce-accordion-item' + (open ? ' is-open' : '') + '" data-subscription-id="' + escapeHtml(s.id) + '">';
      html += '<button type="button" class="commerce-accordion-summary" data-accordion-toggle="subscription" data-id="'
        + escapeHtml(s.id) + '" aria-expanded="' + (open ? 'true' : 'false') + '">';
      html += '<span class="commerce-accordion-chevron" aria-hidden="true"></span>';
      html += '<div class="commerce-accordion-main">';
      html += '<div class="commerce-accordion-tags">' + subStatusBadge(s.status, s) + dunningBadge(s) + typeTagsHtml(tags) + '</div>';
      html += '<div class="commerce-accordion-title">' + escapeHtml(summary) + '</div>';
      html += '<div class="commerce-accordion-sub">' + escapeHtml(customerSummary(s))
        + ' · Next ' + escapeHtml(s.next_billing_at ? s.next_billing_at.slice(0, 10) : '—')
        + (line.entry_id ? (' · ID ' + escapeHtml(line.entry_id)) : '')
        + (line.sku ? (' · SKU ' + escapeHtml(line.sku)) : '')
        + '</div>';
      html += '</div>';
      html += '<div class="commerce-accordion-total">' + escapeHtml(formatCents(s.amount_cents, s.currency))
        + '<div class="commerce-line-price-sub">/ ' + escapeHtml(s.interval || 'month') + '</div></div>';
      html += '</button>';
      html += '<div class="commerce-accordion-body"' + (open ? '' : ' hidden') + '>';
      html += '<div class="commerce-accordion-section">' + renderCustomerBlock(s, { allowMissingAddress: true }) + '</div>';
      html += '<div class="commerce-accordion-section"><h4>Subscribed product</h4>';
      html += renderLineItems(s, { skipState: true, detailed: true });
      html += '</div>';
      html += '<div class="commerce-accordion-actions">';
      html += '<button type="button" class="btn btn-primary btn-sm commerce-open-subscription" data-id="' + escapeHtml(s.id) + '">Open full details</button>';
      html += ' <button type="button" class="btn btn-secondary btn-sm commerce-print-subscription" data-id="' + escapeHtml(s.id) + '">Print</button>';
      if (s.order_id) {
        html += ' <button type="button" class="btn btn-secondary btn-sm commerce-open-order" data-id="'
          + escapeHtml(s.order_id) + '">View source order</button>';
      }
      html += '</div></div></article>';
    });
    el.innerHTML = html;
  }

  function loadSubscriptions() {
    var el = document.getElementById('commerce-subscriptions-list');
    if (!el) return;
    markSeenAt(SEEN_SUBS_KEY);
    setTabBadge('subscriptions', 0);
    var keepDetail = (location.hash || '').indexOf('#subscription/') === 0;
    if (!keepDetail) {
      showSubscriptionsListView();
      el.innerHTML = '<div class="loading-state"><p>Loading subscriptions…</p></div>';
    }
    commercePost('list_subscriptions').then(function (res) {
      subscriptionsCache = (res.data && res.data.subscriptions) || [];
      if ((location.hash || '').indexOf('#subscription/') === 0) {
        var sid = (location.hash || '').slice('#subscription/'.length);
        if (sid) viewSubscription(sid);
        refreshActivityBadges();
        return;
      }
      renderSubscriptionsList();
      refreshActivityBadges();
    }).catch(function () {
      if ((location.hash || '').indexOf('#subscription/') !== 0) {
        el.innerHTML = '<p class="error">Failed to load subscriptions</p>';
      }
    });
  }

  function viewSubscription(id) {
    var detail = document.getElementById('commerce-subscription-detail');
    if (!detail) return;
    activateCommerceTab('subscriptions');
    showSubscriptionDetailView();
    setCommerceHash('subscription/' + id);
    detail.innerHTML = '<div class="loading-state"><p>Loading subscription…</p></div>';
    commercePost('get_subscription', { id: id }).then(function (res) {
      if ((location.hash || '') !== '#subscription/' + id) return;
      var s = res.data && res.data.subscription;
      if (!s) {
        detail.innerHTML = '<p class="error">' + escapeHtml((res && res.message) || 'Subscription not found') + '</p>';
        return;
      }
      currentSubscriptionDetail = s;
      var canCancel = s.status !== 'canceled' && s.status !== 'cancelled';
      var canRetry = s.status === 'past_due';
      var canPause = s.status === 'active' || s.status === 'past_due' || s.status === 'trialing';
      var canResume = s.status === 'paused';
      var line = (s.lines && s.lines[0]) || {};
      var tags = [{ key: 'subscription', label: s.interval ? ('Subscription · ' + s.interval) : 'Subscription' }];
      if (line.is_bundle) tags.push({ key: 'bundle', label: 'Bundle' });
      var html = '<div class="commerce-detail-card">';
      html += '<div class="commerce-detail-header">';
      html += '<div><h2>' + escapeHtml(subscriptionTitle(s)) + '</h2>';
      html += '<p class="commerce-order-id">' + escapeHtml(s.id) + '</p></div>';
      html += '<div class="commerce-detail-header-tags">' + subStatusBadge(s.status, s) + dunningBadge(s) + typeTagsHtml(tags) + '</div>';
      html += '</div>';
      html += '<div class="commerce-detail-grid">';
      html += '<div><span class="label">Customer</span><strong>' + escapeHtml(customerName(s) || customerEmail(s) || '—') + '</strong></div>';
      html += '<div><span class="label">Amount</span><strong>' + escapeHtml(formatCents(s.amount_cents, s.currency)) + ' / ' + escapeHtml(s.interval || 'month') + '</strong></div>';
      html += '<div><span class="label">Started</span><strong>' + escapeHtml(formatOrderDate(s.created_at)) + '</strong></div>';
      html += '<div><span class="label">Next billing</span><strong>' + escapeHtml(s.next_billing_at ? s.next_billing_at.slice(0, 10) : '—') + '</strong></div>';
      html += '</div>';
      html += '<div class="commerce-detail-columns"><div>' + renderCustomerBlock(s, { allowMissingAddress: true }) + '</div>';
      html += '<div><h4>Product identity</h4>' + renderProductIds(line);
      if (line.purchase_option_label || line.purchase_option_id) {
        html += '<p class="commerce-order-meta">Plan: ' + escapeHtml(line.purchase_option_label || line.purchase_option_id);
        if (line.interval || s.interval) html += ' · Every ' + escapeHtml(line.interval || s.interval);
        html += '</p>';
      }
      if (formatVariantAttrs(line.variant_attrs)) {
        html += '<p class="commerce-order-meta">Variant: ' + escapeHtml(formatVariantAttrs(line.variant_attrs)) + '</p>';
      }
      html += '</div></div>';
      if (s.order_id) {
        html += '<p class="commerce-order-meta">Source order: <button type="button" class="linkish commerce-open-order" data-id="'
          + escapeHtml(s.order_id) + '">' + escapeHtml(s.order_id) + '</button>'
          + (s.provider ? ' · Provider: ' + escapeHtml(s.provider) : '') + '</p>';
      }
      if (s.line_id) html += '<p class="commerce-order-meta">Order line: ' + escapeHtml(s.line_id) + '</p>';
      if (s.canceled_at) html += '<p class="commerce-order-meta">Canceled: ' + escapeHtml(s.canceled_at) + '</p>';
      if (s.paused_at) html += '<p class="commerce-order-meta">Paused: ' + escapeHtml(s.paused_at) + '</p>';
      if (s.past_due_at) html += '<p class="commerce-order-meta">Past due since: ' + escapeHtml(s.past_due_at) + '</p>';
      if (s.dunning && s.dunning.attempt_count) {
        html += '<p class="commerce-dunning-meta">Dunning: attempt ' + escapeHtml(s.dunning.attempt_count);
        if (s.dunning.last_failed_at) html += ' · last failed ' + escapeHtml(s.dunning.last_failed_at);
        html += '</p>';
      }
      if (s.upgraded_at) html += '<p class="commerce-order-meta">Last upgraded: ' + escapeHtml(s.upgraded_at) + '</p>';
      if (s.last_proration_cents) html += '<p class="commerce-order-meta">Last proration: ' + escapeHtml(formatCents(s.last_proration_cents, s.currency)) + '</p>';
      html += '<h3>Subscribed item</h3>';
      html += renderLineItems(s, { skipState: true, detailed: true });
      html += '<div class="commerce-detail-actions">';
      if (canRetry) {
        html += '<button class="btn btn-primary" id="commerce-sub-retry" data-id="' + escapeHtml(s.id) + '">Retry payment</button> ';
      }
      if (s.status === 'active' || s.status === 'past_due') {
        html += '<div class="commerce-sub-upgrade" id="commerce-sub-upgrade-wrap"><p><strong>Change plan</strong></p>';
        html += '<select id="commerce-sub-upgrade-select" class="input"><option value="">Loading options…</option></select> ';
        html += '<button class="btn btn-secondary" id="commerce-sub-upgrade-btn" data-id="' + escapeHtml(s.id) + '" disabled>Upgrade</button></div>';
      }
      if (canPause) {
        html += '<button class="btn btn-secondary" id="commerce-sub-pause" data-id="' + escapeHtml(s.id) + '">Pause subscription</button> ';
      }
      if (canResume) {
        html += '<button class="btn btn-primary" id="commerce-sub-resume" data-id="' + escapeHtml(s.id) + '">Resume subscription</button> ';
      }
      if (canCancel) {
        html += '<button class="btn btn-danger" id="commerce-sub-cancel" data-id="' + escapeHtml(s.id) + '">Cancel subscription</button>';
      }
      html += '</div></div>';
      detail.innerHTML = html;

      var retryBtn = document.getElementById('commerce-sub-retry');
      if (retryBtn) {
        retryBtn.addEventListener('click', function () {
          if (!confirm('Retry payment for this subscription?')) return;
          commercePost('retry_subscription_payment', { id: retryBtn.getAttribute('data-id') }).then(function (r) {
            if (r.status === 'ok') { viewSubscription(id); }
            else { alert((r.message) || 'Payment retry failed'); }
          });
        });
      }
      var upgradeSelect = document.getElementById('commerce-sub-upgrade-select');
      var upgradeBtn = document.getElementById('commerce-sub-upgrade-btn');
      if (upgradeSelect && upgradeBtn) {
        commercePost('list_subscription_upgrade_options', { id: id }).then(function (optRes) {
          var options = (optRes.data && optRes.data.options) || [];
          if (!options.length) { upgradeSelect.innerHTML = '<option value="">No other plans available</option>'; return; }
          upgradeSelect.innerHTML = '<option value="">Select plan…</option>';
          options.forEach(function (opt) {
            var label = (opt.label || opt.id) + ' — ' + formatCents(opt.price_cents, opt.currency) + ' / ' + (opt.interval || 'month');
            upgradeSelect.innerHTML += '<option value="' + escapeHtml(opt.id) + '">' + escapeHtml(label) + '</option>';
          });
          upgradeBtn.disabled = false;
        });
        upgradeBtn.addEventListener('click', function () {
          var optionId = upgradeSelect.value;
          if (!optionId) { alert('Select a plan to upgrade to'); return; }
          if (!confirm('Change subscription to the selected plan? Proration may apply.')) return;
          commercePost('upgrade_subscription', { id: upgradeBtn.getAttribute('data-id'), purchase_option_id: optionId }).then(function (r) {
            if (r.status === 'ok') { viewSubscription(id); }
            else { alert((r.message) || 'Upgrade failed'); }
          });
        });
      }
      var cancelBtn = document.getElementById('commerce-sub-cancel');
      if (cancelBtn) {
        cancelBtn.addEventListener('click', function () {
          if (!confirm('Cancel this subscription? This cannot be undone.')) return;
          commercePost('cancel_subscription', { id: cancelBtn.getAttribute('data-id') }).then(function (r) {
            if (r.status === 'ok') {
              viewSubscription(id);
            } else {
              alert((r.message) || 'Failed to cancel subscription');
            }
          });
        });
      }
      var pauseBtn = document.getElementById('commerce-sub-pause');
      if (pauseBtn) {
        pauseBtn.addEventListener('click', function () {
          if (!confirm('Pause billing for this subscription?')) return;
          commercePost('pause_subscription', { id: pauseBtn.getAttribute('data-id') }).then(function (r) {
            if (r.status === 'ok') { viewSubscription(id); }
            else { alert((r.message) || 'Failed to pause subscription'); }
          });
        });
      }
      var resumeBtn = document.getElementById('commerce-sub-resume');
      if (resumeBtn) {
        resumeBtn.addEventListener('click', function () {
          if (!confirm('Resume billing for this subscription?')) return;
          commercePost('resume_subscription', { id: resumeBtn.getAttribute('data-id') }).then(function (r) {
            if (r.status === 'ok') { viewSubscription(id); }
            else { alert((r.message) || 'Failed to resume subscription'); }
          });
        });
      }
    }).catch(function (err) {
      detail.innerHTML = '<p class="error">Failed to load subscription' + (err && err.message ? (': ' + escapeHtml(err.message)) : '') + '</p>';
    });
  }

  var pendingRefundReload = null;

  function closeRefundModal() {
    closeCommerceModal(document.getElementById('commerce-refund-modal'));
  }

  function promptRefund(btn) {
    var orderId = btn.getAttribute('data-order-id');
    if (!orderId) return;
    var remaining = parseInt(btn.getAttribute('data-remaining'), 10) || 0;
    var currency = btn.getAttribute('data-currency') || commerceDefaultCurrency();
    var lineId = btn.getAttribute('data-line-id') || '';
    var label = lineId ? 'this line item' : 'the order';
    var modal = document.getElementById('commerce-refund-modal');
    if (!modal) return;
    document.getElementById('commerce-refund-order-id').value = orderId;
    document.getElementById('commerce-refund-line-id').value = lineId;
    document.getElementById('commerce-refund-remaining').value = String(remaining);
    document.getElementById('commerce-refund-amount').value = '';
    document.getElementById('commerce-refund-reason').value = '';
    document.getElementById('commerce-refund-summary').textContent =
      'Refund ' + label + '. Full remaining: ' + formatCents(remaining, currency) + '.';
    pendingRefundReload = function () {
      if ((location.hash || '').indexOf('#order/') === 0) {
        viewOrder(orderId);
      } else {
        loadOrders();
      }
    };
    openCommerceModal(modal);
    window.setTimeout(function () {
      document.getElementById('commerce-refund-amount')?.focus();
    }, 0);
  }

  function submitRefundModal() {
    var orderId = document.getElementById('commerce-refund-order-id')?.value || '';
    if (!orderId) return;
    var lineId = document.getElementById('commerce-refund-line-id')?.value || '';
    var body = { id: orderId };
    if (lineId) body.line_id = lineId;
    var trimmed = (document.getElementById('commerce-refund-amount')?.value || '').trim();
    if (trimmed !== '') {
      var amount = parseFloat(trimmed);
      if (isNaN(amount) || amount <= 0) {
        alert('Enter a valid refund amount, or leave blank for full remaining.');
        return;
      }
      body.amount_cents = Math.round(amount * 100);
    }
    body.reason = document.getElementById('commerce-refund-reason')?.value || '';
    commercePost('refund_order', body).then(function (res) {
      if (res.status !== 'ok') {
        commerceToast('Refund failed: ' + commerceErrorMessage(res), true);
        return;
      }
      closeRefundModal();
      commerceToast('Refund processed');
      if (typeof pendingRefundReload === 'function') pendingRefundReload();
      else if (typeof loadOrderDetail === 'function' && orderId) loadOrderDetail(orderId);
    }).catch(function (err) {
      commerceToast('Refund failed: ' + (err && err.message ? err.message : 'Network error'), true);
    });
  }

  var pendingCancelReload = null;

  function closeCancelModal() {
    closeCommerceModal(document.getElementById('commerce-cancel-modal'));
  }

  function promptCancelOrder(btn) {
    var orderId = btn.getAttribute('data-order-id');
    if (!orderId) return;
    var remaining = parseInt(btn.getAttribute('data-remaining'), 10) || 0;
    var currency = btn.getAttribute('data-currency') || commerceDefaultCurrency();
    var status = btn.getAttribute('data-status') || '';
    var modal = document.getElementById('commerce-cancel-modal');
    if (!modal) return;
    document.getElementById('commerce-cancel-order-id').value = orderId;
    document.getElementById('commerce-cancel-reason').value = '';
    var refundCb = document.getElementById('commerce-cancel-refund');
    var paidLike = status === 'paid' || status === 'partially_refunded';
    if (refundCb) {
      refundCb.checked = paidLike && remaining > 0;
      refundCb.disabled = !paidLike || remaining <= 0;
    }
    document.getElementById('commerce-cancel-summary').textContent = paidLike && remaining > 0
      ? ('Cancel this order and stop fulfillment. Remaining balance: ' + formatCents(remaining, currency) + '.')
      : 'Cancel this order and stop fulfillment. No paid balance to refund.';
    pendingCancelReload = function () {
      if ((location.hash || '').indexOf('#order/') === 0) {
        viewOrder(orderId);
      } else {
        loadOrders();
      }
      if (document.getElementById('payments-tab-fulfillment') && !document.getElementById('payments-tab-fulfillment').hidden) {
        loadFulfillmentDesk();
      }
      refreshActivityBadges();
    };
    openCommerceModal(modal);
    window.setTimeout(function () {
      document.getElementById('commerce-cancel-reason')?.focus();
    }, 0);
  }

  function submitCancelModal() {
    var orderId = document.getElementById('commerce-cancel-order-id')?.value || '';
    if (!orderId) return;
    var body = {
      id: orderId,
      reason: document.getElementById('commerce-cancel-reason')?.value || '',
      refund: !!document.getElementById('commerce-cancel-refund')?.checked,
    };
    commercePost('cancel_order', body).then(function (res) {
      if (res.status !== 'ok') {
        alert('Cancel failed: ' + (res.message || 'Unknown error'));
        return;
      }
      closeCancelModal();
      commerceToast(body.refund ? 'Order canceled and refunded' : 'Order canceled');
      if (typeof pendingCancelReload === 'function') pendingCancelReload();
    });
  }

  function initAccordionNavigation() {
    document.addEventListener('change', function (e) {
      var t = eventEl(e);
      if (!t) return;
      var select = t.closest('.commerce-order-select');
      if (!select) return;
      var id = select.getAttribute('data-id');
      if (!id) return;
      if (select.checked) selectedOrderIds[id] = true;
      else delete selectedOrderIds[id];
      updateOrdersBulkBar();
    });

    document.addEventListener('click', function (e) {
      var t = eventEl(e);
      if (!t) return;

      if (t.closest('.commerce-row-check') || t.closest('.commerce-order-select')) {
        e.stopPropagation();
        return;
      }

      var openCustomer = t.closest('.commerce-open-customer');
      if (openCustomer) {
        e.preventDefault();
        e.stopPropagation();
        openCustomerTimeline(openCustomer.getAttribute('data-email') || openCustomer.getAttribute('data-id') || '');
        return;
      }

      var emailLogBtn = t.closest('.commerce-open-email-log');
      if (emailLogBtn) {
        e.preventDefault();
        e.stopPropagation();
        openCommerceEmailLog();
        return;
      }

      var syncPayBtn = t.closest('.commerce-sync-order-payment');
      if (syncPayBtn) {
        e.preventDefault();
        e.stopPropagation();
        var syncId = syncPayBtn.getAttribute('data-id');
        if (!syncId) return;
        if (!window.confirm('Confirm payment with the provider and mark this order paid? This also sends the receipt email if enabled.')) {
          return;
        }
        syncPayBtn.disabled = true;
        commercePost('sync_order_payment', { id: syncId }).then(function (res) {
          syncPayBtn.disabled = false;
          if (res.status !== 'ok') {
            alert(res.message || 'Payment could not be confirmed');
            return;
          }
          viewOrder(syncId);
          loadOrders();
          alert('Order marked paid. Check Settings → Emails → Recent sends for delivery status.');
        }).catch(function () {
          syncPayBtn.disabled = false;
          alert('Failed to confirm payment');
        });
        return;
      }

      var resendBtn = t.closest('.commerce-resend-receipt');
      if (resendBtn) {
        e.preventDefault();
        e.stopPropagation();
        var resendId = resendBtn.getAttribute('data-id');
        if (!resendId) return;
        resendBtn.disabled = true;
        commercePost('resend_order_email', { id: resendId }).then(function (res) {
          resendBtn.disabled = false;
          if (res.status !== 'ok') {
            alert(res.message || 'Failed to resend receipt');
            return;
          }
          alert('Receipt send attempted. Open View email log for delivery status.');
          openCommerceEmailLog();
        }).catch(function () {
          resendBtn.disabled = false;
          alert('Failed to resend receipt');
        });
        return;
      }

      var invoiceBtn = t.closest('.commerce-invoice-order');
      if (invoiceBtn) {
        e.preventDefault();
        e.stopPropagation();
        var invoiceId = invoiceBtn.getAttribute('data-id');
        if (!invoiceId) return;
        openHtmlDocumentAsync(
          commercePost('order_invoice', { id: invoiceId }).then(function (res) {
            if (res.status !== 'ok' || !res.data || !res.data.html) {
              throw new Error(res.message || 'Failed to build invoice');
            }
            return res.data.html;
          }),
          'invoice.html'
        ).catch(function (err) {
          alert((err && err.message) || 'Failed to build invoice');
        });
        return;
      }

      var createShip = t.closest('.commerce-create-shipment');
      if (createShip) {
        e.preventDefault();
        var form = createShip.closest('.commerce-create-shipment-form');
        if (!form) return;
        var orderId = form.getAttribute('data-order-id');
        var items = [];
        form.querySelectorAll('.commerce-ship-item-row').forEach(function (row) {
          var check = row.querySelector('.commerce-ship-item-check');
          if (check && !check.checked) return;
          var qty = parseInt(row.querySelector('.commerce-ship-item-qty')?.value || '0', 10);
          var lineId = row.getAttribute('data-line-id');
          if (!lineId || !qty || qty < 1) return;
          items.push({ line_id: lineId, quantity: qty });
        });
        if (!items.length) {
          alert('Select at least one item quantity to ship');
          return;
        }
        var carrier = form.querySelector('.commerce-ship-carrier')?.value.trim() || '';
        var tracking = form.querySelector('.commerce-ship-tracking')?.value.trim() || '';
        var packages = parseInt(form.querySelector('.commerce-ship-packages')?.value || '1', 10) || 1;
        var notify = !!form.querySelector('.commerce-ship-notify-cb')?.checked;
        createShip.disabled = true;
        commercePost('create_shipment', {
          id: orderId,
          items: items,
          tracking_number: tracking,
          carrier: carrier,
          package_count: packages,
          notify_customer: notify,
        }).then(function (res) {
          createShip.disabled = false;
          if (res.status !== 'ok') {
            alert(res.message || 'Failed to create shipment');
            return;
          }
          viewOrder(orderId);
          loadOrders();
          if (document.getElementById('payments-tab-fulfillment') && !document.getElementById('payments-tab-fulfillment').hidden) {
            loadFulfillmentDesk();
          }
          refreshActivityBadges();
        }).catch(function () {
          createShip.disabled = false;
          alert('Failed to create shipment');
        });
        return;
      }

      var slipShip = t.closest('.commerce-packing-slip-shipment');
      if (slipShip) {
        e.preventDefault();
        var oid = slipShip.getAttribute('data-order-id');
        var sid = slipShip.getAttribute('data-shipment-id');
        openHtmlDocumentAsync(
          commercePost('packing_slips', {
            ids: [oid],
            id: oid,
            shipment_id: sid,
            brand_name: 'Packing slip',
          }).then(function (res) {
            if (res.status !== 'ok' || !res.data || !res.data.html) {
              throw new Error(res.message || 'Failed to build packing slip');
            }
            return res.data.html;
          }),
          'packing-slip.html'
        ).catch(function (err) {
          alert((err && err.message) || 'Failed to build packing slip');
        });
        return;
      }

      var slipRem = t.closest('.commerce-packing-slip-remaining');
      if (slipRem) {
        e.preventDefault();
        var remId = slipRem.getAttribute('data-order-id');
        openHtmlDocumentAsync(
          commercePost('packing_slips', {
            ids: [remId],
            remaining_only: slipRem.getAttribute('data-all') !== '1',
            brand_name: 'Packing slip',
          }).then(function (res) {
            if (res.status !== 'ok' || !res.data || !res.data.html) {
              throw new Error(res.message || 'Failed to build packing slip');
            }
            return res.data.html;
          }),
          'packing-slip.html'
        ).catch(function (err) {
          alert((err && err.message) || 'Failed to build packing slip');
        });
        return;
      }

      var refundBtn = t.closest('.commerce-refund-order');
      if (refundBtn) {
        e.preventDefault();
        promptRefund(refundBtn);
        return;
      }

      var cancelBtn = t.closest('.commerce-cancel-order');
      if (cancelBtn) {
        e.preventDefault();
        e.stopPropagation();
        promptCancelOrder(cancelBtn);
        return;
      }

      var printOrderBtn = t.closest('.commerce-print-order');
      if (printOrderBtn) {
        e.preventDefault();
        e.stopPropagation();
        var printOrderId = printOrderBtn.getAttribute('data-id');
        var orderToPrint = (ordersCache || []).find(function (o) { return o.id === printOrderId; })
          || (currentOrderDetail && currentOrderDetail.id === printOrderId ? currentOrderDetail : null);
        if (orderToPrint) printOrderDocument(orderToPrint);
        else if (printOrderId) {
          commercePost('get_order', { id: printOrderId }).then(function (res) {
            if (res.data && res.data.order) printOrderDocument(res.data.order);
          });
        }
        return;
      }

      var printSubBtn = t.closest('.commerce-print-subscription');
      if (printSubBtn) {
        e.preventDefault();
        e.stopPropagation();
        var printSubId = printSubBtn.getAttribute('data-id');
        var subToPrint = (subscriptionsCache || []).find(function (s) { return s.id === printSubId; })
          || (currentSubscriptionDetail && currentSubscriptionDetail.id === printSubId ? currentSubscriptionDetail : null);
        if (subToPrint) printSubscriptionDocument(subToPrint);
        else if (printSubId) {
          commercePost('get_subscription', { id: printSubId }).then(function (res) {
            if (res.data && res.data.subscription) printSubscriptionDocument(res.data.subscription);
          });
        }
        return;
      }

      var toggle = t.closest('[data-accordion-toggle]');
      if (toggle) {
        e.preventDefault();
        var kind = toggle.getAttribute('data-accordion-toggle');
        var id = toggle.getAttribute('data-id');
        if (!id) return;
        if (kind === 'order') {
          if (expandedOrders[id]) delete expandedOrders[id];
          else expandedOrders[id] = true;
          renderOrdersList();
        } else if (kind === 'subscription') {
          if (expandedSubs[id]) delete expandedSubs[id];
          else expandedSubs[id] = true;
          renderSubscriptionsList();
        }
        return;
      }

      var openOrder = t.closest('.commerce-open-order');
      if (openOrder) {
        e.preventDefault();
        e.stopPropagation();
        var orderId = openOrder.getAttribute('data-id');
        if (!orderId) return;
        setCommerceHash('order/' + orderId);
        activateCommerceTab('orders');
        viewOrder(orderId);
        return;
      }

      var openSub = t.closest('.commerce-open-subscription');
      if (openSub) {
        e.preventDefault();
        e.stopPropagation();
        var subId = openSub.getAttribute('data-id');
        if (!subId) return;
        setCommerceHash('subscription/' + subId);
        activateCommerceTab('subscriptions');
        viewSubscription(subId);
      }
    });
  }

  function routeCommerceHash() {
    var hash = (location.hash || '').replace(/^#/, '');
    if (!hash) return false;
    if (hash === 'analytics' || hash === 'dashboard') {
      setCommerceHash('dashboard');
      activateCommerceTab('dashboard');
      return true;
    }
    if (hash === 'stock' || hash === 'inventory') {
      setCommerceHash('inventory');
      activateCommerceTab('inventory');
      return true;
    }
    if (hash.indexOf('inventory/sku/') === 0) {
      var sku = decodeURIComponent(hash.slice('inventory/sku/'.length));
      activateCommerceTab('inventory');
      setCommerceHash('inventory/sku/' + encodeURIComponent(sku));
      focusInventorySku(sku);
      return true;
    }
    if (hash === 'connections') {
      setCommerceHash('connections');
      activateCommerceTab('connections');
      return true;
    }
    if (hash === 'migration') {
      setCommerceHash('settings/import');
      activateCommerceTab('settings');
      activateSettingsPanel('import', { skipHash: true });
      return true;
    }
    if (hash === 'docs' || hash === 'documentation' || hash.indexOf('docs/') === 0) {
      setCommerceHash(hash.indexOf('docs') === 0 ? hash : 'docs');
      activateCommerceTab('docs');
      activateCommerceDocs();
      return true;
    }
    if (hash.indexOf('settings/') === 0) {
      var panelKey = hash.slice('settings/'.length) || 'connections';
      if (panelKey === 'migration') panelKey = 'import';
      if (panelKey === 'documentation' || panelKey === 'docs') {
        setCommerceHash('docs');
        activateCommerceTab('docs');
        activateCommerceDocs();
        return true;
      }
      activateCommerceTab('settings');
      activateSettingsPanel(panelKey, { skipHash: true });
      return true;
    }
    var settingsBtn = document.querySelector('.commerce-settings-nav .side-nav-item[data-settings-panel="' + hash + '"]');
    if (settingsBtn) {
      activateCommerceTab('settings');
      activateSettingsPanel(hash);
      return true;
    }
    if (hash === 'draft-orders' || hash === 'quotes') {
      if (hash === 'quotes') setCommerceHash('draft-orders');
      activateCommerceTab('orders');
      showDraftOrdersView();
      loadQuotes();
      return true;
    }
    if (hash.indexOf('order/') === 0) {
      activateCommerceTab('orders');
      viewOrder(hash.slice('order/'.length));
      return true;
    }
    if (hash.indexOf('customer-profile/') === 0) {
      openCustomerProfile(decodeURIComponent(hash.slice('customer-profile/'.length)), false);
      return true;
    }
    if (hash === 'customers/new') {
      openNewCustomer();
      return true;
    }
    if (hash.indexOf('customer/') === 0) {
      activateCommerceTab('orders');
      openCustomerTimeline(decodeURIComponent(hash.slice('customer/'.length)));
      return true;
    }
    if (hash.indexOf('subscription/') === 0) {
      activateCommerceTab('subscriptions');
      viewSubscription(hash.slice('subscription/'.length));
      return true;
    }
    if (hash === 'orders' || hash === 'subscriptions' || hash === 'customers' || hash === 'fulfillment') {
      activateCommerceTab(hash);
      return true;
    }
    var hashTab = document.querySelector('.commerce-tabs .tab[data-tab="' + hash + '"]');
    if (hashTab) {
      hashTab.click();
      return true;
    }
    return false;
  }

  var shippingZonesCache = [];
  var shippingRegionOptions = [
    { label: 'All countries', codes: ['*'] },
    { label: 'European Union (sample)', codes: ['DE', 'FR', 'IT', 'ES', 'NL', 'BE', 'AT', 'PL', 'SE'] },
    { label: 'North America', codes: ['US', 'CA', 'MX'] },
    { label: 'United Kingdom', codes: ['GB'] },
    { label: 'Germany', codes: ['DE'] },
    { label: 'France', codes: ['FR'] },
    { label: 'United States', codes: ['US'] },
  ];
  var warehouseCache = [];
  var inventoryMode = 'simple';

  var shippingConfigCache = {
    provider: 'manual',
    easypost_api_key_set: false,
    from_address: {},
    free_shipping_min_cents: 0,
  };

  function syncShippingProviderUi() {
    var provider = document.getElementById('commerce-shipping-rate-provider')?.value || shippingConfigCache.provider || 'manual';
    shippingConfigCache.provider = provider;
    var ep = document.getElementById('commerce-shipping-easypost-fields');
    if (ep) ep.hidden = provider !== 'easypost';
  }

  function syncFreeShippingUi() {
    var enabled = !!document.getElementById('commerce-free-shipping-enabled')?.checked;
    var wrap = document.getElementById('commerce-free-shipping-amount-wrap');
    if (wrap) wrap.hidden = !enabled;
  }

  function loadShippingZones() {
    var el = document.getElementById('commerce-shipping-zones-list');
    if (!el) return;
    commercePost('list_shipping_zones').then(function (res) {
      var data = res.data || {};
      shippingZonesCache = Array.isArray(data.zones) ? data.zones : [];
      shippingConfigCache = {
        provider: data.provider === 'easypost' ? 'easypost' : 'manual',
        easypost_api_key_set: !!data.easypost_api_key_set,
        from_address: data.from_address && typeof data.from_address === 'object' ? data.from_address : {},
        free_shipping_min_cents: Math.max(0, parseInt(data.free_shipping_min_cents || 0, 10) || 0),
      };
      var providerEl = document.getElementById('commerce-shipping-rate-provider');
      if (providerEl) providerEl.value = shippingConfigCache.provider;
      var fromCountry = document.getElementById('commerce-shipping-from-country');
      var fromZip = document.getElementById('commerce-shipping-from-zip');
      if (fromCountry) fromCountry.value = shippingConfigCache.from_address.country || '';
      if (fromZip) fromZip.value = shippingConfigCache.from_address.zip || '';
      var keyStatus = document.getElementById('commerce-easypost-key-status');
      if (keyStatus) keyStatus.hidden = !shippingConfigCache.easypost_api_key_set;
      var freeEnabled = document.getElementById('commerce-free-shipping-enabled');
      var freeMin = document.getElementById('commerce-free-shipping-min-cents');
      if (freeEnabled) freeEnabled.checked = shippingConfigCache.free_shipping_min_cents > 0;
      if (freeMin) freeMin.value = shippingConfigCache.free_shipping_min_cents > 0 ? String(shippingConfigCache.free_shipping_min_cents) : '';
      syncShippingProviderUi();
      syncFreeShippingUi();
      renderShippingZones();
    });
  }

  function renderShippingZones() {
    var el = document.getElementById('commerce-shipping-zones-list');
    if (!el) return;
    if (!shippingZonesCache.length) {
      el.innerHTML = '<p>No shipping zones configured.</p>';
      return;
    }
    var html = '';
    shippingZonesCache.forEach(function (zone, idx) {
      var rateType = zone.rate_type || 'flat';
      var tiers = Array.isArray(zone.weight_tiers) ? zone.weight_tiers : [];
      html += '<div class="commerce-shipping-zone commerce-settings-row" data-idx="' + idx + '">';
      html += '<div class="form-group"><label>Name</label><input type="text" class="input zone-name" value="' + escapeHtml(zone.name || '') + '"></div>';
      html += '<div class="form-group"><label>Region preset</label><select class="input zone-region-preset" data-idx="' + idx + '">';
      shippingRegionOptions.forEach(function (opt) {
        html += '<option value="' + escapeHtml(opt.codes.join(',')) + '">' + escapeHtml(opt.label) + '</option>';
      });
      html += '</select></div>';
      html += '<div class="form-group"><label>Countries (* = all)</label><input type="text" class="input zone-countries" value="' + escapeHtml((zone.countries || ['*']).join(', ')) + '"></div>';
      html += '<div class="form-group"><label>Rate type</label><select class="input zone-rate-type" data-idx="' + idx + '">';
      html += '<option value="flat"' + (rateType === 'flat' ? ' selected' : '') + '>Flat rate</option>';
      html += '<option value="weight_tiers"' + (rateType === 'weight_tiers' ? ' selected' : '') + '>Weight tiers</option>';
      html += '</select></div>';
      html += '<div class="form-group zone-flat-row" data-idx="' + idx + '"' + (rateType === 'weight_tiers' ? ' hidden' : '') + '><label>Flat rate (cents)</label><input type="number" class="input zone-rate" value="' + (zone.flat_rate_cents || 0) + '"></div>';
      html += '<div class="form-group zone-weight-tiers commerce-settings-form-span" data-idx="' + idx + '"' + (rateType !== 'weight_tiers' ? ' hidden' : '') + '>';
      html += '<label>Weight tiers (max grams → rate cents)</label>';
      if (!tiers.length) tiers = [{ max_grams: 500, rate_cents: 500 }, { max_grams: null, rate_cents: 900 }];
      tiers.forEach(function (tier, tIdx) {
        html += '<div class="commerce-weight-tier-row"><input type="number" class="input zone-tier-max" placeholder="max g (blank=∞)" value="' + (tier.max_grams == null ? '' : tier.max_grams) + '">';
        html += '<input type="number" class="input zone-tier-rate" placeholder="rate cents" value="' + (tier.rate_cents || 0) + '">';
        html += '<button type="button" class="btn btn-secondary commerce-remove-tier" data-zone="' + idx + '" data-tier="' + tIdx + '">×</button></div>';
      });
      html += '<button type="button" class="btn btn-secondary commerce-add-tier" data-idx="' + idx + '">Add tier</button></div>';
      html += '<div class="commerce-settings-row__actions"><button type="button" class="btn btn-secondary commerce-remove-zone" data-idx="' + idx + '">Remove</button></div></div>';
    });
    el.innerHTML = html;
    el.querySelectorAll('.zone-region-preset').forEach(function (sel) {
      sel.addEventListener('change', function () {
        var row = sel.closest('.commerce-shipping-zone');
        var countries = row?.querySelector('.zone-countries');
        if (countries) countries.value = sel.value.split(',').join(', ');
      });
    });
    el.querySelectorAll('.zone-rate-type').forEach(function (sel) {
      sel.addEventListener('change', function () {
        var idx = sel.getAttribute('data-idx');
        var flat = el.querySelector('.zone-flat-row[data-idx="' + idx + '"]');
        var tiers = el.querySelector('.zone-weight-tiers[data-idx="' + idx + '"]');
        var isWeight = sel.value === 'weight_tiers';
        if (flat) flat.hidden = isWeight;
        if (tiers) tiers.hidden = !isWeight;
      });
    });
    el.querySelectorAll('.commerce-remove-zone').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var i = parseInt(btn.getAttribute('data-idx'), 10);
        shippingZonesCache.splice(i, 1);
        renderShippingZones();
      });
    });
    el.querySelectorAll('.commerce-add-tier').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var i = parseInt(btn.getAttribute('data-idx'), 10);
        if (!shippingZonesCache[i].weight_tiers) shippingZonesCache[i].weight_tiers = [];
        shippingZonesCache[i].weight_tiers.push({ max_grams: null, rate_cents: 0 });
        renderShippingZones();
      });
    });
    el.querySelectorAll('.commerce-remove-tier').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var zi = parseInt(btn.getAttribute('data-zone'), 10);
        var ti = parseInt(btn.getAttribute('data-tier'), 10);
        shippingZonesCache[zi].weight_tiers.splice(ti, 1);
        renderShippingZones();
      });
    });
  }

  var taxRulesCache = {
    enabled: false,
    provider: 'manual',
    default_rate: 0,
    country_rates: [],
    classes: {},
    class_country_rates: [],
    b2b_reverse_charge: {
      enabled: false,
      merchant_country: '',
      eligible_countries: [],
      require_different_country: true,
    },
  };

  function syncB2bTaxUiFromCache() {
    var b2b = taxRulesCache.b2b_reverse_charge || {};
    var enabledEl = document.getElementById('commerce-tax-b2b-enabled');
    var merchantEl = document.getElementById('commerce-tax-b2b-merchant');
    var diffEl = document.getElementById('commerce-tax-b2b-require-diff');
    var eligibleEl = document.getElementById('commerce-tax-b2b-eligible');
    if (enabledEl) enabledEl.checked = !!b2b.enabled;
    if (merchantEl) merchantEl.value = b2b.merchant_country || '';
    if (diffEl) diffEl.checked = b2b.require_different_country !== false;
    if (eligibleEl) {
      eligibleEl.value = Array.isArray(b2b.eligible_countries)
        ? b2b.eligible_countries.join(', ')
        : '';
    }
  }

  function readB2bTaxUi() {
    var eligibleRaw = (document.getElementById('commerce-tax-b2b-eligible')?.value || '').trim();
    var eligible = [];
    if (eligibleRaw) {
      eligibleRaw.split(/[\s,;]+/).forEach(function (part) {
        var cc = String(part || '').trim().toUpperCase();
        if (/^[A-Z]{2}$/.test(cc) && eligible.indexOf(cc) === -1) eligible.push(cc);
      });
    }
    return {
      enabled: !!document.getElementById('commerce-tax-b2b-enabled')?.checked,
      merchant_country: (document.getElementById('commerce-tax-b2b-merchant')?.value || '').trim().toUpperCase(),
      eligible_countries: eligible,
      require_different_country: !!document.getElementById('commerce-tax-b2b-require-diff')?.checked,
    };
  }

  function syncTaxProviderUi() {
    var provider = (document.getElementById('commerce-tax-provider')?.value || taxRulesCache.provider || 'manual');
    taxRulesCache.provider = provider;
    var stripeNote = document.getElementById('commerce-tax-stripe-note');
    var manualFields = document.getElementById('commerce-tax-manual-fields');
    if (stripeNote) stripeNote.hidden = provider !== 'stripe_tax';
    // Manual rate UI remains for Manual provider; also used as Stripe Tax mock fallback.
    if (manualFields) {
      manualFields.style.opacity = provider === 'manual' ? '1' : '0.85';
    }
  }

  function taxClassesAsRows() {
    var rows = [];
    var classes = taxRulesCache.classes || {};
    Object.keys(classes).forEach(function (code) {
      var meta = classes[code] || {};
      rows.push({
        code: code,
        label: meta.label || code,
        default_rate: meta.default_rate === null || meta.default_rate === undefined ? '' : meta.default_rate,
      });
    });
    rows.sort(function (a, b) { return String(a.code).localeCompare(String(b.code)); });
    return rows;
  }

  function loadTaxRules() {
    var el = document.getElementById('commerce-tax-country-list');
    if (!el) return;
    commercePost('list_tax_rules').then(function (res) {
      var data = res.data || {};
      var b2b = data.b2b_reverse_charge && typeof data.b2b_reverse_charge === 'object'
        ? data.b2b_reverse_charge
        : {};
      taxRulesCache = {
        enabled: !!data.enabled,
        provider: data.provider === 'stripe_tax' ? 'stripe_tax' : 'manual',
        default_rate: Number(data.default_rate) || 0,
        country_rates: Array.isArray(data.country_rates) ? data.country_rates : [],
        classes: data.classes && typeof data.classes === 'object' ? data.classes : {},
        class_country_rates: Array.isArray(data.class_country_rates) ? data.class_country_rates : [],
        b2b_reverse_charge: {
          enabled: !!b2b.enabled,
          merchant_country: b2b.merchant_country || '',
          eligible_countries: Array.isArray(b2b.eligible_countries) ? b2b.eligible_countries : [],
          require_different_country: b2b.require_different_country !== false,
        },
      };
      var enabledEl = document.getElementById('commerce-tax-enabled');
      var rateEl = document.getElementById('commerce-tax-default-rate');
      var providerEl = document.getElementById('commerce-tax-provider');
      if (enabledEl) enabledEl.checked = taxRulesCache.enabled;
      if (rateEl) rateEl.value = taxRulesCache.default_rate;
      if (providerEl) providerEl.value = taxRulesCache.provider;
      syncTaxProviderUi();
      syncB2bTaxUiFromCache();
      renderTaxCountries();
      renderTaxClasses();
      renderTaxClassCountries();
    });
  }

  function renderTaxCountries() {
    var el = document.getElementById('commerce-tax-country-list');
    if (!el) return;
    if (!taxRulesCache.country_rates.length) {
      el.innerHTML = '<p>No country overrides. The default rate applies when class rates do not match.</p>';
      return;
    }
    var html = '';
    taxRulesCache.country_rates.forEach(function (entry, idx) {
      html += '<div class="commerce-tax-country commerce-settings-row" data-idx="' + idx + '">';
      html += '<div class="form-group"><label>Country code (ISO)</label><input type="text" class="input tax-country" maxlength="2" value="' + escapeHtml(entry.country || '') + '"></div>';
      html += '<div class="form-group"><label>Rate (%)</label><input type="number" step="0.01" min="0" class="input tax-rate" value="' + (Number(entry.rate) || 0) + '"></div>';
      html += '<div class="commerce-settings-row__actions"><button type="button" class="btn btn-secondary commerce-remove-tax-country" data-idx="' + idx + '">Remove</button></div></div>';
    });
    el.innerHTML = html;
    el.querySelectorAll('.commerce-remove-tax-country').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var i = parseInt(btn.getAttribute('data-idx'), 10);
        taxRulesCache.country_rates.splice(i, 1);
        renderTaxCountries();
      });
    });
  }

  function syncTaxClassesFromDom() {
    var el = document.getElementById('commerce-tax-class-list');
    if (!el) return;
    var next = {};
    el.querySelectorAll('.commerce-tax-class-row').forEach(function (row) {
      var code = (row.querySelector('.tax-class-code')?.value || '').trim().toLowerCase();
      if (!code) return;
      var rateRaw = (row.querySelector('.tax-class-rate')?.value || '').trim();
      next[code] = {
        label: (row.querySelector('.tax-class-label')?.value || code).trim() || code,
        default_rate: rateRaw === '' ? null : (parseFloat(rateRaw) || 0),
      };
    });
    taxRulesCache.classes = next;
  }

  function renderTaxClasses() {
    var el = document.getElementById('commerce-tax-class-list');
    if (!el) return;
    var rows = taxClassesAsRows();
    if (!rows.length) {
      el.innerHTML = '<p>No tax classes defined.</p>';
      return;
    }
    var html = '';
    rows.forEach(function (entry, idx) {
      html += '<div class="commerce-tax-class-row commerce-settings-row" data-idx="' + idx + '">';
      html += '<div class="form-group"><label>Code</label><input type="text" class="input tax-class-code" value="' + escapeHtml(entry.code || '') + '"></div>';
      html += '<div class="form-group"><label>Label</label><input type="text" class="input tax-class-label" value="' + escapeHtml(entry.label || '') + '"></div>';
      html += '<div class="form-group"><label>Default rate (%) — blank = inherit</label><input type="number" step="0.01" min="0" class="input tax-class-rate" value="' + escapeHtml(entry.default_rate === '' || entry.default_rate === null || entry.default_rate === undefined ? '' : String(entry.default_rate)) + '"></div>';
      html += '<div class="commerce-settings-row__actions"><button type="button" class="btn btn-secondary commerce-remove-tax-class" data-code="' + escapeHtml(entry.code || '') + '">Remove</button></div></div>';
    });
    el.innerHTML = html;
    el.querySelectorAll('.commerce-remove-tax-class').forEach(function (btn) {
      btn.addEventListener('click', function () {
        syncTaxClassesFromDom();
        var code = btn.getAttribute('data-code');
        if (code && taxRulesCache.classes[code]) delete taxRulesCache.classes[code];
        renderTaxClasses();
        renderTaxClassCountries();
      });
    });
  }

  function renderTaxClassCountries() {
    var el = document.getElementById('commerce-tax-class-country-list');
    if (!el) return;
    if (!taxRulesCache.class_country_rates.length) {
      el.innerHTML = '<p>No class×country overrides.</p>';
      return;
    }
    var classOpts = Object.keys(taxRulesCache.classes || {});
    var html = '';
    taxRulesCache.class_country_rates.forEach(function (entry, idx) {
      html += '<div class="commerce-tax-class-country commerce-settings-row" data-idx="' + idx + '">';
      html += '<div class="form-group"><label>Class</label><input type="text" class="input tax-cc-class" list="commerce-tax-class-datalist" value="' + escapeHtml(entry.class || '') + '"></div>';
      html += '<div class="form-group"><label>Country</label><input type="text" class="input tax-cc-country" maxlength="2" value="' + escapeHtml(entry.country || '') + '"></div>';
      html += '<div class="form-group"><label>Rate (%)</label><input type="number" step="0.01" min="0" class="input tax-cc-rate" value="' + (Number(entry.rate) || 0) + '"></div>';
      html += '<div class="commerce-settings-row__actions"><button type="button" class="btn btn-secondary commerce-remove-tax-class-country" data-idx="' + idx + '">Remove</button></div></div>';
    });
    html += '<datalist id="commerce-tax-class-datalist">';
    classOpts.forEach(function (c) { html += '<option value="' + escapeHtml(c) + '">'; });
    html += '</datalist>';
    el.innerHTML = html;
    el.querySelectorAll('.commerce-remove-tax-class-country').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var i = parseInt(btn.getAttribute('data-idx'), 10);
        taxRulesCache.class_country_rates.splice(i, 1);
        renderTaxClassCountries();
      });
    });
  }

  var discountsCache = [];

  function commerceDefaultCurrency() {
    var el = document.getElementById('payments-default-currency') || document.getElementById('commerce-default-currency');
    var v = el && el.value ? String(el.value).trim() : '';
    return v || 'eur';
  }

  function discountValueLabel(rule) {
    var vt = rule.value_type || 'percent';
    var cur = commerceDefaultCurrency();
    if (vt === 'free_shipping') return 'Free shipping';
    if (vt === 'fixed') {
      var cents = rule.fixed_off_cents != null ? Number(rule.fixed_off_cents) : Number(rule.value) || 0;
      return formatCents(cents, cur) + ' off';
    }
    return (Number(rule.value) || Number(rule.percent_off) || 0) + '% off';
  }

  function discountConstraints(rule) {
    var bits = [];
    if (Number(rule.min_purchase_cents) > 0) bits.push('min ' + formatCents(rule.min_purchase_cents, commerceDefaultCurrency()));
    if (rule.usage_limit != null && rule.usage_limit !== '') {
      bits.push('uses ' + (rule.usage_count || 0) + '/' + rule.usage_limit);
    } else if (Number(rule.usage_count) > 0) {
      bits.push('uses ' + rule.usage_count);
    }
    if (rule.starts_at || rule.ends_at) {
      bits.push([(rule.starts_at || '…').slice(0, 10), (rule.ends_at || '…').slice(0, 10)].join(' → '));
    }
    bits.push(rule.stackable ? 'stackable' : 'exclusive');
    if (rule.target) bits.push(rule.target);
    return bits.join(' · ');
  }

  function loadDiscounts() {
    var el = document.getElementById('commerce-discounts-list');
    if (!el) return;
    commercePost('list_discounts').then(function (res) {
      discountsCache = (res.data && res.data.rules) || [];
      if (!discountsCache.length) {
        el.innerHTML = '<div class="empty-state"><p>No discount rules yet.</p><p class="field-help">Add a coupon, automatic promotion, or affiliate rule to get started.</p></div>';
        return;
      }
      var html = '<div class="table-container"><table class="table commerce-discounts-table"><thead><tr>'
        + '<th>Name</th><th>Type</th><th>Value</th><th>Constraints</th><th>Status</th><th></th>'
        + '</tr></thead><tbody>';
      discountsCache.forEach(function (r) {
        html += '<tr data-id="' + escapeHtml(r.id || '') + '">';
        html += '<td><strong>' + escapeHtml(r.name || r.code || r.id || 'Rule') + '</strong>';
        if (r.code) html += '<div class="commerce-order-meta"><code>' + escapeHtml(r.code) + '</code></div>';
        html += '</td>';
        html += '<td>' + escapeHtml(r.type || '') + '</td>';
        html += '<td>' + escapeHtml(discountValueLabel(r)) + '</td>';
        html += '<td class="commerce-order-meta">' + escapeHtml(discountConstraints(r)) + '</td>';
        html += '<td>' + (r.enabled ? '<span class="badge badge-success">enabled</span>' : '<span class="badge badge-neutral">disabled</span>') + '</td>';
        html += '<td class="commerce-discount-actions">';
        html += '<button type="button" class="btn btn-secondary btn-sm commerce-discount-edit" data-id="' + escapeHtml(r.id || '') + '">Edit</button> ';
        html += '<button type="button" class="btn btn-secondary btn-sm commerce-discount-delete" data-id="' + escapeHtml(r.id || '') + '">Delete</button>';
        html += '</td></tr>';
      });
      html += '</tbody></table></div>';
      el.innerHTML = html;
    });
  }

  function discountDateInputValue(iso) {
    if (!iso) return '';
    return String(iso).slice(0, 10);
  }

  function syncDiscountFormFields() {
    var type = document.getElementById('commerce-discount-type')?.value || 'coupon';
    var vt = document.getElementById('commerce-discount-value-type')?.value || 'percent';
    var codeGroup = document.getElementById('commerce-discount-code-group');
    var affGroup = document.getElementById('commerce-discount-affiliate-group');
    var valueGroup = document.getElementById('commerce-discount-value-group');
    var hint = document.getElementById('commerce-discount-value-hint');
    if (codeGroup) codeGroup.hidden = type !== 'coupon';
    if (affGroup) affGroup.hidden = type !== 'affiliate';
    if (valueGroup) valueGroup.hidden = vt === 'free_shipping';
    if (hint) {
      hint.textContent = vt === 'fixed'
        ? 'Fixed amount in major units (e.g. 5.00).'
        : 'Percent 0–100.';
    }
    var valueInput = document.getElementById('commerce-discount-value');
    if (valueInput) {
      valueInput.step = vt === 'fixed' ? '0.01' : '1';
      valueInput.min = '0';
    }
  }

  function openCommerceModal(modal) {
    if (!modal) return;
    if (modal.parentElement !== document.body) {
      document.body.appendChild(modal);
    }
    modal.hidden = false;
    modal.classList.add('active');
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
  }

  function closeCommerceModal(modal) {
    if (!modal) return;
    modal.hidden = true;
    modal.classList.remove('active');
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
  }

  function openDiscountModal(rule) {
    rule = rule || {};
    var modal = document.getElementById('commerce-discount-modal');
    if (!modal) return;
    document.getElementById('commerce-discount-modal-title').textContent = rule.id ? 'Edit discount rule' : 'Add discount rule';
    document.getElementById('commerce-discount-id').value = rule.id || '';
    document.getElementById('commerce-discount-name').value = rule.name || '';
    document.getElementById('commerce-discount-type').value = rule.type || 'coupon';
    document.getElementById('commerce-discount-code').value = rule.code || '';
    document.getElementById('commerce-discount-affiliate').value = rule.affiliate_id || '';
    var valueType = rule.value_type || (rule.fixed_off_cents != null ? 'fixed' : 'percent');
    document.getElementById('commerce-discount-value-type').value = valueType;
    var value = rule.value;
    if (value == null) value = rule.fixed_off_cents != null ? rule.fixed_off_cents : (rule.percent_off != null ? rule.percent_off : 10);
    // Fixed amounts are stored in cents; show major units in the form.
    if (valueType === 'fixed') {
      value = (Number(value) || 0) / 100;
    } else if (value == null || value === '') {
      value = 10;
    }
    document.getElementById('commerce-discount-value').value = value;
    document.getElementById('commerce-discount-min').value = ((Number(rule.min_purchase_cents) || 0) / 100).toFixed(2);
    document.getElementById('commerce-discount-usage-limit').value = (rule.usage_limit == null || rule.usage_limit === '') ? '' : rule.usage_limit;
    document.getElementById('commerce-discount-starts').value = discountDateInputValue(rule.starts_at);
    document.getElementById('commerce-discount-ends').value = discountDateInputValue(rule.ends_at);
    document.getElementById('commerce-discount-target').value = rule.target || '';
    document.getElementById('commerce-discount-stackable').checked = !!rule.stackable;
    document.getElementById('commerce-discount-enabled').checked = rule.enabled !== false;
    syncDiscountFormFields();
    openCommerceModal(modal);
    window.setTimeout(function () {
      document.getElementById('commerce-discount-name')?.focus();
    }, 0);
  }

  function closeDiscountModal() {
    closeCommerceModal(document.getElementById('commerce-discount-modal'));
  }

  function openGiftCardModal() {
    var modal = document.getElementById('commerce-gift-card-modal');
    if (!modal) return;
    var amount = document.getElementById('commerce-gift-card-amount');
    var code = document.getElementById('commerce-gift-card-code');
    var note = document.getElementById('commerce-gift-card-note');
    if (amount) amount.value = '25.00';
    if (code) code.value = '';
    if (note) note.value = '';
    openCommerceModal(modal);
    window.setTimeout(function () {
      amount?.focus();
    }, 0);
  }

  function closeGiftCardModal() {
    closeCommerceModal(document.getElementById('commerce-gift-card-modal'));
  }

  function issueGiftCardFromModal() {
    var amountEl = document.getElementById('commerce-gift-card-amount');
    var codeEl = document.getElementById('commerce-gift-card-code');
    var noteEl = document.getElementById('commerce-gift-card-note');
    var amount = amountEl ? amountEl.value : '';
    var cents = Math.round(parseFloat(amount) * 100);
    if (isNaN(cents) || cents <= 0) {
      alert('Enter a valid balance greater than zero.');
      amountEl?.focus();
      return;
    }
    var code = (codeEl && codeEl.value.trim()) ? codeEl.value.trim() : null;
    var note = noteEl ? noteEl.value.trim() : '';
    commercePost('issue_gift_card', { balance_cents: cents, code: code, note: note }).then(function (res) {
      if (res.status !== 'ok') {
        alert('Issue failed: ' + (res.message || 'Unknown error'));
        return;
      }
      closeGiftCardModal();
      var issued = (res.data && res.data.gift_card && res.data.gift_card.code) || '';
      commerceToast(issued ? ('Gift card issued: ' + issued) : 'Gift card issued');
      loadGiftCards();
    });
  }

  function collectDiscountForm() {
    var usageRaw = document.getElementById('commerce-discount-usage-limit')?.value;
    var usageLimit = (usageRaw === '' || usageRaw == null) ? null : parseInt(usageRaw, 10);
    var valueType = document.getElementById('commerce-discount-value-type')?.value || 'percent';
    var rawValue = parseFloat(document.getElementById('commerce-discount-value')?.value || '0') || 0;
    var minMajor = parseFloat(document.getElementById('commerce-discount-min')?.value || '0') || 0;
    return {
      id: document.getElementById('commerce-discount-id')?.value || '',
      name: document.getElementById('commerce-discount-name')?.value || '',
      type: document.getElementById('commerce-discount-type')?.value || 'coupon',
      code: document.getElementById('commerce-discount-code')?.value || '',
      affiliate_id: document.getElementById('commerce-discount-affiliate')?.value || '',
      value_type: valueType,
      value: valueType === 'fixed' ? Math.round(rawValue * 100) : rawValue,
      min_purchase_cents: Math.round(minMajor * 100),
      usage_limit: usageLimit,
      starts_at: document.getElementById('commerce-discount-starts')?.value || null,
      ends_at: document.getElementById('commerce-discount-ends')?.value || null,
      target: document.getElementById('commerce-discount-target')?.value || '',
      stackable: !!document.getElementById('commerce-discount-stackable')?.checked,
      enabled: !!document.getElementById('commerce-discount-enabled')?.checked
    };
  }

  function bindDiscountUi() {
    document.getElementById('commerce-discount-type')?.addEventListener('change', syncDiscountFormFields);
    document.getElementById('commerce-discount-value-type')?.addEventListener('change', syncDiscountFormFields);
    document.getElementById('commerce-discount-modal-close')?.addEventListener('click', closeDiscountModal);
    document.getElementById('commerce-discount-cancel')?.addEventListener('click', closeDiscountModal);
    document.getElementById('commerce-discount-save')?.addEventListener('click', function () {
      var rule = collectDiscountForm();
      if (!rule.name.trim()) {
        alert('Name is required');
        return;
      }
      commercePost('save_discount', { rule: rule }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Save failed');
          return;
        }
        closeDiscountModal();
        commerceToast('Discount rule saved');
        loadDiscounts();
      });
    });
    document.getElementById('commerce-discounts-list')?.addEventListener('click', function (e) {
      var edit = e.target && e.target.closest ? e.target.closest('.commerce-discount-edit') : null;
      var del = e.target && e.target.closest ? e.target.closest('.commerce-discount-delete') : null;
      if (edit) {
        var id = edit.getAttribute('data-id');
        var rule = discountsCache.find(function (r) { return r.id === id; });
        openDiscountModal(rule || { id: id });
        return;
      }
      if (del) {
        var did = del.getAttribute('data-id');
        if (!did || !confirm('Delete this discount rule?')) return;
        commercePost('delete_discount', { id: did }).then(function (res) {
          if (res.status !== 'ok') {
            alert(res.message || 'Delete failed');
            return;
          }
          loadDiscounts();
        });
      }
    });
  }

  function loadGiftCards() {
    var el = document.getElementById('commerce-gift-cards-list');
    if (!el) return;
    el.innerHTML = '<div class="loading-state"><p>Loading gift cards…</p></div>';
    commercePost('list_gift_cards').then(function (res) {
      if (res.status !== 'ok') {
        el.innerHTML = '<p class="error">Failed to load gift cards</p>';
        return;
      }
      var cards = (res.data && res.data.gift_cards) || [];
      if (!cards.length) {
        el.innerHTML = '<p>No gift cards issued yet.</p>';
        return;
      }
      var html = '<div class="table-container"><table class="table commerce-gift-cards-table"><thead><tr>'
        + '<th>Code</th><th>Balance</th><th>Source</th><th>Status</th><th>Expires</th><th></th></tr></thead><tbody>';
      cards.forEach(function (c) {
        var source = c.source || (c.order_id ? 'purchased' : 'admin');
        html += '<tr><td><code class="commerce-sku">' + escapeHtml(c.code || '') + '</code>'
          + ' <button type="button" class="btn btn-secondary btn-sm commerce-copy-gift-code" data-code="'
          + escapeHtml(c.code || '') + '">Copy</button></td>';
        html += '<td>' + escapeHtml(formatCents(c.balance_cents, c.currency)) + '</td>';
        html += '<td>' + escapeHtml(source) + (c.order_id ? ' <span class="commerce-order-meta">(' + escapeHtml(c.order_id) + ')</span>' : '') + '</td>';
        html += '<td><span class="' + (function(st){ st=String(st||''); if(st==='active'||st==='succeeded'||st==='paid')return 'badge badge-success'; if(st==='pending'||st==='open')return 'badge badge-warning'; if(st==='void'||st==='failed'||st==='refunded')return 'badge badge-danger'; return 'badge badge-neutral'; })(c.status || 'unknown') + '">'
          + escapeHtml(c.status || '—') + '</span></td>';
        html += '<td>' + escapeHtml(c.expires_at || '—') + '</td>';
        html += '<td><button type="button" class="btn btn-secondary btn-sm commerce-void-gift-card" data-code="' + escapeHtml(c.code || '') + '">Void</button></td></tr>';
      });
      html += '</tbody></table></div>';
      el.innerHTML = html;
    });
  }

  var customersCache = [];
  var currentCustomerDetail = null;
  var customersSearchTimer = null;

  function showCustomersListView() {
    var listView = document.getElementById('commerce-customers-list-view');
    var detailView = document.getElementById('commerce-customer-detail-view');
    if (listView) listView.hidden = false;
    if (detailView) detailView.hidden = true;
  }

  function showCustomerDetailView() {
    var listView = document.getElementById('commerce-customers-list-view');
    var detailView = document.getElementById('commerce-customer-detail-view');
    if (listView) listView.hidden = true;
    if (detailView) detailView.hidden = false;
  }

  function renderCustomerTags(tags) {
    tags = Array.isArray(tags) ? tags : [];
    if (!tags.length) return '<span class="commerce-order-meta">—</span>';
    return '<div class="commerce-customer-tags">' + tags.map(function (t) {
      return '<span class="commerce-customer-tag">' + escapeHtml(t) + '</span>';
    }).join('') + '</div>';
  }

  function loadCustomers(search) {
    var el = document.getElementById('commerce-customers-list');
    if (!el) return;
    if ((location.hash || '').indexOf('#customer-profile/') === 0) {
      // Keep detail open while refresh happens in background.
    } else {
      showCustomersListView();
    }
    el.innerHTML = '<div class="loading-state"><p>Loading customers…</p></div>';
    var q = typeof search === 'string' ? search : (document.getElementById('commerce-customers-search')?.value || '');
    commercePost('list_customers', { search: q }).then(function (res) {
      if (res.status !== 'ok') {
        el.innerHTML = '<p class="error">Failed to load customers</p>';
        return;
      }
      customersCache = (res.data && res.data.customers) || [];
      if (!customersCache.length) {
        el.innerHTML = '<p>No customers yet. Import a CSV or wait for the next order with an email.</p>';
        return;
      }
      var html = '<table class="table commerce-customers-table"><thead><tr>'
        + '<th>Name</th><th>Email</th><th>Phone</th><th>Tags</th><th>Source</th><th>Updated</th>'
        + '</tr></thead><tbody>';
      customersCache.forEach(function (c) {
        html += '<tr class="commerce-open-customer" data-id="' + escapeHtml(c.id || '') + '">';
        html += '<td><strong>' + escapeHtml(c.name || '—') + '</strong></td>';
        html += '<td>' + escapeHtml(c.email || '') + '</td>';
        html += '<td>' + escapeHtml(c.phone || '—') + '</td>';
        html += '<td>' + renderCustomerTags(c.tags) + '</td>';
        html += '<td>' + escapeHtml(c.source || '') + '</td>';
        html += '<td>' + escapeHtml(formatOrderDate(c.updated_at)) + '</td>';
        html += '</tr>';
      });
      html += '</tbody></table>';
      el.innerHTML = html;
    }).catch(function () {
      el.innerHTML = '<p class="error">Failed to load customers</p>';
    });
  }

  function emptyCustomerForm() {
    return {
      id: '',
      email: '',
      name: '',
      phone: '',
      tags: [],
      notes: '',
      addresses: [{
        id: '',
        label: 'Shipping',
        name: '',
        line1: '',
        line2: '',
        city: '',
        region: '',
        postal: '',
        country: '',
        phone: '',
        default: true
      }],
      source: 'manual'
    };
  }

  function renderCustomerDetail(payload) {
    var el = document.getElementById('commerce-customer-detail');
    if (!el) return;
    var customer = (payload && payload.customer) || emptyCustomerForm();
    var timeline = (payload && payload.timeline) || { orders: [], subscriptions: [] };
    var um = (payload && payload.user_management) || {};
    currentCustomerDetail = customer;
    var addresses = Array.isArray(customer.addresses) && customer.addresses.length
      ? customer.addresses
      : emptyCustomerForm().addresses;
    var html = '<div class="commerce-detail-card commerce-customer-form">';
    html += '<div class="commerce-detail-header"><div><h2>' + escapeHtml(customer.name || customer.email || 'Customer') + '</h2>';
    html += '<p class="commerce-order-id">' + escapeHtml(customer.email || 'New customer') + '</p></div></div>';
    if (um.active) {
      html += '<div class="commerce-customer-um-link">';
      if (um.user_id && um.admin_url) {
        html += '<a class="btn btn-secondary btn-sm" href="' + escapeHtml(um.admin_url) + '">Open in User Management'
          + (um.user_name ? (' (' + escapeHtml(um.user_name) + ')') : '') + '</a>';
      } else if (um.admin_url) {
        html += '<a class="btn btn-secondary btn-sm" href="' + escapeHtml(um.admin_url) + '">Find in User Management</a>';
        html += '<p class="field-help">No linked account yet. Invite or reset password from User Management — never import passwords here.</p>';
      } else {
        html += '<p class="field-help">User Management is active. Link accounts by matching email; invite/reset only (no password import).</p>';
      }
      html += '</div>';
    }
    html += '<input type="hidden" id="commerce-customer-id" value="' + escapeHtml(customer.id || '') + '">';
    html += '<div class="form-group"><label for="commerce-customer-email">Email</label>';
    html += '<input type="email" id="commerce-customer-email" class="input" value="' + escapeHtml(customer.email || '') + '" required></div>';
    html += '<div class="form-group"><label for="commerce-customer-name">Name</label>';
    html += '<input type="text" id="commerce-customer-name" class="input" value="' + escapeHtml(customer.name || '') + '"></div>';
    html += '<div class="form-group"><label for="commerce-customer-phone">Phone</label>';
    html += '<input type="text" id="commerce-customer-phone" class="input" value="' + escapeHtml(customer.phone || '') + '"></div>';
    html += '<div class="form-group"><label for="commerce-customer-tags">Tags (comma-separated)</label>';
    html += '<input type="text" id="commerce-customer-tags" class="input" value="' + escapeHtml((customer.tags || []).join(', ')) + '"></div>';
    html += '<div class="form-group"><label for="commerce-customer-notes">Notes</label>';
    html += '<textarea id="commerce-customer-notes" class="input" rows="4">' + escapeHtml(customer.notes || '') + '</textarea></div>';
    html += '<h3>Addresses</h3><div class="commerce-customer-addresses" id="commerce-customer-addresses">';
    addresses.forEach(function (addr, idx) {
      html += '<div class="commerce-customer-address-card" data-addr-idx="' + idx + '">';
      html += '<div class="form-group"><label>Label</label><input type="text" class="input cust-addr-label" value="' + escapeHtml(addr.label || '') + '"></div>';
      html += '<div class="form-group"><label>Name</label><input type="text" class="input cust-addr-name" value="' + escapeHtml(addr.name || '') + '"></div>';
      html += '<div class="form-group"><label>Line 1</label><input type="text" class="input cust-addr-line1" value="' + escapeHtml(addr.line1 || '') + '"></div>';
      html += '<div class="form-group"><label>Line 2</label><input type="text" class="input cust-addr-line2" value="' + escapeHtml(addr.line2 || '') + '"></div>';
      html += '<div class="form-group"><label>City</label><input type="text" class="input cust-addr-city" value="' + escapeHtml(addr.city || '') + '"></div>';
      html += '<div class="form-group"><label>Region</label><input type="text" class="input cust-addr-region" value="' + escapeHtml(addr.region || '') + '"></div>';
      html += '<div class="form-group"><label>Postal</label><input type="text" class="input cust-addr-postal" value="' + escapeHtml(addr.postal || '') + '"></div>';
      html += '<div class="form-group"><label>Country</label><input type="text" class="input cust-addr-country" value="' + escapeHtml(addr.country || '') + '"></div>';
      html += '<div class="form-group"><label>Phone</label><input type="text" class="input cust-addr-phone" value="' + escapeHtml(addr.phone || '') + '"></div>';
      html += '<label><input type="radio" name="commerce-customer-default-addr" class="cust-addr-default"' + (addr.default ? ' checked' : '') + '> Default</label>';
      html += '</div>';
    });
    html += '</div>';
    html += '<button type="button" class="btn btn-secondary btn-sm" id="commerce-customer-add-address">Add address</button>';

    var orders = timeline.orders || [];
    var subs = timeline.subscriptions || [];
    html += '<h3>Timeline</h3>';
    html += '<div class="commerce-detail-grid">';
    html += '<div><span class="label">Orders</span><strong>' + orders.length + '</strong></div>';
    html += '<div><span class="label">Subscriptions</span><strong>' + subs.length + '</strong></div></div>';
    html += '<h4>Orders</h4>';
    if (!orders.length) html += '<p class="commerce-order-meta">No orders.</p>';
    else {
      html += '<ul class="commerce-timeline-list">';
      orders.forEach(function (o) {
        html += '<li><button type="button" class="linkish commerce-open-order" data-id="' + escapeHtml(o.id) + '">'
          + escapeHtml(orderDisplayNumber(o)) + '</button> · ' + escapeHtml(o.status || '')
          + ' · ' + escapeHtml(formatCents(o.total_cents, o.currency))
          + ' · ' + escapeHtml(formatOrderDate(o.created_at)) + '</li>';
      });
      html += '</ul>';
    }
    html += '<h4>Subscriptions</h4>';
    if (!subs.length) html += '<p class="commerce-order-meta">No subscriptions.</p>';
    else {
      html += '<ul class="commerce-timeline-list">';
      subs.forEach(function (s) {
        html += '<li><button type="button" class="linkish commerce-open-subscription" data-id="' + escapeHtml(s.id) + '">'
          + escapeHtml(s.id) + '</button> · ' + escapeHtml(s.status || '')
          + ' · ' + escapeHtml(formatCents(s.amount_cents, s.currency)) + ' / ' + escapeHtml(s.interval || 'month')
          + '</li>';
      });
      html += '</ul>';
    }
    html += '</div>';
    el.innerHTML = html;

    document.getElementById('commerce-customer-add-address')?.addEventListener('click', function () {
      var wrap = document.getElementById('commerce-customer-addresses');
      if (!wrap) return;
      var idx = wrap.querySelectorAll('.commerce-customer-address-card').length;
      var card = document.createElement('div');
      card.className = 'commerce-customer-address-card';
      card.setAttribute('data-addr-idx', String(idx));
      card.innerHTML = ''
        + '<div class="form-group"><label>Label</label><input type="text" class="input cust-addr-label" value="Shipping"></div>'
        + '<div class="form-group"><label>Name</label><input type="text" class="input cust-addr-name" value=""></div>'
        + '<div class="form-group"><label>Line 1</label><input type="text" class="input cust-addr-line1" value=""></div>'
        + '<div class="form-group"><label>Line 2</label><input type="text" class="input cust-addr-line2" value=""></div>'
        + '<div class="form-group"><label>City</label><input type="text" class="input cust-addr-city" value=""></div>'
        + '<div class="form-group"><label>Region</label><input type="text" class="input cust-addr-region" value=""></div>'
        + '<div class="form-group"><label>Postal</label><input type="text" class="input cust-addr-postal" value=""></div>'
        + '<div class="form-group"><label>Country</label><input type="text" class="input cust-addr-country" value=""></div>'
        + '<div class="form-group"><label>Phone</label><input type="text" class="input cust-addr-phone" value=""></div>'
        + '<label><input type="radio" name="commerce-customer-default-addr" class="cust-addr-default"> Default</label>';
      wrap.appendChild(card);
    });
  }

  function collectCustomerForm() {
    var tagsRaw = document.getElementById('commerce-customer-tags')?.value || '';
    var tags = tagsRaw.split(/[,;|]/).map(function (t) { return t.trim(); }).filter(Boolean);
    var addresses = [];
    document.querySelectorAll('#commerce-customer-addresses .commerce-customer-address-card').forEach(function (card) {
      addresses.push({
        label: card.querySelector('.cust-addr-label')?.value || '',
        name: card.querySelector('.cust-addr-name')?.value || '',
        line1: card.querySelector('.cust-addr-line1')?.value || '',
        line2: card.querySelector('.cust-addr-line2')?.value || '',
        city: card.querySelector('.cust-addr-city')?.value || '',
        region: card.querySelector('.cust-addr-region')?.value || '',
        postal: card.querySelector('.cust-addr-postal')?.value || '',
        country: card.querySelector('.cust-addr-country')?.value || '',
        phone: card.querySelector('.cust-addr-phone')?.value || '',
        default: !!(card.querySelector('.cust-addr-default')?.checked)
      });
    });
    return {
      id: document.getElementById('commerce-customer-id')?.value || '',
      email: document.getElementById('commerce-customer-email')?.value || '',
      name: document.getElementById('commerce-customer-name')?.value || '',
      phone: document.getElementById('commerce-customer-phone')?.value || '',
      tags: tags,
      notes: document.getElementById('commerce-customer-notes')?.value || '',
      addresses: addresses,
      source: (currentCustomerDetail && currentCustomerDetail.source) || 'manual'
    };
  }

  function openCustomerProfile(idOrEmail, isEmail) {
    var key = String(idOrEmail || '').trim();
    if (!key) return;
    setCommerceHash('customer-profile/' + encodeURIComponent(key));
    activateCommerceTab('customers');
    showCustomerDetailView();
    var el = document.getElementById('commerce-customer-detail');
    if (el) el.innerHTML = '<div class="loading-state"><p>Loading customer…</p></div>';
    var body = isEmail ? { email: key } : { id: key };
    // If it looks like an email, prefer email lookup.
    if (!isEmail && key.indexOf('@') !== -1) body = { email: key };
    commercePost('get_customer', body).then(function (res) {
      if (res.status !== 'ok') {
        if (key.indexOf('@') !== -1) {
          var stub = emptyCustomerForm();
          stub.email = key;
          renderCustomerDetail({ customer: stub, timeline: { orders: [], subscriptions: [] }, user_management: {} });
          return;
        }
        if (el) el.innerHTML = '<p class="error">' + escapeHtml(res.message || 'Customer not found') + '</p>';
        return;
      }
      renderCustomerDetail(res.data || {});
    }).catch(function () {
      if (el) el.innerHTML = '<p class="error">Failed to load customer</p>';
    });
  }

  function openNewCustomer() {
    setCommerceHash('customers/new');
    activateCommerceTab('customers');
    showCustomerDetailView();
    renderCustomerDetail({ customer: emptyCustomerForm(), timeline: { orders: [], subscriptions: [] }, user_management: {} });
  }

  function saveCurrentCustomer() {
    var payload = collectCustomerForm();
    if (!payload.email.trim()) {
      alert('Email is required');
      return;
    }
    commercePost('save_customer', { customer: payload }).then(function (res) {
      if (res.status !== 'ok') {
        alert(res.message || 'Save failed');
        return;
      }
      commerceToast('Customer saved');
      var saved = (res.data && res.data.customer) || payload;
      if (saved.id) {
        setCommerceHash('customer-profile/' + encodeURIComponent(saved.id));
        openCustomerProfile(saved.id, false);
      } else {
        loadCustomers();
      }
    });
  }

  function importCustomersCsv(file) {
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      var csv = String(reader.result || '');
      commercePost('import_customers_csv', { csv: csv }).then(function (res) {
        var box = document.getElementById('commerce-customers-import-summary');
        if (res.status !== 'ok') {
          alert(res.message || 'Import failed');
          return;
        }
        var d = res.data || {};
        var msg = 'Import complete: ' + (d.created || 0) + ' created, '
          + (d.updated || 0) + ' updated, ' + (d.skipped || 0) + ' skipped.';
        if ((d.errors || []).length) {
          msg += ' Errors: ' + d.errors.slice(0, 5).join('; ');
        }
        if (box) {
          box.hidden = false;
          box.textContent = msg;
        }
        commerceToast(msg);
        loadCustomers();
      });
    };
    reader.readAsText(file);
  }

  function bindCustomerUi() {
    document.getElementById('commerce-customers-refresh')?.addEventListener('click', function () {
      loadCustomers();
    });
    document.getElementById('commerce-customers-add')?.addEventListener('click', openNewCustomer);
    document.getElementById('commerce-customer-detail-back')?.addEventListener('click', function () {
      setCommerceHash('customers');
      showCustomersListView();
      loadCustomers();
    });
    document.getElementById('commerce-customer-save')?.addEventListener('click', saveCurrentCustomer);
    document.getElementById('commerce-customers-import')?.addEventListener('click', function () {
      document.getElementById('commerce-customers-csv-file')?.click();
    });
    document.getElementById('commerce-customers-csv-file')?.addEventListener('change', function (e) {
      var file = e.target && e.target.files && e.target.files[0];
      importCustomersCsv(file);
      e.target.value = '';
    });
    document.getElementById('commerce-customers-search')?.addEventListener('input', function () {
      clearTimeout(customersSearchTimer);
      customersSearchTimer = setTimeout(function () {
        loadCustomers();
      }, 250);
    });
    document.getElementById('commerce-customers-list')?.addEventListener('click', function (e) {
      var row = e.target && e.target.closest ? e.target.closest('.commerce-open-customer') : null;
      if (!row) return;
      openCustomerProfile(row.getAttribute('data-id') || '', false);
    });
  }

  var draftEditorState = {
    id: null,
    lines: [],
    acceptUrl: '',
    previewTimer: null,
  };

  function draftAcceptUrl(token) {
    return (window.Birkly && typeof Birkly.url === 'function')
      ? Birkly.url('/api/index.php?route=commerce&action=get_quote&token=' + encodeURIComponent(token || ''))
      : '/api/index.php?route=commerce&action=get_quote&token=' + encodeURIComponent(token || '');
  }

  function draftPayloadFromEditor() {
    var country = (document.getElementById('commerce-draft-country')?.value || '').trim().toUpperCase();
    var shipping = null;
    if (country) shipping = { country: country };
    return {
      customer_email: (document.getElementById('commerce-draft-email')?.value || '').trim(),
      note: (document.getElementById('commerce-draft-note')?.value || '').trim(),
      vat_id: (document.getElementById('commerce-draft-vat')?.value || '').trim(),
      shipping_address: shipping,
      lines: draftEditorState.lines.map(function (line) {
        return {
          collection: line.collection || line.collection_slug || '',
          entry_id: line.entry_id || '',
          sku: line.sku || '',
          purchase_option_id: line.purchase_option_id || 'default',
          quantity: Math.max(1, Number(line.quantity) || 1),
          unit_price_cents: line.custom_price ? Number(line.unit_price_cents) || 0 : undefined,
          custom_price: !!line.custom_price,
        };
      }),
    };
  }

  function renderDraftTotals(snap) {
    var el = document.getElementById('commerce-draft-totals');
    if (!el) return;
    snap = snap || {};
    var currency = snap.currency || 'eur';
    var html = '';
    html += '<div class="commerce-money-row"><span>Subtotal</span><strong>' + escapeHtml(formatCents(snap.subtotal_cents || 0, currency)) + '</strong></div>';
    html += '<div class="commerce-money-row"><span>Shipping</span><strong>' + escapeHtml(formatCents(snap.shipping_cents || 0, currency)) + '</strong></div>';
    html += '<div class="commerce-money-row"><span>Tax</span><strong>' + escapeHtml(formatCents(snap.tax_cents || 0, currency)) + '</strong></div>';
    if (Array.isArray(snap.tax_lines) && snap.tax_lines.length) {
      snap.tax_lines.forEach(function (tl) {
        html += '<div class="commerce-money-row"><span class="commerce-order-meta">'
          + escapeHtml(tl.title || tl.reason || 'Tax line')
          + '</span><strong>' + escapeHtml(formatCents(tl.tax_cents || 0, currency)) + '</strong></div>';
      });
    }
    html += '<div class="commerce-money-row is-total"><span>Total</span><strong>' + escapeHtml(formatCents(snap.total_cents || 0, currency)) + '</strong></div>';
    el.innerHTML = html;
  }

  function renderDraftLines() {
    var el = document.getElementById('commerce-draft-lines');
    if (!el) return;
    if (!draftEditorState.lines.length) {
      el.innerHTML = '<p class="field-help">No lines yet. Search the catalog and add a product.</p>';
      return;
    }
    var html = '<table class="table"><thead><tr><th>Item</th><th>SKU</th><th>Qty</th><th>Unit (cents)</th><th></th></tr></thead><tbody>';
    draftEditorState.lines.forEach(function (line, idx) {
      html += '<tr data-idx="' + idx + '">';
      html += '<td>' + escapeHtml(line.title || line.entry_id || 'Item') + '</td>';
      html += '<td>' + escapeHtml(line.sku || '—') + '</td>';
      html += '<td><input type="number" min="1" class="input draft-line-qty" data-idx="' + idx + '" value="' + (Number(line.quantity) || 1) + '" style="width:5rem"></td>';
      html += '<td><input type="number" min="0" class="input draft-line-price" data-idx="' + idx + '" value="' + (Number(line.unit_price_cents) || 0) + '" style="width:7rem" title="Override unit price (cents)"></td>';
      html += '<td><button type="button" class="btn btn-secondary btn-sm commerce-draft-remove-line" data-idx="' + idx + '">Remove</button></td>';
      html += '</tr>';
    });
    html += '</tbody></table>';
    el.innerHTML = html;
  }

  function scheduleDraftPreview() {
    if (draftEditorState.previewTimer) clearTimeout(draftEditorState.previewTimer);
    draftEditorState.previewTimer = setTimeout(runDraftPreview, 280);
  }

  function runDraftPreview() {
    var payload = draftPayloadFromEditor();
    commercePost('draft_order_preview', payload).then(function (res) {
      if (res.status !== 'ok' || !res.data || !res.data.preview) {
        renderDraftTotals({});
        return;
      }
      renderDraftTotals(res.data.preview);
    });
  }

  function openDraftEditor(quote) {
    var panel = document.getElementById('commerce-draft-editor');
    if (!panel) return;
    panel.hidden = false;
    draftEditorState.id = quote && quote.id ? quote.id : null;
    draftEditorState.acceptUrl = quote && quote.token ? draftAcceptUrl(quote.token) : '';
    document.getElementById('commerce-draft-id').value = draftEditorState.id || '';
    document.getElementById('commerce-draft-editor-title').textContent = draftEditorState.id
      ? ('Edit draft ' + draftEditorState.id)
      : 'New draft order';
    document.getElementById('commerce-draft-email').value = (quote && quote.customer_email) || '';
    document.getElementById('commerce-draft-note').value = (quote && quote.note) || '';
    document.getElementById('commerce-draft-vat').value = (quote && (quote.vat_id || quote.tax_id)) || '';
    var addr = (quote && quote.shipping_address) || {};
    document.getElementById('commerce-draft-country').value = addr.country || '';
    draftEditorState.lines = Array.isArray(quote && quote.lines)
      ? quote.lines.map(function (line) {
        return {
          collection: line.collection_slug || line.collection || '',
          collection_slug: line.collection_slug || line.collection || '',
          entry_id: line.entry_id || '',
          sku: line.sku || '',
          title: line.title || line.entry_title || line.entry_id || '',
          purchase_option_id: line.purchase_option_id || 'default',
          quantity: Number(line.quantity) || 1,
          unit_price_cents: Number(line.unit_price_cents || line.effective_unit_cents || line.amount_cents) || 0,
          custom_price: !!line.custom_price,
        };
      })
      : [];
    var urlWrap = document.getElementById('commerce-draft-accept-url-wrap');
    var urlEl = document.getElementById('commerce-draft-accept-url');
    if (draftEditorState.acceptUrl) {
      urlWrap.hidden = false;
      urlEl.value = draftEditorState.acceptUrl;
    } else {
      urlWrap.hidden = true;
      urlEl.value = '';
    }
    document.getElementById('commerce-draft-catalog-results').innerHTML = '';
    renderDraftLines();
    if (quote && (quote.total_cents != null || quote.tax_lines)) {
      renderDraftTotals({
        subtotal_cents: quote.subtotal_cents != null ? quote.subtotal_cents : Math.max(0, (Number(quote.total_cents) || 0) - (Number(quote.shipping_cents) || 0) - (Number(quote.tax_cents) || 0)),
        shipping_cents: quote.shipping_cents || 0,
        tax_cents: quote.tax_cents || 0,
        tax_lines: quote.tax_lines || [],
        total_cents: quote.total_cents || 0,
        currency: quote.currency || 'eur',
      });
    } else {
      scheduleDraftPreview();
    }
    // Prefill email suggestions from customers (best-effort).
    commercePost('list_customers', { search: '' }).then(function (res) {
      var list = document.getElementById('commerce-draft-email-suggestions');
      if (!list) return;
      var rows = (res.data && res.data.customers) || [];
      list.innerHTML = rows.slice(0, 40).map(function (c) {
        return '<option value="' + escapeHtml(c.email || '') + '">';
      }).join('');
    }).catch(function () {});
  }

  function closeDraftEditor() {
    var panel = document.getElementById('commerce-draft-editor');
    if (panel) panel.hidden = true;
    draftEditorState.id = null;
    draftEditorState.lines = [];
    draftEditorState.acceptUrl = '';
  }

  function saveDraftOrder(opts) {
    opts = opts || {};
    var payload = draftPayloadFromEditor();
    var action = draftEditorState.id ? 'draft_order_update' : 'draft_order_create';
    if (draftEditorState.id) payload.id = draftEditorState.id;
    return commercePost(action, payload).then(function (res) {
      if (res.status !== 'ok') {
        alert((res.message || 'Save failed'));
        return null;
      }
      var quote = (res.data && res.data.quote) || null;
      var acceptUrl = (res.data && res.data.accept_url) || (quote && quote.token ? draftAcceptUrl(quote.token) : '');
      if (quote) {
        draftEditorState.id = quote.id;
        document.getElementById('commerce-draft-id').value = quote.id || '';
        document.getElementById('commerce-draft-editor-title').textContent = 'Edit draft ' + quote.id;
        draftEditorState.acceptUrl = acceptUrl;
        var urlWrap = document.getElementById('commerce-draft-accept-url-wrap');
        var urlEl = document.getElementById('commerce-draft-accept-url');
        if (acceptUrl) {
          urlWrap.hidden = false;
          urlEl.value = acceptUrl;
        }
        renderDraftTotals({
          subtotal_cents: quote.subtotal_cents,
          shipping_cents: quote.shipping_cents,
          tax_cents: quote.tax_cents,
          tax_lines: quote.tax_lines,
          total_cents: quote.total_cents,
          currency: quote.currency,
        });
      }
      if (opts.copyLink && acceptUrl) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(acceptUrl).then(function () {
            alert('Accept link copied');
          }).catch(function () {
            prompt('Accept link:', acceptUrl);
          });
        } else {
          prompt('Accept link:', acceptUrl);
        }
      }
      loadQuotes();
      return res.data;
    });
  }

  function searchDraftCatalog() {
    var q = (document.getElementById('commerce-draft-catalog-search')?.value || '').trim();
    var el = document.getElementById('commerce-draft-catalog-results');
    if (!el) return;
    el.innerHTML = '<p class="field-help">Searching…</p>';
    commercePost('draft_order_search_catalog', { q: q, limit: 12 }).then(function (res) {
      var items = (res.data && res.data.items) || [];
      if (!items.length) {
        el.innerHTML = '<p class="field-help">No catalog matches.</p>';
        return;
      }
      var html = '<ul class="table">';
      items.forEach(function (item) {
        html += '<li><strong>' + escapeHtml(item.entry_title || item.entry_id || '') + '</strong>';
        html += ' <span class="commerce-order-meta">' + escapeHtml(item.sku || '') + ' · '
          + escapeHtml(formatCents(item.price_cents || 0, item.currency || 'eur')) + '</span> ';
        html += '<button type="button" class="btn btn-secondary btn-sm commerce-draft-add-catalog"'
          + ' data-collection="' + escapeHtml(item.collection_slug || '') + '"'
          + ' data-entry="' + escapeHtml(item.entry_id || '') + '"'
          + ' data-sku="' + escapeHtml(item.sku || '') + '"'
          + ' data-title="' + escapeHtml(item.entry_title || '') + '"'
          + ' data-option="' + escapeHtml(item.purchase_option_id || 'default') + '"'
          + ' data-price="' + (Number(item.price_cents) || 0) + '"'
          + '>Add</button></li>';
      });
      html += '</ul>';
      el.innerHTML = html;
    });
  }

  function loadQuotes() {
    var el = document.getElementById('commerce-quotes-list');
    if (!el) return;
    el.innerHTML = '<div class="loading-state"><p>Loading draft orders…</p></div>';
    commercePost('list_quotes').then(function (res) {
      if (res.status !== 'ok') {
        el.innerHTML = '<p class="error">Failed to load draft orders</p>';
        return;
      }
      var quotes = (res.data && res.data.quotes) || [];
      if (!quotes.length) {
        el.innerHTML = '<p>No draft orders yet.</p>';
        return;
      }
      var html = '<table class="table"><thead><tr><th>ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Accept link</th><th></th></tr></thead><tbody>';
      quotes.forEach(function (q) {
        var acceptUrl = draftAcceptUrl(q.token || '');
        html += '<tr><td><button type="button" class="linkish commerce-open-draft" data-id="'
          + escapeHtml(q.id || '') + '"><code>' + escapeHtml(q.id || '') + '</code></button></td>';
        html += '<td>' + escapeHtml(q.customer_email || '—') + '</td>';
        html += '<td>' + escapeHtml(formatCents(q.total_cents, q.currency)) + '</td>';
        html += '<td>' + escapeHtml(q.status || '') + '</td>';
        html += '<td><input type="text" class="form-input commerce-quote-link" readonly value="' + escapeHtml(acceptUrl) + '"></td>';
        html += '<td><button type="button" class="btn btn-secondary btn-sm commerce-cancel-quote" data-id="' + escapeHtml(q.id || '') + '">Cancel</button></td></tr>';
      });
      html += '</tbody></table>';
      el.innerHTML = html;
    });
  }

  function loadAnalytics() {
    var summaryEl = document.getElementById('commerce-analytics-summary');
    var opsEl = document.getElementById('commerce-analytics-ops');
    var cohortsEl = document.getElementById('commerce-analytics-cohorts');
    var productsEl = document.getElementById('commerce-analytics-products');
    var affiliatesEl = document.getElementById('commerce-analytics-affiliates');
    if (!summaryEl) return;
    summaryEl.innerHTML = '<div class="loading-state"><p>Loading dashboard…</p></div>';
    if (opsEl) opsEl.innerHTML = '';
    if (cohortsEl) cohortsEl.innerHTML = '';
    if (productsEl) productsEl.innerHTML = '';
    if (affiliatesEl) affiliatesEl.innerHTML = '';
    commercePost('analytics_summary').then(function (res) {
      if (res.status !== 'ok' || !res.data || !res.data.summary) {
        summaryEl.innerHTML = '<p class="error">Failed to load dashboard</p>';
        return;
      }
      var s = res.data.summary;
      var dashCurrency = s.currency || commerceDefaultCurrency();

      function dashMetric(label, value) {
        return '<div class="stat"><span class="stat-label">' + escapeHtml(label) + '</span><span class="stat-value">' + escapeHtml(String(value)) + '</span></div>';
      }

      function dashWidget(title, bodyHtml, sizeClass) {
        sizeClass = sizeClass || 'dash-widget--2x';
        return '<section class="card dash-widget ' + sizeClass + '">'
          + '<header class="card-header"><h2 class="card-title">' + escapeHtml(title) + '</h2></header>'
          + '<div class="card-body dash-widget-body">' + bodyHtml + '</div>'
          + '</section>';
      }

      var html = '<div class="dashboard-widgets-grid">';
      html += dashWidget('Overview',
        '<div class="dash-metrics">'
        + dashMetric('Revenue', formatCents(s.revenue_cents, dashCurrency))
        + dashMetric('Orders', s.order_count || 0)
        + dashMetric('AOV', formatCents(s.aov_cents, dashCurrency))
        + dashMetric('New customers', s.new_customers || 0)
        + dashMetric('Returning', s.returning_customers || 0)
        + '</div>', 'dash-widget--2x');

      var avgHours = s.avg_fulfillment_hours == null ? '—' : (s.avg_fulfillment_hours + 'h');
      var slaHours = s.fulfillment_sla_hours || 48;
      html += dashWidget('Fulfillment ops',
        '<div class="dash-metrics">'
        + dashMetric('Needs shipping', s.needs_shipping_count || 0)
        + dashMetric('SLA breaches (>' + slaHours + 'h)', s.sla_breach_count || 0)
        + dashMetric('Avg fulfillment time', avgHours)
        + '</div>', 'dash-widget--2x');

      var cohorts = s.cohorts || [];
      if (cohorts.length) {
        var periodLabel = (s.cohort_period || 'month') === 'week' ? 'First-order week' : 'First-order month';
        var cohortTable = '<div class="table-container"><table class="table"><thead><tr>'
          + '<th>' + escapeHtml(periodLabel) + '</th><th>Customers</th><th>Orders</th><th>Revenue</th></tr></thead><tbody>';
        cohorts.forEach(function (c) {
          cohortTable += '<tr><td>' + escapeHtml(c.period || '') + '</td>'
            + '<td>' + escapeHtml(c.customers || 0) + '</td>'
            + '<td>' + escapeHtml(c.orders || 0) + '</td>'
            + '<td>' + escapeHtml(formatCents(c.revenue_cents, dashCurrency)) + '</td></tr>';
        });
        cohortTable += '</tbody></table></div>';
        html += dashWidget('Customer cohorts', cohortTable, 'dash-widget--2x');
      }

      var products = s.top_products || [];
      if (products.length) {
        var productList = '<ul class="data-list">';
        products.forEach(function (p) {
          productList += '<li class="data-list-item"><strong>' + escapeHtml(p.title || p.key || '') + '</strong> — '
            + escapeHtml(p.quantity || 0) + ' sold, ' + escapeHtml(formatCents(p.revenue_cents, dashCurrency)) + '</li>';
        });
        productList += '</ul>';
        html += dashWidget('Top products', productList, 'dash-widget--2x');
      }

      var aff = s.affiliates || [];
      if (aff.length) {
        var affList = '<ul class="data-list">';
        aff.forEach(function (a) {
          affList += '<li class="data-list-item"><strong>' + escapeHtml(a.affiliate_id || '') + '</strong> — '
            + escapeHtml(a.orders || 0) + ' orders, ' + escapeHtml(formatCents(a.revenue_cents, dashCurrency)) + '</li>';
        });
        affList += '</ul>';
        html += dashWidget('Affiliates', affList, 'dash-widget--2x');
      }

      html += '</div>';
      summaryEl.innerHTML = html;
    });
  }

  var mappingWizardCatalog = [];
  var mappingWizardTiers = [];

  function showMappingWizardStep(step) {
    [1, 2, 3].forEach(function (n) {
      var panel = document.getElementById('commerce-wizard-step-' + n);
      var tab = document.querySelector('.commerce-wizard-step[data-step="' + n + '"]');
      if (panel) panel.hidden = n !== step;
      if (tab) tab.classList.toggle('active', n === step);
    });
  }

  function getSelectedCatalogItem() {
    var sel = document.getElementById('commerce-wizard-catalog');
    var idx = parseInt(sel && sel.value, 10);
    if (isNaN(idx) || idx < 0 || !mappingWizardCatalog[idx]) return null;
    return mappingWizardCatalog[idx];
  }

  function populateMappingOptions(item) {
    var optSel = document.getElementById('commerce-wizard-option');
    if (!optSel) return;
    optSel.innerHTML = '<option value="">Any / default</option>';
    var options = (item && item.purchase_options) || (item && item.commerce && item.commerce.purchase_options) || [];
    options.forEach(function (opt) {
      var o = document.createElement('option');
      o.value = opt.id || '';
      o.textContent = (opt.label || opt.id || 'option') + (opt.billing ? ' (' + opt.billing + ')' : '');
      optSel.appendChild(o);
    });
  }

  function updateMappingWizardSummary() {
    var summary = document.getElementById('commerce-wizard-summary');
    if (!summary) return;
    var item = getSelectedCatalogItem();
    var sku = document.getElementById('commerce-wizard-sku')?.value || '';
    var optionId = document.getElementById('commerce-wizard-option')?.value || '';
    var tierSel = document.getElementById('commerce-wizard-tier');
    var tierLabel = tierSel && tierSel.selectedOptions[0] ? tierSel.selectedOptions[0].textContent : '';
    var parts = [];
    if (item) {
      parts.push((item.entry_title || item.entry_slug) + ' (' + item.collection_slug + ')');
    } else if (sku) {
      parts.push('SKU ' + sku);
    }
    if (optionId) parts.push('option ' + optionId);
    if (tierLabel) parts.push('→ tier ' + tierLabel);
    summary.textContent = parts.length ? parts.join(' · ') : 'Complete the wizard steps to preview the mapping.';
  }

  function initMappingWizard() {
    commercePost('mapping_wizard_data').then(function (res) {
      if (res.status !== 'ok') return;
      var data = res.data || {};
      mappingWizardCatalog = data.catalog || [];
      mappingWizardTiers = data.tiers || [];

      var catalogSel = document.getElementById('commerce-wizard-catalog');
      if (catalogSel) {
        catalogSel.innerHTML = '<option value="">Select catalog item…</option>';
        mappingWizardCatalog.forEach(function (item, idx) {
          var o = document.createElement('option');
          o.value = String(idx);
          o.textContent = (item.entry_title || item.entry_slug) + ' · ' + item.collection_slug + (item.sku ? ' · ' + item.sku : '');
          catalogSel.appendChild(o);
        });
      }

      var tierSel = document.getElementById('commerce-wizard-tier');
      var tierHint = document.getElementById('commerce-wizard-tier-hint');
      if (tierSel) {
        tierSel.innerHTML = '';
        if (!mappingWizardTiers.length) {
          tierSel.innerHTML = '<option value="">No tiers available</option>';
          tierSel.disabled = true;
          if (tierHint) tierHint.hidden = false;
        } else {
          tierSel.disabled = false;
          if (tierHint) tierHint.hidden = true;
          tierSel.innerHTML = '<option value="">Select tier…</option>';
          mappingWizardTiers.forEach(function (tier) {
            var o = document.createElement('option');
            o.value = tier.id || tier.slug || '';
            o.textContent = tier.name || tier.id || 'tier';
            tierSel.appendChild(o);
          });
        }
      }
    });
  }

  function loadMappings() {
    var el = document.getElementById('commerce-mappings-list');
    if (!el) return;
    commercePost('list_mappings').then(function (res) {
      var mappings = (res.data && res.data.mappings) || {};
      var keys = Object.keys(mappings);
      if (!keys.length) {
        el.innerHTML = '<p>No purchase mappings.</p>';
        return;
      }
      var html = '<ul class="table">';
      keys.forEach(function (k) {
        var label = mappings[k].label || k;
        html += '<li><code>' + escapeHtml(k) + '</code> — ' + escapeHtml(label) + ' → tier <strong>' + escapeHtml(mappings[k].grant_tier || '') + '</strong>'
          + ' <button type="button" class="btn btn-sm btn-secondary commerce-delete-mapping" data-key="' + escapeHtml(k) + '">Remove</button></li>';
      });
      html += '</ul>';
      el.innerHTML = html;
      el.querySelectorAll('.commerce-delete-mapping').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var key = btn.getAttribute('data-key');
          if (!key || !confirm('Remove mapping ' + key + '?')) return;
          commercePost('delete_mapping', { key: key }).then(function () {
            loadMappings();
            initMappingWizard();
          });
        });
      });
    });
  }

  var fieldtypeProfileDraft = null;
  var fieldtypeProfilesCache = [];

  var FULFILLMENT_LABELS = { ship: 'Ship', deliver: 'Deliver', register: 'Register', gift_card: 'Gift card', none: 'None' };
  var FULFILLMENT_COLORS = { ship: 'blue', deliver: 'purple', register: 'green', gift_card: 'teal', none: 'gray' };
  var FULFILLMENT_BADGE = { ship: 'info', deliver: 'info', register: 'success', gift_card: 'accent', none: 'neutral' };

  var FT_PRESETS = {
    events: {
      name: 'Events & Classes',
      slug: 'events',
      settings: {
        default_fulfillment: 'register',
        enabled_fulfillments: ['register'],
        enable_fulfillment: true,
        enable_purchase_options: true,
        enable_quantity: true,
        enable_sku: false,
        enable_weight: false,
        enable_delivery: false,
        interval_options: [{ value: 'month', label: 'Monthly' }],
        custom_fields: [],
      },
    },
    digital: {
      name: 'Digital Products',
      slug: 'digital',
      settings: {
        default_fulfillment: 'deliver',
        enabled_fulfillments: ['deliver'],
        enable_fulfillment: true,
        enable_purchase_options: true,
        enable_quantity: false,
        enable_sku: true,
        enable_weight: false,
        enable_delivery: true,
        interval_options: [{ value: 'month', label: 'Monthly' }],
        custom_fields: [],
      },
    },
    physical: {
      name: 'Physical Products',
      slug: 'physical',
      settings: {
        default_fulfillment: 'ship',
        enabled_fulfillments: ['ship'],
        enable_fulfillment: true,
        enable_purchase_options: true,
        enable_quantity: true,
        enable_sku: true,
        enable_weight: true,
        enable_delivery: false,
        interval_options: [
          { value: 'month', label: 'Monthly' },
          { value: '2_weeks', label: 'Every 2 weeks' },
        ],
        custom_fields: [],
      },
    },
    membership: {
      name: 'Membership',
      slug: 'membership',
      settings: {
        default_fulfillment: 'none',
        enabled_fulfillments: ['none'],
        enable_fulfillment: true,
        enable_purchase_options: true,
        enable_quantity: false,
        enable_sku: false,
        enable_weight: false,
        enable_delivery: false,
        interval_options: [
          { value: 'month', label: 'Monthly' },
          { value: 'year', label: 'Yearly' },
        ],
        custom_fields: [],
      },
    },
    gift_card: {
      name: 'Gift Cards',
      slug: 'gift_card',
      settings: {
        default_fulfillment: 'gift_card',
        enabled_fulfillments: ['gift_card'],
        enable_fulfillment: true,
        enable_purchase_options: true,
        enable_quantity: true,
        enable_sku: true,
        enable_weight: false,
        enable_delivery: false,
        interval_options: [{ value: 'month', label: 'Monthly' }],
        custom_fields: [],
      },
    },
    donation: {
      name: 'Donations',
      slug: 'donation',
      settings: {
        default_fulfillment: 'none',
        enabled_fulfillments: ['none'],
        enable_fulfillment: true,
        enable_purchase_options: true,
        enable_quantity: false,
        enable_sku: false,
        enable_weight: false,
        enable_delivery: false,
        interval_options: [
          { value: 'month', label: 'Monthly' },
          { value: 'year', label: 'Yearly' },
        ],
        custom_fields: [],
      },
    },
  };

  function escapeHtml(str) {
    return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function updateTypePreview() {
    var slugEl = document.getElementById('commerce-ft-slug');
    var preview = document.getElementById('commerce-ft-type-preview');
    if (!preview || !slugEl) return;
    var slug = slugEl.value.trim();
    var id = document.getElementById('commerce-ft-profile-id')?.value || '';
    if (id === 'default' || !slug || slug === 'default') {
      preview.textContent = 'commerce';
      return;
    }
    preview.textContent = 'commerce_' + slug.replace(/[^a-z0-9_]/gi, '_').toLowerCase();
  }

  function showFieldtypeModal() {
    var modal = document.getElementById('commerce-fieldtype-modal');
    if (!modal) return;
    // Portal to body so parent overflow/stacking cannot trap clicks.
    if (modal.parentElement !== document.body) {
      document.body.appendChild(modal);
    }
    modal.hidden = false;
    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('commerce-ft-modal-open');
    window.setTimeout(function () {
      document.getElementById('commerce-ft-name')?.focus();
    }, 0);
  }

  function closeFieldtypeModal(e) {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    var modal = document.getElementById('commerce-fieldtype-modal');
    if (!modal) return;
    modal.hidden = true;
    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('commerce-ft-modal-open');
    fieldtypeProfileDraft = null;
  }

  function loadFieldtypeProfiles() {
    var el = document.getElementById('commerce-fieldtype-profiles-list');
    if (!el) return;
    el.innerHTML = '<div class="loading-state"><p>Loading fieldtype profiles…</p></div>';
    commercePost('list_fieldtype_profiles').then(function (res) {
      fieldtypeProfilesCache = (res.data && res.data.profiles) || [];
      if (!fieldtypeProfilesCache.length) {
        el.innerHTML = '<div class="commerce-ft-empty"><p>No fieldtypes yet.</p><button type="button" class="btn btn-primary" id="commerce-ft-empty-create">Create your first fieldtype</button></div>';
        document.getElementById('commerce-ft-empty-create')?.addEventListener('click', newFieldtypeProfile);
        return;
      }
      var html = '';
      fieldtypeProfilesCache.forEach(function (p) {
        var settings = p.settings || {};
        var fulfillment = settings.default_fulfillment || 'ship';
        var intervalCount = (settings.interval_options || []).length;
        var cfCount = (settings.custom_fields || []).length;
        html += '<article class="commerce-ft-card' + (p.is_default ? ' is-default' : '') + '">'
          + '<header class="commerce-ft-card__header">'
          + '<div class="commerce-ft-card__title-block">'
          + '<h3 class="commerce-ft-card__title">' + escapeHtml(p.name || p.id) + '</h3>'
          + '<code class="commerce-ft-card__key">' + escapeHtml(p.type_key || 'commerce') + '</code>'
          + '</div>'
          + (p.is_default ? '<span class="badge badge-neutral">Default</span>' : '')
          + '</header>'
          + '<dl class="commerce-ft-card__meta">'
          + '<div class="commerce-ft-card__meta-item"><dt>Fulfillment</dt><dd>' + escapeHtml(FULFILLMENT_LABELS[fulfillment] || fulfillment) + '</dd></div>'
          + '<div class="commerce-ft-card__meta-item"><dt>Intervals</dt><dd>' + intervalCount + '</dd></div>'
          + '<div class="commerce-ft-card__meta-item"><dt>Custom fields</dt><dd>' + cfCount + '</dd></div>'
          + '</dl>'
          + '<footer class="commerce-ft-card__actions">'
          + '<button type="button" class="btn btn-secondary commerce-edit-profile" data-id="' + escapeHtml(p.id) + '">Edit</button>'
          + (p.is_default ? '' : '<button type="button" class="btn btn-secondary commerce-delete-profile" data-id="' + escapeHtml(p.id) + '">Delete</button>')
          + '</footer></article>';
      });
      el.innerHTML = html;
      el.querySelectorAll('.commerce-edit-profile').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.getAttribute('data-id');
          var profile = fieldtypeProfilesCache.find(function (p) { return p.id === id; });
          if (profile) openFieldtypeEditor(profile);
        });
      });
      el.querySelectorAll('.commerce-delete-profile').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.getAttribute('data-id');
          if (!confirm('Delete this fieldtype? Collections using it will need updating.')) return;
          commercePost('delete_fieldtype_profile', { id: id }).then(function () { loadFieldtypeProfiles(); });
        });
      });
    });
  }

  function renderIntervalRows(intervals) {
    var list = document.getElementById('commerce-ft-intervals-list');
    if (!list) return;
    if (!intervals || !intervals.length) {
      list.innerHTML = '<p class="commerce-ft-list-empty">No custom intervals — add one below.</p>';
      return;
    }
    list.innerHTML = intervals.map(function (iv, idx) {
      return '<div class="commerce-ft-list-item">'
        + '<div><strong>' + escapeHtml(iv.label) + '</strong><br><code>' + escapeHtml(iv.value) + '</code></div>'
        + '<button type="button" class="btn-icon commerce-ft-remove-interval" data-idx="' + idx + '" title="Remove">×</button>'
        + '</div>';
    }).join('');
    list.querySelectorAll('.commerce-ft-remove-interval').forEach(function (btn) {
      btn.addEventListener('click', function () {
        fieldtypeProfileDraft.settings.interval_options.splice(parseInt(btn.getAttribute('data-idx'), 10), 1);
        renderIntervalRows(fieldtypeProfileDraft.settings.interval_options);
      });
    });
  }

  function renderCustomFieldRows(fields) {
    var list = document.getElementById('commerce-ft-custom-fields-list');
    if (!list) return;
    if (!fields || !fields.length) {
      list.innerHTML = '<p class="commerce-ft-list-empty">No custom fields — optional merchant metadata.</p>';
      return;
    }
    list.innerHTML = fields.map(function (cf, idx) {
      return '<div class="commerce-ft-list-item">'
        + '<div><strong>' + escapeHtml(cf.label) + '</strong><br><code>' + escapeHtml(cf.key) + '</code></div>'
        + '<button type="button" class="btn-icon commerce-ft-remove-cf" data-idx="' + idx + '" title="Remove">×</button>'
        + '</div>';
    }).join('');
    list.querySelectorAll('.commerce-ft-remove-cf').forEach(function (btn) {
      btn.addEventListener('click', function () {
        fieldtypeProfileDraft.settings.custom_fields.splice(parseInt(btn.getAttribute('data-idx'), 10), 1);
        renderCustomFieldRows(fieldtypeProfileDraft.settings.custom_fields);
      });
    });
  }

  function renderFulfillmentChips(settings) {
    var ftEl = document.getElementById('commerce-ft-fulfillments');
    if (!ftEl) return;
    var enabled = settings.enabled_fulfillments || ['ship', 'deliver', 'register', 'gift_card', 'none'];
    ftEl.innerHTML = ['ship', 'deliver', 'register', 'gift_card', 'none'].map(function (f) {
      var checked = enabled.indexOf(f) >= 0 ? ' checked' : '';
      return '<label class="commerce-ft-chip"><input type="checkbox" class="commerce-ft-fulfillment-cb" value="' + f + '"' + checked + '><span>' + FULFILLMENT_LABELS[f] + '</span></label>';
    }).join('');
  }

  function renderToggleGrid(settings) {
    var toggles = [
      ['enable_fulfillment', 'Fulfillment selector', 'Let merchants pick ship / deliver / register / gift card / none'],
      ['enable_purchase_options', 'Purchase options', 'One-time and recurring prices on same entry'],
      ['enable_quantity', 'Quantity / capacity', 'Stock limits or event spots'],
      ['enable_sku', 'SKU', 'Warehouse or inventory identifier'],
      ['enable_weight', 'Weight (grams)', 'For shipping calculations'],
      ['enable_delivery', 'Delivery panel', 'Digital asset path and external URL'],
    ];
    var el = document.getElementById('commerce-ft-toggles');
    if (!el) return;
    el.innerHTML = toggles.map(function (t) {
      var checked = settings[t[0]] !== false ? ' checked' : '';
      return '<label class="commerce-ft-toggle-card">'
        + '<input type="checkbox" class="commerce-ft-toggle-cb" data-key="' + t[0] + '"' + checked + '>'
        + '<span class="commerce-ft-toggle-title">' + t[1] + '</span>'
        + '<span class="commerce-ft-toggle-desc">' + t[2] + '</span></label>';
    }).join('');
  }

  function setEl(id, mutator) {
    var el = document.getElementById(id);
    if (!el || typeof mutator !== 'function') return el;
    mutator(el);
    return el;
  }

  function openFieldtypeEditor(profile) {
    var modal = document.getElementById('commerce-fieldtype-modal');
    if (!modal) {
      commerceToast('Fieldtype editor markup is missing. Reload Commerce admin.', true);
      return;
    }
    fieldtypeProfileDraft = JSON.parse(JSON.stringify(profile || {}));
    if (!fieldtypeProfileDraft.settings) fieldtypeProfileDraft.settings = {};

    var isDefault = !!profile.is_default;
    var isNew = !profile.id;
    setEl('commerce-fieldtype-editor-title', function (el) {
      el.textContent = isNew ? 'New fieldtype' : (isDefault ? 'Edit default fieldtype' : 'Edit fieldtype');
    });
    setEl('commerce-ft-modal-subtitle', function (el) {
      el.textContent = isNew
        ? 'Choose a quick start preset or configure manually.'
        : 'Changes apply to all collections using this field type.';
    });
    setEl('commerce-ft-presets-wrap', function (el) { el.hidden = !isNew; });
    setEl('commerce-ft-profile-id', function (el) { el.value = profile.id || ''; });
    setEl('commerce-ft-name', function (el) { el.value = profile.name || ''; });
    setEl('commerce-ft-slug', function (el) {
      el.value = profile.slug || '';
      el.disabled = isDefault;
    });
    setEl('commerce-ft-default-fulfillment', function (el) {
      el.value = profile.settings.default_fulfillment || 'ship';
    });

    renderFulfillmentChips(profile.settings);
    renderToggleGrid(profile.settings);
    renderIntervalRows(profile.settings.interval_options || []);
    renderCustomFieldRows(profile.settings.custom_fields || []);
    updateTypePreview();
    showFieldtypeModal();
  }

  function newFieldtypeProfile() {
    openFieldtypeEditor({ id: '', name: '', slug: '', settings: JSON.parse(JSON.stringify(FT_PRESETS.physical.settings)) });
  }

  function applyPreset(presetKey) {
    var preset = FT_PRESETS[presetKey];
    if (!preset || !fieldtypeProfileDraft) return;
    fieldtypeProfileDraft.name = preset.name;
    fieldtypeProfileDraft.slug = preset.slug;
    fieldtypeProfileDraft.settings = JSON.parse(JSON.stringify(preset.settings));
    openFieldtypeEditor(fieldtypeProfileDraft);
  }

  function saveFieldtypeProfile(e) {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (!fieldtypeProfileDraft) return;
    var settings = fieldtypeProfileDraft.settings || {};
    settings.default_fulfillment = document.getElementById('commerce-ft-default-fulfillment').value;
    settings.enabled_fulfillments = [];
    document.querySelectorAll('.commerce-ft-fulfillment-cb:checked').forEach(function (cb) {
      settings.enabled_fulfillments.push(cb.value);
    });
    document.querySelectorAll('.commerce-ft-toggle-cb').forEach(function (cb) {
      settings[cb.getAttribute('data-key')] = cb.checked;
    });
    var profile = {
      id: document.getElementById('commerce-ft-profile-id').value || undefined,
      name: document.getElementById('commerce-ft-name').value.trim(),
      slug: document.getElementById('commerce-ft-slug').value.trim(),
      settings: settings,
    };
    if (!profile.name) {
      commerceToast('Enter a display name for this fieldtype.', true);
      document.getElementById('commerce-ft-name')?.focus();
      return;
    }
    var saveBtn = document.getElementById('commerce-ft-save');
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }
    commercePost('save_fieldtype_profile', { profile: profile }).then(function (res) {
      if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save fieldtype'; }
      if (res.status !== 'ok') {
        commerceToast(res.message || 'Save failed', true);
        return;
      }
      closeFieldtypeModal();
      commerceToast('Fieldtype saved');
      loadFieldtypeProfiles();
    }).catch(function (err) {
      if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save fieldtype'; }
      commerceToast(err && err.message ? err.message : 'Save failed', true);
    });
  }

  var importSourcesCache = [];
  var importCollectionsCache = [];
  var importHistoryCache = [];
  var importWizard = {
    step: 1,
    source: 'generic',
    csv: '',
    fileName: '',
    preview: null,
    filter: 'all',
    search: '',
  };

  var IMPORT_STEP_LABELS = ['Choose your platform', 'Upload your export', 'Review products', 'Import complete'];

  function getImportCollectionMode() {
    var checked = document.querySelector('input[name="commerce-import-collection-mode"]:checked');
    return checked ? checked.value : 'existing';
  }

  function updateImportCollectionModeUI() {
    var mode = getImportCollectionMode();
    var existing = document.getElementById('commerce-import-collection-existing');
    var createNew = document.getElementById('commerce-import-collection-new');
    if (existing) existing.hidden = mode !== 'existing';
    if (createNew) createNew.hidden = mode !== 'new';
  }

  function renderImportCollectionSelect() {
    var select = document.getElementById('commerce-import-collection-select');
    if (!select) return;
    if (!importCollectionsCache.length) {
      select.innerHTML = '<option value="">No product collections yet — create a new one below</option>';
      return;
    }
    select.innerHTML = importCollectionsCache.map(function (col) {
      return '<option value="' + escapeHtml(col.slug) + '">' + escapeHtml(col.title || col.slug) + '</option>';
    }).join('');
  }

  function loadImportCollections() {
    return commercePost('import_collections').then(function (res) {
      importCollectionsCache = (res.data && res.data.collections) || [];
      renderImportCollectionSelect();
      return importCollectionsCache;
    });
  }

  function getImportCollectionPayload() {
    var mode = getImportCollectionMode();
    if (mode === 'new') {
      var title = document.getElementById('commerce-import-collection-title')?.value.trim() || '';
      return {
        create_collection: true,
        collection_title: title,
        collection: '',
      };
    }
    return {
      create_collection: false,
      collection_title: '',
      collection: document.getElementById('commerce-import-collection-select')?.value || '',
    };
  }

  function getImportCollectionLabel() {
    var payload = getImportCollectionPayload();
    if (payload.create_collection) {
      return payload.collection_title || 'New collection';
    }
    var slug = payload.collection;
    var match = importCollectionsCache.find(function (col) { return col.slug === slug; });
    return match ? (match.title || slug) : slug;
  }

  function validateImportCollectionStep() {
    var payload = getImportCollectionPayload();
    if (payload.create_collection) {
      if (!payload.collection_title) {
        alert('Please enter a name for the new collection.');
        return false;
      }
      return true;
    }
    if (!payload.collection) {
      alert('Please select a collection or choose to create a new one.');
      return false;
    }
    return true;
  }

  function loadImportTab() {
    loadImportHistory();
    loadLiveImportConfig();
    if (!importSourcesCache.length) {
      commercePost('import_sources').then(function (res) {
        importSourcesCache = (res.data && res.data.sources) || [];
      });
    }
  }

  var liveImportCollectionsLoaded = false;

  function populateLiveImportCollections(selectIds) {
    if (liveImportCollectionsLoaded) {
      return Promise.resolve();
    }
    return commercePost('import_collections').then(function (res) {
      var collections = (res.data && res.data.collections) || [];
      selectIds.forEach(function (id) {
        var sel = document.getElementById(id);
        if (!sel) return;
        var current = sel.value;
        sel.innerHTML = collections.map(function (c) {
          return '<option value="' + escapeHtml(c.slug || c) + '">' + escapeHtml(c.title || c.slug || c) + '</option>';
        }).join('');
        if (current) sel.value = current;
      });
      liveImportCollectionsLoaded = true;
    });
  }

  function livePlatformPrefix(platform) {
    if (platform === 'woocommerce') return 'woo';
    return platform;
  }

  function applyLiveImportConfig(config) {
    if (!config) return;
    ['shopify', 'woocommerce', 'etsy', 'square', 'amazon', 'ebay'].forEach(function (platform) {
      var p = config[platform] || {};
      var prefix = livePlatformPrefix(platform);
      var status = document.getElementById('commerce-live-' + prefix + '-status');
      if (status) {
        status.className = 'commerce-live-import-status badge ' + (p.connected ? 'badge-success' : 'badge-neutral');
        status.textContent = p.connected ? 'Connected' : 'Not connected';
      }
      var collection = document.getElementById('commerce-live-' + prefix + '-collection');
      if (collection && p.collection) collection.value = p.collection;
      var currency = document.getElementById('commerce-live-' + prefix + '-currency');
      if (currency && p.default_currency) currency.value = p.default_currency;
      var enabled = document.getElementById('commerce-live-' + prefix + '-enabled');
      if (enabled) enabled.checked = !!p.enabled;
      var schedule = document.getElementById('commerce-live-' + prefix + '-schedule');
      if (schedule) schedule.checked = !!p.schedule_enabled;
      if (platform === 'shopify') {
        var domain = document.getElementById('commerce-live-shopify-domain');
        if (domain && p.shop_domain) domain.value = p.shop_domain;
      }
      if (platform === 'woocommerce') {
        var url = document.getElementById('commerce-live-woo-url');
        if (url && p.site_url) url.value = p.site_url;
      }
      if (platform === 'etsy') {
        var shopId = document.getElementById('commerce-live-etsy-shop-id');
        if (shopId && p.shop_id) shopId.value = p.shop_id;
      }
      if (platform === 'square') {
        var loc = document.getElementById('commerce-live-square-location');
        if (loc && p.location_id) loc.value = p.location_id;
      }
      if (platform === 'amazon') {
        var seller = document.getElementById('commerce-live-amazon-seller-id');
        if (seller && p.seller_id) seller.value = p.seller_id;
        var amzMkt = document.getElementById('commerce-live-amazon-marketplace');
        if (amzMkt && p.marketplace_id) amzMkt.value = p.marketplace_id;
      }
      if (platform === 'ebay') {
        var ebayMkt = document.getElementById('commerce-live-ebay-marketplace');
        if (ebayMkt && p.marketplace_id) ebayMkt.value = p.marketplace_id;
      }
      var meta = document.getElementById('commerce-live-' + prefix + '-meta');
      if (meta && p.last_sync_at) {
        meta.textContent = 'Last sync: ' + formatImportDate(p.last_sync_at) + (p.last_sync_status ? ' (' + p.last_sync_status + ')' : '');
      }
    });
    var cron = document.getElementById('commerce-live-import-cron-command');
    if (cron && config.cron_token) {
      cron.textContent = 'php scripts/commerce-live-import-cron.php --token=' + config.cron_token;
    }
  }

  function loadLiveImportConfig() {
    var collectionSelects = [
      'commerce-live-shopify-collection', 'commerce-live-woo-collection',
      'commerce-live-etsy-collection', 'commerce-live-square-collection',
      'commerce-live-amazon-collection', 'commerce-live-ebay-collection',
    ];
    populateLiveImportCollections(collectionSelects).then(function () {
      return commercePost('import_live_config');
    }).then(function (res) {
      if (res.status === 'ok' && res.data) {
        applyLiveImportConfig(res.data);
      }
    });
    commercePost('get_inventory_webhook_config').then(function (res) {
      if (res.status !== 'ok' || !res.data) return;
      ['shopify', 'woocommerce'].forEach(function (platform) {
        var row = res.data[platform] || {};
        var urlEl = document.getElementById('commerce-webhook-url-' + platform);
        if (urlEl && row.webhook_url) urlEl.value = row.webhook_url;
      });
    });
  }

  function liveImportPatch(platform) {
    var prefix = livePlatformPrefix(platform);
    var patch = {
      enabled: !!document.getElementById('commerce-live-' + prefix + '-enabled')?.checked,
      schedule_enabled: !!document.getElementById('commerce-live-' + prefix + '-schedule')?.checked,
      collection: document.getElementById('commerce-live-' + prefix + '-collection')?.value || 'products',
      default_currency: document.getElementById('commerce-live-' + prefix + '-currency')?.value || 'eur',
    };
    if (platform === 'shopify') {
      patch.shop_domain = document.getElementById('commerce-live-shopify-domain')?.value || '';
      var token = document.getElementById('commerce-live-shopify-token')?.value;
      if (token) patch.access_token = token;
    }
    if (platform === 'woocommerce') {
      patch.site_url = document.getElementById('commerce-live-woo-url')?.value || '';
      var key = document.getElementById('commerce-live-woo-key')?.value;
      var secret = document.getElementById('commerce-live-woo-secret')?.value;
      if (key) patch.consumer_key = key;
      if (secret) patch.consumer_secret = secret;
    }
    if (platform === 'etsy') {
      patch.shop_id = document.getElementById('commerce-live-etsy-shop-id')?.value || '';
      var apiKey = document.getElementById('commerce-live-etsy-api-key')?.value;
      var etsyToken = document.getElementById('commerce-live-etsy-token')?.value;
      if (apiKey) patch.api_key = apiKey;
      if (etsyToken) patch.access_token = etsyToken;
    }
    if (platform === 'square') {
      patch.location_id = document.getElementById('commerce-live-square-location')?.value || '';
      var sqToken = document.getElementById('commerce-live-square-token')?.value;
      if (sqToken) patch.access_token = sqToken;
    }
    if (platform === 'amazon') {
      patch.seller_id = document.getElementById('commerce-live-amazon-seller-id')?.value || '';
      patch.marketplace_id = document.getElementById('commerce-live-amazon-marketplace')?.value || '';
      var amzToken = document.getElementById('commerce-live-amazon-token')?.value;
      if (amzToken) patch.refresh_token = amzToken;
    }
    if (platform === 'ebay') {
      patch.marketplace_id = document.getElementById('commerce-live-ebay-marketplace')?.value || 'EBAY_US';
      var ebayToken = document.getElementById('commerce-live-ebay-token')?.value;
      if (ebayToken) patch.access_token = ebayToken;
    }
    return patch;
  }

  function initLiveImportPlatform(platform) {
    var prefix = livePlatformPrefix(platform);
    document.getElementById('commerce-live-' + prefix + '-test')?.addEventListener('click', function () {
      commercePost('import_live_save', { platform: platform, config: liveImportPatch(platform) }).then(function () {
        return commercePost('import_live_test', { platform: platform });
      }).then(function (res) {
        alert(res.status === 'ok' ? 'Connection OK' : (res.message || 'Connection failed'));
      });
    });
    document.getElementById('commerce-live-' + prefix + '-save')?.addEventListener('click', function () {
      commercePost('import_live_save', { platform: platform, config: liveImportPatch(platform) }).then(function (res) {
        if (res.status === 'ok') {
          loadLiveImportConfig();
          alert('Saved');
        } else {
          alert(res.message || 'Save failed');
        }
      });
    });
    document.getElementById('commerce-live-' + prefix + '-sync')?.addEventListener('click', function () {
      commercePost('import_live_sync', { platform: platform }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Sync failed');
          return;
        }
        loadImportHistory();
        loadLiveImportConfig();
        alert('Beta import finished. Imported ' + ((res.data && res.data.imported_count) || 0) + ' product(s). Verify products before storefront cutover.');
      });
    });
  }

  function initLiveImportWebhooks() {
    document.querySelectorAll('.commerce-webhook-rotate').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var platform = btn.getAttribute('data-platform');
        if (!platform || !confirm('Generate a new webhook secret for ' + platform + '? Update your store webhook configuration.')) return;
        commercePost('rotate_inventory_webhook_secret', { platform: platform }).then(function (res) {
          if (res.status !== 'ok') {
            alert(res.message || 'Failed to rotate secret');
            return;
          }
          var secret = (res.data && res.data.webhook_secret) || '';
          var el = document.getElementById('commerce-webhook-secret-' + platform);
          if (el && secret) {
            el.hidden = false;
            el.textContent = 'New secret (copy now): ' + secret;
          }
          loadLiveImportConfig();
        });
      });
    });
  }

  var cutoverLastBatchId = '';

  function showCutoverResult(message, isError) {
    var box = document.getElementById('commerce-cutover-result');
    if (!box) return;
    box.hidden = false;
    box.textContent = message;
    box.classList.toggle('is-error', !!isError);
  }

  function initShopifyCutover() {
    var resourcesEl = document.getElementById('commerce-cutover-resources');
    var rollbackBtn = document.getElementById('commerce-cutover-rollback');
    document.getElementById('commerce-cutover-test')?.addEventListener('click', function () {
      commercePost('shopify_cutover_test').then(function (res) {
        if (res.status === 'ok') {
          var name = (res.data && res.data.shop_name) || 'Shopify';
          showCutoverResult('Connected to ' + name);
          commerceToast('Shopify connection OK');
        } else {
          showCutoverResult(res.message || 'Connection failed', true);
          alert(res.message || 'Connection failed');
        }
      });
    });
    document.getElementById('commerce-cutover-dry-run')?.addEventListener('click', function () {
      var resources = resourcesEl ? resourcesEl.value : 'all';
      showCutoverResult('Running dry-run…');
      commercePost('shopify_cutover_dry_run', { resources: resources, max_pages: 2 }).then(function (res) {
        if (res.status !== 'ok') {
          showCutoverResult(res.message || 'Dry-run failed', true);
          alert(res.message || 'Dry-run failed');
          return;
        }
        var d = res.data || {};
        cutoverLastBatchId = d.dry_run_token || d.batch_id || '';
        if (rollbackBtn) rollbackBtn.disabled = !cutoverLastBatchId;
        var parts = [];
        if (d.products) parts.push('products: ' + (d.products.count || 0));
        if (d.customers) parts.push('customers: ' + (d.customers.count || 0));
        if (d.orders) parts.push('archived orders: ' + (d.orders.count || 0));
        showCutoverResult('Dry-run OK (' + parts.join(', ') + '). Token: ' + (cutoverLastBatchId || '—') + '. No data written.');
        commerceToast('Shopify cutover dry-run complete');
      });
    });
    document.getElementById('commerce-cutover-import')?.addEventListener('click', function () {
      var resources = resourcesEl ? resourcesEl.value : 'all';
      if (!confirm('Import Shopify cutover for "' + resources + '"? Archived orders will not fulfill or change stock. Continue?')) {
        return;
      }
      showCutoverResult('Importing cutover…');
      var payload = { resources: resources, confirm: true };
      if (cutoverLastBatchId) payload.dry_run_token = cutoverLastBatchId;
      commercePost('shopify_cutover_import', payload).then(function (res) {
        if (res.status !== 'ok') {
          showCutoverResult(res.message || 'Import failed', true);
          alert(res.message || 'Import failed');
          return;
        }
        var d = res.data || {};
        cutoverLastBatchId = d.batch_id || cutoverLastBatchId;
        if (rollbackBtn) rollbackBtn.disabled = !cutoverLastBatchId;
        var msg = 'Cutover import ' + (d.status || 'done')
          + ' — products +' + ((d.products && d.products.created) || 0)
          + '/~' + ((d.products && d.products.updated) || 0)
          + ', customers +' + ((d.customers && d.customers.created) || 0)
          + ', archived orders +' + ((d.orders && d.orders.created) || 0)
          + '. Batch: ' + (cutoverLastBatchId || '—');
        showCutoverResult(msg);
        commerceToast('Shopify cutover import finished');
        loadImportHistory();
      });
    });
    rollbackBtn?.addEventListener('click', function () {
      if (!cutoverLastBatchId) {
        alert('No cutover batch to roll back. Run dry-run/import first.');
        return;
      }
      if (!confirm('Roll back cutover batch ' + cutoverLastBatchId + '? This deletes created customers/archived orders and rolls back linked product imports when recorded.')) {
        return;
      }
      commercePost('shopify_cutover_rollback', { batch_id: cutoverLastBatchId }).then(function (res) {
        if (res.status !== 'ok') {
          showCutoverResult(res.message || 'Rollback failed', true);
          alert(res.message || 'Rollback failed');
          return;
        }
        var d = res.data || {};
        showCutoverResult('Rolled back batch ' + cutoverLastBatchId
          + ' — customers removed: ' + (d.deleted_customers || 0)
          + ', orders removed: ' + (d.deleted_orders || 0));
        cutoverLastBatchId = '';
        if (rollbackBtn) rollbackBtn.disabled = true;
        commerceToast('Cutover rolled back');
        loadImportHistory();
      });
    });
  }

  function initLiveImport() {
    initShopifyCutover();
    ['shopify', 'woocommerce', 'etsy', 'square', 'amazon', 'ebay'].forEach(initLiveImportPlatform);
    initLiveImportWebhooks();
  }

  function loadImportHistory() {
    var el = document.getElementById('commerce-import-history-list');
    if (!el) return;
    commercePost('import_history', { limit: 50 }).then(function (res) {
      importHistoryCache = (res.data && res.data.imports) || [];
      renderImportHistory();
      renderImportStats();
    });
  }

  function renderImportStats() {
    var wrap = document.getElementById('commerce-import-stats');
    if (!wrap) return;
    if (!importHistoryCache.length) {
      wrap.hidden = true;
      return;
    }
    var success = importHistoryCache.filter(function (i) { return i.status === 'success'; }).length;
    var partial = importHistoryCache.filter(function (i) { return i.status === 'partial'; }).length;
    var failed = importHistoryCache.filter(function (i) { return i.status === 'failed'; }).length;
    var totalProducts = importHistoryCache.reduce(function (sum, i) { return sum + (i.imported_count || 0); }, 0);
    wrap.hidden = false;
    wrap.innerHTML = [
      { value: importHistoryCache.length, label: 'Total imports' },
      { value: totalProducts, label: 'Products imported' },
      { value: success, label: 'Successful' },
      { value: partial + failed, label: 'With issues' },
    ].map(function (s) {
      return '<div class="commerce-import-stat-card"><div class="commerce-import-stat-value">' + s.value + '</div><div class="commerce-import-stat-label">' + escapeHtml(s.label) + '</div></div>';
    }).join('');
  }

  function formatImportDate(iso) {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
    } catch (e) {
      return iso;
    }
  }

  function renderImportHistory() {
    var el = document.getElementById('commerce-import-history-list');
    if (!el) return;
    if (!importHistoryCache.length) {
      el.innerHTML = '<div class="commerce-import-history-empty"><p>No imports yet.</p><p>Click <strong>Import products</strong> to bring your catalog from another system.</p></div>';
      return;
    }
    var html = '<table class="commerce-import-history-table"><thead><tr>'
      + '<th>Date</th><th>Platform</th><th>Collection</th><th>Status</th><th>Imported</th><th>Skipped</th><th>File</th><th></th>'
      + '</tr></thead><tbody>';
    importHistoryCache.forEach(function (item) {
      var status = item.status || 'success';
      var rolledBack = status === 'rolled_back' || !!item.rolled_back_at;
      var actions = rolledBack
        ? '<span class="field-help">Removed</span>'
        : '<button type="button" class="btn btn-secondary commerce-import-view-detail" data-id="' + escapeHtml(item.id) + '">Details</button>'
          + ' <button type="button" class="btn btn-danger commerce-import-delete" data-id="' + escapeHtml(item.id) + '"'
          + ' data-collection="' + escapeHtml(item.collection || '') + '"'
          + ' data-count="' + (item.imported_count || 0) + '"'
          + (item.collection_created ? ' data-collection-created="1"' : '')
          + '>Remove</button>';
      html += '<tr>'
        + '<td>' + escapeHtml(formatImportDate(item.at)) + '</td>'
        + '<td>' + escapeHtml(item.platform || item.preset || '—') + '</td>'
        + '<td><code>' + escapeHtml(item.collection || 'products') + '</code></td>'
        + '<td><span class="commerce-import-status ' + escapeHtml(status) + '">' + escapeHtml(status) + '</span></td>'
        + '<td>' + (item.imported_count || 0) + '</td>'
        + '<td>' + (item.skipped_count || 0) + '</td>'
        + '<td>' + escapeHtml(item.file_name || '—') + '</td>'
        + '<td class="commerce-import-history-actions">' + actions + '</td>'
        + '</tr>';
    });
    html += '</tbody></table>';
    el.innerHTML = html;
    el.querySelectorAll('.commerce-import-view-detail').forEach(function (btn) {
      btn.addEventListener('click', function () {
        showImportDetail(btn.getAttribute('data-id'));
      });
    });
    el.querySelectorAll('.commerce-import-delete').forEach(function (btn) {
      btn.addEventListener('click', function () {
        rollbackImport(btn);
      });
    });
  }

  function rollbackImport(btn) {
    var importId = btn.getAttribute('data-id');
    var collection = btn.getAttribute('data-collection') || 'collection';
    var count = btn.getAttribute('data-count') || '0';
    var createdCollection = btn.hasAttribute('data-collection-created');
    var message = 'Remove ' + count + ' imported product(s) from "' + collection + '"?';
    if (createdCollection) {
      message += '\n\nThis import created the collection — the collection will be deleted as well.';
    }
    message += '\n\nThis cannot be undone.';
    if (!confirm(message)) {
      return;
    }
    btn.disabled = true;
    commercePost('import_rollback', { id: importId, delete_collection: true }).then(function (res) {
      btn.disabled = false;
      if (res.status !== 'ok') {
        alert(res.message || 'Could not remove import');
        return;
      }
      var data = res.data || {};
      var summary = 'Removed ' + (data.deleted || 0) + ' product(s)';
      if (data.variants_deleted) {
        summary += ' and ' + data.variants_deleted + ' variant(s)';
      }
      if (data.collection_deleted) {
        summary += '. Collection deleted.';
      }
      alert(summary);
      loadImportHistory();
      loadImportCollections();
      if (document.querySelector('.commerce-tabs .tab.active')?.getAttribute('data-tab') === 'catalog') {
        loadCatalog();
      }
    });
  }

  function showImportDetail(importId) {
    commercePost('import_detail', { id: importId }).then(function (res) {
      if (res.status !== 'ok') {
        alert(res.message || 'Could not load import details');
        return;
      }
      var item = res.data.import || {};
      var errors = item.errors || [];
      var msg = 'Platform: ' + (item.platform || '—') + '\n'
        + 'Collection: ' + (item.collection || '—') + '\n'
        + 'Status: ' + (item.status || '—') + '\n'
        + 'Imported: ' + (item.imported_count || 0) + ' (created ' + (item.created_count || 0) + ', updated ' + (item.updated_count || 0) + ')\n'
        + 'Skipped: ' + (item.skipped_count || 0) + '\n'
        + 'Variants: ' + (item.variant_count || 0);
      if (errors.length) {
        msg += '\n\nIssues:\n' + errors.slice(0, 10).map(function (e) {
          return 'Row ' + e.row + ': ' + (e.reason || 'Unknown') + (e.title ? ' (' + e.title + ')' : '');
        }).join('\n');
      }
      alert(msg);
    });
  }

  function platformBadge(name) {
    var text = (name || '?').replace(/[^A-Za-z0-9]/g, '').slice(0, 2).toUpperCase();
    return text || '?';
  }

  function filteredImportSources() {
    return importSourcesCache.filter(function (src) {
      if (importWizard.filter !== 'all' && (src.category || 'other') !== importWizard.filter) return false;
      if (!importWizard.search) return true;
      var q = importWizard.search.toLowerCase();
      return (src.name || '').toLowerCase().indexOf(q) !== -1
        || (src.description || '').toLowerCase().indexOf(q) !== -1
        || (src.id || '').toLowerCase().indexOf(q) !== -1;
    });
  }

  function renderWizardSources() {
    var el = document.getElementById('commerce-import-wizard-sources');
    if (!el) return;
    var categories = [
      { id: 'store', label: 'Online stores' },
      { id: 'inventory', label: 'Inventory & stock' },
      { id: 'other', label: 'Other' },
    ];
    var sources = filteredImportSources();
    if (!sources.length) {
      el.innerHTML = '<p class="form-text">No platforms match your search.</p>';
      return;
    }
    var html = '';
    categories.forEach(function (cat) {
      var items = sources.filter(function (s) { return (s.category || 'other') === cat.id; });
      if (!items.length) return;
      html += '<div class="commerce-import-source-group"><h4 class="commerce-import-source-group-title">' + escapeHtml(cat.label) + '</h4><div class="commerce-import-source-grid">';
      html += items.map(function (src) {
        return '<button type="button" class="commerce-import-source-card' + (src.id === importWizard.source ? ' is-active' : '') + '" data-source="' + escapeHtml(src.id) + '">'
          + '<span class="commerce-import-source-badge">' + escapeHtml(platformBadge(src.name)) + '</span>'
          + '<span class="commerce-import-source-name">' + escapeHtml(src.name) + '</span>'
          + '<span class="commerce-import-source-desc">' + escapeHtml(src.description) + '</span>'
          + '</button>';
      }).join('');
      html += '</div></div>';
    });
    el.innerHTML = html;
    el.querySelectorAll('.commerce-import-source-card').forEach(function (btn) {
      btn.addEventListener('click', function () {
        importWizard.source = btn.getAttribute('data-source') || 'generic';
        renderWizardSources();
      });
    });
  }

  function getSelectedSource() {
    return importSourcesCache.find(function (s) { return s.id === importWizard.source; }) || { id: 'generic', name: 'Generic CSV' };
  }

  function updateWizardStepUI() {
    var step = importWizard.step;
    document.querySelectorAll('.commerce-import-wizard-pane').forEach(function (pane) {
      var paneStep = parseInt(pane.getAttribute('data-step'), 10);
      pane.hidden = paneStep !== step;
      pane.classList.toggle('is-active', paneStep === step);
    });
    document.querySelectorAll('.commerce-import-wizard-step-indicator').forEach(function (ind) {
      var indStep = parseInt(ind.getAttribute('data-step'), 10);
      ind.classList.toggle('is-active', indStep === step);
      ind.classList.toggle('is-done', indStep < step);
    });
    var subtitle = document.getElementById('commerce-import-wizard-subtitle');
    if (subtitle) subtitle.textContent = 'Step ' + step + ' of 4 — ' + (IMPORT_STEP_LABELS[step - 1] || '');

    var backBtn = document.getElementById('commerce-import-wizard-back');
    var nextBtn = document.getElementById('commerce-import-wizard-next');
    var importBtn = document.getElementById('commerce-import-wizard-import');
    var doneBtn = document.getElementById('commerce-import-wizard-done');
    var cancelBtn = document.getElementById('commerce-import-wizard-cancel');

    if (backBtn) backBtn.hidden = step <= 1 || step === 4;
    if (nextBtn) nextBtn.hidden = step !== 1 && step !== 2;
    if (importBtn) importBtn.hidden = step !== 3;
    if (doneBtn) doneBtn.hidden = step !== 4;
    if (cancelBtn) cancelBtn.hidden = step === 4;

    if (step === 2) {
      var src = getSelectedSource();
      var platformEl = document.getElementById('commerce-import-selected-platform');
      var stepsEl = document.getElementById('commerce-import-export-steps');
      if (platformEl) {
        platformEl.innerHTML = '<span class="commerce-import-source-badge">' + escapeHtml(platformBadge(src.name)) + '</span>'
          + '<div><strong>' + escapeHtml(src.name) + '</strong><div class="field-help">' + escapeHtml(src.description || '') + '</div></div>';
      }
      if (stepsEl) stepsEl.textContent = src.export_steps || '';
    }
  }

  function openImportWizard() {
    importWizard = { step: 1, source: 'generic', csv: '', fileName: '', preview: null, filter: 'all', search: '' };
    var search = document.getElementById('commerce-import-search');
    if (search) search.value = '';
    document.querySelectorAll('#commerce-import-filters .btn').forEach(function (btn) {
      btn.classList.toggle('is-active', btn.getAttribute('data-filter') === 'all');
    });
    var csvArea = document.getElementById('commerce-import-csv');
    if (csvArea) csvArea.value = '';
    var fileName = document.getElementById('commerce-import-file-name');
    if (fileName) { fileName.textContent = 'No file selected'; delete fileName.dataset.filename; }
    var fileInput = document.getElementById('commerce-import-file');
    if (fileInput) fileInput.value = '';

    var ensureSources = Promise.all([
      importSourcesCache.length
        ? Promise.resolve()
        : commercePost('import_sources').then(function (res) {
          importSourcesCache = (res.data && res.data.sources) || [];
        }),
      loadImportCollections(),
    ]);

    ensureSources.then(function () {
      var modeNew = document.querySelector('input[name="commerce-import-collection-mode"][value="new"]');
      if (!importCollectionsCache.length && modeNew) {
        modeNew.checked = true;
        var modeExisting = document.querySelector('input[name="commerce-import-collection-mode"][value="existing"]');
        if (modeExisting) modeExisting.checked = false;
      }
      updateImportCollectionModeUI();
      renderWizardSources();
      updateWizardStepUI();
      var modal = document.getElementById('commerce-import-wizard');
      if (modal) {
        modal.hidden = false;
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('commerce-import-wizard-open');
      }
    });
  }

  function closeImportWizard() {
    var modal = document.getElementById('commerce-import-wizard');
    if (modal) {
      modal.hidden = true;
      modal.setAttribute('aria-hidden', 'true');
    }
    document.body.classList.remove('commerce-import-wizard-open');
  }

  function setImportCsvContent(text) {
    importWizard.csv = text || '';
    var textarea = document.getElementById('commerce-import-csv');
    if (textarea && text) textarea.value = text;
  }

  function readImportFile(file) {
    if (!file) return;
    importWizard.fileName = file.name;
    var reader = new FileReader();
    reader.onload = function (ev) {
      var nameEl = document.getElementById('commerce-import-file-name');
      if (nameEl) {
        nameEl.textContent = file.name;
        nameEl.dataset.filename = file.name;
      }
      setImportCsvContent(ev.target.result || '');
    };
    reader.readAsText(file);
  }

  function getImportCsvPayload() {
    return importWizard.csv || document.getElementById('commerce-import-csv')?.value || '';
  }

  function renderImportPreviewTable(preview) {
    var tableEl = document.getElementById('commerce-import-preview-table');
    if (!tableEl) return;
    if (!preview || !preview.length) {
      tableEl.innerHTML = '<p class="form-text">No products to preview.</p>';
      return;
    }
    var html = '<table><thead><tr><th>Title</th><th>SKU</th><th>Price</th><th>Type</th></tr></thead><tbody>';
    preview.slice(0, 50).forEach(function (row) {
      html += '<tr><td>' + escapeHtml(row.title) + '</td><td>' + escapeHtml(row.sku || '—') + '</td><td>'
        + ((row.price_cents || 0) / 100).toFixed(2) + '</td><td>' + (row.is_variant ? 'Variant' : 'Product') + '</td></tr>';
    });
    if (preview.length > 50) html += '<tr><td colspan="4">… and ' + (preview.length - 50) + ' more</td></tr>';
    html += '</tbody></table>';
    tableEl.innerHTML = html;
  }

  function runWizardDryRun() {
    var csv = getImportCsvPayload();
    var errEl = document.getElementById('commerce-import-review-error');
    if (errEl) errEl.hidden = true;
    return commercePost('import_dry_run', Object.assign({
      csv: csv,
      preset: importWizard.source,
      default_currency: document.getElementById('commerce-import-currency')?.value || 'eur',
    }, getImportCollectionPayload())).then(function (res) {
      if (res.status !== 'ok') {
        if (errEl) { errEl.hidden = false; errEl.textContent = res.message || 'Preview failed'; }
        return null;
      }
      importWizard.preview = res.data || {};
      var summary = document.getElementById('commerce-import-review-summary');
      if (summary) {
        var preview = (res.data.preview || []);
        var productCount = res.data.product_count != null
          ? res.data.product_count
          : preview.filter(function (r) { return !r.is_variant; }).length;
        var variants = res.data.variant_count != null
          ? res.data.variant_count
          : preview.filter(function (r) { return r.is_variant; }).length;
        summary.innerHTML = [
          { label: 'Products', value: productCount },
          { label: 'Variants', value: variants },
          { label: 'Rows', value: res.data.count || preview.length },
          { label: 'Collection', value: getImportCollectionLabel() },
          { label: 'Currency', value: (document.getElementById('commerce-import-currency')?.value || 'eur').toUpperCase() },
        ].map(function (s) {
          return '<div class="commerce-import-review-stat"><span class="field-help">' + escapeHtml(s.label) + '</span><strong>' + escapeHtml(String(s.value)) + '</strong></div>';
        }).join('');
      }
      renderImportPreviewTable((res.data && res.data.preview) || []);
      return res.data;
    });
  }

  function runWizardImport() {
    var csv = getImportCsvPayload();
    var importBtn = document.getElementById('commerce-import-wizard-import');
    if (importBtn) { importBtn.disabled = true; importBtn.textContent = 'Importing…'; }
    return commercePost('import_csv', Object.assign({
      csv: csv,
      preset: importWizard.source,
      default_currency: document.getElementById('commerce-import-currency')?.value || 'eur',
      file_name: importWizard.fileName || null,
    }, getImportCollectionPayload())).then(function (res) {
      if (importBtn) { importBtn.disabled = false; importBtn.textContent = 'Import products'; }
      if (res.status !== 'ok') {
        var errEl = document.getElementById('commerce-import-review-error');
        if (errEl) {
          errEl.hidden = false;
          errEl.textContent = res.message || (res.permission_denied
            ? 'Permission denied. Your account needs Commerce admin access.'
            : 'Import failed');
        }
        return;
      }
      importWizard.step = 4;
      renderImportResult(res.data || {});
      updateWizardStepUI();
      loadImportHistory();
    });
  }

  function renderImportResult(data) {
    var card = document.getElementById('commerce-import-result-card');
    var errorsWrap = document.getElementById('commerce-import-result-errors');
    if (!card) return;
    var status = data.status || 'success';
    var src = getSelectedSource();
    var collection = data.collection || getImportCollectionLabel();
    var collectionNote = data.collection_created ? ' (new collection created)' : '';
    card.className = 'commerce-import-result-card is-' + status;
    var title = status === 'success' ? 'Import complete' : (status === 'partial' ? 'Import completed with issues' : 'Import failed');
    card.innerHTML = '<h3>' + escapeHtml(title) + '</h3>'
      + '<p><strong>' + (data.imported_count || 0) + '</strong> products imported into <code>' + escapeHtml(collection) + '</code>' + escapeHtml(collectionNote) + ' from ' + escapeHtml(src.name) + '.</p>'
      + '<p>Created: ' + (data.created_count || 0) + ' · Updated: ' + (data.updated_count || 0) + ' · Skipped: ' + (data.skipped_count || 0) + ' · Variants: ' + (data.variant_count || 0) + '</p>';
    var skipped = data.skipped || [];
    if (errorsWrap) {
      if (!skipped.length) {
        errorsWrap.hidden = true;
        errorsWrap.innerHTML = '';
      } else {
        errorsWrap.hidden = false;
        var html = '<table><thead><tr><th>Row</th><th>Product</th><th>Issue</th></tr></thead><tbody>';
        skipped.forEach(function (row) {
          html += '<tr><td>' + escapeHtml(row.row || '—') + '</td><td>' + escapeHtml(row.title || row.sku || '—') + '</td><td>' + escapeHtml(row.reason || '—') + '</td></tr>';
        });
        html += '</tbody></table>';
        errorsWrap.innerHTML = html;
      }
    }
  }

  function wizardNextStep() {
    if (importWizard.step === 1) {
      importWizard.step = 2;
      updateWizardStepUI();
      return;
    }
    if (importWizard.step === 2) {
      if (!validateImportCollectionStep()) {
        return;
      }
      if (!getImportCsvPayload().trim()) {
        alert('Please upload or paste a CSV file first.');
        return;
      }
      importWizard.step = 3;
      updateWizardStepUI();
      runWizardDryRun();
      return;
    }
  }

  function wizardBackStep() {
    if (importWizard.step > 1 && importWizard.step < 4) {
      importWizard.step--;
      updateWizardStepUI();
    }
  }

  function initImportWizard() {
    document.getElementById('commerce-import-start')?.addEventListener('click', openImportWizard);
    document.getElementById('commerce-import-history-refresh')?.addEventListener('click', loadImportHistory);
    document.getElementById('commerce-import-wizard-close')?.addEventListener('click', closeImportWizard);
    document.getElementById('commerce-import-wizard-overlay')?.addEventListener('click', closeImportWizard);
    document.getElementById('commerce-import-wizard-cancel')?.addEventListener('click', closeImportWizard);
    document.getElementById('commerce-import-wizard-back')?.addEventListener('click', wizardBackStep);
    document.getElementById('commerce-import-wizard-next')?.addEventListener('click', wizardNextStep);
    document.getElementById('commerce-import-wizard-import')?.addEventListener('click', runWizardImport);
    document.getElementById('commerce-import-wizard-done')?.addEventListener('click', closeImportWizard);

    document.querySelectorAll('input[name="commerce-import-collection-mode"]').forEach(function (radio) {
      radio.addEventListener('change', updateImportCollectionModeUI);
    });

    document.getElementById('commerce-import-search')?.addEventListener('input', function (e) {
      importWizard.search = e.target.value.trim();
      renderWizardSources();
    });

    document.querySelectorAll('#commerce-import-filters .btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        importWizard.filter = btn.getAttribute('data-filter') || 'all';
        document.querySelectorAll('#commerce-import-filters .btn').forEach(function (b) {
          b.classList.toggle('is-active', b === btn);
        });
        renderWizardSources();
      });
    });

    document.getElementById('commerce-import-browse')?.addEventListener('click', function () {
      document.getElementById('commerce-import-file')?.click();
    });

    document.getElementById('commerce-import-file')?.addEventListener('change', function (e) {
      var file = e.target.files && e.target.files[0];
      if (file) readImportFile(file);
    });

    var dropzone = document.getElementById('commerce-import-dropzone');
    if (dropzone) {
      dropzone.addEventListener('dragover', function (e) { e.preventDefault(); dropzone.classList.add('is-dragover'); });
      dropzone.addEventListener('dragleave', function () { dropzone.classList.remove('is-dragover'); });
      dropzone.addEventListener('drop', function (e) {
        e.preventDefault();
        dropzone.classList.remove('is-dragover');
        var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (file) readImportFile(file);
      });
    }

    document.getElementById('commerce-import-csv')?.addEventListener('input', function (e) {
      importWizard.fileName = '';
      var nameEl = document.getElementById('commerce-import-file-name');
      if (nameEl) {
        delete nameEl.dataset.filename;
        nameEl.textContent = e.target.value.trim()
          ? 'CSV pasted (' + e.target.value.split('\n').length + ' lines)'
          : 'No file selected';
      }
      setImportCsvContent(e.target.value);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !document.getElementById('commerce-import-wizard')?.hidden) {
        closeImportWizard();
      }
    });
  }

  var migrationPreviewCache = [];

  function hasLegacyMigrationSources(data) {
    data = data || {};
    return !!((data.shopping_cart && data.shopping_cart.detected) || (data.events && data.events.detected));
  }

  function migrationOptions() {
    var sources = [];
    if (document.getElementById('commerce-migration-source-cart')?.checked) sources.push('shopping_cart');
    if (document.getElementById('commerce-migration-source-events')?.checked) sources.push('events');
    return {
      sources: sources,
      products_collection: document.getElementById('commerce-migration-products-collection')?.value || 'products',
      events_collection: document.getElementById('commerce-migration-events-collection')?.value || 'events-commerce',
      create_collections: !!document.getElementById('commerce-migration-create-collections')?.checked,
    };
  }

  function renderMigrationScan(data) {
    var el = document.getElementById('commerce-migration-scan');
    if (!el) return;
    var cart = data.shopping_cart || {};
    var events = data.events || {};
    var html = '<div class="commerce-migration-scan-grid">';
    html += '<div class="commerce-migration-scan-card"><h4>Shopping Cart</h4><p>'
      + (cart.detected ? 'Detected — ' + (cart.entry_count || 0) + ' legacy product entries' : 'No legacy product collections found')
      + '</p></div>';
    html += '<div class="commerce-migration-scan-card"><h4>Events</h4><p>'
      + (events.detected ? 'Detected — ' + (events.entry_count || 0) + ' legacy event entries' : 'No legacy events collections found')
      + '</p></div></div>';
    html += '<p class="field-help">Imported source keys on record: ' + (data.imported_source_keys || 0) + '</p>';
    el.innerHTML = html;
  }

  function loadMigrationScan() {
    var el = document.getElementById('commerce-migration-scan');
    var section = document.getElementById('commerce-migration-section');
    if (!el || !section) return Promise.resolve(false);
    el.innerHTML = '<div class="loading-state"><p>Scanning for legacy data…</p></div>';
    return commercePost('migration_scan').then(function (res) {
      if (res.status !== 'ok') {
        section.hidden = true;
        el.innerHTML = '<p class="error">Scan failed</p>';
        return false;
      }
      var data = res.data || {};
      var visible = hasLegacyMigrationSources(data);
      section.hidden = !visible;
      if (visible) {
        renderMigrationScan(data);
      } else {
        el.innerHTML = '';
      }
      return visible;
    });
  }

  function renderMigrationPreview(rows) {
    var wrap = document.getElementById('commerce-migration-preview-wrap');
    var table = document.getElementById('commerce-migration-preview-table');
    if (!wrap || !table) return;
    if (!rows.length) {
      wrap.hidden = false;
      table.innerHTML = '<p>No rows to preview for the selected sources.</p>';
      return;
    }
    var html = '<table class="table"><thead><tr><th>Source</th><th>Title</th><th>Target</th><th>Fulfillment</th><th>Action</th></tr></thead><tbody>';
    rows.forEach(function (row) {
      html += '<tr><td>' + escapeHtml(row.source || '') + '</td><td>' + escapeHtml(row.title || '') + '</td><td>'
        + escapeHtml(row.target_collection || '') + '</td><td>' + escapeHtml(row.fulfillment || '—') + '</td><td>'
        + escapeHtml(row.action || '') + '</td></tr>';
    });
    html += '</tbody></table>';
    table.innerHTML = html;
    wrap.hidden = false;
  }

  function runMigrationPreview() {
    commercePost('migration_preview', migrationOptions()).then(function (res) {
      if (res.status !== 'ok') {
        alert('Preview failed: ' + (res.message || 'Unknown error'));
        return;
      }
      migrationPreviewCache = (res.data && res.data.preview) || [];
      renderMigrationPreview(migrationPreviewCache);
    });
  }

  function runMigrationImport() {
    if (!confirm('Import legacy entries into Commerce collections? Legacy plugins and source entries are not removed.')) {
      return;
    }
    commercePost('migration_import', migrationOptions()).then(function (res) {
      if (res.status !== 'ok') {
        alert('Import failed: ' + (res.message || 'Unknown error'));
        return;
      }
      var data = res.data || {};
      alert('Imported ' + (data.imported_count || 0) + ' entries (' + (data.skipped_count || 0) + ' skipped).');
      loadMigrationScan();
      loadMigrationHistory();
      runMigrationPreview();
    });
  }

  function loadMigrationHistory() {
    var el = document.getElementById('commerce-migration-history-list');
    if (!el) return;
    el.innerHTML = '<div class="loading-state"><p>Loading migration history…</p></div>';
    commercePost('migration_history').then(function (res) {
      var items = (res.data && res.data.migrations) || [];
      if (!items.length) {
        el.innerHTML = '<p>No migration runs yet.</p>';
        return;
      }
      var html = '';
      items.forEach(function (run) {
        html += '<div class="commerce-migration-history-card">';
        html += '<div class="commerce-migration-history-head"><strong>' + escapeHtml(run.id || '') + '</strong> — ' + escapeHtml(run.status || '') + ' · ' + escapeHtml(run.at || '') + '</div>';
        html += '<p>Imported: ' + escapeHtml(run.imported_count || 0) + ' · Skipped: ' + escapeHtml(run.skipped_count || 0);
        if (run.rolled_back_at) html += ' · Rolled back ' + escapeHtml(run.rolled_back_at);
        html += '</p>';
        if (!run.rolled_back_at && (run.imported_count || 0) > 0) {
          html += '<button type="button" class="btn btn-secondary commerce-migration-rollback" data-id="' + escapeHtml(run.id || '') + '">Rollback</button>';
        }
        html += '</div>';
      });
      el.innerHTML = html;
      el.querySelectorAll('.commerce-migration-rollback').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.getAttribute('data-id');
          if (!id || !confirm('Delete Commerce entries created by this migration run?')) return;
          commercePost('migration_rollback', { id: id }).then(function (rb) {
            if (rb.status !== 'ok') {
              alert('Rollback failed: ' + (rb.message || 'Unknown error'));
              return;
            }
            loadMigrationHistory();
            loadMigrationScan();
            runMigrationPreview();
          });
        });
      });
    });
  }

  function loadMigrationTab() {
    return loadMigrationScan().then(function (visible) {
      if (visible) {
        loadMigrationHistory();
      }
      return visible;
    });
  }

  function initMigrationTab() {
    document.getElementById('commerce-migration-refresh')?.addEventListener('click', loadMigrationScan);
    document.getElementById('commerce-migration-preview')?.addEventListener('click', runMigrationPreview);
    document.getElementById('commerce-migration-import')?.addEventListener('click', runMigrationImport);
    document.getElementById('commerce-migration-history-refresh')?.addEventListener('click', loadMigrationHistory);
  }

  function loadStock() {
    var el = document.getElementById('commerce-stock-list');
    if (!el) return;
    return commercePost('list_warehouse_stock').then(function (res) {
      if (res.status !== 'ok') {
        el.innerHTML = '<p class="error">Failed to load stock</p>';
        return;
      }
      inventoryMode = (res.data && res.data.mode) || 'simple';
      setInventoryModeUi(inventoryMode);
      warehouseCache = (res.data && res.data.warehouses) || [];
      populateWarehouseSelects(warehouseCache);
      var rows = (res.data && res.data.stock) || [];
      if (inventoryMode === 'unlimited') {
        el.innerHTML = '<p class="field-help">Unlimited mode is active: stock codes are not counted, checkout does not reserve stock, and Catalog Available shows ∞.</p>';
        return;
      }
      if (!rows.length) {
        el.innerHTML = '<p class="field-help">No catalog stock codes yet. Add a Commerce field with a stock code (SKU) on a published product, rebuild the catalog, then set on-hand here.</p>';
        return;
      }
      var whMap = {};
      warehouseCache.forEach(function (w) { whMap[w.id] = w.name || w.id; });
      var html = '<div class="table-container"><table class="table commerce-stock-table"><thead><tr>'
        + (inventoryMode === 'locations' ? '<th>Warehouse</th>' : '')
        + '<th>Product</th><th>Stock code</th><th>On hand</th><th>Reserved</th><th>Available</th><th>Low alert</th><th>Catalog</th><th></th></tr></thead><tbody>';
      rows.forEach(function (row) {
        var tracked = row.tracked !== false && row.quantity_on_hand != null;
        html += '<tr class="' + (tracked ? '' : 'commerce-stock-untracked') + '">';
        if (inventoryMode === 'locations') {
          html += '<td>' + escapeHtml(whMap[row.warehouse_id] || row.warehouse_id || '') + '</td>';
        }
        html += '<td>' + escapeHtml(row.title || '—') + '</td>';
        html += '<td><code class="commerce-sku">' + escapeHtml(row.sku || '') + '</code></td>';
        if (tracked) {
          html += '<td>' + (row.quantity_on_hand ?? 0) + '</td><td>'
            + (row.reserved ?? 0) + '</td><td>' + (row.available ?? 0) + '</td><td>'
            + (row.low_stock_threshold ?? 0) + '</td><td>'
            + escapeHtml(row.catalog_quantity_available === null ? '∞' : (row.catalog_quantity_available ?? '—')) + '</td>';
        } else {
          html += '<td colspan="4"><span class="commerce-stock-unset">Not counted yet — sells as unlimited until you set on-hand</span></td>'
            + '<td>' + escapeHtml(row.catalog_quantity_available === null ? '∞' : (row.catalog_quantity_available ?? '—')) + '</td>';
        }
        html += '<td><button type="button" class="btn btn-secondary btn-sm commerce-stock-edit" data-sku="'
          + escapeHtml(row.sku || '') + '" data-qty="' + escapeHtml(String(row.quantity_on_hand ?? 0))
          + '" data-threshold="' + escapeHtml(String(row.low_stock_threshold ?? 0))
          + '">' + (tracked ? 'Edit' : 'Set stock') + '</button></td></tr>';
      });
      el.innerHTML = html + '</tbody></table></div>';
    });
  }

  function setInventoryModeUi(mode) {
    mode = mode || 'simple';
    var modeEl = document.getElementById('commerce-inventory-mode');
    if (modeEl) modeEl.value = mode;
    var settingsModeEl = document.getElementById('commerce-stock-mode');
    if (settingsModeEl) settingsModeEl.value = mode;
    var locations = mode === 'locations';
    var unlimited = mode === 'unlimited';
    ['commerce-locations-controls', 'commerce-transfer-controls'].forEach(function (id) {
      var section = document.getElementById(id);
      if (section) section.hidden = !locations;
    });
    var editor = document.querySelector('.commerce-inv-editor');
    if (editor) editor.hidden = unlimited;
    var saveBtn = document.getElementById('commerce-stock-save');
    if (saveBtn) saveBtn.disabled = unlimited;
  }

  function populateWarehouseSelects(warehouses) {
    ['commerce-warehouse-select', 'commerce-transfer-from', 'commerce-transfer-to'].forEach(function (id) {
      var sel = document.getElementById(id);
      if (!sel) return;
      var current = sel.value;
      sel.innerHTML = warehouses.map(function (w) {
        return '<option value="' + escapeHtml(w.id) + '">' + escapeHtml(w.name || w.id) + '</option>';
      }).join('');
      if (current) sel.value = current;
    });
  }

  function activateSettingsPanel(panelKey, opts) {
    opts = opts || {};
    var key = panelKey || 'connections';
    if (key === 'migration') key = 'import';
    var nav = document.querySelectorAll('.commerce-settings-nav .side-nav-item');
    var panels = document.querySelectorAll('.commerce-settings-panel');
    if (!nav.length) return;
    var found = false;
    nav.forEach(function (btn) {
      var match = btn.getAttribute('data-settings-panel') === key;
      btn.classList.toggle('active', match);
      btn.setAttribute('aria-selected', match ? 'true' : 'false');
      if (match) found = true;
    });
    if (!found) {
      key = 'connections';
      nav.forEach(function (btn) {
        var match = btn.getAttribute('data-settings-panel') === key;
        btn.classList.toggle('active', match);
        btn.setAttribute('aria-selected', match ? 'true' : 'false');
      });
    }
    panels.forEach(function (panel) {
      var match = panel.getAttribute('data-settings-panel') === key;
      panel.classList.toggle('active', match);
      panel.hidden = !match;
    });
    if (!opts.skipHash) setCommerceHash('settings/' + key);
    if (opts.skipLoad) return;
    if (key === 'connections') {
      if (typeof window.loadCommercePaymentsData === 'function') {
        window.loadCommercePaymentsData();
      }
    }
    if (key === 'fieldtypes') loadFieldtypeProfiles();
    if (key === 'mappings') {
      loadMappings();
      initMappingWizard();
    }
    if (key === 'shipping') loadShippingZones();
    if (key === 'tax') loadTaxRules();
    if (key === 'invoices') loadInvoiceSettings();
    if (key === 'emails') loadEmailSettings();
    if (key === 'import') {
      loadImportTab();
      loadMigrationTab();
    }
    if (key === 'fulfillment' && typeof window.loadFulfillmentTab === 'function') {
      window.loadFulfillmentTab();
    }
    if (key === 'activity' && typeof window.loadPaymentsActivity === 'function') {
      window.loadPaymentsActivity();
    }
  }

  function activateCommerceDocs() {
    if (window.BirklyPluginDocs) {
      window.BirklyPluginDocs.activate('commerce', 'commerce-docs-panel');
    }
  }

  window.commerceActivateSettingsPanel = function (panelKey) {
    activateSettingsPanel(panelKey || document.querySelector('.commerce-settings-nav .side-nav-item.active')?.getAttribute('data-settings-panel') || 'connections');
  };

  function initCommerceSettingsNav() {
    document.querySelectorAll('.commerce-settings-nav .side-nav-item').forEach(function (btn) {
      btn.addEventListener('click', function () {
        activateSettingsPanel(btn.getAttribute('data-settings-panel'));
      });
    });
  }

  var emailTemplatesCache = [];
  var emailSelectedId = '';
  var invoiceTemplatesCache = [];
  var invoiceSelectedTplId = '';
  var commerceCeAssetsLoaded = false;

  function fieldtypesApiUrl() {
    return (window.Birkly && typeof Birkly.url === 'function')
      ? Birkly.url('/api/admin_fieldtypes.php')
      : '/api/admin_fieldtypes.php';
  }

  function syncContentEditorHost(hostId, hiddenTextareaId) {
    var host = document.getElementById(hostId);
    var ta = document.getElementById(hiddenTextareaId);
    if (!host || !ta) return ta ? (ta.value || '') : '';
    var fallback = host.querySelector('textarea[id$="_fallback"]');
    if (fallback) {
      ta.value = fallback.value || '';
      return ta.value || '';
    }
    var wrapper = host.querySelector('.content-editor-wrapper');
    if (wrapper && window.ContentEditorSync && typeof ContentEditorSync.syncWrapperToHidden === 'function') {
      ContentEditorSync.syncWrapperToHidden(wrapper, true);
    }
    var field = host.querySelector('input[type="hidden"][id^="field_"], textarea[id^="field_"]');
    if (field) {
      ta.value = field.value || '';
    }
    return ta.value || '';
  }

  function getAdminCspNonce() {
    var el = document.querySelector('script[nonce]');
    if (!el) return '';
    // IDL .nonce is readable; getAttribute('nonce') is often empty by design.
    return el.nonce || el.getAttribute('nonce') || '';
  }

  /**
   * Admin CSP is script-src 'self' 'nonce-…' 'unsafe-eval'.
   * A bare <script textContent=…> without nonce is blocked — that was why the
   * Content Editor chrome rendered but Bold/Italic/etc. did nothing.
   * Prefer nonce'd inline script; fall back to eval (same as DynamicItems).
   */
  function injectContentEditorJavascript(jsSource) {
    if (!jsSource || window.ContentEditorSync) return !!window.ContentEditorSync;
    var nonce = getAdminCspNonce();
    try {
      var script = document.createElement('script');
      script.id = 'commerce-content-editor-js';
      if (nonce) {
        script.nonce = nonce;
        script.setAttribute('nonce', nonce);
      }
      script.textContent = jsSource;
      document.head.appendChild(script);
    } catch (e) {
      console.error('Content Editor script-tag inject failed', e);
    }
    if (window.ContentEditorSync) return true;
    try {
      (0, eval)(jsSource);
    } catch (e2) {
      console.error('Content Editor eval inject failed', e2);
    }
    return !!window.ContentEditorSync;
  }

  function ensureContentEditorAssets(data) {
    if (commerceCeAssetsLoaded && window.ContentEditorSync) {
      return true;
    }
    if (data.css && !document.getElementById('commerce-content-editor-css')) {
      var style = document.createElement('style');
      style.id = 'commerce-content-editor-css';
      style.textContent = data.css;
      document.head.appendChild(style);
    }
    var ok = true;
    if (!window.ContentEditorSync) {
      ok = injectContentEditorJavascript(data.javascript || '');
    }
    commerceCeAssetsLoaded = true;
    return ok;
  }

  function mountContentEditor(hostId, fieldName, label, htmlValue) {
    var host = document.getElementById(hostId);
    if (!host) return Promise.resolve();
    var formData = new FormData();
    formData.append('action', 'render');
    formData.append('fieldtype', 'content-editor');
    formData.append('config[name]', fieldName);
    formData.append('config[label]', label || 'Body');
    formData.append('config[value]', htmlValue || '');
    return fetch(fieldtypesApiUrl(), {
      method: 'POST',
      credentials: 'same-origin',
      body: formData
    }).then(function (r) { return r.json(); }).then(function (data) {
      if (data.error) throw new Error(data.error);
      if (!data.html) throw new Error('Content editor failed to render');
      // Load CE scripts BEFORE inserting markup — toolbar binds via MutationObserver
      // in editor.js, which only sees nodes added after the observer is attached.
      if (!ensureContentEditorAssets(data)) {
        throw new Error('Content Editor scripts blocked by CSP');
      }
      host.innerHTML = data.html;
      var editor = host.querySelector('.content-editor-area');
      if (editor) {
        window.ContentEditorState = window.ContentEditorState || {};
        window.ContentEditorState.activeEditor = editor;
      }
      setTimeout(function () {
        var wrapper = host.querySelector('.content-editor-wrapper');
        if (!wrapper || wrapper.dataset.initialized === 'true') return;
        // Nudge observer if the first paint raced observer attach.
        var html = host.innerHTML;
        host.innerHTML = '';
        host.innerHTML = html;
        var ed = host.querySelector('.content-editor-area');
        if (ed) {
          window.ContentEditorState = window.ContentEditorState || {};
          window.ContentEditorState.activeEditor = ed;
        }
      }, 0);
    }).catch(function (err) {
      console.error(err);
      host.innerHTML = '<p class="field-help">Could not load Content Editor — falling back to plain HTML.</p>'
        + '<textarea class="input" rows="12" id="' + escapeHtml(fieldName) + '_fallback">'
        + escapeHtml(htmlValue || '') + '</textarea>';
    });
  }

  /** Same path resolution as OG image / Media Library (relative /media/… is valid). */
  function resolveCommerceMediaUrl(mediaOrUrl) {
    var url = '';
    if (typeof mediaOrUrl === 'string') {
      url = mediaOrUrl;
    } else if (mediaOrUrl && typeof mediaOrUrl === 'object') {
      url = mediaOrUrl.url || mediaOrUrl.path || '';
    }
    return String(url || '').trim();
  }

  function updateInvoiceLogoPreview() {
    var input = document.getElementById('commerce-invoice-logo');
    var preview = document.getElementById('commerce-invoice-logo-preview');
    var thumb = document.getElementById('commerce-invoice-logo-thumb');
    if (!input || !preview || !thumb) return;
    var url = String(input.value || '').trim();
    if (!url) {
      preview.hidden = true;
      thumb.removeAttribute('src');
      return;
    }
    // Preview on the admin page can use site-relative /media/ paths.
    if (window.Birkly && typeof window.Birkly.url === 'function' && url.charAt(0) === '/' && !/^https?:\/\//i.test(url)) {
      thumb.src = window.Birkly.url(url.replace(/^\//, ''));
    } else {
      thumb.src = url;
    }
    preview.hidden = false;
  }

  function openCommerceMediaPicker(onSelect) {
    var modal = (window.Birkly && window.Birkly.MediaModal) || window.MediaModal;
    if (!modal || typeof modal.open !== 'function') {
      alert('Media Library is not available on this page. Paste an image URL instead, or reload admin.');
      return;
    }
    // System MediaModal — same API as entry OG image picker.
    modal.open(function (media) {
      var url = resolveCommerceMediaUrl(media);
      if (url && typeof onSelect === 'function') onSelect(url, media);
    });
  }

  function collectInvoiceProfileFromForm() {
    return {
      company_name: document.getElementById('commerce-invoice-company')?.value || '',
      address: document.getElementById('commerce-invoice-address')?.value || '',
      vat_id: document.getElementById('commerce-invoice-vat')?.value || '',
      email: document.getElementById('commerce-invoice-email')?.value || '',
      phone: document.getElementById('commerce-invoice-phone')?.value || '',
      bank_iban: document.getElementById('commerce-invoice-iban')?.value || '',
      logo_url: document.getElementById('commerce-invoice-logo')?.value || '',
      footer_note: document.getElementById('commerce-invoice-footer')?.value || '',
      tax_note: document.getElementById('commerce-invoice-tax-note')?.value || '',
      legal_disclaimer: document.getElementById('commerce-invoice-legal-text')?.value || '',
      template: document.getElementById('commerce-invoice-template')?.value || 'classic',
      number_prefix: document.getElementById('commerce-invoice-prefix')?.value || 'INV',
      auto_issue_on_paid: !!(document.getElementById('commerce-invoice-auto-issue')?.checked),
      legal_disclaimer_accepted: !!(document.getElementById('commerce-invoice-legal')?.checked)
    };
  }

  function fillActiveTemplateSelect(templates, activeId) {
    var sel = document.getElementById('commerce-invoice-template');
    if (!sel) return;
    sel.innerHTML = (templates || []).map(function (tpl) {
      return '<option value="' + escapeHtml(tpl.id) + '">' + escapeHtml(tpl.name || tpl.id) + '</option>';
    }).join('');
    if (activeId) sel.value = activeId;
  }

  function fillInvoiceProfileForm(profile, templates) {
    profile = profile || {};
    if (templates) fillActiveTemplateSelect(templates, profile.template || 'classic');
    var set = function (id, val) {
      var el = document.getElementById(id);
      if (el) el.value = val == null ? '' : String(val);
    };
    set('commerce-invoice-company', profile.company_name);
    set('commerce-invoice-address', profile.address);
    set('commerce-invoice-vat', profile.vat_id);
    set('commerce-invoice-email', profile.email);
    set('commerce-invoice-phone', profile.phone);
    set('commerce-invoice-iban', profile.bank_iban);
    set('commerce-invoice-logo', profile.logo_url);
    updateInvoiceLogoPreview();
    set('commerce-invoice-footer', profile.footer_note);
    set('commerce-invoice-tax-note', profile.tax_note);
    set('commerce-invoice-legal-text', profile.legal_disclaimer);
    set('commerce-invoice-template', profile.template || 'classic');
    set('commerce-invoice-prefix', profile.number_prefix || 'INV');
    var auto = document.getElementById('commerce-invoice-auto-issue');
    if (auto) auto.checked = profile.auto_issue_on_paid !== false;
    var legal = document.getElementById('commerce-invoice-legal');
    if (legal) legal.checked = !!profile.legal_disclaimer_accepted;
  }

  function renderInvoiceTemplateList() {
    var list = document.getElementById('commerce-invoice-template-list');
    if (!list) return;
    list.innerHTML = invoiceTemplatesCache.map(function (tpl) {
      var active = tpl.id === invoiceSelectedTplId ? ' active' : '';
      return '<button type="button" class="commerce-email-list__btn' + active + '" data-invoice-tpl-id="'
        + escapeHtml(tpl.id) + '"><strong>' + escapeHtml(tpl.name || tpl.id) + '</strong>'
        + '<small>' + (tpl.preset ? 'preset · editable' : 'custom') + '</small></button>';
    }).join('') || '<p class="field-help">No templates</p>';
    list.querySelectorAll('[data-invoice-tpl-id]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        selectInvoiceTemplate(btn.getAttribute('data-invoice-tpl-id'));
      });
    });
  }

  function selectInvoiceTemplate(id) {
    invoiceSelectedTplId = id || '';
    var tpl = null;
    invoiceTemplatesCache.forEach(function (row) {
      if (row.id === id) tpl = row;
    });
    renderInvoiceTemplateList();
    if (!tpl) return;
    document.getElementById('commerce-invoice-tpl-id').value = tpl.id;
    document.getElementById('commerce-invoice-tpl-name').value = tpl.name || '';
    document.getElementById('commerce-invoice-body').value = tpl.body_html || '';
    return mountContentEditor('commerce-invoice-body-editor', 'commerce_invoice_body', 'Invoice template', tpl.body_html || '');
  }

  function collectInvoiceTemplateFromForm() {
    var body = syncContentEditorHost('commerce-invoice-body-editor', 'commerce-invoice-body');
    var fallback = document.getElementById('commerce_invoice_body_fallback');
    if (fallback) body = fallback.value || body;
    return {
      id: document.getElementById('commerce-invoice-tpl-id')?.value || '',
      name: document.getElementById('commerce-invoice-tpl-name')?.value || '',
      body_html: body
    };
  }

  function loadInvoiceSettings() {
    commercePost('get_invoice_profile').then(function (res) {
      if (res.status !== 'ok' || !res.data) return;
      invoiceTemplatesCache = res.data.templates || [];
      var tokens = res.data.tokens || [];
      var tokenEl = document.getElementById('commerce-invoice-tokens');
      if (tokenEl) {
        tokenEl.textContent = 'Tokens: ' + tokens.map(function (t) {
          return '{{' + t.token + '}}';
        }).join(', ');
      }
      fillInvoiceProfileForm(res.data.profile || {}, invoiceTemplatesCache);
      var active = (res.data.profile && res.data.profile.template) || 'classic';
      if (!invoiceSelectedTplId) invoiceSelectedTplId = active;
      selectInvoiceTemplate(invoiceSelectedTplId);
    }).catch(function () {});
  }

  var emailDelayAnchors = {
    order_review_request: 'order_shipped',
    after_order_shipped: 'order_shipped',
    after_order_paid: 'order_paid'
  };
  var emailScheduledCache = [];

  function isDelayedEmailTrigger(trigger) {
    return !!emailDelayAnchors[trigger];
  }

  function syncEmailDelayFields() {
    var trigger = document.getElementById('commerce-email-trigger')?.value || '';
    var delayed = isDelayedEmailTrigger(trigger);
    var delayWrap = document.getElementById('commerce-email-delay-wrap');
    var reviewWrap = document.getElementById('commerce-email-review-url-wrap');
    if (delayWrap) delayWrap.hidden = !delayed;
    if (reviewWrap) reviewWrap.hidden = trigger !== 'order_review_request';
  }

  function saveCommerceDefaultEmailConnection(alias) {
    return commercePost('save_email_delivery_settings', {
      settings: { email_connection_alias: alias || '' }
    }).then(function (res) {
      if (res.status !== 'ok') {
        throw new Error(res.message || 'Failed to save default email connection');
      }
      return res;
    });
  }

  function mountCommerceEmailConnectionPicker(el, value, onChange) {
    if (!el || !window.BirklyEmailConnectionPicker) return;
    el.setAttribute('data-picker-value', value || '');
    BirklyEmailConnectionPicker.mount(el, {
      name: 'email_connection_alias',
      value: value || '',
      id: el.getAttribute('data-picker-id') || 'commerce-email-connection',
      help: el.getAttribute('data-picker-help') || '',
      onChange: onChange,
    });
  }

  function mountEmailTemplateConnectionPicker(value) {
    var wrap = document.getElementById('commerce-email-template-connection-wrap');
    if (!wrap) return;
    wrap.innerHTML = '<div id="commerce-email-template-connection-picker" data-email-connection-picker data-picker-name="email_connection_alias" data-picker-id="commerce-email-template-connection" data-picker-help="Send this template using a specific email connection. The Commerce default above is used when this matches the site default."></div>';
    mountCommerceEmailConnectionPicker(wrap.querySelector('[data-email-connection-picker]'), value || '');
  }

  function loadEmailSettings() {
    Promise.all([
      commercePost('list_email_templates'),
      commercePost('list_email_log', { limit: 15 })
    ]).then(function (results) {
      var tplRes = results[0];
      var logRes = results[1];
      if (tplRes.status === 'ok' && tplRes.data) {
        emailTemplatesCache = tplRes.data.templates || [];
        emailScheduledCache = tplRes.data.scheduled || [];
        if (tplRes.data.delay_anchors) emailDelayAnchors = tplRes.data.delay_anchors;
        var delivery = tplRes.data.delivery_settings || {};
        var picker = document.getElementById('commerce-email-connection-picker');
        mountCommerceEmailConnectionPicker(picker, delivery.email_connection_alias || '', function (alias) {
          saveCommerceDefaultEmailConnection(alias).catch(function (err) {
            alert((err && err.message) || 'Failed to save default email connection');
          });
        });
        var tokens = tplRes.data.tokens || [];
        var tokenEl = document.getElementById('commerce-email-tokens');
        if (tokenEl) {
          tokenEl.textContent = 'Tokens: ' + tokens.map(function (t) {
            return '{{' + t.token + '}}';
          }).join(', ');
        }
        renderEmailTemplateList();
        renderEmailScheduled(emailScheduledCache);
        if (!emailSelectedId && emailTemplatesCache.length) {
          selectEmailTemplate(emailTemplatesCache[0].id);
        } else if (emailSelectedId) {
          selectEmailTemplate(emailSelectedId);
        }
      }
      renderEmailLog((logRes && logRes.data && logRes.data.entries) || []);
    }).catch(function () {});
  }

  function renderEmailTemplateList() {
    var list = document.getElementById('commerce-email-template-list');
    if (!list) return;
    list.innerHTML = emailTemplatesCache.map(function (tpl) {
      var active = tpl.id === emailSelectedId ? ' active' : '';
      var meta = tpl.trigger || '';
      if (tpl.trigger === 'subscription_payment_failed') {
        meta = 'Dunning · ' + meta;
      }
      if (isDelayedEmailTrigger(tpl.trigger)) {
        meta += ' · ' + (parseInt(tpl.delay_days, 10) || 0) + 'd';
      }
      var enabled = !!tpl.enabled;
      var statusBadge = enabled
        ? '<span class="badge badge-success">Enabled</span>'
        : '<span class="badge badge-neutral">Disabled</span>';
      return '<button type="button" class="commerce-email-list__btn' + active + '" data-email-id="'
        + escapeHtml(tpl.id) + '"><span class="commerce-email-list__btn-top"><strong>'
        + escapeHtml(tpl.name || tpl.id) + '</strong>' + statusBadge + '</span>'
        + '<small>' + escapeHtml(meta) + '</small></button>';
    }).join('') || '<p class="field-help">No templates</p>';
    list.querySelectorAll('[data-email-id]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        selectEmailTemplate(btn.getAttribute('data-email-id'));
      });
    });
  }

  function renderEmailScheduled(jobs) {
    var el = document.getElementById('commerce-email-scheduled');
    if (!el) return;
    var pending = (jobs || []).filter(function (j) { return (j.status || '') === 'pending'; });
    if (!pending.length) {
      el.innerHTML = '<p class="field-help">No pending delayed emails. They appear here after an order is paid/shipped when a delayed template is enabled. Delivery still depends on a healthy Email connection under Settings → Connections.</p>';
      return;
    }
    el.innerHTML = pending.slice(0, 20).map(function (j) {
      return '<div class="commerce-email-log-row"><strong>' + escapeHtml(j.trigger || j.template_id || '')
        + '</strong> · order ' + escapeHtml(j.order_id || '')
        + '<br><small>Send at ' + escapeHtml(j.send_at || '') + ' (' + escapeHtml(String(j.delay_days || '')) + 'd)</small></div>';
    }).join('');
  }

  function selectEmailTemplate(id) {
    emailSelectedId = id || '';
    var tpl = null;
    emailTemplatesCache.forEach(function (row) {
      if (row.id === id) tpl = row;
    });
    renderEmailTemplateList();
    if (!tpl) return;
    var set = function (elId, val) {
      var el = document.getElementById(elId);
      if (el) el.value = val == null ? '' : String(val);
    };
    set('commerce-email-id', tpl.id);
    set('commerce-email-name', tpl.name);
    set('commerce-email-trigger', tpl.trigger);
    set('commerce-email-subject', tpl.subject);
    set('commerce-email-body', tpl.body_html);
    set('commerce-email-delay-days', tpl.delay_days != null ? tpl.delay_days : 7);
    set('commerce-email-review-url', tpl.review_url || '');
    var en = document.getElementById('commerce-email-enabled');
    if (en) en.checked = !!tpl.enabled;
    var attachInvoice = document.getElementById('commerce-email-attach-invoice');
    if (attachInvoice) attachInvoice.checked = !!tpl.attach_invoice;
    var attachPacking = document.getElementById('commerce-email-attach-packing-slip');
    if (attachPacking) attachPacking.checked = !!tpl.attach_packing_slip;
    var attachLabel = document.getElementById('commerce-email-attach-shipping-label');
    if (attachLabel) attachLabel.checked = !!tpl.attach_shipping_label;
    mountEmailTemplateConnectionPicker(tpl.email_connection_alias || '');
    syncEmailDelayFields();
    var box = document.getElementById('commerce-email-preview-box');
    if (box) box.hidden = true;
    return mountContentEditor('commerce-email-body-editor', 'commerce_email_body', 'Email body', tpl.body_html || '');
  }

  function collectEmailTemplateFromForm() {
    var body = syncContentEditorHost('commerce-email-body-editor', 'commerce-email-body');
    var fallback = document.getElementById('commerce_email_body_fallback');
    if (fallback) body = fallback.value || body;
    return {
      id: document.getElementById('commerce-email-id')?.value || '',
      name: document.getElementById('commerce-email-name')?.value || '',
      trigger: document.getElementById('commerce-email-trigger')?.value || 'order_paid',
      enabled: !!(document.getElementById('commerce-email-enabled')?.checked),
      delay_days: parseInt(document.getElementById('commerce-email-delay-days')?.value || '0', 10) || 0,
      review_url: document.getElementById('commerce-email-review-url')?.value || '',
      subject: document.getElementById('commerce-email-subject')?.value || '',
      body_html: body,
      body_mode: 'html',
      email_connection_alias: document.getElementById('commerce-email-template-connection')?.value || '',
      attach_invoice: !!(document.getElementById('commerce-email-attach-invoice')?.checked),
      attach_packing_slip: !!(document.getElementById('commerce-email-attach-packing-slip')?.checked),
      attach_shipping_label: !!(document.getElementById('commerce-email-attach-shipping-label')?.checked),
    };
  }

  function openCommerceEmailLog() {
    var commerceTab = document.getElementById('payments-tab-settings');
    if (commerceTab && commerceTab.hidden) {
      document.querySelector('[data-payments-tab="settings"]')?.click();
    }
    activateSettingsPanel('emails');
    var section = document.getElementById('commerce-email-log-section');
    if (section) {
      section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  function renderEmailLog(entries) {
    var el = document.getElementById('commerce-email-log');
    if (!el) return;
    if (!entries.length) {
      el.innerHTML = '<p class="field-help">No sends logged yet. That usually means no <strong>order paid</strong> event has fired — check the order status in Orders (pending vs paid). Enabling a template prepares the message; delivery still needs a healthy Email connection under Settings → Connections.</p>';
      return;
    }
    el.innerHTML = entries.map(function (row) {
      var statusLabel = '';
      if (row.skipped) {
        statusLabel = 'skipped';
      } else if (row.ok === false) {
        statusLabel = 'failed';
      } else if (row.queued) {
        statusLabel = 'queued';
      } else if (row.logged || row.delivered === false) {
        statusLabel = 'logged only (not inbox)';
      } else if (row.delivered) {
        statusLabel = 'delivered';
      }
      return '<div class="payments-connection-card"><strong>'
        + escapeHtml(row.subject || '(no subject)') + '</strong>'
        + '<div class="field-help">' + escapeHtml(row.to || '') + ' · '
        + escapeHtml(row.method || '') + ' · ' + escapeHtml(row.trigger || '')
        + (statusLabel ? ' · ' + escapeHtml(statusLabel) : '')
        + (row.note ? ' · ' + escapeHtml(row.note) : '')
        + (row.error && !row.note ? ' · ' + escapeHtml(row.error) : '')
        + '</div></div>';
    }).join('');
  }

  function initInvoiceEmailSettings() {
    document.getElementById('commerce-invoice-logo-pick')?.addEventListener('click', function () {
      openCommerceMediaPicker(function (url) {
        var input = document.getElementById('commerce-invoice-logo');
        if (!input) return;
        input.value = url;
        updateInvoiceLogoPreview();
      });
    });
    document.getElementById('commerce-invoice-logo-clear')?.addEventListener('click', function () {
      var input = document.getElementById('commerce-invoice-logo');
      if (input) input.value = '';
      updateInvoiceLogoPreview();
    });
    document.getElementById('commerce-invoice-logo')?.addEventListener('input', updateInvoiceLogoPreview);
    document.getElementById('commerce-invoice-form')?.addEventListener('submit', function (e) {
      e.preventDefault();
      commercePost('save_invoice_profile', { profile: collectInvoiceProfileFromForm() }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Failed to save invoice profile');
          return;
        }
        fillInvoiceProfileForm((res.data && res.data.profile) || collectInvoiceProfileFromForm(), invoiceTemplatesCache);
        alert('Invoice company profile saved');
      }).catch(function (err) {
        alert((err && err.message) || 'Failed to save invoice profile');
      });
    });
    document.getElementById('commerce-invoice-preview')?.addEventListener('click', function () {
      var body = syncContentEditorHost('commerce-invoice-body-editor', 'commerce-invoice-body');
      openHtmlDocumentAsync(
        commercePost('preview_invoice', {
          profile: collectInvoiceProfileFromForm(),
          template_id: document.getElementById('commerce-invoice-tpl-id')?.value || '',
          body_html: body
        }).then(function (res) {
          if (res.status !== 'ok' || !res.data || !res.data.html) {
            throw new Error(res.message || 'Preview failed');
          }
          return res.data.html;
        }),
        'invoice-preview.html'
      ).catch(function (err) {
        alert((err && err.message) || 'Preview failed');
      });
    });
    document.getElementById('commerce-invoice-tpl-save')?.addEventListener('click', function () {
      var tpl = collectInvoiceTemplateFromForm();
      commercePost('save_invoice_template', { template: tpl }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Failed to save template');
          return;
        }
        invoiceTemplatesCache = (res.data && res.data.templates) || invoiceTemplatesCache;
        fillActiveTemplateSelect(invoiceTemplatesCache, document.getElementById('commerce-invoice-template')?.value);
        invoiceSelectedTplId = (res.data && res.data.template && res.data.template.id) || tpl.id;
        selectInvoiceTemplate(invoiceSelectedTplId);
        alert('Invoice template saved');
      }).catch(function (err) {
        alert((err && err.message) || 'Failed to save template');
      });
    });
    document.getElementById('commerce-invoice-tpl-duplicate')?.addEventListener('click', function () {
      var id = document.getElementById('commerce-invoice-tpl-id')?.value;
      if (!id) return;
      commercePost('duplicate_invoice_template', { id: id }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Duplicate failed');
          return;
        }
        invoiceTemplatesCache = (res.data && res.data.templates) || [];
        fillActiveTemplateSelect(invoiceTemplatesCache, document.getElementById('commerce-invoice-template')?.value);
        invoiceSelectedTplId = res.data.template.id;
        selectInvoiceTemplate(invoiceSelectedTplId);
      }).catch(function (err) {
        alert((err && err.message) || 'Duplicate failed');
      });
    });
    document.getElementById('commerce-invoice-tpl-add')?.addEventListener('click', function () {
      var name = prompt('New template name:', 'Custom invoice');
      if (!name) return;
      var base = invoiceTemplatesCache[0] || { body_html: '<h1>Invoice {{invoice_number}}</h1>{{line_items_html}}<div class="money">{{money_html}}</div>' };
      commercePost('save_invoice_template', {
        template: {
          id: '',
          name: name,
          body_html: base.body_html || '',
          preset: false
        }
      }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Create failed');
          return;
        }
        invoiceTemplatesCache = (res.data && res.data.templates) || [];
        fillActiveTemplateSelect(invoiceTemplatesCache, document.getElementById('commerce-invoice-template')?.value);
        invoiceSelectedTplId = res.data.template.id;
        selectInvoiceTemplate(invoiceSelectedTplId);
      }).catch(function (err) {
        alert((err && err.message) || 'Create failed');
      });
    });
    document.getElementById('commerce-invoice-tpl-delete')?.addEventListener('click', function () {
      var id = document.getElementById('commerce-invoice-tpl-id')?.value;
      if (!id) return;
      if (!confirm('Delete this invoice template?')) return;
      commercePost('delete_invoice_template', { id: id }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Delete failed');
          return;
        }
        invoiceTemplatesCache = (res.data && res.data.templates) || [];
        fillActiveTemplateSelect(invoiceTemplatesCache, document.getElementById('commerce-invoice-template')?.value);
        invoiceSelectedTplId = invoiceTemplatesCache[0] ? invoiceTemplatesCache[0].id : 'classic';
        selectInvoiceTemplate(invoiceSelectedTplId);
      }).catch(function (err) {
        alert((err && err.message) || 'Delete failed');
      });
    });
    document.getElementById('commerce-email-trigger')?.addEventListener('change', syncEmailDelayFields);
    document.getElementById('commerce-email-save')?.addEventListener('click', function () {
      var tpl = collectEmailTemplateFromForm();
      commercePost('save_email_template', { template: tpl }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Failed to save template');
          return;
        }
        alert('Email template saved');
        loadEmailSettings();
      }).catch(function (err) {
        alert((err && err.message) || 'Failed to save template');
      });
    });
    document.getElementById('commerce-email-process-due')?.addEventListener('click', function () {
      commercePost('process_scheduled_emails').then(function (res) {
        if (res.status !== 'ok' || !res.data) {
          alert(res.message || 'Failed to process scheduled emails');
          return;
        }
        alert('Processed ' + (res.data.processed || 0)
          + ' due email(s): ' + (res.data.sent || 0) + ' sent, '
          + (res.data.skipped || 0) + ' skipped.');
        loadEmailSettings();
      }).catch(function (err) {
        alert((err && err.message) || 'Failed to process scheduled emails');
      });
    });
    document.getElementById('commerce-email-preview')?.addEventListener('click', function () {
      var id = document.getElementById('commerce-email-id')?.value;
      if (!id) return;
      commercePost('save_email_template', { template: collectEmailTemplateFromForm() }).then(function () {
        return commercePost('preview_email_template', { id: id });
      }).then(function (res) {
        if (res.status !== 'ok' || !res.data) {
          alert(res.message || 'Preview failed');
          return;
        }
        var box = document.getElementById('commerce-email-preview-box');
        if (!box) return;
        box.hidden = false;
        box.innerHTML = '<p class="commerce-email-preview__subject">' + escapeHtml(res.data.subject || '')
          + '</p><div>' + (res.data.body_html || '') + '</div>';
      }).catch(function (err) {
        alert((err && err.message) || 'Preview failed');
      });
    });
    document.getElementById('commerce-email-send-test')?.addEventListener('click', function () {
      var id = document.getElementById('commerce-email-id')?.value;
      if (!id) return;
      var to = prompt('Send test email to:');
      if (!to) return;
      commercePost('save_email_template', { template: collectEmailTemplateFromForm() }).then(function () {
        return commercePost('send_test_email', { id: id, to: to });
      }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || (res.data && res.data.error) || 'Send failed');
          return;
        }
        var data = res.data || {};
        var message;
        if (data.queued) {
          message = 'Test email accepted by the mail server.';
        } else if (data.method === 'commerce_log') {
          message = 'Test logged locally — the Birkly mail pipeline was not loaded. Update CMS core and Commerce, then retry.';
        } else if (data.logged || data.delivered === false) {
          message = data.note || 'Test logged locally — not delivered. Choose a deliverable email connection under Settings → Connections (SMTP or an ESP, not Log only).';
        } else         if (data.delivered) {
          message = 'Test email accepted by the configured connection.';
        } else {
          message = 'Test send handled.';
        }
        if (res.warning) {
          message = res.warning + '\n\n' + message;
        }
        alert(message);
        loadEmailSettings();
      }).catch(function (err) {
        alert((err && err.message) || 'Send failed');
      });
    });
  }

  var fulfillmentView = 'open';
  var fulfillmentSearch = '';
  var fulfillmentCache = { items: [], counts: { open: 0, history: 0, all: 0 } };
  var fulfillmentSearchTimer = null;
  var selectedFulfillmentIds = {};
  var expandedFulfillment = {};

  function fulfillmentTypeBadge(key, label) {
    return '<span class="commerce-type-tag commerce-fulfill-type-' + escapeHtml(key || 'ship') + '">'
      + escapeHtml(label || key || 'Ship') + '</span>';
  }

  function fulfillmentStatusBadge(status) {
    var map = {
      open: { cls: 'needs_ship', label: 'Action needed' },
      partial: { cls: 'partial_ship', label: 'Partial' },
      done: { cls: 'shipped', label: 'Done' },
      pending: { cls: 'needs_ship', label: 'Pending' },
    };
    var meta = map[status] || map.open;
    return '<span class="commerce-type-tag commerce-fulfill-tag-' + meta.cls + '">' + meta.label + '</span>';
  }

  function renderFulfillmentActors(actors) {
    actors = Array.isArray(actors) ? actors : [];
    if (!actors.length) return '<span class="commerce-order-meta">No admin attributed yet</span>';
    return actors.slice(0, 3).map(function (a) {
      return '<span class="commerce-fulfillment-actor" title="'
        + escapeHtml(a.email || '') + '">' + escapeHtml(a.label || 'Admin') + '</span>';
    }).join(' ');
  }

  function updateFulfillmentBulkBar() {
    var ids = Object.keys(selectedFulfillmentIds);
    var btn = document.getElementById('commerce-fulfillment-bulk-ship');
    if (btn) btn.disabled = !ids.length;
  }

  function renderFulfillmentList() {
    var el = document.getElementById('commerce-fulfillment-list');
    var countsEl = document.getElementById('commerce-fulfillment-counts');
    if (!el) return;
    var counts = fulfillmentCache.counts || {};
    if (countsEl) {
      countsEl.innerHTML = '<span><strong>' + (counts.open || 0) + '</strong> open</span>'
        + '<span><strong>' + (counts.history || 0) + '</strong> history</span>'
        + '<span><strong>' + (counts.all || 0) + '</strong> total</span>';
    }
    setTabBadge('fulfillment', counts.open || 0);
    var items = fulfillmentCache.items || [];
    if (!items.length) {
      el.innerHTML = '<div class="empty-state"><p>'
        + (fulfillmentSearch
          ? 'No fulfillment rows match your search.'
          : (fulfillmentView === 'history'
            ? 'No completed fulfillments yet.'
            : 'No open fulfillments. Paid orders with ship/digital/register/gift-card lines appear here until done.'))
        + '</p></div>';
      updateFulfillmentBulkBar();
      return;
    }
    var html = '';
    items.forEach(function (card) {
      var open = !!expandedFulfillment[card.id];
      var checked = !!selectedFulfillmentIds[card.id];
      var canShip = (card.primary_action === 'ship');
      html += '<article class="commerce-accordion-item' + (open ? ' is-open' : '') + '" data-fulfillment-id="'
        + escapeHtml(card.id || '') + '">';
      html += '<div class="commerce-accordion-summary-row">';
      if (canShip && fulfillmentView !== 'history') {
        html += '<label class="commerce-row-check" title="Select for bulk ship"><input type="checkbox" class="commerce-fulfillment-select" data-id="'
          + escapeHtml(card.id || '') + '"' + (checked ? ' checked' : '') + '></label>';
      } else {
        html += '<span class="commerce-row-check-spacer"></span>';
      }
      html += '<div class="commerce-accordion-summary-stack">';
      html += '<button type="button" class="commerce-accordion-summary" data-fulfillment-toggle="'
        + escapeHtml(card.id || '') + '" aria-expanded="' + (open ? 'true' : 'false') + '">';
      html += '<span class="commerce-accordion-chevron" aria-hidden="true"></span>';
      html += '<div class="commerce-accordion-main">';
      html += '<div class="commerce-accordion-tags">';
      html += fulfillmentStatusBadge(card.has_open_work ? 'open' : 'done');
      Object.keys(card.type_counts || {}).forEach(function (key) {
        var labels = { ship: 'Ship', deliver: 'Digital', register: 'Register', gift_card: 'Gift card' };
        html += fulfillmentTypeBadge(key, labels[key] || key);
      });
      html += '</div>';
      html += '<div class="commerce-accordion-title"><span class="commerce-order-number">'
        + escapeHtml(card.order_number || card.id || '') + '</span>'
        + '<span class="commerce-order-items-sep">·</span>'
        + escapeHtml(card.summary || '') + '</div>';
      html += '</div>';
      html += '<div class="commerce-accordion-total">' + escapeHtml(formatCents(card.total_cents, card.currency)) + '</div>';
      html += '</button>';
      html += '<div class="commerce-accordion-meta">';
      html += '<div class="commerce-accordion-meta-line">';
      html += '<span class="commerce-accordion-meta-name">' + escapeHtml(card.customer_name || card.customer_email || 'No customer') + '</span>';
      html += '<span class="commerce-accordion-meta-date">' + escapeHtml(formatOrderDate(card.created_at)) + '</span>';
      html += '</div>';
      if (card.customer_email && card.customer_name) {
        html += '<div class="commerce-accordion-meta-email">' + escapeHtml(card.customer_email) + '</div>';
      }
      html += '<div class="commerce-fulfillment-actors">Handled by: ' + renderFulfillmentActors(card.actors) + '</div>';
      html += '</div></div></div>';

      html += '<div class="commerce-accordion-body"' + (open ? '' : ' hidden') + '>';
      html += '<div class="commerce-accordion-section"><h4>Line actions</h4>';
      (card.lines || []).forEach(function (line) {
        html += '<div class="commerce-fulfillment-line">';
        html += '<div class="commerce-fulfillment-line-main">';
        html += fulfillmentTypeBadge(line.fulfillment, line.fulfillment_label);
        html += fulfillmentStatusBadge(line.status);
        html += '<strong>' + escapeHtml(line.title || 'Item') + '</strong>';
        if (line.sku) html += ' <code class="commerce-sku">' + escapeHtml(line.sku) + '</code>';
        html += '<span class="commerce-order-meta">Qty ' + escapeHtml(String(line.quantity || 1));
        if (line.fulfillment === 'ship') {
          html += ' · shipped ' + escapeHtml(String(line.quantity_shipped || 0))
            + ' · remaining ' + escapeHtml(String(line.quantity_remaining || 0));
        }
        html += '</span></div>';
        html += '<p class="commerce-fulfillment-next">' + escapeHtml(line.next_action || '') + '</p>';
        html += '</div>';
      });
      html += '</div>';

      if ((card.shipments || []).length) {
        html += '<div class="commerce-accordion-section"><h4>Shipment history</h4><ul class="commerce-fulfillment-history">';
        (card.shipments || []).slice().reverse().forEach(function (s) {
          html += '<li><strong>' + escapeHtml(formatOrderDate(s.created_at)) + '</strong> — '
            + escapeHtml(s.carrier || 'Carrier') + ' '
            + escapeHtml(s.tracking_number || 'no tracking')
            + ' · by ' + escapeHtml(s.created_by || 'unknown admin') + '</li>';
        });
        html += '</ul></div>';
      }
      if ((card.fulfillment_activity || []).length) {
        html += '<div class="commerce-accordion-section"><h4>Activity</h4><ul class="commerce-fulfillment-history">';
        (card.fulfillment_activity || []).slice().reverse().slice(0, 8).forEach(function (row) {
          html += '<li><strong>' + escapeHtml(formatOrderDate(row.at)) + '</strong> — '
            + escapeHtml(row.actor_label || 'Admin') + ': '
            + escapeHtml(row.detail || row.action || '') + '</li>';
        });
        html += '</ul></div>';
      }

      html += '<div class="commerce-accordion-actions">';
      if (canShip) {
        html += '<button type="button" class="btn btn-primary btn-sm commerce-fulfillment-ship-now" data-id="'
          + escapeHtml(card.id || '') + '">' + escapeHtml(card.primary_label || 'Mark shipped') + '</button> ';
        html += '<button type="button" class="btn btn-secondary btn-sm commerce-fulfillment-packing" data-id="'
          + escapeHtml(card.id || '') + '">Packing slip</button> ';
      }
      html += '<button type="button" class="btn btn-secondary btn-sm commerce-open-order" data-id="'
        + escapeHtml(card.id || '') + '">Open full order</button>';
      html += '</div></div></article>';
    });
    el.innerHTML = html;
    updateFulfillmentBulkBar();
  }

  function loadFulfillmentDesk() {
    var el = document.getElementById('commerce-fulfillment-list');
    if (!el) return;
    el.innerHTML = '<div class="loading-state"><p>Loading fulfillment desk…</p></div>';
    return commercePost('list_fulfillment_desk', {
      view: fulfillmentView,
      search: fulfillmentSearch,
    }).then(function (res) {
      if (res.status !== 'ok' || !res.data) {
        el.innerHTML = '<p class="error">Failed to load fulfillment desk</p>';
        return;
      }
      fulfillmentCache = res.data;
      renderFulfillmentList();
    }).catch(function () {
      el.innerHTML = '<p class="error">Failed to load fulfillment desk</p>';
    });
  }

  function shipFulfillmentOrder(orderId) {
    if (!orderId) return Promise.resolve();
    return commercePost('create_shipment', {
      id: orderId,
      items: [],
      carrier: 'Manual',
      package_count: 1,
      notify_customer: false,
    }).then(function (res) {
      if (res.status !== 'ok') {
        alert(res.message || 'Failed to mark shipped');
        return;
      }
      commerceToast('Shipment recorded'
        + ((res.data && res.data.shipment && res.data.shipment.created_by)
          ? (' by ' + res.data.shipment.created_by) : ''));
      loadFulfillmentDesk();
      refreshActivityBadges();
    });
  }

  function initFulfillmentDesk() {
    document.getElementById('commerce-fulfillment-refresh')?.addEventListener('click', loadFulfillmentDesk);
    document.querySelectorAll('[data-fulfillment-view]').forEach(function (chip) {
      chip.addEventListener('click', function () {
        setSegmentedFilterActive('[data-fulfillment-view]', chip);
        fulfillmentView = chip.getAttribute('data-fulfillment-view') || 'open';
        selectedFulfillmentIds = {};
        loadFulfillmentDesk();
      });
    });
    document.getElementById('commerce-fulfillment-search')?.addEventListener('input', function (e) {
      clearTimeout(fulfillmentSearchTimer);
      fulfillmentSearchTimer = setTimeout(function () {
        fulfillmentSearch = (e.target && e.target.value) ? e.target.value.trim() : '';
        loadFulfillmentDesk();
      }, 220);
    });
    document.getElementById('commerce-fulfillment-bulk-ship')?.addEventListener('click', function () {
      var ids = Object.keys(selectedFulfillmentIds);
      if (!ids.length) return;
      if (!confirm('Mark ' + ids.length + ' order(s) as shipped?')) return;
      commercePost('bulk_mark_shipped', { ids: ids, carrier: 'Manual' }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Bulk ship failed');
        } else {
          commerceToast('Updated ' + ((res.data && res.data.updated && res.data.updated.length) || 0) + ' order(s)');
        }
        selectedFulfillmentIds = {};
        loadFulfillmentDesk();
        refreshActivityBadges();
      });
    });
    document.getElementById('commerce-fulfillment-list')?.addEventListener('change', function (e) {
      var t = eventEl(e);
      var box = t && t.closest ? t.closest('.commerce-fulfillment-select') : null;
      if (!box) return;
      var id = box.getAttribute('data-id');
      if (!id) return;
      if (box.checked) selectedFulfillmentIds[id] = true;
      else delete selectedFulfillmentIds[id];
      updateFulfillmentBulkBar();
    });
    document.getElementById('commerce-fulfillment-list')?.addEventListener('click', function (e) {
      var t = eventEl(e);
      if (!t) return;
      if (t.closest('.commerce-row-check') || t.closest('.commerce-fulfillment-select')) {
        e.stopPropagation();
        return;
      }
      var toggle = t.closest('[data-fulfillment-toggle]');
      if (toggle) {
        var tid = toggle.getAttribute('data-fulfillment-toggle');
        if (!tid) return;
        expandedFulfillment[tid] = !expandedFulfillment[tid];
        renderFulfillmentList();
        return;
      }
      var shipNow = t.closest('.commerce-fulfillment-ship-now');
      if (shipNow) {
        e.preventDefault();
        shipFulfillmentOrder(shipNow.getAttribute('data-id'));
        return;
      }
      var packing = t.closest('.commerce-fulfillment-packing');
      if (packing) {
        e.preventDefault();
        var oid = packing.getAttribute('data-id');
        openHtmlDocumentAsync(
          commercePost('packing_slips', { ids: [oid], id: oid, remaining_only: true, brand_name: 'Packing slip' }).then(function (res) {
            if (res.status !== 'ok' || !res.data || !res.data.html) {
              throw new Error(res.message || 'Failed to build packing slip');
            }
            return res.data.html;
          }),
          'packing-slip.html'
        ).catch(function (err) {
          alert((err && err.message) || 'Failed to build packing slip');
        });
      }
    });
  }

  function initCommerceTabs() {
    initCommerceSettingsNav();
    initInvoiceEmailSettings();
    var tabs = document.querySelectorAll('.commerce-page .tab[data-tab]');
    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        var name = tab.getAttribute('data-tab');
        if (!name) return;

        tabs.forEach(function (t) {
          var on = t === tab;
          t.classList.toggle('active', on);
          t.setAttribute('aria-selected', on ? 'true' : 'false');
        });

        showCommercePanel(name);

        var currentHash = location.hash || '';
        var settingsDeepLink = name === 'settings' && currentHash.indexOf('#settings/') === 0;
        if (name !== 'orders' && name !== 'subscriptions' && name !== 'customers' && !settingsDeepLink) {
          setCommerceHash(name);
        }

        if (name === 'analytics' || name === 'dashboard') loadAnalytics();
        if (name === 'catalog') loadCatalog();
        if (name === 'stock' || name === 'inventory') loadStock();
        if (name === 'orders') {
          var orderHash = location.hash || '';
          if (orderHash.indexOf('#order/') !== 0 && orderHash.indexOf('#customer/') !== 0
            && orderHash !== '#draft-orders' && orderHash !== '#quotes') {
            setCommerceHash('orders');
          }
          loadOrders();
        }
        if (name === 'customers') {
          var custHash = location.hash || '';
          if (custHash.indexOf('#customer-profile/') !== 0 && custHash !== '#customers/new') {
            setCommerceHash('customers');
            showCustomersListView();
          }
          loadCustomers();
        }
        if (name === 'subscriptions') {
          if ((location.hash || '').indexOf('#subscription/') !== 0) {
            setCommerceHash('subscriptions');
          }
          loadSubscriptions();
        }
        if (name === 'fulfillment') {
          setCommerceHash('fulfillment');
          loadFulfillmentDesk();
        }
        if (name === 'discounts') loadDiscounts();
        if (name === 'gift-cards') loadGiftCards();
        if (name === 'docs' || name === 'documentation') {
          setCommerceHash('docs');
          activateCommerceDocs();
        }
        if (name === 'settings') {
          var settingsPanel = document.querySelector('.commerce-settings-nav .side-nav-item.active')?.getAttribute('data-settings-panel') || 'connections';
          if (settingsDeepLink) {
            settingsPanel = currentHash.replace(/^#settings\//, '') || settingsPanel;
            if (settingsPanel === 'migration') settingsPanel = 'import';
            if (settingsPanel === 'documentation' || settingsPanel === 'docs') {
              activateCommerceTab('docs');
              return;
            }
          }
          activateSettingsPanel(settingsPanel, { skipHash: settingsDeepLink });
        }
      });
    });
  }

  var fieldtypeModalActionsBound = false;

  function initFieldtypeModalActions() {
    if (fieldtypeModalActionsBound) return;
    fieldtypeModalActionsBound = true;

    // Capture phase so modal buttons still work even if a child stops bubbling.
    document.addEventListener('click', function (e) {
      var t = e.target;
      if (!(t instanceof Element)) return;
      if (t.closest('#commerce-add-fieldtype-profile') || t.closest('#commerce-ft-empty-create')) {
        e.preventDefault();
        newFieldtypeProfile();
        return;
      }
      if (t.closest('#commerce-ft-save')) {
        saveFieldtypeProfile(e);
        return;
      }
      if (t.closest('#commerce-ft-cancel') || t.closest('#commerce-ft-modal-close') || t.closest('#commerce-ft-modal-overlay')) {
        closeFieldtypeModal(e);
        return;
      }
      var preset = t.closest('.commerce-ft-preset');
      if (preset) {
        e.preventDefault();
        applyPreset(preset.getAttribute('data-preset'));
        return;
      }
      if (t.closest('#commerce-ft-add-interval')) {
        e.preventDefault();
        if (!fieldtypeProfileDraft) return;
        var valueEl = document.getElementById('commerce-ft-interval-value');
        var labelEl = document.getElementById('commerce-ft-interval-label');
        var value = (valueEl && valueEl.value || '').trim();
        var label = (labelEl && labelEl.value || '').trim();
        if (!value) return;
        if (!label) label = value.replace(/_/g, ' ');
        if (!fieldtypeProfileDraft.settings.interval_options) fieldtypeProfileDraft.settings.interval_options = [];
        fieldtypeProfileDraft.settings.interval_options.push({ value: value, label: label });
        if (valueEl) valueEl.value = '';
        if (labelEl) labelEl.value = '';
        renderIntervalRows(fieldtypeProfileDraft.settings.interval_options);
        return;
      }
      if (t.closest('#commerce-ft-add-custom-field')) {
        e.preventDefault();
        if (!fieldtypeProfileDraft) return;
        var keyEl = document.getElementById('commerce-ft-cf-key');
        var cfLabelEl = document.getElementById('commerce-ft-cf-label');
        var key = ((keyEl && keyEl.value) || '').trim().replace(/[^a-z0-9_]/gi, '_').toLowerCase();
        var cfLabel = ((cfLabelEl && cfLabelEl.value) || '').trim();
        if (!key) return;
        if (!cfLabel) cfLabel = key;
        if (!fieldtypeProfileDraft.settings.custom_fields) fieldtypeProfileDraft.settings.custom_fields = [];
        fieldtypeProfileDraft.settings.custom_fields.push({ key: key, label: cfLabel, type: 'text' });
        if (keyEl) keyEl.value = '';
        if (cfLabelEl) cfLabelEl.value = '';
        renderCustomFieldRows(fieldtypeProfileDraft.settings.custom_fields);
      }
    }, true);

    document.getElementById('commerce-ft-slug')?.addEventListener('input', updateTypePreview);
    document.addEventListener('keydown', function (e) {
      var modal = document.getElementById('commerce-fieldtype-modal');
      if (e.key === 'Escape' && modal && !modal.hidden) {
        closeFieldtypeModal(e);
      }
    });
  }

  function initCommerceActions() {
    // Bind fieldtype modal first — must not depend on later init helpers.
    initFieldtypeModalActions();

    document.getElementById('commerce-reindex')?.addEventListener('click', function () {
      commercePost('rebuild_catalog').then(function () { loadCatalog(); });
    });
    document.getElementById('commerce-inventory-mode-save')?.addEventListener('click', function () {
      var mode = document.getElementById('commerce-inventory-mode')?.value || 'simple';
      commercePost('save_stock_mode', { mode: mode }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Failed to save stock mode');
          return;
        }
        setInventoryModeUi(mode);
        loadStock();
        loadCatalog();
      });
    });
    document.getElementById('commerce-inventory-rebuild')?.addEventListener('click', function () {
      commercePost('rebuild_catalog').then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Rebuild failed');
          return;
        }
        loadStock();
        loadCatalog();
      });
    });
    document.getElementById('commerce-inventory-reconcile')?.addEventListener('click', function () {
      commercePost('reconcile_inventory', { apply: true }).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Reconcile failed');
          return;
        }
        var drift = (res.data && res.data.drift_count) || 0;
        var fixed = (res.data && res.data.fixed_count) || 0;
        alert('Inventory reconcile complete. Drift rows: ' + drift + '. Fixed projections: ' + fixed + '.');
        loadStock();
        loadCatalog();
      });
    });
    document.getElementById('commerce-stock-save')?.addEventListener('click', function () {
      commercePost('save_warehouse_stock', {
        warehouse_id: inventoryMode === 'locations' ? (document.getElementById('commerce-warehouse-select')?.value || '') : '',
        sku: document.getElementById('commerce-stock-sku')?.value || '',
        quantity_on_hand: parseInt(document.getElementById('commerce-stock-qty')?.value || '0', 10),
        low_stock_threshold: parseInt(document.getElementById('commerce-stock-threshold')?.value || '0', 10),
      }).then(function () { loadStock(); });
    });
    document.getElementById('commerce-warehouse-add')?.addEventListener('click', function () {
      var name = prompt('Warehouse name:', 'East');
      if (!name) return;
      commercePost('save_warehouse', { name: name }).then(function () { loadStock(); });
    });
    document.getElementById('commerce-warehouse-rename')?.addEventListener('click', function () {
      var id = document.getElementById('commerce-warehouse-select')?.value;
      if (!id) return;
      var name = prompt('New warehouse name:');
      if (!name) return;
      commercePost('save_warehouse', { id: id, name: name }).then(function () { loadStock(); });
    });
    document.getElementById('commerce-warehouse-delete')?.addEventListener('click', function () {
      var id = document.getElementById('commerce-warehouse-select')?.value;
      if (!id || !confirm('Delete this warehouse? It must have zero stock.')) return;
      commercePost('delete_warehouse', { id: id }).then(function (res) {
        if (res.status !== 'ok') alert(res.message || 'Delete failed');
        loadStock();
      });
    });
    document.getElementById('commerce-transfer-stock')?.addEventListener('click', function () {
      commercePost('transfer_warehouse_stock', {
        sku: document.getElementById('commerce-transfer-sku')?.value || '',
        quantity: parseInt(document.getElementById('commerce-transfer-qty')?.value || '1', 10),
        from_warehouse_id: document.getElementById('commerce-transfer-from')?.value || '',
        to_warehouse_id: document.getElementById('commerce-transfer-to')?.value || '',
      }).then(function (res) {
        if (res.status !== 'ok') alert(res.message || 'Transfer failed');
        else loadStock();
      });
    });

    document.getElementById('commerce-subscriptions-refresh')?.addEventListener('click', loadSubscriptions);
    document.getElementById('commerce-orders-refresh')?.addEventListener('click', loadOrders);

    document.getElementById('commerce-issue-gift-card')?.addEventListener('click', openGiftCardModal);
    document.getElementById('commerce-gift-card-modal-close')?.addEventListener('click', closeGiftCardModal);
    document.getElementById('commerce-gift-card-cancel')?.addEventListener('click', closeGiftCardModal);
    document.getElementById('commerce-gift-card-save')?.addEventListener('click', issueGiftCardFromModal);
    document.getElementById('commerce-gift-card-modal')?.addEventListener('click', function (e) {
      if (e.target === e.currentTarget) closeGiftCardModal();
    });
    document.getElementById('commerce-discount-modal')?.addEventListener('click', function (e) {
      if (e.target === e.currentTarget) closeDiscountModal();
    });
    document.getElementById('commerce-refund-modal-close')?.addEventListener('click', closeRefundModal);
    document.getElementById('commerce-refund-cancel')?.addEventListener('click', closeRefundModal);
    document.getElementById('commerce-refund-save')?.addEventListener('click', submitRefundModal);
    document.getElementById('commerce-refund-modal')?.addEventListener('click', function (e) {
      if (e.target === e.currentTarget) closeRefundModal();
    });
    document.getElementById('commerce-cancel-modal-close')?.addEventListener('click', closeCancelModal);
    document.getElementById('commerce-cancel-dismiss')?.addEventListener('click', closeCancelModal);
    document.getElementById('commerce-cancel-confirm')?.addEventListener('click', submitCancelModal);
    document.getElementById('commerce-cancel-modal')?.addEventListener('click', function (e) {
      if (e.target === e.currentTarget) closeCancelModal();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      var openModal = document.querySelector('.modal-backdrop.active');
      if (!openModal) return;
      if (openModal.id === 'commerce-discount-modal') closeDiscountModal();
      else if (openModal.id === 'commerce-gift-card-modal') closeGiftCardModal();
      else if (openModal.id === 'commerce-refund-modal') closeRefundModal();
      else if (openModal.id === 'commerce-cancel-modal') closeCancelModal();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      var link = e.target && e.target.closest ? e.target.closest('span.linkish.commerce-open-customer') : null;
      if (!link) return;
      e.preventDefault();
      openCustomerTimeline(link.getAttribute('data-email') || '');
    });
    document.getElementById('commerce-stock-list')?.addEventListener('click', function (e) {
      var btn = e.target && e.target.closest ? e.target.closest('.commerce-stock-edit') : null;
      if (!btn) return;
      var skuInput = document.getElementById('commerce-stock-sku');
      var qtyInput = document.getElementById('commerce-stock-qty');
      var thrInput = document.getElementById('commerce-stock-threshold');
      if (skuInput) skuInput.value = btn.getAttribute('data-sku') || '';
      if (qtyInput) qtyInput.value = btn.getAttribute('data-qty') || '0';
      if (thrInput) thrInput.value = btn.getAttribute('data-threshold') || '0';
      skuInput?.focus();
      skuInput?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });

    document.getElementById('commerce-gift-cards-list')?.addEventListener('click', function (e) {
      var copyBtn = e.target.closest('.commerce-copy-gift-code');
      if (copyBtn) {
        var copyCode = copyBtn.getAttribute('data-code') || '';
        if (!copyCode) return;
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(copyCode).then(function () {
            commerceToast('Code copied');
          }).catch(function () {
            prompt('Copy gift card code:', copyCode);
          });
        } else {
          prompt('Copy gift card code:', copyCode);
        }
        return;
      }
      var btn = e.target.closest('.commerce-void-gift-card');
      if (!btn) return;
      var code = btn.getAttribute('data-code');
      if (!code || !confirm('Void gift card ' + code + '?')) return;
      commercePost('void_gift_card', { code: code }).then(function (res) {
        if (res.status !== 'ok') {
          alert('Void failed');
          return;
        }
        loadGiftCards();
      });
    });

    document.getElementById('commerce-new-draft-order')?.addEventListener('click', function () {
      openDraftEditor(null);
    });

    document.getElementById('commerce-draft-editor-close')?.addEventListener('click', closeDraftEditor);

    document.getElementById('commerce-create-quote')?.addEventListener('click', function () {
      var email = prompt('Customer email:', '') || '';
      commercePost('create_quote', { customer_email: email }).then(function (res) {
        if (res.status !== 'ok') {
          alert('Create from cart failed: ' + (res.message || 'Is the cart empty?'));
          return;
        }
        var url = (res.data && res.data.accept_url) || '';
        if (url) {
          prompt('Quote accept URL (copy to send to customer):', url);
        }
        loadQuotes();
        if (res.data && res.data.quote) openDraftEditor(res.data.quote);
      });
    });

    document.getElementById('commerce-draft-catalog-search-btn')?.addEventListener('click', searchDraftCatalog);
    document.getElementById('commerce-draft-catalog-search')?.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        searchDraftCatalog();
      }
    });

    document.getElementById('commerce-draft-catalog-results')?.addEventListener('click', function (e) {
      var btn = e.target.closest('.commerce-draft-add-catalog');
      if (!btn) return;
      draftEditorState.lines.push({
        collection: btn.getAttribute('data-collection') || '',
        collection_slug: btn.getAttribute('data-collection') || '',
        entry_id: btn.getAttribute('data-entry') || '',
        sku: btn.getAttribute('data-sku') || '',
        title: btn.getAttribute('data-title') || '',
        purchase_option_id: btn.getAttribute('data-option') || 'default',
        quantity: 1,
        unit_price_cents: Number(btn.getAttribute('data-price') || 0) || 0,
        custom_price: false,
      });
      renderDraftLines();
      scheduleDraftPreview();
    });

    document.getElementById('commerce-draft-lines')?.addEventListener('click', function (e) {
      var btn = e.target.closest('.commerce-draft-remove-line');
      if (!btn) return;
      var idx = parseInt(btn.getAttribute('data-idx'), 10);
      if (isNaN(idx)) return;
      draftEditorState.lines.splice(idx, 1);
      renderDraftLines();
      scheduleDraftPreview();
    });

    document.getElementById('commerce-draft-lines')?.addEventListener('change', function (e) {
      var qty = e.target.closest('.draft-line-qty');
      var price = e.target.closest('.draft-line-price');
      if (qty) {
        var qi = parseInt(qty.getAttribute('data-idx'), 10);
        if (!isNaN(qi) && draftEditorState.lines[qi]) {
          draftEditorState.lines[qi].quantity = Math.max(1, parseInt(qty.value, 10) || 1);
          scheduleDraftPreview();
        }
      }
      if (price) {
        var pi = parseInt(price.getAttribute('data-idx'), 10);
        if (!isNaN(pi) && draftEditorState.lines[pi]) {
          draftEditorState.lines[pi].unit_price_cents = Math.max(0, parseInt(price.value, 10) || 0);
          draftEditorState.lines[pi].custom_price = true;
          scheduleDraftPreview();
        }
      }
    });

    ['commerce-draft-email', 'commerce-draft-country', 'commerce-draft-vat', 'commerce-draft-note'].forEach(function (id) {
      document.getElementById(id)?.addEventListener('change', scheduleDraftPreview);
      document.getElementById(id)?.addEventListener('input', scheduleDraftPreview);
    });

    document.getElementById('commerce-draft-preview')?.addEventListener('click', runDraftPreview);
    document.getElementById('commerce-draft-save')?.addEventListener('click', function () {
      saveDraftOrder({});
    });
    document.getElementById('commerce-draft-save-send')?.addEventListener('click', function () {
      saveDraftOrder({ copyLink: true });
    });
    document.getElementById('commerce-draft-checkout')?.addEventListener('click', function () {
      saveDraftOrder({}).then(function (data) {
        if (!data || !data.quote) return;
        if (!confirm('Convert this draft to a pending payment checkout?')) return;
        commercePost('draft_order_checkout', {
          id: data.quote.id,
          email: data.quote.customer_email || '',
        }).then(function (res) {
          if (res.status !== 'ok') {
            alert(res.message || 'Checkout failed (is payments configured?)');
            return;
          }
          var redirect = res.data && res.data.redirect_url;
          if (redirect) {
            if (confirm('Payment started. Open payment URL?')) window.open(redirect, '_blank');
          } else {
            alert('Pending checkout created' + (res.data && res.data.order_id ? (' · order ' + res.data.order_id) : ''));
          }
          loadQuotes();
        });
      });
    });

    document.getElementById('commerce-quotes-list')?.addEventListener('click', function (e) {
      var openBtn = e.target.closest('.commerce-open-draft');
      if (openBtn) {
        var openId = openBtn.getAttribute('data-id');
        if (!openId) return;
        commercePost('draft_order_get', { id: openId }).then(function (res) {
          if (res.status !== 'ok' || !res.data || !res.data.quote) {
            alert('Could not load draft');
            return;
          }
          openDraftEditor(res.data.quote);
        });
        return;
      }
      var btn = e.target.closest('.commerce-cancel-quote');
      if (!btn) return;
      var id = btn.getAttribute('data-id');
      if (!id || !confirm('Cancel quote ' + id + '?')) return;
      commercePost('cancel_quote', { id: id }).then(function (res) {
        if (res.status !== 'ok') {
          alert('Cancel failed');
          return;
        }
        if (draftEditorState.id === id) closeDraftEditor();
        loadQuotes();
      });
    });

    document.getElementById('commerce-analytics-refresh')?.addEventListener('click', loadAnalytics);
    document.getElementById('commerce-analytics-export-orders')?.addEventListener('click', function () {
      var url = (window.Birkly && typeof Birkly.url === 'function')
        ? Birkly.url('/api/index.php?route=commerce&action=analytics_export_csv')
        : '/api/index.php?route=commerce&action=analytics_export_csv';
      window.open(url, '_blank');
    });

    document.getElementById('commerce-add-discount')?.addEventListener('click', function () {
      openDiscountModal({
        type: 'coupon',
        value_type: 'percent',
        value: 10,
        enabled: true,
        stackable: false
      });
    });
    bindDiscountUi();

    initImportWizard();
    initMigrationTab();

    document.getElementById('commerce-wizard-catalog')?.addEventListener('change', function () {
      var item = getSelectedCatalogItem();
      if (item && item.sku) {
        var skuInput = document.getElementById('commerce-wizard-sku');
        if (skuInput && !skuInput.value) skuInput.value = item.sku;
      }
      populateMappingOptions(item);
      updateMappingWizardSummary();
    });
    document.getElementById('commerce-wizard-sku')?.addEventListener('input', updateMappingWizardSummary);
    document.getElementById('commerce-wizard-option')?.addEventListener('change', updateMappingWizardSummary);
    document.getElementById('commerce-wizard-tier')?.addEventListener('change', updateMappingWizardSummary);

    document.getElementById('commerce-wizard-next-1')?.addEventListener('click', function () {
      var item = getSelectedCatalogItem();
      var sku = document.getElementById('commerce-wizard-sku')?.value || '';
      if (!item && !sku) {
        alert('Select a catalog item or enter a SKU');
        return;
      }
      populateMappingOptions(item);
      showMappingWizardStep(2);
      updateMappingWizardSummary();
    });
    document.getElementById('commerce-wizard-back-2')?.addEventListener('click', function () { showMappingWizardStep(1); });
    document.getElementById('commerce-wizard-next-2')?.addEventListener('click', function () {
      showMappingWizardStep(3);
      updateMappingWizardSummary();
    });
    document.getElementById('commerce-wizard-back-3')?.addEventListener('click', function () { showMappingWizardStep(2); });
    document.getElementById('commerce-wizard-save')?.addEventListener('click', function () {
      var item = getSelectedCatalogItem();
      var sku = document.getElementById('commerce-wizard-sku')?.value || '';
      var optionId = document.getElementById('commerce-wizard-option')?.value || '';
      var tier = document.getElementById('commerce-wizard-tier')?.value || '';
      if (!tier) {
        alert('Select a tier to grant');
        return;
      }
      if (!item && !sku) {
        alert('Select a catalog item or enter a SKU');
        return;
      }
      var payload = {
        grant_tier: tier,
        purchase_option_id: optionId,
        sku: sku,
      };
      if (item) {
        payload.collection_slug = item.collection_slug || '';
        payload.entry_slug = item.entry_slug || item.entry_id || '';
      }
      commercePost('create_membership_mapping', payload).then(function (res) {
        if (res.status !== 'ok') {
          alert(res.message || 'Failed to save mapping');
          return;
        }
        loadMappings();
        initMappingWizard();
        showMappingWizardStep(1);
        alert('Mapping saved');
      });
    });

    function syncFulfillmentProviderUi() {
      var adapter = document.getElementById('commerce-fulfillment-adapter')?.value || 'manual';
      var ep = document.getElementById('commerce-fulfillment-easypost-fields');
      if (ep) ep.hidden = adapter !== 'easypost';
    }

    window.loadFulfillmentTab = function () {
      commercePost('list_fulfillment').then(function (res) {
        var data = res.data || {};
        var connections = data.connections || {};
        var adapter = connections.active_adapter === 'easypost' ? 'easypost' : 'manual';
        var sel = document.getElementById('commerce-fulfillment-adapter');
        if (sel) {
          // Rebuild options from API (never include shipstation).
          var adapters = Array.isArray(data.available_adapters) ? data.available_adapters : [];
          if (adapters.length) {
            sel.innerHTML = adapters.map(function (a) {
              var label = escapeHtml(a.name || a.id);
              if (a.configured) label += ' (configured)';
              return '<option value="' + escapeHtml(a.id) + '">' + label + '</option>';
            }).join('');
          }
          sel.value = adapter;
        }
        var ep = connections.easypost || {};
        var urlEl = document.getElementById('commerce-easypost-webhook-url');
        if (urlEl && ep.webhook_url) urlEl.textContent = ep.webhook_url;
        var hint = document.getElementById('commerce-easypost-configured-hint');
        if (hint) hint.hidden = !ep.api_key_set;
        syncFulfillmentProviderUi();
      });
    };

    document.getElementById('commerce-fulfillment-adapter')?.addEventListener('change', syncFulfillmentProviderUi);

    document.getElementById('commerce-test-fulfillment')?.addEventListener('click', function () {
      var adapter = document.getElementById('commerce-fulfillment-adapter')?.value || 'manual';
      commercePost('test_fulfillment', { adapter: adapter }).then(function (res) {
        var el = document.getElementById('commerce-fulfillment-result');
        if (!el) return;
        el.hidden = false;
        el.textContent = (res.data && (res.data.message || res.data.error)) || res.message || JSON.stringify(res);
      });
    });

    document.getElementById('commerce-fulfillment-form')?.addEventListener('submit', function (e) {
      e.preventDefault();
      var adapter = document.getElementById('commerce-fulfillment-adapter')?.value || 'manual';
      commercePost('save_fulfillment', {
        connections: {
          active_adapter: adapter,
          easypost: {
            webhook_secret: document.getElementById('commerce-easypost-webhook-secret')?.value || '',
          },
        },
      }).then(function () {
        var secretEl = document.getElementById('commerce-easypost-webhook-secret');
        if (secretEl) secretEl.value = '';
        alert('Fulfillment settings saved');
        if (typeof window.loadFulfillmentTab === 'function') window.loadFulfillmentTab();
      });
    });

    document.getElementById('commerce-add-shipping-zone')?.addEventListener('click', function () {
      shippingZonesCache.push({ id: 'zone_' + Date.now(), name: 'New zone', countries: ['*'], rate_type: 'flat', flat_rate_cents: 500, weight_tiers: [] });
      renderShippingZones();
    });

    document.getElementById('commerce-shipping-rate-provider')?.addEventListener('change', syncShippingProviderUi);
    document.getElementById('commerce-free-shipping-enabled')?.addEventListener('change', syncFreeShippingUi);

    document.getElementById('commerce-save-shipping-zones')?.addEventListener('click', function () {
      var el = document.getElementById('commerce-shipping-zones-list');
      var zones = [];
      el?.querySelectorAll('.commerce-shipping-zone').forEach(function (row, idx) {
        var countriesRaw = row.querySelector('.zone-countries')?.value || '*';
        var rateType = row.querySelector('.zone-rate-type')?.value || 'flat';
        var zone = {
          id: shippingZonesCache[idx]?.id || ('zone_' + idx),
          name: row.querySelector('.zone-name')?.value || 'Zone',
          countries: countriesRaw.split(',').map(function (c) { return c.trim().toUpperCase(); }).filter(Boolean),
          rate_type: rateType,
          flat_rate_cents: parseInt(row.querySelector('.zone-rate')?.value || '0', 10),
        };
        if (rateType === 'weight_tiers') {
          zone.weight_tiers = [];
          row.querySelectorAll('.commerce-weight-tier-row').forEach(function (tierRow) {
            var maxRaw = tierRow.querySelector('.zone-tier-max')?.value.trim();
            zone.weight_tiers.push({
              max_grams: maxRaw === '' ? null : parseInt(maxRaw, 10),
              rate_cents: parseInt(tierRow.querySelector('.zone-tier-rate')?.value || '0', 10),
            });
          });
        }
        zones.push(zone);
      });
      var freeEnabled = !!document.getElementById('commerce-free-shipping-enabled')?.checked;
      var freeMin = freeEnabled
        ? Math.max(0, parseInt(document.getElementById('commerce-free-shipping-min-cents')?.value || '0', 10) || 0)
        : 0;
      commercePost('save_shipping_zones', {
        provider: document.getElementById('commerce-shipping-rate-provider')?.value || 'manual',
        easypost_api_key: document.getElementById('commerce-easypost-api-key')?.value || '',
        from_address: {
          country: (document.getElementById('commerce-shipping-from-country')?.value || '').trim().toUpperCase(),
          zip: (document.getElementById('commerce-shipping-from-zip')?.value || '').trim(),
        },
        free_shipping_min_cents: freeMin,
        zones: zones,
      }).then(function () {
        var keyEl = document.getElementById('commerce-easypost-api-key');
        if (keyEl) keyEl.value = '';
        alert('Shipping settings saved');
        loadShippingZones();
      });
    });

    document.getElementById('commerce-add-tax-country')?.addEventListener('click', function () {
      taxRulesCache.country_rates.push({ country: '', rate: 0 });
      renderTaxCountries();
    });

    document.getElementById('commerce-add-tax-class')?.addEventListener('click', function () {
      syncTaxClassesFromDom();
      var code = 'class_' + String(Object.keys(taxRulesCache.classes || {}).length + 1);
      taxRulesCache.classes[code] = { label: 'New class', default_rate: null };
      renderTaxClasses();
    });

    document.getElementById('commerce-add-tax-class-country')?.addEventListener('click', function () {
      syncTaxClassesFromDom();
      var first = Object.keys(taxRulesCache.classes || {})[0] || 'standard';
      taxRulesCache.class_country_rates.push({ class: first, country: '', rate: 0 });
      renderTaxClassCountries();
    });

    document.getElementById('commerce-save-tax-rules')?.addEventListener('click', function () {
      var el = document.getElementById('commerce-tax-country-list');
      var countryRates = [];
      el?.querySelectorAll('.commerce-tax-country').forEach(function (row) {
        var country = (row.querySelector('.tax-country')?.value || '').trim().toUpperCase();
        if (!country) return;
        countryRates.push({ country: country, rate: parseFloat(row.querySelector('.tax-rate')?.value || '0') || 0 });
      });
      syncTaxClassesFromDom();
      var classCountryRates = [];
      document.getElementById('commerce-tax-class-country-list')?.querySelectorAll('.commerce-tax-class-country').forEach(function (row) {
        var cls = (row.querySelector('.tax-cc-class')?.value || '').trim().toLowerCase();
        var country = (row.querySelector('.tax-cc-country')?.value || '').trim().toUpperCase();
        if (!cls || !country) return;
        classCountryRates.push({
          class: cls,
          country: country,
          rate: parseFloat(row.querySelector('.tax-cc-rate')?.value || '0') || 0,
        });
      });
      commercePost('save_tax_rules', {
        enabled: !!document.getElementById('commerce-tax-enabled')?.checked,
        provider: document.getElementById('commerce-tax-provider')?.value || 'manual',
        default_rate: parseFloat(document.getElementById('commerce-tax-default-rate')?.value || '0') || 0,
        country_rates: countryRates,
        classes: taxRulesCache.classes,
        class_country_rates: classCountryRates,
        b2b_reverse_charge: readB2bTaxUi(),
      }).then(function () {
        alert('Tax rules saved');
        loadTaxRules();
      });
    });

    document.getElementById('commerce-tax-provider')?.addEventListener('change', syncTaxProviderUi);

  }

  function init() {
    initFieldtypeModalActions();
    initOrdersFilters();
    initAccordionNavigation();
    initCommerceTabs();
    initFulfillmentDesk();
    initCommerceActions();
    bindCustomerUi();
    initLiveImport();
    startActivityPolling();
    window.addEventListener('hashchange', function () {
      routeCommerceHash();
    });
    if (!routeCommerceHash()) {
      document.querySelector('.commerce-tabs .tab.active')?.click();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
