# Troubleshooting

Common Commerce issues and fixes.

**Who it's for:** merchants and developers stuck on checkout, tax, stock, or admin navigation.

---

## Docs tab location

| Symptom | Fix |
|---------|-----|
| Cannot find documentation under Settings | From **Commerce 1.0.57+**, help is a **primary tab**: Admin → **Commerce → Docs**. It is not under Settings → Documentation. |
| Older plugin | Upgrade Commerce, or open the overview topic via plugin help registration / Birkly-Docs |

![Docs tab](/plugins/commerce/assets/docs/docs-tab.svg)

---

## Remove not working

| Cause | Fix |
|-------|-----|
| Stale `commerce-storefront.js` | Hard refresh; cache-bust `?v=1.0.57+` |
| Plugin older than 1.0.55 | Upgrade — empty `purchase_option_id` now match-any |
| Plugin older than 1.0.56 | Upgrade — add persists resolved option id on session rows |
| Multiple options, wrong id | Pass the exact `purchase_option_id` from the cart line |
| Session drift | `BirklyCommerce.clear()` then re-add |

```js
await BirklyCommerce.remove({
  entry_id: 'my-slug',
  collection: 'products',
  purchase_option_id: 'once'
});
```

Details: [help-storefront.md](help-storefront.md) → Remove cart caveats.

---

## Tax looks double-added

| Cause | Fix |
|-------|-----|
| Custom UI adds `tax_cents` on top of included prices | Use `tax_add_cents` for charge delta; when `prices_include_tax`, show **Tax (included)** |
| Product set to exclusive but shelf price was gross | Set **Price tax mode** → Tax included on the entry field |
| Reverse charge not stripping VAT | Enable B2B reverse charge; pass `vat_id`; confirm countries eligible |

> **Note:** Default `tax_included` is **true** (EU). Prefer `BirklyCommerce.renderMoneyRows(cart)`.

See [help-tax.md](help-tax.md).

---

## Missing “Price tax mode”

| Wrong place | Right place |
|-------------|-------------|
| Settings → Tax | **Entry editor → Commerce field → Tax block** |

Settings → Tax configures **rates and providers**. Price tax mode (`tax_included`) is per product on the Commerce field — [help-fieldtype.md](help-fieldtype.md).

![Commerce field blocks](/plugins/commerce/assets/docs/product-commerce-field.svg)

---

## Stock shows unlimited / not decrementing

| Cause | Fix |
|-------|-----|
| Stock mode = Unlimited | Settings → General → Stock mode → Simple or Locations |
| Digital / gift_card / none fulfillment | These do not use warehouse stock by design |
| Catalog stale | Commerce → Catalog → Rebuild index |
| Inventory never set | Inventory tab → set on hand for the SKU |
| Buying parent instead of variant | Buy the variant sub-entry id that owns the SKU |

See [help-catalog-inventory.md](help-catalog-inventory.md).

---

## Provider / live mode

| Symptom | Fix |
|---------|-----|
| Live charges fail | Connection must be a **certified** provider in live mode with live keys |
| Test cards fail in live | Use sandbox connection / test keys |
| “Commerce plugin is not active” | Activate under Settings → Plugins |
| Wrong provider selected | Settings → General → selection mode / default provider |

![Settings hub](/plugins/commerce/assets/docs/settings-nav.svg)

---

## Item not in catalog

1. Entry **published**?  
2. Commerce field filled (purchase options + fulfillment)?  
3. Correct `collection` + `entry_id` / slug on the buy button?  
4. **Rebuild catalog** after imports or file-level edits.  
5. For variants, pass the **variant** id, not the parent.

---

## Checkout / shipping / split pay

| Symptom | Fix |
|---------|-----|
| Shipping stays 0 | Cart has `ship` lines? Address on draft? Zones configured? |
| EasyPost fails | `weight_grams` set? API key valid? Manual zones as fallback? |
| Second payment missing | Call `continueSplitCheckout()` when `getSplitState().nextGroupKey` is set |
| Coupon ignored on subscription | Expected — promotions apply to one-time group only |

---

## Still stuck

1. Check **Commerce → Settings → Activity** for payment errors.  
2. Confirm plugin version in plugin.json / Hub (docs assume **1.0.57+** for Docs tab; cart remove fixes from **1.0.55/1.0.56**).  
3. Read [help-getting-started.md](help-getting-started.md) and [help-project-integration.md](help-project-integration.md).  
4. Public docs: [docs.birkly.com — Commerce](https://docs.birkly.com/06-extensibility/plugins/commerce.html)

## Related

- [Overview](help-overview.md)
- [Storefront](help-storefront.md)
- [Developer](help-developer.md)
