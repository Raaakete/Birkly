# RFC — Commerce Storefront Platform v2

**Status:** Approved (P70) · **Baseline:** Commerce 1.0.93+  
**Plan:** `Birkly-Marketplace/internal/planning/reviews/P70-commerce-storefront-platform-plan.md`

## Problem

Site builders write custom JS to orchestrate purchase-option UI, amount validation, linked CMS entry creation, and hosted Stripe Checkout. Commerce already supports variable pricing, hosted checkout, and entry sync — but not declaratively from HTML + `commerce-storefront.js`.

## Goals

1. **`catalog_item` SSOT** — enriched `purchase_options` for storefront rendering and validation.
2. **Purchase option picker** — `data-commerce-purchase-options` binder (fixed, variable, one-time, recurring tiers).
3. **`begin_linked_checkout`** — server-side: validate product, optionally create linked entry, start hosted checkout with entry-sync metadata.
4. **Declarative binders** — `data-commerce-linked-checkout`, `data-commerce-confirm-return` (M4–M5).
5. **Remove site-specific orchestration** — e.g. birkly.io `donate.js` (M7).

## Non-goals (P70)

- Variable recurring amounts (custom monthly) — fixed recurring tiers only.
- Provider certification beyond existing Stripe/Mollie matrix.

## API: `catalog_item` enrichment

Each `purchase_options[]` item gains storefront fields:

| Field | Type | Meaning |
|-------|------|---------|
| `allows_custom_amount` | bool | `pricing_mode === variable` |
| `is_recurring` | bool | `billing === recurring` |
| `display_amount_cents` | int | Shelf price for UI (fixed or suggested variable) |
| `suggested_amount_cents` | int | Default for variable inputs |
| `min_price_cents` / `max_price_cents` | int\|null | Validation bounds |

## API: `begin_linked_checkout`

**Public action** (no admin auth). Request:

```json
{
  "action": "begin_linked_checkout",
  "product": {
    "collection": "donations",
    "entry_id": "support-birkly",
    "purchase_option_id": "once",
    "amount_cents": 1500
  },
  "customer": { "email": "a@example.com", "name": "Ada" },
  "linked_entry": {
    "collection": "supporters",
    "fields": { "title": "Ada", "email": "a@example.com", "featured": "1" },
    "consent_field": "featured"
  },
  "hosted_checkout": true,
  "success_url": "https://example.com/thank-you.html",
  "cancel_url": "https://example.com/donate.html?canceled=1"
}
```

**Response** (success):

```json
{
  "status": "ok",
  "data": {
    "redirect_url": "https://checkout.stripe.com/...",
    "order_id": "ord_...",
    "linked_entry_id": "abc123",
    "checkout_session_id": "cd_..."
  }
}
```

**Flow:**

1. Resolve catalog item (lazy-index if MCP write skipped hooks).
2. Validate `purchase_option_id` + `amount_cents` against schema.
3. If `linked_entry` present: create draft CMS row; build `entry_sync_meta` from `commerce_entry_sync_*` settings.
4. Clear cart → add line → set checkout draft → `checkout()` with `hosted_checkout`.

Entry sync on pay/abandon uses `CommerceEntrySync` (`CommerceDonorSync` remains a deprecated alias).

Optional file fields: `upload_linked_checkout_asset` (multipart) pre-uploads images; storefront binder merges returned URLs into `linked_entry.fields` before step 3.

## Storefront markup

```html
<form
  data-commerce-linked-checkout
  data-product-collection="donations"
  data-product-entry="support-birkly"
  data-linked-collection="supporters"
  data-hosted-checkout="1"
  data-success-url="/project/thank-you.html"
  data-cancel-url="/project/sponsors.html?canceled=1">
  <div data-commerce-purchase-options
       data-product-collection="donations"
       data-product-entry="support-birkly"></div>
  <input name="name" required>
  <input type="email" name="email" required>
  <label><input type="checkbox" name="featured" value="1"> Show on supporters wall</label>
  <button type="submit">Donate</button>
</form>
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
```

## Milestones

| ID | Deliverable |
|----|-------------|
| M0 | Plan + RFC |
| M1 | Catalog enrichment + `data-commerce-purchase-options` |
| M2 | `begin_linked_checkout` + tests |
| M3 | `data-commerce-linked-checkout` binder |
| M4 | `data-commerce-confirm-return` + abandon |
| M5 | Entry sync settings UI + order purge |
| M6 | Docs + birkly.io migration |
| M7 | Release + human notify |

## Verification

See P70 plan matrix V1–V8.
