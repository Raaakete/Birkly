# Catalog & inventory

Commerce separates **what you sell** (CMS entries → Catalog index) from **how much stock you have** (Inventory ledger).

**Who it's for:** merchants managing products and stock; operators rebuilding the index after bulk edits.

![Catalog vs Inventory](/plugins/commerce/assets/docs/catalog-vs-inventory.svg)

---

## Systems of record

| System | Role | Edit where |
|--------|------|------------|
| **CMS entry** | Name, copy, images, Commerce field (price, fulfillment, tax) | Collections → entry |
| **Catalog** | Indexed read model for cart/checkout | Auto on save; rebuild if stale |
| **Inventory** | Countable stock ledger (on hand / reserved / available) | Commerce → Inventory |
| **Orders** | Frozen money + line snapshots after pay | Commerce → Orders (read-mostly) |

> **Note:** Cart and checkout never read raw entry JSON for price/stock. They use the **Catalog** index. Inventory Available is projected onto catalog rows for countable SKUs.

---

## Merchant quick start

1. Create / publish a product entry with a Commerce field and optional **SKU** (defaults to slug).
2. Open **Commerce → Catalog** — confirm the sellable unit appears (rebuild if missing).
3. Open **Settings → General → Stock mode** — pick Unlimited / Simple / Locations.
4. If Simple or Locations: open **Inventory** → set **On hand** (+ location when needed).
5. Optional: set a **low threshold** for restock alerts.
6. Add to cart on the storefront — Available should reflect the ledger.

---

## Catalog tab

**Commerce → Catalog** lists sellable units (one row per parent product or variant).

| Action | When to use |
|--------|-------------|
| Browse / search | Find SKUs and projected availability |
| Open entry | Change price, title, fulfillment (edit in CMS) |
| **Rebuild index** | After imports, bulk file edits, or “item not in catalog” errors |

Admin / API actions: `list_catalog`, `reindex_catalog` / `rebuild_catalog`.

### What gets indexed

- Published entries (and variants) that have a Commerce field value
- Purchase options, fulfillment, tax_class, tax_included, SKU, weight
- Projected `quantity_available` from Inventory (or `null` when unlimited)

Catalog is a **checkout read model**. Edit names and pricing on the CMS entry; adjust countable stock in **Inventory**.

---

## Inventory tab

**Commerce → Inventory** is the ledger for countable stock.

| Concept | Meaning |
|---------|---------|
| **On hand** | Physical / countable units in stock |
| **Reserved** | Held by active carts / checkouts |
| **Available** | On hand − reserved (what Catalog shows) |
| **Low threshold** | Restock alert point → Automation `commerce_low_stock` |

### Stock modes

Set under **Settings → General → Stock mode**:

| Mode | Behavior | Best for |
|------|----------|----------|
| **Unlimited** | Ignores counts; catalog `quantity_available` is null; no reserve/commit | Services, memberships, pure digital |
| **Simple** | One ledger row per SKU | Single warehouse / simple shop |
| **Locations** | Per-SKU stock per warehouse; transfers supported | Multi-warehouse ops |

> **Note:** Digital (`deliver`), gift card, and `none` lines do **not** hold warehouse stock. `register` uses Available as **capacity**. `ship` lines with tracked SKUs reserve until pay or release.

### Day-to-day

1. Create / publish the product entry (SKU optional — defaults to slug).
2. Open **Inventory** → set on hand (Simple or Locations).
3. Set a **low threshold** if you want restock alerts.
4. After imports or manual JSON edits, run **Reconcile** / rebuild catalog so projections match.

Checkout behaviour:

- Add-to-cart checks availability when a countable SKU row exists.
- Checkout fails or warns if Available &lt; cart quantity.
- On `order.paid`, stock **decrements**.
- **Full refund** restores quantity (partial refunds may not restore in current builds).

API helpers: `save_stock_mode`, `reconcile_inventory`, `list_warehouse_stock`, `save_warehouse_stock`, `list_warehouses`, `save_warehouse`, `transfer_warehouse_stock`.

### Example ledger row (conceptual)

```json
{
  "sku": "COFFEE-250-WB",
  "quantity_on_hand": 42,
  "low_stock_threshold": 5
}
```

Available shown in Catalog ≈ on hand − reserved.

---

## Low stock

When Available drops to or below the threshold, Commerce emits Automation trigger **`commerce_low_stock`** with payload:

```json
{
  "sku": "COFFEE-250-WB",
  "on_hand": 4,
  "reserved": 0,
  "available": 4,
  "threshold": 5
}
```

- Debounced per SKU until stock recovers above the threshold.
- Import the Automation Commerce recipe pack for a ready-made alert workflow — [help-webhooks-automation.md](help-webhooks-automation.md).

Dashboard ops metrics also surface needs-shipping and SLA breaches (Settings → General → Fulfillment SLA hours).

---

## Variants and SKUs

| Setup | Catalog rows | Inventory rows |
|-------|--------------|----------------|
| Simple product | 1 (parent) | 1 SKU |
| Parent + variant sub-entries | 1 per variant | 1 per variant SKU |

Always set **distinct SKUs** on variants when using Locations mode.

Templates must buy the **variant** id — [help-templating.md](help-templating.md).

---

## Inventory webhooks (optional)

For real-time stock from Shopify/Woo while you still sync products externally:

1. Save a live connection under Settings → Import & migrate.
2. Copy webhook URL + signing secret.
3. Register `inventory_levels/update` (Shopify) or product updated (Woo) at the external platform.
4. Matching **SKU** updates catalog + warehouse on hand.

Unsigned HMAC requests are rejected. Details: [help-webhooks-automation.md](help-webhooks-automation.md).

---

## Advanced notes

- Orders do **not** re-read current inventory for historical totals — only for remaining ship qty / cancel restore.
- Unlimited mode is the right default for services, memberships, and pure digital catalogs.
- After Shopify cutover, verify stock mode and rebuild catalog — [help-shopify-cutover.md](help-shopify-cutover.md).
- Store path (advanced): `data/plugins/commerce/warehouse_stock.json`.

## Related

- [Fieldtype](help-fieldtype.md)
- [Orders & customers](help-orders-customers.md)
- [Fulfillment](help-fulfillment.md)
- [Webhooks & Automation](help-webhooks-automation.md)
- [Troubleshooting](help-troubleshooting.md) — “stock shows unlimited”
