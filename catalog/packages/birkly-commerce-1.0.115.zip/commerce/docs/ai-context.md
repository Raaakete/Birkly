# Commerce — AI context (Birkly P6.5 v2)

Content-first commerce plugin: payment providers, catalog, cart, checkout, orders, discounts, import, fulfillment.

## MCP tools (when plugin active)

Inbound MCP exposes `commerce_*` tools — see `docs/mcp-tools.md`. Prefer `commerce_list_catalog`, `commerce_list_orders`, etc. over guessing REST payloads. For full admin parity (emails, invoices, fulfillment, inventory, tax, shipping, discounts, import, mappings, draft orders, analytics), use `commerce_list_admin_actions` and `commerce_admin_action`.

## Content model (two independent axes)

1. **fulfillment** — what happens after payment: `ship` | `deliver` | `register` | `none`
2. **purchase_options[]** — one or more ways to pay on the same sellable unit:
   `{ id, label, billing: one_time|recurring, price_cents, currency, interval? }`

Billing is **not** coupled to fulfillment. Example: coffee ships (`ship`) with both one-time and recurring purchase options on the same variant.

## Variants

- Parent entry = marketing content (title, ContentEditor, gallery)
- Sub-collection `variants` = sellable SKUs; each variant sub-entry has its own commerce field
- Catalog indexes **one row per sellable unit** (variant sub-entry OR parent if no variants)
- Templates buy via variant sub-entry id/slug: `{commerce_buy_url variant_id collection qty}`

## Commerce fieldtype (v2 stored value)

```json
{
  "fulfillment": "ship",
  "purchase_options": [
    { "id": "buy_once", "label": "One-time", "billing": "one_time", "price_cents": 1499, "currency": "eur" },
    { "id": "subscribe", "label": "Subscribe", "billing": "recurring", "interval": "month", "price_cents": 1299, "currency": "eur" }
  ],
  "quantity_available": null,
  "sku": "SKU-250G-WB"
}
```

Conditional panels by fulfillment:
- **ship** — `weight_grams` (required for EasyPost live rates), optional `length_mm`/`width_mm`/`height_mm`, shipping address at checkout
- **Settings → Shipping:** provider `manual` | `easypost` (`commerce_shipping_rate_provider`); zones remain for Manual + fallback
- **deliver** — digital asset URL/file, signed download token after payment
- **register** — uses `quantity_available` as capacity; attendee name at checkout
- **none** — purchase mappings / automation only (e.g. recurring membership)

Collection field config: choose a saved **fieldtype profile** (`commerce`, `commerce_events`, …). Manage profiles in **Commerce admin → Fieldtypes** (intervals, custom fields, fulfillment presets) — not in the collection editor.

## PostPurchaseRouter

Single router class switches on fulfillment after successful payment (idempotent on order_id + line_id):

| fulfillment | Action |
|-------------|--------|
| ship | Fulfillment adapter (Manual or EasyPost) + `commerce_physical_fulfilled`; EasyPost `create_shipment` push + tracking webhook (`commerce_tracking_updated`) |
| deliver | DigitalDeliveryStore signed token + `commerce_digital_delivered` |
| register | EventRegistrationStore, capacity decrement + `commerce_event_registered` |
| none | Purchase mappings; `commerce_membership_started` when recurring |

Order lines snapshot commerce value + `purchase_option_id` at checkout.

## Admin (Commerce page)

Tabs: Connections, Catalog, Orders, **Subscriptions**, Discounts, Import, Mappings, Fulfillment, **Tax**, Activity, Settings. Shipping zones v1 for flat-rate shipping.

## Draft orders / Quotes (P2-M5)

- **Orders → Draft orders:** create from scratch (no cart) or from cart; line picker via catalog search; qty + optional unit price override; preview shipping/tax; save + accept link; optional merchant-assisted `draft_order_checkout`
- Backing store: `CommerceQuoteStore` (`draft_order: true`); statuses remain `quote` → `pending_payment` → `paid`
- Admin API: `draft_order_create`, `draft_order_update`, `draft_order_preview`, `draft_order_get`, `draft_order_search_catalog`, `draft_order_checkout`

## Tax (P8 / P1-M5 / P2-M1 / P2-M4)

- **Settings → Tax:** provider select (`manual` | `stripe_tax`), default rate, country→rate map, tax classes, class×country rates, **B2B reverse charge**
- Setting `commerce_tax_provider` (default `manual`); Stripe Tax uses Stripe secret from Connections for calculation only (any charge PSP allowed)
- Commerce field `tax_class` (default `standard`); Manual resolution: class×country → class default → country → default
- Checkout resolves `TaxProviderInterface` and emits `tax_lines[]`; order stores frozen `tax_cents` / `tax_lines` (never re-calls provider for paid orders)
- **B2B VAT (P2-M4):** checkout accepts `vat_id` / `tax_id`; persisted on the order. When reverse charge is enabled and customer + merchant countries are both in the eligible list (default EU), customer ≠ merchant (configurable), and a VAT ID is present → zero-rate `tax_lines` with `reason: reverse_charge`. Format normalize only — **live VIES is future work**. Stripe Tax mock reuses Manual reverse-charge logic.

## Refunds (P8)

- Order detail → Refund (full or partial amount in cents)
- Executes via active payment provider on `commerce_shelf`

## Subscriptions (P8)

- Created when checkout completes a `billing: recurring` purchase_option
- Admin **Subscriptions** tab: list, detail, cancel
- Provider webhooks update status (`active`, `past_due`, `canceled`)
- Out of scope: plan upgrades, dunning automation

## Order email automation (P8)

On `order_paid`, Commerce enqueues:

| Trigger | Typical use |
|---------|-------------|
| `commerce_order_receipt` | Customer receipt email |
| `commerce_order_admin_notify` | Staff notification |

Configure workflows in Admin → Automation using these trigger types.

## Automation recipe pack (P54 P3-M3)

The Automation plugin ships a Commerce recipe pack (`recipes/commerce/`) importable from Admin → Automation:

| Recipe | Trigger |
|--------|---------|
| Post-purchase receipt | `commerce_order_paid` |
| Subscription dunning | `commerce_subscription_payment_failed` |
| Low stock alert | `commerce_low_stock` |
| Order shipped / fulfilled | `commerce_order_shipped` |

Merchants import disabled workflows, set addresses, then enable. See Automation plugin `recipes/README.md`.

### Ops intelligence (P3-M4)

- Dashboard `analytics_summary` adds: `new_customers`, `returning_customers`, `cohorts[]`, `needs_shipping_count`, `avg_fulfillment_hours`, `sla_breach_count`, `fulfillment_sla_hours`
- Setting `commerce_fulfillment_sla_hours` (default 48) — paid ship orders with remaining qty older than this are SLA breaches
- Automation trigger `commerce_low_stock` — payload `{ sku, on_hand, reserved, available, threshold }`; debounced per SKU until stock recovers above threshold (`CommerceLowStockService`)

## Shelf services

- `commerce_shelf` — primary payment/catalog API
- `payment_shelf` — legacy alias (same instance)

## Cart / checkout contract (integrators)

- Route: `/api/index.php?route=commerce`
- Public actions include `get`, `add`, `update`, `remove`, `clear`, `checkout`, `storefront_config`
- Cart payload includes `checkout_allowed`, `split_required`, `groups[]`, `error`
- Mixed billing modes → **split checkout** (sequential `group_key` payments, reuse `checkout_session_id`)
- Mixed fulfillments (`ship`+`deliver`+`register`) stay in the **one-time** group; `subscribe`/recurring is a later group — see `docs/help-hybrid-cart.md`
- Recurring is **enabled by default**; disable only via `COMMERCE_ENABLE_RECURRING_BILLING=0` / `COMMERCE_DISABLE_RECURRING_BILLING=1`
- Prefer plugin script `/plugins/commerce/assets/commerce-storefront.js` over custom cart engines (`continueSplitCheckout`, `cartNeedsShipping`, `cartNeedsAttendee`)

## Template functions

| Function | Purpose |
|----------|---------|
| `{commerce_cart_count}` | Items in session cart |
| `{commerce_cart_url}` | Cart API URL |
| `{commerce_buy_url entry_id collection qty}` | Checkout/add URL for sellable unit |
| `{commerce_add_to_cart entry_id collection qty}` | Alias for buy URL |
| `{commerce_price_from entry_id collection}` | Lowest price display ("from €X") |

## Scenarios

- **Yoga class** — `register`, one purchase_option, capacity 20, attendee at checkout
- **Coffee** — variant sub-entries, `ship`, dual purchase_options (buy + subscribe)
- **Course** — `deliver`, one_time, download token
- **Community** — `none`, recurring, purchase mapping → user tier

## Coexistence

Legacy `shopping_cart` and `events` plugins remain; new sites use Commerce fieldtype + content model only.

## Public API

`/api/index.php?route=commerce` — cart actions: get, add, update, remove, checkout. Checkout selects purchase_option; collects shipping/attendee per line fulfillment.
