# Subscriptions

Recurring purchase options create Commerce subscriptions when checkout completes a `billing: recurring` line.

**Who it's for:** merchants selling memberships or subscribe-and-save; admins handling failed renewals; developers calling subscription APIs.

---

## Merchant quick start

1. On the product Commerce field, add a purchase option with **billing = recurring** and an interval (`month`, `year`, or a custom profile interval like `2_weeks`).
2. Publish the product; confirm it appears in **Catalog**.
3. Place a **sandbox** checkout with that option selected.
4. Open **Commerce → Subscriptions** — you should see status **active**.
5. Optional: map memberships under **Settings → Mappings** when fulfillment is `none` / access.

```json
{
  "id": "sub",
  "label": "Subscribe monthly",
  "billing": "recurring",
  "interval": "month",
  "pricing_mode": "fixed",
  "price_cents": 1299,
  "currency": "eur"
}
```

Example: **€12.99 / month** coffee club or yoga membership.

### Fulfillment is independent

| Product | Fulfillment | Billing |
|---------|-------------|---------|
| Coffee bag subscribe-and-save | `ship` | `recurring` / `month` |
| Digital magazine | `deliver` | `recurring` / `month` |
| Yoga membership | `none` + Mappings | `recurring` / `month` |

Recurring billing is **enabled by default**. Disable only via env: `COMMERCE_ENABLE_RECURRING_BILLING=0` or `COMMERCE_DISABLE_RECURRING_BILLING=1`.

Checkout with mixed one-time + recurring lines uses **split checkout** — [help-hybrid-cart.md](help-hybrid-cart.md). Gift cards and coupons apply to the **one-time** group only and do **not** re-apply on renewals.

![Hybrid cart split](/plugins/commerce/assets/docs/hybrid-cart.svg)

---

## Subscriptions tab

**Commerce → Subscriptions** lists lifecycle state.

| Status | Meaning | What you can do |
|--------|---------|-----------------|
| `active` | Renewing normally | Upgrade / cancel |
| `past_due` | Renewal payment failed; dunning in progress | **Retry payment**, upgrade, cancel |
| `canceled` | Ended | View history only |

### Admin actions (click a row → detail)

| Action | When | Notes |
|--------|------|-------|
| **View detail** | Always | Customer, plan, invoices, dunning metadata |
| **Retry payment** | `past_due` only | Retries via provider (`retry_subscription_payment`) |
| **Cancel** | Active / past_due | Ends subscription at provider + local status |
| **Change plan / Upgrade** | Same catalog entry | Pick another recurring purchase option |

> **Note:** You cannot move a subscription to a **different product** in one step — cancel and create a new subscription instead. Upgrades stay on the **same catalog entry** (e.g. monthly → annual).

---

## Changing a plan (upgrade / downgrade)

1. Open the subscription detail.
2. Under **Change plan**, pick a new recurring option from the dropdown.
3. Click **Upgrade**.
4. The provider updates the subscription; status and next billing date refresh after confirmation.

Same-plan requests are rejected; canceled subscriptions cannot upgrade.

---

## Dunning (failed renewals)

When a renewal fails:

1. Status → `past_due`; `dunning.attempt_count` increments.
2. Automation trigger **`commerce_subscription_payment_failed`** (and related past-due events).
3. Enable the **Subscription payment failed / dunning** template under **Settings → Emails** (and/or Automation `commerce_subscription_payment_failed`).
4. On recovery → `commerce_subscription_recovered` / renewed triggers; dunning cleared.

| Setting | Purpose |
|---------|---------|
| Send dunning email on payment failure | Toggle built-in mailer |
| Subject / body | Placeholders: `{subscription_id}`, `{customer_email}`, `{amount}`, `{interval}`, `{attempt_count}` |

> **Note:** Prefer Automation workflows for branded dunning. The built-in email is a simple fallback. Import the Automation Commerce recipe **“Subscription dunning”**.

### Recovering

- Wait for the provider retry, **or**
- Click **Retry payment** on the past-due row, **or**
- Ask the customer to update their payment method at the provider (Stripe Customer Portal / etc., depending on connection).

---

## Memberships

For access products:

1. Fulfillment `none` (or `register` when capacity matters).
2. Recurring purchase option.
3. **Settings → Mappings** → product → User Management tier.
4. PostPurchaseRouter emits `commerce_membership_started` on pay.

Requires the **User Management** plugin for tier grants.

---

## Developer API

Admin session (`route=commerce`):

| Action | Body / notes |
|--------|----------------|
| `list_subscriptions` | All subscriptions |
| `get_subscription` | `{ id }` |
| `list_subscription_upgrade_options` | Eligible recurring options on same entry |
| `upgrade_subscription` | `{ id, purchase_option_id }` |
| `cancel_subscription` | Cancel + provider sync when available |
| `retry_subscription_payment` | Manual retry on `past_due` |

### Record shape (conceptual)

Stored under `data/plugins/commerce/subscriptions/` as JSON:

| Field | Notes |
|-------|-------|
| `status` | `active`, `past_due`, `canceled` |
| `purchase_option_id` | Recurring option on the catalog line |
| `provider_subscription_id` | Stripe/Mollie subscription id |
| `dunning` | `{ attempt_count, last_failed_at, last_invoice_id }` when past due |
| `upgraded_at` | Set after successful plan change |

### Automation triggers

| Trigger | When |
|---------|------|
| `commerce_subscription_payment_failed` | Invoice/payment failed; subscription `past_due` |
| `commerce_subscription_past_due` | Entered past-due state |
| `commerce_subscription_recovered` | Payment succeeds after failure |
| `commerce_subscription_renewed` | Successful renewal |
| `commerce_subscription_canceled` | Canceled |
| `commerce_subscription_upgraded` | Plan change succeeded |

Provider webhooks (`invoice.payment_failed`, recovery events) update status via `CommerceSubscriptionService`. Full trigger list: [help-webhooks-automation.md](help-webhooks-automation.md).

---

## Advanced notes

- Subscriptions store provider references; refunds of the original order do **not** always cancel the subscription — cancel explicitly when needed.
- Plan upgrades use `SubscriptionUpgradeService` for eligible `active` / `past_due` subs.
- Customer profiles show subscription timeline — [help-orders-customers.md](help-orders-customers.md).

## Related

- [Fieldtype — purchase options](help-fieldtype.md)
- [Hybrid cart](help-hybrid-cart.md)
- [Promotions](help-promotions.md) — coupons do not re-apply on renewals
- [Webhooks & Automation](help-webhooks-automation.md)
- [Developer API](help-developer.md)
