# Tax

Commerce tax is configured under **Settings → Tax**, while each product stores **Price tax mode** and **tax class** on its Commerce field.

**Who it's for:** merchants selling in VAT/GST regions; developers reading cart money fields.

![Tax included vs excluded](/plugins/commerce/assets/docs/tax-modes.svg)

---

## Merchant quick start

1. Open **Commerce → Settings → Tax**.
2. Leave **Tax provider** on **Manual** (or choose **Stripe Tax** if you use Stripe Tax Calculations).
3. Check **Enable tax at checkout**.
4. Set a **default rate** (e.g. `19` for 19% VAT) and optional country overrides.
5. On each product’s Commerce field, set **Price tax mode** (usually **Tax included in price** for EU) and **Tax class**.
6. Save, add a product to cart with a shipping/billing country, and confirm the money rows look right.

> **Note:** Do **not** look for Price tax mode under Settings. It lives on the **entry’s Commerce field**. Settings → Tax only holds rates and provider choice. See [help-fieldtype.md](help-fieldtype.md).

---

## Providers

| Provider | Setting | Behavior |
|----------|---------|----------|
| **Manual** (default) | `commerce_tax_provider: manual` | Rate table: class×country → class default → country → default |
| **Stripe Tax** | `commerce_tax_provider: stripe_tax` | Calculation via Stripe Tax API using the Stripe secret from Connections |

> **Note:** Tax provider is **orthogonal** to the payment provider. You can charge with Mollie and still calculate with Stripe Tax (when configured).

Stripe Tax uses the Stripe **secret key** from **Settings → Connections** for calculation only. Charge PSP can be any configured provider.

---

## Tax included (EU default)

Each sellable unit has `tax_included` on the Commerce field (admin label: **Price tax mode**).

| Mode | UI label | Shelf `price_cents` | Checkout |
|------|----------|---------------------|----------|
| Included (default) | Tax included in price | Gross (already contains VAT) | Extracts tax for display; `tax_add_cents` = `0` |
| Exclusive | Tax excluded (added at checkout) | Net | Adds tax; `tax_add_cents` = tax amount |

Default when omitted: **`tax_included: true`** (EU-style).

### Concrete EUR example

Product shelf price **€14.99** (`price_cents: 1499`), class `standard`, rate **19%**, country `DE`.

| Price tax mode | What the customer sees | Charge math |
|----------------|------------------------|-------------|
| **Included** | Shelf €14.99; label “Tax (included)” ~€2.39 | Goods stay 1499; `tax_add_cents` = 0 |
| **Excluded** | Shelf €14.99 + tax ~€2.85 | `tax_add_cents` ≈ 285; total rises |

**Manual formulas (per line, post-discount base):**

- Inclusive: `tax = round(gross × r / (100 + r))`
- Exclusive: `tax = round(net × r / 100)`

---

## Tax classes

| Class | Typical use |
|-------|-------------|
| `standard` | Default VAT/GST |
| `reduced` | Reduced rate goods |
| `zero` | Zero-rated |
| custom | e.g. `books` — define rates in Settings → Tax |

### Manual resolution order (per line)

1. **Class × country** (e.g. reduced × DE = 7%)  
2. **Class default**  
3. **Country override**  
4. **Site default**

Leave a class default blank to inherit; use `0` for explicit zero-rated.

Mixed carts emit **one tax line per class×mode** on the paid order.

---

## Cart money fields

| Field | Meaning |
|-------|---------|
| `tax_cents` | Calculated tax for the quote (breakdown / reporting) |
| `tax_add_cents` | Cents **added to the charge** for exclusive tax; `0` when prices include tax; may be **negative** when reverse charge strips embedded VAT |
| `tax_included` / `prices_include_tax` | Cart-level flags when shelf prices include tax |
| `tax_lines[]` | Frozen on the order after pay (`rate`, `tax_cents`, `tax_class`, `reason?`) |

### Storefront display rules

1. If `prices_include_tax` — label tax as **Tax (included)**; do **not** add `tax_cents` on top of subtotal for the customer-facing total.
2. If exclusive — show tax as an add-on; `total` includes `tax_add_cents`.
3. Prefer `BirklyCommerce.renderMoneyRows(cart)` so labels stay correct.

```js
const cart = await BirklyCommerce.getCart();
// Prefer tax_add_cents for charge delta
BirklyCommerce.renderMoneyRows(cart);
```

`catalog_item` also returns a tax **estimate** for product pages (`net_cents` / `tax_cents` / `gross_cents`, optional `?country=`).

---

## B2B reverse charge

When reverse charge is enabled in Settings → Tax:

1. Checkout sends `vat_id` / `tax_id` (also persisted on the order).
2. Customer country and merchant country are both in the eligible list (default EU).
3. Customer country ≠ merchant country (configurable; default on).
4. A VAT ID is present.

Then tax lines are zero-rated with `reason: reverse_charge`.

| Price mode | Reverse charge effect |
|------------|----------------------|
| Exclusive | No tax add (`tax_add_cents` ≈ 0) |
| Inclusive | Embedded VAT is **stripped** (`tax_add_cents` negative) so B2B pays net |

### Settings shape (`tax_rules.b2b_reverse_charge`)

| Key | Meaning |
|-----|---------|
| `enabled` | Toggle reverse charge |
| `merchant_country` | Merchant ISO country (e.g. `DE`) |
| `eligible_countries` | List of ISO codes (default EU-style set) |
| `require_different_country` | Default `true` |

> **Note:** VAT ID is **format-normalized** only today. Live VIES validation is future work — merchants remain responsible for validating EU VAT numbers. OSS/IOSS automation is out of scope for this release.

### Checkout draft with VAT ID

```js
await BirklyCommerce.setCheckoutDraft({
  email: 'ap@acme.eu',
  vat_id: 'DE123456789',
  shipping_address: { country: 'FR', /* … */ }
});
```

---

## Orders & invoices

Paid orders store frozen `tax_cents` / `tax_lines`. Commerce does **not** re-call the tax provider for historical orders when you change rates later.

Invoice templates can show tax/reverse-charge notes from **Settings → Invoices** (company profile). Birkly provides tools and presets — **not legal advice**.

---

## Common mistakes

| Symptom | Fix |
|---------|-----|
| Tax added twice on EU prices | Set **Price tax mode** to included on the product; use `renderMoneyRows` |
| Wrong rate for DE reduced | Add class×country override; set product `tax_class` |
| Stripe Tax not calculating | Ensure Stripe secret exists under Connections; tax provider = `stripe_tax` |
| Reverse charge not applying | VAT ID + eligible countries + different-country rule |
| Old order totals changed | They shouldn’t — paid orders freeze tax; check you are viewing a new order |

---

## Related

- [Fieldtype — Price tax mode](help-fieldtype.md)
- [Storefront — money fields](help-storefront.md)
- [Troubleshooting — tax double-add](help-troubleshooting.md)
- [Settings reference](help-settings-reference.md)
