# Fulfillment

After payment, **PostPurchaseRouter** runs per order line based on fulfillment type. Operators work the open queue in **Commerce → Fulfillment**.

**Who it's for:** warehouse / ops staff and merchants configuring adapters.

![Fulfillment desk queue](/plugins/commerce/assets/docs/fulfillment-queue.svg)

---

## Merchant quick start (ship a paid order)

1. Confirm the product’s Commerce field uses fulfillment **`ship`**.
2. Open **Commerce → Settings → Fulfillment** → leave **Manual / Export** (or choose EasyPost).
3. After a paid test order, open **Commerce → Fulfillment** (or the order detail).
4. **Create shipment** — select lines/qty (partial OK), enter tracking if Manual, optionally notify customer.
5. Print **packing slip** (browser Print → Save as PDF).

Dashboard **SLA breaches** use **Settings → General → Fulfillment SLA (hours)** (default **48**): paid ship orders older than this with remaining unshipped qty.

---

## Fulfillment types

| Type | After payment | Ops surface |
|------|---------------|-------------|
| `ship` | Order enters shipping queue; adapter may create tracker/label | Fulfillment desk, shipments, packing slips |
| `deliver` | Secure download token issued | Order detail / customer email |
| `register` | Attendee recorded; capacity committed | Fulfillment (Register) + Events → Attendees |
| `gift_card` | Store-credit codes issued (face value = unit price) | Gift Cards tab; Automation `commerce_gift_card_issued` |
| `none` | Purchase mappings / Automation only (memberships) | Subscriptions + User Management |

Router is **idempotent** on `order_id` + `line_id`.

Only lines with `fulfillment: ship` are shippable. Digital, register, gift_card, and none lines use PostPurchaseRouter instead of the packing desk.

---

## Fulfillment desk

**Commerce → Fulfillment** shows:

| Section | Contents |
|---------|----------|
| Open queue | Paid ship (and related) lines needing action |
| History | Who packed / shipped; tracking updates |
| Filters | Needs shipping, SLA breaches, search |

### Create a shipment

1. Open the order (from Orders or Fulfillment).
2. **Create shipment** — select lines/qty (partial and multi-package supported).
3. Enter tracking if Manual; EasyPost may push and return tracker data.
4. Optional **package count** (≥ 1).
5. Notify customer (triggers `commerce_shipment_created` / `commerce_order_shipped` / `commerce_tracking_updated` as applicable).
6. Print **packing slip**.

Line status moves **unfulfilled → partial → shipped** as quantities ship.

API: `list_fulfillment_desk`, `create_shipment`, `update_order_shipment`, `bulk_mark_shipped`, `packing_slips`.

### Example `create_shipment` body

```json
{
  "action": "create_shipment",
  "order_id": "ord_…",
  "items": [{ "line_id": "line_1", "quantity": 1 }],
  "tracking_number": "1Z999…",
  "carrier": "ups",
  "package_count": 1,
  "notify_customer": true
}
```

Order shape: `shipments[]` with `id`, `items`, `package_count`, tracking/carrier, `notify_customer`; EasyPost may add `source: easypost`, `easypost_tracker_id`. Lines track `quantity_shipped` and `fulfillment_status`.

---

## Adapters (Settings → Fulfillment)

| Adapter | Behavior |
|---------|----------|
| **Manual / Export** (default) | Export/CSV-style ops; enter tracking yourself |
| **EasyPost** | Live `pushOrder` on shipment create + tracking webhook |

> **Note:** EasyPost reuses the API key from **Settings → Shipping**. ShipStation remains an internal stub and is **not** offered in the UI.

### EasyPost setup

1. Save the API key under **Settings → Shipping**.
2. Set **Active adapter** to **EasyPost** under Settings → Fulfillment.
3. Optionally set a **webhook secret** and copy the webhook URL shown in the panel.
4. Point EasyPost tracker events at the Commerce webhook URL with `platform=easypost`.

When EasyPost is active, creating a shipment triggers EasyPost push; tracking webhooks update the order and emit `commerce_tracking_updated`.

Public webhook endpoint: `api/commerce_webhooks.php?platform=easypost` — see [help-webhooks-automation.md](help-webhooks-automation.md).

---

## Packing slips & invoices

| Document | Where |
|----------|-------|
| Packing slip | Order / Fulfillment → packing slip popup (print) |
| Invoice | Order → invoice; templates under Settings → Invoices |

Invoice company profile (logo, tax note, disclaimer) feeds `{{tokens}}`. You own legal wording — Birkly provides presets, not legal advice.

Allow pop-ups if the packing-slip window is blocked.

---

## Deliver / register / gift card / none

| Type | Operator notes |
|------|----------------|
| **Deliver** | Buyer gets download link; cancel before ship-equivalent revokes token |
| **Register** | Capacity from Inventory Available; attendee name at checkout |
| **Gift card** | Codes appear under Gift Cards; no warehouse pick |
| **None** | Confirm Settings → Mappings for membership tiers |

Cancel vs refund rules (unshipped only for cancel): [help-orders-customers.md](help-orders-customers.md).

---

## Automation triggers

| Trigger | Typical use |
|---------|-------------|
| `commerce_physical_fulfilled` | Internal / ERP |
| `commerce_shipment_created` | Pack notify |
| `commerce_order_shipped` | Shipped email (when notify enabled) |
| `commerce_tracking_updated` | Tracking email |
| `commerce_digital_delivered` | Download ready |
| `commerce_event_registered` | Ticket confirm |
| `commerce_gift_card_issued` | Code delivery |
| `commerce_membership_started` | Welcome / tier |

Import the Automation Commerce recipe pack for ready-made shipped / receipt flows — [help-webhooks-automation.md](help-webhooks-automation.md).

---

## Common mistakes

| Symptom | Fix |
|---------|-----|
| Order never in Fulfillment queue | Product must be `fulfillment: ship` and **paid** |
| EasyPost push fails | API key on Shipping panel; weight on product |
| No tracking emails | Enable notify on shipment + Automation recipe / SMTP |
| SLA breach noise | Tune Settings → General → Fulfillment SLA hours |
| Trying to cancel after ship | Use refund / return — cancel blocked once shipped |

---

## Related

- [Shipping](help-shipping.md)
- [Orders & customers](help-orders-customers.md)
- [Hybrid cart](help-hybrid-cart.md)
- [Webhooks & Automation](help-webhooks-automation.md)
- [Overview](help-overview.md)
