<?php
/**
 * Commerce plugin MCP tools — registered when the plugin is active.
 *
 * Docs: docs/mcp-tools.md · read_birkly_docs topic commerce
 */

declare(strict_types=1);

require_once __DIR__ . '/../init.php';
require_once dirname(__DIR__) . '/includes/CommerceMcpAdmin.php';

function commerce_mcp_user_can(array $aiUser, string $capability): bool
{
    $role = (string) ($aiUser['role'] ?? '');
    if (in_array($role, ['admin', 'superadmin'], true)) {
        return true;
    }

    if (function_exists('checkPermission')) {
        if (checkPermission($aiUser, 'manage_commerce') || checkPermission($aiUser, $capability)) {
            return true;
        }
    }

    $caps = $aiUser['plugin_capabilities']['commerce'] ?? $aiUser['capabilities'] ?? [];
    if (!is_array($caps)) {
        return false;
    }

    if (in_array('manage_commerce', $caps, true) || in_array('manage_payments', $caps, true)) {
        return true;
    }

    return in_array($capability, $caps, true);
}

/** @return array{status: string, message?: string}|null */
function commerce_mcp_require(array $aiUser, string $capability): ?array
{
    if (!commerce_mcp_user_can($aiUser, $capability)) {
        return ['status' => 'error', 'message' => 'Permission denied for Commerce action (requires ' . $capability . ')'];
    }
    return null;
}

/** @param list<string> $capabilities @return array{status: string, message?: string}|null */
function commerce_mcp_require_any(array $aiUser, array $capabilities): ?array
{
    foreach ($capabilities as $capability) {
        if (commerce_mcp_user_can($aiUser, $capability)) {
            return null;
        }
    }
    return [
        'status' => 'error',
        'message' => 'Permission denied for Commerce action (requires one of: ' . implode(', ', $capabilities) . ')',
    ];
}

function commerce_mcp_bootstrap_services(): void
{
    if (!commerce_plugin_active()) {
        throw new RuntimeException('Commerce plugin is not active');
    }
    commerce_bootstrap();
    commerce_bootstrap_cart_services();
}

function commerce_mcp_schema_object(array $properties = [], array $required = []): array
{
    $schema = ['type' => 'object', 'properties' => $properties];
    if ($required !== []) {
        $schema['required'] = $required;
    }
    return $schema;
}

/** @return array<string, array> */
function commerce_mcp_tool_registry(): array
{
    $id = ['type' => 'string', 'description' => 'Resource ID'];
    $limit = ['type' => 'number', 'description' => 'Max rows to return'];

    return [
        'commerce_list_orders' => [
            'description' => 'List commerce orders (newest first). Reconciles pending payments. Requires Commerce plugin active.',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'read'],
            'inputSchema' => commerce_mcp_schema_object([
                'include_abandoned' => ['type' => 'boolean', 'description' => 'Include abandoned checkouts'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'view_commerce_orders')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $orders = new CommerceOrderStore();
                $catalog = new CommerceCatalog();
                $cart = new CommerceCartSession();
                $checkout = new CommerceCheckoutService($orders, $catalog, $cart);
                require_once dirname(__DIR__) . '/includes/CommerceOrderOps.php';
                $orderOps = new CommerceOrderOps($orders, new CommerceSubscriptionStore());
                $reconcile = $checkout->reconcilePendingPayments(50);
                $orders->ensureOrderNumbers();
                $all = $orders->listAll();
                if (empty($arguments['include_abandoned'])) {
                    $all = array_values(array_filter($all, static fn ($o) => ($o['status'] ?? '') !== 'abandoned'));
                }
                return [
                    'status' => 'ok',
                    'data' => [
                        'orders' => array_map(static fn ($o) => $orderOps->enrichOrder($o), $all),
                        'reconcile' => $reconcile,
                    ],
                ];
            },
        ],
        'commerce_get_order' => [
            'description' => 'Get one commerce order by id with enriched shipment/subscription context.',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'read'],
            'inputSchema' => commerce_mcp_schema_object(['id' => $id], ['id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'view_commerce_orders')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $orders = new CommerceOrderStore();
                require_once dirname(__DIR__) . '/includes/CommerceOrderOps.php';
                $orderOps = new CommerceOrderOps($orders, new CommerceSubscriptionStore());
                $id = (string) ($arguments['id'] ?? '');
                $order = $orders->get($id);
                if (!$order) {
                    return ['status' => 'error', 'message' => 'Order not found'];
                }
                if (empty($order['order_number'])) {
                    $number = $orders->allocateOrderNumber($order['created_at'] ?? null);
                    $order = $orders->update($id, ['order_number' => $number]) ?? $order;
                }
                return ['status' => 'ok', 'data' => ['order' => $orderOps->enrichOrder($order)]];
            },
        ],
        'commerce_list_customers' => [
            'description' => 'List commerce customers; optional search by email or name substring.',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'read'],
            'inputSchema' => commerce_mcp_schema_object([
                'search' => ['type' => 'string', 'description' => 'Filter by email or name'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'view_commerce_orders')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $customers = new CommerceCustomerStore();
                $orders = new CommerceOrderStore();
                $backfill = [];
                if ($customers->count() === 0) {
                    $backfill = $customers->backfillFromOrders($orders, false);
                }
                return [
                    'status' => 'ok',
                    'data' => [
                        'customers' => $customers->list((string) ($arguments['search'] ?? '')),
                        'backfill' => $backfill,
                    ],
                ];
            },
        ],
        'commerce_get_customer' => [
            'description' => 'Get a commerce customer by id or email with order timeline.',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'read'],
            'inputSchema' => commerce_mcp_schema_object([
                'id' => ['type' => 'string'],
                'email' => ['type' => 'string'],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'view_commerce_orders')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $customers = new CommerceCustomerStore();
                $orders = new CommerceOrderStore();
                require_once dirname(__DIR__) . '/includes/CommerceOrderOps.php';
                $orderOps = new CommerceOrderOps($orders, new CommerceSubscriptionStore());
                $id = (string) ($arguments['id'] ?? '');
                $email = (string) ($arguments['email'] ?? '');
                $customer = $id !== '' ? $customers->getById($id) : null;
                if (!$customer && $email !== '') {
                    $customer = $customers->getByEmail($email);
                }
                if (!$customer) {
                    return ['status' => 'error', 'message' => 'Customer not found'];
                }
                $timeline = $orderOps->customerTimeline((string) $customer['email'], $customers);
                $timeline['orders'] = array_map(
                    static fn ($o) => $orderOps->enrichOrder($o),
                    $timeline['orders'] ?? []
                );
                return ['status' => 'ok', 'data' => ['customer' => $customer, 'timeline' => $timeline]];
            },
        ],
        'commerce_list_catalog' => [
            'description' => 'List indexed sellable catalog items (products, variants, purchase options).',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'view_commerce_stats', 'read'],
            'inputSchema' => commerce_mcp_schema_object([
                'filters' => ['type' => 'object', 'description' => 'Optional catalog filters', 'additionalProperties' => true],
            ]),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require_any($aiUser, ['manage_commerce', 'view_commerce_orders', 'view_commerce_stats'])) {
                    return $err;
                }
                return commerce_mcp_dispatch_admin('list_catalog', $arguments, $aiUser);
            },
        ],
        'commerce_storefront_config' => [
            'description' => 'Read commerce storefront config: currency, tax flags, public API actions, script paths.',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'view_commerce_stats', 'read'],
            'inputSchema' => commerce_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require_any($aiUser, ['manage_commerce', 'view_commerce_orders', 'view_commerce_stats'])) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $catalog = new CommerceCatalog();
                $taxRules = $catalog->loadTaxRules();
                $b2b = is_array($taxRules['b2b_reverse_charge'] ?? null) ? $taxRules['b2b_reverse_charge'] : [];
                $pluginJson = [];
                $pluginJsonPath = dirname(__DIR__) . '/plugin.json';
                if (is_file($pluginJsonPath)) {
                    $decoded = json_decode((string) file_get_contents($pluginJsonPath), true);
                    if (is_array($decoded)) {
                        $pluginJson = $decoded;
                    }
                }
                return [
                    'status' => 'ok',
                    'data' => [
                        'plugin_version' => (string) ($pluginJson['version'] ?? ''),
                        'api_route' => '/api/index.php?route=commerce',
                        'storefront_script' => '/plugins/commerce/assets/commerce-storefront.js',
                        'currency' => function_exists('commerce_get_default_currency') ? commerce_get_default_currency() : 'eur',
                        'tax_enabled' => !empty($taxRules['enabled']),
                        'b2b_reverse_charge_enabled' => !empty($b2b['enabled']),
                    ],
                ];
            },
        ],
        'commerce_activity_counts' => [
            'description' => 'Commerce admin attention counts: new orders, pending payments, subscriptions, open fulfillment.',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_stats', 'read'],
            'inputSchema' => commerce_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'view_commerce_stats')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $orders = new CommerceOrderStore();
                $subscriptionStore = new CommerceSubscriptionStore();
                $ordersNew = 0;
                $ordersPending = 0;
                foreach ($orders->listAll() as $order) {
                    $status = (string) ($order['status'] ?? '');
                    if (in_array($status, ['abandoned', 'failed', 'canceled'], true)) {
                        continue;
                    }
                    if ($status === 'pending') {
                        $ordersPending++;
                        $ordersNew++;
                    } elseif ($status === 'paid') {
                        $ordersNew++;
                    }
                }
                $subsTotal = count($subscriptionStore->listAll());
                return [
                    'status' => 'ok',
                    'data' => [
                        'orders_new' => $ordersNew,
                        'orders_pending' => $ordersPending,
                        'subscriptions_total' => $subsTotal,
                    ],
                ];
            },
        ],
        'commerce_list_subscriptions' => [
            'description' => 'List commerce subscriptions (recurring billing).',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'read'],
            'inputSchema' => commerce_mcp_schema_object(['limit' => $limit]),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'view_commerce_orders')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                require_once dirname(__DIR__) . '/includes/CommerceSubscriptionService.php';
                $subscriptionStore = new CommerceSubscriptionStore();
                $subscriptions = new CommerceSubscriptionService($subscriptionStore, commerce_bootstrap());
                $subscriptions->normalizeToSingleLineSubscriptions();
                $rows = $subscriptionStore->listAll();
                $limit = (int) ($arguments['limit'] ?? 0);
                if ($limit > 0) {
                    $rows = array_slice($rows, 0, $limit);
                }
                return ['status' => 'ok', 'data' => ['subscriptions' => $rows]];
            },
        ],
        'commerce_reindex_catalog' => [
            'description' => 'Rebuild the commerce catalog index from CMS entries and reconcile inventory.',
            'category' => 'write',
            'permissions' => ['manage_commerce'],
            'inputSchema' => commerce_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'manage_commerce')) {
                    return $err;
                }
                return commerce_mcp_dispatch_admin('reindex_catalog', $arguments, $aiUser);
            },
        ],
        'commerce_update_order_shipment' => [
            'description' => 'Create a shipment on an order line (carrier, tracking number). Requires order id and line_id.',
            'category' => 'write',
            'permissions' => ['manage_commerce'],
            'inputSchema' => commerce_mcp_schema_object([
                'id' => $id,
                'line_id' => ['type' => 'string', 'description' => 'Order line id to ship'],
                'carrier' => ['type' => 'string'],
                'tracking_number' => ['type' => 'string'],
                'notify_customer' => ['type' => 'boolean'],
            ], ['id', 'line_id']),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'manage_commerce')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $orders = new CommerceOrderStore();
                require_once dirname(__DIR__) . '/includes/CommerceOrderOps.php';
                $orderOps = new CommerceOrderOps($orders, new CommerceSubscriptionStore());
                $id = (string) ($arguments['id'] ?? '');
                $lineId = (string) ($arguments['line_id'] ?? '');
                $result = $orderOps->createShipment($id, [
                    'line_id' => $lineId,
                    'tracking_number' => (string) ($arguments['tracking_number'] ?? ''),
                    'carrier' => (string) ($arguments['carrier'] ?? ''),
                    'notify_customer' => !empty($arguments['notify_customer']),
                ]);
                if (!($result['ok'] ?? false)) {
                    return ['status' => 'error', 'message' => (string) ($result['error'] ?? 'Shipment update failed')];
                }
                $order = $result['order'] ?? null;
                if (is_array($order)) {
                    $order = $orderOps->enrichOrder($order);
                }
                return ['status' => 'ok', 'data' => ['order' => $order, 'shipment' => $result]];
            },
        ],
        'commerce_add_order_note' => [
            'description' => 'Append an internal note to a commerce order.',
            'category' => 'write',
            'permissions' => ['manage_commerce'],
            'inputSchema' => commerce_mcp_schema_object([
                'id' => $id,
                'note' => ['type' => 'string', 'description' => 'Note text'],
            ], ['id', 'note']),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'manage_commerce')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $orders = new CommerceOrderStore();
                require_once dirname(__DIR__) . '/includes/CommerceOrderOps.php';
                $orderOps = new CommerceOrderOps($orders, new CommerceSubscriptionStore());
                $id = (string) ($arguments['id'] ?? '');
                $note = trim((string) ($arguments['note'] ?? ''));
                if ($note === '') {
                    return ['status' => 'error', 'message' => 'note is required'];
                }
                $updated = $orderOps->addNote($id, $note, (string) ($aiUser['id'] ?? 'ai'));
                if (!($updated['ok'] ?? false)) {
                    return ['status' => 'error', 'message' => (string) ($updated['error'] ?? 'Order not found')];
                }
                $order = $updated['order'] ?? null;
                return ['status' => 'ok', 'data' => ['order' => is_array($order) ? $orderOps->enrichOrder($order) : null]];
            },
        ],
        'commerce_bulk_mark_shipped' => [
            'description' => 'Mark multiple orders as shipped with optional shared carrier/tracking.',
            'category' => 'write',
            'permissions' => ['manage_commerce'],
            'inputSchema' => commerce_mcp_schema_object([
                'ids' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Order IDs'],
                'carrier' => ['type' => 'string'],
                'tracking_prefix' => ['type' => 'string'],
                'notify_customer' => ['type' => 'boolean'],
            ], ['ids']),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require($aiUser, 'manage_commerce')) {
                    return $err;
                }
                commerce_mcp_bootstrap_services();
                $orders = new CommerceOrderStore();
                require_once dirname(__DIR__) . '/includes/CommerceOrderOps.php';
                $orderOps = new CommerceOrderOps($orders, new CommerceSubscriptionStore());
                $ids = is_array($arguments['ids'] ?? null) ? $arguments['ids'] : [];
                $result = $orderOps->bulkMarkShipped(
                    $ids,
                    (string) ($arguments['carrier'] ?? ''),
                    (string) ($arguments['tracking_prefix'] ?? ''),
                    !empty($arguments['notify_customer']),
                    ['id' => (string) ($aiUser['id'] ?? 'ai'), 'label' => 'MCP']
                );
                $updated = array_map(
                    static fn ($o) => is_array($o) ? $orderOps->enrichOrder($o) : $o,
                    $result['updated'] ?? []
                );
                return ['status' => 'ok', 'data' => ['updated' => $updated, 'count' => count($updated), 'result' => $result]];
            },
        ],
        'commerce_list_admin_actions' => [
            'description' => 'List all Commerce admin API actions grouped by area (catalog, orders, emails, invoices, fulfillment, inventory, tax, shipping, discounts, import, mappings, draft orders, analytics). Use commerce_admin_action to dispatch one.',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'view_commerce_stats', 'read'],
            'inputSchema' => commerce_mcp_schema_object(),
            'handler' => static function (array $arguments, array $aiUser): array {
                if ($err = commerce_mcp_require_any($aiUser, ['manage_commerce', 'view_commerce_orders', 'view_commerce_stats'])) {
                    return $err;
                }
                return ['status' => 'ok', 'data' => ['catalog' => commerce_mcp_admin_action_catalog()]];
            },
        ],
        'commerce_admin_action' => [
            'description' => 'Dispatch any Commerce admin API action by name. Prefer named commerce_* tools for common tasks (list orders, ship, notes). Use this for settings, emails, invoices, fulfillment, inventory, tax, shipping, discounts, import, mappings, draft orders, and analytics.',
            'category' => 'read',
            'permissions' => ['manage_commerce', 'view_commerce_orders', 'view_commerce_stats', 'read', 'write'],
            'inputSchema' => commerce_mcp_schema_object([
                'action' => ['type' => 'string', 'description' => 'Admin action name (see commerce_list_admin_actions)'],
                'payload' => ['type' => 'object', 'description' => 'Action input payload', 'additionalProperties' => true],
            ], ['action']),
            'handler' => static function (array $arguments, array $aiUser): array {
                $action = trim((string) ($arguments['action'] ?? ''));
                if ($action === '') {
                    return ['status' => 'error', 'message' => 'action is required'];
                }
                $payload = is_array($arguments['payload'] ?? null) ? $arguments['payload'] : [];
                return commerce_mcp_dispatch_admin($action, $payload, $aiUser);
            },
        ],
    ];
}
