# Commerce Provider Certification Matrix

Date: 2026-07-31
Scope: Marketplace v1

This matrix is mirrored in `includes/ProviderCertification.php` and controls live-mode provider gating.

| Provider | v1 status | Test/sandbox | Live mode | Certified for v1 | Blocked for v1 |
| --- | --- | --- | --- | --- | --- |
| Stripe | Certified | Yes | Yes | One-time payments, refunds, signed webhooks | Recurring subscriptions |
| Mollie | Certified | Yes | Yes | One-time hosted payments, refunds, signed webhooks | Recurring subscriptions, separate capture |
| PayPal | Sandbox only | Yes | No | Sandbox/testing | Live payments, refunds, subscriptions |
| Adyen | Sandbox only | Yes | No | Sandbox/testing | Live payments |
| Square | Sandbox only | Yes | No | Sandbox/testing | Live payments |
| Razorpay | Sandbox only | Yes | No | Sandbox/testing | Live payments |
| Komoju | Sandbox only | Yes | No | Sandbox/testing | Live payments |
| Payssion | Sandbox only | Yes | No | Sandbox/testing | Live payments |

## Enforcement

- Admin provider cards and connection rows display the certification status.
- The connection modal warns when a provider is sandbox-only.
- Saving an enabled live-mode connection fails closed unless the provider is live-certified.
- Existing live-mode uncertified connections are not selected for checkout.
- Recurring billing remains globally gated for Marketplace v1.

## Certification upgrade rule

Move a provider to live-certified only after sandbox/live documentation review, webhook verification proof, refund proof when advertised, checkout walkthrough evidence, and release lead sign-off.
