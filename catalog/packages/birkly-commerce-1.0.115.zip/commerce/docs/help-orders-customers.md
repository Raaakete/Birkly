# Orders & customers

Paid commerce history, draft quotes, cancel/refund, and customer profiles.

**Who it's for:** store operators handling day-to-day sales and customer records.

![Checkout → paid order](/plugins/commerce/assets/docs/checkout-flow.svg)

---

## Orders tab

**Commerce → Orders** lists commercial history. Each paid order stores a **frozen snapshot** of lines, discounts, shipping, and tax — not a live recalculation from today’s catalog.

| Column / state | Meaning |
|----------------|---------|
| Paid / pending / canceled | Payment lifecycle |
| Fulfillment state | Open, partial, shipped, delivered, etc. |
| Money fields | `subtotal`, `discount`, `shipping`, `tax`, `total` (cents) from checkout |

### Day-to-day ops

1. Open an order → review lines, customer email, money snapshot, tax lines.
2. Add **notes** / **tags** for warehouse or support.
3. Create **shipment** when `ship` lines remain — [help-fulfillment.md](help-fulfillment.md).
4. Issue **invoice** / packing slip as needed.
5. **Refund** or **Cancel** per the rules below.
6. Export CSV from the Orders list for accounting.

Hybrid carts may create **multiple paid groups** (one-time then subscription); each paid group is an order (or linked subscription). See [help-hybrid-cart.md](help-hybrid-cart.md).

---

## Draft orders / quotes

Inside Orders, **Draft orders** let you build a cart-less quote:

1. Create a draft (from scratch or from an existing cart).
2. Search catalog lines; set qty and optional unit price override.
3. Enter customer email, shipping address, optional **VAT ID**.
4. **Preview** shipping and tax from current providers.
5. **Save & send** an accept link to the customer.
6. Customer accepts → payment via `quote_checkout` / draft checkout.
7. Optional: **merchant-assisted checkout** from the editor.

| Status | Meaning |
|--------|---------|
| `quote` | Created, awaiting customer accept |
| `pending_payment` | Accepted, checkout in progress |
| `paid` | Order completed |
| `expired` / `canceled` | No longer valid |

Default expiry is about **30 days** from creation. Cancel invalidates the accept token.

Accept URL shape:

```text
/api/index.php?route=commerce&action=get_quote&token={token}
```

Admin API: `draft_order_create`, `draft_order_update`, `draft_order_preview`, `draft_order_get`, `draft_order_search_catalog`, `draft_order_checkout`, `create_quote`, `list_quotes`, `cancel_quote`.

Public: `get_quote`, `accept_quote`, `quote_checkout`.

---

## Cancel vs refund

| Action | What it does |
|--------|----------------|
| **Refund** | Returns money (full, partial, or per line) via the payment provider. Does **not** by itself mean “stop the order.” |
| **Cancel** | Stops the order: leaves Fulfillment queue, restores stock, cancels registrations, revokes digital downloads. Optionally refunds the remaining balance (default on for paid orders). |

### Rules

1. **Cancel** is only allowed while **nothing has shipped**.
2. After shipment, use **refund** / return instead.
3. Admin cancel is always available on the order detail (when unshipped).
4. Optional **customer self-service cancel** is off by default under **Settings → General** (`lookup_order` + `customer_cancel_order`).

| Setting | Default | Meaning |
|---------|---------|---------|
| Customer order cancel | Off | Allow public cancel via lookup API |
| Cancel window (hours) | 24 | Hours after pay/create; `0` = no time limit while unshipped |

Automation triggers: `commerce_order_canceled`, `commerce_order_refunded`.

### Admin API

| Action | Purpose |
|--------|---------|
| `refund_order` | Money return via PSP |
| `cancel_order` | Stop fulfillment + optional refund |
| `list_orders` / `get_order` | Browse |
| `export_orders_csv` | Bulk export |
| `add_order_note` / `set_order_tags` | Ops metadata |

---

## Order detail actions

| Action | Use |
|--------|-----|
| Add note / tags | Internal ops |
| Create shipment | Partial or multi-package — [Fulfillment](help-fulfillment.md) |
| Packing slip | Print tab → browser Print / PDF |
| Invoice | Issue / preview from invoice templates |
| Manage subscription | Jump to linked subscription when recurring |
| Export CSV | Bulk export from Orders list |

Money snapshot includes `tax_lines[]` and `discount_allocations` — useful for accounting exports. Invoice / email templates: **Settings → Invoices** / **Emails**.

---

## Customers tab

**Commerce → Customers** profiles are keyed by **email** (unique). No password import — User Management accounts stay invite/reset-only.

| Data | Notes |
|------|-------|
| Addresses | Shipping / billing saved on profile |
| Tags & notes | Merchant ops |
| Timeline | Orders + subscriptions for that email |
| Optional User Management link | When the User plugin is active |

### CSV import

1. Open Customers → **Import CSV**.
2. Map columns (email required; name, tags, addresses as available).
3. Review import result; duplicates merge by email.

API: `import_customers_csv`, `list_customers`, `get_customer`, `save_customer`, `delete_customer`, `customer_timeline`.

> **Note:** Shopify cutover imports customers with `source: shopify`. Passwords are never imported — [help-shopify-cutover.md](help-shopify-cutover.md).

### Customer self-service (optional)

When Settings → General enables customer cancel:

```json
{ "action": "lookup_order", "email": "buyer@example.com", "order_id": "ord_…" }
{ "action": "customer_cancel_order", "email": "buyer@example.com", "order_id": "ord_…" }
```

---

## Common mistakes

| Symptom | Fix |
|---------|-----|
| Totals disagree with catalog | Orders freeze money at pay — expected |
| Cannot cancel | Something already shipped — refund instead |
| Draft accept link 404 | Quote expired/canceled; re-save & send |
| Duplicate customers | Merge key is email — normalize casing/typos |
| Subscription still active after refund | Cancel subscription explicitly — [help-subscriptions.md](help-subscriptions.md) |

---

## Related

- [Fulfillment](help-fulfillment.md)
- [Subscriptions](help-subscriptions.md)
- [Tax](help-tax.md)
- [Promotions](help-promotions.md)
- [Troubleshooting](help-troubleshooting.md)
