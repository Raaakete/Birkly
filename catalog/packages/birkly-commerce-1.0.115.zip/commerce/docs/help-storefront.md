# Storefront kit

Build the customer-facing cart and checkout with Birkly templates plus the Commerce storefront script. Prefer the plugin’s JS for cart mechanics; keep your brand UI thin.

**Who it's for:** frontend developers and AI agents wiring `project/` sites.

> **Note:** This is the full storefront guide. Short template-function reference: [help-templating.md](help-templating.md). End-to-end checklist: [help-project-integration.md](help-project-integration.md).

![Checkout flow](/plugins/commerce/assets/docs/checkout-flow.svg)

---

## Scripts

Every templated page needs Birkly client; commerce pages also load the storefront kit:

```html
<script src="/birkly-client.js"></script>
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
<script>
  BirklyCommerce.bind(document);
</script>
```

| Script | Role |
|--------|------|
| `/birkly-client.js` | Template language (`{for each}`, `{commerce_buy_url}`, …) |
| `/plugins/commerce/assets/commerce-storefront.js` | Session cart API wrapper, checkout, split pay, money rows |

Cache-bust after plugin updates if your host caches aggressively, e.g. `commerce-storefront.js?v=1.0.57`.

---

## Template functions

| Function | Returns / purpose |
|----------|-------------------|
| `{commerce_cart_count}` | Items in session cart (header badge) |
| `{commerce_cart_url}` | Cart API URL |
| `{commerce_buy_url entry_id collection qty}` | Buy / checkout URL for sellable unit |
| `{commerce_add_to_cart entry_id collection qty}` | Alias for cart-first UX |
| `{commerce_price_from entry_id collection}` | Lowest purchase_option (“from €X”) |
| `{commerce_quantity_available entry_id collection}` | Live Inventory Available (empty when unlimited) |

**Variants:** pass the **variant sub-entry** id/slug, not the parent product id.

```html
<a href="{commerce_buy_url variant_slug products 1}">Buy 250g whole bean</a>
```

Affiliate: append `?ref=partner_id` to commerce URLs; Commerce stores the ref for discount rules.

---

## Markup hooks (Fieldnotes patterns)

| Attribute / hook | Purpose |
|------------------|---------|
| `[data-commerce-add]` | Button/link → add to cart (`data-entry-id`, `data-collection`, `data-qty`, optional `data-purchase-option-id`) |
| `[data-commerce-cart]` | Cart root; auto-refresh on changes |
| `[data-commerce-checkout]` | Checkout form |
| `[data-commerce-shipping-fields]` | Hidden when cart has no `ship` lines |
| `[data-commerce-attendee-fields]` | Shown when cart has `register` lines |
| `[data-commerce-status]` | Status / error surface (`data-commerce-error` on failure) |
| `[data-commerce-money]` | Money breakdown host for `renderMoneyRows` |

### Example buy button (€14.99 once)

```html
<button
  type="button"
  data-commerce-add
  data-entry-id="{slug}"
  data-collection="products"
  data-purchase-option-id="once"
  data-qty="1">
  Add to cart — €14.99
</button>
```

### Variable / donate pricing

When `pricing_mode` is `variable`, pass amount in cents:

```js
await BirklyCommerce.add({
  entry_id: 'donate',
  collection: 'giving',
  purchase_option_id: 'donate',
  qty: 1,
  amount_cents: 2500 // €25.00, clamped to min/max
});
```

---

## BirklyCommerce JS API

```js
BirklyCommerce.bind(document);

await BirklyCommerce.add({
  entry_id: 'coffee-250',
  collection: 'products',
  purchase_option_id: 'once',
  qty: 1
});

const cart = await BirklyCommerce.getCart();
BirklyCommerce.renderMoneyRows(cart);

BirklyCommerce.on('checkout-ready', function (data) {
  // data.client_secret → mount Stripe Payment Element
  // data.needs_split → pay this group, then continue
});
```

| Call | Purpose |
|------|---------|
| `add({ entry_id, collection, purchase_option_id?, qty?, amount_cents? })` | Add line |
| `update({ … })` | Change qty |
| `remove({ entry_id, collection, purchase_option_id? })` | Remove line |
| `getCart()` | Session cart + `groups` / `split_required` |
| `clear()` | Empty cart |
| `setCheckoutDraft(fields)` | Persist address/email/VAT; re-quote shipping/tax |
| `setCoupon` / `setGiftCard` / `setAffiliate` | Promotions |
| `renderMoneyRows(cart)` | Subtotal / shipping / tax / total (+ free-shipping progress) |
| `checkout(fields)` | Starts payment; auto-selects first group when split |
| `confirmPayment(stripe, elements)` | After Payment Element |
| `continueSplitCheckout()` | Next billing group |
| `cartNeedsShipping()` / `cartNeedsAttendee()` | UI helpers |
| `getSplitState()` | `{ currentGroupKey, nextGroupKey }` |
| `storefrontConfig()` | `recurring_billing_enabled`, version, public actions |

### Stripe sandbox sketch

```js
BirklyCommerce.on('checkout-ready', async function (data) {
  const stripe = Stripe('pk_test_…'); // publishable only — never secret
  // elements = stripe.elements({ clientSecret: data.client_secret })
  // … mount Payment Element …
  // await BirklyCommerce.confirmPayment(stripe, elements);
  if (BirklyCommerce.getSplitState().nextGroupKey) {
    await BirklyCommerce.continueSplitCheckout();
  }
});
```

---

## Cart money fields

Use these for free-shipping progress and tax-aware UI:

| Field | Meaning |
|-------|---------|
| `subtotal_cents` | Lines before shipping/tax adjustments |
| `shipping_cents` | Quoted shipping |
| `tax_cents` | Tax amount (informational / line breakdown) |
| `tax_add_cents` | **Amount added to the charge** for exclusive tax (0 when prices include tax) |
| `prices_include_tax` / `tax_included` | Shelf prices already include VAT |
| `discount_cents` / `gift_card_cents` | Promotions applied to one-time group |
| `total_cents` | Amount to charge for the current group |
| `free_shipping_min_cents` | Configured threshold (0 = off) |
| `free_shipping_remaining_cents` | Still needed to unlock |
| `free_shipping_unlocked` | Threshold or free-shipping promo zeroed shipping |

> **Note:** When `prices_include_tax` is true, show tax as **included** — do not add `tax_cents` again on top of the shelf total. Use `tax_add_cents` for the charge delta. See [help-tax.md](help-tax.md).

![Tax modes](/plugins/commerce/assets/docs/tax-modes.svg)

---

## Public cart API actions

Route: `/api/index.php?route=commerce` (JSON body or query `action=`).

| Action | Auth | Purpose |
|--------|------|---------|
| `get` | Public (session) | Read cart |
| `add` | Public | Add line |
| `update` | Public | Change qty |
| `remove` | Public | Remove line |
| `clear` | Public | Empty cart |
| `set_coupon` / `set_gift_card` / `set_affiliate` | Public | Promotions |
| `set_checkout_draft` | Public | Persist checkout fields |
| `catalog_item` | Public | Single catalog row + tax estimate |
| `storefront_config` | Public | Feature flags + `public_actions` |
| `checkout` | Public | Start payment |
| `confirm_payment` | Public | Confirm provider payment |
| `lookup_order` / `customer_cancel_order` | Public | Self-service (when enabled) |
| `list_my_subscriptions` / `customer_pause_subscription` / `customer_resume_subscription` / `customer_cancel_subscription` | Public | Signed-in site user subscription self-service |
| `get_quote` / `accept_quote` / `quote_checkout` | Public | Draft order accept flow |

Full action list (admin + public): [help-developer.md](help-developer.md).

Always send cookies: `credentials: 'same-origin'`.

---

## Remove cart caveats

Cart remove matches session rows by `collection` + `entry_id` + optional `purchase_option_id`.

| Situation | Behavior (Commerce 1.0.55+) |
|-----------|-----------------------------|
| Client omits `purchase_option_id` | Treated as match-any for that entry |
| Session row missing option id | Matches a remove that targets the resolved default (e.g. `once`) |
| Multiple options for same entry | Pass the exact `purchase_option_id` to remove only that line |

```js
// Preferred — pass the option shown in the cart UI
await BirklyCommerce.remove({
  entry_id: 'coffee-250',
  collection: 'products',
  purchase_option_id: 'once'
});
```

Add persists the resolved `purchase_option_id` onto the session row when the client omitted it (1.0.56+), so later removes are stable.

If Remove still fails: hard-refresh, clear cart, confirm plugin ≥ 1.0.56 — [help-troubleshooting.md](help-troubleshooting.md).

---

## Split checkout (hybrid)

Mixed one-time + subscription carts use **split checkout**: collect customer details once, pay groups sequentially.

![Hybrid cart](/plugins/commerce/assets/docs/hybrid-cart.svg)

```js
await BirklyCommerce.checkout({ email, shipping_address, attendee_name });
// mount Stripe with client_secret, then:
await BirklyCommerce.confirmPayment(stripe, elements);
if (BirklyCommerce.getSplitState().nextGroupKey) {
  await BirklyCommerce.continueSplitCheckout();
}
```

| Group | Typical lines | Promotions |
|-------|---------------|------------|
| One-time | ship + deliver + register | Coupons + gift cards apply |
| Subscription | recurring purchase options | Coupons/gift cards do **not** re-apply |

Details: [help-hybrid-cart.md](help-hybrid-cart.md).

---

## Common mistakes

| Symptom | Fix |
|---------|-----|
| Buttons dead | Load storefront JS + `bind(document)` |
| Cart empty after refresh on another origin | Session is cookie-bound to CMS host |
| Shipping stays 0 | Call `setCheckoutDraft` with country before final total |
| Tax doubled | Inclusive mode — don’t add `tax_cents` to shelf total |
| Split stuck | Call `continueSplitCheckout` after first confirm |
| Stale behaviour after upgrade | Cache-bust `commerce-storefront.js` |

---

## Account page (subscriptions + delete)

Pair **User Management** `user-storefront.js` with Commerce for signed-in self-service.

Reference template: `plugins/user_management/examples/project/account.html`

```html
<script src="/birkly-client.js"></script>
<script src="/plugins/user_management/assets/user-storefront.js"></script>
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>

<section data-birkly-account-guest hidden>…login form data-birkly-login…</section>
<section data-birkly-account-member hidden>
  <div data-commerce-subscriptions></div>
  <form data-birkly-delete-account>…</form>
</section>

<script>
  document.documentElement.setAttribute('data-commerce-autobind', '1');
  BirklyUser.bind(document);
  BirklyCommerce.bind(document);
</script>
```

| UI hook | Behaviour |
|---------|-----------|
| `data-birkly-account-guest` / `data-birkly-account-member` | Toggled by `BirklyUser.session()` |
| `data-commerce-subscriptions` | Lists owned subs; pause / resume / cancel buttons |
| `data-birkly-delete-account` | Deletes account; prompts to cancel subs first |

API routes: `user_account` (`profile`, `delete_preview`, `delete_account`) and Commerce `list_my_subscriptions` + customer subscription actions. Requires site user sign-in.

---

## Related

- [Templating (short)](help-templating.md)
- [Project integration](help-project-integration.md)
- [Developer API](help-developer.md)
- [Fieldtype](help-fieldtype.md)
- [Tax](help-tax.md)
- [Hybrid cart](help-hybrid-cart.md)
