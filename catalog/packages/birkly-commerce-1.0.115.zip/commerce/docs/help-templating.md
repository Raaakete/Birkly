# Commerce template functions

Short reference for Light DOM template tags. Register when Commerce is **active**.

**Who it's for:** site builders adding buy links and cart badges to HTML.

> **Note:** For the full storefront kit (`commerce-storefront.js`, cart money fields, remove caveats, Fieldnotes hooks), use **[help-storefront.md](help-storefront.md)**. For a project checklist, see [help-project-integration.md](help-project-integration.md).

---

## Setup on every commerce page

```html
<script src="/birkly-client.js"></script>
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
<script>BirklyCommerce.bind(document);</script>
```

Without `birkly-client.js`, `{commerce_buy_url}` and loops render as **raw text**. Without the storefront script, `data-commerce-add` buttons do nothing.

Use `get_project_info` → `site_url_prefix` for your CSS/pages (often `/project/`). Plugin scripts stay host-root paths.

---

## Cart

| Function | Returns | Example |
|----------|---------|---------|
| `{commerce_cart_count}` | Number of items in session cart | Header badge |
| `{commerce_cart_url}` | URL to cart API endpoint | Link to cart page |

```html
<a href="/project/cart.html">Cart ({commerce_cart_count})</a>
```

---

## Buy / add to cart

| Function | Arguments | Purpose |
|----------|-----------|---------|
| `{commerce_buy_url entry_id}` | entry id or slug | Checkout URL for sellable unit |
| `{commerce_buy_url entry_id collection}` | + collection slug | Disambiguate id |
| `{commerce_buy_url entry_id collection qty}` | + quantity | Default qty 1 |
| `{commerce_add_to_cart entry_id collection qty}` | Same as buy_url | Semantic alias for cart-first UX |

**Variants:** pass the **variant sub-entry** id/slug, not the parent product id.

```html
<a href="{commerce_buy_url variant_slug products 1}">Buy 250g whole bean</a>
```

### Prefer markup hooks for JS cart

```html
<button
  type="button"
  data-commerce-add
  data-entry-id="{slug}"
  data-collection="products"
  data-purchase-option-id="once"
  data-qty="1">
  Add to cart — €14.99
</button>
```

---

## Price & stock display

| Function | Purpose |
|----------|---------|
| `{commerce_price_from entry_id collection}` | Lowest purchase_option price for "from €X" on parent pages |
| `{commerce_quantity_available entry_id collection}` | Live Inventory Available (empty when unlimited) |

Prefer `{commerce_quantity_available …}` over static teaser text like “only 3 left” — Available is projected from the inventory ledger after reserve/pay.

```html
<p>From {commerce_price_from slug products}</p>
<p>{commerce_quantity_available slug products} left</p>
```

---

## Example product page (with variants)

```html
<h1>{title}</h1>
{content}

{for each variant in sub_entries variants}
  <div class="variant">
    <h3>{variant.title}</h3>
    <p>From {commerce_price_from variant.id products}</p>
    <button
      type="button"
      data-commerce-add
      data-entry-id="{variant.id}"
      data-collection="products"
      data-purchase-option-id="once"
      data-qty="1">
      Add to cart
    </button>
  </div>
{endfor}

<script src="/birkly-client.js"></script>
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
<script>BirklyCommerce.bind(document);</script>
```

---

## Example class / capacity product

```html
{if pricing.quantity_available > 0}
  <a href="{commerce_buy_url slug classes 1}">Book — €25</a>
{else}
  <p>Sold out</p>
{endif}
```

For `register` fulfillment, Available is **capacity** (seats), not warehouse stock.

---

## Affiliate tracking

Append `?ref=partner_id` to any commerce URL path on your site; Commerce stores the ref in session for checkout discount rules.

```html
<a href="/project/shop.html?ref=studio_partner">Shop with partner offer</a>
```

---

## Storefront JS (recommended)

```html
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
<script>
  BirklyCommerce.bind(document);
  BirklyCommerce.on('checkout-ready', function (data) {
    // data.client_secret → mount Stripe Payment Element
  });
</script>
```

| Helper | Use |
|--------|-----|
| `add` / `getCart` / `remove` | Session cart |
| `setCheckoutDraft` | Address / email / VAT — re-quotes shipping & tax |
| `renderMoneyRows` | Subtotal / shipping / tax / free-shipping progress |
| `checkout` / `continueSplitCheckout` | Pay (+ hybrid groups) |
| `storefrontConfig` | Flags + `public_actions` |

Cart money fields: `tax_add_cents`, `prices_include_tax`, `free_shipping_remaining_cents` — [help-storefront.md](help-storefront.md), [help-tax.md](help-tax.md).

Mixed one-time + subscription carts use **split checkout** — [help-hybrid-cart.md](help-hybrid-cart.md).

![Checkout flow](/plugins/commerce/assets/docs/checkout-flow.svg)

---

## API alternative

Templates can link to `/api/index.php?route=commerce&action=checkout&…` directly; template functions build the correct query string for you.

Public JSON route: `/api/index.php?route=commerce` with `action=get|add|remove|clear|checkout|storefront_config|…`.

```json
{
  "action": "add",
  "entry_id": "coffee-250",
  "collection": "products",
  "purchase_option_id": "once",
  "quantity": 1
}
```

Use `credentials: 'same-origin'` so the PHP session cookie is sent.

---

## Common mistakes

| Symptom | Fix |
|---------|-----|
| Raw `{commerce_buy_url …}` on page | Add `/birkly-client.js` |
| Buy button does nothing | Load `commerce-storefront.js` + `BirklyCommerce.bind` |
| Wrong variant / price | Pass **variant** id, not parent |
| Stock always blank | Unlimited mode → Available is empty by design |
| Assets 404 | Prefix project CSS with `site_url_prefix` |

---

## Related

- [Storefront kit (full)](help-storefront.md)
- [Commerce fieldtype](help-fieldtype.md)
- [Project integration](help-project-integration.md)
- [Birkly-Docs — Commerce template functions](https://docs.birkly.com/03-templating/commerce-functions.html)
