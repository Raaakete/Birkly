# Settings reference

Every panel under **Commerce → Settings** (two-pane hub). Use this as a map of *where to click*; deep behaviour lives in topic articles.

**Who it's for:** merchants configuring the shop; operators onboarding a new site.

![Settings two-pane hub](/plugins/commerce/assets/docs/settings-nav.svg)

---

## How the hub is organized

| Left group | Panels |
|------------|--------|
| **Payments & catalog** | Connections · General · Fieldtypes · Mappings · Import & migrate |
| **Shipping, tax & ops** | Shipping · Tax · Invoices · Emails · Fulfillment · Activity |

Open **Commerce → Settings**, then click a left-nav item. Changes usually need an explicit **Save** on that panel.

> **Note:** In-plugin help lives under the primary **Docs** tab (not buried inside Settings).

---

## Connections

**What:** Payment providers (Stripe, Mollie, …).

| Task | Steps |
|------|-------|
| Add sandbox Stripe | Add Connection → Stripe → paste **test** secret → save |
| Go live | Switch to live keys only after a successful test order; certified providers only |
| Tax with Stripe Tax | Still needs a Stripe secret here even if another PSP charges |

See [Getting started](help-getting-started.md).

---

## General

**What:** Provider selection, currency, stock mode, SLA, customer cancel, activity bell, dunning emails, optional display FX.

| Control | Meaning |
|---------|---------|
| Provider selection mode | `auto` (by currency/country/method) or `fixed` (always default) |
| Default provider | Used when mode is fixed / as fallback |
| Default currency | Charge currency for **new** purchase options (`eur`, `usd`, …). No FX at checkout |
| Stock mode | Unlimited · Simple · Locations — [help-catalog-inventory.md](help-catalog-inventory.md) |
| Fulfillment SLA (hours) | Default `48` — Dashboard SLA breach window for unshipped paid ship orders |
| Customer cancel | Off by default; optional public `lookup_order` / `customer_cancel_order` |
| Cancel window (hours) | Default `24`; `0` = no time limit while unshipped |
| Display currency / FX JSON | Catalog **labels** only — checkout still charges purchase-option currency |
| Activity notify / nav dot | Bell + sidebar mint indicator for shop activity |
| Dashboard widget | Optional home widget + roles |
| Dunning emails | Built-in past-due mailer; prefer Automation for branded flows — [help-subscriptions.md](help-subscriptions.md) |

---

## Fieldtypes

**What:** Saved Commerce field **profiles** (fulfillment presets, intervals, custom merchant fields).

1. Click **New fieldtype**.
2. Choose enabled fulfillments and billing intervals (including custom like `2_weeks`).
3. Save — the profile becomes selectable when editing a collection schema.

Profiles are **not** edited inside the collection field picker itself. See [help-fieldtype.md](help-fieldtype.md).

---

## Mappings

**What:** Product → User Management **tier** grants after pay (`none` / membership-style products).

Wizard steps:

1. Pick catalog item (or SKU).
2. Pick purchase option (or any/default).
3. Pick tier → **Save mapping**.

Requires the **User Management** plugin for tiers. Emits `commerce_membership_started` via PostPurchaseRouter.

---

## Import & migrate

| Path | Use when |
|------|----------|
| **Shopify cutover** | One-time products + customers + archived orders — [help-shopify-cutover.md](help-shopify-cutover.md) |
| **CSV import** | Spreadsheet product rows |
| **Live store sync (Beta)** | Ongoing product sync (Shopify/Woo/…); not customers/orders |
| **Legacy wizard** | Appears only when old Shop/Events sources are detected |

Always dry-run before production import. Prefer rollback over hand-deleting mixed rows.

---

## Shipping

| Control | Meaning |
|---------|---------|
| Rate provider | Manual zones or EasyPost |
| EasyPost API key | Live quotes; reused by EasyPost fulfillment |
| Zones / fallback | Country matchers + rates in **cents** |
| Free shipping min | Cart goods threshold in cents (`0` = off) |

Deep guide: [help-shipping.md](help-shipping.md).

---

## Tax

| Control | Meaning |
|---------|---------|
| Tax provider | Manual or Stripe Tax (orthogonal to charge PSP) |
| Enable tax at checkout | Master switch |
| Default rate / country map | Manual table |
| Tax classes + class×country | e.g. reduced × DE = 7% |
| B2B reverse charge | VAT ID rules; format normalize only (no live VIES) |

**Price tax mode** is on each product’s Commerce field, not here — [help-tax.md](help-tax.md).

---

## Invoices

| Control | Meaning |
|---------|---------|
| Company profile | Logo, address, tax note, disclaimer |
| Templates | HTML with tokens; sequential numbers |
| Issue / preview | From order detail |

Presets are tools — **not legal advice**.

---

## Emails

| Control | Meaning |
|---------|---------|
| Transactional templates | Receipts, follow-ups (Content Editor) |
| Scheduled emails | Delayed follow-ups; process via admin/API |
| Test send | Verify SMTP before go-live |

For event-driven branded mail, prefer **Automation** recipes — [help-webhooks-automation.md](help-webhooks-automation.md).

---

## Fulfillment

| Control | Meaning |
|---------|---------|
| Active adapter | Manual / Export (default) or EasyPost |
| Webhook secret / URL | EasyPost tracking inbound |
| Test adapter | Connectivity check when offered |

Rate quoting ≠ labels — Shipping panel vs this panel. Deep guide: [help-fulfillment.md](help-fulfillment.md).

---

## Activity

Payment and shop activity log. Complements General → activity notify / sidebar indicator settings.

---

## Quick “where do I…?”

| I want to… | Go to |
|------------|-------|
| Take payments | Connections |
| Change stock counting | General → Stock mode |
| Grant membership tiers | Mappings |
| Move off Shopify | Import & migrate → Shopify cutover |
| Set VAT rates | Tax (+ Price tax mode on products) |
| Set shipping zones | Shipping |
| Print labels / tracking | Fulfillment (+ Fulfillment tab for queue) |
| Brand invoices | Invoices |
| Past-due subscription email | General → Dunning **or** Automation |

---

## Related

- [Overview](help-overview.md)
- [Getting started](help-getting-started.md)
- [Shipping](help-shipping.md)
- [Tax](help-tax.md)
- [Fulfillment](help-fulfillment.md)
- [Webhooks & Automation](help-webhooks-automation.md)
