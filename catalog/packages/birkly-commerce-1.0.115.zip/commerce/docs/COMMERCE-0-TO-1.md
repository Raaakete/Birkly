# Commerce 0→1 (P54)

**Status:** Phase complete (P0–P3) — Commerce **1.0.29** (2026-08-02).  
**Baseline:** this plugin **1.0.14**.

## Canonical plan

Full phase plan, milestones, and locked decisions live in the private Marketplace workspace:

- Plan: `Birkly-Marketplace/internal/planning/reviews/P54-commerce-0-to-1-plan.md`
- Lead handoff: `Birkly-Marketplace/internal/planning/reviews/P54-lead-engineer-handoff.md`

Do **not** duplicate the full plan here.

## Sequencing

| Phase | Focus | Gate |
|-------|--------|------|
| **P0** | Foundation — IA, inventory SoR, tax_lines freeze, stub honesty, docs IA | Must complete first |
| **P1** | Parity — customers, Shopify cutover, promotions, sellable gift cards, tax classes, manual fulfillment | After P0 DoD |
| **P2** | Automation — Stripe Tax, live shipping rates, live fulfillment, B2B VAT, draft orders | After P1 DoD |
| **P3** | Differentiation — hybrid cart, MCP store kit, automation recipes, ops intelligence | After P2 DoD |

## Gap inventory

`docs/RELEASE-READINESS-PLAN.md` remains the detailed gap inventory. **Execution order is P54**, not the older release-wave sequencing in that file.
