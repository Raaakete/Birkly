# Promotions — discounts & gift cards

Coupons, automatic discounts, affiliate rules, and store-credit gift cards.

**Who it's for:** merchants running sales; developers applying codes on the storefront.

---

## Merchant quick start — create a coupon

1. Open **Commerce → Discounts**.
2. Click **Add Rule**.
3. Set **Name**, **Type** = `coupon`, and a code (e.g. `SAVE10`).
4. Choose value type:
   - **Percent off** — e.g. `10` = 10%
   - **Fixed amount** — cents off, e.g. `500` = €5.00
   - **Free shipping**
5. Optional: min purchase (`min_purchase_cents`), usage limit, start/end dates, target (`collection:…` or `entry:…`).
6. Leave **Enabled** on → **Save rule**.
7. On the storefront, apply with `BirklyCommerce.setCoupon('SAVE10')` or your checkout coupon field.

---

## Discounts tab (Promotions v2)

**Commerce → Discounts** manages rules that evaluate at cart/checkout. Paid orders increment usage counts.

| Rule kind | How it applies |
|-----------|----------------|
| **Coupon** | Customer enters a code (`set_coupon`) |
| **Automatic** | Applies when cart matches conditions (no code) |
| **Affiliate** | Tied to `?ref=` / `set_affiliate` |

### Rule fields

| Field | Purpose | Example |
|-------|---------|---------|
| `value_type` | `percent`, `fixed`, or `free_shipping` | `percent` |
| `value` | Percent points or cents off (N/A for free_shipping) | `10` or `500` |
| Date window | Start / end — outside window → no discount | Campaign week |
| `usage_limit` | Max redemptions; blank = unlimited; increments when paid | `100` |
| Min purchase | Minimum cart **goods** subtotal in cents | `5000` (€50) |
| Target | Optional `collection:…` or `entry:…:slug` | Limit to one SKU |
| `stackable` | Whether it can combine with other rules | on/off |

### Stacking (plain language)

| Kind | Behavior |
|------|----------|
| **Non-stackable** (`stackable` off) | Among matching exclusive candidates, only the **highest customer savings** applies |
| **Stackable** (`stackable` on) | May apply **in addition** to the winning exclusive rule |
| **Coupon + automatic** | May combine when **both** are stackable |

Engine returns `line_discounts`, `free_shipping`, `discount_cents`, `allocations`, `applied_rule_ids`.

Free-shipping value type zeros shipping without reducing line totals. It also sets cart `free_shipping_unlocked`. Site-wide cart threshold: [help-shipping.md](help-shipping.md).

### Storefront / API

```js
await BirklyCommerce.setCoupon('SAVE10');
// or POST { "action": "set_coupon", "code": "SAVE10" }
const cart = await BirklyCommerce.getCart();
// cart.discount_cents, cart.discount_allocations
```

> **Note:** Coupons and gift cards settle on the **one-time** checkout group only. They do **not** re-apply to subscription / recurring groups in a split cart — [help-hybrid-cart.md](help-hybrid-cart.md).

---

## Gift Cards tab

**Commerce → Gift Cards** — issue and manage store credit.

### Admin-issued cards

1. Click **Issue Gift Card**.
2. Enter balance in major units as the UI expects (e.g. `50` for €50.00) **or** use API `balance_cents: 5000`.
3. Optional custom code; leave blank to auto-generate.
4. Card appears as **active**.

**Void** disables a card. Voided and expired cards are rejected at checkout.

### Sell as a product

1. On a CMS entry Commerce field, set fulfillment to **`gift_card`**.
2. Set purchase option `price_cents` to the **face value** (e.g. `2500` = €25 credit).
3. After payment, PostPurchaseRouter issues one code per quantity.
4. Automation trigger: `commerce_gift_card_issued`.
5. Codes appear on the order and under **Gift Cards**.

Checkout for gift-card lines collects email only (no shipping).

### Customer redemption

```js
await BirklyCommerce.setGiftCard('GIFT-ABCD-1234');
```

| Rule (v1) | Detail |
|-----------|--------|
| One gift card per checkout | Additional codes replace / reject per engine rules |
| Currency must match | Card currency = order currency |
| Partial redemption | Remainder stays on the card |
| Tender order | Gift card applies **after** coupons |

Admin API: `issue_gift_card` `{ balance_cents, code?, currency?, expires_at? }`, `void_gift_card`, `list_gift_cards`.

---

## Affiliates

1. Create an **affiliate**-type discount rule with the partner id.
2. Share URLs with `?ref=partner_id`.
3. Commerce stores the ref in session; matching rules apply at evaluate time.

```js
await BirklyCommerce.setAffiliate('partner_id');
// or land on /project/shop.html?ref=partner_id
```

---

## Worked examples (EUR cents)

| Goal | Rule |
|------|------|
| 10% off sitewide coupon | type `coupon`, code `SAVE10`, `value_type: percent`, `value: 10` |
| €5 off over €50 | `fixed` / `500`, `min_purchase_cents: 5000` |
| Free shipping weekend | `free_shipping`, date window Sat–Sun |
| Partner 15% | type `affiliate`, affiliate id, `percent` / `15` |
| Sell €50 gift card | product `fulfillment: gift_card`, `price_cents: 5000` |

---

## What promotions are not

| Concern | Where instead |
|---------|----------------|
| Product shelf price | Commerce field `purchase_options` |
| Tax rate | Settings → Tax |
| Membership tiers | Settings → Mappings |
| Free shipping by cart amount | Settings → Shipping threshold |
| Draft / quote line overrides | Orders → Draft orders |

Paid orders freeze `discount_allocations` — later rule edits do not rewrite history.

---

## Related

- [Hybrid cart](help-hybrid-cart.md) — one-time vs recurring settlement
- [Fieldtype — gift_card fulfillment](help-fieldtype.md)
- [Storefront — setCoupon / setGiftCard](help-storefront.md)
- [Orders](help-orders-customers.md) — frozen allocations; draft quotes
- [Shipping — free shipping threshold](help-shipping.md)
