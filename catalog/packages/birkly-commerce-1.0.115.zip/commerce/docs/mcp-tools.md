# Commerce MCP tools

Registered when the Commerce plugin is **active**. Tool definitions and handlers live in `docs/mcp_tools.php`.

These are **inbound Birkly MCP** tools for AI apps connected to your admin. Visitor website tools (WebMCP) are a separate catalog — see [webmcp-tools.md](webmcp-tools.md).

## When to use

- Prefer these tools over raw `/api/commerce` calls from MCP.
- Call `list_plugins` first — tools disappear when Commerce is deactivated.
- Read full context: `read_birkly_docs` topic `commerce` or `birkly://docs/plugin/commerce`.
- For settings, emails, invoices, fulfillment, inventory, tax, shipping, discounts, import, mappings, draft orders, or analytics — use `commerce_list_admin_actions` + `commerce_admin_action` (full admin API parity).

## Read tools

| Tool | Purpose |
|------|---------|
| `commerce_list_orders` | Orders list (optional `include_abandoned`) |
| `commerce_get_order` | Single order by `id` |
| `commerce_list_customers` | Customers (`search` optional) |
| `commerce_get_customer` | Customer by `id` or `email` + timeline |
| `commerce_list_catalog` | Indexed sellable catalog rows |
| `commerce_storefront_config` | Currency, tax flags, script paths |
| `commerce_activity_counts` | Admin attention counts |
| `commerce_list_subscriptions` | Recurring subscriptions |
| `commerce_list_admin_actions` | Grouped catalog of all admin API actions |

## Write tools

| Tool | Purpose |
|------|---------|
| `commerce_reindex_catalog` | Rebuild catalog index + inventory reconcile |
| `commerce_update_order_shipment` | Ship a line (`id`, `line_id`, tracking) |
| `commerce_add_order_note` | Internal order note |
| `commerce_bulk_mark_shipped` | Bulk ship (`ids`, `carrier`, `tracking_prefix`) |
| `commerce_admin_action` | Dispatch any admin action (`action`, `payload`) — write actions require `manage_commerce` |

## Permissions

Requires Commerce capabilities on the connected user. Reads accept `manage_commerce`, `view_commerce_orders`, or `view_commerce_stats` (catalog included). Writes require `manage_commerce`. Admins always allowed.

## Site building reminder

Product **images** belong in `gallery` / `image` / `media` fields on entries — not `url` text fields. Use the Commerce fieldtype on sellable entries; see `commerce-store-kit` playbook.
