# Commerce fieldtype

Add sellable pricing to any collection. The field stores fulfillment, purchase options, tax mode, SKU, and optional weight — not discounts or shipping zones (those live in Commerce admin).

**Who it's for:** merchants editing products, and developers defining schemas.

![Entry editor — Commerce blocks](/plugins/commerce/assets/docs/product-commerce-field.svg)

---

## Add the field

```json
{
  "name": "pricing",
  "type": "commerce",
  "label": "Pricing"
}
```

Or pick a **saved profile** as the field type (`commerce`, `commerce_events`, `commerce_digital`, …). Profiles are managed in **Commerce → Settings → Fieldtypes** — not in the collection editor.

Each profile controls: enabled fulfillment types, billing intervals (including custom values like `3_days`, `2_weeks`), optional custom merchant fields, and which sub-panels appear in the entry editor.

### Merchant steps

1. Open the collection schema → **Add field**.
2. Choose type **Commerce** (or a saved profile).
3. Save the schema.
4. Edit an entry → fill Fulfillment, Tax, and Purchase options blocks.
5. Publish → confirm the SKU appears under **Commerce → Catalog**.

---

## Two axes (v2)

### Fulfillment

What happens **after** payment:

| Value | Use for | Checkout collects |
|-------|---------|-------------------|
| `ship` | Physical products | Shipping address |
| `deliver` | Digital downloads | Email (download link after pay) |
| `register` | Classes, events, workshops | Attendee name; capacity from quantity |
| `gift_card` | Sellable store credit | Email; issues gift card codes on pay |
| `none` | Memberships, access grants | Email only |

### Purchase options

One entry can expose **multiple** payment choices. At checkout the buyer picks **one** option (and a variant if applicable).

```json
"purchase_options": [
  {
    "id": "once",
    "label": "Buy once",
    "billing": "one_time",
    "pricing_mode": "fixed",
    "price_cents": 2500,
    "currency": "eur"
  },
  {
    "id": "sub",
    "label": "Monthly",
    "billing": "recurring",
    "interval": "month",
    "pricing_mode": "fixed",
    "price_cents": 1999,
    "currency": "eur"
  },
  {
    "id": "donate",
    "label": "Donate",
    "billing": "one_time",
    "pricing_mode": "variable",
    "price_cents": 2500,
    "min_price_cents": 500,
    "max_price_cents": 100000,
    "currency": "eur"
  }
]
```

| Field | Notes |
|-------|-------|
| `id` | Stable key used by cart (`purchase_option_id`) |
| `label` | Storefront / admin label |
| `billing` | `one_time` or `recurring` |
| `interval` | Required for recurring (`month`, `year`, custom profile intervals) |
| `pricing_mode` | `fixed` or `variable` |
| `price_cents` | Integer cents — **€14.99 → `1499`** |
| `min_price_cents` / `max_price_cents` | For variable mode clamps |
| `currency` | Charge currency (no FX at checkout) |

For `pricing_mode: variable`, pass `amount_cents` when adding to cart (clamped to min/max).

---

## Price tax mode (admin UI)

On the entry Commerce field, the **Tax** block includes:

| Control | Options | Meaning |
|---------|---------|---------|
| **Price tax mode** | Tax included in price · Tax excluded (added at checkout) | Whether `price_cents` already contains VAT |
| **Tax class** | `standard`, `reduced`, `zero`, or custom | Rate table from **Settings → Tax** |

> **Note:** **Price tax mode is on the product entry field**, not under Settings → Tax. Settings → Tax configures *rates and providers*; the field stores whether this product’s shelf price includes tax.

Default `tax_included` is **true** (EU-style). Details: [help-tax.md](help-tax.md).

![Tax modes](/plugins/commerce/assets/docs/tax-modes.svg)

---

## Stored fields

| Field | Notes |
|-------|-------|
| `fulfillment` | `ship`, `deliver`, `register`, `gift_card`, or `none` |
| `tax_included` | Boolean; default `true` (EU). UI label: **Price tax mode** |
| `tax_class` | Product tax class code. Default `standard` |
| `purchase_options[]` | id, label, billing, pricing_mode (`fixed`\|`variable`), price_cents, min/max, currency, interval? |
| `quantity_available` | Catalog projection of Inventory Available, or null for unlimited; capacity for `register` |
| `sku` | Optional; defaults to entry slug |
| `weight_grams` | Physical weight for shipping quotes (EasyPost / weight-based zones) |

### Fulfillment-specific panels

| Fulfillment | Extra fields |
|-------------|--------------|
| `ship` | `weight_grams`; optional `length_mm` / `width_mm` / `height_mm` |
| `deliver` | Asset URL or file reference |
| `register` | Uses quantity as max attendees |
| `gift_card` | Purchase option price = face value issued after payment (no shipping) |
| `none` | No warehouse stock; use Settings → Mappings for tiers |

---

## Full schema examples

### Physical + subscribe (€14.99 once / €12.99 month)

```json
{
  "fulfillment": "ship",
  "tax_included": true,
  "tax_class": "standard",
  "sku": "COFFEE-250-WB",
  "weight_grams": 280,
  "purchase_options": [
    {
      "id": "once",
      "label": "Buy once",
      "billing": "one_time",
      "pricing_mode": "fixed",
      "price_cents": 1499,
      "currency": "eur"
    },
    {
      "id": "sub",
      "label": "Subscribe monthly",
      "billing": "recurring",
      "interval": "month",
      "pricing_mode": "fixed",
      "price_cents": 1299,
      "currency": "eur"
    }
  ],
  "quantity_available": null
}
```

### Workshop ticket (capacity)

```json
{
  "fulfillment": "register",
  "tax_included": true,
  "tax_class": "standard",
  "purchase_options": [
    {
      "id": "ticket",
      "label": "Workshop ticket",
      "billing": "one_time",
      "pricing_mode": "fixed",
      "price_cents": 2500,
      "currency": "eur"
    }
  ],
  "quantity_available": 20
}
```

### Membership (access)

```json
{
  "fulfillment": "none",
  "tax_included": true,
  "purchase_options": [
    {
      "id": "pro-month",
      "label": "Pro monthly",
      "billing": "recurring",
      "interval": "month",
      "pricing_mode": "fixed",
      "price_cents": 1900,
      "currency": "eur"
    }
  ]
}
```

Then map the product → User Management tier under **Settings → Mappings**.

---

## Variants (sizes, options)

For products with options (size, grind, color):

1. Create a **parent entry** with marketing copy and images.
2. Add a **variants** sub-collection on that entry.
3. Put the Commerce field on each **variant sub-entry** (price, SKU, stock) — not only on the parent.

| Pattern | Commerce field location |
|---------|-------------------------|
| Simple product | Parent entry only |
| Product with options | Each variant sub-entry |

Catalog indexes **one row per sellable unit**. Templates must buy via the **variant** id/slug:

```html
<button
  type="button"
  data-commerce-add
  data-entry-id="{variant.id}"
  data-collection="products"
  data-purchase-option-id="once"
  data-qty="1">
  Buy 250g
</button>
```

Always set **distinct SKUs** per variant when using Inventory Locations mode.

---

## Gift card products

Set fulfillment to `gift_card`. The purchase option’s `price_cents` is the **face value** issued after payment (e.g. `5000` = €50 credit). Checkout collects email only. Automation trigger: `commerce_gift_card_issued`. See [help-promotions.md](help-promotions.md).

---

## Legacy migration

Entries saved with the old flat schema (`price_cents` + `billing` only) migrate automatically to a single `purchase_option`, with inferred fulfillment (default `ship` when unknown).

## Not on the fieldtype

| Concern | Where |
|---------|-------|
| Discounts / coupons | Commerce → **Discounts** |
| Affiliate codes | `?ref=` on URLs + discount rules |
| User tier grants | Settings → **Mappings** |
| Shipping zones | Settings → **Shipping** |
| Tax rates | Settings → **Tax** |
| Stock ledger rows | Commerce → **Inventory** |

## Catalog sync

Saving an entry updates `catalog_index.json`. Cart and checkout read from the index, not raw collection files. For countable SKUs, **Inventory** is the system of record and Catalog stores projected availability — [help-catalog-inventory.md](help-catalog-inventory.md).

![Catalog vs Inventory](/plugins/commerce/assets/docs/catalog-vs-inventory.svg)

---

## Common mistakes

| Mistake | Fix |
|---------|-----|
| Empty `purchase_options` | Cart cannot price — add at least one option |
| Price in euros as `14.99` | Use integer cents: `1499` |
| Commerce field only on parent with variants | Put field on each variant sub-entry |
| Looking for tax mode in Settings | It is on the **entry** field |
| EasyPost fails | Set `weight_grams` on `ship` lines |
| Stock wrong | Edit Inventory ledger, not only `quantity_available` on the field |

## Related

- [Getting started](help-getting-started.md)
- [Tax](help-tax.md)
- [Catalog & inventory](help-catalog-inventory.md)
- [Storefront](help-storefront.md)
- [Subscriptions](help-subscriptions.md)
