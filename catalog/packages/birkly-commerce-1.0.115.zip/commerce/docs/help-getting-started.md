# Getting started — first sale

Take a new Birkly site from **plugin off** to a **test Stripe payment** in one sitting.

**Who it's for:** store owners and merchants (no coding required for the admin steps). Site wiring needs a project HTML page — see [Project integration](help-project-integration.md) if you are building the storefront.

## Checklist

1. Enable the Commerce plugin  
2. Connect a payment provider (Stripe sandbox)  
3. Add a Commerce field to a collection  
4. Create a product entry  
5. Add a buy button on the site  
6. Complete a test checkout  

---

## 1. Enable Commerce

1. Open **Settings → Plugins**.
2. Find **Commerce** and activate it.
3. Confirm **Commerce** appears in the admin sidebar.

> **Note:** Commerce replaces the legacy Payments / Shopping Cart plugins for new stores. You can keep legacy data until you migrate (Settings → Import & migrate).

---

## 2. Connect Stripe (or another provider)

1. Open **Commerce → Settings → Connections**.
2. Click **Add Connection**.
3. Choose **Stripe**, paste your **test** secret key, and save.
4. Leave the connection in **sandbox / test** until you have placed a real test order.

![Settings hub — Connections](/plugins/commerce/assets/docs/settings-nav.svg)

| Tip | Detail |
|-----|--------|
| Live mode | Only certified providers can go live; sandbox-only providers stay badged |
| Default provider | Settings → General → Provider selection mode (`auto` or `fixed`) |
| Mollie / others | Same Connections panel — add when you need them |

> **Note:** Tax and shipping providers are separate from the payment connection. Configure them later under Settings → Tax and Settings → Shipping.

---

## 3. Add a Commerce field to a collection

1. Open your product collection (or create one, e.g. `products`).
2. Add a field with type **commerce** (or a saved profile such as `commerce_digital` from **Settings → Fieldtypes**).
3. Save the collection schema.

Example schema fragment:

```json
{
  "name": "pricing",
  "type": "commerce",
  "label": "Pricing"
}
```

Field profiles control which fulfillment types and billing intervals appear. Manage them in **Commerce → Settings → Fieldtypes** — not in the collection editor. Details: [help-fieldtype.md](help-fieldtype.md).

---

## 4. Create a product entry

1. Create a new entry in that collection.
2. Fill title, description, and images as usual.
3. In the **Commerce** field blocks:

| Block | Set for first sale |
|-------|--------------------|
| Fulfillment | `ship` for a physical product, or `deliver` for a digital file |
| Price tax mode | **Tax included in price** (EU default) unless you sell tax-exclusive |
| Tax class | `standard` unless you need reduced/zero |
| Purchase options | One option: **Buy once**, fixed price, your currency |
| SKU / weight | Optional; set `weight_grams` if you will use EasyPost rates |

![Commerce field on the entry](/plugins/commerce/assets/docs/product-commerce-field.svg)

4. Set status to **Published** and save.

> **Note:** Saving the entry updates the **Catalog** index. If the product does not appear at checkout, open Catalog → rebuild index ([help-catalog-inventory.md](help-catalog-inventory.md)).

---

## 5. Add a buy button on the site

On a project page that already loads `birkly-client.js`, add the storefront script and a button:

```html
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
<button
  type="button"
  data-commerce-add
  data-entry-id="YOUR-ENTRY-SLUG"
  data-collection="products"
  data-qty="1">
  Buy
</button>
<script>
  BirklyCommerce.bind(document);
</script>
```

Or use a template function link:

```html
<a href="{commerce_buy_url your-entry-slug products 1}">Buy</a>
```

Full patterns: [help-storefront.md](help-storefront.md) and [help-project-integration.md](help-project-integration.md).

---

## 6. Test checkout with Stripe

1. Open the product page on your site (preview / project URL).
2. Click **Buy** — cart should show the line and money breakdown.
3. Enter a test email and (for ship) a shipping address.
4. Complete payment with a Stripe **test card** (e.g. `4242 4242 4242 4242`).
5. Confirm the order appears under **Commerce → Orders** as paid.
6. For ship products, open **Fulfillment** and mark shipped or create a shipment.

| If this fails… | Check |
|----------------|-------|
| Button does nothing | `commerce-storefront.js` loaded? `BirklyCommerce.bind(document)` called? |
| “Item not in catalog” | Entry published? Catalog rebuild? Correct collection + slug? |
| Payment error | Connections sandbox key valid? Provider live mode off for test? |
| Tax looks double | Price tax mode vs storefront labels — [help-tax.md](help-tax.md) |

---

## After your first test sale

| Next | Guide |
|------|-------|
| Stock counting | [Catalog & inventory](help-catalog-inventory.md) |
| Shipping zones / free shipping | [Shipping](help-shipping.md) |
| Tax classes / B2B | [Tax](help-tax.md) |
| Coupons & gift cards | [Promotions](help-promotions.md) |
| Subscriptions | [Subscriptions](help-subscriptions.md) |
| Go live | Switch Connection to **live** keys; re-test one small real payment |

## Related

- [Overview](help-overview.md) — tab map  
- [Troubleshooting](help-troubleshooting.md) — common blockers  
- [Docs tab](/plugins/commerce/assets/docs/docs-tab.svg) — help lives under Commerce → Docs (1.0.57+)
