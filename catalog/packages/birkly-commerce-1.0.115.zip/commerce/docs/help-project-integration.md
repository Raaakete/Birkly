# Project site integration

End-to-end checklist for wiring Commerce into a Birkly **`project/`** site (HTML + `birkly-client.js`).

**Who it's for:** frontend developers and AI agents building storefronts.

![Checkout flow](/plugins/commerce/assets/docs/checkout-flow.svg)

---

## Prerequisites

| Check | |
|-------|-|
| Commerce plugin active | Settings → Plugins |
| Payment connection | Commerce → Settings → Connections (sandbox for tests) |
| Collection with Commerce field | [help-fieldtype.md](help-fieldtype.md) |
| Published product entry | Catalog shows the SKU |
| Tax / shipping basics | Settings → Tax / Shipping if you sell physical EU goods |
| `get_project_info` → `site_url_prefix` | Use for asset/page URLs |

---

## Checklist

### 1. Schema & content

1. Create or update the products collection with a `commerce` field (or profile).
2. Add purchase options, fulfillment, **Price tax mode**, SKU / weight as needed.
3. For variants: Commerce field on each variant sub-entry.
4. Publish entries; open **Catalog** and rebuild if the item is missing.
5. If countable stock: set Inventory on hand — [help-catalog-inventory.md](help-catalog-inventory.md).

Example sellable unit (€14.99, tax included, ship):

```json
{
  "fulfillment": "ship",
  "tax_included": true,
  "tax_class": "standard",
  "sku": "COFFEE-250-WB",
  "weight_grams": 280,
  "purchase_options": [
    {
      "id": "once",
      "label": "Buy once",
      "billing": "one_time",
      "pricing_mode": "fixed",
      "price_cents": 1499,
      "currency": "eur"
    }
  ]
}
```

### 2. Scripts on every commerce page

```html
<link rel="stylesheet" href="/project/css/style.css">
<!-- … page markup … -->
<script src="/birkly-client.js"></script>
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
<script>
  BirklyCommerce.bind(document);
</script>
```

> **Note:** Without `birkly-client.js`, `{commerce_buy_url}` and loops render as raw text. Without `commerce-storefront.js`, `data-commerce-add` buttons do nothing.

### 3. Product / list page — buy buttons

```html
<button
  type="button"
  data-commerce-add
  data-entry-id="{slug}"
  data-collection="products"
  data-purchase-option-id="once"
  data-qty="1">
  Add to cart
</button>
```

Or:

```html
<a href="{commerce_buy_url slug products 1}">Buy</a>
```

Show price / stock:

```html
<p>From {commerce_price_from slug products}</p>
<p>{commerce_quantity_available slug products} left</p>
```

**Variants:** loop sub-entries and pass each variant’s id — never only the parent.

### 4. Cart page (`cart.html`)

Minimal structure:

```html
<div data-commerce-cart>
  <!-- line items rendered by your markup + getCart() -->
  <div data-commerce-money></div>
</div>

<form data-commerce-checkout>
  <input name="email" type="email" required>
  <div data-commerce-shipping-fields>
    <input name="shipping_name">
    <input name="shipping_line1">
    <input name="shipping_city">
    <input name="shipping_postal_code">
    <input name="shipping_country">
  </div>
  <div data-commerce-attendee-fields hidden>
    <input name="attendee_name">
  </div>
  <div data-commerce-status></div>
  <button type="submit">Pay</button>
</form>

<script src="/birkly-client.js"></script>
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
<script src="https://js.stripe.com/v3/"></script>
<script>
  BirklyCommerce.bind(document);
  BirklyCommerce.on('checkout-ready', async function (data) {
    const stripe = Stripe('pk_test_…'); // publishable key only
    // Mount Payment Element with data.client_secret
    // After confirmPayment, call continueSplitCheckout() if needed
    if (BirklyCommerce.getSplitState().nextGroupKey) {
      await BirklyCommerce.continueSplitCheckout();
    }
  });
</script>
```

Use `renderMoneyRows` for subtotal / shipping / tax / free-shipping progress. Respect `prices_include_tax` — [help-tax.md](help-tax.md).

### 5. Header cart badge

```html
<a href="/project/cart.html">Cart ({commerce_cart_count})</a>
```

### 6. Cache bust

After upgrading Commerce, bust cached JS if the CDN/browser holds an old file:

```html
<script src="/plugins/commerce/assets/commerce-storefront.js?v=1.0.57"></script>
```

Remove buttons that fail after upgrade usually mean a stale storefront script — [help-troubleshooting.md](help-troubleshooting.md).

### 7. Smoke test

1. Add product → cart count increments.  
2. Remove line → cart updates (pass `purchase_option_id` when known).  
3. Address entered → shipping/tax quote appears.  
4. Stripe **test** card pay → order in admin.  
5. Mixed subscribe + one-time → split checkout continues after first payment.  
6. Confirm Fulfillment / download / registration path matches the product’s fulfillment type.

---

## URL prefix

Always resolve assets with `site_url_prefix` from `get_project_info` (often `/project/`). Wrong:

```html
<link rel="stylesheet" href="/css/style.css">
```

Right:

```html
<link rel="stylesheet" href="/project/css/style.css">
```

Plugin scripts (`/plugins/commerce/...`, `/birkly-client.js`) stay host-root paths.

---

## Integration patterns

| Pattern | Approach |
|---------|----------|
| Simple buy link | `{commerce_buy_url}` |
| JS cart UX | `data-commerce-add` + cart page |
| Coupons | Input → `BirklyCommerce.setCoupon(code)` |
| Gift cards | `setGiftCard(code)` on checkout |
| Affiliates | `?ref=` on landing URLs |
| Hybrid cart | Collect details once; `continueSplitCheckout` |
| Quotes | Customer opens accept token URL |

---

## Optional pieces

| Feature | Doc |
|---------|-----|
| Hybrid / split pay | [help-hybrid-cart.md](help-hybrid-cart.md) |
| Coupons / gift cards | [help-promotions.md](help-promotions.md) |
| Customer cancel | Settings → General + `lookup_order` |
| Events tickets | Fulfillment `register` on event entry — [help-overview.md](help-overview.md) |
| Automation emails | [help-webhooks-automation.md](help-webhooks-automation.md) |

---

## Common mistakes

| Symptom | Fix |
|---------|-----|
| Raw `{for each}` / `{commerce_…}` | Missing `birkly-client.js` |
| Add does nothing | Missing storefront script or `bind` |
| Unstyled page | Wrong `site_url_prefix` on CSS |
| Empty detail after buy link | Detail page looping whole collection — use URL entry context |
| Tax looks doubled | Inclusive prices + wrong storefront math — use `renderMoneyRows` |
| Remove fails | Pass `purchase_option_id`; upgrade ≥ 1.0.56 |

---

## Related

- [Storefront kit](help-storefront.md)
- [Templating](help-templating.md)
- [Getting started](help-getting-started.md)
- [Developer API](help-developer.md)
- [Fieldtype](help-fieldtype.md)
