# Commerce overview

**Extension — not part of core Birkly.** Activate Commerce under Settings → Plugins.

Commerce is Birkly’s content-first store: payment providers, catalog, cart, checkout, orders, customers, tax, shipping, subscriptions, promotions, and fulfillment — driven by the **Commerce fieldtype** on your CMS entries.

> **Note:** From **Commerce 1.0.57+**, in-plugin help lives under the primary **Docs** tab (Admin → Commerce → Docs). It is not buried inside Settings.

## Who this is for

| Audience | Start here |
|----------|------------|
| Store owners / merchants | [Getting started](help-getting-started.md) → first sale |
| Site builders | [Project integration](help-project-integration.md) + [Storefront](help-storefront.md) |
| Developers / integrators | [Developer API](help-developer.md) + [Templating](help-templating.md) |

## Quick start

1. **Enable** Commerce in Settings → Plugins.
2. Open **Commerce** in the admin sidebar → **Settings → Connections** → add Stripe (or another certified provider).
3. Add a **Commerce** field to a collection schema (`type: commerce` or a saved fieldtype profile).
4. Create a product entry with price, fulfillment, and **Price tax mode**.
5. Wire a buy button on your project site (`commerce-storefront.js` or `{commerce_buy_url}`).
6. Place a **test** order in sandbox, then switch the connection to live when ready.

Full walkthrough: [help-getting-started.md](help-getting-started.md).

![Docs tab in Commerce](/plugins/commerce/assets/docs/docs-tab.svg)

## What you can sell

Commerce uses **two independent settings** on each sellable entry:

| Setting | Meaning | Examples |
|---------|---------|----------|
| **Fulfillment** | What happens after payment | Ship a product, deliver a download, register for a class, issue a gift card, grant membership |
| **Purchase options** | How the buyer pays | One-time €25, or subscribe €12/month — **both on the same item** |

A coffee bag can ship while offering **Buy once** and **Subscribe monthly** on the same variant. Shoppers can also mix fulfillment types in one cart — see [Hybrid cart](help-hybrid-cart.md).

## Admin tabs

| Tab | Purpose |
|-----|---------|
| **Dashboard** | Revenue, orders, AOV, new vs returning customers, cohorts, needs-shipping / SLA breaches, top products |
| **Orders** | Paid history, fulfillment state, money/tax snapshots; **Draft orders / Quotes** (create lines without a cart, preview tax/shipping, send accept link) |
| **Customers** | Profiles by email (addresses, tags, notes), CSV import, order/subscription timeline |
| **Catalog** | Indexed read model of sellable CMS entries — edit products in the entry, rebuild index if needed |
| **Inventory** | Stock ledger (Unlimited / Simple / Locations): on hand, reserved, available, low threshold |
| **Fulfillment** | Open queue + history; create shipments, packing slips, tracking |
| **Subscriptions** | Recurring purchases, retry, cancel, upgrade options |
| **Discounts** | Coupons, automatic rules, affiliates — usage limits, windows, stacking |
| **Gift Cards** | Issue and manage store credit |
| **Settings** | Connections, General, Fieldtypes, Mappings, Import & migrate, Shipping, Tax, Invoices, Emails, Fulfillment adapter, Activity |
| **Docs** | This help hub (primary tab, Commerce 1.0.57+) |

![Settings two-pane hub](/plugins/commerce/assets/docs/settings-nav.svg)

### Settings hub (left nav)

| Panel | What you configure |
|-------|--------------------|
| Connections | Stripe, Mollie, etc. — sandbox vs live |
| General | Currency, stock mode, SLA hours, customer cancel, activity bell, dunning emails |
| Fieldtypes | Saved Commerce field profiles (fulfillment presets, intervals) |
| Mappings | Product → User Management tier |
| Import & migrate | Shopify cutover, CSV, legacy migration |
| Shipping | Manual zones or EasyPost; free-shipping threshold |
| Tax | Manual rates or Stripe Tax; classes; B2B reverse charge |
| Invoices | Company profile, HTML templates, sequential numbers |
| Emails | Transactional + delayed follow-ups (Content Editor) |
| Fulfillment | Manual / Export or EasyPost push + tracking |
| Activity | Payment and shop activity log |

## Docs topic map

| Topic | File | For |
|-------|------|-----|
| Getting started | [help-getting-started.md](help-getting-started.md) | Merchants — zero → first sale |
| Settings reference | [help-settings-reference.md](help-settings-reference.md) | Every Settings panel map |
| Commerce fieldtype | [help-fieldtype.md](help-fieldtype.md) | Pricing, fulfillment, tax mode, variants |
| Catalog & inventory | [help-catalog-inventory.md](help-catalog-inventory.md) | Index, stock modes, low stock |
| Orders & customers | [help-orders-customers.md](help-orders-customers.md) | Orders, drafts, cancel/refund, CSV |
| Storefront kit | [help-storefront.md](help-storefront.md) | `commerce-storefront.js`, cart API, Fieldnotes |
| Template functions | [help-templating.md](help-templating.md) | `{commerce_buy_url}` and friends |
| Tax | [help-tax.md](help-tax.md) | Included vs exclusive, classes, reverse charge |
| Shipping | [help-shipping.md](help-shipping.md) | Zones, EasyPost, free shipping, weight |
| Fulfillment | [help-fulfillment.md](help-fulfillment.md) | Desk, ship/deliver/register, packing slips |
| Subscriptions | [help-subscriptions.md](help-subscriptions.md) | Recurring, dunning, admin actions |
| Promotions | [help-promotions.md](help-promotions.md) | Discounts, gift cards, stacking |
| Hybrid cart | [help-hybrid-cart.md](help-hybrid-cart.md) | Mixed ship + deliver + register + subscribe |
| Shopify cutover | [help-shopify-cutover.md](help-shopify-cutover.md) | One-time Shopify transfer |
| Project integration | [help-project-integration.md](help-project-integration.md) | End-to-end `project/` checklist |
| Developer API | [help-developer.md](help-developer.md) | Public route, actions, payloads |
| Webhooks & Automation | [help-webhooks-automation.md](help-webhooks-automation.md) | Triggers, recipes, inbound webhooks |
| Troubleshooting | [help-troubleshooting.md](help-troubleshooting.md) | Common fixes |

![Catalog vs Inventory](/plugins/commerce/assets/docs/catalog-vs-inventory.svg)

## Catalog, inventory, orders (mental model)

- **Catalog** — checkout read model from CMS entries with Commerce fields. Edit names/prices in the entry.
- **Inventory** — stock ledger (system of record for countable SKUs). Catalog shows projected **Available**.
- **Orders** — historical snapshots. Totals, tax, and shipping are frozen at pay time — not recalculated from today’s catalog.

Details: [help-catalog-inventory.md](help-catalog-inventory.md).

## After payment

**PostPurchaseRouter** runs per paid line:

| Fulfillment | Result |
|-------------|--------|
| **Ship** | Fulfillment adapter (Manual or EasyPost); packing slips; tracking notify |
| **Deliver** | Secure download link |
| **Register** | Attendee recorded; capacity reduced |
| **Gift card** | Store-credit codes issued (face value = unit price) |
| **None** | Tier mapping / Automation only (memberships) |

See [help-fulfillment.md](help-fulfillment.md).

## Cancel vs refund

| Action | What it does |
|--------|----------------|
| **Refund** | Returns money (full, partial, or per line). Does not by itself stop fulfillment. |
| **Cancel** | Stops the order: leaves fulfillment queue, restores stock, cancels registrations, revokes downloads. Optionally refunds remaining balance. |

Cancel is only allowed while nothing has shipped. Details: [help-orders-customers.md](help-orders-customers.md).

## With Events + User Management

| Sell | Commerce field | After payment |
|------|----------------|---------------|
| **Event ticket** | Same entry as `event`; fulfillment `register` | Commerce order + Events → Attendees |
| **Membership** | Fulfillment `none` + recurring option; Settings → Mappings | Commerce → Subscriptions + User Management tier |

Free RSVPs stay in Events only. Paid tickets use Commerce checkout.

## Related

- Public Birkly-Docs: [Commerce plugin](https://docs.birkly.com/06-extensibility/plugins/commerce.html)
- Stuck? [help-troubleshooting.md](help-troubleshooting.md)
