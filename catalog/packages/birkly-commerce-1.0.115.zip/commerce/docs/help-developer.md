# Developer API

Public and admin JSON API for Commerce, plus Automation triggers, webhooks, and AI store-kit notes.

**Who it's for:** integrators, plugin authors, and agents building storefronts or ops tools.

> **Note:** Prefer `/plugins/commerce/assets/commerce-storefront.js` over hand-rolled cart engines. See [help-storefront.md](help-storefront.md).

![Checkout flow](/plugins/commerce/assets/docs/checkout-flow.svg)

---

## Route

```http
POST /api/index.php?route=commerce
Content-Type: application/json

{ "action": "get" }
```

`action` may also be passed as a query parameter. Responses are JSON: `{ status, message?, data }`.

Commerce must be **active** or the route returns 404. Public cart actions rely on the PHP session cookie — use `credentials: 'same-origin'` from browser JS. Admin actions require an authenticated admin session + commerce permissions (and CSRF where the CMS enforces it).

Discover the live public list via `storefront_config` → `public_actions`.

---

## Session cart

Cart state is stored in the PHP session (`CommerceCartSession`). Checkout draft fields (email, shipping address, attendee, VAT id) persist via `set_checkout_draft` and are reused across split-pay groups.

### Public actions

| Action | Key fields | Purpose |
|--------|------------|---------|
| `get` | — | Read cart + money quote (`groups[]`, `split_required`) |
| `add` | `entry_id`, `collection`, `quantity`, `purchase_option_id?`, `amount_cents?`, `parent_id?` | Add line |
| `update` | same identity + `quantity` | Change qty |
| `remove` | `entry_id`, `collection`, `purchase_option_id?` | Remove line (option optional — match-any / default resolve) |
| `clear` | — | Empty cart |
| `set_coupon` | `code` | Apply coupon |
| `set_gift_card` | `code` | Apply gift card |
| `set_affiliate` | `ref` / affiliate id | Affiliate session |
| `set_checkout_draft` | `email`, `shipping_address`, `attendee_name`, `vat_id`… | Persist checkout fields; re-quote |
| `catalog_item` | `entry_id`, `collection`, `country?` | Single catalog row + tax estimate |
| `storefront_config` | — | Flags, version, `public_actions` |
| `checkout` | draft fields + `group_key?`, `checkout_session_id?` | Start payment |
| `confirm_payment` | provider payload | Confirm provider payment |
| `get_quote` / `accept_quote` / `quote_checkout` | `token` | Draft order customer flow |
| `lookup_order` | `email`, `order_id` | Customer order lookup |
| `customer_cancel_order` | `email`, `order_id` | Self-cancel when Settings allow |

### Example: add + quote + checkout

```js
await fetch('/api/index.php?route=commerce', {
  method: 'POST',
  credentials: 'same-origin',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    action: 'add',
    entry_id: 'coffee-250',
    collection: 'products',
    purchase_option_id: 'once',
    quantity: 1
  })
});

await fetch('/api/index.php?route=commerce', {
  method: 'POST',
  credentials: 'same-origin',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    action: 'set_checkout_draft',
    email: 'buyer@example.com',
    shipping_address: {
      name: 'Ada Lovelace',
      line1: 'Unter den Linden 1',
      city: 'Berlin',
      postal_code: '10117',
      country: 'DE'
    }
  })
});

const checkout = await fetch('/api/index.php?route=commerce', {
  method: 'POST',
  credentials: 'same-origin',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ action: 'checkout' })
}).then((r) => r.json());
// checkout.data.client_secret → Stripe Payment Element
```

### Split checkout payload

When the cart mixes one-time + recurring:

1. First `checkout` without `group_key` may return `needs_split: true`, `checkout_session_id`, and `groups[]`.
2. Pay with `group_key` + `checkout_session_id` for the first group.
3. Continue with the next group (storefront: `continueSplitCheckout()`).

See [help-hybrid-cart.md](help-hybrid-cart.md).

---

## Admin actions (selected)

Require authenticated admin + commerce permissions. Non-exhaustive — prefer admin UI for day-to-day ops.

| Area | Actions |
|------|---------|
| Catalog | `list_catalog`, `reindex_catalog` / `rebuild_catalog` |
| Inventory | `save_stock_mode`, `reconcile_inventory`, `list_warehouse_stock`, `save_warehouse_stock`, `list_warehouses`, `save_warehouse`, `transfer_warehouse_stock` |
| Orders | `list_orders`, `get_order`, `export_orders_csv`, `refund_order`, `cancel_order`, `add_order_note`, `set_order_tags` |
| Fulfillment | `list_fulfillment_desk`, `create_shipment`, `packing_slips`, `bulk_mark_shipped`, `update_order_shipment` |
| Customers | `list_customers`, `get_customer`, `save_customer`, `import_customers_csv`, `delete_customer`, `customer_timeline` |
| Subscriptions | `list_subscriptions`, `get_subscription`, `cancel_subscription`, `retry_subscription_payment`, `list_subscription_upgrade_options`, `upgrade_subscription` |
| Discounts | `list_discounts`, `save_discount`, `delete_discount` |
| Gift cards | `list_gift_cards`, `issue_gift_card`, `void_gift_card` |
| Drafts / quotes | `draft_order_create`, `draft_order_update`, `draft_order_preview`, `draft_order_get`, `draft_order_search_catalog`, `draft_order_checkout`, `create_quote`, `list_quotes`, `cancel_quote` |
| Shipping / tax | `list_shipping_zones`, `save_shipping_zones`, `list_shipping_rate_providers`, `list_tax_rules`, `save_tax_rules`, `list_tax_providers` |
| Invoices / emails | profile + template CRUD, `process_scheduled_emails`, `send_test_email` |
| Import | `import_csv`, `import_live_*`, `shopify_cutover_*`, migration_* |
| Mappings | `list_mappings`, `save_mapping`, `create_membership_mapping`, `list_membership_tiers` |
| Analytics | `analytics_summary`, `analytics_export_csv`, `activity_counts` |
| Webhooks | `get_inventory_webhook_config`, `rotate_inventory_webhook_secret` |

---

## Money & cart fields (integrators)

| Field | Meaning |
|-------|---------|
| `subtotal_cents` | Lines before shipping/tax adjustments |
| `shipping_cents` | Quoted shipping |
| `tax_cents` | Tax amount (display / breakdown) |
| `tax_add_cents` | Amount added to charge (0 when included; may be negative under reverse charge) |
| `prices_include_tax` | Shelf prices already include VAT |
| `discount_cents` / `gift_card_cents` | Promotions on one-time group |
| `total_cents` | Amount to charge for current group |
| `free_shipping_*` | Threshold progress fields |
| `split_required` / `groups[]` | Hybrid billing groups |

Prices are **integer cents**. Example: €14.99 → `1499`.

---

## Webhooks & providers

Payment providers (Stripe, etc.) send webhooks to the CMS/provider endpoints configured at connection time. Commerce applies subscription status (`past_due`, `canceled`, `active`) and payment confirmation through the provider adapter on `commerce_shelf`.

| Inbound webhook | Endpoint | Purpose |
|-----------------|----------|---------|
| EasyPost tracking | `api/commerce_webhooks.php?platform=easypost` | Shipment tracking → `commerce_tracking_updated` |
| Shopify inventory | `api/commerce_webhooks.php?platform=shopify` | SKU stock sync |
| Woo inventory | `api/commerce_webhooks.php?platform=woocommerce` | SKU stock sync |

> **Note:** Never expose secret keys in project HTML. Connections store secrets server-side; the storefront only receives `client_secret` (or equivalent) at checkout time.

Full Automation + webhook guide: [help-webhooks-automation.md](help-webhooks-automation.md).

---

## Automation triggers

Registered when Commerce (and Automation) are active:

| Trigger | Typical use |
|---------|-------------|
| `commerce_order_paid` / `commerce_order_created` | Ops + receipt |
| `commerce_order_receipt` / `commerce_order_admin_notify` | Emails |
| `commerce_order_refunded` / `commerce_order_canceled` | Lifecycle |
| `commerce_physical_fulfilled` | Ship adapter |
| `commerce_shipment_created` / `commerce_order_shipped` / `commerce_tracking_updated` | Shipping notify |
| `commerce_digital_delivered` | Download ready |
| `commerce_event_registered` | Ticket confirm |
| `commerce_gift_card_issued` | Code delivery |
| `commerce_membership_started` | Tier welcome |
| `commerce_subscription_past_due` / `payment_failed` / `recovered` / `renewed` / `canceled` / `upgraded` | Dunning & plan changes |
| `commerce_low_stock` | Restock alert |
| `payment_succeeded` / `payment_failed` | Legacy/generic payment blocks |

Import recipes from Automation → Commerce recipe pack (`recipes/commerce/`).

---

## Shelf services

| Service id | Role |
|------------|------|
| `commerce_shelf` | Primary payment/catalog API for consumer plugins |
| `payment_shelf` | Legacy alias (same instance) |

---

## MCP / store kit notes

- AI topic slug: `commerce` / playbook **`commerce-store-kit`**
- Plugin docs register via `register_plugin_docs` (`docs/help-*.md`, `docs/ai-context.md`)
- Agents should: define Commerce fields before entries; use storefront script; avoid custom fetch that bypasses session cart; pass variant ids for options
- In-admin help: **Commerce → Docs**
- **Inbound MCP** (`register_plugin_mcp_tools`) is admin-side: `commerce_*` tools in `docs/mcp_tools.php`.
- **WebMCP** (`birkly_webmcp_register_tools`) is visitor-side: `birkly_commerce_*` tools in `includes/webmcp_tools.php`. Enable in Discovery → WebMCP. See [webmcp-tools.md](webmcp-tools.md).

### Agent checklist

1. `list_plugins` — confirm Commerce active  
2. Schema with `type: commerce` + full `purchase_options`  
3. `create_entry` with `status: published`  
4. `rebuild_catalog` if missing  
5. Wire `commerce-storefront.js` + `data-commerce-add`  
6. Sandbox Stripe pay → verify Orders  

---

## Common mistakes

| Mistake | Fix |
|---------|-----|
| Custom `fetch` without credentials | Session cart empty — use `same-origin` or storefront kit |
| Parent id for variants | Pass variant sub-entry id |
| Adding `tax_cents` again on EU prices | Use `tax_add_cents` / `renderMoneyRows` |
| Ignoring `needs_split` | Continue with `group_key` + session id |
| Secrets in HTML | Keep keys in Connections only |

---

## Template + project

| Piece | Doc |
|-------|-----|
| Template functions | [help-templating.md](help-templating.md) |
| Storefront JS | [help-storefront.md](help-storefront.md) |
| Project checklist | [help-project-integration.md](help-project-integration.md) |
| Field schema | [help-fieldtype.md](help-fieldtype.md) |
| Settings panels | [help-settings-reference.md](help-settings-reference.md) |
| Webhooks / Automation | [help-webhooks-automation.md](help-webhooks-automation.md) |

## Related

- [Hybrid cart](help-hybrid-cart.md)
- [Troubleshooting](help-troubleshooting.md)
