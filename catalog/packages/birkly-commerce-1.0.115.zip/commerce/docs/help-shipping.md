# Shipping

Configure how Commerce quotes shipping for **`ship`** fulfillment lines. Digital (`deliver`), register, gift card, and `none` lines do **not** need a shipping address for fulfillment (an address may still be used for tax).

**Who it's for:** merchants shipping physical goods; developers reading free-shipping cart fields.

![Checkout flow — address unlocks shipping quote](/plugins/commerce/assets/docs/checkout-flow.svg)

---

## Merchant quick start

1. Open **Commerce → Settings → Shipping**.
2. Leave **Shipping rate provider** on **Manual** (or switch to EasyPost when ready).
3. Add at least one **zone** (countries) and a **fallback** rate in cents.
4. On every shippable product / variant, set **Weight (grams)** if you use weight tiers or EasyPost.
5. Optional: set a **free shipping minimum** (cart subtotal in cents).
6. **Save**, then place a test order with a shipping address and confirm the quote.

> **Note:** Shipping **rates** (this panel) are separate from the fulfillment **adapter** (labels/tracking under Settings → Fulfillment). You can quote with Manual zones and still fulfill with EasyPost labels — or the reverse.

---

## Providers

**Commerce → Settings → Shipping**

| Provider | Setting | Behavior |
|----------|---------|----------|
| **Manual** (default) | `commerce_shipping_rate_provider: manual` | Zone table + fallback rate |
| **EasyPost** | `easypost` | Live carrier rates via EasyPost API key; falls back to manual zones on live failure |

| Secret / field | Where | Purpose |
|----------------|-------|---------|
| `commerce_easypost_api_key` | Settings → Shipping | Live quotes **and** reused by EasyPost fulfillment for labels/tracking |

---

## Manual zones

Define zones with country/region matchers and rates (flat and/or weight-based, depending on your zone rows).

| Concept | Meaning | Example |
|---------|---------|---------|
| Zone match | Buyer shipping country (and optional region) | `DE`, `AT`, `CH` |
| Rate | Amount in **cents** for matching `ship` lines | `595` = €5.95 |
| Fallback | Used when no zone matches | Domestic default |
| Weight | Sum of line `weight_grams` × qty when zones use weight tiers | 2 × 400 g = 800 g |

### Example zone thinking

| Cart | Destination | Result |
|------|-------------|--------|
| One coffee bag (400 g), zone DE flat `595` | DE | Shipping `595` cents |
| Same cart, no DE zone | FR (unmatched) | Fallback rate |
| Free-shipping min `5000` (€50), cart goods `5200` | Any | Shipping `0`, `free_shipping_unlocked: true` |

### Product weight

On each shippable Commerce field / variant, set **`weight_grams`** (grams). EasyPost live rates **require** weight. Manual weight tiers also need it.

```json
{
  "fulfillment": "ship",
  "weight_grams": 400,
  "length_mm": 200,
  "width_mm": 120,
  "height_mm": 80,
  "purchase_options": [
    {
      "id": "once",
      "label": "Buy once",
      "billing": "one_time",
      "pricing_mode": "fixed",
      "price_cents": 1499,
      "currency": "eur"
    }
  ]
}
```

Optional parcel dimensions: `length_mm`, `width_mm`, `height_mm` (used when the rate provider supports them).

---

## EasyPost live rates

1. Set **Shipping rate provider** to **EasyPost**.
2. Enter the **EasyPost API key** and save (status shows when stored). Prefer test keys until go-live.
3. On every `ship` SKU, set **`weight_grams` > 0**. Missing weight → live quote error — fix the product before checkout can price shipping.
4. At checkout, the customer picks a returned rate; the order stores `shipping_lines` with `source: easypost` when live rates succeed.

### Fallback

When EasyPost fails (missing destination, API error, no rates), Commerce quotes **manual zones** instead and may mark the snapshot with `fallback: true`. **Keep zones configured** even if you primarily use EasyPost so checkout can continue.

### Tips

1. Prefer test/prod keys intentionally (EasyPost mode follows the key).
2. Only **`ship` lines** contribute to weight and rates — mixed carts (ship + deliver + register) calculate shipping from the ship subset only.
3. For labels and tracking after pay, also set **Settings → Fulfillment → EasyPost** — [help-fulfillment.md](help-fulfillment.md).

---

## Free shipping threshold

Under Shipping settings, enable a **minimum cart amount** for free shipping:

| Field | Meaning | Example |
|-------|---------|---------|
| `free_shipping_min_cents` | Threshold in cents (`0` = off) | `5000` = free over €50 |
| Cart `free_shipping_remaining_cents` | Amount still needed | `1200` = €12 to go |
| Cart `free_shipping_unlocked` | True when threshold met **or** a free-shipping promo applied | `true` / `false` |

Storefront helper `BirklyCommerce.renderMoneyRows(cart)` can show progress toward free shipping.

> **Note:** A Discounts rule with `value_type: free_shipping` also zeros shipping and sets `free_shipping_unlocked` — see [help-promotions.md](help-promotions.md). Threshold and promo can both apply; shipping becomes free when **either** unlocks it.

---

## Quote timing

Shipping (and tax) are re-quoted when:

1. The cart has `ship` lines, and  
2. A shipping address is on the checkout draft (`set_checkout_draft`) or passed into checkout.

Until an address exists, shipping may be `0` or estimated — **collect address before showing a final total**.

### Developer: draft → quote

```js
await BirklyCommerce.setCheckoutDraft({
  email: 'buyer@example.com',
  shipping_address: {
    name: 'Ada Lovelace',
    line1: 'Unter den Linden 1',
    city: 'Berlin',
    postal_code: '10117',
    country: 'DE'
  }
});
const cart = await BirklyCommerce.getCart();
// cart.shipping_cents, cart.shipping_lines, cart.free_shipping_remaining_cents
BirklyCommerce.renderMoneyRows(cart);
```

Mixed fulfillment carts: [help-hybrid-cart.md](help-hybrid-cart.md).

---

## Common mistakes

| Symptom | Fix |
|---------|-----|
| Shipping always `0` | Enter shipping address; confirm cart has `fulfillment: ship` lines |
| EasyPost error about weight | Set `weight_grams` on every shippable variant |
| Wrong country rate | Check zone matchers (ISO country codes) and fallback |
| Free shipping never unlocks | Threshold is in **cents**; confirm goods subtotal (not total with tax) |
| Labels missing after pay | Rate provider ≠ adapter — configure Settings → Fulfillment |

---

## Related

- [Fulfillment](help-fulfillment.md)
- [Fieldtype — weight_grams](help-fieldtype.md)
- [Storefront — free shipping fields](help-storefront.md)
- [Promotions — free shipping coupons](help-promotions.md)
- [Hybrid cart](help-hybrid-cart.md)
- [Settings reference](help-settings-reference.md)
