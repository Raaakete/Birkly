# Commerce website tools (WebMCP)

Visitor-facing tools an AI helper can call on your **live public storefront**. These are **off by default**. Enable them in **Discovery → WebMCP** (or Agent Guide → Tools) after turning the Website tools master switch on.

This is **not** the same as Commerce’s inbound MCP tools (`commerce_list_orders`, `commerce_admin_action`, …). Those help AI apps manage your Birkly admin. WebMCP only does what a visitor could already do on the public page.

## Tools

| Tool | Kind | Confirmation | Default |
|------|------|--------------|---------|
| `birkly_commerce_get_cart` | Read | None | Off |
| `birkly_commerce_add_to_cart` | Write | Visitor confirms | Off |
| `birkly_commerce_checkout` | Write | Visitor confirms before paying | Off |

Tools appear in the admin catalog only while Commerce is **installed and active**. Disable or uninstall Commerce and those ids are ignored on the next save/load.

## Storefront surface

The runtime registers Commerce tools only when `window.BirklyCommerce.getCart` is present. Include the storefront helper on shop pages:

```html
<script src="/plugins/commerce/assets/commerce-storefront.js"></script>
<script>
  BirklyCommerce.bind(document);
</script>
```

Without that script, catalog toggles can be on in admin but nothing registers in the visitor’s browser.

## Owner steps

1. Install and activate Commerce.
2. Open **Discovery → WebMCP** and turn Website tools on.
3. Enable the shop actions you want (start with **Read the cart**).
4. Load `commerce-storefront.js` on public product/cart pages.

Sensitive actions never skip confirmation. Checkout always uses the pay consent gate.
