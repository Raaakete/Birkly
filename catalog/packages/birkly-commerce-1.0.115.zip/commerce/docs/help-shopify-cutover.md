# Shopify cutover (one-time transfer)

**Not perpetual sync.** Use **Settings → Import & migrate → Shopify cutover** for a planned move from Shopify into Birkly Commerce. Ongoing product sync remains under the separate **Live store sync (Beta)** Shopify card.

**Who it's for:** merchants migrating off Shopify; operators running dry-run → import → rollback.

---

## Cutover vs other import paths

| Path | Purpose |
|------|---------|
| **Shopify cutover** | Planned move: products + customers + archived orders, with dry-run and rollback |
| **Live store sync (Beta)** | Ongoing **product** catalog sync — not customers/orders |
| **CSV import** | One-time product rows from export files |
| **Legacy migration wizard** | Birkly Shopping Cart / Events → Commerce (when detected) |

Admin path: **Commerce → Settings → Import & migrate → Shopify cutover**.

---

## Before you start

1. Activate **Commerce** (Settings → Plugins).
2. Configure a payment provider under **Settings → Connections** if you will take new orders in Birkly after cutover.
3. Optionally activate **User Management** if buyers will get accounts later (invite / password-reset only — Shopify passwords are **never** imported).
4. Back up `content/` and `data/` before a production import.
5. **Freeze Shopify catalog edits** for the window you are transferring so dry-run counts match import.

---

## Steps 1–3 (solid)

### 1. Prep / connect

1. In Shopify Admin, create a **custom app** (Admin API) with **read** access to **products**, **customers**, and **orders**.
2. Copy the **Admin API access token** and shop domain (`your-store.myshopify.com`).
3. In Birkly: **Commerce → Settings → Import & migrate**.
4. On the **Shopify** beta card under Live store sync, save **shop domain**, **access token**, target **collection**, and default **currency**. Cutover reuses these credentials.
5. Open the **Shopify cutover** panel.
6. Click **1. Test connection** and confirm the API responds.

Do not treat this as a standing two-way sync. Credentials are for transfer (and optional later Beta product sync), not for Birkly writing back to Shopify.

### 2. Map the content model

| Shopify | Birkly |
|---------|--------|
| Product | Parent CMS entry in the target collection (Commerce field) |
| Variants | Variant **sub-entries** (same pattern as CSV / live product import) |
| Images | First image URL mapped onto the product row |
| Customer | Commerce **Customers** profile (`source: shopify`, email unique key) |
| Order (history) | Commerce order with `status: archived` / `source: shopify_archive` |

**Passwords are never imported.** Accounts in User Management stay invite/reset-only.

After import:

1. Set **Price tax mode** and tax classes on products if Shopify prices were tax-inclusive — [help-tax.md](help-tax.md).
2. Rebuild **Catalog** and verify **Inventory** stock mode — [help-catalog-inventory.md](help-catalog-inventory.md).

### 3. Dry-run product import

1. Set **Resources** to `Products only` (or All when ready).
2. Click **2. Dry-run** — review counts and sample titles/SKUs. **No catalog writes** occur.
3. When samples look right, click **3. Import cutover** (requires confirm after dry-run token).
4. Continue with **customers**, then **archived orders** (or run All once).

After products land, open **Catalog** (and CMS entries) to spot-check prices, SKUs, variants, and images before you import history.

---

## Customers and archived orders

Use the same **Resources** selector and dry-run → import flow:

| Resources | What happens |
|-----------|--------------|
| **Customers only** | Upserts Commerce profiles by email; tags / Shopify customer id retained when present; **no passwords** |
| **Archived orders only** | Writes historical orders tagged as Shopify archive; idempotent on Shopify order id |

**Archived orders are commercial history only.** They do **not**:

- Capture payment  
- Decrement / reserve stock  
- Run PostPurchaseRouter fulfillment  
- Fire paid Automation emails  

Treat them as read-only support and reporting history.

Markers on imported archive orders include: `status: archived`, `source: shopify_archive`, `skip_fulfillment` / `skip_inventory` / `skip_automation`.

---

## Rollback

If a batch looks wrong:

1. Click **Rollback last batch** in the Shopify cutover panel, or  
2. Call `shopify_cutover_rollback` with the `batch_id` from the import result.

Rollback removes customers and archived orders created by that cutover batch and rolls back the linked product import when recorded. Prefer rollback over hand-deleting mixed catalog rows.

---

## Steps 4–11 (go-live checklist)

Cutover itself does **not** import gift-card balances, discount rules, tax class mappings, shipping zones, or open fulfillments — recreate those in Commerce after products/customers land.

| Step | Action |
|------|--------|
| **4. Customers** | Dry-run → import; verify under Customers; plan invite / password-reset |
| **5. Orders archive** | Dry-run → import; confirm `archived`, no stock movement, no fulfillment emails |
| **6. Catalog + inventory** | Rebuild catalog; set stock mode; reconcile on-hand vs Shopify |
| **7. Memberships / options** | Map subscriptions to `purchase_options` + Settings → Mappings; test one recurring SKU |
| **8. Storefront smoke** | Rebuild storefront on Birkly (not Liquid); test ship / deliver / register paths — [help-project-integration.md](help-project-integration.md) |
| **9. Gift cards** | Recreate balances when needed; disable Shopify gift-card codes so they are not double-spent |
| **10. Discounts + DNS** | Recreate critical coupons; put Shopify in password/closed mode; point domain to Birkly |
| **11. SEO + hypercare** | Publish redirects; reconcile inventory daily first week; disable fee-charging Shopify apps |

> **Note:** Live store sync (Beta) is a separate path from cutover. Do **not** run conflicting product edits in both systems during cutover week.

---

## API

| Action | Purpose |
|--------|---------|
| `shopify_cutover_test` | Connection check |
| `shopify_cutover_dry_run` | `resources`: `products` \| `customers` \| `orders` \| `all` (comma combos accepted); returns `dry_run_token` / `batch_id` |
| `shopify_cutover_import` | Same resources; requires `confirm: true` or `dry_run_token` |
| `shopify_cutover_rollback` | `{ batch_id }` |

```json
{
  "action": "shopify_cutover_dry_run",
  "resources": "products"
}
```

---

## Out of scope / not claimed

- Perpetual Shopify ↔ Birkly sync of customers or orders  
- Shopify password migration  
- Gift-card **balance** import with cutover alone  
- Discount / promotion rule import  
- Tax class or shipping zone import  
- Open / unfulfilled shipment migration  
- Automatic Liquid → Birkly theme conversion  

---

## Related

- [Catalog & inventory](help-catalog-inventory.md)
- [Orders & customers](help-orders-customers.md)
- [Getting started](help-getting-started.md)
- [Tax](help-tax.md)
- [Project integration](help-project-integration.md)
