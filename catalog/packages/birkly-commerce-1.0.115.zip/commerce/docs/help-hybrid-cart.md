# Hybrid cart (ship + deliver + register + subscribe)

**Extension — Commerce plugin.** One session cart can mix fulfillment types and billing modes. Checkout splits **billing groups** (one-time vs recurring); within the one-time group, mixed fulfillments settle together.

**Who it's for:** merchants selling mixed catalogs; developers implementing split checkout.

![Hybrid cart — one-time vs subscription groups](/plugins/commerce/assets/docs/hybrid-cart.svg)

## Merchant notes

### What shoppers can mix

| Line type | Fulfillment | Billing | Same checkout group? |
|-----------|-------------|---------|----------------------|
| Physical product | `ship` | one-time | One-time group |
| Digital download | `deliver` | one-time | One-time group |
| Event / class | `register` | one-time | One-time group |
| Gift card product | `gift_card` | one-time | One-time group |
| Membership / club | `none` (or product) | recurring | **Separate** subscription group |

Example cart: coffee bag (ship) + PDF guide (deliver) + workshop seat (register) + monthly club (subscribe).

### What buyers enter once

Collect **email**, **shipping address** (only when the cart has `ship` lines), and **attendee name** (when it has `register` lines) on the first step. Commerce stores a checkout draft (`checkout_session_id`) and reuses those details for later groups.

Optional B2B: `vat_id` / `tax_id` on the draft for reverse charge — [help-tax.md](help-tax.md).

### Payment order

1. **One-time group** — all ship + deliver + register + gift_card lines (coupons and gift cards apply here).
2. **Subscription group(s)** — each recurring interval is its own payment (gift cards/coupons do **not** re-apply).

Shipping is calculated only from `ship` lines. Digital-only or register-only carts never require a shipping address for fulfillment (address may still be used for tax if provided).

### After payment

**PostPurchaseRouter** runs per paid order line:

| Fulfillment | Result |
|-------------|--------|
| **Ship** | Fulfillment adapter (Manual export or EasyPost) |
| **Deliver** | Secure download token |
| **Register** | Attendee record + capacity hold/commit |
| **Gift card** | Store-credit codes |
| **Subscribe / none** | Subscription + optional membership mapping |

### Capacity and stock

- **Register** capacity uses catalog `quantity_available` (Inventory Available). Spots are reserved at checkout and committed when paid.
- **Deliver / gift_card / none** do not hold warehouse stock.
- **Ship** lines with tracked SKUs reserve inventory until pay or release.

---

## Developer notes

### Groups API

`buildCartLines` / cart `get` expose:

```json
{
  "split_required": true,
  "groups": [
    {
      "key": "one_time:eur:once",
      "billing": "one_time",
      "lines": []
    },
    {
      "key": "recurring:eur:month",
      "billing": "recurring",
      "interval": "month",
      "lines": []
    }
  ]
}
```

Checkout without `group_key` on a multi-group cart returns `needs_split: true` plus `checkout_session_id` and `groups`. Pass `group_key` + `checkout_session_id` to pay one group.

### Storefront helper

Prefer `/plugins/commerce/assets/commerce-storefront.js`:

```js
BirklyCommerce.checkout({ email, shipping_address, attendee_name }); // auto-starts first group
// … mount Stripe with data.client_secret, then:
await BirklyCommerce.confirmPayment(stripe, elements);
if (BirklyCommerce.getSplitState().nextGroupKey) {
  await BirklyCommerce.continueSplitCheckout(); // reuses draft details
}
```

Helpers: `cartNeedsShipping()`, `cartNeedsAttendee()`, `continueSplitCheckout()`, `getSplitState()` (`currentGroupKey` vs `nextGroupKey`).

Markup hooks:

- `[data-commerce-shipping-fields]` — hidden when cart has no ship lines
- `[data-commerce-attendee-fields]` — shown when cart has register lines
- `[data-commerce-status]` — cleared between attempts; `data-commerce-error` on failure

Money fields across groups: use `tax_add_cents` / `prices_include_tax` from [help-storefront.md](help-storefront.md) — do not double-add included tax on either group.

### Certification

Plugin tests cover the mixed cart E2E path in `tests/run.php` (`hybrid cart ship+deliver+register+subscribe certified`).

### Related platform pieces

- MCP/Agent store kit — AI topic `commerce-store-kit`
- Automation Commerce recipe pack (post-purchase, dunning, low-stock, shipped)
- Ops intelligence — Dashboard cohorts, fulfillment SLA, `commerce_low_stock`

## Related

- [Commerce overview](help-overview.md)
- [Storefront kit](help-storefront.md)
- [Template functions](help-templating.md)
- [Commerce fieldtype](help-fieldtype.md)
- [Subscriptions](help-subscriptions.md)
