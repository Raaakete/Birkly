# Webhooks & Automation

Inbound provider webhooks (payments, tracking, inventory) and outbound Automation triggers / recipe pack.

**Who it's for:** operators wiring email/ops workflows; developers verifying signatures and payloads.

---

## Two different “webhook” ideas

| Kind | Direction | Where |
|------|-----------|-------|
| **Provider / inventory webhooks** | External → Birkly | `api/commerce_webhooks.php` + Connections |
| **Automation webhooks** | Birkly → your URL | Automation plugin workflows (outgoing) |

This page covers Commerce **inbound** endpoints and the **triggers** Automation can listen for. Outgoing Automation HTTP actions are configured in the Automation plugin.

---

## Merchant quick start — recipe pack

1. Activate **Automation** and **Commerce**.
2. Open **Automation** → **Recipe pack**.
3. Import a commerce recipe (imports are **disabled** until you edit placeholders).
4. Replace emails, configure **Setup → SMTP**, enable, and test.

| Recipe id | Name | Trigger |
|-----------|------|---------|
| `commerce-post-purchase-receipt` | Post-purchase receipt | `commerce_order_paid` |
| `commerce-subscription-dunning` | Subscription dunning | `commerce_subscription_payment_failed` |
| `commerce-low-stock-alert` | Low stock alert | `commerce_low_stock` |
| `commerce-order-fulfilled` | Order shipped / fulfilled | `commerce_order_shipped` |

### Useful template variables

| Recipe | Keys |
|--------|------|
| Order paid | `order_id`, `customer_email`, `total_cents`, `currency`, `status`, `lines` |
| Dunning | `subscription_id`, `customer_email`, `attempt_count`, `dunning` |
| Shipped | `order_id`, `shipment_id`, `tracking_number`, `carrier`, `package_count` |
| Low stock | `sku`, `on_hand`, `reserved`, `available`, `threshold` |

Built-in dunning email under Settings → General is a simple fallback — branded multi-step flows belong in Automation.

---

## Automation triggers (Commerce)

Registered when Commerce (and Automation) are active:

### Orders & money

| Trigger | When |
|---------|------|
| `commerce_order_created` | Order record created |
| `commerce_order_paid` | Payment succeeded |
| `commerce_order_receipt` / `commerce_order_admin_notify` | Receipt / admin notify helpers |
| `commerce_order_refunded` | Refund applied |
| `commerce_order_canceled` | Cancel completed |

### Fulfillment

| Trigger | When |
|---------|------|
| `commerce_physical_fulfilled` | Ship adapter / physical path |
| `commerce_shipment_created` | New shipment record |
| `commerce_order_shipped` | Customer-facing shipped notify (when notify enabled) |
| `commerce_tracking_updated` | EasyPost tracker webhook update |
| `commerce_digital_delivered` | Download token issued |
| `commerce_event_registered` | Register / ticket capacity committed |
| `commerce_gift_card_issued` | Sellable gift card codes issued |
| `commerce_membership_started` | Mapping / tier grant path |

### Subscriptions & inventory

| Trigger | When |
|---------|------|
| `commerce_subscription_payment_failed` | Renewal failed → past_due |
| `commerce_subscription_past_due` | Entered past-due |
| `commerce_subscription_recovered` | Recovered after failure |
| `commerce_subscription_renewed` | Successful renewal |
| `commerce_subscription_canceled` | Canceled |
| `commerce_subscription_upgraded` | Plan change |
| `commerce_low_stock` | Available ≤ threshold (debounced per SKU) |

Legacy/generic: `payment_succeeded` / `payment_failed` may still appear in older blocks.

---

## Inbound Commerce webhooks

Endpoint base: `POST /api/commerce_webhooks.php?platform=…`

### EasyPost tracking

| Item | Detail |
|------|--------|
| Platform | `easypost` |
| Configure | Settings → Fulfillment (webhook URL + optional secret) |
| Effect | Updates shipment tracking; may fire `commerce_tracking_updated` |

Requires EasyPost adapter active and Shipping API key saved. See [help-fulfillment.md](help-fulfillment.md).

### Inventory sync (Shopify / Woo)

Real-time stock when an external store still manages quantity:

| Platform | Query | Signature header | Typical topic |
|----------|-------|------------------|---------------|
| Shopify | `platform=shopify` | `X-Shopify-Hmac-Sha256` | Inventory levels update |
| WooCommerce | `platform=woocommerce` | `X-WC-Webhook-Signature` | Product updated |

HMAC-SHA256 of raw body (base64). Unsigned / invalid → **HTTP 401**.

#### Merchant setup (Shopify)

1. Save Shopify live connection under **Settings → Import & migrate**.
2. Open inventory webhooks / Import webhooks UI → copy URL + secret.
3. In Shopify Admin → Notifications → Webhooks → create **Inventory levels update** → paste URL.
4. Paste Shopify shared secret into Birkly → **Save**.
5. Use **Rotate secret** after staff changes or leaks.

Matching **SKU** updates Catalog projection + warehouse on hand. Non-matching SKUs are skipped. Birkly does **not** write stock back to Shopify/Woo in v1.

Admin API: `get_inventory_webhook_config`, `rotate_inventory_webhook_secret`.

---

## Payment provider webhooks

Stripe (and other PSPs) use their own CMS/connection webhook URLs configured when you save a Connection — not always `commerce_webhooks.php`.

Commerce applies:

- Payment confirmation → paid orders / PostPurchaseRouter  
- Subscription invoice failures → `past_due` + dunning triggers  
- Recovery → `active` + recovered triggers  

Never put secret keys in project HTML. Storefront only receives short-lived `client_secret` (or equivalent) at checkout.

---

## Developer notes

### Import recipes via API (Automation plugin)

```http
GET  /api/automation.php?action=list_recipes&pack=commerce
POST /api/automation.php
     { "action": "import_recipe", "recipe_id": "commerce-post-purchase-receipt", "_csrf": "…" }
```

### Low-stock payload example

```json
{
  "sku": "COFFEE-250-WB",
  "on_hand": 4,
  "reserved": 0,
  "available": 4,
  "threshold": 5
}
```

### Security checklist

1. Require HMAC on inventory webhooks.  
2. Rotate secrets after leaks.  
3. Do not fetch arbitrary URLs from webhook handlers.  
4. Keep provider secrets server-side (Connections).  
5. Treat Automation recipe emails as disabled until SMTP + addresses are real.

---

## Related

- [Fulfillment](help-fulfillment.md)
- [Subscriptions](help-subscriptions.md)
- [Catalog & inventory](help-catalog-inventory.md)
- [Developer API](help-developer.md)
- [Settings reference](help-settings-reference.md)
- [Birkly-Docs — Commerce recipes](https://docs.birkly.com/05-automation/commerce-recipes.html)
