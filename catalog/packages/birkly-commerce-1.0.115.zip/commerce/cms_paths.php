<?php
/**
 * CMS path helpers for marketplace / data-volume plugin installs.
 *
 * Relative paths like __DIR__ . '/../../../api/session.php' break when the
 * plugin lives under /app/data/plugins/commerce instead of /app/plugins/commerce.
 */

declare(strict_types=1);

function commerce_cms_root(): string
{
    if (!empty($GLOBALS['commerce_test_cms_root']) && is_string($GLOBALS['commerce_test_cms_root'])) {
        return rtrim($GLOBALS['commerce_test_cms_root'], '/');
    }
    if (function_exists('birkly_project_root')) {
        return birkly_project_root();
    }
    if (defined('BIRKLY_CMS_ROOT')) {
        return (string) BIRKLY_CMS_ROOT;
    }
    $env = getenv('BIRKLY_CMS_ROOT');
    if (is_string($env) && $env !== '') {
        return rtrim($env, '/');
    }
    if (is_dir('/app/core') && is_dir('/app/api')) {
        return '/app';
    }

    // Walk up from this file looking for a Birkly CMS root (core/ + api/).
    $dir = __DIR__;
    for ($i = 0; $i < 6; $i++) {
        if (is_dir($dir . '/core') && is_dir($dir . '/api')) {
            return $dir;
        }
        $parent = dirname($dir);
        if ($parent === $dir) {
            break;
        }
        $dir = $parent;
    }

    // Official plugin repo layout fallback: CMS/plugins/commerce → two levels up
    $candidate = dirname(__DIR__, 2);
    if (is_dir($candidate . '/core') || is_dir($candidate . '/api')) {
        return $candidate;
    }

    return $candidate;
}

function commerce_cms_content_root(): string
{
    return rtrim(commerce_cms_root(), '/') . '/content';
}

function commerce_cms_path(string $relative): string
{
    return rtrim(commerce_cms_root(), '/') . '/' . ltrim(str_replace('\\', '/', $relative), '/');
}

function commerce_require_cms(string $relativePath): void
{
    $path = commerce_cms_path($relativePath);
    if (!is_file($path)) {
        throw new RuntimeException('Commerce could not load CMS file: ' . $relativePath);
    }
    require_once $path;
}
