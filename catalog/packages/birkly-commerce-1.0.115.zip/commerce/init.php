<?php
/**
 * Commerce plugin initialization — shelf, resolver, webhook router, migration.
 */

require_once __DIR__ . '/cms_paths.php';

function commerce_plugin_dir(): string
{
    return __DIR__;
}

function commerce_data_dir(): string
{
    if (function_exists('birkly_data_root')) {
        $dataRoot = birkly_data_root();
        if (is_string($dataRoot) && $dataRoot !== '') {
            $root = rtrim($dataRoot, '/');
            // Prefer dedicated runtime tree (survives Hub zip extract). If the volume
            // cannot create/write plugin-data/, fall back to colocated plugins/commerce
            // (CMS Hub upgrade now preserves non-package paths there).
            $preferred = $root . '/plugin-data/commerce';
            $legacyColocated = $root . '/plugins/commerce';
            $chosen = commerce_resolve_writable_data_dir($preferred, $legacyColocated);
            commerce_ensure_writable_dir($chosen);
            commerce_reconcile_all_data_dirs($chosen);
            return $chosen;
        }
    }
    $legacy = commerce_cms_root() . '/data/plugins/commerce';
    commerce_ensure_writable_dir($legacy);
    commerce_reconcile_all_data_dirs($legacy);
    return $legacy;
}

/**
 * All directories that may hold commerce runtime JSON (historical layouts).
 *
 * @return list<string>
 */
function commerce_candidate_data_dirs(): array
{
    $candidates = [];
    if (function_exists('birkly_data_root')) {
        $dataRoot = birkly_data_root();
        if (is_string($dataRoot) && $dataRoot !== '') {
            $root = rtrim($dataRoot, '/');
            $candidates[] = $root . '/plugin-data/commerce';
            $candidates[] = $root . '/plugins/commerce';
        }
    }
    $candidates[] = commerce_cms_root() . '/data/plugins/commerce';

    $seen = [];
    $unique = [];
    foreach ($candidates as $dir) {
        $key = is_dir($dir) ? (realpath($dir) ?: $dir) : $dir;
        if (isset($seen[$key])) {
            continue;
        }
        $seen[$key] = true;
        $unique[] = $dir;
    }

    return $unique;
}

/**
 * Rough score of persisted merchant data under a directory (for diagnostics).
 */
function commerce_runtime_data_score(string $dir): int
{
    if (!is_dir($dir)) {
        return 0;
    }
    $score = 0;
    foreach (['orders', 'customers', 'connections', 'subscriptions', 'quotes', 'gift_cards'] as $sub) {
        $path = $dir . '/' . $sub;
        if (!is_dir($path)) {
            continue;
        }
        foreach (scandir($path) ?: [] as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            if (is_file($path . '/' . $item)) {
                $score += ($sub === 'orders' || $sub === 'customers') ? 10 : 3;
            }
        }
    }
    foreach ([
        'email_templates.json',
        'invoice_templates.json',
        'invoice_profile.json',
        'encryption_key.txt',
        'order_sequence.json',
        'catalog_index.json',
    ] as $file) {
        if (is_file($dir . '/' . $file) && filesize($dir . '/' . $file) > 2) {
            $score += 5;
        }
    }

    return $score;
}

/**
 * Pull runtime rows from every known historical path into the active data dir.
 * Idempotent: never overwrites existing destination files.
 */
function commerce_reconcile_all_data_dirs(string $canonical): void
{
    static $reconciled = [];
    $key = is_dir($canonical) ? (realpath($canonical) ?: $canonical) : $canonical;
    if (isset($reconciled[$key])) {
        return;
    }
    $reconciled[$key] = true;

    commerce_ensure_writable_dir($canonical);
    foreach (commerce_candidate_data_dirs() as $candidate) {
        if ($candidate === $canonical) {
            continue;
        }
        $cReal = is_dir($candidate) ? realpath($candidate) : false;
        $canReal = is_dir($canonical) ? realpath($canonical) : false;
        if ($cReal !== false && $canReal !== false && $cReal === $canReal) {
            continue;
        }
        if (!is_dir($candidate)) {
            continue;
        }
        commerce_merge_runtime_from($candidate, $canonical);
    }

    commerce_ensure_plugin_data_dir($canonical, commerce_colocated_plugin_dir());
}

function commerce_colocated_plugin_dir(): string
{
    if (function_exists('birkly_data_root')) {
        $dataRoot = birkly_data_root();
        if (is_string($dataRoot) && $dataRoot !== '') {
            return rtrim($dataRoot, '/') . '/plugins/commerce';
        }
    }

    return commerce_cms_root() . '/plugins/commerce';
}

/**
 * Pick a runtime directory the PHP process can actually write.
 */
function commerce_resolve_writable_data_dir(string $preferred, string $fallback): string
{
    if (commerce_ensure_writable_dir($preferred)) {
        return $preferred;
    }
    if (commerce_ensure_writable_dir($fallback)) {
        return $fallback;
    }
    // Last resort: return preferred so callers still have a stable path; save will
    // surface a clear write error with the path.
    return $preferred;
}

/**
 * Create directory (0775) and verify the process can write a probe file.
 */
function commerce_ensure_writable_dir(string $dir): bool
{
    $dir = rtrim($dir, '/');
    if ($dir === '') {
        return false;
    }
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0775, true) && !is_dir($dir)) {
            return false;
        }
    }
    @chmod($dir, 0775);
    if (!is_writable($dir)) {
        return false;
    }
    $probe = $dir . '/.commerce_write_probe_' . bin2hex(random_bytes(3));
    if (@file_put_contents($probe, '1', LOCK_EX) === false) {
        return false;
    }
    @unlink($probe);
    return true;
}

/**
 * Record successful migration into plugin-data/commerce (audit trail only).
 * Reconciliation runs on every bootstrap; the flag does not block future merges.
 */
function commerce_ensure_plugin_data_dir(string $preferred, string $legacyColocated): void
{
    commerce_ensure_writable_dir($preferred);

    $flag = rtrim($preferred, '/') . '/.migrated_from_colocated_plugins';
    $prefReal = realpath($preferred);
    $legReal = is_dir($legacyColocated) ? realpath($legacyColocated) : false;
    if ($legReal === false || ($prefReal !== false && $legReal === $prefReal)) {
        if (!is_file($flag)) {
            @file_put_contents($flag, date('c'));
        }
        return;
    }

    if (!is_file($flag)) {
        @file_put_contents($flag, date('c'));
    }
}

/**
 * Copy runtime basenames from $from into $to when missing (never overwrites).
 * Merges into existing destination directories (e.g. empty Docker skeleton dirs).
 */
function commerce_merge_runtime_from(string $from, string $to): void
{
    if (!is_dir($from)) {
        return;
    }
    if (!is_dir($to)) {
        commerce_ensure_writable_dir($to);
        if (!is_dir($to)) {
            return;
        }
    }
    $fromReal = realpath($from);
    $toReal = realpath($to);
    if ($fromReal !== false && $toReal !== false && $fromReal === $toReal) {
        return;
    }

    $skip = commerce_package_basenames();
    foreach (scandir($from) ?: [] as $item) {
        if ($item === '.' || $item === '..' || isset($skip[$item])) {
            continue;
        }
        // Skip our own probes / one-shot flags from the source tree.
        if (str_starts_with($item, '.commerce_write_probe_')) {
            continue;
        }
        if ($item === '.migrated_from_colocated_plugins' || $item === '.migrated_from_payments') {
            continue;
        }
        $src = $from . '/' . $item;
        $dest = $to . '/' . $item;
        if (is_dir($src)) {
            if (is_dir($dest)) {
                commerce_merge_runtime_from($src, $dest);
            } elseif (!file_exists($dest)) {
                commerce_copy_dir($src, $dest);
            }
        } elseif (!file_exists($dest)) {
            @copy($src, $dest);
        }
    }
}

/**
 * Filenames/dirs that belong to the installable plugin package (not runtime data).
 *
 * @return array<string, true>
 */
function commerce_package_basenames(): array
{
    static $skip = null;
    if (is_array($skip)) {
        return $skip;
    }
    $names = [
        'plugin.php',
        'plugin.json',
        'init.php',
        'cms_paths.php',
        'admin',
        'includes',
        'api',
        'fieldtypes',
        'docs',
        'tests',
        'scripts',
        'assets',
        'build',
        'README.md',
        'CHANGELOG.md',
        '.git',
        '.github',
        '.cursor',
    ];
    $skip = array_fill_keys($names, true);
    return $skip;
}

function commerce_legacy_payments_data_dir(): string
{
    if (function_exists('birkly_data_root')) {
        $dataRoot = birkly_data_root();
        if (is_string($dataRoot) && $dataRoot !== '') {
            return rtrim($dataRoot, '/') . '/plugins/payments';
        }
    }
    return commerce_cms_root() . '/data/plugins/payments';
}

function commerce_plugin_active(): bool
{
    if (!function_exists('birkly_is_plugin_active')) {
        commerce_require_cms('core/plugins.php');
    }
    return birkly_is_plugin_active('commerce');
}

function commerce_active_plugin_id(): string
{
    return 'commerce';
}

function commerce_migrate_legacy_data(): void
{
    $commerceDir = commerce_data_dir();
    $legacyDir = commerce_legacy_payments_data_dir();
    $flagFile = $commerceDir . '/.migrated_from_payments';

    if (is_file($flagFile)) {
        return;
    }

    if (!is_dir($commerceDir)) {
        mkdir($commerceDir, 0755, true);
    }

    if (is_dir($legacyDir) && $legacyDir !== $commerceDir) {
        commerce_copy_dir($legacyDir, $commerceDir);
    }

    commerce_migrate_plugin_settings();

    file_put_contents($flagFile, date('c'));
}

function commerce_copy_dir(string $src, string $dest): void
{
    if (!is_dir($dest)) {
        mkdir($dest, 0755, true);
    }
    foreach (scandir($src) ?: [] as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $from = $src . '/' . $item;
        $to = $dest . '/' . $item;
        if (is_dir($from)) {
            commerce_copy_dir($from, $to);
        } elseif (!is_file($to)) {
            copy($from, $to);
        }
    }
}

function commerce_migrate_plugin_settings(): void
{
    $root = commerce_cms_root();
    $legacyFile = $root . '/settings/plugins/payments.json';
    $commerceFile = $root . '/settings/plugins/commerce.json';

    if (!is_file($legacyFile) || is_file($commerceFile)) {
        return;
    }

    $dir = dirname($commerceFile);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    copy($legacyFile, $commerceFile);
}

/** @return PaymentShelf|null */
function commerce_bootstrap()
{
    static $shelf = null;
    if (!commerce_plugin_active()) {
        return null;
    }
    if ($shelf !== null) {
        return $shelf;
    }

    commerce_migrate_legacy_data();

    $dir = commerce_plugin_dir();
    require_once $dir . '/includes/ProviderInterface.php';
    require_once $dir . '/includes/AbstractProvider.php';
    require_once $dir . '/includes/CredentialStore.php';
    require_once $dir . '/includes/ActivityLog.php';
    require_once $dir . '/includes/ProviderResolver.php';
    require_once $dir . '/includes/WebhookRouter.php';
    require_once $dir . '/includes/PaymentShelf.php';

    foreach ([
        'StripeProvider', 'MollieProvider', 'PayPalProvider', 'AdyenProvider',
        'SquareProvider', 'RazorpayProvider', 'KomojuProvider', 'PayssionProvider',
    ] as $providerFile) {
        require_once $dir . '/includes/providers/' . $providerFile . '.php';
    }

    $store = new PaymentsCredentialStore();
    $activityLog = new PaymentsActivityLog($store->getDataDir());
    $resolver = new PaymentsProviderResolver($store);

    $resolver->register(new StripeProvider());
    $resolver->register(new MollieProvider());
    $resolver->register(new PayPalProvider());
    $resolver->register(new AdyenProvider());
    $resolver->register(new SquareProvider());
    $resolver->register(new RazorpayProvider());
    $resolver->register(new KomojuProvider());
    $resolver->register(new PayssionProvider());

    $shelf = new PaymentShelf($resolver, $store, $activityLog);
    $webhookRouter = new PaymentsWebhookRouter($resolver, $store, $activityLog);
    $shelf->setWebhookRouter($webhookRouter);

    $GLOBALS['commerce_webhook_router'] = $webhookRouter;
    $GLOBALS['commerce_credential_store'] = $store;
    $GLOBALS['commerce_activity_log'] = $activityLog;
    $GLOBALS['payments_webhook_router'] = $webhookRouter;
    $GLOBALS['payments_credential_store'] = $store;
    $GLOBALS['payments_activity_log'] = $activityLog;

    commerce_ensure_catalog_index();

    return $shelf;
}

/**
 * Rebuild catalog index when empty (Hub/data-volume installs may skip activate reindex).
 */
function commerce_ensure_catalog_index(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    if (!commerce_plugin_active()) {
        return;
    }
    if (!class_exists('CatalogIndexer')) {
        require_once commerce_plugin_dir() . '/includes/CatalogIndexer.php';
    }
    try {
        $indexer = new CatalogIndexer();
        $index = $indexer->loadIndex();
        if (!empty($index['entries'])) {
            return;
        }
        $indexer->reindexAll(commerce_cms_content_root());
    } catch (Throwable $e) {
        // non-fatal
    }
}

function commerce_webhook_router(): ?PaymentsWebhookRouter
{
    commerce_bootstrap();
    return $GLOBALS['commerce_webhook_router'] ?? null;
}

function commerce_require_admin_capability(string $capability): void
{
    if (!isset($_SESSION['user'])) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
        exit;
    }
    if (!commerce_user_has_capability($capability)) { http_response_code(403); echo json_encode(['status'=>'error','message'=>'Forbidden']); exit; }
}
function commerce_user_has_capability(string $capability): bool {
    if (!isset($_SESSION['user'])) return false;
    if (in_array($_SESSION['user']['role']??'', ['admin','superadmin'], true)) return true;
    $caps=$_SESSION['user']['capabilities']??$_SESSION['user']['plugin_capabilities']['commerce']??[];
    return is_array($caps) && (in_array($capability,$caps,true) || (in_array($capability,['view_commerce_stats','view_payment_stats'],true)&&(in_array('view_commerce_stats',$caps,true)||in_array('view_payment_stats',$caps,true))) || (in_array($capability,['manage_commerce','manage_payments'],true)&&(in_array('manage_commerce',$caps,true)||in_array('manage_payments',$caps,true))));
}

function commerce_can_view_activity(): bool
{
    if (!isset($_SESSION['user'])) {
        return false;
    }
    $role = $_SESSION['user']['role'] ?? '';
    return in_array($role, ['admin', 'superadmin'], true);
}

function commerce_can_manage(): bool
{
    return commerce_user_has_capability('view_commerce_stats')||commerce_user_has_capability('manage_commerce');
}

function commerce_can_view_stats(): bool
{
    return commerce_can_view_activity();
}

function commerce_require_stats_capability(): void { if (!commerce_can_view_stats()) { http_response_code(403); echo json_encode(['status'=>'error','message'=>'Forbidden']); exit; } }
function commerce_can_view_orders(): bool { return commerce_user_has_capability('view_commerce_orders')||commerce_user_has_capability('manage_commerce'); }

function commerce_get_setting(string $key, $default = null)
{
    if (isset($GLOBALS['commerce_test_settings']) && is_array($GLOBALS['commerce_test_settings'])
        && array_key_exists($key, $GLOBALS['commerce_test_settings'])) {
        return $GLOBALS['commerce_test_settings'][$key];
    }
    if (function_exists('get_plugin_setting')) {
        $val = get_plugin_setting('commerce', $key, null);
        if ($val !== null) {
            return $val;
        }
    }
    return $default;
}

/** Public store/brand name for emails and customer-facing copy (not invoice legal name). */
function commerce_store_display_name(?string $dataDir = null): string
{
    $name = trim((string) commerce_get_setting('commerce_store_name', ''));
    if ($name !== '') {
        return $name;
    }
    if (class_exists('CommerceInvoiceService')) {
        $profile = (new CommerceInvoiceService($dataDir ?? commerce_data_dir()))->getProfile();
        $invoiceName = trim((string) ($profile['company_name'] ?? ''));
        if ($invoiceName !== '') {
            return $invoiceName;
        }
    }
    return 'Commerce';
}

/** Site default charge currency (P14-M1). No FX engine — display = charge currency unless P17 display currency set. */
function commerce_get_default_currency(): string
{
    $cur = strtolower(trim((string) commerce_get_setting('commerce_default_currency', 'eur')));
    return preg_match('/^[a-z]{3}$/', $cur) ? $cur : 'eur';
}

/** Optional display currency for catalog templates (P17-M2). Empty = charge currency. */
function commerce_get_display_currency(): ?string
{
    $cur = strtolower(trim((string) commerce_get_setting('commerce_display_currency', '')));
    if ($cur === '' || $cur === 'same') {
        return null;
    }

    return preg_match('/^[a-z]{3}$/', $cur) ? $cur : null;
}

/**
 * Manual FX rates relative to display currency (P17-M2).
 *
 * @return array<string, float> e.g. ['eur' => 1.0, 'usd' => 1.08]
 */
function commerce_get_fx_rates(): array
{
    $raw = commerce_get_setting('commerce_fx_rates', []);
    if (is_string($raw) && $raw !== '') {
        $decoded = json_decode($raw, true);
        $raw = is_array($decoded) ? $decoded : [];
    }
    if (!is_array($raw)) {
        return [];
    }
    $rates = [];
    foreach ($raw as $code => $rate) {
        $code = strtolower(trim((string) $code));
        if (preg_match('/^[a-z]{3}$/', $code) && is_numeric($rate)) {
            $rates[$code] = (float) $rate;
        }
    }

    return $rates;
}

/** Convert amount_cents from charge currency to display currency using manual rates. */
function commerce_convert_display_cents(int $amountCents, string $fromCurrency): int
{
    $display = commerce_get_display_currency();
    if ($display === null) {
        return $amountCents;
    }
    $from = strtolower($fromCurrency);
    if ($from === $display) {
        return $amountCents;
    }
    $rates = commerce_get_fx_rates();
    if (empty($rates)) {
        return $amountCents;
    }
    $baseRate = (float) ($rates[$display] ?? 0);
    $fromRate = (float) ($rates[$from] ?? 0);
    if ($baseRate <= 0 || $fromRate <= 0) {
        return $amountCents;
    }
    $major = ($amountCents / 100) * ($baseRate / $fromRate);

    return (int) round($major * 100);
}

/**
 * Format price for catalog display with optional FX conversion (P17-M2).
 * Checkout charge amounts are unchanged — use raw cents + charge currency there.
 */
function commerce_format_price_display(int $amountCents, string $chargeCurrency, bool $includeCode = true): string
{
    $display = commerce_get_display_currency() ?? strtolower($chargeCurrency);
    $displayCents = commerce_convert_display_cents($amountCents, $chargeCurrency);
    $major = number_format($displayCents / 100, 2, '.', ',');
    $symbol = match ($display) {
        'usd' => '$',
        'eur' => '€',
        'gbp' => '£',
        'jpy' => '¥',
        'chf' => 'CHF ',
        default => '',
    };
    $formatted = $symbol !== '' ? $symbol . $major : $major;
    if ($includeCode) {
        $formatted .= ' ' . strtoupper($display);
    }

    return trim($formatted);
}

function commerce_init_automation_triggers(): void
{
    if (!function_exists('register_automation_block')) {
        return;
    }

    register_automation_block('trigger', 'payment_succeeded', [
        'name' => 'Payment Succeeded',
        'description' => 'Fires when a payment succeeds',
        'category' => 'Commerce',
        'schema' => [
            'provider' => [
                'type' => 'string',
                'label' => 'Provider (optional)',
                'description' => 'Filter by provider ID, or leave empty for all',
            ],
        ],
        'handler' => function ($config, $context) {
            if (!empty($config['provider'])) {
                return ($context['provider'] ?? '') === $config['provider'];
            }
            return true;
        },
    ]);

    register_automation_block('trigger', 'payment_failed', [
        'name' => 'Payment Failed',
        'description' => 'Fires when a payment fails',
        'category' => 'Commerce',
        'schema' => [
            'provider' => [
                'type' => 'string',
                'label' => 'Provider (optional)',
                'description' => 'Filter by provider ID, or leave empty for all',
            ],
        ],
        'handler' => function ($config, $context) {
            if (!empty($config['provider'])) {
                return ($context['provider'] ?? '') === $config['provider'];
            }
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_order_paid', [
        'name' => 'Commerce Order Paid',
        'description' => 'Fires when a commerce order is paid',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_order_created', [
        'name' => 'Commerce Order Created',
        'description' => 'Fires when a commerce order is created',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_order_receipt', [
        'name' => 'Order Receipt (Customer)',
        'description' => 'Fires when an order is paid — build a customer receipt email. Payload includes lines, totals, tax, and customer_email.',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_order_admin_notify', [
        'name' => 'Order Notification (Admin)',
        'description' => 'Fires when an order is paid — notify the site admin of a new order. Same order payload as the receipt trigger.',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_order_refunded', [
        'name' => 'Order Refunded',
        'description' => 'Fires when an order receives a full or partial refund',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_order_canceled', [
        'name' => 'Order Canceled',
        'description' => 'Fires when an order is canceled (admin or customer), optionally with refund',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_physical_fulfilled', [
        'name' => 'Physical Order Fulfilled',
        'description' => 'Fires when a ship fulfillment line is pushed to the fulfillment adapter',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_shipment_created', [
        'name' => 'Shipment Created',
        'description' => 'Fires when a manual shipment is created (partial or full), with tracking and line quantities',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_order_shipped', [
        'name' => 'Order Shipped (Customer Notify)',
        'description' => 'Fires when a shipment is created with customer notification enabled — use for shipping emails',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_tracking_updated', [
        'name' => 'Tracking Updated',
        'description' => 'Fires when an EasyPost (or compatible) tracking webhook updates shipment status',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_digital_delivered', [
        'name' => 'Digital Delivery Created',
        'description' => 'Fires when a deliver fulfillment line receives a download token',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_event_registered', [
        'name' => 'Event Registration',
        'description' => 'Fires when a register fulfillment line creates an attendee record',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_gift_card_issued', [
        'name' => 'Gift Card Issued',
        'description' => 'Fires when a gift_card fulfillment line issues store credit (purchased), once per code',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_subscription_started', [
        'name' => 'Subscription Started',
        'description' => 'Fires when a recurring none-fulfillment purchase begins',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_membership_started', [
        'name' => 'Membership Started (deprecated)',
        'description' => 'Deprecated alias for commerce_subscription_started — removed in a future release',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_subscription_past_due', [
        'name' => 'Subscription Past Due',
        'description' => 'Fires when a subscription is marked past_due from a provider event',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_subscription_canceled', [
        'name' => 'Subscription Canceled',
        'description' => 'Fires when a subscription is canceled (admin action or provider event)',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_subscription_renewed', [
        'name' => 'Subscription Renewed',
        'description' => 'Fires when a subscription renewal payment succeeds',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_subscription_payment_failed', [
        'name' => 'Subscription Payment Failed',
        'description' => 'Fires when a subscription payment fails (dunning)',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_subscription_recovered', [
        'name' => 'Subscription Recovered',
        'description' => 'Fires when a past_due subscription payment succeeds',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_subscription_upgraded', [
        'name' => 'Subscription Upgraded',
        'description' => 'Fires when a subscription plan is changed to another purchase option',
        'category' => 'Commerce',
        'schema' => [],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);

    register_automation_block('trigger', 'commerce_low_stock', [
        'name' => 'Low Stock',
        'description' => 'Fires once per SKU when available inventory hits or goes below the low-stock threshold (debounced until stock recovers)',
        'category' => 'Commerce',
        'schema' => [
            'sku' => ['type' => 'string', 'description' => 'SKU that crossed the threshold'],
            'on_hand' => ['type' => 'integer', 'description' => 'Quantity on hand'],
            'reserved' => ['type' => 'integer', 'description' => 'Quantity currently reserved'],
            'available' => ['type' => 'integer', 'description' => 'Available = on_hand − reserved'],
            'threshold' => ['type' => 'integer', 'description' => 'Configured low-stock threshold'],
        ],
        'handler' => function ($config, $context) {
            return true;
        },
    ]);
}

/**
 * @return list<array<string, mixed>>
 */
function commerce_dashboard_widgets(): array
{
    if (!commerce_plugin_active() || !commerce_can_view_stats()) {
        return [];
    }

    // The dashboard is useful as soon as Commerce is activated. Administrators
    // can still explicitly turn it off in the plugin settings.
    $enabled = (bool) commerce_get_setting('enable_dashboard_widget', true);
    if (!$enabled) {
        return [];
    }

    $roles = commerce_get_setting('dashboard_widget_roles', ['admin']);
    if (!is_array($roles)) {
        $roles = ['admin'];
    }

    return [[
        'id' => 'commerce-stats',
        'title' => 'Commerce',
        'roles' => $roles,
        'size' => 'md',
        'priority' => 60,
        'endpoint' => '/api/index.php?route=commerce&action=analytics_summary',
        'mount' => 'commerceStats',
        'refresh' => 60,
    ]];
}

function commerce_bootstrap_cart_services(): void
{
    static $loaded = false;
    if ($loaded) {
        return;
    }
    $dir = commerce_plugin_dir();
    require_once $dir . '/includes/CommerceSchema.php';
    require_once $dir . '/includes/ProviderCertification.php';
    require_once $dir . '/includes/TaxProviderInterface.php';
    require_once $dir . '/includes/ManualTaxProvider.php';
    require_once $dir . '/includes/StripeTaxProvider.php';
    require_once $dir . '/includes/TaxProviderResolver.php';
    require_once $dir . '/includes/ShippingRateProviderInterface.php';
    require_once $dir . '/includes/ManualShippingRateProvider.php';
    require_once $dir . '/includes/EasyPostShippingRateProvider.php';
    require_once $dir . '/includes/ShippingRateProviderResolver.php';
    require_once $dir . '/includes/CommerceFieldtypeProfileStore.php';
    require_once $dir . '/includes/CommerceCatalog.php';
    require_once $dir . '/includes/CommerceCartSession.php';
    require_once $dir . '/includes/CommerceOrderStore.php';
    require_once $dir . '/includes/CommerceSubscriptionStore.php';
    require_once $dir . '/includes/CommerceSubscriptionService.php';
    require_once $dir . '/includes/SubscriptionUpgradeService.php';
    require_once $dir . '/includes/CommerceDunningNotifier.php';
    require_once $dir . '/includes/DiscountEngine.php';
    require_once $dir . '/includes/GiftCardStore.php';
    require_once $dir . '/includes/CommerceCustomerStore.php';
    require_once $dir . '/includes/CommerceQuoteStore.php';
    require_once $dir . '/includes/CommerceDraftOrderService.php';
    require_once $dir . '/includes/CommerceAnalyticsService.php';
    require_once $dir . '/includes/CommerceLowStockService.php';
    require_once $dir . '/includes/CommerceNotify.php';
    require_once $dir . '/includes/CommerceInvoiceService.php';
    require_once $dir . '/includes/CommerceEmailService.php';
    require_once $dir . '/includes/CommerceCheckoutService.php';
    require_once $dir . '/includes/CatalogIndexer.php';
    require_once $dir . '/includes/WarehouseStockStore.php';
    require_once $dir . '/includes/InventoryLedger.php';
    require_once $dir . '/includes/StockReservationStore.php';
    require_once $dir . '/includes/PurchaseMappingService.php';
    require_once $dir . '/includes/FulfillmentAdapterInterface.php';
    require_once $dir . '/includes/ManualFulfillmentAdapter.php';
    require_once $dir . '/includes/EasyPostFulfillmentAdapter.php';
    require_once $dir . '/includes/FulfillmentAdapterResolver.php';
    require_once $dir . '/includes/EasyPostTrackingWebhookService.php';
    require_once $dir . '/includes/ShipStationStubAdapter.php';
    require_once $dir . '/includes/ImportService.php';
    require_once $dir . '/includes/ImportHttpClient.php';
    require_once $dir . '/includes/CommerceImportCredentialStore.php';
    require_once $dir . '/includes/ShopifyImportAdapter.php';
    require_once $dir . '/includes/WooImportAdapter.php';
    require_once $dir . '/includes/CommerceLiveImportService.php';
    require_once $dir . '/includes/ShopifyCutoverService.php';
    require_once $dir . '/includes/CommerceSchema.php';
    require_once $dir . '/includes/CommerceBundleSchema.php';
    require_once $dir . '/includes/EventRegistrationStore.php';
    require_once $dir . '/includes/DigitalDeliveryStore.php';
    require_once $dir . '/includes/PostPurchaseRouter.php';
    $loaded = true;
}

function commerce_profile_settings_for_type(string $typeKey): array
{
    commerce_bootstrap_cart_services();
    $store = new CommerceFieldtypeProfileStore();
    return $store->getSettingsForTypeKey($typeKey);
}

function commerce_register_fieldtype_profiles(): void
{
    if (!function_exists('register_plugin_fieldtype') || !commerce_plugin_active()) {
        return;
    }

    if (!class_exists('Birkly\FieldTypes\BaseField')) {
        commerce_require_cms('fieldtypes/BaseField.php');
    }
    require_once commerce_plugin_dir() . '/includes/CommerceSchema.php';
    require_once commerce_plugin_dir() . '/includes/CommerceFieldtypeProfileStore.php';
    require_once commerce_plugin_dir() . '/fieldtypes/Commerce/Commerce.php';

    $pluginId = commerce_active_plugin_id();
    $store = new CommerceFieldtypeProfileStore();

    global $haru_plugin_fieldtypes;
    if (isset($haru_plugin_fieldtypes) && function_exists('unregister_plugin_fieldtype')) {
        $profileTypeKeys = array_map(fn ($p) => $p['type_key'] ?? 'commerce', $store->listProfiles());
        foreach (array_keys($haru_plugin_fieldtypes) as $type) {
            if (($type === 'commerce' || in_array($type, $profileTypeKeys, true))
                && (($haru_plugin_fieldtypes[$type]['plugin_id'] ?? '') === $pluginId)) {
                unregister_plugin_fieldtype($type, $pluginId);
            }
        }
    }

    foreach ($store->listProfiles() as $profile) {
        $typeKey = $profile['type_key'] ?? 'commerce';
        register_plugin_fieldtype(
            $typeKey,
            'Birkly\\FieldTypes\\Commerce\\Commerce',
            $pluginId,
            [
                'label' => $profile['name'] ?? ucwords(str_replace('_', ' ', $typeKey)),
                'description' => 'Commerce field profile',
                'profile_id' => $profile['id'] ?? null,
            ]
        );
    }

    require_once commerce_plugin_dir() . '/fieldtypes/CommerceBundle/CommerceBundle.php';
    register_plugin_fieldtype(
        'commerce_bundle',
        'Birkly\\FieldTypes\\CommerceBundle\\CommerceBundle',
        $pluginId,
        [
            'label' => 'Commerce Bundle',
            'description' => 'Bundle of catalog entries with bundle pricing rules',
        ]
    );
}

function commerce_on_payment_succeeded(array $data): void
{
    if (!commerce_plugin_active()) {
        return;
    }
    commerce_bootstrap_cart_services();
    $paymentId = $data['payment_id'] ?? '';
    if ($paymentId === '') {
        return;
    }
    $checkout = new CommerceCheckoutService();
    $checkout->markPaidByPaymentId($paymentId);
}

function commerce_register_payment_handlers(): void
{
    if (!function_exists('subscribe_to_event')) {
        return;
    }
    static $registered = false;
    if ($registered) {
        return;
    }
    subscribe_to_event('payment_succeeded', function (array $data) {
        commerce_on_payment_succeeded($data);
    });
    $registered = true;
}

function commerce_buy_url(string $entryId = '', string $collectionSlug = '', int $qty = 1, string $purchaseOptionId = ''): string
{
    $base = function_exists('birkly_url')
        ? birkly_url('/api/index.php?route=commerce&action=add')
        : '/api/index.php?route=commerce&action=add';
    $params = [];
    if ($entryId !== '') {
        $params['entry_id'] = $entryId;
    }
    if ($collectionSlug !== '') {
        $params['collection'] = $collectionSlug;
    }
    if ($qty > 1) {
        $params['quantity'] = $qty;
    }
    if ($purchaseOptionId !== '') {
        $params['purchase_option_id'] = $purchaseOptionId;
    }
    if (empty($params)) {
        return $base;
    }
    return $base . '&' . http_build_query($params);
}

function commerce_cart_url(): string
{
    return function_exists('birkly_url')
        ? birkly_url('/api/index.php?route=commerce&action=get')
        : '/api/index.php?route=commerce&action=get';
}

// --- Legacy payments_* aliases ---

function payments_plugin_dir(): string { return commerce_plugin_dir(); }
function payments_plugin_active(): bool { return commerce_plugin_active(); }
function payments_bootstrap() { return commerce_bootstrap(); }
function payments_webhook_router(): ?PaymentsWebhookRouter { return commerce_webhook_router(); }
function payments_require_admin_capability(string $capability): void { commerce_require_admin_capability($capability); }
function payments_can_view_activity(): bool { return commerce_can_view_activity(); }
function payments_can_manage(): bool { return commerce_can_manage(); }
function payments_can_view_stats(): bool { return commerce_can_view_stats(); }
function payments_init_automation_triggers(): void { commerce_init_automation_triggers(); }
function payments_dashboard_widgets(): array { return commerce_dashboard_widgets(); }
